'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.42.0',
  title: 'Revulution Hub 2.42',
  sub: 'Klügerer Schach-Bot, Support-Seite, Regenwolke für die Pflanze und neue Erfolge.',
  items: [
    { open: 'chess', icon: 'chess', title: 'Schach', text: 'Die KI opfert keine Figuren mehr sinnlos und rechnet tiefer. Der Coach sagt viel mehr verschiedene Sätze und erklärt Fehler sofort. Neu: Training, Simulieren (freies Brett, Live-Partien zusehen) und das Rätsel des Tages.' },
    { open: 'tool-support', icon: 'chat', title: 'Support', text: 'Oben neben dem Zahnrad: Feedback geben, Bugs melden oder Hilfe holen – mit Bildschirmfoto. Hintergründe meldest du direkt beim Wallpaper.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Pflanze mit Regenwolke', text: 'Statt Gießkanne: Klick auf die Wolke, sobald sie grau ist – es regnet. Pflanze, Notizen und To-dos bleiben jetzt auch nach einem Neustart erhalten.' },
    { open: 'tool-achievements', icon: 'spark', title: 'Mehr Erfolge', text: 'Neu: Am Stück, Nachteule, Frühaufsteher, Turbo-Leitung und Modder – mit deinem Profilbild.' },
    { open: 'orbit', icon: 'calendar', title: 'Island', text: 'Der Countdown-Ring für den nächsten Termin ist jetzt auch links in der kleinen Island.' },
    { open: 'home', icon: 'layers', title: 'Design', text: 'Titel oben als runde Pille (Klick zeigt die Beschreibung), alle Knöpfe und Felder ganz rund.' },
  ],
};
