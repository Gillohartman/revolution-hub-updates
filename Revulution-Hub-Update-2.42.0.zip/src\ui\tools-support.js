'use strict';

/* 2.42 Support: Feedback, Bugs, Probleme und Meldungen (z. B. ein Premium-Wallpaper) als Ticket ans Admin-Center.
   Andere Seiten können vorausfüllen: window.revSupport({ kind, ref, refName, img, text }). */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-support';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const KINDS = [
    ['bug', '🐞', 'Bug melden', 'Etwas funktioniert nicht'],
    ['problem', '🛟', 'Problem', 'Ich komme nicht weiter'],
    ['feedback', '💬', 'Feedback', 'Was dir gefällt oder nicht'],
    ['idea', '💡', 'Idee', 'Neue Funktion vorschlagen'],
    ['wallpaper', '🖼️', 'Hintergrund melden', 'Ein Wallpaper ist falsch oder kaputt'],
  ];
  const st = { kind: 'bug', subject: '', text: '', email: '', ref: '', refName: '', refImg: '', shot: '', withShot: false, busy: false, sent: null, err: '' };
  const load = () => {
    try {
      return JSON.parse(localStorage.getItem('rev-tickets') || '[]');
    } catch {
      return [];
    }
  };

  window.revSupport = (pre = {}) => {
    Object.assign(st, { kind: pre.kind || 'bug', ref: pre.ref || '', refName: pre.refName || '', refImg: pre.img || '', text: pre.text || '', subject: pre.refName ? `Hintergrund: ${pre.refName}` : '', sent: null, err: '' });
    window.hub.open(PAGE);
  };

  function html() {
    const mine = load().slice(0, 5);
    if (st.sent) {
      return `<div class="sup-done"><div class="sup-check">✓</div><h3>Danke! Dein Ticket ist angekommen.</h3><p class="muted">Ticket-Nummer <b>${esc(st.sent.slice(0, 8).toUpperCase())}</b>. Wir schauen es uns so bald wie möglich an.</p><button class="btn primary" data-sup="new">Neues Ticket</button></div>`;
    }
    return `<div class="sup-hero"><div class="sup-ic"><svg viewBox="0 0 24 24"><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="13" width="4" height="6" rx="2"/><rect x="17" y="13" width="4" height="6" rx="2"/><path d="M19 19a3 3 0 0 1-3 3h-3"/></svg></div><div><h3>Wie können wir helfen?</h3><p class="muted">Schreib uns – dein Ticket landet direkt beim Revulution-Team.</p></div></div>
      <div class="sup-kinds">${KINDS.map(([k, e, n, d], i) => `<button class="sup-kind ${st.kind === k ? 'on' : ''}" style="--d:${i * 40}ms" data-sup-kind="${k}"><span>${e}</span><b>${esc(n)}</b><small>${esc(d)}</small></button>`).join('')}</div>
      <div class="sup-form">
        ${st.ref ? `<div class="sup-ref">${st.refImg ? `<img src="${esc(st.refImg)}" alt="" />` : ''}<div><small>Betrifft</small><b>${esc(st.refName || st.ref)}</b></div><button class="sup-x" data-sup="unref" title="Entfernen">✕</button></div>` : ''}
        <input class="input sup-in" data-sup-f="subject" maxlength="80" placeholder="Betreff (kurz)" value="${esc(st.subject)}" />
        <textarea class="input sup-text" data-sup-f="text" maxlength="3000" rows="2" placeholder="Was ist passiert? Je genauer, desto schneller können wir helfen …">${esc(st.text)}</textarea>
        <input class="input sup-in" data-sup-f="email" maxlength="80" placeholder="E-Mail für eine Antwort (optional)" value="${esc(st.email)}" />
        <div class="sup-row"><button class="switch ${st.withShot ? 'on' : ''}" data-sup="shot"></button><span>Bildschirmfoto vom Hub anhängen</span>${st.shot && st.withShot ? `<img class="sup-shot" src="${st.shot}" alt="" />` : ''}</div>
        ${st.err ? `<p class="err">${esc(st.err)}</p>` : ''}
        <button class="btn primary sup-send" data-sup="send" ${st.busy ? 'disabled' : ''}>${st.busy ? 'Wird gesendet …' : 'Ticket senden'}</button>
      </div>
      ${mine.length ? `<h4 class="pc-h">Deine letzten Tickets</h4><div class="sup-mine">${mine.map((x) => `<div><span>${esc(KINDS.find((k) => k[0] === x.kind)?.[1] || '🎫')}</span><b>${esc(x.subject || '(ohne Betreff)')}</b><small>${new Date(x.at).toLocaleDateString('de-CH')} · #${esc(x.id.slice(0, 8).toUpperCase())}</small></div>`).join('')}</div>` : ''}`;
  }

  // Textfeld wächst mit
  const grow = (el) => {
    el.style.height = 'auto';
    el.style.height = `${Math.min(320, el.scrollHeight + 2)}px`;
  };
  document.addEventListener('input', (e) => {
    if (!active()) return;
    const f = e.target.dataset?.supF;
    if (!f) return;
    st[f] = e.target.value;
    if (f === 'text') grow(e.target);
  });
  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const k = e.target.closest('[data-sup-kind]')?.dataset.supKind;
    if (k) {
      st.kind = k;
      return ctx().render();
    }
    const a = e.target.closest('[data-sup]')?.dataset.sup;
    if (!a) return;
    if (a === 'new') {
      Object.assign(st, { sent: null, subject: '', text: '', ref: '', refName: '', refImg: '', shot: '', withShot: false });
      return ctx().render();
    }
    if (a === 'unref') {
      Object.assign(st, { ref: '', refName: '', refImg: '' });
      return ctx().render();
    }
    if (a === 'shot') {
      st.withShot = !st.withShot;
      if (st.withShot && !st.shot) st.shot = await window.hub.support.snap().catch(() => '');
      return ctx().render();
    }
    if (a === 'send') {
      st.busy = true;
      st.err = '';
      ctx().render();
      try {
        const r = await window.hub.support.send({ kind: st.kind, subject: st.subject, text: st.text, email: st.email, ref: st.ref, refName: st.refName, img: st.withShot ? st.shot : '' });
        const list = [{ id: r.id, kind: st.kind, subject: st.subject, at: Date.now() }, ...load()].slice(0, 30);
        localStorage.setItem('rev-tickets', JSON.stringify(list));
        st.sent = r.id;
      } catch (err) {
        st.err = errText(err);
      }
      st.busy = false;
      ctx().render();
    }
  });

  T.register(PAGE, { nav: 'Support', title: 'Support', sub: 'Feedback, Bugs und Hilfe', icon: 'chat', tint: 'linear-gradient(135deg,#38bdf8,#6366f1)', desc: 'Feedback geben, Bugs melden oder Hilfe bekommen – dein Ticket landet direkt beim Revulution-Team.' }, html);
})();
