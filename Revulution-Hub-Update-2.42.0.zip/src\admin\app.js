'use strict';

/*
 * Revolution Hub Admin – eigene App für Hintergründe und Meldungen.
 * Startet über "Revolution Hub.exe --admin" (bzw. electron . --admin) und hat
 * mit der normalen Hub-Oberfläche nichts zu tun. Die Datenbank bleibt dieselbe.
 */
const { app, BrowserWindow, Menu, dialog, ipcMain, shell, safeStorage, nativeImage } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Community } = require('../main/community');
const fbase = require('../main/firebase');
const { CloudBackgrounds, rulesFor } = require('../main/cloud-backgrounds');

function start() {
  const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dataRoot = path.join(appData, 'Revolution Hub');
  app.setName('Revulution Hub Admin');
  app.setPath('userData', path.join(appData, 'Revolution Hub Admin'));
  if (process.platform === 'win32') app.setAppUserModelId('com.revolution.hub.admin');

  if (!app.requestSingleInstanceLock()) {
    app.quit();
    return;
  }

  const community = new Community({ dir: dataRoot, getSettings: () => ({}), saveSettings: () => {} });
  community.ensure();
  let win = null;

  const createWindow = () => {
    const icon = path.join(__dirname, '..', 'ui', 'assets', 'logo.png');
    win = new BrowserWindow({
      width: 1180,
      height: 800,
      minWidth: 860,
      minHeight: 560,
      show: false,
      // 2.36: Glas statt grauer Windows-Leiste – eigene, durchsichtige Titelleiste
      backgroundColor: '#00000000',
      backgroundMaterial: 'acrylic',
      titleBarStyle: 'hidden',
      titleBarOverlay: { color: '#00000000', symbolColor: '#ffffff', height: 40 },
      autoHideMenuBar: true,
      title: 'Revulution Hub Admin',
      ...(fs.existsSync(icon) ? { icon } : {}),
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
      },
    });
    win.loadFile(path.join(__dirname, 'index.html'));
    win.once('ready-to-show', () => win.show());
    win.on('closed', () => {
      win = null;
    });
  };

  ipcMain.handle('admin:status', () => community.adminStatus());

  /* ---------------- Cloud: Anmeldung mit dem Revulution-Konto, Einsendungen prüfen */
  const fb = fbase.client(fbase.accountConfig());
  const cloud = new CloudBackgrounds({ fb });
  const sessionFile = () => path.join(app.getPath('userData'), 'session.bin');
  let session = null;
  let pendingMfa = null;
  const saveSession = () => {
    try {
      if (!session) return fs.rmSync(sessionFile(), { force: true });
      const raw = JSON.stringify({ email: session.email, uid: session.uid, refreshToken: session.refreshToken });
      fs.writeFileSync(sessionFile(), safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(raw) : Buffer.from(raw));
    } catch {
      /* dann eben neu anmelden */
    }
  };
  const restore = async () => {
    try {
      const buf = fs.readFileSync(sessionFile());
      const s = JSON.parse(safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(buf) : buf.toString());
      session = { ...s, ...(await fb.refresh(s.refreshToken)) };
    } catch {
      session = null;
    }
  };
  const restored = (async () => {
    await restore();
    // 2.42: vom Hub übergebene Anmeldung (Strg+Umschalt+A) – dann muss im Admin-Center niemand mehr anmelden
    const h = process.env.REV_ADMIN_HANDOVER;
    delete process.env.REV_ADMIN_HANDOVER;
    if (h) {
      try {
        const s = JSON.parse(h);
        if (s?.refreshToken && (!session || session.uid !== s.uid)) {
          session = { email: s.email, uid: s.uid, refreshToken: s.refreshToken, ...(await fb.refresh(s.refreshToken)) };
          saveSession();
        }
      } catch {
        /* dann normal anmelden */
      }
    }
  })();
  const token = async () => {
    await restored;
    if (!session) throw new Error('Bitte zuerst anmelden.');
    if (Date.now() > session.expires) session = { ...session, ...(await fb.refresh(session.refreshToken)) };
    return session.idToken;
  };
  const cloudState = async () => {
    await restored;
    return { signedIn: Boolean(session), email: session?.email || '', uid: session?.uid || '', needCode: Boolean(pendingMfa) };
  };
  const friendly = (e) => {
    const m = String(e?.message || e);
    if (/PERMISSION_DENIED|403|insufficient/i.test(m)) return new Error('Keine Berechtigung – trag die Regeln unter „Einrichten“ in Firebase ein.');
    return e instanceof Error ? e : new Error(m);
  };
  const wrap = (fn) => async (...args) => {
    try {
      return await fn(...args);
    } catch (e) {
      throw friendly(e);
    }
  };
  ipcMain.handle('admin:cloud-state', cloudState);
  // Käufe & Geschenke: über die Store-Funktionen (nur Admin-Konten, siehe functions/index.js)
  const STORE = 'https://europe-west6-revolutionhub-56a80.cloudfunctions.net';
  const storeCall = async (fn, body) => {
    const t = await token();
    let r;
    try {
      r = await fetch(`${STORE}/${fn}`, { method: body ? 'POST' : 'GET', headers: { 'content-type': 'application/json', authorization: `Bearer ${t}` }, body: body ? JSON.stringify(body) : undefined });
    } catch {
      throw new Error('Store-Server nicht erreichbar.');
    }
    if (r.status === 404) throw new Error('Die Store-Funktionen sind noch nicht hochgeladen (firebase deploy --only functions).');
    const j = await r.json().catch(() => null);
    if (!j?.ok) throw new Error(j?.error || `Fehler ${r.status}`);
    return j;
  };
  ipcMain.handle('admin:sales', wrap(async () => (await storeCall('adminPurchases')).rows || []));
  ipcMain.handle('admin:gift', wrap(async (_e, g) => storeCall('adminGift', { email: String(g?.email || ''), uid: String(g?.uid || ''), coins: Number(g?.coins) || 0, item: String(g?.item || '') })));
  ipcMain.handle('admin:login', wrap(async (_e, email, password) => {
    const r = await fb.signIn(String(email || '').trim(), String(password || ''));
    if (r.mfa) {
      pendingMfa = r.mfa;
      return cloudState();
    }
    session = r;
    saveSession();
    return cloudState();
  }));
  ipcMain.handle('admin:code', wrap(async (_e, code) => {
    if (!pendingMfa) throw new Error('Kein Code erwartet.');
    session = await fb.finishMfa(pendingMfa.pending, pendingMfa.enrollmentId, code);
    pendingMfa = null;
    saveSession();
    return cloudState();
  }));
  ipcMain.handle('admin:logout', () => {
    session = null;
    pendingMfa = null;
    saveSession();
    return cloudState();
  });
  ipcMain.handle('admin:rules', async () => rulesFor((await cloudState()).uid || '<DEINE-UID>'));
  ipcMain.handle('admin:pending', wrap(async () => cloud.pending(await token())));
  ipcMain.handle('admin:tickets', wrap(async () => cloud.tickets(await token())));
  ipcMain.handle('admin:ticket-status', wrap(async (_e, id, status) => cloud.ticketStatus(String(id || ''), String(status || ''), await token())));
  ipcMain.handle('admin:chat-reports', wrap(async () => cloud.chatReports(await token())));
  ipcMain.handle('admin:chat-report-status', wrap(async (_e, id, status) => cloud.chatReportStatus(String(id || ''), String(status || ''), await token())));
  ipcMain.handle('admin:public', wrap(async () => cloud.list(true)));
  ipcMain.handle('admin:approve', wrap(async (_e, id, name) => cloud.approve(String(id || ''), await token(), String(name || ''))));
  ipcMain.handle('admin:reject', wrap(async (_e, id) => cloud.reject(String(id || ''), await token())));
  ipcMain.handle('admin:unpublish', wrap(async (_e, id) => cloud.removePublic(String(id || ''), await token())));
  ipcMain.handle('admin:publish-files', wrap(async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Bilder veröffentlichen', properties: ['openFile', 'multiSelections'], filters: [{ name: 'Bilder', extensions: ['png', 'jpg', 'jpeg', 'webp', 'bmp'] }] });
    if (r.canceled) return 0;
    const t = await token();
    let n = 0;
    for (const file of r.filePaths) {
      let img = nativeImage.createFromPath(file);
      if (img.isEmpty()) continue;
      const { width, height } = img.getSize();
      if (Math.max(width, height) > 1920) img = width >= height ? img.resize({ width: 1920, quality: 'best' }) : img.resize({ height: 1920, quality: 'best' });
      let data = null;
      for (const q of [86, 78, 70, 60, 50]) {
        const url = `data:image/jpeg;base64,${img.toJPEG(q).toString('base64')}`;
        if (url.length < 900 * 1024) {
          data = url;
          break;
        }
      }
      if (!data) continue;
      await cloud.publish({ name: path.basename(file, path.extname(file)), img: data }, t);
      n++;
    }
    return n;
  }));
  ipcMain.handle('admin:copy', (_e, text) => {
    require('electron').clipboard.writeText(String(text || ''));
    return true;
  });
  ipcMain.handle('admin:pick', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'Hintergrundbilder auswählen',
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'Bilder', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'] }],
    });
    return r.canceled ? [] : r.filePaths;
  });
  ipcMain.handle('admin:add', (event, file, name) => community.add(String(file || ''), String(name || '')));
  ipcMain.handle('admin:remove', (event, id) => community.remove(String(id || '')));
  ipcMain.handle('admin:desktop', (event, id) => community.desktop(String(id || '')));
  ipcMain.handle('admin:report-status', (event, id, status) => community.setReport(String(id || ''), String(status || 'open')));
  ipcMain.handle('admin:open-data', async () => {
    const error = await shell.openPath(dataRoot);
    if (error) throw new Error(error);
    return true;
  });
  ipcMain.handle('admin:path', () => dataRoot);

  app.on('second-instance', () => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
  });

  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    createWindow();
    app.on('activate', () => {
      if (!win) createWindow();
    });
  });
  app.on('window-all-closed', () => app.quit());
}

module.exports = { start };
