'use strict';

/*
 * 2.43 Kindersicherung – eingerichtet von einem Elternteil mit eigenem PIN.
 *
 *  - PIN: nur als gesalzener scrypt-Hash gespeichert, nie im Klartext.
 *  - Bildschirmzeit: Tageslimit für den PC (danach Sperrbildschirm mit PIN) und Limits pro App
 *    (danach wird die App für heute geschlossen). Gemessen mit der Bildschirmzeit des Hubs.
 *  - Webseiten: in allen Browsern über die Windows-hosts-Datei gesperrt (einmal Admin-Bestätigung),
 *    mit Kategorien und erlaubten Ausnahmen.
 *  - Schutz: startet mit Windows, Beenden nur mit PIN, Wächter-Aufgabe startet den Hub neu, wenn er beendet wird.
 *
 * Grenzen (ehrlich): Wer auf dem PC Administrator ist, kann das umgehen. Das Kind sollte darum ein
 * normales Windows-Konto (ohne Admin-Rechte) haben.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile, spawn } = require('child_process');

const HOSTS = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'drivers', 'etc', 'hosts');
const BEGIN = '# >>> Revulution Kindersicherung (nicht von Hand ändern) >>>';
const END = '# <<< Revulution Kindersicherung <<<';
const TASK = 'RevulutionHubWaechter';

// Kategorien zum schnellen Sperren
const CATEGORIES = {
  social: { name: 'Soziale Netzwerke', domains: ['tiktok.com', 'instagram.com', 'facebook.com', 'snapchat.com', 'x.com', 'twitter.com', 'reddit.com', 'pinterest.com', 'threads.net', 'bereal.com'] },
  video: { name: 'Videos & Streaming', domains: ['youtube.com', 'twitch.tv', 'netflix.com', 'disneyplus.com', 'primevideo.com', 'kick.com', 'dailymotion.com'] },
  games: { name: 'Spiele-Seiten', domains: ['roblox.com', 'poki.com', 'crazygames.com', 'miniclip.com', 'friv.com', 'epicgames.com', 'store.steampowered.com'] },
  chat: { name: 'Chat & Messenger', domains: ['discord.com', 'discord.gg', 'web.whatsapp.com', 'web.telegram.org', 'omegle.com', 'ome.tv', 'chatroulette.com'] },
  adult: { name: 'Nicht jugendfrei', domains: ['pornhub.com', 'xvideos.com', 'xnxx.com', 'xhamster.com', 'onlyfans.com', 'redtube.com', 'youporn.com'] },
  gambling: { name: 'Glücksspiel', domains: ['stake.com', 'bet365.com', 'pokerstars.com', 'betway.com', 'unibet.com', 'roobet.com'] },
};

const cleanDomain = (d) => String(d || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/[/?#].*$/, '').replace(/[^a-z0-9.-]/g, '').slice(0, 120);
const hashPin = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString('hex');

class Parental {
  /** @param {{ settings: () => any, save: (p: any) => void, screen: () => any, notify: (t: string, b: string) => void, onLock: (on: boolean, info: any) => void, exePath: string, appRoot: string, packaged: boolean }} o */
  constructor(o) {
    this.o = o;
    this.unlockedUntil = 0; // nach richtiger PIN-Eingabe kurz entsperrt (Einstellungen ändern, Beenden)
    this.allowQuit = false;
    this.killed = {}; // heute geschlossene Apps
    this.timer = null;
  }

  cfg() {
    return { enabled: false, pinHash: '', pinSalt: '', dailyMin: 0, appLimits: {}, categories: [], blocked: [], allowed: [], extraMin: 0, extraDay: '', ...(this.o.settings().parental || {}) };
  }
  save(patch) {
    const c = { ...this.cfg(), ...patch };
    this.o.save({ parental: c });
    return c;
  }
  hasPin() {
    const c = this.cfg();
    return Boolean(c.pinHash && c.pinSalt);
  }
  unlocked() {
    return !this.cfg().enabled || Date.now() < this.unlockedUntil;
  }

  /** PIN prüfen (mit kleiner Bremse gegen Durchprobieren) */
  checkPin(pin) {
    const c = this.cfg();
    if (!this.hasPin()) return true;
    const now = Date.now();
    if (this.blockUntil && now < this.blockUntil) throw new Error(`Zu viele Versuche – warte ${Math.ceil((this.blockUntil - now) / 1000)} s.`);
    const ok = crypto.timingSafeEqual(Buffer.from(hashPin(pin, c.pinSalt), 'hex'), Buffer.from(c.pinHash, 'hex'));
    if (!ok) {
      this.fails = (this.fails || 0) + 1;
      if (this.fails >= 5) {
        this.blockUntil = now + 60000;
        this.fails = 0;
      }
      return false;
    }
    this.fails = 0;
    this.unlockedUntil = now + 10 * 60000;
    return true;
  }
  setPin(pin) {
    if (!/^\d{4,8}$/.test(String(pin))) throw new Error('Der PIN hat 4 bis 8 Ziffern.');
    if (this.hasPin() && !this.unlocked()) throw new Error('Erst mit dem alten PIN entsperren.');
    const salt = crypto.randomBytes(16).toString('hex');
    this.save({ pinHash: hashPin(pin, salt), pinSalt: salt });
    this.unlockedUntil = Date.now() + 10 * 60000;
    return true;
  }
  requireUnlocked() {
    if (!this.unlocked()) throw new Error('Gesperrt – bitte zuerst den Eltern-PIN eingeben.');
  }

  state() {
    const c = this.cfg();
    const sum = this.usage();
    return {
      enabled: c.enabled, hasPin: this.hasPin(), unlocked: this.unlocked(), dailyMin: c.dailyMin, appLimits: c.appLimits, categories: c.categories, blocked: c.blocked, allowed: c.allowed,
      catalog: Object.fromEntries(Object.entries(CATEGORIES).map(([k, v]) => [k, { name: v.name, count: v.domains.length }])),
      usedMin: Math.floor(sum.total / 60), apps: sum.apps, extraMin: c.extraDay === today() ? c.extraMin : 0, locked: Boolean(this.lockOn),
    };
  }
  usage() {
    try {
      const s = this.o.screen()?.summary?.();
      return { total: Number(s?.total) || 0, apps: (s?.apps || []).slice(0, 12).map((a) => ({ exe: a.exe, name: a.name, min: Math.floor((a.secs || 0) / 60) })) };
    } catch {
      return { total: 0, apps: [] };
    }
  }

  async update(patch = {}) {
    this.requireUnlocked();
    const c = this.cfg();
    const next = {};
    if (typeof patch.dailyMin === 'number') next.dailyMin = Math.max(0, Math.min(24 * 60, Math.round(patch.dailyMin)));
    if (patch.appLimits && typeof patch.appLimits === 'object') {
      next.appLimits = {};
      for (const [exe, min] of Object.entries(patch.appLimits)) {
        const e = String(exe).toLowerCase().replace(/[^a-z0-9._ -]/g, '').slice(0, 80);
        const m = Math.round(Number(min) || 0);
        if (e && m > 0) next.appLimits[e] = Math.min(24 * 60, m);
      }
    }
    if (Array.isArray(patch.categories)) next.categories = patch.categories.filter((k) => CATEGORIES[k]);
    if (Array.isArray(patch.blocked)) next.blocked = [...new Set(patch.blocked.map(cleanDomain).filter((d) => d.includes('.')))].slice(0, 300);
    if (Array.isArray(patch.allowed)) next.allowed = [...new Set(patch.allowed.map(cleanDomain).filter((d) => d.includes('.')))].slice(0, 300);
    const saved = this.save(next);
    const webChanged = ['categories', 'blocked', 'allowed'].some((k) => k in next);
    if (saved.enabled && webChanged) await this.applyHosts();
    return this.state();
  }

  /** Kindersicherung ein/aus (braucht PIN). Einschalten: Autostart, Wächter, Webseiten-Sperre. */
  async setEnabled(on) {
    if (!this.hasPin()) throw new Error('Lege zuerst einen Eltern-PIN fest.');
    this.requireUnlocked();
    this.save({ enabled: Boolean(on) });
    if (on) {
      this.autostart(true);
      await this.watchdog(true).catch(() => {});
      await this.applyHosts();
      this.start();
    } else {
      await this.watchdog(false).catch(() => {});
      await this.applyHosts(true);
      this.setLock(false);
    }
    return this.state();
  }
  /** Eltern geben heute Extra-Zeit */
  extraTime(min) {
    this.requireUnlocked();
    const c = this.cfg();
    const base = c.extraDay === today() ? c.extraMin : 0;
    this.save({ extraMin: base + Math.max(0, Math.min(600, Math.round(Number(min) || 0))), extraDay: today() });
    this.killed = {};
    this.setLock(false);
    return this.state();
  }

  autostart(on) {
    if (!this.o.packaged || process.platform !== 'win32') return;
    require('electron').app.setLoginItemSettings({ openAtLogin: Boolean(on), path: this.o.exePath, args: ['--hidden'] });
  }
  /** Geplante Aufgabe: jede Minute den Hub starten (läuft er schon, passiert nichts). */
  watchdog(on) {
    if (process.platform !== 'win32' || !this.o.packaged) return Promise.resolve();
    const args = on
      ? ['/Create', '/F', '/SC', 'MINUTE', '/MO', '1', '/TN', TASK, '/TR', `"${this.o.exePath}" --hidden`]
      : ['/Delete', '/F', '/TN', TASK];
    return new Promise((resolve) => execFile('schtasks.exe', args, { windowsHide: true }, () => resolve()));
  }

  /** hosts-Datei: eigener Block zwischen BEGIN/END. Schreiben braucht einmal die Admin-Bestätigung (UAC). */
  domains() {
    const c = this.cfg();
    const set = new Set(c.blocked);
    for (const k of c.categories) for (const d of CATEGORIES[k]?.domains || []) set.add(d);
    for (const a of c.allowed) set.delete(a);
    const out = [];
    for (const d of set) {
      out.push(d);
      if (!d.startsWith('www.')) out.push(`www.${d}`);
    }
    return out;
  }
  async applyHosts(remove = false) {
    if (process.platform !== 'win32') return false;
    let text = '';
    try {
      text = fs.readFileSync(HOSTS, 'utf8');
    } catch {
      text = '';
    }
    const re = new RegExp(`\\r?\\n?${BEGIN.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[\\s\\S]*?${END.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\r?\\n?`, 'g');
    let base = text.replace(re, '\r\n').replace(/\s+$/, '');
    const list = remove || !this.cfg().enabled ? [] : this.domains();
    const next = list.length ? `${base}\r\n\r\n${BEGIN}\r\n${list.map((d) => `0.0.0.0 ${d}`).join('\r\n')}\r\n${END}\r\n` : `${base}\r\n`;
    if (next === text) return true;
    try {
      fs.writeFileSync(HOSTS, next, 'utf8');
    } catch {
      // keine Rechte: einmal als Administrator schreiben (Windows fragt nach)
      const tmp = path.join(os.tmpdir(), `rev-hosts-${Date.now()}.txt`);
      fs.writeFileSync(tmp, next, 'utf8');
      const ps = `Start-Process -FilePath powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-Command',"Copy-Item -LiteralPath '${tmp.replace(/'/g, "''")}' -Destination '${HOSTS}' -Force; ipconfig /flushdns | Out-Null"`;
      await new Promise((resolve) => execFile('powershell.exe', ['-NoProfile', '-Command', ps], { windowsHide: true }, () => resolve()));
      try {
        fs.rmSync(tmp, { force: true });
      } catch {
        /* egal */
      }
      return fs.readFileSync(HOSTS, 'utf8') === next;
    }
    execFile('ipconfig', ['/flushdns'], { windowsHide: true }, () => {});
    return true;
  }

  /* -------- laufende Prüfung (alle 30 s) */
  start() {
    clearInterval(this.timer);
    if (!this.cfg().enabled) return;
    this.timer = setInterval(() => this.check(), 30000);
    setTimeout(() => this.check(), 3000);
  }
  check() {
    const c = this.cfg();
    if (!c.enabled) return this.setLock(false);
    if (this.day !== today()) {
      this.day = today();
      this.killed = {};
    }
    const u = this.usage();
    const extra = c.extraDay === today() ? c.extraMin : 0;
    // Tageslimit für den ganzen PC
    if (c.dailyMin > 0 && u.total / 60 >= c.dailyMin + extra && !this.unlocked()) this.setLock(true, { usedMin: Math.floor(u.total / 60), limit: c.dailyMin + extra });
    else if (this.lockOn && (c.dailyMin === 0 || u.total / 60 < c.dailyMin + extra || this.unlocked())) this.setLock(false);
    // Limits pro App
    for (const [exe, min] of Object.entries(c.appLimits || {})) {
      const a = u.apps.find((x) => String(x.exe).toLowerCase() === exe);
      if (!a || a.min < min + extra || this.unlocked()) continue;
      execFile('taskkill.exe', ['/IM', exe, '/F'], { windowsHide: true }, () => {});
      if (!this.killed[exe]) {
        this.killed[exe] = true;
        this.o.notify('Zeit aufgebraucht', `${a.name || exe}: Das Limit von ${min} min für heute ist erreicht.`);
      }
    }
  }
  setLock(on, info = {}) {
    if (Boolean(this.lockOn) === Boolean(on)) return;
    this.lockOn = Boolean(on);
    this.o.onLock(this.lockOn, info);
  }
}

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

module.exports = { Parental, CATEGORIES };
