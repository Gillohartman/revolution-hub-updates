'use strict';

/*
 * Desktop: Personalisierung mit Vorschau. Hintergrund (Blur + Dim), die
 * Revulution-Leiste und die Widgets lassen sich hier direkt an- und ausschalten.
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const ctx = () => T.ctx();
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const icon = (n, s) => window.icon(n, s);
  const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
  const pc = { live: null, busy: false };
  let deskTab = 'widgets';
  let deskBg = '';

  const settings = () => ctx().state()?.settings || {};
  const widgets = () => ({ sysLive: true, upcoming: true, screentime: true, speed: true, ...(settings().widgets || {}) });
  const blurOn = () => settings().backdropBlur !== false;
  const blurAmount = () => Math.max(0, Math.min(40, Number(settings().backdropBlurAmount ?? 18)));
  const dimAmount = () => Math.max(0, Math.min(0.75, Number(settings().backdropDim ?? 0.3)));
  const backdrop = () => ctx().state()?.desktopBackdrop || '';
  const WALL_NAMES = { nebula: 'Nebula', aurora: 'Aurora', galaxy: 'Galaxy', synthwave: 'Synthwave', liquid: 'Liquid', silk: 'Silk', waves: 'Waves', ocean: 'Ocean', clouds: 'Clouds', mountains: 'Mountains', fireflies: 'Fireflies', bokeh: 'Bokeh', lava: 'Lava', warp: 'Warp' };

  const fmtTime = () => new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const fmtDay = () => new Date().toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
  const pct = (v) => (v == null || Number.isNaN(Number(v)) ? '–' : `${Math.round(Number(v))} %`);

  function paintClock() {
    const time = document.getElementById('desk-time');
    if (time) time.textContent = fmtTime();
    const day = document.getElementById('desk-day');
    if (day) day.textContent = fmtDay();
    document.querySelectorAll('[data-desk-clock]').forEach((el) => (el.textContent = fmtTime()));
  }

  function paintSystem() {
    const l = pc.live;
    if (!l) return;
    const rows = [['cpu', l.cpu], ['ram', l.ramPct], ['gpu', l.gpu]];
    for (const [key, value] of rows) {
      const out = document.querySelector(`[data-desk-pc="${key}"]`);
      if (out) out.textContent = pct(value);
      const bar = document.querySelector(`[data-desk-bar="${key}"]`);
      if (bar) bar.style.width = `${Math.max(0, Math.min(100, Number(value) || 0))}%`;
    }
  }

  async function loadSystem() {
    if (pc.busy) return;
    pc.busy = true;
    try {
      pc.live = await window.hub.pcLive();
      paintSystem();
    } catch {
      /* Werte bleiben beim letzten Stand */
    }
    pc.busy = false;
  }

  /* ------------------------------------------------------------- Vorschauen */
  function stage(extraClass = '') {
    const bg = backdrop() ? ` style="background-image:url('${fileUrl(backdrop())}')"` : '';
    const tint = blurOn() ? dimAmount() : 0.16;
    return `<div class="desk-stage ${blurOn() ? 'is-blur' : ''} ${extraClass}" style="--blur:${blurAmount()}px;--dim:${tint}">
      <div class="desk-stage-bg"${bg}></div>
      <div class="desk-stage-tint"></div>
      <div class="desk-stage-ui">
        <div class="desk-mini-bar"><b>R</b><i></i><i></i><i></i><span></span><em data-desk-clock>${fmtTime()}</em></div>
        <div class="desk-mini-cards">
          <div class="desk-mini-card"><small>System</small><b>23 %</b><i style="width:23%"></i></div>
          <div class="desk-mini-card"><small>RAM</small><b>61 %</b><i style="width:61%"></i></div>
          <div class="desk-mini-card"><small>Netz</small><b>↓ 86</b><i style="width:72%"></i></div>
        </div>
      </div>
      <span class="desk-stage-tag">${blurOn() ? 'Blur an' : 'Klarer Desktop'}</span>
    </div>`;
  }

  function tabOverview() {
    const replace = Boolean(settings().replaceTaskbar);
    return `<div class="desk-grid">
      <section class="desk-widget desk-clock">
        <div><div class="tool-label">Jetzt</div><time id="desk-time">${fmtTime()}</time><div class="desk-day" id="desk-day">${esc(fmtDay())}</div></div>
        <small>Revulution Desktop · ${replace ? 'Revulution-Leiste aktiv' : 'Windows-Taskleiste aktiv'}</small>
      </section>
      <section class="desk-widget desk-system">
        <div class="list-row" style="padding:0"><div class="tool-label">System</div><small class="muted">live</small></div>
        ${[['cpu', 'Prozessor'], ['ram', 'Arbeitsspeicher'], ['gpu', 'Grafikkarte']].map(([key, name]) => `<div class="desk-file"><span>${esc(name)}</span><b data-desk-pc="${key}">–</b><div class="desk-bar"><i data-desk-bar="${key}" style="width:0%"></i></div></div>`).join('')}
      </section>
      <section class="desk-widget">
        <div class="tool-label">Schnellzugriff</div>
        <div class="desk-actions">
          <button class="desk-action" data-desk-open="control">${icon('control', 18)}<b>Kontrollzentrum</b></button>
          <button class="desk-action" data-desk-open="settings">${icon('settings', 18)}<b>Einstellungen</b></button>
          <button class="desk-action" data-desk-tab="background">${icon('image', 18)}<b>Hintergrund</b></button>
          <button class="desk-action" data-desk-action="lock">${icon('shield', 18)}<b>PC sperren</b></button>
        </div>
      </section>
      <section class="desk-widget desk-taskbar">
        <div class="grow"><div class="tool-label">Taskleiste</div><b>Revulution-Leiste</b><small>Ersetzt die Windows-Taskleiste am oberen Rand.</small></div>
        <button class="switch ${replace ? 'on' : ''}" data-desk-taskbar title="Revulution-Leiste ein- oder ausschalten"></button>
        <div class="desk-preview" aria-hidden="true"><i>R</i><i>K</i><i>E</i><span></span><em>${fmtTime()}</em></div>
      </section>
      <section class="desk-widget desk-quick" style="grid-column:1/-1">
        <div class="grow"><div class="tool-label">Kurz eingestellt</div><b>${blurOn() ? `Hintergrund geblurrt · ${blurAmount()} px` : 'Hintergrund klar'}</b><small>${Object.entries(widgets()).filter(([, v]) => v).length} von 4 Widgets aktiv</small></div>
        <div class="desk-pills"><span class="${blurOn() ? 'on' : ''}">Blur</span><span class="${settings().replaceTaskbar ? 'on' : ''}">Leiste</span><span class="on">Widgets</span></div>
      </section>
    </div>`;
  }

  function tabBackground() {
    const list = ctx().state()?.wallpapers || [];
    const dir = ctx().state()?.wallpaperDir || '';
    return `<div class="desk-custom">
      <section class="desk-pane">
        <div class="desk-pane-head"><div><h3>Hintergrund</h3><p>Der echte Windows-Desktop bleibt hinter dem Hub sichtbar – weichgezeichnet und leicht abgedunkelt, damit alles ruhig wirkt.</p></div></div>
        ${stage()}
        <div class="desk-controls">
          <div class="desk-control-row"><div class="grow"><b>Desktop weichzeichnen</b><small>Dein Windows-Hintergrund, weich hinter Karten und Leisten.</small></div><button class="switch ${blurOn() ? 'on' : ''}" data-desk-toggle="backdropBlur"></button></div>
          <label class="desk-control-row"><div class="grow"><b>Blur-Stärke</b><small>Wenig ist dezenter, viel nimmt alle Details raus.</small></div><div class="range"><input type="range" min="0" max="40" step="1" value="${blurAmount()}" data-desk-range="backdropBlurAmount" /><output>${blurAmount()} px</output></div></label>
          <label class="desk-control-row"><div class="grow"><b>Abdunkelung</b><small>Mehr Abdunkelung = besserer Kontrast für weiße Schrift.</small></div><div class="range"><input type="range" min="0" max="0.75" step="0.05" value="${dimAmount()}" data-desk-range="backdropDim" /><output>${Math.round(dimAmount() * 100)} %</output></div></label>
        </div>
      </section>
      <aside class="desk-pane">
        <div class="desk-pane-head"><div><h3>Windows-Hintergrund</h3><p>Ein Klick setzt das Bild als echten Windows-Hintergrund. Der Hub übernimmt es automatisch.</p></div></div>
        <div class="desk-bg-grid">${list
          .map((id) => `<button class="desk-bg-card ${deskBg === id ? 'on' : ''}" data-desk-bg="${esc(id)}" title="${esc(WALL_NAMES[id] || id)}"><img src="${fileUrl(`${dir}/thumbs/${id}.jpg`)}" alt="" loading="lazy" /><span>${esc(WALL_NAMES[id] || id)}</span><i class="desk-bg-check">${icon('check', 12)}</i></button>`)
          .join('')}</div>
      </aside>
    </div>`;
  }

  function tabTaskbar() {
    const on = Boolean(settings().replaceTaskbar);
    return `<div class="desk-custom">
      <section class="desk-pane">
        <div class="desk-pane-head"><div><h3>Taskleiste</h3><p>Die Revulution-Leiste liegt oben, ist komplett transparent und zeigt Apps, Kontrollzentrum und Uhr. Die Windows-Taskleiste übernimmt sie auf allen Monitoren.</p></div></div>
        <div class="desk-choice">
          <button class="desk-choice-card ${on ? 'on' : ''}" data-desk-taskbar-choice="on">
            <div class="desk-choice-pv rev"><div class="desk-mini-bar"><b>R</b><i></i><i></i><i></i><span></span><em>${fmtTime()}</em></div><div class="desk-choice-pop"><span></span><span></span><span></span></div></div>
            <div class="desk-choice-txt"><b>Revulution-Leiste</b><small>Oben, transparent, mit Drawer und Popups.</small></div>
            <i class="desk-choice-dot"></i>
          </button>
          <button class="desk-choice-card ${on ? '' : 'on'}" data-desk-taskbar-choice="off">
            <div class="desk-choice-pv win"><div class="desk-win-taskbar"><span>⊞</span><i></i><i></i><i></i><em>${fmtTime()}</em></div></div>
            <div class="desk-choice-txt"><b>Windows-Taskleiste</b><small>Original unten, nichts wird verändert.</small></div>
            <i class="desk-choice-dot"></i>
          </button>
        </div>
        <div class="desk-controls">
          <div class="desk-control-row"><div class="grow"><b>Revulution-Leiste verwenden</b><small>Blendet die Windows-Taskleiste aus. Im Vollbild verschwindet die Leiste automatisch.</small></div><button class="switch ${on ? 'on' : ''}" data-desk-taskbar></button></div>
          <div class="desk-control-row"><div class="grow"><b>Windows-Startmenü</b><small>Die Windows-Taste öffnet die App-Übersicht oben – nicht das normale Startmenü.</small></div><button class="btn small" data-desk-taskbar-start>Testen</button></div>
        </div>
      </section>
      <aside class="desk-pane desk-side-note">
        <div class="desk-note-ic">${icon('layers', 22)}</div>
        <h3>Was die Leiste kann</h3>
        <div class="desk-checklist">
          <span>${icon('check', 14)} Apps starten und wechseln</span>
          <span>${icon('check', 14)} Kontrollzentrum & Einstellungen</span>
          <span>${icon('check', 14)} Bildschirmzeit als Popup</span>
          <span>${icon('check', 14)} Windows-Taste öffnet den Drawer</span>
          <span>${icon('check', 14)} Vollbild reicht bis ganz nach unten</span>
        </div>
      </aside>
    </div>`;
  }

  function widgetPreview(key) {
    if (key === 'sysLive')
      return `<div class="desk-wpv w-sys"><div><small>CPU</small><b>23 %</b><i style="width:23%"></i></div><div><small>RAM</small><b>61 %</b><i style="width:61%"></i></div><div><small>GPU</small><b>8 %</b><i style="width:8%"></i></div></div>`;
    if (key === 'upcoming')
      return `<div class="desk-wpv w-agenda"><div><em>14:30</em><span>Team-Meeting</span></div><div><em>18:00</em><span>Training</span></div><div><em>Morgen</em><span>Zahnarzt</span></div></div>`;
    if (key === 'screentime')
      return `<div class="desk-wpv w-screen"><div class="w-screen-top"><small>Bildschirmzeit</small><b>2 Std. 14</b></div><div class="w-screen-row"><span>Explorer</span><i style="width:78%"></i></div><div class="w-screen-row"><span>Opera</span><i style="width:52%"></i></div><div class="w-screen-row"><span>Hub</span><i style="width:31%"></i></div></div>`;
    return `<div class="desk-wpv w-speed"><div><small>Down</small><b>86</b></div><div><small>Up</small><b>34</b></div><div><small>Ping</small><b>12</b></div></div>`;
  }

  /* Akzentfarbe + Premium-Widgets (Trading, Stream-Chat) */
  const chat = { state: null, platform: 'tiktok', channel: '' };
  window.hub.streamChat?.onState?.((x) => {
    chat.state = x;
    if (ctx().state()?.active === 'tool-desktop') ctx().render();
  });
  window.hub.streamChat?.state?.().then((x) => {
    chat.state = x;
    if (x?.saved) Object.assign(chat, { platform: x.saved.platform || 'tiktok', channel: x.saved.channel || '' });
  }).catch(() => {});
  function premiumHtml(dw) {
    const s = settings();
    const owns = (id) => Boolean(window.RevStore?.owns('widget', id));
    const ACC = ['#ff2d2d', '#ff9f0a', '#ffd60a', '#30d158', '#64d2ff', '#0a84ff', '#bf5af2', '#ff375f', '#ffffff'];
    const acc = s.widgetAccent || '#ff2d2d';
    const lock = (id, name) => `<div class="desk-prem-lock"><span>${icon('spark', 15)} ${esc(name)} gibt es im Revolution Store.</span><button class="btn small primary" data-desk-store>Im Store ansehen</button></div>`;
    const cs = chat.state || {};
    const status = cs.status === 'live' ? `<span class="desk-live">● LIVE · ${esc(cs.cfg?.channel || '')}</span>` : cs.status === 'connecting' ? '<span class="muted">verbindet …</span>' : cs.status === 'error' ? `<span class="desk-err">${esc(cs.error)}</span>` : '';
    return `<section class="desk-pane desk-prem">
      <div class="desk-prem-row"><div class="grow"><b>Akzentfarbe der Widgets</b><small>Statt Rot – gilt für Uhr, Punkte, Visualizer und Wetter. Tipp: Strg + Rechtsklick auf ein Widget öffnet sein Menü, Strg + Scrollen ändert die Größe.</small></div>
        <div class="desk-acc">${ACC.map((c) => `<button class="${acc.toLowerCase() === c ? 'on' : ''}" style="--c:${c}" data-desk-acc="${c}"></button>`).join('')}<label class="desk-acc-custom" title="Eigene Farbe"><input type="color" value="${esc(acc)}" data-desk-acc-input /></label></div></div>
      <div class="desk-prem-card"><div class="desk-prem-h"><b>Trading</b>${owns('trading') ? `<button class="switch ${dw.trading ? 'on' : ''}" data-desk-prem="trading"></button>` : ''}</div>
        ${owns('trading') ? `<small class="muted">Symbole durch Komma getrennt – Aktien (AAPL), ETFs (SPY), Krypto (BTC-USD), Indizes (^GSPC).</small><input class="input" data-desk-syms value="${esc((s.tradingSymbols || ['AAPL', 'NVDA', 'TSLA', 'BTC-USD']).join(', '))}" />` : lock('trading', 'Das Trading-Widget')}</div>
      <div class="desk-prem-card"><div class="desk-prem-h"><b>Stream-Chat</b>${owns('streamchat') ? `<button class="switch ${dw.streamchat ? 'on' : ''}" data-desk-prem="streamchat"></button>` : ''}</div>
        ${owns('streamchat') ? `<div class="desk-chat-form"><div class="seg">${[['tiktok', 'TikTok'], ['twitch', 'Twitch']].map(([v, n]) => `<button class="${chat.platform === v ? 'on' : ''}" data-desk-plat="${v}">${n}</button>`).join('')}</div><input class="input" data-desk-chan placeholder="${chat.platform === 'twitch' ? 'Twitch-Kanal' : '@TikTok-Name'}" value="${esc(chat.channel)}" />
          ${cs.status && cs.status !== 'off' ? '<button class="btn small" data-desk-chat="stop">Trennen</button>' : '<button class="btn small primary" data-desk-chat="start">Verbinden</button>'}</div>
          <div class="desk-chat-foot">${status}<span class="grow"></span><button class="btn small ${cs.overlay ? '' : 'ghost'}" data-desk-chat="overlay">${cs.overlay ? 'Overlay schließen' : 'Als Overlay über Spielen'}</button></div>
          <small class="muted">TikTok: dein Live muss laufen – der Chat wird von deiner öffentlichen Live-Seite gelesen. Twitch: einfach den Kanalnamen eingeben. Kein Passwort nötig.</small>` : lock('streamchat', 'Das Stream-Chat-Widget')}</div>
    </section>`;
  }

  function tabWidgets() {
    const w = widgets();
    const dw = settings().desktopWidgets || {};
    const desktopOn = dw.enabled !== false;
    const bg = backdrop() ? ` style="background-image:url('${fileUrl(backdrop())}')"` : '';
    const defs = [
      ['sysLive', 'System Live', 'CPU, RAM, GPU und Laufwerk live auf der Startseite.'],
      ['upcoming', 'Nächste Termine', 'Die nächsten Einträge aus der Agenda direkt auf der Startseite.'],
      ['screentime', 'Bildschirmzeit', 'Uhr-Symbol in der oberen Leiste mit Popup und App-Zeiten.'],
      ['speed', 'WLAN & Speedtest', 'WLAN-Symbol in der Leiste, das den Speedtest öffnet.'],
    ];
    return `<section class="desk-pane desk-desktop-pane">
      <div class="desk-control-row"><div class="grow"><b>Widgets auf dem Windows-Desktop</b><small>Uhr, System, Bildschirmzeit und Termine schweben rechts auf deinem Desktop – sie liegen hinter normalen Fenstern und stören nicht.</small></div><button class="switch ${desktopOn ? 'on' : ''}" data-desk-desktop-widgets aria-label="Widgets auf dem Desktop"></button></div>
      ${desktopOn ? `<div class="desk-dw-list">${[['clock', 'Punktmatrix-Uhr', true], ['face', 'Gesicht', true], ['music', 'Läuft gerade', true], ['system', 'System', true], ['calendar', 'Kalender', true], ['screentime', 'Bildschirmzeit', false], ['upcoming', 'Termine', false], ['eq', 'Sound-Visualizer', true], ['mixer', 'Mixer', false], ['weather', 'Punkt-Wetter', true], ['football', 'Fußball', false], ['clicker', 'Autoclicker', false], ['cards', 'Mit Hintergrund', false], ['vinyl', 'Plattenspieler', true]].map(([k, n, def]) => { const on = dw[k] === undefined ? def : dw[k] !== false; return `<button class="desk-dw-chip ${on ? 'on' : ''}" data-desk-dw="${k}" data-on="${on ? 1 : 0}">${esc(n)}</button>`; }).join('')}<small>Widgets frei mit der Maus verschieben – auch auf andere Monitore.</small></div>` : ''}
      <div class="desk-desktop-pv ${desktopOn ? 'on' : ''}">
        <div class="desk-desktop-pv-bg"${bg}></div>
        <div class="desk-desktop-pv-tint"></div>
        <span class="desk-desktop-pv-label">Dein Desktop</span>
        <div class="desk-desktop-pv-stack">
          <div class="dpv-card dpv-clock"><small>Revulution</small><b data-desk-clock>${fmtTime()}</b><span>${esc(fmtDay())}</span></div>
          <div class="dpv-card"><div class="dpv-head">System <em>live</em></div><div class="dpv-row"><span>CPU</span><i><b style="width:23%"></b></i><strong>23 %</strong></div><div class="dpv-row"><span>RAM</span><i><b style="width:61%"></b></i><strong>61 %</strong></div></div>
          <div class="dpv-card"><div class="dpv-head">Bildschirmzeit</div><b class="dpv-total">2 Std. 14</b><div class="dpv-row"><span>Explorer</span><i><b style="width:78%"></b></i></div></div>
        </div>
        <span class="desk-desktop-pv-state">${desktopOn ? 'aktiv' : 'aus'}</span>
      </div>
    </section>
    ${desktopOn ? premiumHtml(dw) : ''}
    <div class="desk-widget-grid">${defs
      .map(([key, name, desc]) => `<article class="desk-wcard ${w[key] ? 'on' : ''}"><div class="desk-wpv-wrap">${widgetPreview(key)}</div><div class="desk-wmeta"><div><b>${esc(name)}</b><small>${esc(desc)}</small></div><button class="switch ${w[key] ? 'on' : ''}" data-desk-widget="${key}" aria-label="${esc(name)}"></button></div></article>`)
      .join('')}</div>
      <div class="desk-widget-note">${icon('spark', 15)} Widgets erscheinen auf der Startseite und in der oberen Leiste. Änderungen sind sofort aktiv.</div>`;
  }


  /* 2.37: Widget-Galerie – jedes Desktop-Widget mit kleiner Live-Vorschau und eigenem Schalter */
  const DW = [
    ['clock', 'Punktmatrix-Uhr', 'Große Uhrzeit aus Punkten', true],
    ['weather', 'Punkt-Wetter', 'Sonne, Wolken, Regen als Punktkreis', true],
    ['face', 'Gesicht', 'Ein Punktgesicht, das blinzelt und schaut', true],
    ['music', 'Läuft gerade', 'Song mit Cover und Steuerung', true],
    ['vinyl', 'Plattenspieler', 'Dreht sich mit deiner Musik', true],
    ['eq', 'Sound-Visualizer', 'Hört mit, was dein PC abspielt', true],
    ['calendar', 'Kalender', 'Der Monat auf einen Blick', true],
    ['system', 'System', 'CPU, RAM und GPU live', true],
    ['perf', 'Leistung', 'CPU, GPU, RAM und Ping als Ringe – aus dem Gaming Hub', false],
    ['football', 'Fußball', 'Live-Stand deiner Teams', false],
    ['clicker', 'Autoclicker', 'Zähler mit Start/Stopp', false],
    ['screentime', 'Bildschirmzeit', 'Heute und die meistgenutzten Apps', false],
    ['upcoming', 'Termine', 'Die nächsten Einträge', false],
    ['mixer', 'Mixer', 'Lautstärke pro App', false],
    ['plant', 'Pixel-Pflanze', 'Gieß sie – sie wächst und blüht', false],
    ['notes', 'Notizen', 'Schnell was aufschreiben', false],
    ['todo', 'To-do', 'Aufgaben zum Abhaken', false],
    ['calc', 'Rechner', 'Taschenrechner, auch mit Tastatur', false],
    ['uptime', 'PC-Laufzeit', 'Wie lange dein PC schon läuft', false],
    ['mic', 'Mikrofon', 'Pegel live – und dich selbst hören', false],
    ['cam', 'Live-Kamera', 'Deine Webcam als kleines Fenster', false],
    ['sound', 'Soundboard', '8 Sounds auf Knopfdruck', false],
    ['quick', 'Schnellzugriff', 'Dateien ablegen und mit einem Klick öffnen', false],
    ['trading', 'Märkte', 'Aktien und Krypto live mit Mini-Chart', false],
    ['streamchat', 'Stream-Chat', 'Dein TikTok- oder Twitch-Chat auf dem Desktop', false],
  ];
  const PREMIUM_W = ['sound', 'quick', 'trading', 'streamchat'];
  const dots = (n, on, red = -1) => Array.from({ length: n }, (_, i) => `<i class="${i < on ? 'on' : ''} ${i === red ? 'r' : ''}"></i>`).join('');
  function dwMini(id) {
    switch (id) {
      case 'clock': return `<div class="mini-clock">${fmtTime()}</div>`;
      case 'weather': return '<div class="mini-sun"><i></i></div><b class="mini-big">21°</b>';
      case 'face': return '<div class="mini-face"><i></i><i></i><u></u></div>';
      case 'music': return '<div class="mini-music"><span></span><div><b>Song</b><small>Artist</small></div></div>';
      case 'vinyl': return '<div class="mini-vinyl"><i></i></div>';
      case 'eq': return `<div class="mini-eq">${Array.from({ length: 12 }, (_, i) => `<i style="--h:${20 + ((i * 37) % 70)}%;--d:${i * 60}ms"></i>`).join('')}</div>`;
      case 'calendar': return `<div class="mini-cal">${Array.from({ length: 28 }, (_, i) => `<i class="${i === new Date().getDate() % 28 ? 'today' : ''}"></i>`).join('')}</div>`;
      case 'system': return `<div class="mini-sys"><span>CPU</span><em>${dots(12, 4, 3)}</em><span>RAM</span><em>${dots(12, 8, 7)}</em><span>GPU</span><em>${dots(12, 2, 1)}</em></div>`;
      case 'football': return '<div class="mini-foot"><b>SUI</b><strong>2 : 1</strong><b>GER</b><small>● 67\'</small></div>';
      case 'clicker': return '<div class="mini-click"><b>1 284</b><small>Klicks</small></div>';
      case 'screentime': return '<b class="mini-big">2h 14</b><small class="mini-sub">Heute</small>';
      case 'upcoming': return '<div class="mini-up"><i></i><span>Training · 18:00</span></div>';
      case 'perf': return '<div class="mini-perf"><i style="--v:42"></i><i style="--v:18"></i><i style="--v:63"></i></div>';
      case 'plant': return '<div class="mini-plant"><i></i><i></i><i></i><u></u></div>';
      case 'notes': return '<div class="mini-notes"><i style="--w:80%"></i><i style="--w:60%"></i><i style="--w:70%"></i></div>';
      case 'todo': return '<div class="mini-todo"><span class="d">✓</span><i></i><span></span><i></i></div>';
      case 'calc': return `<div class="mini-calc">${Array.from({ length: 12 }, (_, i) => `<i class="${i % 4 === 3 ? 'op' : ''}"></i>`).join('')}</div>`;
      case 'uptime': return '<b class="mini-big">3<small>T</small> 4<small>h</small></b><small class="mini-sub">PC läuft seit</small>';
      case 'mic': return `<div class="mini-mic">${Array.from({ length: 10 }, (_, i) => `<i class="${i < 6 ? (i > 4 ? 'y' : 'g') : ''}"></i>`).join('')}</div>`;
      case 'cam': return '<div class="mini-cam"><i></i></div>';
      case 'sound': return '<div class="mini-pads"><i>🥁</i><i>👏</i><i>📯</i><i>✨</i></div>';
      case 'quick': return '<div class="mini-quick"><i>📁</i><i>📄</i><i>🖼️</i></div>';
      case 'trading': return '<div class="mini-trade"><b>AAPL</b><svg viewBox="0 0 60 20"><polyline points="0,15 10,12 20,14 30,8 40,10 50,4 60,6" fill="none" stroke="#30d158" stroke-width="2"/></svg><em>+1.8 %</em></div>';
      case 'streamchat': return '<div class="mini-chat"><p><b style="color:#62c9ff">luca</b> GG</p><p><b style="color:#ff7ad1">mia</b> Song?</p><p><b style="color:#5ee08a">nico</b> 🎁</p></div>';
      case 'mixer': return '<div class="mini-mix"><i style="--w:70%"></i><i style="--w:40%"></i><i style="--w:85%"></i></div>';
      default: return '';
    }
  }
  function widgetGallery(dw) {
    const desktopOn = dw.enabled !== false;
    return `<section class="desk-pane dwg">
      <div class="dwg-head"><div><b>Widgets auf deinem Desktop</b><small>Tippe ein Widget an, um es ein- oder auszuschalten. Auf dem Desktop: frei verschieben, Strg + Rechtsklick für das Menü, Strg + Scrollen für die Größe.</small></div>
        <button class="switch ${desktopOn ? 'on' : ''}" data-desk-desktop-widgets title="Alle Desktop-Widgets ein/aus"></button></div>
      <div class="dwg-grid ${desktopOn ? '' : 'off'}">${DW.map(([k, n, d, def], i) => {
        const on = dw[k] === undefined ? def : dw[k] !== false;
        // 2.39: Soundboard und Schnellzugriff sind Premium (Revolution Store)
        if (PREMIUM_W.includes(k) && !window.RevStore?.owns('widget', k)) return `<button class="dwg-card locked" style="--d:${i * 30}ms" data-desk-store><div class="dwg-prev">${dwMini(k)}</div><div class="dwg-meta"><b>${esc(n)} <em class="dwg-prem">PREMIUM</em></b><small>${esc(d)}</small></div><span class="dwg-check">🔒</span></button>`;
        return `<button class="dwg-card ${on ? 'on' : ''}" style="--d:${i * 30}ms" data-desk-dw="${k}" data-on="${on ? 1 : 0}"><div class="dwg-prev">${dwMini(k)}</div><div class="dwg-meta"><b>${esc(n)}${PREMIUM_W.includes(k) ? ' <em class="dwg-prem">PREMIUM</em>' : ''}</b><small>${esc(d)}</small></div><span class="dwg-check">${on ? '✓' : '+'}</span></button>`;
      }).join('')}</div>
    </section>`;
  }
  function tabTaskbar2() {
    const on = Boolean(settings().translucentTaskbar);
    return `<section class="desk-pane dwg">
      <div class="dwg-head"><div><b>Durchsichtige Windows-Taskleiste</b><small>Macht die normale Windows-Taskleiste klar wie Glas – mit TranslucentTB, das der Hub für dich startet und beendet. Ist es nicht installiert, öffnet sich der Microsoft Store.</small></div>
        <button class="switch ${on ? 'on' : ''}" data-desk-translucent></button></div>
      <div class="tb-preview ${on ? 'on' : ''}"><div class="tb-preview-bar">${['#62c9ff', '#ff7ad1', '#5ee08a', '#ffd166', '#a78bfa'].map((c) => `<i style="background:${c}"></i>`).join('')}</div></div>
    </section>`;
  }

  function desktopHtml() {
    // 2.37: nur noch Widgets und Taskleiste – Hintergründe gibt es in der Hintergründe-App
    const tabs = [['widgets', 'Widgets', 'spark'], ['taskbar', 'Taskleiste', 'layers']];
    if (!['widgets', 'taskbar'].includes(deskTab)) deskTab = 'widgets';
    const dw = settings().desktopWidgets || {};
    const body = deskTab === 'taskbar' ? tabTaskbar2() : `${widgetGallery(dw)}${dw.enabled !== false ? premiumHtml(dw) : ''}`;
    return `<div class="desk-page">
      <div class="desk-head">
        <span class="desk-hint">Widgets und Taskleiste – alles mit Vorschau.</span>
        <nav class="desk-tabs">${tabs.map(([id, name, ic]) => `<button class="${deskTab === id ? 'on' : ''}" data-desk-tab="${id}">${icon(ic, 14)}<span>${name}</span></button>`).join('')}</nav>
      </div>
      ${body}
    </div>`;
  }

  function paintStage() {
    const stage = document.querySelector('.desk-stage');
    if (!stage) return;
    stage.classList.toggle('is-blur', blurOn());
    stage.style.setProperty('--blur', `${blurAmount()}px`);
    stage.style.setProperty('--dim', String(blurOn() ? dimAmount() : 0.16));
    const tag = stage.querySelector('.desk-stage-tag');
    if (tag) tag.textContent = blurOn() ? 'Blur an' : 'Klarer Desktop';
  }

  document.addEventListener('click', (e) => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    const tab = e.target.closest?.('[data-desk-tab]');
    if (tab) {
      deskTab = tab.dataset.deskTab;
      return ctx().render();
    }
    const open = e.target.closest?.('[data-desk-open]');
    if (open) return window.hub.open(open.dataset.deskOpen).catch(() => {});
    if (e.target.closest?.('[data-desk-action="lock"]')) return window.hub.cc.lock().catch(() => {});
    if (e.target.closest?.('[data-desk-taskbar-start]')) return window.hub.taskbar.start().catch(() => {});

    const choice = e.target.closest?.('[data-desk-taskbar-choice]');
    if (choice) {
      const on = choice.dataset.deskTaskbarChoice === 'on';
      return window.hub.taskbar.replace(on).then(() => ctx().render()).catch(() => {});
    }

    if (e.target.closest?.('[data-desk-taskbar]')) {
      const on = !settings().replaceTaskbar;
      return window.hub.taskbar.replace(on).then(() => {
        ctx().toast(on ? 'Revulution-Leiste übernimmt.' : 'Windows-Taskleiste ist wieder da.');
        ctx().render();
      }).catch(() => {});
    }

    const toggle = e.target.closest?.('[data-desk-toggle]');
    if (toggle) {
      const key = toggle.dataset.deskToggle;
      const next = key === 'backdropBlur' ? !blurOn() : true;
      return ctx().settings({ [key]: next }).then(() => paintStage());
    }

    if (e.target.closest?.('[data-desk-store]')) {
      window.RevStore?.open?.('widgets');
      return window.hub.open('tool-store');
    }
    const acc = e.target.closest?.('[data-desk-acc]')?.dataset.deskAcc;
    if (acc) return ctx().settings({ widgetAccent: acc }).then(() => ctx().render());
    const prem = e.target.closest?.('[data-desk-prem]')?.dataset.deskPrem;
    if (prem) return ctx().settings({ desktopWidgets: { [prem]: !settings().desktopWidgets?.[prem] } }).then(() => ctx().render());
    const plat = e.target.closest?.('[data-desk-plat]')?.dataset.deskPlat;
    if (plat) {
      chat.platform = plat;
      return ctx().render();
    }
    const ca = e.target.closest?.('[data-desk-chat]')?.dataset.deskChat;
    if (ca) {
      const err = (x) => ctx().toast(String(x?.message || x).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
      if (ca === 'start') {
        chat.channel = document.querySelector('[data-desk-chan]')?.value || chat.channel;
        return window.hub.streamChat.start({ platform: chat.platform, channel: chat.channel }).then(() => ctx().settings({ desktopWidgets: { streamchat: true } })).then(() => ctx().render()).catch(err);
      }
      if (ca === 'stop') return window.hub.streamChat.stop().then(() => ctx().render()).catch(err);
      if (ca === 'overlay') return window.hub.streamChat.overlay({}).then(() => ctx().render()).catch(err);
    }
    if (e.target.closest?.('[data-desk-translucent]')) {
      const on = !settings().translucentTaskbar;
      return window.hub.translucentTaskbar(on).then((r) => {
        ctx().toast(r === 'store' ? 'TranslucentTB ist nicht installiert – der Microsoft Store ist offen.' : on ? 'Taskleiste ist jetzt durchsichtig.' : 'Taskleiste wieder normal.');
        ctx().render();
      }).catch(() => {});
    }
    const dwChip = e.target.closest?.('[data-desk-dw]');
    if (dwChip) return ctx().settings({ desktopWidgets: { [dwChip.dataset.deskDw]: dwChip.dataset.on !== '1' } }).then(() => ctx().render());
    if (e.target.closest?.('[data-desk-desktop-widgets]')) {
      const on = settings().desktopWidgets?.enabled === false;
      return window.hub.desktopWidgets.set(on).then(() => {
        ctx().toast(on ? 'Widgets sind jetzt auf deinem Desktop.' : 'Desktop-Widgets sind aus.');
        ctx().render();
      }).catch(() => {});
    }

    const widget = e.target.closest?.('[data-desk-widget]');
    if (widget) {
      const key = widget.dataset.deskWidget;
      const next = !widgets()[key];
      const patch = { widgets: { [key]: next } };
      if (key === 'screentime' || key === 'speed') {
        const current = settings().topbarItems || [];
        patch.topbarItems = next ? [...new Set([...current, key])] : current.filter((x) => x !== key);
      }
      return ctx().settings(patch).then(() => ctx().render());
    }

    const bg = e.target.closest?.('[data-desk-bg]');
    if (bg) {
      const id = bg.dataset.deskBg;
      bg.classList.add('busy');
      return window.pickWallpaperTarget().then((target) => target && window.hub.community.builtinDesktop(id, target)).then((done) => {
        if (!done) return bg.classList.remove('busy');
        deskBg = id;
        ctx().toast(`${WALL_NAMES[id] || 'Hintergrund'} ist jetzt dein Windows-Hintergrund.`);
        setTimeout(() => window.__hubRefreshBackdrop?.(), 1400);
        ctx().render();
      }).catch((error) => {
        bg.classList.remove('busy');
        ctx().toast(String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
      });
    }
  });

  document.addEventListener('change', (e) => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    if (e.target.matches?.('[data-desk-syms]')) ctx().settings({ tradingSymbols: e.target.value.split(/[,\s]+/).filter(Boolean) }).then(() => ctx().toast('Symbole gespeichert.'));
    if (e.target.matches?.('[data-desk-acc-input]')) ctx().settings({ widgetAccent: e.target.value }).then(() => ctx().render());
    if (e.target.matches?.('[data-desk-chan]')) chat.channel = e.target.value;
  });
  let saveTimer = null;
  document.addEventListener('input', (e) => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    const el = e.target.closest?.('[data-desk-range]');
    if (!el) return;
    const key = el.dataset.deskRange;
    const value = Number(el.value);
    const out = el.parentElement.querySelector('output');
    if (out) out.textContent = key === 'backdropDim' ? `${Math.round(value * 100)} %` : `${value} px`;
    const stage = document.querySelector('.desk-stage');
    if (stage) stage.style.setProperty(key === 'backdropDim' ? '--dim' : '--blur', key === 'backdropDim' ? String(value) : `${value}px`);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => ctx().settings({ [key]: value }), 220);
  });

  setInterval(() => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    paintClock();
  }, 1000);
  setInterval(() => {
    if (ctx().state()?.active === 'tool-desktop') loadSystem();
  }, 6000);

  T.register(
    'tool-desktop',
    {
      nav: 'Desktop',
      title: 'Desktop',
      sub: 'Widgets und Taskleiste',
      icon: 'home',
      tint: 'linear-gradient(135deg,#e5e7eb,#6b7280)',
      desc: 'Desktop-Widgets ein- und ausschalten und die Windows-Taskleiste durchsichtig machen.',
    },
    desktopHtml,
  );

  // Beim ersten Öffnen die Livewerte holen und die Uhr direkt stellen.
  const base = T.html;
  T.html = (id) => {
    const html = base(id);
    if (id === 'tool-desktop') setTimeout(() => { paintClock(); paintStage(); if (pc.live) paintSystem(); loadSystem(); }, 0);
    return html;
  };
})();
