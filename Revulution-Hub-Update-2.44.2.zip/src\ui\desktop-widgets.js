'use strict';

/* Widgets auf dem Windows-Desktop: ein durchsichtiges Fenster pro Monitor.
   Klicks gehen überall durch – nur über einem Widget nimmt das Fenster die Maus,
   damit man es frei ziehen (auch auf einen anderen Monitor) und bedienen kann. */
(function () {
  /* 2.36 Leistung: sind die Widgets verdeckt (Fenster darüber, Spiel im Vollbild) oder der
     Bildschirm aus, meldet Chromium „hidden“ – dann laufen keine Zeitgeber und keine Aufnahme. */
  const realInterval = window.setInterval.bind(window);
  let pausedFs = false;
  window.setInterval = (fn, ms, ...args) => realInterval(() => { if (!document.hidden && !pausedFs) fn(...args); }, ms);
  window.hub?.onWidgetsPause?.((on) => {
    pausedFs = Boolean(on);
    try { if (pausedFs) eqStop(); else apply(); } catch { /* noch nicht bereit */ }
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      try { eqStop(); } catch { /* noch nicht bereit */ }
    } else {
      try { apply(); } catch { /* noch nicht bereit */ }
    }
  });
  const stage = document.getElementById('stack');
  const query = new URLSearchParams(location.search);
  const MY_DISPLAY = Number(query.get('display'));
  const IS_PRIMARY = query.get('primary') === '1';
  let state = null;
  let pc = {};
  let screen = null;
  let media = null;
  let interactive = false;

  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const pct = (v) => (v == null || Number.isNaN(Number(v)) ? '–' : `${Math.round(Number(v))} %`);
  const clamp = (v) => Math.max(0, Math.min(100, Number(v) || 0));
  const mmss = (s) => `${Math.floor((Number(s) || 0) / 60)}:${String(Math.floor((Number(s) || 0) % 60)).padStart(2, '0')}`;

  const timeText = () => new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const dayHtml = () => {
    const d = new Date();
    const wd = d.toLocaleDateString('de-DE', { weekday: 'short' }).replace('.', '').toUpperCase();
    return `<b>${esc(wd)}</b> · ${String(d.getDate()).padStart(2, '0')} ${esc(d.toLocaleDateString('de-DE', { month: 'short' }).replace('.', '').toUpperCase())}`;
  };
  const fmtDuration = (seconds) => {
    const s = Math.max(0, Math.round(Number(seconds) || 0));
    const h = Math.floor(s / 3600);
    const m = Math.round((s % 3600) / 60);
    return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m`;
  };
  /** Punkte-Balken: der letzte gefüllte Punkt ist rot. */
  function dots(value, n = 20) {
    const k = Math.round((clamp(value) / 100) * n);
    let html = '<div class="dw-dots">';
    for (let i = 0; i < n; i++) html += `<i class="${i < k - 1 ? 'on' : i === k - 1 ? 'tip' : ''}"></i>`;
    return `${html}</div>`;
  }

  const ICON = {
    prev: '<svg viewBox="0 0 24 24"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M16 5h2v14h-2zM4 5v14l11-7z"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4v16l13-8z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
  };

  /* Tonarm wie im Musik-Overlay: Drehpunkt oben rechts, wandert mit dem Song nach innen. */
  const ARM_SVG = `<svg class="dw-arm" viewBox="0 0 100 100" aria-hidden="true">
    <defs>
      <linearGradient id="dwArmMetal" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4f6fa"/><stop offset="0.55" stop-color="#b9c0cc"/><stop offset="1" stop-color="#7d8594"/></linearGradient>
      <radialGradient id="dwArmBase" cx="0.4" cy="0.35" r="0.7"><stop offset="0" stop-color="#5c6370"/><stop offset="1" stop-color="#1b1e25"/></radialGradient>
    </defs>
    <g class="dw-arm-rot">
      <g transform="translate(92 8)">
        <rect x="-15" y="-3.2" width="8" height="6.4" rx="1.6" fill="#2a2e37" stroke="#7d8594" stroke-width="0.6"/>
        <rect x="-7" y="-1.3" width="60" height="2.6" rx="1.3" fill="url(#dwArmMetal)" stroke="rgba(0,0,0,0.35)" stroke-width="0.3"/>
        <g transform="translate(55 0) rotate(22)">
          <rect x="-4" y="-2.6" width="11" height="5.2" rx="1.2" fill="#d9dde5" stroke="#5c6370" stroke-width="0.5"/>
          <rect x="4.6" y="1.2" width="1.6" height="2.6" rx="0.4" fill="#ff2d2d"/>
        </g>
      </g>
      <circle cx="92" cy="8" r="6.5" fill="url(#dwArmBase)" stroke="rgba(255,255,255,0.25)" stroke-width="0.6"/>
      <circle cx="92" cy="8" r="2.2" fill="#c9ced8"/>
    </g>
  </svg>`;
  const ARM_REST = 82;
  const ARM_START = 90.5;
  const ARM_END = 108.4;

  /* Standardplätze auf dem Hauptmonitor (rechts oben) – danach zählt, wo du sie hinziehst. */
  const W = window.innerWidth;
  const DEFAULTS = {
    clock: { x: W - 330, y: 76 },
    face: { x: W - 560, y: 76 },
    music: { x: W - 360, y: 236 },
    system: { x: W - 300, y: 420 },
    calendar: { x: W - 560, y: 296 },
    screen: { x: W - 300, y: 540 },
    upcoming: { x: W - 300, y: 690 },
    eq: { x: W - 640, y: 560 },
    mixer: { x: 40, y: 560 },
    trading: { x: 40, y: 90 },
    streamchat: { x: 40, y: 330 },
    weather: { x: W - 640, y: 76 },
    football: { x: 40, y: 560 },
    clicker: { x: 360, y: 560 },
    uptime: { x: 40, y: 90 },
    notes: { x: 300, y: 90 },
    todo: { x: 300, y: 330 },
    calc: { x: 580, y: 90 },
    plant: { x: 580, y: 420 },
    perf: { x: 40, y: 420 },
    mic: { x: 40, y: 250 },
    cam: { x: 820, y: 90 },
    sound: { x: 40, y: 400 },
    quick: { x: 820, y: 360 },
  };
  // Einstellung ↔ Karte (zum Ausblenden per Menü)
  const SETTING_OF = { screen: 'screentime' };
  const accent = () => getComputedStyle(document.documentElement).getPropertyValue('--red').trim() || '#ff2d2d';

  stage.innerHTML = `
    <section class="dw dw-clock" data-w="clock"><time id="dw-time">${timeText()}</time><div class="dw-day" id="dw-day">${dayHtml()}</div></section>
    <section class="dw dw-face" data-w="face"><canvas id="dw-face" width="340" height="340"></canvas></section>
    <section class="dw dw-music" data-w="music"><div class="dw-label">Läuft gerade</div><div id="dw-music-body"></div></section>
    <section class="dw dw-system" data-w="system"><div class="dw-label">System</div><div id="dw-sys-body"></div></section>
    <section class="dw dw-cal" data-w="calendar"><div id="dw-cal-body"></div></section>
    <section class="dw dw-screen" data-w="screen"><div class="dw-label">Bildschirmzeit</div><div id="dw-screen-body"></div></section>
    <section class="dw dw-up" data-w="upcoming"><div class="dw-label">Termine</div><div id="dw-up-body"></div></section>
    <section class="dw dw-eq-w" data-w="eq"><div class="dw-label">Sound <em id="dw-eq-state">…</em></div><canvas id="dw-eq" width="560" height="200"></canvas><div class="dw-eq-foot"><span>BASS</span><i id="dw-eq-bass"><b></b></i><span>30 Hz – 16 kHz</span></div></section>
    <section class="dw dw-mix" data-w="mixer"><div class="dw-label">Mixer</div><div id="dw-mix-body"><div class="dw-empty">…</div></div></section>
    <section class="dw dw-wx" data-w="weather"><canvas id="dw-wx" width="340" height="340"></canvas><div class="dw-wx-info"><b id="dw-wx-temp">–°</b><span id="dw-wx-foot"></span><em id="dw-wx-city"></em></div></section>
    <section class="dw dw-foot" data-w="football"><div class="dw-label">Fußball <em id="dw-foot-state"></em></div><div id="dw-foot-body"><div class="dw-empty">Im Hub unter Fußball Teams folgen.</div></div></section>
    <section class="dw dw-click" data-w="clicker"><div class="dw-label">Autoclicker <em id="dw-click-state"></em></div><div class="dw-click-body"><b id="dw-click-n">0</b><small>Klicks</small><button id="dw-click-btn">Start</button></div></section>
    <section class="dw dw-trade" data-w="trading"><div class="dw-label">Märkte <em id="dw-trade-state"></em></div><div id="dw-trade-body"><div class="dw-empty">Kurse werden geladen …</div></div></section>
    <section class="dw dw-chat" data-w="streamchat"><div class="dw-label">Stream-Chat <em id="dw-chat-state"></em></div><div id="dw-chat-body"><div class="dw-empty">Im Hub unter Desktop einen Kanal verbinden.</div></div></section>
    <section class="dw dw-x dw-uptime" data-w="uptime"><div class="dw-label">PC läuft seit</div><b id="dw-up-big">–</b><small id="dw-up-since"></small></section>
    <section class="dw dw-x dw-notes" data-w="notes"><div class="dw-label">Notizen</div><textarea id="dw-notes-t" data-nodrag spellcheck="false" placeholder="Schreib was auf …"></textarea></section>
    <section class="dw dw-x dw-todo" data-w="todo"><div class="dw-label">To-do <em id="dw-todo-n"></em></div><div id="dw-todo-list"></div><input id="dw-todo-in" data-nodrag placeholder="+ Neue Aufgabe" /></section>
    <section class="dw dw-x dw-calc" data-w="calc"><div class="dw-calc-d" id="dw-calc-d">0</div><div class="dw-calc-k" id="dw-calc-k"></div></section>
    <section class="dw dw-x dw-plant" data-w="plant"><canvas class="dw-cloud" id="dw-cloud" width="180" height="72" data-nodrag></canvas><canvas id="dw-plant-c" width="300" height="360"></canvas><div class="dw-plant-f"><svg class="dw-ring" id="dw-ring" viewBox="0 0 20 20"><circle class="t" cx="10" cy="10" r="8" pathLength="100"/><circle class="p" id="dw-ring-p" cx="10" cy="10" r="8" pathLength="100"/></svg><span id="dw-plant-s"></span></div></section>
    <section class="dw dw-x dw-perf" data-w="perf"><div class="dw-label">Leistung</div><div id="dw-perf-body"></div></section>
    <section class="dw dw-x dw-mic" data-w="mic"><div class="dw-label">Mikrofon <em id="dw-mic-db"></em></div><small class="dw-dev" id="dw-mic-dev"></small><div class="dw-mic-bar" id="dw-mic-bar"></div><div class="dw-row"><button id="dw-mic-on">Start</button><button id="dw-mic-hear" title="Dich selbst hören (Kopfhörer!)">Mithören</button></div></section>
    <section class="dw dw-x dw-cam" data-w="cam"><video id="dw-cam-v" muted playsinline></video><div class="dw-cam-off" id="dw-cam-off">Kamera aus</div><button id="dw-cam-btn">Kamera an</button></section>
    <section class="dw dw-x dw-sound" data-w="sound"><div class="dw-label">Soundboard</div><div class="dw-pads" id="dw-pads"></div></section>
    <section class="dw dw-x dw-quick" data-w="quick"><div class="dw-label">Schnellzugriff <button id="dw-quick-add" title="Datei hinzufügen">+</button></div><div id="dw-quick-list"><div class="dw-empty">Dateien hierher ziehen</div></div></section>`;

  const cards = Object.fromEntries([...stage.querySelectorAll('[data-w]')].map((el) => [el.dataset.w, el]));
  const visible = (id) => cards[id] && !cards[id].hidden && !cards[id].classList.contains('away');

  /** Gehört das Widget auf diesen Monitor? Alte Positionen (ohne Monitor) = Hauptmonitor. */
  function slot(id) {
    const p = state?.settings?.widgetPos?.[id];
    if (!p) return IS_PRIMARY ? { ...DEFAULTS[id] } : null;
    if (p.d == null) return IS_PRIMARY ? { x: p.x, y: p.y + 36 } : null; // früher lag das Fenster 36 px tiefer
    // Monitor gerade nicht angeschlossen: vorübergehend hier, ohne die gespeicherte Stelle zu ändern
    if (p.tmp != null) return Number(p.tmp) === MY_DISPLAY ? { x: Math.min(p.x, window.innerWidth - 120), y: Math.min(p.y, window.innerHeight - 80) } : null;
    return Number(p.d) === MY_DISPLAY ? { x: p.x, y: p.y } : null;
  }

  function place() {
    for (const [id, el] of Object.entries(cards)) {
      if (drag?.el === el || el.classList.contains('ghost')) continue;
      const p = slot(id);
      el.classList.toggle('away', !p);
      if (!p) continue;
      el.style.left = `${Math.max(0, Math.min(window.innerWidth - 60, p.x))}px`;
      el.style.top = `${Math.max(0, Math.min(window.innerHeight - 40, p.y))}px`;
    }
  }

  /* ------------------------------------------------------------ Ziehen (auch über Monitore) */
  let drag = null;
  let dragSent = 0;
  stage.addEventListener('pointerdown', (e) => {
    const el = e.target.closest('.dw');
    // 2.37: rechte Maustaste zieht überall; linke nur dort, wo kein Regler/Knopf/Eingabefeld ist
    if (!el || (e.button !== 0 && e.button !== 2) || (e.button === 2 && e.ctrlKey)) return;
    if (e.button === 0 && e.target.closest('button, input, textarea, select, a, .dw-mix-row, [data-nodrag]')) return;
    const r = el.getBoundingClientRect();
    drag = { el, dx: e.clientX - r.left, dy: e.clientY - r.top, moved: false };
    el.setPointerCapture(e.pointerId);
    el.classList.add('dragging');
  });
  stage.addEventListener('pointermove', (e) => {
    if (!drag) return;
    drag.moved = true;
    const outside = e.clientX < 0 || e.clientY < 0 || e.clientX > window.innerWidth || e.clientY > window.innerHeight;
    // Draußen (auf einem anderen Monitor) zeigt das Fenster dort das Widget – hier ausblenden.
    drag.el.classList.toggle('leaving', outside);
    drag.el.style.left = `${e.clientX - drag.dx}px`;
    drag.el.style.top = `${e.clientY - drag.dy}px`;
    if (!dragSent) {
      dragSent = requestAnimationFrame(() => {
        dragSent = 0;
        if (drag) window.hub.widgetDrag?.(drag.el.dataset.w, drag.dx, drag.dy, 'move');
      });
    }
  });
  const endDrag = () => {
    if (!drag) return;
    const { el, moved, dx, dy } = drag;
    el.classList.remove('dragging', 'leaving');
    drag = null;
    if (moved) window.hub.widgetDrag?.(el.dataset.w, dx, dy, 'end');
  };
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);

  // Ein Widget, das gerade von einem anderen Monitor herübergezogen wird.
  window.hub.onWidgetGhost?.((g) => {
    const el = g && cards[g.id];
    if (!el || drag?.el === el) return;
    if (g.off) {
      if (el.classList.contains('ghost')) {
        el.classList.remove('ghost', 'dragging');
        place();
      }
      return;
    }
    if (el.hidden) return;
    el.classList.remove('away');
    el.classList.add('ghost', 'dragging');
    // 2.44: kommt kein „off“ mehr (Fenster gewechselt, Hub zu), verschwindet die Kopie von selbst –
    // vorher blieb ein halbes Widget auf dem anderen Monitor hängen und ließ sich doppelt ziehen.
    clearTimeout(el.__ghostT);
    el.__ghostT = setTimeout(() => {
      if (!el.classList.contains('ghost')) return;
      el.classList.remove('ghost', 'dragging');
      place();
    }, 900);
    el.style.left = `${g.x}px`;
    el.style.top = `${g.y}px`;
    if (g.id === 'face') drawFace();
  });

  // Nur über einem Widget nimmt das Fenster die Maus – sonst geht alles zum Desktop durch.
  document.addEventListener('mousemove', (e) => {
    // 2.44: auch über Rechtsklick-Fenstern und Menüs die Maus nehmen – sonst ging „Fertig“ ins Leere
    const over = Boolean(drag || document.elementFromPoint(e.clientX, e.clientY)?.closest('.dw, .dw-cfg, .dw-menu'));
    if (over !== interactive) {
      interactive = over;
      window.hub.widgetsInteractive?.(over);
    }
  });

  /* ------------------------------------------------------------ Inhalte */
  function paintClock() {
    const t = document.getElementById('dw-time');
    if (t && t.textContent !== timeText()) t.textContent = timeText();
    const d = document.getElementById('dw-day');
    if (d && d.innerHTML !== dayHtml()) d.innerHTML = dayHtml();
  }

  function paintSystem() {
    const body = document.getElementById('dw-sys-body');
    if (!body) return;
    body.innerHTML = [['CPU', pc.cpu], ['RAM', pc.ramPct], ['GPU', pc.gpu]].map(([n, v]) => `<div class="dw-row"><span>${n}</span>${dots(v)}<b>${pct(v)}</b></div>`).join('');
    paintPerf();
  }
  /* 2.44 Leistung (vorher im Gaming Hub): vier Ringe – CPU, GPU, RAM und Ping */
  let perfPing = null;
  let perfPingAt = 0;
  function paintPerf() {
    const body = document.getElementById('dw-perf-body');
    if (!body || cards.perf?.hidden) return;
    if (Date.now() - perfPingAt > 5000) {
      perfPingAt = Date.now();
      window.hub.widgetPing?.().then((ms) => (perfPing = ms)).catch(() => {});
    }
    const ring = (label, v, txt, warn) => {
      const p = Math.max(0, Math.min(100, Number(v) || 0));
      return `<div class="dw-pr ${warn ? 'warn' : ''}"><svg viewBox="0 0 40 40"><circle class="t" cx="20" cy="20" r="16" pathLength="100"/><circle class="p" cx="20" cy="20" r="16" pathLength="100" style="stroke-dashoffset:${100 - p}"/></svg><b>${txt}</b><span>${label}</span></div>`;
    };
    const ping = perfPing == null ? null : Math.round(perfPing);
    body.innerHTML = ring('CPU', pc.cpu, pct(pc.cpu), pc.cpu > 85)
      + ring('GPU', pc.gpu, pct(pc.gpu), pc.gpu > 90)
      + ring('RAM', pc.ramPct, pc.ramUsed ? `${String(pc.ramUsed).replace('.', ',')}<small>GB</small>` : pct(pc.ramPct), pc.ramPct > 88)
      + ring('PING', ping == null ? 0 : Math.min(100, ping / 2), ping == null ? '–' : `${ping}<small>ms</small>`, ping > 120);
  }

  function paintScreen() {
    const body = document.getElementById('dw-screen-body');
    if (!body) return;
    if (!screen) return (body.innerHTML = '<div class="dw-empty">…</div>');
    const apps = (screen.apps || []).slice(0, 3);
    body.innerHTML = `<div class="dw-big">${fmtDuration(screen.total)}</div><div style="height:10px"></div>${apps.map((a) => `<div class="dw-app"><span>${esc(a.name)}</span>${dots((a.secs / Math.max(1, screen.total)) * 100)}</div>`).join('')}`;
  }

  function paintUpcoming() {
    const body = document.getElementById('dw-up-body');
    if (!body) return;
    const list = (state?.upcoming || []).slice(0, 3);
    if (!list.length) return (body.innerHTML = '<div class="dw-empty">Keine Termine</div>');
    body.innerHTML = list
      .map((e) => {
        const d = new Date(e.start);
        const today = new Date();
        const tomorrow = new Date(Date.now() + 86400000);
        const day = d.toDateString() === today.toDateString() ? 'Heute' : d.toDateString() === tomorrow.toDateString() ? 'Morgen' : d.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
        const when = e.allDay ? `${day} · ganztägig` : `${day} · ${d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
        return `<div class="dw-event"><i></i><div><b>${esc(e.title)}</b><small>${esc(when)}</small></div></div>`;
      })
      .join('');
  }

  function paintCalendar() {
    const body = document.getElementById('dw-cal-body');
    if (!body) return;
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth();
    const key = `${y}-${m}-${now.getDate()}`;
    if (body.dataset.key === key) return;
    const first = (new Date(y, m, 1).getDay() + 6) % 7; // Montag zuerst
    const days = new Date(y, m + 1, 0).getDate();
    const prevDays = new Date(y, m, 0).getDate();
    let html = ['MO', 'DI', 'MI', 'DO', 'FR', 'SA', 'SO'].map((d) => `<span class="wd">${d}</span>`).join('');
    for (let i = 0; i < 42; i++) {
      const n = i - first + 1;
      if (n < 1) html += `<span class="d off">${prevDays + n}</span>`;
      else if (n > days) html += `<span class="d off">${n - days}</span>`;
      else html += `<span class="d ${n === now.getDate() ? 'today' : ''}">${n}</span>`;
      if (i >= 34 && n >= days) break;
    }
    body.dataset.key = key;
    body.innerHTML = `<div class="dw-cal-head"><span>${esc(now.toLocaleDateString('de-DE', { month: 'long' }))}</span><span>${y}</span></div><div class="dw-cal-grid">${html}</div>`;
  }

  /* ------------------------------------------------------------ Musik: Plattenspieler oder Cover */
  const vinylOn = () => state?.settings?.desktopWidgets?.vinyl !== false;
  let musicKey = '';
  function paintMusic() {
    const body = document.getElementById('dw-music-body');
    if (!body) return;
    const m = media;
    const vinyl = vinylOn();
    cards.music.classList.toggle('playing', Boolean(m?.playing));
    cards.music.classList.toggle('vinyl', vinyl);
    if (!m?.title) {
      musicKey = '';
      body.innerHTML = '<div class="dw-empty">Gerade läuft nichts</div>';
      return;
    }
    const art = m.art ? `background-image:url('data:image/jpeg;base64,${m.art}')` : '';
    // Grundgerüst nur neu bauen, wenn sich Song/Cover/Modus ändert – sonst läuft die Platte weich weiter.
    const key = `${vinyl}|${m.title}|${m.artist}|${m.art ? m.art.length : 0}`;
    if (key !== musicKey) {
      musicKey = key;
      const disc = vinyl
        ? `<div class="dw-deck"><div class="dw-vinyl"><div class="dw-label-art" style="${art}">${m.art ? '' : '♪'}</div><div class="dw-sheen"></div></div>${ARM_SVG}</div>`
        : `<div class="dw-cover" style="${art}">${m.art ? '' : '♪'}</div>`;
      body.innerHTML = `<div class="dw-mu-top">${disc}<div class="dw-mu-text"><b>${esc(m.title)}</b><span>${esc(m.artist || '')}</span>
        <div class="dw-mu-ctl"><button data-media="prev">${ICON.prev}</button><button class="main" data-media="playpause"></button><button data-media="next">${ICON.next}</button></div></div></div>
        <div class="dw-mu-prog"><span data-mu-pos></span><div data-mu-dots></div><span data-mu-dur></span></div>`;
    }
    const prog = m.duration > 0 ? (m.position / m.duration) * 100 : 0;
    body.querySelector('[data-mu-pos]').textContent = mmss(m.position);
    body.querySelector('[data-mu-dur]').textContent = mmss(m.duration);
    body.querySelector('[data-mu-dots]').innerHTML = dots(prog, 28);
    body.querySelector('.main').innerHTML = m.playing ? ICON.pause : ICON.play;
    const arm = body.querySelector('.dw-arm-rot');
    if (arm) {
      const angle = m.playing ? ARM_START + (ARM_END - ARM_START) * Math.min(1, Math.max(0, prog / 100)) : ARM_REST;
      arm.style.transform = `rotate(${angle.toFixed(2)}deg)`;
    }
  }
  stage.addEventListener('click', (e) => {
    const b = e.target.closest('[data-media]');
    if (!b) return;
    window.hub.cc?.media?.(b.dataset.media)?.catch?.(() => {});
    if (b.dataset.media === 'playpause' && media) {
      media.playing = !media.playing;
      paintMusic();
    }
  });


  /* ------------------------------------------------------------ Sound-Visualizer (Systemton live) */
  const EQ_COLS = 28;
  const EQ_ROWS = 10;
  const eq = { stream: null, ctx: null, an: null, data: null, raf: 0, peaks: new Array(EQ_COLS).fill(0), lvl: new Array(EQ_COLS).fill(0), bass: 0, tried: 0 };
  async function eqStart() {
    if (eq.stream || Date.now() - eq.tried < 5000) return;
    eq.tried = Date.now();
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
      s.getVideoTracks().forEach((t) => t.stop());
      if (!s.getAudioTracks().length) return;
      eq.stream = s;
      // 2.38: wechselt das Audiogerät (Kopfhörer, Schlaf), endet die Spur – dann neu verbinden statt stumm zu bleiben
      s.getAudioTracks().forEach((t) => t.addEventListener('ended', () => {
        eqStop();
        eq.tried = 0;
        setTimeout(() => { eqStart(); if (!eq.raf) eq.raf = requestAnimationFrame(eqFrame); }, 800);
      }));
      eq.silentSince = 0;
      eq.ctx = new AudioContext();
      eq.ctx.resume?.().catch(() => {});
      const src = eq.ctx.createMediaStreamSource(new MediaStream(s.getAudioTracks()));
      eq.an = eq.ctx.createAnalyser();
      eq.an.fftSize = 2048;
      eq.an.smoothingTimeConstant = 0.72;
      src.connect(eq.an);
      eq.data = new Uint8Array(eq.an.frequencyBinCount);
    } catch {
      /* ohne Systemton bleibt das Widget ruhig */
    }
  }
  function eqStop() {
    cancelAnimationFrame(eq.raf);
    eq.raf = 0;
    eq.stream?.getTracks().forEach((t) => t.stop());
    eq.ctx?.close().catch(() => {});
    eq.stream = eq.ctx = eq.an = null;
  }
  function eqFrame() {
    eq.raf = 0;
    // 2.37: läuft auch nur fürs Gesicht (singt im Takt), dann ohne Zeichnen der Balken
    if (!visible('eq') && !visible('face')) return eqStop();
    const cv = document.getElementById('dw-eq');
    const draw = Boolean(cv && visible('eq'));
    const g = (cv || document.createElement('canvas')).getContext('2d');
    const W2 = cv ? cv.width : 10;
    const H2 = cv ? cv.height : 10;
    if (draw) g.clearRect(0, 0, W2, H2);
    const bins = eq.data ? eq.data.length : 0;
    if (eq.an) eq.an.getByteFrequencyData(eq.data);
    // logarithmische Bänder: 30 Hz … 16 kHz
    const nyq = (eq.ctx?.sampleRate || 48000) / 2;
    for (let c = 0; c < EQ_COLS; c++) {
      let v = 0;
      if (bins) {
        const f0 = 30 * Math.pow(16000 / 30, c / EQ_COLS);
        const f1 = 30 * Math.pow(16000 / 30, (c + 1) / EQ_COLS);
        const i0 = Math.max(1, Math.floor((f0 / nyq) * bins));
        const i1 = Math.max(i0 + 1, Math.floor((f1 / nyq) * bins));
        let sum = 0;
        for (let i = i0; i < i1 && i < bins; i++) sum = Math.max(sum, eq.data[i]);
        v = sum / 255;
      }
      eq.lvl[c] += (v - eq.lvl[c]) * 0.5;
      eq.peaks[c] = Math.max(eq.lvl[c], eq.peaks[c] - 0.012);
    }
    eq.bass += ((eq.lvl[0] + eq.lvl[1] + eq.lvl[2] + eq.lvl[3]) / 4 - eq.bass) * 0.3;
    // Wachhund: Musik läuft laut Windows, aber 15 s lang kommt nichts an → Aufnahme neu starten
    if (eq.stream && media?.playing && eq.lvl.every((v) => v < 0.01)) {
      eq.silentSince ||= Date.now();
      if (Date.now() - eq.silentSince > 15000) {
        eqStop();
        eq.tried = 0;
        eqStart();
      }
    } else eq.silentSince = 0;
    if (eq.ctx?.state === 'suspended') eq.ctx.resume().catch(() => {});
    // Stimme/Mitten für den Mund des Gesichts
    const mids = eq.lvl.slice(Math.floor(EQ_COLS * 0.3), Math.floor(EQ_COLS * 0.7));
    eq.voice = (eq.voice || 0) + ((mids.reduce((a, b) => a + b, 0) / Math.max(1, mids.length)) - (eq.voice || 0)) * 0.45;
    if (!draw) {
      eq.raf = requestAnimationFrame(eqFrame);
      return;
    }
    const cw = W2 / EQ_COLS;
    const rh = H2 / EQ_ROWS;
    const r = Math.min(cw, rh) * 0.32;
    for (let c = 0; c < EQ_COLS; c++) {
      const on = Math.round(eq.lvl[c] * EQ_ROWS);
      const pk = Math.min(EQ_ROWS - 1, Math.round(eq.peaks[c] * EQ_ROWS));
      for (let row = 0; row < EQ_ROWS; row++) {
        const y = H2 - (row + 0.5) * rh;
        const x = (c + 0.5) * cw;
        g.beginPath();
        g.arc(x, y, r, 0, Math.PI * 2);
        g.fillStyle = row === pk && pk > 0 ? accent() : row < on ? '#ffffff' : 'rgba(255,255,255,0.12)';
        g.fill();
      }
    }
    const bassEl = document.getElementById('dw-eq-bass');
    if (bassEl) bassEl.style.setProperty('--b', eq.bass.toFixed(3));
    const lab = document.getElementById('dw-eq-state');
    if (lab) lab.textContent = eq.stream ? (media?.playing ? 'LIVE' : 'BEREIT') : 'KEIN TON';
    eq.raf = requestAnimationFrame(eqFrame);
  }
  function eqEnsure() {
    if (!visible('eq') && !visible('face')) return eqStop();
    eqStart();
    if (!eq.raf) eq.raf = requestAnimationFrame(eqFrame);
  }

  /* ------------------------------------------------------------ Mixer: Lautstärke pro App */
  let mixData = null;
  let mixBusy = false;
  async function loadMixer() {
    if (!visible('mixer') || mixBusy) return;
    mixBusy = true;
    try {
      mixData = await window.hub.mix?.list?.();
    } catch {
      mixData = null;
    }
    mixBusy = false;
    paintMixer();
  }
  function paintMixer() {
    const body = document.getElementById('dw-mix-body');
    if (!body || document.activeElement?.closest?.('#dw-mix-body')) return; // nicht unter dem Finger neu bauen
    const apps = (mixData?.apps || []).filter((a) => a && a.name).sort((x, y) => Number(y.active) - Number(x.active)).slice(0, 5);
    if (!apps.length) return (body.innerHTML = '<div class="dw-empty">Keine App spielt gerade Ton</div>');
    body.innerHTML = apps
      .map((a) => `<label class="dw-mix-row"><span>${esc(a.name)}</span><input type="range" min="0" max="100" value="${Math.round(Number(a.volume ?? 1) * 100)}" data-mix="${esc(a.pid)}" style="--v:${Math.round(Number(a.volume ?? 1) * 100)}%" /><b>${Math.round(Number(a.volume ?? 1) * 100)}</b></label>`)
      .join('');
  }
  stage.addEventListener('input', (e) => {
    const r = e.target.closest?.('[data-mix]');
    if (!r) return;
    r.style.setProperty('--v', `${r.value}%`);
    const b = r.parentElement.querySelector('b');
    if (b) b.textContent = r.value;
    window.hub.mix?.app?.(Number(r.dataset.mix), Number(r.value) / 100, null)?.catch?.(() => {});
  });
  stage.addEventListener('change', () => setTimeout(loadMixer, 400));
  setInterval(loadMixer, 5000);

  /* ------------------------------------------------------------ Punktmatrix-Gesicht */
  const face = { blinkAt: Date.now() + 2500, look: 0, lookTo: 0, lookAt: Date.now() + 1800 };
  function drawFace() {
    const cv = document.getElementById('dw-face');
    if (!cv || !visible('face')) return;
    const g = cv.getContext('2d');
    const N = 21;
    const S = cv.width / N;
    const now = Date.now();
    g.clearRect(0, 0, cv.width, cv.height);
    if (now > face.lookAt) {
      face.lookTo = [-1, 0, 0, 1][Math.floor(Math.random() * 4)];
      face.lookAt = now + 1500 + Math.random() * 2500;
    }
    face.look += (face.lookTo - face.look) * 0.35;
    const blink = now > face.blinkAt && now < face.blinkAt + 140;
    if (now > face.blinkAt + 140) face.blinkAt = now + 2200 + Math.random() * 3000;
    const lx = Math.round(face.look);
    const lit = new Set();
    const red = new Set();
    const eye = (cx) => {
      for (let y = 7; y <= 10; y++) for (let x = cx - 2; x <= cx + 1; x++) if (!blink || y === 9) lit.add(`${x + lx},${y}`);
    };
    eye(7);
    eye(14);
    red.add(`${5 + lx},13`);
    red.add(`${15 + lx},13`);
    // Mund: wippt, solange Musik spielt
    // 2.37: singt im Takt – Mundöffnung aus Stimme (Mitten) und Bass, Breite wächst bei lauten Stellen
    const level = eq.an ? Math.min(1, (eq.voice || 0) * 1.6 + (eq.bass || 0) * 0.6) : media?.playing ? (Math.sin(now / 160) + 1) / 2 : 0;
    const open = Math.round(level * 3.2);
    const wide = level > 0.55 ? 1 : 0;
    for (let x = 9 - wide; x <= 11 + wide; x++) for (let y = 14; y <= 14 + open; y++) lit.add(`${x + lx},${y}`);
    for (let y = 0; y < N; y++)
      for (let x = 0; x < N; x++) {
        const dx = x - (N - 1) / 2;
        const dy = y - (N - 1) / 2;
        if (dx * dx + dy * dy > 10.2 * 10.2) continue;
        const k = `${x},${y}`;
        g.beginPath();
        g.arc(x * S + S / 2, y * S + S / 2, S * (lit.has(k) || red.has(k) ? 0.4 : 0.22), 0, Math.PI * 2);
        g.fillStyle = red.has(k) ? accent() : lit.has(k) ? '#ffffff' : 'rgba(255,255,255,0.14)';
        g.fill();
      }
  }

  /* ------------------------------------------------------------ Steuerung */
  function apply() {
    const d = state?.settings?.desktopWidgets || {};
    const on = (k, def = true) => (d[k] === undefined ? def : d[k] !== false);
    document.body.classList.toggle('cards', d.cards !== false);
    cards.clock.hidden = !on('clock');
    cards.face.hidden = !on('face');
    cards.music.hidden = !on('music');
    cards.system.hidden = !on('system');
    cards.calendar.hidden = !on('calendar');
    cards.screen.hidden = !on('screentime', false);
    cards.upcoming.hidden = !on('upcoming', false);
    cards.eq.hidden = !on('eq', true);
    cards.mixer.hidden = !on('mixer', false);
    cards.trading.hidden = d.trading !== true;
    cards.weather.hidden = !on('weather', true);
    cards.football.hidden = !on('football', false);
    cards.clicker.hidden = !on('clicker', false);
    for (const k of ['uptime', 'notes', 'todo', 'calc', 'plant', 'mic', 'cam', 'sound', 'quick', 'perf']) if (cards[k]) cards[k].hidden = !on(k, false);
    window.dispatchEvent(new CustomEvent('dw-extra'));
    if (visible('football')) loadFoot();
    if (visible('clicker')) loadClick();
    document.documentElement.style.setProperty('--red', state?.settings?.widgetAccent || '#ff2d2d');
    for (const [id, el] of Object.entries(cards)) {
      const s = state?.settings?.widgetScale?.[id] || 1;
      el.style.zoom = s === 1 ? '' : String(s);
    }
    if (visible('weather')) loadWeather();
    cards.streamchat.hidden = d.streamchat !== true;
    place();
    if (visible('trading')) loadTrade();
    paintClock();
    paintSystem();
    paintScreen();
    paintUpcoming();
    paintCalendar();
    paintMusic();
    // nach dem Platzieren: erst dann ist klar, ob die Widgets auf diesem Monitor sichtbar sind
    setTimeout(() => {
      eqEnsure();
      loadMixer();
    }, 50);
  }

  async function loadSystem() {
    if (!visible('system') && !visible('perf')) return;
    try {
      pc = (await window.hub.pcLive()) || {};
      paintSystem();
    } catch {
      /* letzter Wert bleibt */
    }
  }
  async function loadScreen() {
    if (!visible('screen')) return;
    try {
      screen = await window.hub.screentime.summary();
      paintScreen();
    } catch {
      /* letzter Wert bleibt */
    }
  }

  setInterval(() => {
    if (visible('clock')) paintClock();
    if (visible('calendar')) paintCalendar();
  }, 1000);
  setInterval(loadSystem, 4000);
  setInterval(() => loadTrade(), 60000);
  setInterval(() => loadWeather(), 15 * 60000);
  setInterval(() => loadFoot(), 60000);
  setInterval(() => loadClick(), 1000);

  /* ------------------------------------------------------------ Fußball: live, nächstes Spiel, letztes Ergebnis */
  async function loadFoot() {
    if (!visible('football') || !window.hub.football) return;
    const body = document.getElementById('dw-foot-body');
    try {
      const o = await window.hub.football.overview();
      const rows = (o.rows || []).slice(0, 3);
      if (!rows.length) return (body.innerHTML = '<div class="dw-empty">Im Hub unter Fußball Teams folgen.</div>');
      const logo = (t) => (t?.logo ? `<img src="${esc(t.logo)}" alt="" />` : '<i></i>');
      body.innerHTML = rows
        .map((r) => {
          const ev = r.live || r.next || r.last;
          if (!ev) return `<div class="dw-fx"><span>${esc(r.team.name)}</span><small>kein Spiel</small></div>`;
          const [a, b] = [ev.teams?.find((t) => t.home) || ev.teams?.[0], ev.teams?.find((t) => !t.home) || ev.teams?.[1]];
          const mid = r.live ? `<b class="live">${esc(r.live.score ? `${r.live.score.home.score}:${r.live.score.away.score}` : `${a?.score ?? 0}:${b?.score ?? 0}`)}</b><small class="live">● ${esc(r.live.score?.clock || 'LIVE')}</small>`
            : r.next === ev ? `<b>${new Date(ev.date).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}</b><small>${new Date(ev.date).toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' })}</small>`
            : `<b>${esc(`${a?.score ?? ''}:${b?.score ?? ''}`)}</b><small>Ende</small>`;
          return `<div class="dw-fx">${logo(a)}<span>${esc(a?.abbr || a?.name || '')}</span><div class="dw-fx-mid">${mid}</div><span>${esc(b?.abbr || b?.name || '')}</span>${logo(b)}</div>`;
        })
        .join('');
      document.getElementById('dw-foot-state').textContent = rows.some((r) => r.live) ? '● LIVE' : '';
    } catch {
      /* letzter Stand bleibt */
    }
  }

  /* ------------------------------------------------------------ Autoclicker: Zähler und Start/Stopp */
  let clickRun = false;
  async function loadClick() {
    if (!visible('clicker') || !window.hub.autoclick) return;
    try {
      const st = await window.hub.autoclick.status();
      clickRun = st.running;
      document.getElementById('dw-click-n').textContent = Number(st.clicks || 0).toLocaleString('de-DE');
      const btn = document.getElementById('dw-click-btn');
      btn.textContent = st.running ? 'Stopp' : 'Start';
      btn.classList.toggle('on', st.running);
      document.getElementById('dw-click-state').textContent = st.running ? '● läuft' : st.hotkey ? `Taste ${st.hotkey}` : '';
    } catch {
      /* egal */
    }
  }
  document.getElementById('dw-click-btn')?.addEventListener('click', () => {
    (clickRun ? window.hub.autoclick.stop() : window.hub.autoclick.start()).then(loadClick).catch(() => {});
  });

  /* ------------------------------------------------------------ Punkt-Wetter */
  const WX_ICON = (code) => (code <= 1 ? 'sun' : code <= 3 ? 'cloud' : code <= 48 ? 'fog' : code <= 67 || (code >= 80 && code <= 82) ? 'rain' : code <= 77 || code === 85 || code === 86 ? 'snow' : 'storm');
  const WX_TEXT = { sun: 'Klar', cloud: 'Bewölkt', fog: 'Nebel', rain: 'Regen', snow: 'Schnee', storm: 'Gewitter' };
  // 9×9-Punktsymbole
  const WX_DOTS = {
    sun: ['000010000', '010000010', '000111000', '001111100', '101111101', '001111100', '000111000', '010000010', '000010000'],
    cloud: ['000000000', '000000000', '000111000', '001111100', '011111110', '111111111', '111111111', '011111110', '000000000'],
    fog: ['000000000', '111111110', '000000000', '011111111', '000000000', '111111110', '000000000', '011111111', '000000000'],
    rain: ['000111000', '001111100', '011111110', '111111111', '011111110', '000000000', '010010010', '001001001', '010010010'],
    snow: ['000010000', '010010010', '001010100', '000111000', '111111111', '000111000', '001010100', '010010010', '000010000'],
    storm: ['000111000', '001111100', '011111110', '111111111', '000011000', '000110000', '001111000', '000011000', '000110000'],
  };
  let wx = null;
  async function loadWeather(force) {
    if (!visible('weather')) return;
    if (!force && wx && Date.now() - wx.at < 14 * 60000) return drawWeather();
    const c = state?.settings?.weatherCity || { name: 'Zürich', lat: 47.37, lon: 8.54 };
    try {
      const d = await window.hub.tool.fetch(`https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1`);
      wx = { at: Date.now(), city: c.name, t: Math.round(d.current.temperature_2m), code: d.current.weather_code, hi: Math.round(d.daily.temperature_2m_max[0]), lo: Math.round(d.daily.temperature_2m_min[0]) };
    } catch {
      /* letzter Wert bleibt */
    }
    drawWeather();
  }
  /* Punktmatrix-Wetter wie das Gesicht: 21×21 Punkte im Kreis, alles bewegt sich. */
  function drawWeather() {
    const cv = document.getElementById('dw-wx');
    if (!cv || !wx || !visible('weather')) return;
    const g = cv.getContext('2d');
    const N = 21;
    const S = cv.width / N;
    const t = Date.now() / 1000;
    const kind = WX_ICON(wx.code);
    const night = (() => { const h = new Date().getHours(); return h < 6 || h >= 20; })();
    const col = new Map(); // "x,y" -> Farbe
    const put = (x, y, c) => { x = Math.round(x); y = Math.round(y); if (x >= 0 && y >= 0 && x < N && y < N) col.set(`${x},${y}`, c); };
    const disc = (cx, cy, r, c) => { for (let y = -r; y <= r; y++) for (let x = -r; x <= r; x++) if (x * x + y * y <= r * r + 0.5) put(cx + x, cy + y, c); };
    const cloud = (cx, cy, c) => { disc(cx - 3, cy + 1, 2.4, c); disc(cx, cy - 1, 3.2, c); disc(cx + 3.4, cy + 1, 2.4, c); for (let x = -5; x <= 6; x++) for (let y = 2; y <= 3; y++) put(cx + x, cy + y, c); };
    const acc = accent();
    if (kind === 'sun') {
      if (night) {
        disc(10, 10, 5, '#fff');
        disc(12.5, 8.5, 4.2, null);
        for (let k = 0; k < 6; k++) { const a = k * 1.7 + 1; if (Math.sin(t * 2 + k) > 0.2) put(3 + ((k * 7) % 15), 3 + ((k * 5) % 14), 'rgba(255,255,255,.8)'); }
      } else {
        disc(10, 10, 4, acc === '#ffffff' ? '#ffd60a' : '#ffd60a');
        for (let k = 0; k < 8; k++) {
          const a = (k / 8) * Math.PI * 2 + t * 0.6;
          const len = 6.5 + Math.sin(t * 3 + k) * 0.8;
          for (let r = 5.6; r <= len; r += 0.7) put(10 + Math.cos(a) * r, 10 + Math.sin(a) * r, '#ffd60a');
        }
      }
    } else if (kind === 'cloud' || kind === 'fog') {
      if (!night) disc(13, 7, 3, '#ffd60a');
      const dx = Math.sin(t * 0.5) * 2;
      cloud(9 + dx, 10, '#fff');
      if (kind === 'fog') for (let y of [15, 17]) for (let x = 3; x < 18; x++) if ((x + Math.floor(t * 4) + y) % 3) put(x, y, 'rgba(255,255,255,.55)');
      else cloud(14 - dx * 0.6, 14, 'rgba(255,255,255,.55)');
    } else {
      cloud(10, 7, '#fff');
      if (kind === 'rain' || kind === 'storm') {
        for (let k = 0; k < 7; k++) {
          const x = 5 + k * 1.8;
          const y = 12 + ((t * 9 + k * 2.3) % 7);
          put(x, y, '#64d2ff');
          put(x, y - 1, 'rgba(100,210,255,.45)');
        }
        if (kind === 'storm' && Math.sin(t * 5) > 0.92) for (const [x, y] of [[11, 11], [10, 12], [10, 13], [11, 13], [10, 14], [9, 15]]) put(x, y, acc);
      } else {
        for (let k = 0; k < 7; k++) put(4 + k * 2 + Math.sin(t * 2 + k), 12 + ((t * 3 + k * 1.7) % 7), '#fff');
      }
    }
    g.clearRect(0, 0, cv.width, cv.height);
    for (let y = 0; y < N; y++)
      for (let x = 0; x < N; x++) {
        const dx = x - (N - 1) / 2;
        const dy = y - (N - 1) / 2;
        if (dx * dx + dy * dy > 10.2 * 10.2) continue;
        const c = col.get(`${x},${y}`);
        g.beginPath();
        g.arc(x * S + S / 2, y * S + S / 2, S * (c ? 0.4 : 0.22), 0, Math.PI * 2);
        g.fillStyle = c || 'rgba(255,255,255,0.14)';
        g.fill();
      }
    document.getElementById('dw-wx-temp').textContent = `${wx.t}°`;
    document.getElementById('dw-wx-city').textContent = wx.city || '';
    document.getElementById('dw-wx-foot').textContent = `${WX_TEXT[kind]} · H ${wx.hi}° T ${wx.lo}°`;
  }
  setInterval(drawWeather, 90);

  /* ------------------------------------------------------------ Strg + Rechtsklick / Strg + Scrollen */
  let menu = null;
  const closeMenu = () => {
    menu?.remove();
    menu = null;
  };
  stage.addEventListener('contextmenu', (e) => {
    const el = e.target.closest('.dw');
    if (!el) return;
    e.preventDefault();
    if (!e.ctrlKey) return;
    closeMenu();
    const id = el.dataset.w;
    menu = document.createElement('div');
    menu.className = 'dw-menu';
    menu.innerHTML = `<button data-m="bigger">Größer</button><button data-m="smaller">Kleiner</button><button data-m="reset">Originalgröße</button><i></i><button data-m="hide" class="danger">Widget ausblenden</button>`;
    menu.style.left = `${Math.min(e.clientX, window.innerWidth - 190)}px`;
    menu.style.top = `${Math.min(e.clientY, window.innerHeight - 170)}px`;
    stage.appendChild(menu);
    menu.addEventListener('click', (ev) => {
      const m = ev.target.closest('[data-m]')?.dataset.m;
      if (!m) return;
      const cur = state?.settings?.widgetScale?.[id] || 1;
      if (m === 'hide') window.hub.setSettings({ desktopWidgets: { [SETTING_OF[id] || id]: false } }).catch(() => {});
      else window.hub.setSettings({ widgetScale: { [id]: m === 'reset' ? 1 : Math.round((cur + (m === 'bigger' ? 0.1 : -0.1)) * 10) / 10 } }).catch(() => {});
      closeMenu();
    });
  });
  document.addEventListener('pointerdown', (e) => {
    if (menu && !e.target.closest('.dw-menu')) closeMenu();
  });
  let wheelTimer = 0;
  stage.addEventListener(
    'wheel',
    (e) => {
      const el = e.target.closest('.dw');
      if (!el || !e.ctrlKey) return;
      e.preventDefault();
      const id = el.dataset.w;
      const cur = Number(el.style.zoom) || 1;
      const next = Math.max(0.6, Math.min(1.8, Math.round((cur + (e.deltaY < 0 ? 0.05 : -0.05)) * 100) / 100));
      el.style.zoom = String(next);
      clearTimeout(wheelTimer);
      wheelTimer = setTimeout(() => window.hub.setSettings({ widgetScale: { [id]: next } }).catch(() => {}), 350);
    },
    { passive: false },
  );

  /* ------------------------------------------------------------ Premium: Trading */
  let tradeKey = '';
  const spark = (vals, up) => {
    if (!vals?.length) return '';
    const lo = Math.min(...vals);
    const hi = Math.max(...vals);
    const pts = vals.map((v, i) => `${((i / Math.max(1, vals.length - 1)) * 100).toFixed(1)},${(30 - ((v - lo) / (hi - lo || 1)) * 28).toFixed(1)}`).join(' ');
    return `<svg viewBox="0 0 100 32" preserveAspectRatio="none"><polyline points="${pts}" fill="none" stroke="${up ? '#30d158' : '#ff453a'}" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;
  };
  const money = (v, cur) => (Number.isFinite(v) ? `${v.toLocaleString('de-DE', { minimumFractionDigits: v < 10 ? 3 : 2, maximumFractionDigits: v < 10 ? 3 : 2 })}${cur === 'USD' ? ' $' : cur === 'EUR' ? ' €' : cur === 'CHF' ? ' CHF' : ''}` : '–');
  async function loadTrade(force) {
    if (!visible('trading') || !window.hub.market) return;
    const syms = state?.settings?.tradingSymbols?.length ? state.settings.tradingSymbols : ['AAPL', 'NVDA', 'TSLA', 'BTC-USD'];
    const key = syms.join(',');
    if (!force && key === tradeKey && Date.now() - (loadTrade.at || 0) < 50000) return;
    tradeKey = key;
    loadTrade.at = Date.now();
    const body = document.getElementById('dw-trade-body');
    try {
      const list = await window.hub.market.quotes(syms);
      body.innerHTML = list
        .map((q) => (q.error ? `<div class="dw-q"><b>${esc(q.sym)}</b><span class="dw-q-n">nicht gefunden</span></div>` : `<div class="dw-q"><div class="dw-q-l"><b>${esc(q.sym.replace('-USD', ''))}</b><span class="dw-q-n">${esc(q.name)}</span></div>${spark(q.spark, q.change >= 0)}<div class="dw-q-r"><b>${money(q.price, q.currency)}</b><span class="${q.change >= 0 ? 'up' : 'down'}">${q.change >= 0 ? '+' : '−'}${Math.abs(q.change).toFixed(2)} %</span></div></div>`))
        .join('');
      document.getElementById('dw-trade-state').textContent = new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      body.innerHTML = `<div class="dw-empty">${esc(String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''))}</div>`;
    }
  }

  /* ------------------------------------------------------------ Premium: Stream-Chat */
  let chatMsgs = [];
  const chatColor = (m) => m.color || `hsl(${[...String(m.user || '?')].reduce((a, c) => a + c.charCodeAt(0), 0) % 360} 80% 68%)`;
  function paintChat() {
    const body = document.getElementById('dw-chat-body');
    if (!body) return;
    if (!chatMsgs.length) return;
    body.innerHTML = chatMsgs
      .slice(-9)
      .map((m) => `<p class="dw-cm ${m.kind && m.kind !== 'chat' ? 'sys' : ''}">${m.user ? `<b style="color:${esc(chatColor(m))}">${esc(m.user)}</b> ` : ''}${esc(m.text)}</p>`)
      .join('');
  }
  function chatState(s) {
    const el = document.getElementById('dw-chat-state');
    if (!el || !s) return;
    el.textContent = s.status === 'live' ? `● ${s.cfg?.platform === 'twitch' ? 'Twitch' : 'TikTok'} · ${s.cfg?.channel}` : s.status === 'connecting' ? 'verbindet …' : s.status === 'error' ? s.error : '';
    if (s.msgs && !chatMsgs.length) {
      chatMsgs = s.msgs.slice(-20);
      paintChat();
    }
  }
  window.hub.streamChat?.onMsgs?.((list) => {
    chatMsgs = [...chatMsgs, ...(list || [])].slice(-30);
    if (visible('streamchat')) paintChat();
  });
  window.hub.streamChat?.onState?.(chatState);
  window.hub.streamChat?.state?.().then(chatState).catch(() => {});
  setInterval(loadScreen, 60000);
  setInterval(drawFace, 90); // ~11 Bilder/s reichen für das Gesicht

  window.hub.onMedia?.((m) => {
    if (!m) return;
    const sameSong = media && media.title === m.title && media.artist === m.artist;
    media = { ...m, art: m.art ? m.art : sameSong ? media.art || '' : '' };
    if (visible('music')) paintMusic();
  });
  window.hub.onState((next) => {
    state = next;
    apply();
  });
  window.hub
    .state()
    .then((initial) => {
      state = initial;
      apply();
      loadSystem();
      loadScreen();
    })
    .catch(() => {});
})();
