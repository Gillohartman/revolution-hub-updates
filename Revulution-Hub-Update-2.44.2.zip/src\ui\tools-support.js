'use strict';

/* 2.42 Support: Feedback, Bugs, Probleme und Meldungen (z. B. ein Premium-Wallpaper) als Ticket ans Admin-Center.
   Andere Seiten können vorausfüllen: window.revSupport({ kind, ref, refName, img, text }). */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-support';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  // 2.42.1: gezeichnete Symbole statt Emojis
  const SVG = {
    bug: '<path d="M9 7a3 3 0 0 1 6 0"/><rect x="7" y="7" width="10" height="12" rx="5"/><path d="M12 11v8M3 13h4M17 13h4M4 7l3 2M20 7l-3 2M4 19l3-2M20 19l-3-2"/>',
    problem: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="m5.6 5.6 3.6 3.6M14.8 14.8l3.6 3.6M18.4 5.6l-3.6 3.6M9.2 14.8l-3.6 3.6"/>',
    feedback: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9.5h8M8 12.5h5"/>',
    idea: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
    wallpaper: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
    other: '<path d="M4 8h16v10H4z"/><path d="M4 8l2-4h12l2 4M10 12h4"/>',
  };
  const ico = (k, size = 22) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${SVG[k] || SVG.other}</svg>`;
  const KINDS = [
    ['bug', '#ff5a6e', 'Bug melden', 'Etwas funktioniert nicht'],
    ['problem', '#f59e0b', 'Problem', 'Ich komme nicht weiter'],
    ['feedback', '#38bdf8', 'Feedback', 'Was dir gefällt oder nicht'],
    ['idea', '#facc15', 'Idee', 'Neue Funktion vorschlagen'],
    ['wallpaper', '#a78bfa', 'Hintergrund melden', 'Ein Wallpaper ist falsch oder kaputt'],
  ];
  const st = { kind: 'bug', subject: '', text: '', email: '', ref: '', refName: '', refImg: '', shot: '', withShot: false, busy: false, sent: null, err: '' };
  const load = () => {
    try {
      return JSON.parse(localStorage.getItem('rev-tickets') || '[]');
    } catch {
      return [];
    }
  };

  window.revSupport = (pre = {}) => {
    Object.assign(st, { kind: pre.kind || 'bug', ref: pre.ref || '', refName: pre.refName || '', refImg: pre.img || '', text: pre.text || '', subject: pre.refName ? `Hintergrund: ${pre.refName}` : '', sent: null, err: '' });
    window.hub.open(PAGE);
  };

  function html() {
    const mine = load().slice(0, 5);
    if (st.sent) {
      return `<div class="sup-done"><div class="sup-check"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></div><h3>Danke! Dein Ticket ist angekommen.</h3><p class="muted">Ticket-Nummer <b>${esc(st.sent.slice(0, 8).toUpperCase())}</b>. Wir schauen es uns so bald wie möglich an.</p><button class="btn primary" data-sup="new">Neues Ticket</button></div>`;
    }
    return `<div class="sup-hero"><div class="sup-ic"><svg viewBox="0 0 24 24"><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="13" width="4" height="6" rx="2"/><rect x="17" y="13" width="4" height="6" rx="2"/><path d="M19 19a3 3 0 0 1-3 3h-3"/></svg></div><div><h3>Wie können wir helfen?</h3><p class="muted">Schreib uns – dein Ticket landet direkt beim Revulution-Team.</p></div></div>
      <div class="sup-kinds">${KINDS.map(([k, c, n, d], i) => `<button class="sup-kind ${st.kind === k ? 'on' : ''}" style="--d:${i * 40}ms;--kc:${c}" data-sup-kind="${k}"><span class="sup-kic">${ico(k)}</span><b>${esc(n)}</b><small>${esc(d)}</small><i class="sup-dot"></i></button>`).join('')}</div>
      <div class="sup-form">
        ${st.ref ? `<div class="sup-ref">${st.refImg ? `<img src="${esc(st.refImg)}" alt="" />` : ''}<div><small>Betrifft</small><b>${esc(st.refName || st.ref)}</b></div><button class="sup-x" data-sup="unref" title="Entfernen">✕</button></div>` : ''}
        <input class="input sup-in" data-sup-f="subject" maxlength="80" placeholder="Betreff (kurz)" value="${esc(st.subject)}" />
        <textarea class="input sup-text" data-sup-f="text" maxlength="3000" rows="2" placeholder="Was ist passiert? Je genauer, desto schneller können wir helfen …">${esc(st.text)}</textarea>
        <input class="input sup-in" data-sup-f="email" maxlength="80" placeholder="E-Mail für eine Antwort (optional)" value="${esc(st.email)}" />
        <div class="sup-row"><button class="switch ${st.withShot ? 'on' : ''}" data-sup="shot"></button><span>Bildschirmfoto vom Hub anhängen</span><span class="sup-kindtag" style="--kc:${KINDS.find((k) => k[0] === st.kind)?.[1] || '#38bdf8'}">${ico(st.kind, 13)} ${esc(KINDS.find((k) => k[0] === st.kind)?.[2] || '')}</span>${st.shot && st.withShot ? `<img class="sup-shot" src="${st.shot}" alt="" />` : ''}</div>
        ${st.err ? `<p class="err">${esc(st.err)}</p>` : ''}
        <button class="btn primary sup-send" data-sup="send" ${st.busy ? 'disabled' : ''}>${st.busy ? 'Wird gesendet …' : 'Ticket senden'}</button>
      </div>
      ${mine.length ? `<h4 class="pc-h">Deine letzten Tickets</h4><div class="sup-mine">${mine.map((x) => `<div><span class="sup-mini" style="--kc:${KINDS.find((k) => k[0] === x.kind)?.[1] || '#94a3b8'}">${ico(x.kind, 15)}</span><b>${esc(x.subject || '(ohne Betreff)')}</b><small>${new Date(x.at).toLocaleDateString('de-CH')} · #${esc(x.id.slice(0, 8).toUpperCase())}</small></div>`).join('')}</div>` : ''}`;
  }

  // Textfeld wächst mit
  const grow = (el) => {
    el.style.height = 'auto';
    el.style.height = `${Math.min(320, el.scrollHeight + 2)}px`;
  };
  document.addEventListener('input', (e) => {
    if (!active()) return;
    const f = e.target.dataset?.supF;
    if (!f) return;
    st[f] = e.target.value;
    if (f === 'text') grow(e.target);
  });
  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const k = e.target.closest('[data-sup-kind]')?.dataset.supKind;
    if (k) {
      st.kind = k;
      return ctx().render();
    }
    const a = e.target.closest('[data-sup]')?.dataset.sup;
    if (!a) return;
    if (a === 'new') {
      Object.assign(st, { sent: null, subject: '', text: '', ref: '', refName: '', refImg: '', shot: '', withShot: false });
      return ctx().render();
    }
    if (a === 'unref') {
      Object.assign(st, { ref: '', refName: '', refImg: '' });
      return ctx().render();
    }
    if (a === 'shot') {
      st.withShot = !st.withShot;
      if (st.withShot && !st.shot) st.shot = await window.hub.support.snap().catch(() => '');
      return ctx().render();
    }
    if (a === 'send') {
      st.busy = true;
      st.err = '';
      ctx().render();
      try {
        const r = await window.hub.support.send({ kind: st.kind, subject: st.subject, text: st.text, email: st.email, ref: st.ref, refName: st.refName, img: st.withShot ? st.shot : '' });
        const list = [{ id: r.id, kind: st.kind, subject: st.subject, at: Date.now() }, ...load()].slice(0, 30);
        localStorage.setItem('rev-tickets', JSON.stringify(list));
        st.sent = r.id;
      } catch (err) {
        st.err = errText(err);
      }
      st.busy = false;
      ctx().render();
    }
  });

  T.register(PAGE, { nav: 'Support', title: 'Support', sub: 'Feedback, Bugs und Hilfe', icon: 'chat', tint: 'linear-gradient(135deg,#38bdf8,#6366f1)', desc: 'Feedback geben, Bugs melden oder Hilfe bekommen – dein Ticket landet direkt beim Revulution-Team.' }, html);
})();
