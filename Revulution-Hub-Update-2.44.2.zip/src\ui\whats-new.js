'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.44.2',
  title: 'Revulution Hub 2.44.2',
  sub: 'Full Gaming Mode, neue Island, Sprachnachrichten, Karaoke-Songtext und eine neue Island.',
  items: [
    { open: 'gaming', icon: 'crosshair', title: 'Full Gaming Mode', text: 'Ein Klick im Gaming Hub: Hub, Island und Widgets gehen ganz aus, nur das Crosshair bleibt. Ein rundes Glas-Logo auf dem Desktop startet alles wieder – mit allem, was offen war.' },
        { open: 'chats', icon: 'chat', title: 'Chats', text: 'Sprachnachrichten aufnehmen und abspielen, jeder Anruf steht im Chat (verpasst, abgelehnt, Dauer), immer ganz unten, Anruf-Fenster ohne Kasten.' },
    { open: 'tool-player', icon: 'music', title: 'Player', text: 'Songtext wie in der Island: das gesungene Wort füllt sich weiß, der Rest bleibt grau. Kein Notenzeichen mehr hinter dem Cover. Auch in der Player-Karte auf der Startseite.' },
    { open: 'orbit', icon: 'layers', title: 'Island', text: 'Erkennt Songs wieder zuverlässig, blendet sich im Vollbild ganz aus, aufgeklappt jetzt kompakt im Liquid-Glass-Stil der App (Tabs als Leiste, Glas-Karten, deutsche Texte), Songtext-Leiste passt sich an.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Widgets', text: 'Pflanze lässt sich endlich ausschalten und erscheint nicht mehr doppelt auf dem anderen Monitor. Neues Leistungs-Widget (CPU, GPU, RAM, Ping), per Rechtsklick entfernen, „Fertig“ klappt wieder, keine doppelten Widgets auf anderen Monitoren.' },
    { open: 'tool-keyboard', icon: 'keyboard', title: 'Geräte & Maus-Fix', text: 'Neuer Tab „Geräte“: alles, was angeschlossen ist. Bei Logitech-Mäusen wie der G502 X gibt es einen Fix gegen Stocken (USB-Energiesparen aus, Empfänger-Neustart) – und der Hub nutzt keinen globalen Maus-Hook mehr.' },
    { open: 'home', icon: 'spark', title: 'Feinschliff', text: 'Sattere App-Symbole, sauberere runde Ecken, Favoriten nur als Logos, Kalender aufgeräumt, Titel im Gaming Hub nicht mehr abgeschnitten, Facecam startet nie von selbst.' },
  ],
};
