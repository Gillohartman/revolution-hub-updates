'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.43.0',
  title: 'Revulution Hub 2.43',
  sub: 'Kindersicherung, Player mit Songtext, Bahnhofsuhr in der Island und viele Reparaturen.',
  items: [
    { open: 'tool-parental', icon: 'shield', title: 'Kindersicherung', text: 'Eltern legen einen PIN fest: tägliche Bildschirmzeit, Limits pro App und gesperrte Webseiten in allen Browsern. Der Hub startet dann mit Windows und lässt sich nur mit PIN beenden.' },
    { open: 'tool-player', icon: 'music', title: 'Player', text: 'Links groß das Albumbild, rechts der Songtext ohne Hintergrund – die gesungene Zeile leuchtet auf.' },
    { open: 'orbit', icon: 'layers', title: 'Island', text: 'SBB-Bahnhofsuhr, mehr Termine und Nachrichten, blauer Termin-Ring ohne Zeiger. Musik wird auch erkannt, wenn Windows keine Sitzung meldet (Spotify), Cover laden nach.' },
    { open: 'chats', icon: 'chat', title: 'Chats', text: 'Immer ganz unten im Chat, verpasste Anrufe als Hinweis mit „Zurückrufen“, Anruf-Fenster sauber rund.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Widgets', text: 'Märkte-Widget repariert, Märkte und Stream-Chat in der Galerie, Pflanze stabiler.' },
    { open: 'chess', icon: 'chess', title: 'Schach', text: 'Der Coach ist standardmäßig aus – du schaltest ihn selbst ein.' },
  ],
};
