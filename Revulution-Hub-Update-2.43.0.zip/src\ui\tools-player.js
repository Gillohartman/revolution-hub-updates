'use strict';

/* 2.43 Player: links groß das Albumbild, rechts der Songtext ohne Hintergrund – die gesungene Zeile leuchtet auf
   und der Text gleitet weich mit. Songtexte (mit Zeitstempeln) kommen von lrclib.net. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-player';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const pl = { m: null, at: 0, key: '', lines: null, plain: '', loading: false, idx: -1, raf: 0 };

  const keyOf = (m) => `${m?.title || ''}|${m?.artist || ''}`;
  const clean = (s) => String(s || '').replace(/\(.*?\)|\[.*?\]|official|video|lyrics|audio|- topic/gi, ' ').replace(/\s+/g, ' ').trim();
  function parseLrc(text) {
    const out = [];
    for (const row of String(text || '').split(/\r?\n/)) {
      const tags = [...row.matchAll(/\[(\d+):(\d+(?:\.\d+)?)\]/g)];
      const words = row.replace(/\[[^\]]*\]/g, '').trim();
      for (const t of tags) out.push({ t: Number(t[1]) * 60 + Number(t[2]), text: words });
    }
    return out.sort((a, b) => a.t - b.t);
  }
  async function loadLyrics(m) {
    const k = keyOf(m);
    if (!m?.title || pl.key === k) return;
    pl.key = k;
    pl.lines = null;
    pl.plain = '';
    pl.idx = -1;
    pl.loading = true;
    if (active()) ctx().render();
    try {
      const q = new URLSearchParams({ track_name: clean(m.title), artist_name: clean(m.artist) });
      if (m.duration > 0) q.set('duration', String(Math.round(m.duration)));
      let r = await window.hub.tool.fetch(`https://lrclib.net/api/get?${q}`).catch(() => null);
      if (!r?.syncedLyrics && !r?.plainLyrics) {
        const list = await window.hub.tool.fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(`${clean(m.artist)} ${clean(m.title)}`)}`).catch(() => null);
        r = Array.isArray(list) ? list.find((x) => x.syncedLyrics) || list[0] : null;
      }
      if (pl.key !== k) return;
      pl.lines = r?.syncedLyrics ? parseLrc(r.syncedLyrics) : null;
      pl.plain = !pl.lines && r?.plainLyrics ? r.plainLyrics : '';
    } catch {
      pl.lines = null;
    }
    pl.loading = false;
    if (active()) ctx().render();
  }
  // Position zwischen den Updates weiterzählen
  const pos = () => {
    const m = pl.m;
    if (!m) return 0;
    return (Number(m.position) || 0) + (m.playing ? (Date.now() - pl.at) / 1000 : 0);
  };
  window.hub.onMedia?.((m) => {
    if (!m) return;
    const same = pl.m && keyOf(pl.m) === keyOf(m);
    pl.m = { ...m, art: m.art || (same ? pl.m.art : '') };
    pl.at = Date.now();
    if (!same) {
      loadLyrics(pl.m);
      if (active()) ctx().render();
    } else if (active()) {
      const btn = document.querySelector('.pl-ctl .main');
      if (btn) btn.innerHTML = window.icon(pl.m.playing ? 'pause' : 'play', 26);
      const art = document.querySelector('.pl-art');
      if (art && pl.m.art && !art.style.backgroundImage) art.style.backgroundImage = `url('data:image/jpeg;base64,${pl.m.art}')`;
    }
    tick();
  });

  function tick() {
    if (pl.raf || !active()) return;
    pl.raf = requestAnimationFrame(() => {
      pl.raf = 0;
      if (!active()) return;
      const p = pos();
      const bar = document.querySelector('.pl-prog i');
      if (bar && pl.m?.duration > 0) bar.style.width = `${Math.min(100, (p / pl.m.duration) * 100)}%`;
      if (pl.lines?.length) {
        let i = -1;
        for (let k = 0; k < pl.lines.length; k++) if (pl.lines[k].t <= p + 0.25) i = k;
        if (i !== pl.idx) {
          pl.idx = i;
          const box = document.querySelector('.pl-lyrics');
          const rows = box?.querySelectorAll('.pl-line');
          rows?.forEach((el, n) => {
            el.classList.toggle('on', n === i);
            el.classList.toggle('past', n < i);
          });
          const cur = rows?.[Math.max(0, i)];
          if (box && cur) {
            const target = cur.offsetTop - box.clientHeight * 0.36;
            box.querySelector('.pl-roll').style.transform = `translateY(${-Math.max(0, target)}px)`;
          }
        }
      }
      if (pl.m?.playing) tick();
      else setTimeout(tick, 500);
    });
  }

  function html() {
    const m = pl.m;
    setTimeout(tick, 30);
    if (!m?.title) {
      return `<div class="pl-empty"><div class="pl-art none">${window.icon('music', 64)}</div><h2>Gerade läuft nichts</h2><p class="muted">Spiel Musik in Spotify, im Browser oder einer anderen App – hier erscheint dann das Cover mit dem Songtext.</p></div>`;
    }
    if (pl.key !== keyOf(m)) loadLyrics(m);
    const art = m.art ? `style="background-image:url('data:image/jpeg;base64,${m.art}')"` : '';
    const lyrics = pl.loading
      ? '<div class="pl-note">Songtext wird gesucht …</div>'
      : pl.lines?.length
        ? `<div class="pl-roll">${pl.lines.map((l, i) => `<p class="pl-line ${i === pl.idx ? 'on' : i < pl.idx ? 'past' : ''}" style="--d:${Math.min(i, 12) * 30}ms">${esc(l.text || '♪')}</p>`).join('')}</div>`
        : pl.plain
          ? `<div class="pl-roll plain">${pl.plain.split(/\r?\n/).map((l) => `<p class="pl-line past">${esc(l) || '&nbsp;'}</p>`).join('')}</div>`
          : '<div class="pl-note">Für diesen Song gibt es keinen Songtext.</div>';
    return `<div class="pl">
      <div class="pl-left">
        <div class="pl-art" ${art}>${m.art ? '' : window.icon('music', 64)}</div>
        <div class="pl-meta"><b>${esc(m.title)}</b><span>${esc(m.artist || '')}</span></div>
        <div class="pl-prog"><i></i></div>
        <div class="pl-ctl"><button data-pl="prev">${window.icon('arrow', 20).replace('class="icon"', 'class="icon flip"')}</button><button class="main" data-pl="playpause">${window.icon(m.playing ? 'pause' : 'play', 26)}</button><button data-pl="next">${window.icon('arrow', 20)}</button></div>
      </div>
      <div class="pl-lyrics ${pl.plain ? 'scroll' : ''}">${lyrics}</div>
    </div>`;
  }

  document.addEventListener('click', (e) => {
    if (!active()) return;
    const b = e.target.closest('[data-pl]');
    if (!b) return;
    window.hub.cc?.media?.(b.dataset.pl)?.catch?.(() => {});
    if (b.dataset.pl === 'playpause' && pl.m) {
      pl.m.playing = !pl.m.playing;
      pl.m.position = pos();
      pl.at = Date.now();
      b.innerHTML = window.icon(pl.m.playing ? 'pause' : 'play', 26);
      tick();
    }
  });

  T.register(PAGE, { nav: 'Player', title: 'Player', sub: 'Cover und Songtext im Vollbild', icon: 'music', tint: 'linear-gradient(135deg,#f472b6,#7c3aed)', desc: 'Großes Albumbild und der Songtext, der beim Singen mitleuchtet – ganz ohne Ablenkung.' }, html);
})();
