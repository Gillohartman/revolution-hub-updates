'use strict';
/*
 * Das Dock als eigene, durchsichtige Ebene über den Apps (die Apps laufen dahinter weiter).
 * Der Hub schickt das Modell (Apps, Punkte, Badges); hier: Zeichnen, weiche Vergrößerung,
 * Namen, Ziehen zum Umsortieren, Rechtsklick-Menü. Die Ebene meldet ihre nötige Größe.
 */
(() => {
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const MAX = 1.42; // grösste Vergrösserung
  let model = null;
  let hover = false, menuOpen = false, drag = null;
  const fx = { cur: new Map(), target: new Map(), raf: 0, mouse: null };

  const vertical = () => model && (model.pos === 'left' || model.pos === 'right');

  function tileHtml(it) {
    return `<button class="dock-item ${it.active ? 'active' : ''}" data-id="${esc(it.id)}" ${it.special ? `data-special="${esc(it.special)}"` : 'draggable="true"'} data-tip="${esc(it.tip)}">${window.appArt(it.art || it.id, 'dock-ic')}${it.dot ? '<i class="dock-dot"></i>' : ''}${it.badge ? `<b class="app-badge">${it.badge > 99 ? '99+' : it.badge}</b>` : ''}</button>`;
  }
  function render() {
    if (!model) return;
    const el = $('#dock');
    document.body.dataset.dock = model.pos;
    document.body.dataset.dockSize = model.size;
    el.className = `dock dock-${model.pos} size-${model.size} ${model.magnify ? 'magnify' : ''} ${hover ? 'live' : ''}`;
    el.style.setProperty('--tile', `${model.tile}px`);
    el.innerHTML = `<div class="dock-bar">${model.items.map(tileHtml).join('')}<span class="dock-sep"></span>${model.fixed.map(tileHtml).join('')}</div>`;
    fx.cur.clear();
    if (fx.mouse) magnify(fx.mouse);
    report();
  }

  /* ---------------- Grösse der Ebene melden (knapp, beim Darüberfahren grösser) */
  let lastSent = '';
  function report() {
    const bar = $('.dock-bar');
    if (!bar || !model) return;
    const t = model.tile;
    const v = vertical();
    // natürliche Länge des Docks (ohne Vergrösserung)
    const n = model.items.length + model.fixed.length;
    const length = n * (t + 4) + 13 + 4 + 24;
    const thick = t + 17;
    const big = hover || menuOpen || drag;
    let w, h;
    if (v) {
      w = thick + 14 + (big ? Math.round(t * (MAX - 1)) + 200 : 0);
      h = length + 16 + (big ? Math.round(t * 1.6) : 0);
    } else {
      w = length + 16 + (big ? Math.round(t * 1.6) : 0);
      h = thick + 14 + (big ? Math.round(t * (MAX - 1)) + 56 : 0);
    }
    if (menuOpen) {
      w = Math.max(w, v ? 420 : w);
      h = Math.max(h, v ? h : 260);
    }
    const key = `${w}x${h}`;
    if (key === lastSent) return;
    lastSent = key;
    window.hub.dockSize?.({ w, h, expanded: big }).catch(() => {});
  }

  /* ---------------- Weiche Vergrösserung (Feder statt Sprung) */
  function magnify(e) {
    fx.mouse = e;
    const bar = $('.dock-bar');
    if (!bar || !model) return;
    const items = [...bar.querySelectorAll('.dock-item')];
    const r = bar.getBoundingClientRect();
    const v = vertical();
    const t = model.tile;
    // Mittelpunkte in Ruhelage (ohne Vergrösserung) berechnen
    const kids = [...bar.children];
    const sizes = kids.map((k) => (k.classList.contains('dock-sep') ? 13 : t));
    const total = sizes.reduce((a, b) => a + b, 0) + 4 * (kids.length - 1);
    let at = -total / 2;
    const centers = new Map();
    kids.forEach((k, i) => {
      centers.set(k, at + sizes[i] / 2);
      at += sizes[i] + 4;
    });
    const p = v ? e.clientY - (r.top + r.height / 2) : e.clientX - (r.left + r.width / 2);
    const range = t * 3;
    let hot = null, hotS = 0;
    for (const k of items) {
      const d = Math.abs(p - centers.get(k));
      const s = model.magnify && d < range ? 1 + (MAX - 1) * Math.pow((Math.cos((Math.PI * d) / range) + 1) / 2, 1.4) : 1;
      fx.target.set(k, s);
      if (d < t * 0.62 && s >= hotS) {
        hot = k;
        hotS = s;
      }
    }
    tip(hot);
    animate();
  }
  function calm() {
    fx.mouse = null;
    for (const k of fx.target.keys()) fx.target.set(k, 1);
    tip(null);
    animate();
  }
  function animate() {
    if (fx.raf) return;
    const step = () => {
      fx.raf = 0;
      let moving = false;
      for (const [k, target] of fx.target) {
        if (!k.isConnected) {
          fx.target.delete(k);
          continue;
        }
        const cur = fx.cur.get(k) ?? 1;
        const next = cur + (target - cur) * 0.24; // weiches Nachziehen
        const done = Math.abs(next - target) < 0.002;
        const val = done ? target : next;
        fx.cur.set(k, val);
        k.style.setProperty('--s', val.toFixed(4));
        if (!done) moving = true;
      }
      if (moving) fx.raf = requestAnimationFrame(step);
    };
    fx.raf = requestAnimationFrame(step);
  }
  function tip(item) {
    const el = $('#dock-label');
    if (!item || drag || menuOpen) {
      el.hidden = true;
      return;
    }
    el.textContent = item.dataset.tip || '';
    el.hidden = false;
    requestAnimationFrame(() => {
      if (el.hidden) return;
      const pos = model.pos, r = item.getBoundingClientRect(), t = el.getBoundingClientRect();
      el.dataset.pos = pos;
      const cx = Math.max(6, Math.min(window.innerWidth - t.width - 6, r.left + r.width / 2 - t.width / 2));
      el.style.left = `${pos === 'left' ? r.right + 12 : pos === 'right' ? r.left - t.width - 12 : cx}px`;
      el.style.top = `${pos === 'bottom' ? r.top - t.height - 12 : pos === 'top' ? r.bottom + 12 : r.top + r.height / 2 - t.height / 2}px`;
    });
  }

  let leaveT = null;
  document.addEventListener('mousemove', (e) => {
    clearTimeout(leaveT);
    if (!hover) {
      hover = true;
      $('#dock')?.classList.add('live');
      report();
    }
    if (e.target.closest?.('.dock-bar')) magnify(e);
    else calm();
  });
  document.addEventListener('mouseleave', () => {
    calm();
    clearTimeout(leaveT);
    leaveT = setTimeout(() => {
      if (menuOpen || drag) return;
      hover = false;
      $('#dock')?.classList.remove('live');
      report();
    }, 260);
  });
  window.addEventListener('blur', calm);

  /* ---------------- Klicks */
  document.addEventListener('click', (e) => {
    const m = e.target.closest('[data-menu]');
    if (m) return menuAction(m.dataset.menu, m.dataset.id);
    const b = e.target.closest('.dock-item');
    if (!b) return;
    if (b.dataset.special) return window.hub.dockSpecial(b.dataset.special).catch(() => {});
    b.classList.add('launching');
    setTimeout(() => b.classList.remove('launching'), 800);
    window.hub.open(b.dataset.id).catch(() => {});
  });

  /* ---------------- Rechtsklick-Menü */
  function closeMenu() {
    menuOpen = false;
    $('#dock-menu').hidden = true;
    report();
  }
  document.addEventListener('contextmenu', (e) => {
    const b = e.target.closest('.dock-item[data-id]:not([data-special])');
    e.preventDefault();
    if (!b) return;
    const it = model.items.find((x) => x.id === b.dataset.id);
    if (!it) return;
    menuOpen = true;
    report();
    const menu = $('#dock-menu');
    menu.innerHTML = `<b>${esc(it.tip)}</b><button data-menu="open" data-id="${esc(it.id)}">Öffnen</button>${it.canQuit ? `<button data-menu="quit" data-id="${esc(it.id)}">${esc(it.quitLabel || 'App beenden')}</button>` : ''}${it.id !== 'home' ? `<button data-menu="remove" data-id="${esc(it.id)}">Aus dem Dock entfernen</button>` : ''}<button data-menu="launcher">Alle Apps …</button>`;
    menu.hidden = false;
    // nach dem Vergrössern der Ebene platzieren
    setTimeout(() => {
      const r = menu.getBoundingClientRect();
      menu.style.left = `${Math.max(6, Math.min(e.clientX, window.innerWidth - r.width - 8))}px`;
      menu.style.top = `${Math.max(6, Math.min(e.clientY - r.height - 6, window.innerHeight - r.height - 8))}px`;
    }, 60);
  });
  document.addEventListener('mousedown', (e) => {
    if (menuOpen && !e.target.closest('#dock-menu')) closeMenu();
  });
  function menuAction(a, id) {
    closeMenu();
    if (a === 'open') window.hub.open(id);
    if (a === 'launcher') window.hub.dockSpecial('launcher');
    if (a === 'remove') window.hub.setSettings({ dock: { items: model.items.map((x) => x.id).filter((x) => x !== id) } });
    if (a === 'quit') {
      const it = model.items.find((x) => x.id === id);
      if (it?.module) window.hub.closeModule(id).catch(() => {});
      else window.hub.open('home');
    }
  }

  /* ---------------- Ziehen zum Umsortieren */
  document.addEventListener('dragstart', (e) => {
    const b = e.target.closest('.dock-item[draggable="true"]');
    if (!b) return;
    drag = b.dataset.id;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', drag);
    b.classList.add('dragging');
    tip(null);
  });
  document.addEventListener('dragover', (e) => {
    if (!drag) return;
    e.preventDefault();
    document.querySelectorAll('.drop-before').forEach((x) => x.classList.remove('drop-before'));
    const over = e.target.closest('.dock-item[draggable="true"]');
    if (over && over.dataset.id !== drag) over.classList.add('drop-before');
  });
  document.addEventListener('drop', (e) => {
    if (!drag) return;
    e.preventDefault();
    const before = e.target.closest('.dock-item[draggable="true"]')?.dataset.id;
    const items = model.items.map((x) => x.id).filter((x) => x !== drag);
    const at = before ? items.indexOf(before) : -1;
    if (at >= 0) items.splice(at, 0, drag);
    else items.push(drag);
    window.hub.setSettings({ dock: { items } }).catch(() => {});
  });
  document.addEventListener('dragend', () => {
    drag = null;
    document.querySelectorAll('.dragging, .drop-before').forEach((x) => x.classList.remove('dragging', 'drop-before'));
    report();
  });

  window.hub.onDockModel?.((m) => {
    model = m;
    render();
  });
  window.hub.dockReady?.().then((m) => {
    if (m && !model) {
      model = m;
      render();
    }
  }).catch(() => {});
})();
