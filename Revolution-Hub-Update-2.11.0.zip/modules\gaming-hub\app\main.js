const {
  app,
  BrowserWindow,
  Menu,
  Tray,
  ipcMain,
  shell,
  dialog,
  globalShortcut,
  desktopCapturer,
  net,
  nativeImage,
  protocol,
  screen,
  session,
  crashReporter,
} = global.__revolutionHub.shim('gaming');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { pathToFileURL } = require('url');
const { Readable } = require('stream');
const { Store, normalizeCrosshair, normalizePerf } = require('./store');
const { patchMp4Duration } = require('./mp4-duration');
const { rebaseClip } = require('./clip-fix');
const {
  MODES,
  RANKS,
  activeProfile,
  newId,
  normalizeApp,
  normalizeProfile,
  defaultProfiles,
} = require('./crosshair');

protocol.registerSchemesAsPrivileged([
  { scheme: 'xh', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } },
  { scheme: 'wall', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true } },
]);
const { scanDirectory, listReplayFiles } = require('./scanner');
const { buildKillCards } = require('./killcards');
const { startWatch } = require('./game');
const ocr = require('./ocr');
const { ChestCounter } = require('./chests');
const { PlayerBook } = require('./players');
const { parseFeed, distance, isPlausibleName } = require('./killfeed');
const inputHook = require('./input');
const media = require('./media');
const perf = require('./perf');
const audio = require('./audio');

const ROOT = path.join(__dirname, '..');
// Umbenennung auf „Revolution Gaming Hub“: Die Daten bleiben im bisherigen
// Ordner, damit Profile, Clips und Einstellungen die Umbenennung überleben.
try {
  const explicitDir = process.argv.some((arg) => arg.startsWith('--user-data-dir='));
  const legacyData = path.join(app.getPath('appData'), 'Revolution Crosshair');
  if (!explicitDir && fs.existsSync(legacyData)) app.setPath('userData', legacyData);
} catch {
  /* Wenn das nicht klappt, gilt der Standardordner */
}
const DEFAULT_REPLAY_DIR = path.join(
  process.env.LOCALAPPDATA || '',
  'FortniteGame',
  'Saved',
  'Demos',
);
const NO_SCAN = process.env.FNPANEL_NO_SCAN === '1' || process.argv.includes('--no-scan');
const SHOT_ARG = process.argv.find((arg) => arg.startsWith('--screenshot='));
const SHOT_VIEW = process.argv.find((arg) => arg.startsWith('--screenshot-view='));
// Mit Windows gestartet: im Hintergrund bleiben, nur das Crosshair ist da.
const START_HIDDEN = process.argv.includes('--hidden');

// Absturz-Diagnose: Chromium schreibt den CHECK-Text in diese Datei, bevor der
// Prozess abbricht. Ohne sie bleibt ein Absturz (wie beim Clip-Speichern) ein
// Rätsel, weil die gepackte App keine Konsole mehr hat.
try {
  app.commandLine.appendSwitch('enable-logging', 'file');
  app.commandLine.appendSwitch('log-file', path.join(app.getPath('userData'), 'crash.log'));
  crashReporter.start({ productName: 'Revolution Crosshair', uploadToServer: false, compress: false });
} catch {
  /* Diagnose darf den Start nie verhindern */
}

// Vollbild-Spiel: das Hub-Fenster ist verdeckt. Windows hält dann Timer und
// Canvas-Bilder an – die Aufnahme schrieb nur noch Ton und schwarze Bilder, und
// die Kill-Erkennung bekam gar keine Bilder mehr. Diese Schalter verhindern das
// Drosseln im Hintergrund.
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.commandLine.appendSwitch('disable-renderer-backgrounding');

let mainWindow = null;
let store = null;
let scanning = false;
// ext merkt sich das Aufnahmeformat: Auto-Clips schreibt der Hauptprozess.
let clipBuffer = { header: null, chunks: [], ext: 'webm' };
let registeredHotkey = null;
let scanTimer = null;
let overlayWindow = null;
let overlayTopTimer = null;
let displayTimer = null;
let xhPreviewUntil = 0;
let tray = null;
let quitting = false;
let registeredXhHotkeys = [];
let gameWatch = null;
let fortniteRunning = false;
let ocrNumbers = 0;
const damageLog = [];
let playerBook = null;
let summaryWindow = null;
let summaryData = null;
let liveKills = 0;
let liveSession = { seen: new Map(), startedAt: Date.now() };
// So lange gilt eine Feed-Zeile als „steht noch da“. Im Spiel verschwindet sie
// nach rund 10 s; die Reserve deckt verpasste Lesungen ab.
const FEED_LINE_TTL = 25000;
let lastFeedDiag = 0;

function storeFile() {
  return path.join(app.getPath('userData'), 'panel-data.json');
}

function migrateLegacyStore(target) {
  if (fs.existsSync(target)) return;
  const roaming = app.getPath('appData');
  for (const legacy of ['Revolution Tracker', 'Fortnite Panel', 'fortnite-panel']) {
    const candidate = path.join(roaming, legacy, 'panel-data.json');
    if (fs.existsSync(candidate)) {
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(candidate, target);
      console.log('Archiv übernommen von', candidate);
      return;
    }
  }
}

function parserCandidates() {
  return [
    app.isPackaged ? path.join(process.resourcesPath, 'parser', 'FnPanel.Parser.exe') : null,
    path.join(ROOT, 'parser', 'dist', 'FnPanel.Parser.exe'),
    path.join(ROOT, 'parser', 'FnPanel.Parser', 'bin', 'Release', 'net10.0', 'win-x64', 'FnPanel.Parser.exe'),
    path.join(ROOT, 'parser', 'FnPanel.Parser', 'bin', 'Release', 'net10.0', 'FnPanel.Parser.exe'),
  ].filter(Boolean);
}

function resolveParser() {
  const candidates = parserCandidates();
  return candidates.find((candidate) => fs.existsSync(candidate)) || candidates[0];
}

function replayDir() {
  const configured = store.settings.replayDir;
  return configured && fs.existsSync(configured) ? configured : DEFAULT_REPLAY_DIR;
}

function clipsDir() {
  const dir = path.join(app.getPath('userData'), 'clips');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/* ---------------- Clip-Dateien ----------------
 * Jeder Clip hat neben dem Video eine kleine JSON-Datei (gleicher Name +
 * „.json“) mit Kategorie, Gegnern und der Tasten-Zeitleiste. So lassen sich
 * Keystrokes nachträglich ein- und ausblenden, ohne das Video neu zu rechnen.
 * Optional liegt daneben ein Vorschaubild („.jpg“).
 */
const CLIP_VIDEO = /\.(mp4|webm)$/i;
const CLIP_CATEGORIES = ['win', 'kill', 'manual', 'recording'];
// Facecam-Spur eines Clips: <clip>.cam.webm / .cam.mp4 – zählt nicht als eigener Clip.
const CAM_FILE = /\.cam\.(mp4|webm)$/i;

function clipMetaPath(name) {
  return path.join(clipsDir(), name + '.json');
}

function clipThumbPath(name) {
  return path.join(clipsDir(), name + '.jpg');
}

/** Kategorie aus dem Dateinamen – für ältere Clips ohne JSON-Datei. */
function guessCategory(name) {
  const lower = String(name || '').toLowerCase();
  if (lower.startsWith('sieg') || lower.startsWith('win')) return 'win';
  if (lower.startsWith('kill')) return 'kill';
  if (lower.startsWith('aufnahme')) return 'recording';
  return 'manual';
}

function readClipMeta(name) {
  try {
    const parsed = JSON.parse(fs.readFileSync(clipMetaPath(name), 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeClipMeta(name, meta) {
  try {
    fs.writeFileSync(clipMetaPath(name), JSON.stringify(meta));
    return true;
  } catch (error) {
    console.log('[clip] Metadaten nicht geschrieben:', error.message);
    return false;
  }
}

function removeClipFiles(name) {
  const cam = readClipMeta(name).cam?.file;
  const extra = cam && CAM_FILE.test(cam) ? [path.join(clipsDir(), path.basename(cam))] : [];
  for (const file of [path.join(clipsDir(), name), clipMetaPath(name), clipThumbPath(name), ...extra]) {
    try {
      if (fs.existsSync(file)) fs.unlinkSync(file);
    } catch {
      /* einzelne Reste sind egal */
    }
  }
}

function safeClipName(name) {
  return typeof name === 'string' && CLIP_VIDEO.test(name) && path.basename(name) === name ? name : null;
}

function listClips() {
  try {
    const dir = clipsDir();
    const all = fs.readdirSync(dir);
    const names = new Set(all);
    return all
      .filter((name) => CLIP_VIDEO.test(name) && !CAM_FILE.test(name) && !/\.part\./i.test(name))
      .map((name) => {
        const full = path.join(dir, name);
        const stat = fs.statSync(full);
        const meta = names.has(name + '.json') ? readClipMeta(name) : {};
        const category = CLIP_CATEGORIES.includes(meta.category) ? meta.category : guessCategory(name);
        return {
          name,
          path: full,
          bytes: stat.size,
          mtime: Number(meta.createdAt) || stat.mtimeMs,
          category,
          title: typeof meta.title === 'string' ? meta.title : '',
          victims: Array.isArray(meta.victims) ? meta.victims.slice(0, 10) : [],
          kills: Number(meta.kills) || (category === 'kill' ? 1 : 0),
          hasKeys: Array.isArray(meta.keys) && meta.keys.length > 0,
          showKeys: meta.showKeys !== false,
          favorite: meta.favorite === true,
          thumb: names.has(name + '.jpg'),
          cam: Boolean(meta.cam?.file && names.has(meta.cam.file)),
        };
      })
      .sort((a, b) => b.mtime - a.mtime);
  } catch {
    return [];
  }
}

function clipUsage() {
  const clips = listClips();
  const bytes = clips.reduce((sum, clip) => sum + clip.bytes, 0);
  return { count: clips.length, bytes, maxBytes: Math.round(store.settings.clipMaxGb * 1024 ** 3) };
}

function pruneClips() {
  const maxBytes = Math.round(store.settings.clipMaxGb * 1024 ** 3);
  let clips = listClips();
  let total = clips.reduce((sum, clip) => sum + clip.bytes, 0);
  // Favoriten fliegen nie automatisch raus – nur die ältesten normalen Clips.
  // Lange Aufnahmen auch nicht: die löscht nur, wer sie selbst löscht.
  let candidates = clips.filter((clip) => !clip.favorite && clip.category !== 'recording');
  while (total > maxBytes && candidates.length > 1) {
    const oldest = candidates[candidates.length - 1];
    removeClipFiles(oldest.name);
    if (fs.existsSync(oldest.path)) break;
    total -= oldest.bytes;
    candidates = candidates.slice(0, -1);
  }
  return clipUsage();
}

function registerClipHotkey() {
  if (registeredHotkey) {
    globalShortcut.unregister(registeredHotkey);
    registeredHotkey = null;
  }
  // Der Clip-Hotkey hat einen eigenen Schalter: Er ist fürs Aufnehmen da
  // und standardmäßig an, unabhängig von den Crosshair-Kürzeln.
  if (!store || store.settings.clipHotkeyEnabled === false) return;
  const accelerator = store.settings.clipHotkey || 'F9';
  try {
    const onPress = () => {
      // Läuft der Puffer, schreibt der Hauptprozess direkt – ohne Umweg über
      // das Fenster, das im Spiel im Hintergrund hängt.
      if (bufferLive()) queueClip({ seconds: Number(store.settings.clipSeconds) || 30, category: 'manual' });
      else mainWindow?.webContents.send('clip:trigger', { label: 'clip' });
    };
    if (globalShortcut.register(accelerator, oncePerPress('clip', onPress, 600))) {
      registeredHotkey = accelerator;
    }
  } catch {
    registeredHotkey = null;
  }
}

function buildState() {
  const dir = replayDir();
  const parserPath = resolveParser();
  return {
    settings: {
      ...store.settings,
      replayDir: store.settings.replayDir || DEFAULT_REPLAY_DIR,
    },
    matches: store.data.matches,
    players: playerBook ? playerBook.all() : [],
    clips: listClips(),
    clipUsage: clipUsage(),
    meta: {
      replayDir: dir,
      replayDirExists: fs.existsSync(dir),
      replayCount: listReplayFiles(dir).length,
      parserReady: fs.existsSync(parserPath),
      parserPath,
      dataFile: store.file,
      clipsDir: clipsDir(),
      scanning,
      fortniteRunning,
      liveKills,
      playerCount: playerBook ? playerBook.count() : 0,
      hotkeyActive: registeredHotkey,
      appVersion: app.getVersion(),
      platform: process.platform,
    },
  };
}

async function runScan() {
  if (scanning) {
    return { started: false, reason: 'busy' };
  }

  const dir = replayDir();
  if (!fs.existsSync(dir)) {
    return { started: false, reason: 'missing-directory', dir };
  }

  const parserPath = resolveParser();
  if (!fs.existsSync(parserPath)) {
    return { started: false, reason: 'missing-parser', parserPath };
  }

  const before = new Set(store.data.matches.map((match) => match.file));
  scanning = true;
  mainWindow?.webContents.send('scan:progress', { phase: 'start', current: null });

  try {
    const summary = await scanDirectory({
      parserPath,
      dir,
      store,
      onProgress: (progress) => mainWindow?.webContents.send('scan:progress', progress),
    });

    // Sieg- und Kill-Clips entstehen live während der Runde (Kill-Feed und
    // „Victory Royale“ werden erkannt). Nach dem Scan läge im Puffer nur noch
    // die Lobby – deshalb wird hier kein Clip mehr geschrieben.

    const freshMatch = store.data.matches
      .filter((match) => !before.has(match.file) && (match.me?.kills || 0) > 0)
      .sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')))[0];
    if (freshMatch) enrichReplayCards(freshMatch);

    scanning = false;
    mainWindow?.webContents.send('scan:done', summary);
    return { started: true, summary };
  } catch (error) {
    scanning = false;
    mainWindow?.webContents.send('scan:done', { error: error.message, failed: [] });
    return { started: false, reason: 'error', error: error.message };
  }
}

function createWindow() {
  mainWindow = global.__revolutionHub.view("gaming", {
    width: 1240,
    height: 840,
    minWidth: 1000,
    minHeight: 640,
    show: false,
    frame: false,
    backgroundColor: '#08090d',
    autoHideMenuBar: true,
    title: 'Revolution Gaming Hub',
    icon: path.join(ROOT, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'crosshair-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false,
      // Statistik-Bereich liegt als Rahmen im Tab und braucht dort das Preload.
      nodeIntegrationInSubFrames: true,
    },
  });

  mainWindow.once('ready-to-show', () => {
    if (!START_HIDDEN) mainWindow.show();
  });
  mainWindow.loadFile(path.join(ROOT, 'renderer', 'crosshair.html'));

  // Das Crosshair gehört zum Hub: wandert das Fenster auf einen anderen Monitor,
  // wandert das Overlay mit (nur bei „Automatisch“).
  const followAppDisplay = () => {
    if (!store || xhConfig().displayId !== 'auto') return;
    positionOverlayOnGameDisplay();
    pushCrosshairConfig();
  };
  mainWindow.on('move', followAppDisplay);
  mainWindow.on('resize', followAppDisplay);

  if (SHOT_ARG) {
    mainWindow.webContents.once('did-finish-load', async () => {
      await new Promise((resolve) => setTimeout(resolve, 3500));
      const view = SHOT_VIEW ? SHOT_VIEW.split('=')[1] : null;
      if (view && /^[a-z]+$/.test(view)) {
        await mainWindow.webContents.executeJavaScript(
          view === 'crosshair'
            ? `(async () => {
                document.querySelector('[data-view="settings"]')?.click();
                await new Promise((resolve) => setTimeout(resolve, 700));
                document.getElementById('crosshair-card')?.scrollIntoView({ block: 'start' });
              })()`
            : view === 'match'
            ? `(async () => {
                document.querySelector('[data-view="history"]')?.click();
                await new Promise((resolve) => setTimeout(resolve, 700));
                document.querySelector('tr[data-match-file]')?.click();
                await new Promise((resolve) => setTimeout(resolve, 900));
                document.querySelector('.kills-table')?.scrollIntoView({ block: 'start' });
              })()`
            : `document.querySelector('[data-view="${view}"]')?.click()`,
        );
        await new Promise((resolve) => setTimeout(resolve, 1800));
      }
      try {
        const image = await mainWindow.webContents.capturePage();
        const target = path.resolve(SHOT_ARG.slice('--screenshot='.length));
        fs.mkdirSync(path.dirname(target), { recursive: true });
        fs.writeFileSync(target, image.toPNG());
        console.log('screenshot written:', target);
      } catch (error) {
        console.error('screenshot failed:', error.message);
      }
      app.quit();
    });
  }

  // Fenster schließen heißt: nur ausblenden. Das Crosshair läuft weiter.
  mainWindow.on('close', (event) => {
    if (!quitting && xhConfig().closeToTray) {
      event.preventDefault();
      mainWindow.hide();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

/* ---------------- Crosshair, Overlay, Tray ---------------- */

function xhConfig() {
  return normalizeApp(store?.settings?.xh);
}

function crosshairDir() {
  const dir = path.join(app.getPath('userData'), 'crosshairs');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function wallpaperDir() {
  return path.join(ROOT, 'assets', 'wallpapers');
}

function userWallpaperDir() {
  const dir = path.join(app.getPath('userData'), 'wallpapers');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

const WALLPAPER_EXT = /\.(mp4|webm|gif|png|jpe?g|webp)$/i;

function wallpaperLabel(name) {
  return name
    .replace(WALLPAPER_EXT, '')
    .replace(/^live-/, '')
    .replace(/[-_]+/g, ' ')
    .replace(/^\w/, (letter) => letter.toUpperCase());
}

/** Live-Hintergründe aus Revolution Browser plus eigene Dateien. */
function listWallpapers() {
  const read = (dir, source) => {
    try {
      return fs
        .readdirSync(dir)
        .filter((name) => WALLPAPER_EXT.test(name))
        .sort()
        .map((name) => {
          const poster = `${name.replace(WALLPAPER_EXT, '')}.jpg`;
          const hasPoster = fs.existsSync(path.join(dir, 'thumbs', poster));
          return {
            name,
            label: wallpaperLabel(name),
            source,
            poster: hasPoster ? `thumbs/${poster}` : '',
          };
        });
    } catch {
      return [];
    }
  };
  return [...read(wallpaperDir(), 'builtin'), ...read(userWallpaperDir(), 'custom')];
}

function currentProfile() {
  return activeProfile(xhConfig());
}

/** Das Rang-Crosshair nimmt Abzeichen, Farbe und Animation vom Rang des Modus. */
function displayProfile() {
  const config = xhConfig();
  const profile = currentProfile();
  if (!profile?.autoRank) return profile;
  const mode = config.rankMode || 'br';
  const rank = RANKS.find((entry) => entry.id === config.ranks?.[mode]);
  if (!rank) {
    // Noch kein Rang gesetzt: neutrales Abzeichen zeigen.
    return {
      ...profile,
      kind: 'image',
      image: 'ranks/unranked.png',
      blend: 'screen',
      imageScale: 0.45,
      outline: 0,
      animation: 'breathe',
    };
  }

  // Für Unreal gibt es kein eigenes Abzeichen – das Champion-Bild läuft im Regenbogen.
  const badge = rank.id === 'unreal' ? 'champion' : rank.id;
  return {
    ...profile,
    kind: 'image',
    image: `ranks/${badge}.png`,
    blend: 'screen',
    imageScale: 0.45,
    outline: 0,
    color: rank.color,
    animation: rank.id === 'unreal' ? 'rainbow' : rank.animation,
  };
}

/**
 * Bildschirm, auf dem das Crosshair sitzt: der gewählte, sonst der Monitor des
 * Hub-Fensters. Früher folgte es der Maus – beim Wegklicken sprang es dadurch
 * auf einen anderen Bildschirm.
 */
function targetDisplay() {
  const config = xhConfig();
  if (config.displayId && config.displayId !== 'auto') {
    const match = screen.getAllDisplays().find((display) => String(display.id) === config.displayId);
    if (match) return match;
  }
  // „Automatisch“ = immer der Hauptbildschirm (dort läuft das Spiel); die Island sitzt auf dem zweiten.
  return screen.getPrimaryDisplay();
}

/** Crosshair sichtbar? Nur im Spiel, dauerhaft oder kurz zur Vorschau. */
function crosshairVisible() {
  const config = xhConfig();
  if (!config.enabled) return false;
  if (Date.now() < xhPreviewUntil) return true;
  // Per F8 eingeschaltet heißt: dauerhaft sichtbar, auch ohne laufendes Spiel.
  if (config.alwaysOn) return true;
  return !config.onlyInGame || fortniteRunning;
}

function pushCrosshairConfig() {
  if (!overlayWindow || overlayWindow.isDestroyed() || overlayWindow.webContents.isLoading()) return;
  const config = xhConfig();
  const display = targetDisplay();
  const height = display?.bounds?.height || 1080;
  overlayWindow.webContents.send('xh:config', {
    profile: displayProfile(),
    scale: config.scale * (height / 1080),
    offsetX: config.offsetX,
    offsetY: config.offsetY,
    visible: crosshairVisible(),
  });
}

/** Overlay auf den Bildschirm legen, auf dem gerade gespielt wird. */
function positionOverlayOnGameDisplay() {
  if (!overlayWindow || overlayWindow.isDestroyed()) return;
  const bounds = targetDisplay().bounds;
  const current = overlayWindow.getBounds();
  if (
    current.x !== bounds.x ||
    current.y !== bounds.y ||
    current.width !== bounds.width ||
    current.height !== bounds.height
  ) {
    overlayWindow.setBounds(bounds);
  }
}

function refreshOverlayVisibility() {
  if (!overlayWindow || overlayWindow.isDestroyed()) return;
  positionOverlayOnGameDisplay();
  // Aufnahmen (Medal, OBS, eigene Clips) sollen das Crosshair mitfilmen.
  try {
    overlayWindow.setContentProtection(!xhConfig().captureVisible);
  } catch {
    /* ältere Windows-Versionen kennen das nicht */
  }
  pushCrosshairConfig();
  if (crosshairVisible()) {
    if (!overlayWindow.isVisible()) overlayWindow.showInactive();
    overlayWindow.setAlwaysOnTop(true, 'screen-saver');
  } else if (overlayWindow.isVisible()) {
    overlayWindow.hide();
  }
}

function xhState() {
  const config = xhConfig();
  return {
    app: config,
    meta: {
      version: app.getVersion(),
      fortniteRunning,
      displays: screen.getAllDisplays().map((display) => ({
        id: String(display.id),
        label: display.label || `Bildschirm ${display.id}`,
        width: display.bounds.width,
        height: display.bounds.height,
        primary: display.id === screen.getPrimaryDisplay().id,
      })),
      matches: store?.data.matches?.length || 0,
      lastMatch: store?.data.matches?.[0]?.date || null,
      players: playerBook ? playerBook.count() : 0,
      scanning,
      hotkeysActive: registeredXhHotkeys.slice(),
      xhDir: crosshairDir(),
      wallpapers: listWallpapers(),
      rank: {
        lastDetection: lastRankDetection,
      },
      clip: {
        settings: {
          clipSeconds: store.settings.clipSeconds,
          clipMaxGb: store.settings.clipMaxGb,
          clipHotkey: store.settings.clipHotkey,
          clipHotkeyEnabled: store.settings.clipHotkeyEnabled !== false,
          clipSourceId: store.settings.clipSourceId,
          clipAutoStart: store.settings.clipAutoStart,
          clipAutoSave: store.settings.clipAutoSave,
          clipFps: store.settings.clipFps,
          clipQuality: store.settings.clipQuality,
          clipOnKill: store.settings.clipOnKill,
          clipOnWin: store.settings.clipOnWin,
          clipAutoGame: store.settings.clipAutoGame,
          clipBurnCrosshair: store.settings.clipBurnCrosshair,
          clipKeystrokes: store.settings.clipKeystrokes,
          clipKeystrokesController: store.settings.clipKeystrokesController,
          clipAudio: store.settings.clipAudio !== false,
          clipKillSeconds: Number(store.settings.clipKillSeconds) || 15,
          clipKillPost: Number.isFinite(Number(store.settings.clipKillPost)) ? Number(store.settings.clipKillPost) : 2,
          clipMic: Boolean(store.settings.clipMic),
          clipMicId: store.settings.clipMicId || '',
          clipMicVolume: Number(store.settings.clipMicVolume ?? 100),
          clipSystemVolume: Number(store.settings.clipSystemVolume ?? 100),
          clipKeysShow: store.settings.clipKeysShow !== false,
          camEnabled: store.settings.camEnabled === true,
          camDeviceId: store.settings.camDeviceId || '',
          recHotkey: store.settings.recHotkey || 'F10',
          displayName: store.settings.displayName || '',
          killFeed: store.settings.killFeed !== false,
        },
        ownNames: ownNames(),
        clips: listClips(),
        usage: clipUsage(),
        dir: clipsDir(),
      },
    },
  };
}

function saveXhConfig(next) {
  store.data.settings.xh = normalizeApp(next);
  store.flush();
  applyAutoStart(store.data.settings.xh);
  registerXhHotkeys();
  registerClipHotkey();
  applyFocusMode(store.data.settings.xh);
  updateTrayMenu();
  refreshOverlayVisibility();
  mainWindow?.webContents.send('xh:state', xhState());
  return xhState();
}

function toggleCrosshair(force) {
  const config = xhConfig();
  const enabled = typeof force === 'boolean' ? force : !config.enabled;
  xhPreviewUntil = 0;
  return saveXhConfig({ ...config, enabled, alwaysOn: enabled });
}

function cycleProfile() {
  const config = xhConfig();
  const list = config.profiles;
  if (list.length < 2) return xhState();
  const index = list.findIndex((profile) => profile.id === config.activeId);
  const next = list[(index + 1) % list.length];
  return saveXhConfig({ ...config, activeId: next.id });
}

function nudgeScale(delta) {
  const config = xhConfig();
  return saveXhConfig({ ...config, scale: Math.round((config.scale + delta) * 10) / 10 });
}

function writeMusicSettings(next) {
  // Ziehen ist zu Ende: ab jetzt gilt die gespeicherte Position.
  musicPreviewPos = null;
  const x = Number(next.x);
  const y = Number(next.y);
  const scale = Number(next.scale);
  store.data.settings.music = {
    enabled: next.enabled !== false,
    preset: MUSIC_PRESETS.includes(next.preset) ? next.preset : 'tc',
    presetDefault: true,
    edgeDefault: true,
    x: Number.isFinite(x) ? Math.round(x) : null,
    y: Number.isFinite(y) ? Math.round(y) : null,
    scale: Number.isFinite(scale) ? Math.min(2, Math.max(0.6, Math.round(scale * 100) / 100)) : 0.8,
    lyrics: next.lyrics !== false,
    title: next.title !== false,
    progress: next.progress !== false,
    vinylOnly: next.vinylOnly === true,
    vinyl: next.vinyl === true || next.vinylOnly === true,
    // Tonarm über der Platte (wandert mit dem Song) und Platten-Knistern.
    arm: next.arm !== false,
    crackle: next.crackle === true,
    crackleVolume: Number.isFinite(Number(next.crackleVolume))
      ? Math.min(100, Math.max(0, Math.round(Number(next.crackleVolume))))
      : 40,
    // Merker, damit die Einmal-Umstellung auf 80 % nicht erneut zuschlägt.
    scaleDefault: true,
  };
  store.flush();
  refreshMusicOverlay();
  if (store.settings.music.enabled) startMediaWatcher();
  else stopMediaWatcher();
  return { settings: musicConfig(), state: musicData };
}

function toggleMusicOverlay(force) {
  const config = musicConfig();
  const enabled = typeof force === 'boolean' ? force : !config.enabled;
  const info = writeMusicSettings({ ...config, enabled });
  mainWindow?.webContents.send('music:state', info);
  return info;
}

/* ---------------- Performance-Overlay ---------------- */

const PERF_MARGIN = 4;
let perfWindow = null;
let perfData = null;
let perfStarted = false;
let focusActive = false;
let focusRegistryApplied = false;
let screenTimeTimer = null;

function perfConfig() {
  return normalizePerf(store?.settings?.perf);
}

function perfRows() {
  const config = perfConfig();
  const rows = [];
  if (config.fps) rows.push('fps');
  if (config.cpu) rows.push('cpu');
  if (config.gpu) rows.push('gpu');
  if (config.ram) rows.push('ram');
  if (config.ping) rows.push('ping');
  return rows;
}

function perfWindowSize() {
  const config = perfConfig();
  const rows = perfRows();
  const others = rows.filter((key) => key !== 'fps').length;
  // Genau wie im Stylesheet: 12 px Polster oben und unten, 66 px FPS-Zeile,
  // 44 px pro Wert, 8 px Abstand dazwischen, dazu Rand und etwas Reserve –
  // sonst schneidet die Karte unten ab.
  const gaps = Math.max(0, rows.length - 1) * 8;
  const height = 24 + 2 + (config.fps ? 66 : 0) + others * 44 + gaps + 6;
  return {
    width: Math.round(300 * config.scale),
    height: Math.round(height * config.scale),
  };
}

/** Abdunklung des Live-Hintergrunds (Prozent) für alle Overlays. */
function wallShade() {
  const value = Number(store?.settings?.xh?.wallShade);
  if (!Number.isFinite(value)) return 80;
  return Math.min(100, Math.max(0, Math.round(value)));
}

/**
 * Werte fürs Overlay. FPS kommt aus der Bildwiederholrate des Monitors –
 * Windows gibt die Bildrate eines Spiels ohne Eingriff ins Spiel nicht heraus.
 */
function perfPayload() {
  const config = perfConfig();
  const data = perfData || {};
  const display = targetDisplay();
  const fps = Math.round(Number(display?.displayFrequency) || 60) || 60;
  const ping = Number(data.ping);
  const temp = Number(data.temp);
  const name = store?.settings?.xh?.wallpaper;
  return {
    fps,
    ms: Math.round((1000 / Math.max(1, fps)) * 10) / 10,
    cpu: Math.round(Number(data.cpu) || 0),
    gpu: Math.round(Number(data.gpu) || 0),
    ram: Math.round((Number(data.ram) || 0) * 10) / 10,
    ramTotal: Math.round((Number(data.ramTotal) || 0) * 10) / 10,
    temp: Number.isFinite(temp) && temp > 5 ? Math.round(temp) : null,
    ping: Number.isFinite(ping) && ping > 0 ? Math.round(ping) : null,
    rows: perfRows(),
    scale: config.scale,
    shade: wallShade(),
    wall: typeof name === 'string' && name ? `wall://media/${encodeURIComponent(name)}` : '',
  };
}

function createPerfOverlay() {
  if (perfWindow && !perfWindow.isDestroyed()) return perfWindow;
  const size = perfWindowSize();
  perfWindow = new BrowserWindow({
    width: size.width,
    height: size.height,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'perf-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false,
    },
  });
  perfWindow.setAlwaysOnTop(true, 'screen-saver');
  perfWindow.setIgnoreMouseEvents(true, { forward: false });
  perfWindow.loadFile(path.join(ROOT, 'renderer', 'perf-overlay.html'));
  perfWindow.on('closed', () => {
    perfWindow = null;
  });
  return perfWindow;
}

function applyPerfBounds(win, config) {
  const area = screen.getPrimaryDisplay().workArea;
  const size = perfWindowSize();
  const spot = (preset) => {
    const row = preset === 'free' ? 't' : preset[0];
    const col = preset === 'free' ? 'r' : preset[1];
    const x =
      col === 'l'
        ? area.x + PERF_MARGIN
        : col === 'r'
          ? area.x + area.width - size.width - PERF_MARGIN
          : Math.round(area.x + (area.width - size.width) / 2);
    const y =
      row === 't'
        ? area.y + PERF_MARGIN
        : row === 'b'
          ? area.y + area.height - size.height - PERF_MARGIN
          : Math.round(area.y + (area.height - size.height) / 2);
    return { x, y };
  };
  const free =
    config.preset === 'free' && config.x !== null
      ? { x: config.x, y: config.y === null ? PERF_MARGIN : config.y }
      : null;
  const target = free
    ? { x: area.x + free.x, y: area.y + free.y }
    : spot(config.preset === 'free' ? 'tr' : config.preset);
  win.setBounds({
    x: Math.min(Math.max(target.x, area.x), area.x + area.width - size.width),
    y: Math.min(Math.max(target.y, area.y), area.y + area.height - size.height),
    width: size.width,
    height: size.height,
  });
}

function pushPerfState() {
  if (!perfWindow || perfWindow.isDestroyed()) return;
  const payload = perfPayload();
  const send = () => {
    if (perfWindow && !perfWindow.isDestroyed()) perfWindow.webContents.send('perf:update', payload);
  };
  if (perfWindow.webContents.isLoading()) perfWindow.webContents.once('did-finish-load', send);
  else send();
}

function refreshPerfOverlay() {
  const config = perfConfig();
  if (!config.enabled) {
    if (perfWindow && !perfWindow.isDestroyed()) perfWindow.hide();
    return;
  }
  const win = createPerfOverlay();
  applyPerfBounds(win, config);
  pushPerfState();
  if (!win.isVisible()) win.showInactive();
}

function handlePerfUpdate(payload) {
  if (!payload || payload.stopped) return;
  perfData = { ...(perfData || {}), ...payload };
  pushPerfState();
  mainWindow?.webContents.send('perf:state', { settings: perfConfig(), data: perfPayload() });
}

function startPerfWatcher() {
  if (perfStarted) return;
  perfStarted = perf.start(handlePerfUpdate);
  if (!perfStarted) console.log('[perf] PowerShell-Helfer fehlt');
}

function stopPerfWatcher() {
  if (!perfStarted) return;
  perf.stop();
  perfStarted = false;
}

function initPerf() {
  if (!perfConfig().enabled) return;
  createPerfOverlay();
  refreshPerfOverlay();
  startPerfWatcher();
}

/* ---------------- Fokus-Modus ---------------- */

/**
 * Fokus-Modus: keine eigenen Hinweise und keine Windows-Benachrichtigungen.
 * Der Windows-Schalter wird beim Ausschalten und beim Beenden zurückgesetzt.
 */
function setFocusNotifications(enabled) {
  if (!enabled && !focusRegistryApplied) return;
  focusRegistryApplied = enabled;
  try {
    execFile(
      'reg',
      [
        'add',
        'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings',
        '/v',
        'NOC_GLOBAL_SETTING_TOASTS_ENABLED',
        '/t',
        'REG_DWORD',
        '/d',
        enabled ? '0' : '1',
        '/f',
      ],
      { windowsHide: true },
      () => {},
    );
  } catch {
    /* Registry ist optional */
  }
}

function applyFocusMode(config) {
  const on = config?.focusMode === true;
  if (on === focusActive) return;
  focusActive = on;
  setFocusNotifications(on);
  mainWindow?.webContents.send('focus:state', { active: on });
}

/* ---------------- Bildschirmzeit & Notizen ---------------- */

function dayKey(date = new Date()) {
  // sv-SE liefert genau YYYY-MM-DD und ist damit ein stabiler Schlüssel.
  return date.toLocaleDateString('sv-SE');
}

function bumpScreenTime() {
  if (!store) return;
  const settings = store.data.settings;
  const key = dayKey();
  if (!settings.screentime || typeof settings.screentime !== 'object') settings.screentime = {};
  if (!settings.screentimeGame || typeof settings.screentimeGame !== 'object') settings.screentimeGame = {};
  settings.screentime[key] = Math.round((Number(settings.screentime[key]) || 0) + 30);
  if (fortniteRunning) {
    settings.screentimeGame[key] = Math.round((Number(settings.screentimeGame[key]) || 0) + 30);
  }
  store.save();
}

function startScreenTime() {
  clearInterval(screenTimeTimer);
  screenTimeTimer = setInterval(bumpScreenTime, 30000);
}

function screenTimeSummary() {
  const settings = store?.data?.settings || {};
  const total = settings.screentime || {};
  const game = settings.screentimeGame || {};
  const readDay = (date) => {
    const key = dayKey(date);
    return {
      key,
      seconds: Math.round(Number(total[key]) || 0),
      game: Math.round(Number(game[key]) || 0),
    };
  };

  const days = [];
  let week = 0;
  let weekGame = 0;
  for (let offset = 6; offset >= 0; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    const entry = readDay(date);
    week += entry.seconds;
    weekGame += entry.game;
    days.push(entry);
  }

  // Zweite Woche dazu: die Seite zeigt mehr als nur sieben Balken.
  const history = [];
  for (let offset = 13; offset >= 7; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    history.push(readDay(date));
  }

  let allTime = 0;
  let trackedDays = 0;
  let best = null;
  for (const [key, value] of Object.entries(total)) {
    const seconds = Math.round(Number(value) || 0);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(key) || seconds <= 0) continue;
    allTime += seconds;
    trackedDays += 1;
    if (!best || seconds > best.seconds) {
      best = { key, seconds, game: Math.round(Number(game[key]) || 0) };
    }
  }

  const today = days[days.length - 1] || { key: dayKey(), seconds: 0, game: 0 };
  return {
    today: today.seconds,
    todayGame: today.game,
    week,
    weekGame,
    days,
    history,
    average: Math.round(week / 7),
    allTime,
    trackedDays,
    best,
  };
}

function applyAutoStart(config) {
  // In der Entwicklung würde sonst Electron selbst als Autostart landen.
  if (!app.isPackaged) return;
  try {
    const exe = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
    app.setLoginItemSettings({
      openAtLogin: Boolean(config.autoStart),
      path: exe,
      // Beim Login im Hintergrund starten: Das Crosshair ist sofort da,
      // das Fenster bleibt im Tray.
      args: ['--hidden'],
    });
  } catch {
    /* Autostart ist optional */
  }
}

function createTray() {
  if (tray) return tray;
  const iconPath = path.join(ROOT, 'renderer', 'assets', 'tray.png');
  let image = nativeImage.createFromPath(iconPath);
  if (image.isEmpty()) image = nativeImage.createFromPath(path.join(ROOT, 'build', 'icon.png'));
  tray = new Tray(image.resize({ width: 16, height: 16 }));
  tray.setToolTip('Revolution Gaming Hub');
  tray.on('click', () => showMainWindow());
  updateTrayMenu();
  return tray;
}

function updateTrayMenu() {
  if (!tray || tray.isDestroyed()) return;
  const config = xhConfig();
  const profile = currentProfile();
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: 'Revolution Gaming Hub', enabled: false },
      { type: 'separator' },
      {
        label: 'Crosshair anzeigen',
        type: 'checkbox',
        checked: config.enabled,
        click: () => toggleCrosshair(),
      },
      { label: `Design: ${profile.name}`, enabled: false },
      { label: 'Nächstes Design', click: () => cycleProfile() },
      { type: 'separator' },
      { label: 'Fenster öffnen', click: () => showMainWindow() },
      {
        label: 'Statistiken',
        click: () => {
          showMainWindow();
          mainWindow?.webContents.send('xh:view', 'stats');
        },
      },
      { type: 'separator' },
      {
        label: 'Beenden',
        click: () => {
          quitting = true;
          app.quit();
        },
      },
    ]),
  );
}

function showMainWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow();
    return;
  }
  if (!mainWindow.isVisible()) mainWindow.show();
  mainWindow.focus();
}

/* ---------------- Clip-Haken und Clipper-Karte ---------------- */

let checkWindow = null;
let checkHideTimer = null;

/** Monitor, auf dem das Spiel (bzw. das Crosshair-Overlay) liegt. */
function gameDisplay() {
  try {
    if (overlayWindow && !overlayWindow.isDestroyed()) {
      return screen.getDisplayMatching(overlayWindow.getBounds());
    }
  } catch {
    /* Rückfall unten */
  }
  return screen.getPrimaryDisplay();
}

/**
 * Kleiner grüner Haken unten links – erscheint erst, wenn der Clip wirklich
 * auf der Platte liegt. Kein Text, keine Karte, nichts zum Wegklicken.
 */
function flashClipCheck() {
  // Fokus-Modus: keine kurzen Einblendungen mitten im Spiel.
  if (focusActive) return;
  try {
    // Unten links, knapp über dem Rand.
    const area = gameDisplay().bounds;
    const bounds = { x: area.x + 18, y: area.y + area.height - 34 - 18, width: 34, height: 34 };
    if (!checkWindow || checkWindow.isDestroyed()) {
      checkWindow = new BrowserWindow({
        ...bounds,
        frame: false,
        transparent: true,
        resizable: false,
        movable: false,
        minimizable: false,
        maximizable: false,
        fullscreenable: false,
        skipTaskbar: true,
        focusable: false,
        hasShadow: false,
        show: false,
        backgroundColor: '#00000000',
        webPreferences: {
          preload: path.join(__dirname, 'check-preload.js'),
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: false,
          backgroundThrottling: false,
        },
      });
      checkWindow.setAlwaysOnTop(true, 'screen-saver');
      checkWindow.setIgnoreMouseEvents(true, { forward: false });
      // Der Haken soll nicht im nächsten Clip landen.
      try {
        checkWindow.setContentProtection(true);
      } catch {
        /* ältere Windows-Versionen */
      }
      checkWindow.loadFile(path.join(ROOT, 'renderer', 'clip-check.html'));
      checkWindow.on('closed', () => {
        checkWindow = null;
      });
    } else {
      checkWindow.setBounds(bounds);
    }
    const win = checkWindow;
    if (win.webContents.isLoading()) {
      win.webContents.once('did-finish-load', () => win.webContents.send('check:flash'));
    } else {
      win.webContents.send('check:flash');
    }
    win.showInactive();
    win.setAlwaysOnTop(true, 'screen-saver');
    clearTimeout(checkHideTimer);
    checkHideTimer = setTimeout(() => {
      if (checkWindow && !checkWindow.isDestroyed()) checkWindow.hide();
    }, 1300);
  } catch (error) {
    console.log('[clip] Haken fehlgeschlagen:', error.message);
  }
}

let clipperWindow = null;
let clipperMessageTimer = null;
let clipperHideTimer = null;
let aiming = false;
let clipSessionCount = 0;
let rankTimer = null;
let lastRankCheck = 0;
let lastRankDetection = null;

function createClipperOverlay() {
  if (clipperWindow && !clipperWindow.isDestroyed()) return clipperWindow;
  const display = screen.getPrimaryDisplay();
  clipperWindow = new BrowserWindow({
    x: display.workArea.x + 18,
    y: display.workArea.y + 16,
    width: 300,
    height: 86,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'clipper-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false,
    },
  });
  clipperWindow.setAlwaysOnTop(true, 'screen-saver');
  clipperWindow.setIgnoreMouseEvents(true, { forward: false });
  clipperWindow.loadFile(path.join(ROOT, 'renderer', 'clipper-overlay.html'));
  clipperWindow.on('closed', () => {
    clipperWindow = null;
  });
  return clipperWindow;
}

function clipperState(message = '') {
  return {
    active: fortniteRunning,
    hotkey: registeredHotkey || '',
    clips: clipSessionCount,
    message,
    wallpaper: xhConfig().wallpaper || '',
  };
}

/** Karte nach einer Weile wieder ausblenden – sie soll nur kurz aufploppen. */
function scheduleClipperHide(ms) {
  clearTimeout(clipperHideTimer);
  if (!ms) return;
  clipperHideTimer = setTimeout(() => {
    if (clipperWindow && !clipperWindow.isDestroyed() && clipperWindow.isVisible()) {
      clipperWindow.hide();
    }
  }, ms);
}

let lastKeys = [];

/*
 * Tasten-Zeitleiste für Clips: jede Änderung mit Zeitstempel. Beim Speichern
 * wird der passende Ausschnitt neben den Clip gelegt – so lassen sich die
 * Keystrokes im Player nachträglich ein- und ausblenden.
 */
const keyTimeline = [];

function recordKeys(keys, at) {
  keyTimeline.push({ t: at, k: keys.slice(0, 24) });
  const cutoff = Date.now() - bufferWindowMs() - 10000;
  while (keyTimeline.length > 1 && keyTimeline[1].t < cutoff) keyTimeline.shift();
  if (keyTimeline.length > 20000) keyTimeline.splice(0, keyTimeline.length - 20000);
}

/** Ausschnitt [from, to] als Liste mit Versatz in ms ab `from`. */
function keysBetween(from, to) {
  const out = [];
  let before = null;
  for (const entry of keyTimeline) {
    if (entry.t < from) {
      before = entry;
      continue;
    }
    if (entry.t > to) break;
    out.push({ o: Math.round(entry.t - from), k: entry.k });
  }
  if (before && before.k.length > 0) out.unshift({ o: 0, k: before.k });
  return out;
}

function handleInputState(payload) {
  const keys = Array.isArray(payload?.keys) ? payload.keys : [];

  // Waffen-Hotkeys: 1–5 schalten das Crosshair um (z. B. pro Waffe eins).
  for (const key of keys) {
    if (lastKeys.includes(key) || !/^[1-5]$/.test(key)) continue;
    const config = xhConfig();
    const target = config.weaponHotkeys?.[key];
    if (target && target !== config.activeId) {
      const exists = (config.profiles || []).some((profile) => profile.id === target);
      if (exists) saveXhConfig({ ...config, activeId: target });
    }
  }
  lastKeys = keys;
  chests?.feedKeys(keys);
  recordKeys(keys, Number(payload?.at) || Date.now());

  aiming = keys.includes('M2');
  mainWindow?.webContents.send('input:state', payload);
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.webContents.send('xh:aim', { aiming });
  }
}

function pushClipperState(message = '') {
  const win = createClipperOverlay();
  if (!win || win.isDestroyed()) return;
  const payload = clipperState(message);
  if (win.webContents.isLoading()) win.webContents.once('did-finish-load', () => win.webContents.send('clipper:state', payload));
  else win.webContents.send('clipper:state', payload);
}

function showClipperMessage(message, ms = 6000) {
  if (!fortniteRunning || focusActive) return;
  pushClipperState(message);
  const win = createClipperOverlay();
  if (win && !win.isDestroyed() && !win.isVisible()) win.showInactive();
  scheduleClipperHide(ms + 400);
  clearTimeout(clipperMessageTimer);
  clipperMessageTimer = setTimeout(() => {
    if (!clipperWindow || clipperWindow.isDestroyed()) return;
    pushClipperState('');
  }, ms);
}

function updateClipperOverlay() {
  // Früher ploppte hier beim Spielstart und bei jeder Einstellungsänderung
  // eine Karte auf. Clips melden sich jetzt nur noch mit dem kleinen Haken;
  // die Karte bleibt für seltene Hinweise (z. B. Rang erkannt).
  if (!fortniteRunning) {
    clearTimeout(clipperMessageTimer);
    if (clipperWindow && !clipperWindow.isDestroyed() && clipperWindow.isVisible()) clipperWindow.hide();
  }
}

/* ---------------- Rang automatisch aus der Lobby lesen ---------------- */

const RANK_WORDS = [
  ['unreal', /\bunreal\b/i],
  ['champion', /\bchampion\b/i],
  ['elite', /\belite\b/i],
  ['diamond', /\b(diamond|diamant)\b/i],
  ['platinum', /\b(platinum|platin)\b/i],
  ['gold', /\bgold\b/i],
  ['silver', /\b(silver|silber)\b/i],
  ['bronze', /\bbronze\b/i],
];

const MODE_WORDS = [
  ['zeroBuild', /(zero\s*build|null\s*bau)/i],
  ['reload', /\breload\b/i],
];

const LOBBY_WORDS = /(lobby|bereit|ready|spielen|play|matchmaking|spielmodus)/i;

async function gameThumbnail() {
  try {
    // Fenster-Thumbnails von Vollbild-Spielen sind oft schwarz – der Monitor liefert
    // immer echte Bilder, deshalb zuerst den Bildschirm der Spiele-Anzeige nehmen.
    const display = screen.getPrimaryDisplay();
    const sources = await desktopCapturer.getSources({
      types: ['screen', 'window'],
      thumbnailSize: {
        width: Math.round(display.size.width * display.scaleFactor),
        height: Math.round(display.size.height * display.scaleFactor),
      },
    });
    const onDisplay = sources.find(
      (entry) => entry.id.startsWith('screen') && String(entry.display_id) === String(display.id),
    );
    const source =
      (onDisplay && !onDisplay.thumbnail.isEmpty() ? onDisplay : null) ||
      sources.find((entry) => entry.id.startsWith('screen') && !entry.thumbnail.isEmpty()) ||
      sources.find((entry) => /fortnite/i.test(entry.name) && !entry.thumbnail.isEmpty());
    if (!source) return null;
    return source.thumbnail.toPNG();
  } catch (error) {
    console.log('[rank] Bildschirmfoto fehlgeschlagen:', error.message);
    return null;
  }
}

async function detectRank() {
  const config = xhConfig();
  if (!config.rankAuto || !fortniteRunning || scanning) return;
  const now = Date.now();
  if (now - lastRankCheck < 12000) return;
  lastRankCheck = now;

  const png = await gameThumbnail();
  if (!png) return;
  const text = await ocr.readScreenText(png);
  if (!text || text.trim().length < 4) return;

  // Der Rang steht nur in der Lobby. Nach dem Verlassen einer Runde liest OCR
  // sonst irgendeinen UI-Text und meldet Unsinn wie „Unreal“.
  if (!LOBBY_WORDS.test(text)) {
    console.log('[rank] keine Lobby – Rang bleibt unverändert');
    return;
  }

  const modeHit = MODE_WORDS.find(([, pattern]) => pattern.test(text));
  // In der Lobby steht immer nur der Rang des gerade gewählten Modus. Damit alle
  // Modi gefüllt sind, gilt ein erkannter Rang automatisch für BR, Null Bauen und Reload.
  const modes = MODES.map((entry) => entry.id);
  const rankHit = RANK_WORDS.find(([, pattern]) => pattern.test(text));

  if (rankHit) {
    const changed = modes.some((id) => config.ranks[id] !== rankHit[0]);
    if (changed) {
      const rank = RANKS.find((entry) => entry.id === rankHit[0]);
      const ranks = { ...config.ranks };
      for (const id of modes) ranks[id] = rankHit[0];
      lastRankDetection = { rank: rankHit[0], modes, at: Date.now() };
      saveXhConfig({ ...config, ranks });
      const labels = modes
        .map((id) => MODES.find((entry) => entry.id === id)?.name || id)
        .join(', ');
      console.log('[rank]', rankHit[0], labels);
      showClipperMessage(`Rang erkannt: ${rank ? rank.name : rankHit[0]} · ${labels}`, 7000);
      mainWindow?.webContents.send('rank:detected', {
        mode: modeHit ? modeHit[0] : 'all',
        modes,
        rank: rankHit[0],
      });
    }
  }

  if (!rankHit) console.log('[rank] kein Rang im Lobby-Bild erkannt');
}

let registeredHotkeySignature = '';
const hotkeyCooldown = new Map();

/**
 * GlobalShortcut feuert beim Halten der Taste immer wieder und eine neue
 * Registrierung löst sofort erneut aus – ohne Sperre schaltet F8 im Dauerlauf.
 */
function oncePerPress(key, action, gapMs = 300) {
  return () => {
    const now = Date.now();
    if (now - (hotkeyCooldown.get(key) || 0) < gapMs) return;
    hotkeyCooldown.set(key, now);
    action();
  };
}

function registerXhHotkeys() {
  const config = xhConfig();
  const signature = JSON.stringify({ hotkeys: config.hotkeys, enabled: config.hotkeysEnabled });
  if (signature === registeredHotkeySignature) return;

  for (const accelerator of registeredXhHotkeys) {
    try {
      globalShortcut.unregister(accelerator);
    } catch {
      /* egal */
    }
  }
  registeredXhHotkeys = [];
  registeredHotkeySignature = signature;
  if (!config.hotkeysEnabled) return;

  const actions = {
    toggle: oncePerPress('toggle', () => toggleCrosshair(), 600),
    cycle: oncePerPress('cycle', () => cycleProfile(), 300),
    bigger: oncePerPress('bigger', () => nudgeScale(0.1), 180),
    smaller: oncePerPress('smaller', () => nudgeScale(-0.1), 180),
    music: oncePerPress('music', () => toggleMusicOverlay(), 300),
  };

  for (const [key, action] of Object.entries(actions)) {
    const accelerator = config.hotkeys[key];
    if (!accelerator) continue;
    try {
      if (globalShortcut.register(accelerator, action)) registeredXhHotkeys.push(accelerator);
    } catch {
      /* ungültige Kombination ignorieren */
    }
  }
}

/* ---------------- IPC: Crosshair ---------------- */

ipcMain.handle('xh:get', () => xhState());

ipcMain.on('xh:overlayReady', () => {
  pushCrosshairConfig();
  refreshOverlayVisibility();
});

ipcMain.on('xh:overlayHide', () => refreshOverlayVisibility());

ipcMain.handle('xh:save', (_event, patch) => saveXhConfig({ ...xhConfig(), ...(patch || {}) }));

ipcMain.handle('xh:setActive', (_event, id) => saveXhConfig({ ...xhConfig(), activeId: String(id || '') }));

ipcMain.handle('xh:toggle', () => toggleCrosshair());

ipcMain.handle('xh:preview', (_event, ms) => {
  const config = xhConfig();
  xhPreviewUntil = Date.now() + Math.min(20000, Math.max(1000, Number(ms) || 6000));
  if (!config.enabled) saveXhConfig({ ...config, enabled: true });
  refreshOverlayVisibility();
  setTimeout(() => {
    xhPreviewUntil = 0;
    refreshOverlayVisibility();
  }, Math.min(20000, Math.max(1000, Number(ms) || 6000)) + 100);
  return true;
});

ipcMain.handle('xh:addProfile', (_event, profile) => {
  const config = xhConfig();
  const created = normalizeProfile({ ...(profile || {}), id: newId('p'), builtin: false });
  config.profiles.push(created);
  config.activeId = created.id;
  return saveXhConfig(config);
});

ipcMain.handle('xh:updateProfile', (_event, profile) => {
  const config = xhConfig();
  const index = config.profiles.findIndex((entry) => entry.id === profile?.id);
  if (index < 0) return xhState();
  config.profiles[index] = normalizeProfile({ ...config.profiles[index], ...profile });
  return saveXhConfig(config);
});

ipcMain.handle('xh:deleteProfile', (_event, id) => {
  const config = xhConfig();
  const profile = config.profiles.find((entry) => entry.id === id);
  if (!profile || profile.builtin) return xhState();
  config.profiles = config.profiles.filter((entry) => entry.id !== id);
  if (config.activeId === id) config.activeId = config.profiles[0]?.id || 'classic';
  const stillUsed = config.profiles.some((entry) => entry.image === profile.image);
  if (profile.image && !stillUsed) {
    config.customImages = config.customImages.filter((image) => image.file !== profile.image);
    try {
      fs.unlinkSync(path.join(crosshairDir(), path.basename(profile.image)));
    } catch {
      /* Datei darf fehlen */
    }
  }
  return saveXhConfig(config);
});

ipcMain.handle('xh:pickImage', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Crosshair-Bild oder GIF wählen',
    properties: ['openFile'],
    filters: [{ name: 'Bilder & GIFs', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'] }],
  });
  if (result.canceled || !result.filePaths[0]) return xhState();

  const source = result.filePaths[0];
  const ext = (path.extname(source) || '.png').toLowerCase();
  const file = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}${ext}`;
  try {
    fs.copyFileSync(source, path.join(crosshairDir(), file));
  } catch (error) {
    return { ...xhState(), error: error.message };
  }

  const config = xhConfig();
  const baseName = path.basename(source, path.extname(source)).slice(0, 30) || 'Eigenes Bild';
  config.customImages.push({ id: newId('img'), name: path.basename(source).slice(0, 60), file, added: Date.now() });
  const profile = normalizeProfile({
    id: newId('p'),
    name: baseName,
    kind: 'image',
    image: file,
    color: '#ffffff',
    outline: 0,
    thickness: 1,
  });
  config.profiles.push(profile);
  config.activeId = profile.id;
  config.enabled = true;
  return saveXhConfig(config);
});

ipcMain.handle('xh:pickWallpaper', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Hintergrund wählen',
    properties: ['openFile'],
    filters: [{ name: 'Videos & Bilder', extensions: ['mp4', 'webm', 'gif', 'png', 'jpg', 'jpeg', 'webp'] }],
  });
  if (result.canceled || !result.filePaths[0]) return xhState();
  const source = result.filePaths[0];
  const ext = (path.extname(source) || '.mp4').toLowerCase();
  const name = `eigen-${Date.now().toString(36)}${ext}`;
  try {
    fs.copyFileSync(source, path.join(userWallpaperDir(), name));
  } catch (error) {
    return { ...xhState(), error: error.message };
  }
  return saveXhConfig({ ...xhConfig(), wallpaper: name });
});

ipcMain.handle('xh:deleteImage', (_event, id) => {
  const config = xhConfig();
  const image = config.customImages.find((entry) => entry.id === id);
  if (!image) return xhState();
  config.customImages = config.customImages.filter((entry) => entry.id !== id);
  config.profiles = config.profiles.filter((profile) => profile.image !== image.file);
  if (!config.profiles.some((profile) => profile.id === config.activeId)) {
    config.activeId = config.profiles[0]?.id || 'classic';
  }
  try {
    fs.unlinkSync(path.join(crosshairDir(), path.basename(image.file)));
  } catch {
    /* Datei darf fehlen */
  }
  return saveXhConfig(config);
});

ipcMain.handle('xh:export', async () => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Crosshair-Konfiguration speichern',
    defaultPath: 'revolution-crosshair.json',
    filters: [{ name: 'JSON', extensions: ['json'] }],
  });
  if (result.canceled || !result.filePath) return false;
  fs.writeFileSync(result.filePath, JSON.stringify(xhConfig(), null, 2), 'utf8');
  return true;
});

ipcMain.handle('xh:import', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Crosshair-Konfiguration laden',
    properties: ['openFile'],
    filters: [{ name: 'JSON', extensions: ['json'] }],
  });
  if (result.canceled || !result.filePaths[0]) return xhState();
  try {
    const parsed = JSON.parse(fs.readFileSync(result.filePaths[0], 'utf8'));
    return saveXhConfig({ ...parsed, customImages: xhConfig().customImages });
  } catch (error) {
    return { ...xhState(), error: error.message };
  }
});

ipcMain.handle('xh:reset', () => {
  const config = xhConfig();
  return saveXhConfig({
    ...normalizeApp({}),
    profiles: [...defaultProfiles()],
    customImages: config.customImages,
  });
});

ipcMain.on('window:minimize', () => mainWindow?.minimize());

ipcMain.on('window:close', () => mainWindow?.close());

ipcMain.on('clipper:ready', () => pushClipperState(''));

ipcMain.handle('input:start', () => {
  inputHook.start(handleInputState);
  return true;
});

ipcMain.handle('input:stop', () => {
  // Der Hook läuft immer mit (Zielen, Waffen-Hotkeys, Tasten-Zeitleiste der
  // Clips). Früher hat der Keystroke-Schalter ihn hier ganz abgeschaltet.
  return true;
});

ipcMain.handle('stats:scan', () => runScan());

function createOverlay() {
  if (overlayWindow && !overlayWindow.isDestroyed()) return overlayWindow;

  const { bounds } = screen.getPrimaryDisplay();

  overlayWindow = new BrowserWindow({
    x: bounds.x,
    y: bounds.y,
    width: bounds.width,
    height: bounds.height,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'overlay-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false,
    },
  });

  overlayWindow.setAlwaysOnTop(true, 'screen-saver');
  overlayWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  overlayWindow.setIgnoreMouseEvents(true, { forward: false });
  overlayWindow.loadFile(path.join(ROOT, 'renderer', 'crosshair-overlay.html'));

  overlayWindow.webContents.on('did-finish-load', () => {
    positionOverlayOnGameDisplay();
    pushCrosshairConfig();
    refreshOverlayVisibility();
  });

  // Vollbild-Spiele nehmen das Fenster sonst aus dem Vordergrund.
  clearInterval(overlayTopTimer);
  overlayTopTimer = setInterval(() => {
    if (!overlayWindow || overlayWindow.isDestroyed() || !overlayWindow.isVisible()) return;
    overlayWindow.setAlwaysOnTop(true, 'screen-saver');
  }, 5000);

  overlayWindow.on('closed', () => {
    overlayWindow = null;
    clearInterval(overlayTopTimer);
    overlayTopTimer = null;
  });

  // Läuft das Spiel auf einem anderen Monitor, wandert das Crosshair mit.
  if (!displayTimer) {
    displayTimer = setInterval(() => {
      if (!overlayWindow || overlayWindow.isDestroyed()) return;
      if (!crosshairVisible()) return;
      positionOverlayOnGameDisplay();
      pushCrosshairConfig();
    }, 2500);
  }

  return overlayWindow;
}

/* Popups (Kill-Karten, „Tracker aktiv“) entfallen: das Overlay zeigt nur das Crosshair. */
function showKillPopup() {
  return false;
}

function showOverlayNotice() {
  return false;
}

function replayMtime(match) {
  try {
    return fs.statSync(path.resolve(replayDir(), match.file || '')).mtimeMs;
  } catch {
    return Date.now();
  }
}

/**
 * Summe der per OCR erkannten Schadenszahlen kurz vor einem Kill.
 * Werte, die in fast allen Bildern des Fensters auftauchen, sind HUD-Zahlen
 * (Munition, Mats, Spielerzahl) und werden verworfen.
 */
function damageForKill(atMs, windowMs = 6000) {
  if (!store?.settings.damageOcr || damageLog.length === 0) return 0;
  const from = atMs - windowMs;
  const counts = new Map();
  for (const event of damageLog) {
    if (event.t < from || event.t > atMs) continue;
    counts.set(event.value, (counts.get(event.value) || 0) + 1);
  }
  let total = 0;
  for (const [value, count] of counts) {
    if (count >= 5) continue;
    total += value;
  }
  return Math.min(total, 999);
}

/* ---------------- Live-Kills, Spieler-Buch, Match-Fenster ---------------- */

function ownNames() {
  const names = new Set();
  if (store?.settings.displayName) names.add(store.settings.displayName);
  for (const match of (store?.data.matches || []).slice(0, 60)) {
    if (match?.me?.name) names.add(match.me.name);
  }
  return [...names];
}

/** Replay-Karten mit Schadensschaetzung und Bekannt-Status anreichern. */
function enrichReplayCards(match) {
  const cards = buildKillCards(match);
  if (cards.length === 0) return cards;

  const endMs = replayMtime(match);
  const startMs = endMs - (Number(match.durationSec) || 0) * 1000;

  for (const card of cards) {
    const estimated = damageForKill(startMs + (card.timeSec || 0) * 1000);
    card.damage = estimated > 0 ? estimated : null;
    card.state = 'dead';

    const before = playerBook?.stat(card.name);
    const entry = playerBook?.record({
      name: card.name,
      state: 'dead',
      level: card.level,
      theirKills: card.kills,
      placement: card.placement,
      bot: card.bot,
      matchDate: match.date,
      counted: false,
    });
    card.recognized = Boolean(before && before.encounters > 0);
    card.times = entry ? (Number(entry.kills) || 0) + (Number(entry.downs) || 0) : undefined;
  }

  return cards;
}

/**
 * Welche Feed-Zeilen sind neu? Die Zeilen bleiben rund 10 s stehen und werden
 * dabei viele Male gelesen – nur was vorher nicht da war, ist ein neuer Kill.
 * Der Zustand gehoert zum Schluessel, damit „zu Boden geschickt“ und danach
 * „eliminiert“ beide eine Karte bekommen.
 */
function freshFeedHits(text, names) {
  const now = Date.now();
  if (now - liveSession.startedAt > 60 * 60 * 1000) {
    liveSession = { seen: new Map(), startedAt: now };
  }
  for (const [key, info] of liveSession.seen) {
    if (now - info.at > 120000) liveSession.seen.delete(key);
  }

  const fresh = [];
  for (const hit of parseFeed(text, names)) {
    const name = playerBook.key(hit.victimName);
    const key = `${name}|${hit.state}`;
    const last = liveSession.seen.get(key);
    const stillThere = Boolean(last) && now - last.at <= FEED_LINE_TTL;

    // OCR liest denselben Namen unterschiedlich („ShicldHorse“ / „ShieldHorse“):
    // ein aehnlicher Name in derselben Zeile ist derselbe Kill.
    let twin = false;
    for (const [otherKey, info] of liveSession.seen) {
      if (otherKey === key || now - info.at > FEED_LINE_TTL) continue;
      const [otherName, otherState] = otherKey.split('|');
      if (otherState !== hit.state) continue;
      const tolerance = Math.max(2, Math.floor(Math.max(otherName.length, name.length) * 0.3));
      if (distance(otherName, name) <= tolerance) {
        twin = true;
        break;
      }
    }

    liveSession.seen.set(key, { at: now, state: hit.state });
    if (!stillThere && !twin) fresh.push(hit);
  }
  return fresh;
}

/** Kill aus dem Live-Feed: Karte einblenden und Gegner dauerhaft merken. */
function handleLiveKill(rawName, rawState) {
  if (!store?.settings.killFeed || !playerBook) return false;
  const name = String(rawName || '').trim().slice(0, 40);
  if (name.length < 3) return false;

  const now = Date.now();

  // Zustand kommt aus der Feed-Zeile: „knocked“ gelb, „eliminated“ rot.
  const state = rawState === 'down' && store.settings.knockDetection ? 'down' : 'dead';

  const before = playerBook.stat(name);
  const entry = playerBook.record({ name, state, counted: true });
  if (!entry) return false;

  liveKills += 1;
  const card = {
    name: entry.name,
    state,
    live: true,
    bot: Boolean(entry.bot),
    recognized: before.encounters > 0,
    times: (Number(entry.kills) || 0) + (Number(entry.downs) || 0),
    damage: Math.max(0, Math.round(Number(damageForKill(now, 8000)) || 0)) || null,
  };

  console.log('[kill]', card.name, card.state, card.damage ?? '-', now);
  mainWindow?.webContents.send('kill:live', { card, liveKills });

  // Nur der eigene, endgültige Kill löst einen Clip aus: ein Knock oder eine
  // Fremd-Zeile aus dem Feed darf keinen Clip schreiben.
  if (store.settings.clipOnKill && state === 'dead') scheduleKillClip(card.name);
  return true;
}

function summaryPayload(match, cards) {
  const me = match.me || {};
  const stats = match.stats || {};
  const myKills = (match.kills || []).filter((kill) => kill.killerId === me.id && !kill.selfElim);
  const weapons = new Map();
  for (const kill of myKills) {
    const weapon = kill.weapon || 'Unbekannt';
    weapons.set(weapon, (weapons.get(weapon) || 0) + 1);
  }

  return {
    matchFile: match.file || null,
    date: match.date || null,
    name: me.name || '',
    placement: Number(me.placement) || null,
    kills: Number(me.kills) || 0,
    durationSec: Number(match.durationSec) || 0,
    recognizedCount: (cards || []).filter((card) => card.recognized).length,
    stats: {
      damageToPlayers: Number(stats.damageToPlayers) || 0,
      damageTaken: Number(stats.damageTaken) || 0,
      accuracy: Number(stats.accuracy) || 0,
      materialsGathered: Number(stats.materialsGathered) || 0,
      materialsUsed: Number(stats.materialsUsed) || 0,
      damageToStructures: Number(stats.damageToStructures) || 0,
      distanceTraveled: Number(stats.distanceTraveled) || 0,
      assists: Number(stats.assists) || 0,
      revives: Number(stats.revives) || 0,
    },
    weapons: [...weapons.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4)
      .map(([weapon, count]) => ({ weapon, count })),
    cards: (cards || []).map((card) => ({
      name: card.name,
      bot: Boolean(card.bot),
      damage: card.damage || null,
      recognized: Boolean(card.recognized),
    })),
  };
}

function createSummaryWindow() {
  if (summaryWindow && !summaryWindow.isDestroyed()) return summaryWindow;

  summaryWindow = new BrowserWindow({
    width: 520,
    height: 720,
    frame: false,
    transparent: true,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: false,
    show: false,
    backgroundColor: '#00000000',
    title: 'Match-Ergebnis',
    webPreferences: {
      preload: path.join(__dirname, 'summary-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  summaryWindow.loadFile(path.join(ROOT, 'renderer', 'summary.html'));
  summaryWindow.webContents.on('did-finish-load', () => {
    if (summaryWindow && !summaryWindow.isDestroyed() && summaryData) {
      summaryWindow.webContents.send('summary:data', summaryData);
    }
  });
  summaryWindow.on('closed', () => {
    summaryWindow = null;
  });
  return summaryWindow;
}

function showMatchSummary(match, cards) {
  if (!match) return false;
  summaryData = summaryPayload(match, cards);
  const win = createSummaryWindow();
  if (!win) return false;

  const send = () => {
    if (win.isDestroyed()) return;
    win.webContents.send('summary:data', summaryData);
    win.center();
    win.showInactive();
  };

  if (win.webContents.isLoading()) win.webContents.once('did-finish-load', send);
  else send();
  return true;
}

function startGameWatch() {
  if (gameWatch) return;
  gameWatch = startWatch({
    getDir: () => replayDir(),
    intervalMs: 6000,
    onStatus: (running, previous) => {
      fortniteRunning = running;
      if (running) {
        liveSession = { seen: new Map(), startedAt: Date.now() };
        liveKills = 0;
        clipSessionCount = 0;
        mainWindow?.webContents.send('clip:auto-game', { start: true });
        clearInterval(rankTimer);
        rankTimer = setInterval(() => {
          detectRank();
        }, 15000);
        // Direkt nach dem Start und nach jedem Match erneut lesen, damit ein
        // Rang-Up auch außerhalb der Lobby ankommt.
        setTimeout(() => detectRank(), 24000);
      } else {
        clearInterval(rankTimer);
        rankTimer = null;
        mainWindow?.webContents.send('clip:auto-game', { start: false });
      }
      updateClipperOverlay();
      refreshOverlayVisibility();
      // Spiel zu: eine offene Runde gilt als beendet.
      refreshChestOverlay();
      mainWindow?.webContents.send('game:status', { running });
      mainWindow?.webContents.send('xh:state', xhState());
      if (previous === true && running === false && !NO_SCAN && store?.settings.autoScan && !scanning) {
        setTimeout(() => {
          if (!scanning) runScan();
        }, 4000);
      }
    },
    onNewReplay: (file) => {
      // Nach einer Runde kann sich der Rang geändert haben – gelesen wird er
      // aber erst wieder in der Lobby (der Intervall oben prüft das).
      lastRankCheck = 0;
      if (NO_SCAN || scanning || !store?.settings.autoScan) return;
      if (Date.now() - file.mtime < 15000) return;
      runScan();
    },
  });
}


/* ---------------- Truhen-Zähler ----------------
 * Zählt geöffnete Truhen (Runde und gesamt), Overlay oben im Spiel. Die
 * Erkennung steckt in chests.js; hier hängen Overlay, Eingaben und IPC dran.
 */

let chests = null;
let chestWindow = null;
let chestPreviewUntil = 0;
let chestPreviewTimer = null;

const CHEST_W = 360;
const CHEST_H = 170;

function chestBounds() {
  const settings = chests?.settings || {};
  const scale = Number(settings.scale) || 1;
  const width = Math.round(CHEST_W * scale);
  const height = Math.round(CHEST_H * scale);
  const area = gameDisplay().bounds;
  const margin = 14;
  const preset = settings.preset || 'tl';
  const col = preset[1];
  const row = preset[0];
  const x = col === 'l' ? area.x + margin : col === 'r' ? area.x + area.width - width - margin : area.x + Math.round((area.width - width) / 2);
  const y = row === 't' ? area.y + margin : row === 'b' ? area.y + area.height - height - margin : area.y + Math.round((area.height - height) / 2);
  return { x, y, width, height };
}

function createChestOverlay() {
  if (chestWindow && !chestWindow.isDestroyed()) return chestWindow;
  chestWindow = new BrowserWindow({
    ...chestBounds(),
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'chest-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false,
    },
  });
  chestWindow.setAlwaysOnTop(true, 'screen-saver');
  chestWindow.setIgnoreMouseEvents(true, { forward: false });
  chestWindow.loadFile(path.join(ROOT, 'renderer', 'chest-overlay.html'));
  chestWindow.webContents.on('did-finish-load', () => sendChests(chests?.snapshot()));
  chestWindow.on('closed', () => {
    chestWindow = null;
  });
  return chestWindow;
}

function chestOverlayWanted() {
  const settings = chests?.settings;
  if (!settings?.enabled || !settings.overlay) return Date.now() < chestPreviewUntil;
  return fortniteRunning || Date.now() < chestPreviewUntil;
}

function refreshChestOverlay() {
  if (!chests) return;
  const wanted = chestOverlayWanted();
  if (!wanted) {
    if (chestWindow && !chestWindow.isDestroyed() && chestWindow.isVisible()) chestWindow.hide();
    return;
  }
  const win = createChestOverlay();
  win.setBounds(chestBounds());
  if (!win.isVisible()) win.showInactive();
  win.setAlwaysOnTop(true, 'screen-saver');
}

function sendChests(snapshot) {
  if (!snapshot) return;
  mainWindow?.webContents.send('chests:state', snapshot);
  if (chestWindow && !chestWindow.isDestroyed()) chestWindow.webContents.send('chests:state', snapshot);
}

function previewChests(ms = 6000) {
  chestPreviewUntil = Date.now() + ms;
  refreshChestOverlay();
  clearTimeout(chestPreviewTimer);
  chestPreviewTimer = setTimeout(refreshChestOverlay, ms + 200);
}

function initChests() {
  chests = new ChestCounter(path.join(app.getPath('userData'), 'chests.json'), {
    log: chestLog,
    onChange: (snapshot) => {
      sendChests(snapshot);
      const type = snapshot.event?.type;
      if (type === 'open') {
        console.log('[chests] +1 · gesamt', snapshot.allTime);
        // Animation auch zeigen, wenn das Spiel gerade nicht erkannt ist (z. B. Test).
        if (!fortniteRunning) previewChests(4000);
      }
    },
  });
  refreshChestOverlay();
}

ipcMain.handle('chests:get', () => chests?.snapshot());
ipcMain.handle('chests:set', (_event, patch) => {
  const next = chests.setSettings(patch || {});
  previewChests(5000);
  return next;
});
ipcMain.handle('chests:adjust', (_event, amount) => chests.count(Math.max(-5, Math.min(5, Math.round(Number(amount) || 0))), 'manual'));
ipcMain.handle('chests:reset', (_event, ign) => chests.reset(ign, ownNames()));
ipcMain.handle('chests:preview', () => {
  previewChests(6000);
  return true;
});
ipcMain.handle('chests:test', () => {
  previewChests(4000);
  // Nur die Animation – die echte Zahl bleibt unverändert.
  const snap = chests.snapshot();
  setTimeout(() => sendChests({ ...snap, allTime: snap.allTime + 1, event: { type: 'open', test: true } }), 350);
  setTimeout(() => sendChests(chests.snapshot()), 3200);
  return true;
});

/* Diagnose: clip-debug/chest.log (was gelesen wurde, Tasten, Zählungen) und
 * bei jedem Tastendruck ein Bild – damit lässt sich die Erkennung einstellen. */
let lastChestText = '';
function chestLog(line) {
  try {
    const file = path.join(clipDebugDir(), 'chest.log');
    if (fs.existsSync(file) && fs.statSync(file).size > 1_000_000) fs.renameSync(file, `${file}.old`);
    fs.appendFileSync(file, `${new Date().toLocaleTimeString('de-DE')}.${String(Date.now() % 1000).padStart(3, '0')} ${line}\n`);
  } catch {
    /* egal */
  }
}

let chestShotIndex = 0;
let lastChestShot = 0;
ipcMain.handle('chests:debugShot', (_event, frameBase64, cropBase64) => {
  if (Date.now() - lastChestShot < 2500) return false;
  lastChestShot = Date.now();
  try {
    chestShotIndex = (chestShotIndex % 6) + 1;
    if (typeof frameBase64 === 'string') fs.writeFileSync(path.join(clipDebugDir(), `chest-${chestShotIndex}.jpg`), Buffer.from(frameBase64, 'base64'));
    if (typeof cropBase64 === 'string') fs.writeFileSync(path.join(clipDebugDir(), `chest-${chestShotIndex}-crop.png`), Buffer.from(cropBase64, 'base64'));
    return true;
  } catch {
    return false;
  }
});

/** Ausschnitt um das Fadenkreuz: Text mit Lage + Gold-Raster derselben Fläche. */
ipcMain.handle('chests:frame', async (_event, base64, kind, gold) => {
  if (!chests?.settings.enabled || typeof base64 !== 'string' || base64.length < 200) return null;
  if (kind === 'xp') {
    const { text } = await ocr.readScreenWords(Buffer.from(base64, 'base64'), 'chest');
    const hit = chests.feedXp(text);
    if (hit) chestLog(`XP gelesen: ${String(text).replace(/\s+/g, ' ').slice(0, 60)}`);
    return { xp: hit };
  }
  if (kind !== 'prompt') return null;
  const { text, words } = await ocr.readScreenWords(Buffer.from(base64, 'base64'), 'chest');
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  const result = chests.feedPrompt(words, gold);
  if (result.search && clean !== lastChestText) chestLog(`liest: ${clean.slice(0, 70)} · Gold ${((result.gold || 0) * 100).toFixed(1)} %`);
  lastChestText = clean;
  return { ...result, text: clean.slice(0, 60) };
});

/* ---------------- Musik-Overlay ---------------- */

const LRC_LINE = /^\[(\d{1,2}):(\d{2}(?:[.,]\d{1,3})?)\]\s*(.*)$/;

let musicWindow = null;
let musicData = null;
let musicLyrics = [];
let musicArt = '';
let musicLinesDirty = false;
let musicArtDirty = false;
let musicTrackKey = '';
// Frisch geladenes Overlay: einmal alles mitschicken, sonst bleiben Cover und
// Text leer, weil sie danach nur noch bei Änderung übertragen werden.
let overlayNeedsFull = false;
let musicHideTimer = null;
let mediaStarted = false;
const lyricCache = new Map();

const MUSIC_PRESETS = ['tl', 'tc', 'tr', 'ml', 'mc', 'mr', 'bl', 'bc', 'br', 'free'];
const MUSIC_MARGIN = 4;

// Position, die gerade im Feld gezogen wird. Ohne diesen Merker setzt der
// nächste Medien-Takt die Karte wieder auf das gespeicherte Preset zurück und
// sie springt beim Ziehen zwischen beiden Stellen hin und her.
let musicPreviewPos = null;

function musicConfig() {
  const source = store?.settings?.music || {};
  const toOffset = (value) => {
    // Number(null) wäre 0 – „nicht gesetzt“ muss aber null bleiben, sonst
    // klebt das Overlay in der linken oberen Ecke statt oben mittig.
    if (value === null || value === undefined || value === '') return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.round(parsed) : null;
  };
  return {
    enabled: source.enabled !== false,
    preset: MUSIC_PRESETS.includes(source.preset)
      ? source.preset
      : toOffset(source.x) !== null || toOffset(source.y) !== null
        ? 'free'
        : 'tc',
    x: toOffset(source.x),
    y: toOffset(source.y),
    scale: Math.min(2, Math.max(0.6, Number(source.scale) || 1)),
    lyrics: source.lyrics !== false,
    title: source.title !== false,
    progress: source.progress !== false,
    vinylOnly: source.vinylOnly === true,
    vinyl: source.vinyl === true || source.vinylOnly === true,
    arm: source.arm !== false,
    crackle: source.crackle === true,
    crackleVolume: Number.isFinite(Number(source.crackleVolume))
      ? Math.min(100, Math.max(0, Number(source.crackleVolume)))
      : 40,
  };
}

function createMusicOverlay() {
  if (musicWindow && !musicWindow.isDestroyed()) return musicWindow;
  musicWindow = new BrowserWindow({
    width: 380,
    height: 118,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'music-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false,
      // Das Knistern soll ohne Klick ins Fenster starten dürfen.
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  musicWindow.setAlwaysOnTop(true, 'screen-saver');
  musicWindow.setIgnoreMouseEvents(true, { forward: false });
  musicWindow.loadFile(path.join(ROOT, 'renderer', 'music-overlay.html'));
  musicWindow.on('closed', () => {
    musicWindow = null;
  });
  return musicWindow;
}

function applyMusicBounds(win, config) {
  const display = screen.getPrimaryDisplay();
  const area = display.workArea;
  // "Nur Schallplatte": quadratisches Fenster, damit nur der runde Kreis da ist.
  const width = Math.round((config.vinylOnly === true ? 140 : 380) * config.scale);
  const height = Math.round((config.vinylOnly === true ? 140 : 118) * config.scale);
  // Im Kreis-Modus darf die Platte bündig in der Ecke sitzen.
  const edge = config.vinylOnly === true ? 0 : MUSIC_MARGIN;
  const spot = (preset) => {
    const row = preset === 'free' ? 't' : preset[0];
    const col = preset === 'free' ? 'l' : preset[1];
    const x =
      col === 'l' ? area.x + edge : col === 'r' ? area.x + area.width - width - edge : Math.round(area.x + (area.width - width) / 2);
    const y =
      row === 't' ? area.y + edge : row === 'b' ? area.y + area.height - height - edge : Math.round(area.y + (area.height - height) / 2);
    return { x, y };
  };
  const free = musicPreviewPos || (config.preset === 'free' && config.x !== null ? { x: config.x, y: config.y } : null);
  const target = free
    ? { x: area.x + free.x, y: area.y + (free.y === null || free.y === undefined ? edge : free.y) }
    : spot(config.preset === 'free' ? 'tl' : config.preset);
  const clampedX = Math.min(Math.max(target.x, area.x), area.x + area.width - width);
  const clampedY = Math.min(Math.max(target.y, area.y), area.y + area.height - height);
  win.setBounds({ x: clampedX, y: clampedY, width, height });
}

function pushMusicState() {
  if (!musicWindow || musicWindow.isDestroyed()) return;
  const config = musicConfig();
  // Liedtext und Cover nur bei Änderung mitschicken: bei drei Abfragen pro
  // Sekunde wäre die Liste sonst 120-mal pro Minute im IPC-Kanal.
  // Das SMTC-Payload enthält ein eigenes (leeres) art-Feld – per Spread würde
  // das jedes geladene Cover im nächsten Takt sofort wieder löschen. Deshalb
  // fällt es hier raus; Cover geht nur noch explizit geladen raus.
  const { art: _sessionArt, ...base } = musicData || { playing: false };
  const full = overlayNeedsFull;
  overlayNeedsFull = false;
  const payload = {
    ...base,
    ...(musicLinesDirty || full ? { lines: musicLyrics } : {}),
    ...(musicArtDirty || full ? { art: musicArt } : {}),
    // Songtext nur bei Musik-Apps: bei einem Video im Browser gibt es keinen Text.
    lyrics: config.lyrics && isMusicApp(musicData),
    scale: config.scale,
    vinyl: config.vinyl,
    // showTitle/showProgress statt title/progress: „title“ ist im Payload
    // der Songtitel und darf hier nicht überschrieben werden.
    showTitle: config.title !== false,
    showProgress: config.progress !== false,
    vinylOnly: config.vinylOnly === true,
    arm: config.arm !== false,
    crackle: config.crackle === true,
    crackleVolume: config.crackleVolume,
    // Dasselbe Wallpaper-Video wie im App-Fenster als Kartenhintergrund.
    shade: wallShade(),
    wall: (() => {
      const name = store?.settings?.xh?.wallpaper;
      return typeof name === 'string' && name ? `wall://media/${encodeURIComponent(name)}` : '';
    })(),
  };
  musicLinesDirty = false;
  musicArtDirty = false;
  const send = () => {
    if (musicWindow && !musicWindow.isDestroyed()) musicWindow.webContents.send('music:update', payload);
  };
  if (musicWindow.webContents.isLoading()) musicWindow.webContents.once('did-finish-load', send);
  else send();
}

function refreshMusicOverlay() {
  const config = musicConfig();
  if (!config.enabled) {
    if (musicWindow && !musicWindow.isDestroyed()) musicWindow.hide();
    return;
  }
  const win = createMusicOverlay();
  applyMusicBounds(win, config);
  if (musicData && (musicData.playing || musicData.title)) {
    win.showInactive();
    pushMusicState();
  }
}

/** Songtext von LRCLIB (kostenlos, ohne Schlüssel) als Zeitzeilen. */
function parseLrc(text) {
  const lines = [];
  for (const raw of String(text || '').split(/\r?\n/)) {
    const match = LRC_LINE.exec(String(raw).trim());
    if (!match) continue;
    const seconds = Number(match[1]) * 60 + Number(String(match[2]).replace(',', '.'));
    const value = match[3].trim();
    if (!value) continue;
    lines.push({ t: Math.round(seconds * 10) / 10, text: value });
  }
  return lines.sort((a, b) => a.t - b.t).slice(0, 400);
}

async function fetchLyrics(track) {
  const key = `${track.artist || ''}|${track.title || ''}|${Math.round(Number(track.duration) || 0)}`;
  if (lyricCache.has(key)) return lyricCache.get(key);

  let lines = [];
  try {
    const url = new URL('https://lrclib.net/api/get');
    url.searchParams.set('artist_name', track.artist || '');
    url.searchParams.set('track_name', track.title || '');
    if (Number(track.duration) > 0) url.searchParams.set('duration', String(Math.round(Number(track.duration))));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'RevolutionCrosshair/2.0 (Desktop)' },
    });
    clearTimeout(timer);
    if (response.ok) {
      const data = await response.json();
      lines = parseLrc(data?.syncedLyrics || '');
    }
  } catch {
    lines = [];
  }

  lyricCache.set(key, lines);
  if (lyricCache.size > 80) lyricCache.delete(lyricCache.keys().next().value);
  return lines;
}

const artCache = new Map();

/**
 * Cover über die iTunes-Suche. Windows liefert das SMTC-Vorschaubild nur als
 * COM-Stream, der sich aus PowerShell nicht zuverlässig auslesen lässt – die
 * Suche nach Interpret + Titel funktioniert dagegen bei jedem Player.
 */
async function fetchArtwork(track) {
  const key = `${track.artist || ''}|${track.title || ''}`;
  if (artCache.has(key)) return artCache.get(key);

  let url = '';
  try {
    const search = new URL('https://itunes.apple.com/search');
    search.searchParams.set('term', `${track.artist || ''} ${track.title || ''}`.trim().slice(0, 120));
    search.searchParams.set('entity', 'song');
    search.searchParams.set('limit', '1');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);
    const response = await fetch(search, { signal: controller.signal });
    clearTimeout(timer);
    if (response.ok) {
      const data = await response.json();
      const art = data?.results?.[0]?.artworkUrl600 || data?.results?.[0]?.artworkUrl100 || '';
      if (art) url = String(art).replace(/\/\d+x\d+bb\./, '/600x600bb.');
    }
  } catch {
    url = '';
  }

  artCache.set(key, url);
  if (artCache.size > 80) artCache.delete(artCache.keys().next().value);
  return url;
}

const ytCache = new Map();

async function fetchPage(url, ms = 15000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
      },
    });
    return response.ok ? await response.text() : '';
  } catch {
    return '';
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Cover für Videos (YouTube im Browser): Windows gibt das SMTC-Vorschaubild nur
 * als COM-Stream heraus, der sich nicht auslesen lässt. Deshalb: Titel suchen,
 * Video-Vorschaubild sofort zeigen und danach das Kanalbild nachladen.
 */
async function fetchVideoArtwork(track) {
  const key = `${track.artist || ''}|${track.title || ''}`;
  const cached = ytCache.get(key);
  if (cached) return cached.avatar || cached.thumb;

  const query = `${track.title || ''} ${track.artist || ''}`.trim().slice(0, 120);
  if (!query) return '';
  const entry = { thumb: '', avatar: '' };
  ytCache.set(key, entry);

  const search = await fetchPage(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
  const hit = /"videoId":"([A-Za-z0-9_-]{11})"/.exec(search);
  if (!hit) return '';

  entry.thumb = `https://i.ytimg.com/vi/${hit[1]}/hqdefault.jpg`;
  if (musicTrackKey === key) {
    musicArt = entry.thumb;
    musicArtDirty = true;
    pushMusicState();
  }

  const page = await fetchPage(`https://www.youtube.com/watch?v=${hit[1]}`);
  const avatar =
    /"videoOwnerRenderer":\{"thumbnail":\{"thumbnails":\[\{"url":"(https:[^"]+)"/.exec(page) ||
    /"avatar":\{"thumbnails":\[\{"url":"(https:[^"]+)"/.exec(page);
  if (avatar) {
    entry.avatar = avatar[1].replace(/=s\d+[^"!]*$/, '=s240-c-k-c0x00ffffff-no-rj');
  }
  if (musicTrackKey === key) {
    musicArt = entry.avatar || entry.thumb;
    musicArtDirty = true;
    pushMusicState();
  }
  return musicArt;
}

/** Spotify & Co. – nur dort gibt es Cover und Songtext. */
function isMusicApp(payload) {
  return /spotify|deezer|tidal|amazonmusic|applemusic|itunes|musicbee/i.test(String(payload?.app || ''));
}

async function handleMediaUpdate(payload) {
  const config = musicConfig();
  musicData = payload && typeof payload === 'object' ? payload : { playing: false };
  const key = `${payload?.artist || ''}|${payload?.title || ''}`;
  // Ohne Titel (Pause, Ende, Helfer-Schluckauf) nichts anfassen: sonst wären
  // Cover und Text bei jeder Lücke weg. Alte Daten bleiben stehen, bis die
  // neuen wirklich geladen sind – der Titel selbst kommt eh in jedem Takt mit.
  if (payload?.title && key !== musicTrackKey) {
    musicTrackKey = key;
    const withMusic = config.enabled && isMusicApp(payload);
    // Wechsel zu Video/Text-aus: alte Daten sofort räumen, sonst stünden sie
    // noch unter dem neuen Titel. Musik-Titel behalten ihre alten bis zum
    // Treffer, damit nichts flackert.
    if (config.enabled && (!withMusic || !config.lyrics) && musicLyrics.length > 0) {
      musicLyrics = [];
      musicLinesDirty = true;
    }
    if (config.enabled && !withMusic && musicArt) {
      musicArt = '';
      musicArtDirty = true;
    }
    if (config.enabled) {
      const loadArt = isMusicApp(payload) ? fetchArtwork(payload) : fetchVideoArtwork(payload);
      loadArt.then((url) => {
        if (musicTrackKey !== key) return;
        musicArt = url;
        musicArtDirty = true;
        pushMusicState();
      });
    }
    if (payload?.title && config.enabled && config.lyrics && isMusicApp(payload)) {
      fetchLyrics(payload).then((lines) => {
        musicLyrics = lines;
        musicLinesDirty = true;
        pushMusicState();
      });
    }
  }

  if (!config.enabled) return;

  if (payload?.playing || payload?.title) {
    clearTimeout(musicHideTimer);
    const win = createMusicOverlay();
    applyMusicBounds(win, config);
    if (!win.isVisible()) win.showInactive();
    pushMusicState();
  } else if (musicWindow && !musicWindow.isDestroyed() && musicWindow.isVisible()) {
    clearTimeout(musicHideTimer);
    musicHideTimer = setTimeout(() => {
      if (musicWindow && !musicWindow.isDestroyed()) musicWindow.hide();
    }, 4000);
  }
}

function startMediaWatcher() {
  if (mediaStarted) return;
  mediaStarted = media.start(handleMediaUpdate);
  if (!mediaStarted) console.log('[media] PowerShell-Helfer fehlt');
}

function stopMediaWatcher() {
  if (!mediaStarted) return;
  media.stop();
  mediaStarted = false;
}

function initMusic() {
  const config = musicConfig();
  if (config.enabled) createMusicOverlay();
  startMediaWatcher();
}

const MUSIC_DEMO_STATE = {
  playing: true,
  title: 'Nebula Drive',
  artist: 'Revolution',
  album: 'Demo',
  app: 'demo',
  position: 26,
  duration: 214,
};

const MUSIC_DEMO_LYRICS = [
  { t: 0, text: 'Wir ziehen durch die Nacht' },
  { t: 6.5, text: 'und die Stadt atmet mit' },
  { t: 12.4, text: 'jeder Schuss ein neuer Takt' },
  { t: 18.2, text: 'und das Licht zieht uns mit' },
  { t: 24.1, text: 'Nebula Drive, wir bleiben wach' },
];

ipcMain.handle('music:get', () => ({ settings: musicConfig(), state: musicData }));

ipcMain.handle('music:set', (_event, patch) => {
  const next = { ...musicConfig(), ...(patch && typeof patch === 'object' ? patch : {}) };
  return writeMusicSettings(next);
});

// Live-Vorschau beim Ziehen: setzt nur die Fensterposition, nichts wird
// gespeichert – sonst würde bei jeder Mausbewegung die Einstellungsdatei
// geschrieben.
ipcMain.handle('music:preview', (_event, patch) => {
  const config = musicConfig();
  if (!config.enabled) return true;
  const x = Number(patch?.x);
  const y = Number(patch?.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return false;
  musicPreviewPos = { x, y };
  const win = createMusicOverlay();
  applyMusicBounds(win, { ...config, preset: 'free', x, y });
  return true;
});

// Der Hub zeigt die Musik-Einstellungen im Island-Bereich („Separater Player“).
if (global.__revolutionHub) {
  // Der Hub fragt das ab: Solange Crosshair oder Clipper laufen, bleibt er beim Schließen im Hintergrund.
  // App-Lautstärken für das Kontrollzentrum des Hubs
  global.__revolutionHub.mixer = {
    list: () => audio.list(),
    setApp: (pid, volume, mute) => audio.setApp(Number(pid) || 0, volume, mute),
    setMaster: (volume, mute) => audio.setMaster(volume, mute),
  };
  global.__revolutionHub.gamingActive = () => {
    try {
      return Boolean(xhConfig().enabled || registeredHotkey || fortniteRunning);
    } catch {
      return false;
    }
  };
  global.__revolutionHub.music = {
    get: () => ({ settings: musicConfig(), state: musicData }),
    set: (patch) => writeMusicSettings({ ...musicConfig(), ...(patch && typeof patch === 'object' ? patch : {}) }),
    demo: () => {
      musicData = { ...MUSIC_DEMO_STATE };
      musicLyrics = MUSIC_DEMO_LYRICS.map((line) => ({ ...line }));
      musicArt = '';
      musicLinesDirty = true;
      musicArtDirty = true;
      musicTrackKey = 'demo';
      if (store.data.settings.music) store.data.settings.music.enabled = true;
      refreshMusicOverlay();
      pushMusicState();
      return { settings: musicConfig(), state: musicData };
    },
  };
}

ipcMain.handle('music:demo', () => {
  musicData = { ...MUSIC_DEMO_STATE };
  musicLyrics = MUSIC_DEMO_LYRICS.map((line) => ({ ...line }));
  musicArt = '';
  musicLinesDirty = true;
  musicArtDirty = true;
  musicTrackKey = 'demo';
  if (store.data.settings.music) store.data.settings.music.enabled = true;
  refreshMusicOverlay();
  pushMusicState();
  return { settings: musicConfig(), state: musicData };
});

ipcMain.on('music:ready', () => {
  overlayNeedsFull = true;
  pushMusicState();
});

/* ---------------- IPC: Leistung, Audio, Notizen, Bildschirmzeit ---------------- */

ipcMain.handle('perf:get', () => ({ settings: perfConfig(), data: perfPayload() }));

ipcMain.handle('perf:set', (_event, patch) => {
  const next = { ...perfConfig(), ...(patch && typeof patch === 'object' ? patch : {}) };
  store.data.settings.perf = normalizePerf(next);
  store.flush();
  refreshPerfOverlay();
  if (store.settings.perf.enabled) startPerfWatcher();
  else stopPerfWatcher();
  return { settings: perfConfig(), data: perfPayload() };
});

ipcMain.on('perf:ready', () => pushPerfState());

ipcMain.handle('audio:list', async () => {
  try {
    return await audio.list();
  } catch (error) {
    return { apps: [], error: error.message };
  }
});

ipcMain.handle('audio:master', async (_event, patch) => {
  const volume = patch && patch.volume !== undefined ? Number(patch.volume) : -1;
  const mute = typeof patch?.mute === 'boolean' ? (patch.mute ? 1 : 0) : -1;
  try {
    return await audio.setMaster(volume, mute);
  } catch (error) {
    return { error: error.message };
  }
});

ipcMain.handle('audio:app', async (_event, patch) => {
  const volume = patch && patch.volume !== undefined ? Number(patch.volume) : -1;
  const mute = typeof patch?.mute === 'boolean' ? (patch.mute ? 1 : 0) : -1;
  try {
    return await audio.setApp(Number(patch?.pid) || 0, volume, mute);
  } catch (error) {
    return { error: error.message };
  }
});

ipcMain.handle('notes:get', () => (Array.isArray(store?.settings?.notes) ? store.settings.notes : []));

ipcMain.handle('notes:save', (_event, notes) => {
  const list = Array.isArray(notes) ? notes : [];
  store.data.settings.notes = list
    .filter((note) => note && typeof note.text === 'string')
    .slice(0, 200)
    .map((note) => ({
      id: String(note.id || Date.now().toString(36)),
      text: note.text.slice(0, 4000),
      at: Number(note.at) || Date.now(),
    }));
  store.save();
  return store.data.settings.notes;
});

ipcMain.handle('screentime:get', () => screenTimeSummary());

/* ---------------- IPC: Statistik ---------------- */

ipcMain.handle('state:get', () => buildState());

ipcMain.handle('scan:start', () => runScan());

ipcMain.on('overlay:idle', () => {});

ipcMain.handle('overlay:noticeTest', () => false);

ipcMain.handle('overlay:crosshairTest', () => {
  xhPreviewUntil = Date.now() + 8000;
  refreshOverlayVisibility();
  setTimeout(() => {
    xhPreviewUntil = 0;
    refreshOverlayVisibility();
  }, 8200);
  return true;
});

ipcMain.handle('overlay:test', () => {
  const demo = [
    { name: 'Sharkboy61', state: 'down', recognized: true, times: 3, damage: 87, kills: 1, level: 33, placement: 23, weapon: 'Heavy-Sturmgewehr', distance: 46 },
    { name: 'Famous_king_31', state: 'dead', damage: 120, kills: 3, level: 31, placement: 39, weapon: 'Sturmgewehr', distance: 24 },
    { name: 'Bot_Waechter', state: 'dead', bot: true, damage: 45, weapon: 'Schrotflinte', distance: 6 },
  ];
  return showKillPopup(demo, { force: true });
});

ipcMain.handle('summary:test', () => {
  const newest = [...(store?.data.matches || [])].sort((a, b) =>
    String(b.date || '').localeCompare(String(a.date || '')),
  )[0];
  if (!newest) return false;
  return showMatchSummary(newest, enrichReplayCards(newest));
});

ipcMain.on('summary:close', () => {
  if (summaryWindow && !summaryWindow.isDestroyed()) summaryWindow.hide();
});

ipcMain.on('summary:open', () => {
  if (summaryWindow && !summaryWindow.isDestroyed()) summaryWindow.hide();
  if (!mainWindow) return;
  mainWindow.show();
  mainWindow.focus();
  mainWindow.webContents.send('ui:open-match', { file: summaryData?.matchFile || null });
});

ipcMain.handle('ocr:feed', async (_event, base64) => {
  if (!store?.settings.killFeed) return [];
  if (typeof base64 !== 'string' || base64.length < 200) return [];

  const names = ownNames();
  // Ohne eigenen Namen kein Abgleich moeglich – das Panel einmal darauf hinweisen.
  if (names.length === 0) {
    if (Date.now() - lastFeedDiag > 60000) {
      lastFeedDiag = Date.now();
      mainWindow?.webContents.send('live:diag', { reason: 'no-name' });
    }
    return [];
  }

  // Diagnose: FNPANEL_FEED_DUMP=<pfad> legt das Bild ab, das die Erkennung sieht.
  if (process.env.FNPANEL_FEED_DUMP) {
    try {
      const base = process.env.FNPANEL_FEED_DUMP.replace(/\.png$/i, '');
      fs.writeFileSync(path.resolve(`${base}-${Date.now()}.png`), Buffer.from(base64, 'base64'));
    } catch {
      /* Diagnose darf nie stoeren */
    }
  }

  const started = Date.now();
  const text = await ocr.readText(Buffer.from(base64, 'base64'));
  // Diagnose: FNPANEL_FEED_TRACE=1 zeigt, was wirklich im Feed gelesen wurde.
  if (process.env.FNPANEL_FEED_TRACE) {
    console.log('[feed:ocr]', `${Date.now() - started}ms`, JSON.stringify(String(text).replace(/\s+/g, ' | ').slice(0, 200)));
  }
  if (!text) return [];

  const victims = [];
  for (const hit of freshFeedHits(text, names)) {
    if (handleLiveKill(hit.victimName, hit.state)) victims.push(hit.victimName);
  }
  clipDiag('feed', text, victims.length ? `Kill erkannt: ${victims.join(', ')}` : '');
  return victims;
});

/*
 * Meldung in der Bildmitte: Fortnite blendet sie nur bei EIGENEN Kills ein
 * („ELIMINIERT Name“ / „ELIMINATED Name“ / „Du hast Name eliminiert“). Sie
 * braucht keinen eigenen Namen und ist deshalb die zuverlässigere Quelle.
 */
const ELIM_WORD = /(el[i1l]m[i1l]n[a-z]{0,6}|ausgeschaltet|ausgel[o0]scht|erledigt)/i;
const KNOCK_WORD = /(kn[o0]ck|niedergeschlagen|zu\s*b[o0]den|down)/i;
let lastElimAt = 0;

ipcMain.handle('ocr:elim', async (_event, base64, kind) => {
  const where = kind === 'xp' ? 'xp' : 'elim';
  if (!store?.settings.clipOnKill) return false;
  if (typeof base64 !== 'string' || base64.length < 200) return false;
  // Eigener Texterkennungs-Worker für Kill-Meldungen: er wartet nie hinter
  // dem Sieg- oder Rang-Scan, so kommt der Kill schneller an.
  const text = await ocr.readScreenText(Buffer.from(base64, 'base64'), 'hud');
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (!clean) return false;
  // „Eliminiert von …“ / „Eliminated by …“ ist der eigene Tod, kein Kill.
  if (!ELIM_WORD.test(clean) || KNOCK_WORD.test(clean) || /\b(by|von|durch)\b|kamerad|assist|mithilfe|unterst/i.test(clean)) {
    clipDiag(where, clean, '');
    return false;
  }
  const now = Date.now();
  // Die Meldung steht 2–3 s im Bild und wird dabei mehrmals gelesen.
  if (now - lastElimAt < 3500) {
    lastElimAt = now;
    return false;
  }
  lastElimAt = now;
  // Opfer: steht unter „ELIMINIERUNG!“ (bzw. hinter „ELIMINATED“). Unsicher
  // gelesene Namen werden nicht übernommen – dann heißt der Clip „Gegner“.
  let victim = 'Gegner';
  if (where === 'elim') {
    const match = /el[i1l]m[i1l]n[a-z]*[!i1l]?\s+([A-Za-z0-9_.-]{3,24})/i.exec(clean);
    if (match && isPlausibleName(match[1]) && /[a-z]/.test(match[1]) && /[A-Z]|[0-9_]/.test(match[1])) victim = match[1];
  }
  clipDiag(where, clean, `Kill erkannt (${where === 'xp' ? 'XP-Meldung' : 'Bildmitte'}): ${victim}`);
  if (!handleLiveKill(victim, 'dead')) scheduleKillClip(victim);
  return true;
});

/* ---------------- Diagnose: was liest die Erkennung? ----------------
 * Alles landet in <userData>/clip-debug: ocr.log (gelesene Texte) und alle
 * 20 s ein Kontrollbild samt der Ausschnitte. So lässt sich prüfen, ob die
 * Erkennung an der richtigen Stelle schaut.
 */
let lastDiagLog = { feed: '', elim: '', xp: '', win: '', kill: '' };

function clipDebugDir() {
  const dir = path.join(app.getPath('userData'), 'clip-debug');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function clipDiag(kind, text, event) {
  const line = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  if (event) mainWindow?.webContents.send('clip:diag', { kind, text: event });
  else if (line) mainWindow?.webContents.send('clip:diag', { kind, text: `liest (${kind}): ${line.slice(0, 90)}` });
  if (!line && !event) return;
  if (!event && line === lastDiagLog[kind]) return;
  lastDiagLog[kind] = line;
  try {
    const file = path.join(clipDebugDir(), 'ocr.log');
    if (fs.existsSync(file) && fs.statSync(file).size > 2 * 1024 * 1024) fs.renameSync(file, file + '.old');
    const stamp = new Date().toLocaleString('sv-SE');
    fs.appendFileSync(file, `${stamp} [${kind}] ${event ? '>>> ' + event + ' | ' : ''}${line}\n`);
  } catch {
    /* Diagnose darf nie stören */
  }
}

ipcMain.on('clip:debug', (_event, payload) => {
  try {
    const dir = clipDebugDir();
    const write = (name, data) => {
      if (typeof data === 'string' && data.length > 100) fs.writeFileSync(path.join(dir, name), Buffer.from(data, 'base64'));
    };
    write('frame.jpg', payload?.frame);
    write('feed.png', payload?.feed);
    write('elim.png', payload?.elim);
    write('xp.png', payload?.xp);
    write('win.png', payload?.win);
    fs.writeFileSync(
      path.join(dir, 'info.json'),
      JSON.stringify(
        {
          at: new Date().toISOString(),
          width: payload?.width,
          height: payload?.height,
          source: store?.settings.clipSourceId,
          fortniteRunning,
          ownNames: ownNames(),
          clipOnKill: store?.settings.clipOnKill,
          killFeed: store?.settings.killFeed,
          bufferLive: bufferLive(),
          liveKills,
        },
        null,
        2,
      ),
    );
  } catch {
    /* egal */
  }
});

ipcMain.on('overlay:hide', () => hideOverlayIfIdle());

ipcMain.handle('ocr:frame', async (_event, base64) => {
  if (!store?.settings.damageOcr) return [];
  if (typeof base64 !== 'string' || base64.length < 200) return [];

  const numbers = await ocr.readNumbers(Buffer.from(base64, 'base64'));
  if (numbers.length === 0) return [];

  const now = Date.now();
  for (const value of numbers) {
    damageLog.push({ t: now, value });
  }
  ocrNumbers += numbers.length;

  const cutoff = now - 3 * 60 * 60 * 1000;
  while (damageLog.length > 0 && damageLog[0].t < cutoff) damageLog.shift();
  if (damageLog.length > 30000) damageLog.splice(0, damageLog.length - 30000);

  mainWindow?.webContents.send('ocr:numbers', { numbers, total: ocrNumbers });
  return numbers;
});

ipcMain.handle('settings:save', (_event, patch) => {
  const next = { ...store.settings };
  if (typeof patch?.displayName === 'string') next.displayName = patch.displayName.slice(0, 60);
  if (typeof patch?.replayDir === 'string' && patch.replayDir.trim().length > 0) {
    next.replayDir = patch.replayDir.trim();
  }
  if (typeof patch?.autoScan === 'boolean') next.autoScan = patch.autoScan;
  if (typeof patch?.matchSummary === 'boolean') next.matchSummary = patch.matchSummary;
  if (typeof patch?.clipAutoStart === 'boolean') next.clipAutoStart = patch.clipAutoStart;
  if (typeof patch?.clipAutoSave === 'boolean') next.clipAutoSave = patch.clipAutoSave;
  if (typeof patch?.killPopup === 'boolean') next.killPopup = patch.killPopup;
  if (typeof patch?.damageOcr === 'boolean') next.damageOcr = patch.damageOcr;
  if (typeof patch?.killFeed === 'boolean') next.killFeed = patch.killFeed;
  if (typeof patch?.knockDetection === 'boolean') next.knockDetection = patch.knockDetection;
  if (typeof patch?.liveMonitor === 'boolean') next.liveMonitor = patch.liveMonitor;
  if (typeof patch?.liveSourceId === 'string') next.liveSourceId = patch.liveSourceId;
  if (patch?.crosshair && typeof patch.crosshair === 'object') {
    next.crosshair = normalizeCrosshair(patch.crosshair);
  }
  if (patch?.clipMaxGb !== undefined) {
    const value = Number(patch.clipMaxGb);
    if (Number.isFinite(value)) next.clipMaxGb = Math.min(50, Math.max(0.5, Math.round(value * 10) / 10));
  }
  if (patch?.clipSeconds !== undefined) {
    const value = Number(patch.clipSeconds);
    if (Number.isFinite(value)) next.clipSeconds = Math.min(120, Math.max(10, Math.round(value)));
  }
  if (typeof patch?.clipHotkey === 'string' && patch.clipHotkey.trim().length > 0) {
    next.clipHotkey = patch.clipHotkey.trim().slice(0, 32);
  }
  if (typeof patch?.clipSourceId === 'string') next.clipSourceId = patch.clipSourceId;
  if (typeof patch?.clipMicId === 'string') next.clipMicId = patch.clipMicId.slice(0, 200);
  if (typeof patch?.camDeviceId === 'string') next.camDeviceId = patch.camDeviceId.slice(0, 300);
  if (typeof patch?.camEnabled === 'boolean') next.camEnabled = patch.camEnabled;
  if (typeof patch?.recHotkey === 'string' && patch.recHotkey.trim()) next.recHotkey = patch.recHotkey.trim().slice(0, 32);
  for (const key of ['clipMicVolume', 'clipSystemVolume']) {
    if (patch?.[key] === undefined) continue;
    const value = Number(patch[key]);
    if (Number.isFinite(value)) next[key] = Math.min(200, Math.max(0, Math.round(value)));
  }
  if (patch?.clipKillPost !== undefined) {
    const value = Number(patch.clipKillPost);
    if (Number.isFinite(value)) next.clipKillPost = Math.min(10, Math.max(0.5, Math.round(value * 2) / 2));
  }
  if (patch?.clipKillSeconds !== undefined) {
    const value = Number(patch.clipKillSeconds);
    if (Number.isFinite(value)) next.clipKillSeconds = Math.min(60, Math.max(5, Math.round(value)));
  }
  for (const key of [
    'clipOnKill',
    'clipOnWin',
    'clipAutoGame',
    'clipBurnCrosshair',
    'clipKeystrokes',
    'clipKeystrokesController',
    'clipKeysShow',
    'clipAudio',
    'clipMic',
    'clipHotkeyEnabled',
  ]) {
    if (typeof patch?.[key] === 'boolean') next[key] = patch[key];
  }
  if (patch?.clipFps !== undefined) {
    const value = Number(patch.clipFps);
    if (Number.isFinite(value)) next.clipFps = value >= 60 ? 60 : 30;
  }
  if (typeof patch?.clipQuality === 'string') {
    next.clipQuality = ['niedrig', 'mittel', 'hoch'].includes(patch.clipQuality)
      ? patch.clipQuality
      : 'hoch';
  }

  const hotkeyChanged =
    next.recHotkey !== store.settings.recHotkey ||
    next.clipHotkey !== store.settings.clipHotkey ||
    next.clipHotkeyEnabled !== store.settings.clipHotkeyEnabled;
  store.data.settings = next;
  store.flush();
  if (hotkeyChanged) {
    registerClipHotkey();
    registerRecHotkey();
  }

  refreshOverlayVisibility();
  updateClipperOverlay();
  mainWindow?.webContents.send('xh:state', xhState());

  return buildState();
});

ipcMain.handle('dialog:pickReplayDir', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Fortnite Replay-Ordner wählen',
    properties: ['openDirectory'],
  });
  if (result.canceled || result.filePaths.length === 0) {
    return buildState();
  }
  store.data.settings.replayDir = result.filePaths[0];
  store.flush();
  return buildState();
});

ipcMain.handle('shell:openPath', async (_event, target) => {
  if (typeof target !== 'string' || target.length === 0) {
    return false;
  }
  const allowedRoots = [replayDir(), clipsDir(), path.dirname(store.file)];
  const resolved = path.resolve(target);
  const allowed = allowedRoots.some((root) => root && resolved.startsWith(path.resolve(root)));
  if (!allowed) {
    return false;
  }
  const error = await shell.openPath(resolved);
  return error === '';
});

ipcMain.handle('matches:clear', () => {
  store.clearMatches();
  return buildState();
});

/* ---------------- IPC: Clips ---------------- */

ipcMain.handle('capture:sources', async () => {
  try {
    const sources = await desktopCapturer.getSources({
      types: ['window', 'screen'],
      thumbnailSize: { width: 320, height: 180 },
      fetchWindowIcons: false,
    });
    const primaryId = String(screen.getPrimaryDisplay().id);
    return sources.map((source) => ({
      id: source.id,
      name: source.name,
      kind: source.id.startsWith('screen') ? 'screen' : 'window',
      displayId: source.displayId || '',
      primary: source.id.startsWith('screen') && String(source.displayId) === primaryId,
      thumbnail: source.thumbnail?.isEmpty() ? null : source.thumbnail.toDataURL(),
    }));
  } catch (error) {
    return { error: error.message };
  }
});

/*
 * Ringpuffer der Aufnahme. Der Renderer liefert jede Sekunde ein Stück des
 * laufenden MediaRecorder-Streams; hier liegen immer nur so viele Sekunden,
 * wie ein Clip (plus zusammengefasste Kills) braucht.
 */
// Nachlauf nach dem letzten Kill (einstellbar, Standard 2 s). Kurz halten:
// erst danach wird geschrieben und der Haken erscheint.
function killPostMs() {
  const value = Number(store?.settings?.clipKillPost);
  return Math.round(Math.min(10, Math.max(0.5, Number.isFinite(value) ? value : 2)) * 1000);
}
const KILL_MERGE_MAX_S = 30; // Kills innerhalb dieser Spanne landen in einem Clip
const WIN_POST_MS = 7000; // Jubel nach „Victory Royale“ noch mitnehmen

function preSeconds(key, fallback) {
  const value = Number(store?.settings?.[key]);
  return Math.min(120, Math.max(5, Number.isFinite(value) && value > 0 ? value : fallback));
}

function bufferWindowMs() {
  const longest = Math.max(preSeconds('clipSeconds', 30), preSeconds('clipKillSeconds', 15) + KILL_MERGE_MAX_S);
  return (longest + 15) * 1000 + WIN_POST_MS;
}

/** Kommen gerade Daten vom Recorder? Nur dann lohnt sich ein Clip. */
function bufferLive() {
  const last = clipBuffer.chunks[clipBuffer.chunks.length - 1];
  return Boolean(clipBuffer.header && last && Date.now() - last.t < 5000);
}

ipcMain.on('clip:chunk', (_event, payload) => {
  if (!payload?.buffer) return;
  // Der IPC-Puffer gehört nach dem Empfang schon uns: ein Buffer.from würde
  // jedes Megabyte-Segment ein zweites Mal in den Speicher legen.
  const view = payload.buffer;
  const buffer = Buffer.from(view.buffer, view.byteOffset, view.byteLength);
  if (payload.isFirst || !clipBuffer.header) {
    clipBuffer.header = buffer;
  }
  clipBuffer.chunks.push({ t: Date.now(), buffer });
  if (longRec) appendRec(longRec.screen, buffer, payload.isFirst);

  const cutoff = Date.now() - bufferWindowMs();
  while (clipBuffer.chunks.length > 0 && clipBuffer.chunks[0].t < cutoff) {
    clipBuffer.chunks.shift();
  }
});

/* ---------------- Facecam-Puffer ----------------
 * Die Webcam läuft als eigener Recorder mit eigenem Ringpuffer. Jeder Clip
 * bekommt daneben eine eigene Cam-Datei, damit sie sich im Player nachträglich
 * verschieben, vergrößern und abschalten lässt. */
let camBuffer = { header: null, chunks: [], ext: 'webm' };

ipcMain.on('cam:chunk', (_event, payload) => {
  if (!payload?.buffer) return;
  const view = payload.buffer;
  const buffer = Buffer.from(view.buffer, view.byteOffset, view.byteLength);
  if (payload.isFirst || !camBuffer.header) camBuffer.header = buffer;
  camBuffer.chunks.push({ t: Date.now(), buffer });
  const cutoff = Date.now() - bufferWindowMs();
  while (camBuffer.chunks.length > 0 && camBuffer.chunks[0].t < cutoff) camBuffer.chunks.shift();
  // Cam kam erst nach dem Start der langen Aufnahme: ab jetzt mitschreiben.
  if (longRec && !longRec.cam) longRec.cam = openRecPart(longRec.base, 'cam', camBuffer.ext);
  if (longRec?.cam) appendRec(longRec.cam, buffer, payload.isFirst);
});

ipcMain.handle('cam:reset', (_event, options) => {
  camBuffer = { header: null, chunks: [], ext: options?.ext === 'mp4' ? 'mp4' : 'webm' };
  return true;
});

ipcMain.handle('cam:stop', () => {
  camBuffer = { header: null, chunks: [], ext: camBuffer.ext };
  return true;
});

/** Cam-Stück zum Zeitraum eines Clips schreiben; liefert die Meta-Angaben. */
async function writeCamPart(name, startWall, endWall) {
  if (!camBuffer.header) return null;
  const keep = camBuffer.chunks.filter((chunk) => chunk.t > startWall && chunk.t <= endWall + 1200 && chunk.buffer !== camBuffer.header);
  if (keep.length < 1) return null;
  const camName = `${name.replace(CLIP_VIDEO, '')}.cam.${camBuffer.ext}`;
  try {
    const total = camBuffer.header.length + keep.reduce((sum, chunk) => sum + chunk.buffer.length, 0);
    const payload = Buffer.allocUnsafe(total);
    let offset = camBuffer.header.copy(payload, 0);
    for (const chunk of keep) offset += chunk.buffer.copy(payload, offset);
    rebaseClip(payload, camBuffer.ext);
    if (camBuffer.ext === 'mp4') patchMp4Duration(payload, { inPlace: true });
    await fs.promises.writeFile(path.join(clipsDir(), camName), payload);
  } catch (error) {
    console.log('[cam] nicht geschrieben:', error.message);
    return null;
  }
  return { file: camName, offsetMs: keep[0].t - 1000 - startWall, ...CAM_DEFAULT };
}

const CAM_DEFAULT = { x: 0.74, y: 0.06, w: 0.24, visible: true, round: false };

/* ---------------- Lange Aufnahmen ----------------
 * Schreibt die laufende Aufnahme direkt auf die Platte, bis sie gestoppt wird
 * (kein Speicherlimit). Zum Schluss setzt ffmpeg die Datei ohne Neukodierung
 * sauber zusammen (richtige Länge, spulbar). */
let longRec = null;

function ffmpegExe() {
  const exe = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  const candidates = [path.join(process.resourcesPath || '', 'ffmpeg', exe), path.join(ROOT, '..', '..', 'vendor', 'ffmpeg', exe)];
  return candidates.find((file) => fs.existsSync(file)) || null;
}

function openRecPart(base, kind, ext) {
  const file = path.join(clipsDir(), `${base}${kind === 'cam' ? '.cam' : ''}.part.${ext}`);
  return { kind, ext, file, stream: fs.createWriteStream(file), started: 0, bytes: 0 };
}

function appendRec(part, buffer, isFirst) {
  if (!part.stream) return;
  if (!part.started) {
    // Erstes Stück: Kopf der laufenden Aufnahme, dann alles ab jetzt.
    const header = part.kind === 'cam' ? camBuffer.header : clipBuffer.header;
    if (!header) return;
    part.stream.write(header);
    part.started = Date.now();
    if (isFirst || buffer === header) return;
  }
  part.stream.write(buffer);
  part.bytes += buffer.length;
}

function recState() {
  return {
    active: Boolean(longRec),
    since: longRec?.startedAt || 0,
    cam: Boolean(longRec?.cam),
    bytes: longRec ? longRec.screen.bytes + (longRec.cam?.bytes || 0) : 0,
    hotkey: store?.settings.recHotkey || 'F10',
  };
}

function pushRecState() {
  mainWindow?.webContents.send('rec:state', recState());
}

function startLongRec() {
  if (longRec) return recState();
  if (!bufferLive()) return { ...recState(), error: 'Die Aufnahme läuft nicht – starte sie zuerst im Clips-Tab.' };
  const stamp = new Date().toLocaleString('sv-SE').replace(' ', '_').replace(/[:]/g, '-');
  const base = `aufnahme-${stamp}`;
  longRec = {
    base,
    startedAt: Date.now(),
    screen: openRecPart(base, 'screen', clipBuffer.ext),
    cam: camBuffer.header ? openRecPart(base, 'cam', camBuffer.ext) : null,
  };
  console.log('[rec] gestartet', base);
  pushRecState();
  return recState();
}

function remux(input, output) {
  const exe = ffmpegExe();
  if (!exe) return Promise.resolve(false);
  return new Promise((resolve) => {
    execFile(
      exe,
      ['-hide_banner', '-loglevel', 'error', '-y', '-fflags', '+genpts', '-i', input, '-c', 'copy', '-avoid_negative_ts', 'make_zero', ...(/\.mp4$/i.test(output) ? ['-movflags', '+faststart'] : []), output],
      { windowsHide: true, timeout: 30 * 60 * 1000 },
      (error) => resolve(!error && fs.existsSync(output)),
    );
  });
}

async function finishPart(part, target) {
  await new Promise((resolve) => part.stream.end(resolve));
  if (!part.started || part.bytes < 10000) {
    fs.rmSync(part.file, { force: true });
    return false;
  }
  if (await remux(part.file, target)) fs.rmSync(part.file, { force: true });
  else fs.renameSync(part.file, target);
  return true;
}

async function stopLongRec() {
  const rec = longRec;
  if (!rec) return recState();
  longRec = null;
  pushRecState();
  mainWindow?.webContents.send('rec:saving', { saving: true });
  const name = `${rec.base}.${rec.screen.ext}`;
  try {
    const ok = await finishPart(rec.screen, path.join(clipsDir(), name));
    if (!ok) return { ...recState(), error: 'Die Aufnahme war leer.' };
    let cam = null;
    if (rec.cam) {
      const camName = `${rec.base}.cam.${rec.cam.ext}`;
      if (await finishPart(rec.cam, path.join(clipsDir(), camName))) {
        cam = { file: camName, offsetMs: rec.cam.started - rec.screen.started, ...CAM_DEFAULT };
      }
    }
    const minutes = Math.max(1, Math.round((Date.now() - rec.startedAt) / 60000));
    writeClipMeta(name, {
      version: 3,
      category: 'recording',
      title: `Aufnahme · ${minutes} min`,
      createdAt: rec.startedAt,
      keys: [],
      showKeys: false,
      ...(cam ? { cam } : {}),
    });
    console.log('[rec] gespeichert', name);
    const clips = listClips();
    mainWindow?.webContents.send('clips:changed', { clips, usage: clipUsage(), saved: { name, category: 'recording' } });
    flashClipCheck();
    return { ...recState(), saved: name };
  } finally {
    mainWindow?.webContents.send('rec:saving', { saving: false });
  }
}

ipcMain.handle('rec:toggle', () => (longRec ? stopLongRec() : startLongRec()));
ipcMain.handle('rec:stop', () => stopLongRec());
ipcMain.handle('rec:state', () => recState());

let registeredRecHotkey = null;
function registerRecHotkey() {
  if (registeredRecHotkey) {
    globalShortcut.unregister(registeredRecHotkey);
    registeredRecHotkey = null;
  }
  const accelerator = store?.settings.recHotkey || 'F10';
  try {
    if (globalShortcut.register(accelerator, oncePerPress('rec', () => (longRec ? stopLongRec() : startLongRec()), 800))) registeredRecHotkey = accelerator;
  } catch {
    registeredRecHotkey = null;
  }
}

ipcMain.handle('clip:reset', (_event, options) => {
  // Format merken: Auto-Clips (Kill, Sieg) schreibt der Hauptprozess und muss
  // dieselbe Endung nutzen wie die Aufnahme – sonst liegt ein MP4 als .webm auf
  // der Platte und Player zeigen eine endlose Länge.
  // Neuer Recorder (z. B. Ton umgestellt): eine laufende lange Aufnahme sauber abschließen.
  if (longRec) stopLongRec().catch(() => {});
  clipBuffer = { header: null, chunks: [], ext: options?.ext === 'mp4' ? 'mp4' : 'webm' };
  return true;
});

/* Schreibvorgänge nacheinander: zwei Kills kurz hintereinander dürfen nicht
 * gleichzeitig je 100 MB zusammensetzen – und keiner darf verloren gehen. */
let clipQueue = Promise.resolve();

function queueClip(job) {
  const run = clipQueue.then(() => writeClip(job));
  clipQueue = run.catch(() => undefined);
  return run;
}

function clipFileName(category, victims, ext) {
  const stamp = new Date().toLocaleString('sv-SE').replace(' ', '_').replace(/[:]/g, '-');
  let prefix = 'clip';
  if (category === 'win') prefix = 'sieg';
  else if (category === 'kill') prefix = victims.length > 1 ? `kill-${victims.length}x` : `kill-${victims[0] || 'gegner'}`;
  const base = `${prefix}-${stamp}`.replace(/[^\w.\-]+/g, '-');
  let name = base + (ext === 'mp4' ? '.mp4' : '.webm');
  let counter = 2;
  while (fs.existsSync(path.join(clipsDir(), name))) {
    name = `${base}-${counter}` + (ext === 'mp4' ? '.mp4' : '.webm');
    counter += 1;
  }
  return name;
}

async function writeClip({
  seconds,
  category = 'manual',
  title = '',
  victims = [],
  kills = 0,
  ext = clipBuffer.ext,
} = {}) {
  const now = Date.now();
  const span = Math.min(180, Math.max(5, Number(seconds) || 30)) * 1000;
  // Der erste Block steckt schon im Header – doppelt geschrieben bricht die Datei
  // nach dem ersten Abschnitt ab (Player zeigen dann nur ~1 Sekunde).
  const keep = clipBuffer.chunks.filter((chunk) => chunk.t >= now - span && chunk.buffer !== clipBuffer.header);

  if (!clipBuffer.header || keep.length === 0) {
    return { ok: false, reason: 'empty-buffer' };
  }

  const kind = CLIP_CATEGORIES.includes(category) ? category : 'manual';
  const name = clipFileName(kind, victims, ext);
  const full = path.join(clipsDir(), name);

  try {
    // Ein einziger Zielpuffer: Buffer.concat plus die Kopie im MP4-Patcher
    // trieben den Speicher auf das Dreifache der Clipgröße.
    const total = clipBuffer.header.length + keep.reduce((sum, chunk) => sum + chunk.buffer.length, 0);
    const payload = Buffer.allocUnsafe(total);
    let offset = clipBuffer.header.copy(payload, 0);
    for (const chunk of keep) offset += chunk.buffer.copy(payload, offset);

    // MediaRecorder lässt die Gesamtdauer im MP4 leer – Player zeigen dann eine
    // falsche (viel zu lange) Länge. Die echte Dauer wird hier nachgetragen.
    // Zeitstempel auf 0 setzen – sonst beginnt der Clip bei „5:00“ und das
    // Spulen im Player springt ins Leere.
    rebaseClip(payload, ext);
    if (ext === 'mp4') patchMp4Duration(payload, { inPlace: true });
    // Asynchron schreiben: 100 MB synchron blockierten die Oberfläche für
    // Sekunden – das sah aus wie ein Absturz.
    await fs.promises.writeFile(full, payload);
  } catch (error) {
    return { ok: false, reason: 'write-error', error: error.message };
  }

  // Zeitachse des Clips: Jedes Stück kommt am Ende seiner Sekunde an. Der
  // Player rechnet vom Ende her zurück – das passt auch, wenn der Header noch
  // ein Stück vom Aufnahmestart enthält.
  const endWall = keep[keep.length - 1].t;
  const startWall = keep[0].t - 1000;
  const keys = keysBetween(startWall, endWall);
  const cam = await writeCamPart(name, startWall, endWall);
  writeClipMeta(name, {
    ...(cam ? { cam } : {}),
    version: 3,
    category: kind,
    title: String(title || '').slice(0, 80),
    victims: victims.slice(0, 10),
    kills: Number(kills) || victims.length || 0,
    createdAt: now,
    startWall,
    endWall,
    keysSpan: endWall - startWall,
    keys,
    showKeys: store.settings.clipKeysShow !== false,
  });

  const usage = pruneClips();
  clipSessionCount += 1;
  const bytes = fs.existsSync(full) ? fs.statSync(full).size : 0;
  // Nur der kleine Haken unten links – und erst jetzt, wo die Datei fertig ist.
  flashClipCheck();
  // Revolution Hub: the island reports the clip; the video editor suggests it.
  try {
    const label = kind === 'win' ? 'Sieg-Clip gespeichert' : kind === 'kill' ? 'Kill-Clip gespeichert' : 'Clip gespeichert';
    global.__revolutionHub?.hub?.notify(label, `${Math.round(bytes / 1048576)} MB · im Video-Schnitt bereit`, {
      app: 'Gaming Hub',
      icon: fs.existsSync(clipThumbPath(name)) ? clipThumbPath(name) : undefined,
      open: full,
    });
  } catch {
    /* standalone Gaming Hub */
  }
  const clips = listClips();
  mainWindow?.webContents.send('clips:changed', { clips, usage, saved: { name, category: kind, bytes } });
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('xh:state', xhState());
  console.log('[clip]', kind, name, Math.round(bytes / 1024 / 1024) + ' MB');
  return { ok: true, name, path: full, bytes, usage, clips, category: kind };
}

/* ---------------- Automatik: Kills ---------------- */

let killClip = null; // { first, victims, timer }

function flushKillClip() {
  const job = killClip;
  killClip = null;
  if (!job) return;
  clearTimeout(job.timer);
  const seconds = preSeconds('clipKillSeconds', 15) + (Date.now() - job.first) / 1000;
  queueClip({
    seconds,
    category: 'kill',
    victims: job.victims,
    kills: job.victims.length,
    title: job.victims.length > 1 ? `${job.victims.length} Kills` : `Kill · ${job.victims[0]}`,
  });
}

/**
 * Ein Kill startet den Clip nicht sofort: ein paar Sekunden danach gehören
 * noch dazu, und weitere Kills in kurzer Folge landen im selben Clip.
 */
const recentKills = []; // { name, at } – derselbe Kill kommt aus Feed UND Bildmitte

function sameKill(a, b) {
  const left = String(a || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const right = String(b || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!left || !right || left === 'gegner' || right === 'gegner') return true;
  if (left === right || left.includes(right) || right.includes(left)) return true;
  return distance(left, right) <= Math.max(2, Math.floor(Math.max(left.length, right.length) * 0.35));
}

function scheduleKillClip(victim) {
  const now = Date.now();
  const name = String(victim || 'Gegner').slice(0, 32);
  while (recentKills.length && now - recentKills[0].at > 8000) recentKills.shift();
  if (recentKills.some((entry) => sameKill(entry.name, name))) return;
  recentKills.push({ name, at: now });
  if (!bufferLive()) {
    clipDiag('kill', '', `Kill erkannt (${name}), aber die Aufnahme läuft nicht`);
    return;
  }
  if (!killClip) killClip = { first: now, victims: [], timer: null };
  killClip.victims.push(name);
  clearTimeout(killClip.timer);
  const tooLong = now - killClip.first > KILL_MERGE_MAX_S * 1000;
  killClip.timer = setTimeout(flushKillClip, tooLong ? 800 : killPostMs());
}

/* ---------------- Automatik: Sieg ---------------- */

let lastWinAt = 0;
let victoryHits = [];
const VICTORY_TEXT = /(v[i1l]ct[o0]r[yv]|sieg)\s*r[o0][yv]a[l1]e?/i;

function triggerWinClip() {
  if (!store.settings.clipOnWin || !bufferLive()) return false;
  if (Date.now() - lastWinAt < 3 * 60 * 1000) return false;
  lastWinAt = Date.now();
  // Ein offener Kill-Clip wird vorher noch geschrieben.
  if (killClip) flushKillClip();
  setTimeout(() => {
    queueClip({
      seconds: preSeconds('clipSeconds', 30) + WIN_POST_MS / 1000,
      category: 'win',
      title: 'Victory Royale',
      kills: liveKills,
    });
  }, WIN_POST_MS);
  return true;
}

ipcMain.handle('ocr:victory', async (_event, base64) => {
  if (!store?.settings.clipOnWin || !fortniteRunning) return false;
  if (typeof base64 !== 'string' || base64.length < 200) return false;
  if (Date.now() - lastWinAt < 3 * 60 * 1000) return false;
  const text = await ocr.readScreenText(Buffer.from(base64, 'base64'), 'screen');
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (clean) clipDiag('win', clean, '');
  // Der Sieg-Schriftzug steht groß und fast allein im Bild. Viel Text drumherum
  // (z. B. Aufträge in der Lobby: „Hol dir einen Victory Royale“) zählt nicht.
  if (!VICTORY_TEXT.test(clean) || clean.replace(/[^a-z0-9]/gi, '').length > 90) return false;
  const now = Date.now();
  victoryHits = victoryHits.filter((at) => now - at < 8000);
  victoryHits.push(now);
  // Zwei Treffer kurz hintereinander: ein einzelnes Fehlbild reicht nicht.
  if (victoryHits.length < 2) return false;
  victoryHits = [];
  console.log('[clip] Victory Royale erkannt');
  return triggerWinClip();
});

ipcMain.handle('clip:save', async (_event, options) => {
  const seconds = Math.min(120, Math.max(5, Number(options?.seconds) || store.settings.clipSeconds));
  const ext = options?.ext === 'mp4' ? 'mp4' : 'webm';
  try {
    return await queueClip({ seconds, category: 'manual', ext });
  } catch (error) {
    return { ok: false, reason: 'write-error', error: error.message };
  }
});

ipcMain.handle('clips:list', () => ({ clips: listClips(), usage: clipUsage() }));

ipcMain.handle('clip:delete', (_event, name) => {
  const safe = safeClipName(name);
  if (safe) removeClipFiles(safe);
  return { clips: listClips(), usage: clipUsage() };
});

ipcMain.handle('clips:deleteMany', (_event, names) => {
  for (const name of Array.isArray(names) ? names.slice(0, 2000) : []) {
    const safe = safeClipName(name);
    if (safe) removeClipFiles(safe);
  }
  return { clips: listClips(), usage: clipUsage() };
});

ipcMain.handle('clips:clear', (_event, category) => {
  for (const clip of listClips()) {
    if (category && CLIP_CATEGORIES.includes(category) && clip.category !== category) continue;
    // Favoriten bleiben beim „Alle löschen“ stehen.
    if (clip.favorite) continue;
    removeClipFiles(clip.name);
  }
  return { clips: listClips(), usage: clipUsage() };
});

/** Tasten-Zeitleiste und Anzeige-Schalter eines Clips. */
ipcMain.handle('clip:info', (_event, name) => {
  const safe = safeClipName(name);
  if (!safe) return null;
  const meta = readClipMeta(safe);
  return {
    name: safe,
    category: CLIP_CATEGORIES.includes(meta.category) ? meta.category : guessCategory(safe),
    keys: Array.isArray(meta.keys) ? meta.keys : [],
    keysSpan: Number(meta.keysSpan) || 0,
    showKeys: meta.showKeys !== false,
    burned: Boolean(meta.burned),
    title: meta.title || '',
    favorite: meta.favorite === true,
    keysPos: meta.keysPos && Number.isFinite(meta.keysPos.x) && Number.isFinite(meta.keysPos.y) ? meta.keysPos : null,
    keysScale: Number(meta.keysScale) || 1,
    cam: meta.cam?.file && fs.existsSync(path.join(clipsDir(), path.basename(meta.cam.file))) ? { ...CAM_DEFAULT, ...meta.cam } : null,
  };
});

ipcMain.handle('clip:setMeta', (_event, name, patch) => {
  const safe = safeClipName(name);
  if (!safe || !fs.existsSync(path.join(clipsDir(), safe))) return null;
  const meta = readClipMeta(safe);
  if (typeof patch?.showKeys === 'boolean') meta.showKeys = patch.showKeys;
  if (typeof patch?.title === 'string') meta.title = patch.title.slice(0, 80);
  if (typeof patch?.favorite === 'boolean') meta.favorite = patch.favorite;
  if (patch?.keysPos === null) delete meta.keysPos;
  else if (patch?.keysPos && Number.isFinite(Number(patch.keysPos.x)) && Number.isFinite(Number(patch.keysPos.y))) {
    meta.keysPos = {
      x: Math.min(1, Math.max(0, Number(patch.keysPos.x))),
      y: Math.min(1, Math.max(0, Number(patch.keysPos.y))),
    };
  }
  if (patch?.keysScale !== undefined && Number.isFinite(Number(patch.keysScale))) {
    meta.keysScale = Math.min(2.5, Math.max(0.4, Number(patch.keysScale)));
  }
  if (patch?.cam && meta.cam) {
    const c = patch.cam;
    const clamp01 = (v, lo, hi) => Math.min(hi, Math.max(lo, Number(v)));
    if (Number.isFinite(Number(c.x))) meta.cam.x = clamp01(c.x, 0, 1);
    if (Number.isFinite(Number(c.y))) meta.cam.y = clamp01(c.y, 0, 1);
    if (Number.isFinite(Number(c.w))) meta.cam.w = clamp01(c.w, 0.08, 0.6);
    if (typeof c.visible === 'boolean') meta.cam.visible = c.visible;
    if (typeof c.round === 'boolean') meta.cam.round = c.round;
  }
  if (patch?.category && CLIP_CATEGORIES.includes(patch.category)) meta.category = patch.category;
  if (!meta.category) meta.category = guessCategory(safe);
  writeClipMeta(safe, meta);
  return { clips: listClips(), usage: clipUsage() };
});

ipcMain.handle('clip:thumb', (_event, name, base64) => {
  const safe = safeClipName(name);
  if (!safe || typeof base64 !== 'string' || base64.length < 100 || base64.length > 2_000_000) return false;
  try {
    fs.writeFileSync(clipThumbPath(safe), Buffer.from(base64, 'base64'));
    return true;
  } catch {
    return false;
  }
});

/** Export mit eingebrannten Keystrokes: der Renderer liefert das fertige Video. */
ipcMain.handle('clip:exportSave', async (_event, source, data, ext) => {
  const safe = safeClipName(source);
  if (!safe || !data) return { ok: false };
  const view = data;
  const buffer = Buffer.from(view.buffer, view.byteOffset, view.byteLength);
  const type = ext === 'mp4' ? 'mp4' : 'webm';
  const base = safe.replace(CLIP_VIDEO, '') + '-export';
  let name = `${base}.${type}`;
  let counter = 2;
  while (fs.existsSync(path.join(clipsDir(), name))) {
    name = `${base}-${counter}.${type}`;
    counter += 1;
  }
  try {
    if (type === 'mp4') patchMp4Duration(buffer, { inPlace: true });
    await fs.promises.writeFile(path.join(clipsDir(), name), buffer);
  } catch (error) {
    return { ok: false, error: error.message };
  }
  const meta = readClipMeta(safe);
  writeClipMeta(name, {
    ...meta,
    category: CLIP_CATEGORIES.includes(meta.category) ? meta.category : guessCategory(safe),
    title: (meta.title || safe) + ' · Export',
    keys: [],
    cam: undefined,
    burned: true,
    showKeys: false,
    createdAt: Date.now(),
  });
  pruneClips();
  return { ok: true, name, clips: listClips(), usage: clipUsage() };
});

ipcMain.handle('clip:reveal', (_event, name) => {
  const safe = safeClipName(name);
  if (!safe) return false;
  shell.showItemInFolder(path.join(clipsDir(), safe));
  return true;
});

/**
 * Ältere Clips (vor der Zeitachsen-Korrektur) einmalig reparieren: ihre
 * Zeitstempel beginnen mitten in der Aufnahme, deshalb ging Spulen nicht.
 */
async function repairOldClips() {
  for (const clip of listClips()) {
    const meta = readClipMeta(clip.name);
    if (Number(meta.version) >= 3 || meta.burned) continue;
    try {
      const buffer = await fs.promises.readFile(clip.path);
      const ext = /\.mp4$/i.test(clip.name) ? 'mp4' : 'webm';
      if (rebaseClip(buffer, ext)) {
        if (ext === 'mp4') patchMp4Duration(buffer, { inPlace: true });
        await fs.promises.writeFile(clip.path, buffer);
      }
      writeClipMeta(clip.name, { ...meta, category: meta.category || guessCategory(clip.name), version: 3 });
      console.log('[clip] Zeitachse repariert:', clip.name);
    } catch (error) {
      console.log('[clip] Reparatur fehlgeschlagen:', clip.name, error.message);
    }
  }
}

/** Clips und Vorschaubilder fürs eigene Fenster – mit Range, damit Spulen geht. */
function serveClipFile(request, name) {
  const file = path.join(clipsDir(), name);
  if (!(CLIP_VIDEO.test(name) || /\.(mp4|webm)\.jpg$/i.test(name)) || !fs.existsSync(file)) {
    return new Response('', { status: 404 });
  }
  const size = fs.statSync(file).size;
  const type = /\.jpg$/i.test(name) ? 'image/jpeg' : /\.mp4$/i.test(name) ? 'video/mp4' : 'video/webm';
  const range = request.headers.get('range');
  const match = range ? /bytes=(\d*)-(\d*)/.exec(range) : null;
  if (match && (match[1] !== '' || match[2] !== '')) {
    let start = match[1] === '' ? Math.max(0, size - Number(match[2])) : Number(match[1]);
    let end = match[1] !== '' && match[2] !== '' ? Math.min(Number(match[2]), size - 1) : size - 1;
    if (start >= size || start > end) {
      return new Response('', { status: 416, headers: { 'content-range': `bytes */${size}` } });
    }
    return new Response(Readable.toWeb(fs.createReadStream(file, { start, end })), {
      status: 206,
      headers: {
        'content-type': type,
        'content-length': String(end - start + 1),
        'content-range': `bytes ${start}-${end}/${size}`,
        'accept-ranges': 'bytes',
        'cache-control': 'no-store',
        'access-control-allow-origin': '*',
      },
    });
  }
  return new Response(Readable.toWeb(fs.createReadStream(file)), {
    headers: {
      'content-type': type,
      'content-length': String(size),
      'accept-ranges': 'bytes',
      'cache-control': 'no-store',
      'access-control-allow-origin': '*',
    },
  });
}

/* ---------------- App lifecycle ---------------- */

// Nur eine Instanz: zwei Overlays übereinander wären Chaos.
const singleInstance = app.requestSingleInstanceLock();

if (!singleInstance) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (app.isReady()) showMainWindow();
  });
}

app.whenReady().then(() => {
  if (!singleInstance) return;
  screen.on('display-metrics-changed', () => refreshOverlayVisibility());
  screen.on('display-added', () => refreshOverlayVisibility());
  screen.on('display-removed', () => refreshOverlayVisibility());

  protocol.handle('xh', (request) => {
    try {
      const url = new URL(request.url);
      const name = path.basename(decodeURIComponent(url.pathname).replace(/^\/+/, ''));
      if (!name) return new Response('', { status: 404 });

      // Gespeicherte Clips (Video + Vorschaubild) für den Player im Clips-Tab.
      if (url.hostname === 'clip') return serveClipFile(request, name);

      // Rang-Abzeichen liegen im App-Ordner (auch im asar lesbar).
      if (url.hostname === 'rank') {
        const file = path.join(ROOT, 'assets', 'ranks', name);
        if (!fs.existsSync(file)) return new Response('', { status: 404 });
        return new Response(fs.readFileSync(file), {
          headers: { 'content-type': 'image/png', 'cache-control': 'no-store' },
        });
      }

      return net.fetch(pathToFileURL(path.join(crosshairDir(), name)).toString());
    } catch {
      return new Response('', { status: 404 });
    }
  });

  // System-Ton für Clips: Electron liefert Loopback-Audio nur über
  // getDisplayMedia mit diesem Handler. Der alte chromeMediaSource-Weg
  // für Audio reißt den Renderer mit (Absturz bei Aufnahmestart).
  session.defaultSession.setDisplayMediaRequestHandler(async (request, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ types: ['window', 'screen'] });
      const wanted = store?.settings?.clipSourceId;
      const source = sources.find((entry) => entry.id === wanted) || sources[0];
      if (!source) return callback({});
      callback({ video: source, audio: 'loopback' });
    } catch {
      callback({});
    }
  });

  // Hintergrund-Videos liegen teils im App-Archiv (asar) – deshalb über fs lesen.
  protocol.handle('wall', (request) => {
    try {
      const url = new URL(request.url);
      const raw = decodeURIComponent(url.pathname).replace(/^\/+/, '');
      const name = path.basename(raw);
      if (!name) return new Response('', { status: 404 });
      const file = raw.startsWith('thumbs/')
        ? path.join(wallpaperDir(), 'thumbs', name)
        : [path.join(userWallpaperDir(), name), path.join(wallpaperDir(), name)].find(
            (candidate) => fs.existsSync(candidate),
          );
      if (!file || !fs.existsSync(file)) return new Response('', { status: 404 });
      const ext = path.extname(file).toLowerCase();
      const type =
        ext === '.mp4'
          ? 'video/mp4'
          : ext === '.webm'
            ? 'video/webm'
            : ext === '.gif'
              ? 'image/gif'
              : ext === '.png'
                ? 'image/png'
                : ext === '.webp'
                  ? 'image/webp'
                  : 'image/jpeg';
      return new Response(fs.readFileSync(file), {
        headers: { 'content-type': type, 'cache-control': 'no-store' },
      });
    } catch {
      return new Response('', { status: 404 });
    }
  });

  const target = storeFile();
  migrateLegacyStore(target);
  store = new Store(target);
  store.load();
  // Umstellungen beim Laden (Crosshair an, Autostart) sofort sichern, damit
  // sie auch nach einem harten Herunterfahren in der Datei stehen.
  store.flush();
  playerBook = new PlayerBook(path.join(path.dirname(store.file), 'players.json'));
  playerBook.load();
  if (!store.settings.replayDir) {
    store.data.settings.replayDir = DEFAULT_REPLAY_DIR;
  }

  createWindow();
  createOverlay();
  createTray();
  setTimeout(() => repairOldClips().catch(() => {}), 5000);
  registerClipHotkey();
  registerRecHotkey();
  registerXhHotkeys();
  applyAutoStart(xhConfig());
  applyFocusMode(xhConfig());
  startGameWatch();
  initMusic();
  initPerf();
  initChests();
  startScreenTime();

  if (!NO_SCAN) {
    mainWindow.webContents.once('did-finish-load', () => {
      setTimeout(() => {
        if (store.settings.autoScan) runScan();
      }, 900);
    });

    scanTimer = setInterval(() => {
      if (store.settings.autoScan && !scanning) runScan();
    }, 120000);
  }

  // Eingaben laufen immer mit: Rechtsklick-Zielen und Keystrokes brauchen sie.
  inputHook.start(handleInputState);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('before-quit', () => {
  quitting = true;
});

app.on('will-quit', () => {
  clearInterval(scanTimer);
  clearInterval(displayTimer);
  clearInterval(rankTimer);
  clearInterval(screenTimeTimer);
  perf.stop();
  audio.stop();
  setFocusNotifications(false);
  if (tray && !tray.isDestroyed()) tray.destroy();
  gameWatch?.stop();
  globalShortcut.unregisterAll();
  playerBook?.flush();
  inputHook.stop();
  ocr.shutdown();
});

app.on('window-all-closed', () => {
  store?.flush();
  // „Fenster schließen“ beendet die App nicht – das Crosshair bleibt aktiv.
  if (!store || !normalizeApp(store.settings.xh).closeToTray) app.quit();
});
