'use strict';

/* Orbit Island page: status, start/stop and every island setting. */
(function () {
  const esc = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const isObject = (value) => value && typeof value === 'object' && !Array.isArray(value);

  function merge(base, over) {
    if (!isObject(base) || !isObject(over)) return over === undefined ? clone(base) : clone(over);
    const out = clone(base);
    for (const [key, value] of Object.entries(over)) {
      // The island reads names case-insensitively; keep whatever spelling the file uses.
      const match = Object.keys(out).find((k) => k.toLowerCase() === key.toLowerCase()) || key;
      out[match] = isObject(out[match]) && isObject(value) ? merge(out[match], value) : clone(value);
    }
    return out;
  }

  function get(obj, path) {
    return path.split('.').reduce((node, key) => (node == null ? undefined : node[key]), obj);
  }

  function set(obj, path, value) {
    const keys = path.split('.');
    let node = obj;
    for (const key of keys.slice(0, -1)) node = node[key] = isObject(node[key]) ? node[key] : {};
    node[keys[keys.length - 1]] = value;
  }

  const page = {
    data: null,
    draft: null,
    original: '',
    section: 'player',
    query: '',
    busy: false,
    error: '',

    async load(force = false) {
      if (this.data && !force) return;
      try {
        this.music = await window.hub.music?.get().catch(() => null);
        this.data = await window.hub.orbit.settings();
        const merged = merge(this.data.defaults.settings, this.data.settings || {});
        this.draft = merged;
        this.original = JSON.stringify(merged);
        this.error = '';
      } catch (error) {
        this.error = String(error?.message || error);
      }
    },

    dirty() {
      return this.draft && JSON.stringify(this.draft) !== this.original;
    },

    /** Only what changed since the last write: arrays and scalars whole, objects per key. */
    diff(before, after) {
      const out = {};
      for (const [key, value] of Object.entries(after)) {
        if (isObject(value) && isObject(before?.[key])) {
          const inner = this.diff(before[key], value);
          if (Object.keys(inner).length) out[key] = inner;
        } else if (JSON.stringify(value) !== JSON.stringify(before?.[key])) out[key] = value;
      }
      return out;
    },

    /** Every change is applied live: written shortly after the last edit, no save button. */
    schedule(delay = 220) {
      clearTimeout(this.saveTimer);
      this.saveTimer = setTimeout(() => this.flush(), delay);
    },

    async flush() {
      clearTimeout(this.saveTimer);
      if (!this.dirty()) return;
      const snapshot = JSON.stringify(this.draft);
      const patch = this.diff(JSON.parse(this.original), JSON.parse(snapshot));
      try {
        await window.hub.orbit.save(patch);
        this.original = snapshot;
        const live = document.getElementById('o-live');
        if (live) {
          live.classList.add('show');
          clearTimeout(this.liveTimer);
          this.liveTimer = setTimeout(() => live.classList.remove('show'), 1400);
        }
      } catch (error) {
        this.toast?.(String(error?.message || error), 'error');
      }
    },

    /* ----------------------------------------------------------- controls */
    control(field) {
      const [path, label, type, options = {}] = field;
      const value = get(this.draft, path);
      const hint = options.hint ? `<small>${esc(options.hint)}</small>` : '';
      const row = (control, wide = false) =>
        `<div class="set-row ${wide ? 'wide' : ''}"><div class="grow"><strong>${esc(label)}</strong>${hint}</div>${control}</div>`;

      if (type === 'b') return row(`<button class="switch ${value ? 'on' : ''}" data-o-bool="${path}" aria-pressed="${Boolean(value)}"></button>`);
      if (type === 'n') {
        const shown = options.pct ? `${Math.round(Number(value) * 100)} %` : `${Number(value)}${options.unit ? ` ${options.unit}` : ''}`;
        return row(
          `<div class="range"><input type="range" min="${options.min}" max="${options.max}" step="${options.step}" value="${Number(value)}" data-o-num="${path}" /><output>${esc(shown)}</output></div>`,
        );
      }
      if (type === 'e') {
        const list = options.monitors ? [['__auto__', 'Automatisch (zweiter Bildschirm, sonst Hauptmonitor)'], ['', 'Hauptmonitor'], ...((window.OrbitPage?.data?.monitors || []).map((m) => [m.name, m.text]))] : options.options || [];
        const known = list.some(([v]) => String(v) === String(value));
        const items = (known ? list : [[value, String(value)], ...list])
          .map(([v, text]) => `<option value="${esc(v)}" ${String(v) === String(value) ? 'selected' : ''}>${esc(text)}</option>`)
          .join('');
        return row(`<select class="select" data-o-enum="${path}" data-numeric="${typeof list[0]?.[0] === 'number'}">${items}</select>`);
      }
      if (type === 'c') {
        const raw = String(value || '#000000');
        const rgb = raw.length === 9 ? `#${raw.slice(3)}` : raw.slice(0, 7);
        return row(
          `<div class="color"><input type="color" value="${esc(rgb)}" data-o-color="${path}" /><input class="input mono" value="${esc(raw)}" data-o-text="${path}" spellcheck="false" /></div>`,
        );
      }
      if (type === 'list') {
        return row(`<input class="input" value="${esc((value || []).join(', '))}" data-o-list="${path}" />`, true);
      }
      if (type === 'wallpaper') {
        const files = this.data.wallpapers || [];
        const base = (p) => String(p || '').split(/[\\/]/).pop();
        const items = [`<option value="">Kein Video (Effekt oben)</option>`]
          .concat(files.map((w) => `<option value="${esc(w.path)}" ${base(w.path) === base(value) ? 'selected' : ''}>${esc(w.name[0].toUpperCase() + w.name.slice(1))}</option>`))
          .join('');
        return row(`<select class="select" data-o-enum="${path}">${items}</select>`);
      }
      const placeholder = type === 'k' ? 'z. B. Ctrl+Alt+I' : type === 'time' ? 'HH:MM' : '';
      return row(`<input class="input ${type === 'k' || type === 'time' ? 'mono short' : ''}" value="${esc(value ?? '')}" placeholder="${placeholder}" data-o-text="${path}" spellcheck="false" />`, type === 't');
    },

    special(kind) {
      const d = this.draft;
      if (kind === 'player') return this.playerHtml();
      if (kind === 'themes') {
        const current = d.Appearance.ThemeId;
        return `<div class="theme-grid">${this.data.defaults.themes
          .map((t) => {
            const a = { ...this.data.defaults.settings.Appearance, ...t.appearance };
            return `<button class="theme ${t.id === current ? 'on' : ''}" data-o-theme="${t.id}">
              <span class="theme-pill" style="background:linear-gradient(135deg,${a.BackgroundColor},${a.BackgroundColor2});border-color:${a.BorderColor}33">
                <i style="background:${a.AccentColor}"></i><i style="background:${a.AccentColor2}"></i></span>
              <b>${esc(t.name)}</b><small>${esc(t.description)}</small></button>`;
          })
          .join('')}</div>`;
      }
      if (kind === 'worldclocks') {
        const list = d.Clock.WorldClocks || [];
        return `<div class="sub-list">${list
          .map(
            (c, i) => `<div class="sub-row"><input class="input" value="${esc(c.Label)}" data-o-item="Clock.WorldClocks.${i}.Label" placeholder="Name" />
            <input class="input mono" value="${esc(c.TimeZoneId)}" data-o-item="Clock.WorldClocks.${i}.TimeZoneId" placeholder="Windows-Zeitzone, z. B. W. Europe Standard Time" />
            <button class="btn small icon-only" data-o-remove="Clock.WorldClocks.${i}" title="Entfernen">${icon('trash', 15)}</button></div>`,
          )
          .join('')}<button class="btn small" data-o-add="worldclock">${icon('plus', 15)} Weltuhr hinzufügen</button></div>`;
      }
      if (kind === 'ics') {
        const list = d.Calendar.IcsSubscriptions || [];
        return `<div class="sub-list">${list
          .map(
            (c, i) => `<div class="sub-row"><button class="switch ${c.Enabled ? 'on' : ''}" data-o-bool="Calendar.IcsSubscriptions.${i}.Enabled"></button>
            <input class="input" value="${esc(c.Name)}" data-o-item="Calendar.IcsSubscriptions.${i}.Name" placeholder="Name" />
            <input class="input mono" value="${esc(c.Url)}" data-o-item="Calendar.IcsSubscriptions.${i}.Url" placeholder="https://… .ics" />
            <button class="btn small icon-only" data-o-remove="Calendar.IcsSubscriptions.${i}" title="Entfernen">${icon('trash', 15)}</button></div>`,
          )
          .join('')}<button class="btn small" data-o-add="ics">${icon('plus', 15)} Kalender abonnieren</button></div>`;
      }
      if (kind === 'presence') {
        const p = d.Presence;
        const when = p.EnrolledUtc ? new Date(p.EnrolledUtc).toLocaleDateString('de-DE') : '';
        return `<div class="faceid ${p.Enabled ? 'on' : ''}">
          <div class="fi-ring">${icon('eye', 26)}</div>
          <div class="grow"><strong>${p.EnrolledName ? `Face ID: ${esc(p.EnrolledName)}${when ? ` · seit ${when}` : ''}` : 'Face ID ist noch nicht eingerichtet'}</strong>
          <small>${p.Enabled ? 'Aktiv – die Island erkennt dich und sperrt, wenn du weg bist.' : p.EnrolledName ? 'Eingerichtet, aber ausgeschaltet. Schalte „Anwesenheit erkennen“ ein.' : 'Scanne dein Gesicht einmal – alles bleibt auf deinem PC.'}<br>Während des Scans pausiert der Hub die Facecam im Gaming Hub, damit die Kamera frei ist.</small></div>
          <div class="fi-actions"><button class="btn small primary" data-o-command="face">${icon('camera', 15)} ${p.EnrolledName ? 'Neu scannen' : 'Face ID einrichten'}</button>
          <button class="switch ${p.Enabled ? 'on' : ''}" data-o-bool="Presence.Enabled" title="Face ID / Anwesenheit an oder aus"></button></div></div>`;
      }
      if (kind === 'events') {
        return `<div class="set-row wide"><div class="grow"><strong>Eigene Termine</strong>
          <small>Einzelne und mehrtägige Termine mit Erinnerung. Sie erscheinen in der Island und melden sich dort rechtzeitig.</small></div>
          <button class="btn small" data-o-command="newevent">${icon('plus', 15)} Neuer Termin</button></div>`;
      }
      if (kind === 'widgets') {
        const list = d.Dock.Widgets || [];
        return `<div class="widget-list">${list
          .map((w, i) => {
            const base = `Dock.Widgets.${i}`;
            const bg = [['Color', 'Farbe'], ['Oled', 'OLED-Schwarz'], ['Live', 'Live-Hintergrund']]
              .map(([v, t]) => `<option value="${v}" ${w.Background === v ? 'selected' : ''}>${t}</option>`)
              .join('');
            return `<div class="widget-card">
              <div class="widget-head"><b>${esc(window.ORBIT_WIDGET_NAMES[w.Kind] || w.Kind)}</b><button class="switch ${w.Enabled ? 'on' : ''}" data-o-bool="${base}.Enabled"></button></div>
              <label>Hintergrund<select class="select" data-o-enum="${base}.Background">${bg}</select></label>
              <label>Farbe<div class="color"><input type="color" value="${esc(String(w.Color).slice(0, 7))}" data-o-color="${base}.Color" /><span class="mono">${esc(w.Color)}</span></div></label>
              <label>Regenbogen<button class="switch ${w.Rainbow ? 'on' : ''}" data-o-bool="${base}.Rainbow"></button></label>
              <label>Deckkraft<div class="range"><input type="range" min="0.1" max="1" step="0.05" value="${w.Opacity}" data-o-num="${base}.Opacity" /><output>${Math.round(w.Opacity * 100)} %</output></div></label>
              <label>Größe<span class="pair"><input class="input mono short" type="number" value="${w.Width}" data-o-int="${base}.Width" /> × <input class="input mono short" type="number" value="${w.Height}" data-o-int="${base}.Height" /></span></label>
            </div>`;
          })
          .join('')}</div>`;
      }
      return '';
    },

    /* -------------------------------------------------------------- render */
    html(state) {
      this.lastState = state;
      const { available, running } = state.orbit;
      const head = `<div class="hero"><div>
          <span class="eyebrow">Revolution Island</span>
          <h2>Revolution Island</h2>
          <p>Deine Dynamic Island – hier steuerst du sie komplett: Design, Größe, Musik, Kalender, Benachrichtigungen, Widgets und mehr.</p>
        </div>
        <div class="row">
          ${available ? (running ? `<button class="btn danger" id="orbit-stop">${icon('stop', 16)} Beenden</button>` : `<button class="btn primary" id="orbit-start">${icon('play', 16)} Starten</button>`) : ''}
          ${available ? `<button class="btn" data-o-native title="Öffnet das Einstellungsfenster der Island selbst">${icon('external', 16)} Island-Fenster</button>` : ''}
        </div></div>
        <div class="panel status-hero">
          <div class="status-orb ${running ? 'on' : ''}">${icon('island', 30)}</div>
          <div class="grow"><h3>${!available ? 'Nicht verfügbar' : running ? 'Revolution Island läuft' : 'Revolution Island ist aus'}</h3>
          <p>${!available ? 'Revolution Island ist nur unter Windows mit dieser Installation verfügbar.' : running ? 'Änderungen gelten sofort – ohne Neustart.' : 'Änderungen werden beim nächsten Start übernommen.'}</p></div>
          <div class="set-inline"><span>Mit dem Hub starten</span><button class="switch ${state.settings.orbitWithHub ? 'on' : ''}" data-setting="orbitWithHub"></button></div>
        </div>`;

      if (this.error) return `<div class="page">${head}<div class="note">${icon('alert', 18)}<div>${esc(this.error)}</div></div></div>`;
      if (!this.draft) return `<div class="page">${head}<div class="empty">Einstellungen werden geladen …</div></div>`;

      const q = this.query.trim().toLowerCase();
      const sections = window.ORBIT_SECTIONS;
      const tabs = sections
        .map((s) => `<button class="tab ${!q && s.id === this.section ? 'on' : ''}" data-o-section="${s.id}">${icon(s.icon, 16)}<span>${esc(s.title)}</span></button>`)
        .join('');

      const renderGroup = (group) => {
        if (group.special) return `<div class="set-group"><h4>${esc(group.title)}</h4><div class="panel">${this.special(group.special)}</div></div>`;
        const fields = q ? group.fields.filter((f) => f[1].toLowerCase().includes(q)) : group.fields;
        if (!fields.length) return '';
        return `<div class="set-group"><h4>${esc(group.title)}</h4><div class="panel">${fields.map((f) => this.control(f)).join('')}</div></div>`;
      };
      const body = q
        ? sections.map((s) => s.groups.filter((g) => !g.special).map(renderGroup).join('')).join('') || `<div class="empty">Keine Einstellung gefunden.</div>`
        : sections.find((s) => s.id === this.section).groups.map(renderGroup).join('');

      return `<div class="page orbit-page">${head}
        <div class="orbit-settings">
          <aside class="tabs"><div class="search">${icon('search', 15)}<input class="input" id="o-search" placeholder="Einstellung suchen …" value="${esc(this.query)}" /></div>${tabs}</aside>
          <section class="set-body">${body}</section>
        </div>
        <div class="live-chip" id="o-live">${icon('check', 14)} Übernommen</div>
      </div>`;
    },


    /** Separater Player: das Musik-Overlay (früher im Gaming Hub). */
    playerHtml() {
      const m = this.music?.settings;
      if (!m) return '<div class="empty">Der Musik-Player ist gerade nicht verfügbar.</div>';
      const row = (key, title, text, on) =>
        `<div class="list-row"><div class="grow"><strong>${esc(title)}</strong><small>${esc(text)}</small></div><button class="switch ${on ? 'on' : ''}" data-mu-toggle="${key}"></button></div>`;
      const st = this.music.state || {};
      const presets = [['tl', '↖ Oben links'], ['tc', '↑ Oben mitte'], ['tr', '↗ Oben rechts'], ['ml', '← Mitte links'], ['mc', '• Mitte'], ['mr', '→ Mitte rechts'], ['bl', '↙ Unten links'], ['bc', '↓ Unten mitte'], ['br', '↘ Unten rechts']];
      return `
        <div class="list-row"><div class="grow"><strong>${st.title ? `♪ ${esc(st.title)}` : 'Gerade läuft nichts'}</strong><small>${esc(st.artist || 'Startet automatisch, sobald auf dem PC Musik läuft (Spotify, Browser, …).')}</small></div><button class="btn small" data-mu-demo="1">Vorschau</button></div>
        ${row('enabled', 'Player anzeigen', 'Blendet die Karte ein, sobald Musik läuft', m.enabled !== false)}
        ${row('lyrics', 'Songtext', 'Aktuelle Zeile läuft mit', m.lyrics !== false)}
        ${row('vinyl', 'Plattenspieler', 'Cover dreht sich wie eine Schallplatte', m.vinyl === true)}
        ${row('arm', 'Tonarm', 'Nadel wandert mit dem Song nach innen', m.arm !== false)}
        ${row('crackle', 'Platten-Knistern', 'Leises Vinyl-Knistern, solange Musik läuft', m.crackle === true)}
        ${row('title', 'Titel & Interpret', 'Songname und Künstler', m.title !== false)}
        ${row('progress', 'Fortschritt & Zeiten', 'Balken mit Lauf- und Restzeit', m.progress !== false)}
        ${row('vinylOnly', 'Nur Schallplatte', 'Nur der runde Kreis – ohne Karte, Text und Balken', m.vinylOnly === true)}
        <div class="list-row"><div class="grow"><strong>Größe</strong><small>Wie groß der Player am Bildschirm ist</small></div>
          <div class="range"><input type="range" min="0.6" max="2" step="0.05" value="${Number(m.scale) || 0.8}" data-mu-range="scale" /><output>${Math.round((Number(m.scale) || 0.8) * 100)} %</output></div></div>
        <div class="list-row"><div class="grow"><strong>Knistern-Lautstärke</strong><small>Nur mit Platten-Knistern</small></div>
          <div class="range"><input type="range" min="0" max="100" step="5" value="${Number(m.crackleVolume ?? 40)}" data-mu-range="crackleVolume" ${m.crackle ? '' : 'disabled'} /><output>${Number(m.crackleVolume ?? 40)} %</output></div></div>
        <div class="list-row column"><div class="grow"><strong>Position</strong><small>Ecke am Bildschirm</small></div>
          <div class="mu-presets">${presets.map(([id, text]) => `<button class="btn small ${m.preset === id ? 'on' : ''}" data-mu-preset="${id}">${text}</button>`).join('')}</div></div>`;
    },

    async musicSet(patch) {
      await window.hub.music.set(patch).catch(() => null);
      this.music = await window.hub.music.get().catch(() => this.music);
    },

    /* --------------------------------------------------------------- events */
    bind(root, rerender, toast) {
      this.toast = toast;
      const changed = (delay) => this.schedule(delay);
      root.addEventListener('input', (event) => {
        const el = event.target;
        if (el.dataset.muRange) {
          const v = Number(el.value);
          const out = el.parentElement.querySelector('output');
          if (out) out.textContent = el.dataset.muRange === 'scale' ? `${Math.round(v * 100)} %` : `${v} %`;
          clearTimeout(this.muTimer);
          this.muTimer = setTimeout(() => this.musicSet({ [el.dataset.muRange]: v }), 250);
          return;
        }
        if (el.id === 'o-search') {
          this.query = el.value;
          rerender();
          const again = document.getElementById('o-search');
          again.focus();
          again.setSelectionRange(again.value.length, again.value.length);
          return;
        }
        if (el.dataset.oNum) {
          const value = Number(el.value);
          set(this.draft, el.dataset.oNum, value);
          const field = window.ORBIT_SECTIONS.flatMap((s) => s.groups).flatMap((g) => g.fields || []).find((f) => f[0] === el.dataset.oNum);
          const opt = field?.[3] || {};
          const out = el.parentElement.querySelector('output');
          if (out) out.textContent = opt.pct || !field ? `${Math.round(value * 100)} %` : `${value}${opt.unit ? ` ${opt.unit}` : ''}`;
        } else if (el.dataset.oInt) set(this.draft, el.dataset.oInt, Number(el.value) || 0);
        else if (el.dataset.oColor) {
          const prev = String(get(this.draft, el.dataset.oColor) || '');
          const next = prev.length === 9 ? `#${prev.slice(1, 3)}${el.value.slice(1)}`.toUpperCase() : el.value.toUpperCase();
          set(this.draft, el.dataset.oColor, next);
          const text = el.parentElement.querySelector('[data-o-text], .mono');
          if (text) text.tagName === 'INPUT' ? (text.value = next) : (text.textContent = next);
        } else if (el.dataset.oText) {
          set(this.draft, el.dataset.oText, el.value);
          const color = el.parentElement.querySelector('[data-o-color]');
          if (color && /^#([0-9a-f]{6}|[0-9a-f]{8})$/i.test(el.value)) color.value = el.value.length === 9 ? `#${el.value.slice(3)}` : el.value;
          changed(650);
          return;
        } else if (el.dataset.oItem) {
          set(this.draft, el.dataset.oItem, el.value);
          changed(650);
          return;
        }
        else if (el.dataset.oList) {
          set(this.draft, el.dataset.oList, el.value.split(/[,;\s]+/).map(Number).filter((n) => Number.isFinite(n) && n > 0));
        } else return;
        changed();
      });

      root.addEventListener('change', (event) => {
        const el = event.target;
        if (!el.dataset.oEnum) return;
        const numeric = el.dataset.numeric === 'true';
        set(this.draft, el.dataset.oEnum, numeric ? Number(el.value) : el.value);
        changed();
      });

      root.addEventListener('click', async (event) => {
        const el = event.target.closest('button');
        if (!el) return;
        if (el.dataset.muToggle) {
          const key = el.dataset.muToggle;
          const next = !(key === 'enabled' || key === 'lyrics' || key === 'arm' || key === 'title' || key === 'progress' ? this.music.settings[key] !== false : this.music.settings[key] === true);
          await this.musicSet(key === 'vinylOnly' ? { vinylOnly: next, vinyl: next || this.music.settings.vinyl } : { [key]: next });
          rerender();
          return;
        }
        if (el.dataset.muPreset) {
          await this.musicSet({ preset: el.dataset.muPreset });
          rerender();
          return;
        }
        if (el.dataset.muDemo) {
          this.music = (await window.hub.music.demo().catch(() => null)) || this.music;
          rerender();
          return;
        }
        if (el.dataset.oBool) {
          const next = !get(this.draft, el.dataset.oBool);
          set(this.draft, el.dataset.oBool, next);
          el.classList.toggle('on', next);
          el.setAttribute('aria-pressed', String(next));
          changed();
        } else if (el.dataset.oSection) {
          // Nur den Inhalt rechts austauschen – nicht die ganze Seite neu aufbauen (kein Flackern).
          this.section = el.dataset.oSection;
          this.query = '';
          const body = root.querySelector('.set-body');
          const tpl = document.createElement('template');
          tpl.innerHTML = this.html(this.lastState);
          const fresh = tpl.content.querySelector('.set-body');
          if (body && fresh) {
            body.replaceChildren(...fresh.childNodes);
            body.scrollTop = 0;
            root.querySelectorAll('[data-o-section]').forEach((b) => b.classList.toggle('on', b.dataset.oSection === this.section));
            const search = root.querySelector('#o-search');
            if (search) search.value = '';
          } else rerender();
        } else if (el.dataset.oTheme) {
          const theme = this.data.defaults.themes.find((t) => t.id === el.dataset.oTheme);
          const keep = ['Wallpaper', 'WallpaperFile', 'WallpaperOpacity', 'WallpaperOnDesktop'];
          const kept = Object.fromEntries(keep.map((k) => [k, this.draft.Appearance[k]]));
          this.draft.Appearance = { ...clone(this.data.defaults.settings.Appearance), ...theme.appearance, ...kept, ThemeId: theme.id, ThemeName: theme.name };
          this.draft.Animation = { ...clone(this.data.defaults.settings.Animation), ...theme.animation };
          rerender();
          changed(0);
        } else if (el.dataset.oAdd === 'worldclock') {
          (this.draft.Clock.WorldClocks ||= []).push({ Label: 'Zürich', TimeZoneId: 'W. Europe Standard Time' });
          rerender();
          changed(0);
        } else if (el.dataset.oAdd === 'ics') {
          (this.draft.Calendar.IcsSubscriptions ||= []).push({ Id: crypto.randomUUID().replace(/-/g, ''), Name: 'Kalender', Url: '', Enabled: true, LastSyncedUtc: null, LastError: '' });
          rerender();
        } else if (el.dataset.oRemove) {
          const parts = el.dataset.oRemove.split('.');
          const index = Number(parts.pop());
          get(this.draft, parts.join('.')).splice(index, 1);
          rerender();
          changed(0);
        } else if (el.dataset.oCommand) {
          window.hub.orbit.command(el.dataset.oCommand).catch((error) => toast(String(error.message || error), 'error'));
        } else if (el.hasAttribute('data-o-native')) {
          window.hub.orbit.openNative().catch((error) => toast(String(error.message || error), 'error'));
        }
      });
    },
  };

  window.OrbitPage = page;
})();
