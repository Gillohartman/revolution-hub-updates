'use strict';

/**
 * Orbit Island is a native WPF app (C#). The hub ships its build and runs it as a
 * background companion: start, stop and a live "running" status.
 */

const { app } = require('electron');
const { spawn, execFile } = require('child_process');
const fs = require('fs');
const { takeOverStandalone } = require('./standalone');
const path = require('path');

const EXE_NAME = 'OrbitIsland.exe';

class OrbitIsland {
  constructor(onChange) {
    this.onChange = onChange;
    this.running = false;
    this.startedByHub = false;
    this.timer = null;
  }

  exePath() {
    const candidates = [
      path.join(process.resourcesPath || '', 'orbit', EXE_NAME),
      path.join(app.getAppPath(), '..', 'orbit', EXE_NAME),
      path.join(app.getAppPath(), 'vendor', 'orbit', EXE_NAME),
    ];
    return candidates.find((file) => fs.existsSync(file)) || null;
  }

  available() {
    return process.platform === 'win32' && Boolean(this.exePath());
  }

  /**
   * Face ID hat Vorrang vor der Facecam: die Island schreibt camera-request.json, sobald sie
   * die Kamera braucht. Dann pausiert der Hub die Facecam des Gaming Hubs (und gibt sie danach zurück).
   */
  watchCamera(onChange) {
    const file = path.join(path.dirname(this.settingsFile()), 'camera-request.json');
    let last = null;
    const check = () => {
      let active = false;
      try {
        const j = JSON.parse(fs.readFileSync(file, 'utf8'));
        active = Boolean(j.active) && this.running !== false;
      } catch {
        active = false;
      }
      if (this.cameraHold && Date.now() < this.cameraHold) active = true;
      if (active !== last) {
        last = active;
        onChange(active);
      }
    };
    check();
    setInterval(check, 1000).unref?.();
  }

  /** Kamera für die Face-ID-Einrichtung sofort freigeben (bis die Island übernimmt). */
  holdCamera(ms = 20000) {
    this.cameraHold = Date.now() + ms;
  }

  watch() {
    if (this.timer) return;
    const tick = () => this.refresh().catch(() => {});
    tick();
    this.timer = setInterval(tick, 4000);
    this.timer.unref?.();
  }

  refresh() {
    return new Promise((resolve) => {
      if (process.platform !== 'win32') return resolve(false);
      execFile('tasklist', ['/FI', `IMAGENAME eq ${EXE_NAME}`, '/FO', 'CSV', '/NH'], { windowsHide: true }, (error, stdout) => {
        const running = !error && stdout.toLowerCase().includes(EXE_NAME.toLowerCase());
        // Läuft eine Island, die nicht der Hub gestartet hat (z. B. alter Autostart),
        // wird sie durch die Island aus dem Hub ersetzt.
        if (running && !this.child && this.autoReplace && !this.replacing) {
          this.replacing = true;
          this.start().catch(() => {}).finally(() => { this.replacing = false; });
        }
        if (running !== this.running) {
          this.running = running;
          if (!running) this.startedByHub = false;
          this.onChange();
        }
        resolve(running);
      });
    });
  }

  async start() {
    const exe = this.exePath();
    if (!exe) throw new Error('Revolution Island ist in dieser Installation nicht enthalten.');
    // Eine alte Einzel-Installation der Island hält sonst die Einzel-Instanz-Sperre –
    // dann liefe deren Prozess statt der Island aus dem Hub.
    if (this.child) return true;
    if (Date.now() - (this.tookOverAt || 0) > 15000) await this.takeOver();
    // Läuft noch eine Island, die nicht vom Hub gestartet wurde (z. B. über den Windows-
    // Autostart), wird sie durch die Island als Teil des Hubs ersetzt.
    if (await this.refresh()) {
      await new Promise((resolve) => execFile('taskkill', ['/IM', EXE_NAME, '/T', '/F'], { windowsHide: true }, () => resolve()));
      await new Promise((resolve) => setTimeout(resolve, 700));
    }
    this.ensureSettingsFile();
    // Nicht losgelöst starten: So gehört die Island zum Hub-Prozess (Task-Manager zeigt
    // sie unter Revolution Hub) und endet mit ihm.
    const child = spawn(exe, ['--startup'], { cwd: path.dirname(exe), stdio: 'ignore', windowsHide: false });
    child.on('error', (error) => console.error('[orbit] start failed', error));
    child.on('exit', () => {
      if (this.child === child) this.child = null;
      setTimeout(() => this.refresh(), 300);
    });
    this.child = child;
    this.startedByHub = true;
    setTimeout(() => this.refresh(), 1500);
    return true;
  }

  /** Alte Einzel-Apps beenden, ihren Autostart auf den Hub umbiegen. */
  async takeOver() {
    this.tookOverAt = Date.now();
    return takeOverStandalone({ islandExe: this.exePath() || '' });
  }

  stop() {
    return new Promise((resolve) => {
      if (process.platform !== 'win32') return resolve(false);
      execFile('taskkill', ['/IM', EXE_NAME, '/T', '/F'], { windowsHide: true }, () => {
        this.startedByHub = false;
        setTimeout(() => this.refresh().then(() => resolve(true)), 600);
      });
    });
  }

  /* -------------------------------------------------------------- settings */

  settingsFile() {
    return path.join(process.env.APPDATA || app.getPath('appData'), 'PulseIsland', 'settings.json');
  }

  defaults() {
    return require('./orbit-defaults.json');
  }

  /** Without a settings file the island opens its own first-run window; the hub has the settings. */
  ensureSettingsFile() {
    const file = this.settingsFile();
    if (fs.existsSync(file)) return;
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      const settings = { ...this.defaults().settings, FirstRun: false };
      fs.writeFileSync(file, JSON.stringify(settings, null, 2));
    } catch {
      /* the island falls back to its own defaults */
    }
  }

  readSettings() {
    try {
      const raw = fs.readFileSync(this.settingsFile(), 'utf8').replace(/^\uFEFF/, '');
      return { exists: true, settings: JSON.parse(raw) };
    } catch {
      return { exists: false, settings: null };
    }
  }

  /** Bundled live wallpapers of the island (same set as the hub). */
  wallpapers() {
    const exe = this.exePath();
    if (!exe) return [];
    const dir = path.join(path.dirname(exe), 'Assets', 'Wallpapers');
    try {
      return fs
        .readdirSync(dir)
        .filter((name) => /\.(mp4|webm|mov|wmv|m4v)$/i.test(name))
        .map((name) => ({ name: name.replace(/^live-/, '').replace(/\.[^.]+$/, ''), path: path.join(dir, name) }));
    } catch {
      return [];
    }
  }

  wallpaperPath(id) {
    return this.wallpapers().find((entry) => entry.name === id)?.path || '';
  }

  /**
   * Writes a change set into settings.json. The running island watches that file and
   * merges the new values into its live settings, so nothing restarts or flickers.
   * Only the changed keys are written; values the island set itself stay untouched.
   */
  async writeSettings(patch) {
    const file = this.settingsFile();
    const current = this.readSettings().settings || { ...this.defaults().settings, FirstRun: false };
    const merge = (base, change) => {
      const out = { ...base };
      for (const [key, value] of Object.entries(change || {})) {
        out[key] = value && typeof value === 'object' && !Array.isArray(value) && base?.[key] && typeof base[key] === 'object' && !Array.isArray(base[key]) ? merge(base[key], value) : value;
      }
      return out;
    };
    const next = { ...merge(current, patch), LastSavedUtc: new Date().toISOString() };
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(`${file}.tmp`, JSON.stringify(next, null, 2));
    fs.renameSync(`${file}.tmp`, file);
    return true;
  }

  /* ----------------------------------------------------------------- inbox */

  inboxDir() {
    return path.join(path.dirname(this.settingsFile()), 'inbox');
  }

  /**
   * Drops a message into the island's inbox (it watches the folder). Used for the hub's
   * own notifications and for commands such as opening the Face ID scan.
   */
  post(message) {
    try {
      const dir = this.inboxDir();
      fs.mkdirSync(dir, { recursive: true });
      const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      fs.writeFileSync(path.join(dir, `${name}.tmp`), JSON.stringify(message));
      fs.renameSync(path.join(dir, `${name}.tmp`), path.join(dir, `${name}.json`));
      return true;
    } catch {
      return false;
    }
  }

  /** Runs a command in the island ("face", "newevent", "settings"), starting it if needed. */
  async command(name) {
    if (name === 'face') this.holdCamera(90000);
    this.post({ command: name });
    if (!(await this.refresh())) await this.start();
    return true;
  }

  /** A second start of the island opens its own settings window in the running instance. */
  openNativeSettings() {
    const exe = this.exePath();
    if (!exe) throw new Error('Revolution Island ist in dieser Installation nicht enthalten.');
    if (!this.child) return this.start();
    // Zweiter Aufruf meldet sich bei der laufenden Island und öffnet deren Einstellungen.
    const child = spawn(exe, [], { cwd: path.dirname(exe), stdio: 'ignore' });
    child.on('error', () => {});
    setTimeout(() => this.refresh(), 1500);
  }

  /** Called when the hub quits: only close the island if the hub started it. */
  shutdown() {
    clearInterval(this.timer);
    if (this.startedByHub && process.platform === 'win32') {
      try {
        require('child_process').execFileSync('taskkill', ['/IM', EXE_NAME, '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
      } catch {
        /* already closed */
      }
    }
  }
}

module.exports = { OrbitIsland };
