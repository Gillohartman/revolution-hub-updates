'use strict';

const $ = (selector) => document.querySelector(selector);
const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);

const APPS = {
  dropzone: {
    nav: 'Dateien',
    title: 'Dateien',
    sub: 'Dropzone by Revolution',
    icon: 'files',
    tint: 'linear-gradient(135deg,#5b8cff,#3a5bdb)',
    desc: 'Dateimanager mit Dual Pane, Tabs, Vorschau, Suche, ZIP, Aufräum-Assistent, Duplikat-Suche und „Pfad kopieren“.',
  },
  gaming: {
    nav: 'Gaming',
    title: 'Gaming Hub',
    sub: 'Revolution Gaming Hub',
    icon: 'crosshair',
    tint: 'linear-gradient(135deg,#ff5d8f,#c2295d)',
    desc: 'Crosshair-Overlay für Fortnite, Clips, Musik- und Leistungs-Overlay, Audio-Mixer, Statistiken und Bildschirmzeit.',
  },
  orbit: {
    nav: 'Island',
    title: 'Revolution Island',
    sub: 'Dynamic Island für Windows',
    icon: 'island',
    tint: 'linear-gradient(135deg,#9a7dff,#6a45f5)',
    desc: 'Die Dynamic Island am oberen Bildschirmrand – mit allen Einstellungen direkt hier im Hub.',
  },
  screenshot: {
    nav: 'Screenshot',
    title: 'Screenshot',
    sub: 'Aufnehmen, markieren, teilen',
    icon: 'camera',
    tint: 'linear-gradient(135deg,#38bdf8,#1d7fd1)',
    desc: 'Bereich oder Bildschirm per Hotkey aufnehmen, mit Pfeilen, Text, Markern und Verpixeln bearbeiten, kopieren oder speichern.',
  },
  video: {
    nav: 'Video',
    title: 'Video-Schnitt',
    sub: 'Schneiden & exportieren',
    icon: 'scissors',
    tint: 'linear-gradient(135deg,#ffb547,#e9720f)',
    desc: 'Videos zuschneiden, teilen und Stücke entfernen. Export als MP4, GIF oder MP3 – auch blitzschnell ohne Neukodierung.',
  },
  docs: {
    nav: 'Dokumente',
    title: 'Dokumente',
    sub: 'Textverarbeitung',
    icon: 'doc',
    tint: 'linear-gradient(135deg,#7aa7ff,#4a63e6)',
    desc: 'Schreiben wie in Word: Formatvorlagen, Tabellen, Bilder, Seitenansicht. Öffnet und speichert .docx, exportiert PDF.',
  },
  chess: {
    nav: 'Schach',
    title: 'Schach-Coach',
    sub: 'Lernen gegen die KI',
    icon: 'chess',
    tint: 'linear-gradient(135deg,#81b64c,#4e7a2c)',
    desc: 'Spiel gegen die KI (bis unschlagbar) oder online gegen Freunde. Der Coach bewertet jeden Zug, erklärt Fehler und analysiert ganze Partien.',
  },
  agenda: {
    nav: 'Agenda',
    title: 'Agenda',
    sub: 'Termine & Erinnerungen',
    icon: 'calendar',
    tint: 'linear-gradient(135deg,#ff7a59,#e8336d)',
    desc: 'Termine als Liste, Woche oder Monat – verbunden mit der Revolution Island. Erinnert dich rechtzeitig, auf Wunsch auch einen Tag vorher.',
  },
  chats: {
    nav: 'Chats',
    title: 'Chats',
    sub: 'Mit Freunden schreiben',
    icon: 'chat',
    tint: 'linear-gradient(135deg,#34d399,#0f766e)',
    desc: 'Räume und Direktnachrichten per Code. Achtung: Chats sind nicht verschlüsselt – teile keine sensiblen Daten.',
  },
  geo: {
    nav: 'Geo',
    title: 'GeoRevolution',
    sub: 'Wo auf der Welt bist du?',
    icon: 'globe',
    tint: 'linear-gradient(135deg,#22c55e,#0e7490)',
    desc: 'Street View erraten wie bei GeoGuessr: Klassisch, Tägliche Challenge, Länder-Streak und online Duell oder Party mit Freunden.',
  },
};

const NAV = ['home', 'dropzone', 'gaming', 'orbit', 'agenda', 'screenshot', 'video', 'docs', 'chess', 'geo', 'chats'];
const MODULE_PAGES = new Set(['dropzone', 'gaming', 'agenda', 'screenshot', 'video', 'docs', 'chess', 'geo', 'chats']);
// Seitenleiste: oben max. 3 angeheftete Apps, darunter frei benannte Gruppen (per Ziehen sortierbar).
const DEFAULT_NAV = () => ({
  pinned: ['home', 'gaming', 'orbit'],
  groups: [
    { id: 'g-tools', name: 'Werkzeuge', apps: ['dropzone', 'agenda', 'screenshot', 'video', 'docs'] },
    { id: 'g-fun', name: 'Spiele & Chat', apps: ['chess', 'geo', 'chats'] },
  ],
});
const PIN_MAX = 3;
const tintColor = (id) => (id === 'home' ? '#b39dff' : /#[0-9a-f]{6}/i.exec(APPS[id]?.tint || '')?.[0] || '#b39dff');
const WALL_NAMES = {
  nebula: 'Nebula', aurora: 'Aurora', galaxy: 'Galaxy', synthwave: 'Synthwave', liquid: 'Liquid', silk: 'Silk', waves: 'Waves',
  ocean: 'Ocean', clouds: 'Clouds', mountains: 'Mountains', fireflies: 'Fireflies', bokeh: 'Bokeh', lava: 'Lava', warp: 'Warp',
};

let state = null;
let page = null;
const sound = window.createClickSound();
sound.attach(document);

/* ------------------------------------------------------------------ helpers */
function toast(message, kind = '') {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast ${kind}`;
  el.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (el.hidden = true), kind === 'error' ? 7000 : 4200);
}

async function run(action, success) {
  try {
    const result = await action();
    if (success) toast(success);
    return result;
  } catch (error) {
    toast(String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
    return null;
  }
}

const moduleState = (id) => state?.modules.find((mod) => mod.id === id);
const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;

/* ---------------------------------------------------------------- wallpaper */
let currentWall = null;
function applyWallpaper() {
  const video = $('#wall');
  // Game-Modus: kein Live-Hintergrund (spart GPU und RAM)
  const id = state.gameMode ? 'none' : state.settings.wallpaper;
  $('#wall-shade').style.opacity = String(state.settings.wallpaperDim);
  if (id === currentWall) return;
  currentWall = id;
  if (id === 'none') {
    video.removeAttribute('src');
    video.load();
    video.hidden = true;
    return;
  }
  video.hidden = false;
  video.src = fileUrl(`${state.wallpaperDir}/live-${id}.mp4`);
  video.play().catch(() => {});
}

/* ---------------------------------------------------------------------- nav */
function navButton(id, label, iconName, draggable = false) {
  const live = id === 'orbit' && state?.orbit.running;
  return `<button class="nav-btn ${state?.active === id ? 'active' : ''}" data-open="${id}" title="${esc(label)}" style="--nc:${tintColor(id)}" ${draggable ? `draggable="true" data-nav-id="${id}"` : ''}>
    <span class="nav-ic">${icon(iconName, 20)}</span><span>${esc(label)}</span>${live ? '<i class="dot"></i>' : ''}
  </button>`;
}

/** Gespeicherte Anordnung – unbekannte/neue Apps landen automatisch in der letzten Gruppe. */
function navLayout() {
  const saved = state?.settings?.nav;
  const nav = saved && Array.isArray(saved.pinned) && Array.isArray(saved.groups) ? JSON.parse(JSON.stringify(saved)) : DEFAULT_NAV();
  const known = new Set(NAV);
  nav.pinned = nav.pinned.filter((id) => known.has(id)).slice(0, PIN_MAX);
  const used = new Set(nav.pinned);
  for (const g of nav.groups) g.apps = (g.apps || []).filter((id) => known.has(id) && !used.has(id) && (used.add(id), true));
  if (!nav.groups.length) nav.groups.push({ id: 'g-apps', name: 'Apps', apps: [] });
  for (const id of NAV) if (!used.has(id)) nav.groups[nav.groups.length - 1].apps.push(id);
  return nav;
}

const navBtn = (id) => (id === 'home' ? navButton('home', 'Start', 'home', true) : navButton(id, APPS[id].nav, APPS[id].icon, true));

function renderNav() {
  renderDock();
}

/* ================================================================== Dock (wie macOS) */
const TOOLS = window.HubTools?.TOOLS || {};
const SPECIAL = {
  home: { nav: 'Start', title: 'Start', icon: 'home', tint: 'linear-gradient(135deg,#a78bfa,#6d28d9)', desc: 'Die Startseite des Hubs.' },
  shop: { nav: 'Shop', title: 'Shop', icon: 'palette', tint: 'linear-gradient(135deg,#fbbf24,#f59e0b)', desc: 'Cosmetics für Schach, Geo und Chats.' },
  settings: { nav: 'Optionen', title: 'Einstellungen', icon: 'settings', tint: 'linear-gradient(135deg,#94a3b8,#475569)', desc: 'Einstellungen des Hubs.' },
};
const ALL_APPS = () => ({ ...SPECIAL, ...APPS, ...TOOLS });
const DEFAULT_DOCK = ['home', 'gaming', 'orbit', 'chess', 'geo', 'chats', 'agenda', 'dropzone', 'screenshot', 'video', 'docs', 'tool-translate', 'tool-calc', 'tool-weather'];
const dockItems = () => (state?.settings?.dock?.items || DEFAULT_DOCK).filter((id) => ALL_APPS()[id]);
const dockCfg = () => ({ pos: 'right', size: 'm', magnify: true, ...(state?.settings?.dock || {}) });
let dockDrag = null;

let dockLaunch = { id: '', until: 0 };

function dockTile(id) {
  const a = ALL_APPS()[id];
  const live = id === 'orbit' && state?.orbit?.running;
  const on = state?.active === id || (state?.opened || []).includes(id);
  const bounce = dockLaunch.id === id && Date.now() < dockLaunch.until;
  return `<button class="dock-item ${state?.active === id ? 'active' : ''} ${bounce ? 'launching' : ''}" data-open="${id}" data-dock-id="${id}" draggable="true" data-tip="${esc(a.nav || a.title)}">${appArt(id, 'dock-ic')}${live || on ? '<i class="dock-dot"></i>' : ''}${state?.badges?.[id] ? `<b class="app-badge">${state.badges[id] > 99 ? '99+' : state.badges[id]}</b>` : ''}</button>`;
}

function renderDock() {
  const el = $('#dock');
  if (!el || !state) return;
  const c = dockCfg();
  const vertical = c.pos === 'left' || c.pos === 'right';
  document.body.dataset.dock = c.pos;
  document.body.dataset.dockSize = c.size;
  el.className = `dock dock-${c.pos} size-${c.size} ${c.magnify ? 'magnify' : ''} ${dockFx.live ? 'live' : ''}`;
  // Passen nicht alle Apps hinein, werden die Kacheln kleiner (statt zu scrollen).
  const items = dockItems();
  const base = { s: 44, m: 54, l: 66 }[c.size] || 54;
  const room = (vertical ? window.innerHeight - 44 : window.innerWidth) - 64;
  const fit = Math.floor((room - 30) / (items.length + 3) - 4);
  const tile = Math.max(28, Math.min(base, fit));
  el.style.setProperty('--tile', `${tile}px`);
  const fixed = (attr, id, tip, on) => `<button class="dock-item fixed ${on ? 'active' : ''}" ${attr} data-tip="${esc(tip)}">${appArt(id, 'dock-ic')}${on ? '<i class="dock-dot"></i>' : ''}</button>`;
  morph(el, `<div class="dock-bar">${items.map((id) => dockTile(id)).join('')}<span class="dock-sep"></span>
    ${fixed('data-dock-special="launcher"', 'launcher', 'Alle Apps', overlay === 'launcher')}
    ${fixed('data-dock-special="control"', 'control', 'Kontrollzentrum', overlay === 'control')}
    ${fixed('data-open="settings"', 'settings', 'Einstellungen', state.active === 'settings')}</div>`);
  dockFx.base = null;
  if (dockFx.ev) dockMagnify(dockFx.ev);
  // Dock als eigene Ebene über den Apps: Modell an die Dock-Ebene schicken
  document.body.classList.toggle('dock-ext', Boolean(state.dockExternal));
  if (state.dockExternal) {
    const opened = state.opened || [];
    const model = {
      pos: c.pos,
      size: c.size,
      magnify: c.magnify,
      tile,
      items: items.map((id) => {
        const a = ALL_APPS()[id];
        const module = MODULE_PAGES.has(id);
        return { id, tip: a.nav || a.title, active: state.active === id, dot: (id === 'orbit' && state.orbit?.running) || state.active === id || opened.includes(id), badge: state.badges?.[id] || 0, module, canQuit: (module && opened.includes(id) && id !== 'gaming') || (!module && state.active === id && id !== 'home'), quitLabel: module ? 'App beenden' : 'Schließen' };
      }),
      fixed: [
        { id: 'launcher', special: 'launcher', tip: 'Alle Apps', active: overlay === 'launcher', dot: overlay === 'launcher' },
        { id: 'control', special: 'control', tip: 'Kontrollzentrum', active: overlay === 'control', dot: overlay === 'control' },
        { id: 'settings', tip: 'Einstellungen', active: state.active === 'settings', dot: state.active === 'settings' },
      ],
    };
    const key = JSON.stringify(model);
    if (key !== renderDock.last) {
      renderDock.last = key;
      window.hub.dockModel?.(model).catch(() => {});
    }
  }
}
window.hub.onDockSpecial?.((kind) => {
  if (kind === 'launcher' || kind === 'control') openOverlay(kind);
});

/* Dock: Vergrößern wie am Mac – die Kachel unter dem Zeiger wächst, die Nachbarn weich mit. */
const dockFx = { base: null, ev: null, live: false, tip: null };
const DOCK_MAX = 1.4;
function dockMeasure(el) {
  const bar = el.querySelector('.dock-bar');
  if (!bar) return null;
  const tile = parseFloat(el.style.getPropertyValue('--tile')) || 54;
  const kids = [...bar.children];
  const sizes = kids.map((k) => (k.classList.contains('dock-sep') ? 13 : tile));
  const total = sizes.reduce((a, b) => a + b, 0) + 4 * (kids.length - 1);
  let at = -total / 2;
  const centers = kids.map((k, i) => {
    const c = at + sizes[i] / 2;
    at += sizes[i] + 4;
    return c;
  });
  return { bar, kids, centers, tile };
}
function dockMagnify(e) {
  const el = $('#dock');
  const c = dockCfg();
  dockFx.ev = e;
  if (!el || dockDrag) return;
  if (!dockFx.base) dockFx.base = dockMeasure(el);
  const b = dockFx.base;
  if (!b) return;
  const vertical = c.pos === 'left' || c.pos === 'right';
  const r = b.bar.getBoundingClientRect();
  const p = vertical ? e.clientY - (r.top + r.height / 2) : e.clientX - (r.left + r.width / 2);
  const range = b.tile * 2.7;
  if (!dockFx.live) {
    dockFx.live = true;
    el.classList.add('live');
  }
  let hot = null, hotS = 0;
  b.kids.forEach((k, i) => {
    if (!k.classList.contains('dock-item')) return;
    const d = Math.abs(p - b.centers[i]);
    const s = c.magnify && d < range ? 1 + (DOCK_MAX - 1) * Math.pow((Math.cos((Math.PI * d) / range) + 1) / 2, 1.25) : 1;
    k.style.setProperty('--s', s.toFixed(3));
    if (d < b.tile * 0.62 && s >= hotS) {
      hot = k;
      hotS = s;
    }
  });
  dockTip(hot);
}
function dockCalm() {
  const el = $('#dock');
  dockFx.ev = null;
  if (!dockFx.live) return;
  dockFx.live = false;
  el?.classList.remove('live');
  el?.querySelectorAll('.dock-item').forEach((k) => k.style.removeProperty('--s'));
  dockTip(null);
}
/** Name der App neben der Kachel. Über einer geöffneten App zeigt Windows den Namen selbst (title). */
function dockTip(item) {
  const tip = $('#dock-label');
  if (!tip) return;
  const covered = MODULE_PAGES.has(state?.active) && !overlay;
  document.querySelectorAll('#dock .dock-item').forEach((k) => (covered ? k.setAttribute('title', k.dataset.tip || '') : k.removeAttribute('title')));
  if (!item || covered || dockDrag) {
    tip.hidden = true;
    dockFx.tip = null;
    return;
  }
  tip.textContent = item.dataset.tip || '';
  tip.hidden = false;
  requestAnimationFrame(() => {
    if (tip.hidden) return;
    const pos = dockCfg().pos;
    const r = item.getBoundingClientRect(), t = tip.getBoundingClientRect();
    const cx = Math.max(8, Math.min(window.innerWidth - t.width - 8, r.left + r.width / 2 - t.width / 2));
    const cy = r.top + r.height / 2 - t.height / 2;
    tip.dataset.pos = pos;
    tip.style.left = `${pos === 'left' ? r.right + 12 : pos === 'right' ? r.left - t.width - 12 : cx}px`;
    tip.style.top = `${pos === 'bottom' ? r.top - t.height - 12 : pos === 'top' ? r.bottom + 12 : cy}px`;
  });
}
document.addEventListener('mousemove', (e) => {
  if (e.target.closest?.('.dock-bar')) dockMagnify(e);
  else dockCalm();
});
document.addEventListener('mouseleave', dockCalm);
window.addEventListener('blur', dockCalm);
window.addEventListener('resize', () => renderDock());
document.addEventListener('click', (e) => {
  const it = e.target.closest?.('#dock [data-dock-id]');
  if (!it || it.classList.contains('active')) return;
  dockLaunch = { id: it.dataset.dockId, until: Date.now() + 800 };
  it.classList.add('launching');
}, true);

function saveDock(items) {
  state.settings.dock = { ...dockCfg(), items };
  renderDock();
  run(() => window.hub.setSettings({ dock: { items } }));
}

/* Dock: Ziehen zum Umsortieren, Rechtsklick-Menü */
document.addEventListener('dragstart', (e) => {
  const it = e.target.closest?.('[data-dock-id]');
  if (!it) return;
  dockDrag = it.dataset.dockId;
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', dockDrag);
  it.classList.add('dragging');
});
document.addEventListener('dragover', (e) => {
  if (!dockDrag) return;
  const over = e.target.closest?.('[data-dock-id]');
  if (!e.target.closest?.('#dock')) return;
  e.preventDefault();
  document.querySelectorAll('.dock-item.drop-before').forEach((x) => x.classList.remove('drop-before'));
  if (over && over.dataset.dockId !== dockDrag) over.classList.add('drop-before');
});
document.addEventListener('drop', (e) => {
  if (!dockDrag || !e.target.closest?.('#dock')) return;
  e.preventDefault();
  const before = e.target.closest('[data-dock-id]')?.dataset.dockId;
  const items = dockItems().filter((x) => x !== dockDrag);
  const at = before ? items.indexOf(before) : -1;
  if (at >= 0) items.splice(at, 0, dockDrag);
  else items.push(dockDrag);
  saveDock(items);
});
document.addEventListener('dragend', () => {
  dockDrag = null;
  document.querySelectorAll('.dock-item.dragging, .dock-item.drop-before').forEach((x) => x.classList.remove('dragging', 'drop-before'));
});
document.addEventListener('contextmenu', (e) => {
  const it = e.target.closest?.('#dock [data-dock-id]');
  if (!it) return;
  e.preventDefault();
  const id = it.dataset.dockId;
  const menu = $('#dock-menu');
  menu.innerHTML = `<b>${esc(ALL_APPS()[id]?.title || id)}</b><button data-dockmenu="open" data-id="${id}">Öffnen</button>${(state?.opened || []).includes(id) && id !== 'gaming' && MODULE_PAGES.has(id) ? `<button data-dockmenu="quit" data-id="${id}">App beenden</button>` : ''}${state?.active === id && !MODULE_PAGES.has(id) && id !== 'home' ? `<button data-dockmenu="quit" data-id="${id}">Schließen</button>` : ''}${id !== 'home' ? `<button data-dockmenu="remove" data-id="${id}">Aus dem Dock entfernen</button>` : ''}<button data-dockmenu="launcher">Alle Apps …</button>`;
  menu.hidden = false;
  const r = menu.getBoundingClientRect();
  menu.style.left = `${Math.min(e.clientX, window.innerWidth - r.width - 8)}px`;
  menu.style.top = `${Math.max(8, Math.min(e.clientY - r.height - 6, window.innerHeight - r.height - 8))}px`;
});
document.addEventListener('mousedown', (e) => {
  const menu = $('#dock-menu');
  if (menu && !menu.hidden && !e.target.closest('#dock-menu')) menu.hidden = true;
});
document.addEventListener('click', (e) => {
  const m = e.target.closest?.('[data-dockmenu]');
  if (!m) return;
  $('#dock-menu').hidden = true;
  const id = m.dataset.id;
  if (m.dataset.dockmenu === 'open') window.hub.open(id);
  if (m.dataset.dockmenu === 'remove') saveDock(dockItems().filter((x) => x !== id));
  if (m.dataset.dockmenu === 'quit') {
    if (MODULE_PAGES.has(id)) run(() => window.hub.closeModule(id), `${ALL_APPS()[id]?.nav || id} beendet.`);
    else window.hub.open('home');
  }
  if (m.dataset.dockmenu === 'launcher') openOverlay('launcher');
});

/* ================================================================== Starter & Kontrollzentrum */
let overlay = '';
let launcherQuery = '';
const cc = { volume: null, brightness: null, power: null, loading: false };

function openOverlay(kind) {
  overlay = overlay === kind ? '' : kind;
  window.hub.overlay?.(Boolean(overlay)).catch(() => {});
  renderOverlay();
  renderDock();
  if (overlay === 'control') {
    loadControl();
    refreshPcLive();
  }
  if (overlay === 'launcher') setTimeout(() => $('#launcher-search')?.focus(), 50);
}

function launcherHtml() {
  const all = ALL_APPS();
  const inDock = new Set(dockItems());
  const q = launcherQuery.trim().toLowerCase();
  const match = (id) => !q || `${all[id].title} ${all[id].nav} ${all[id].desc || ''}`.toLowerCase().includes(q);
  const groups = [
    ['Apps', ['home', 'shop', ...Object.keys(APPS)]],
    ['Mini-Apps', Object.keys(TOOLS)],
    ['System', ['settings']],
  ];
  return `<div class="launcher"><div class="launcher-head"><input class="input" id="launcher-search" placeholder="Apps durchsuchen …" value="${esc(launcherQuery)}" /><small class="muted">Klick öffnet · Plus legt die App ins Dock · Rechtsklick im Dock entfernt sie</small></div>
    ${groups
      .map(([name, ids]) => {
        const list = ids.filter((id) => all[id] && match(id));
        if (!list.length) return '';
        return `<h4>${name}</h4><div class="launcher-grid">${list
          .map((id) => `<div class="launch-tile"><button class="launch-open" data-launch="${id}">${appArt(id, 'launch-ic')}<b>${esc(all[id].nav || all[id].title)}</b><small>${esc(all[id].desc || all[id].sub || '')}</small></button>
            ${id === 'settings' ? '' : `<button class="launch-pin ${inDock.has(id) ? 'on' : ''}" data-pin="${id}" title="${inDock.has(id) ? 'Aus dem Dock entfernen' : 'Ins Dock legen'}">${icon(inDock.has(id) ? 'check' : 'plus', 14)}</button>`}</div>`)
          .join('')}</div>`;
      })
      .join('')}</div>`;
}

const fmtLeft = (at) => {
  const s = Math.max(0, Math.round((at - Date.now()) / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`;
};
setInterval(() => document.querySelectorAll('[data-cc-until]').forEach((el) => (el.textContent = fmtLeft(Number(el.dataset.ccUntil)))), 1000);
async function loadTimers() {
  cc.timers = await window.hub.cc.timers?.().catch(() => []) || [];
  if (overlay === 'control') renderOverlay();
}
document.addEventListener('click', async (e) => {
  const tb = e.target.closest?.('[data-cc-timer]');
  if (tb) {
    const v = tb.dataset.ccTimer === 'custom' ? parseFloat(String($('#cc-min')?.value || '').replace(',', '.')) : Number(tb.dataset.ccTimer);
    if (!v || v <= 0) return toast('Bitte Minuten eingeben.', 'error');
    await run(() => window.hub.cc.timer(v * 60, `Timer ${v} min`), `Timer ${v} min läuft – in der Island.`);
    return loadTimers();
  }
  if (e.target.closest?.('[data-cc-alarm]')) {
    cc.alarm = $('#cc-alarm')?.value || '07:00';
    const r = await run(() => window.hub.cc.alarm(cc.alarm));
    if (r) toast(`Wecker gestellt: ${new Date(r.at).toLocaleString('de-DE', { weekday: 'short', hour: '2-digit', minute: '2-digit' })}`);
    return loadTimers();
  }
});

async function loadMix() {
  cc.mix = await window.hub.mix?.list().catch(() => null) || { apps: [], error: 'Mixer nicht verfügbar' };
  if (overlay === 'control') renderOverlay();
}
let mixTimer = null;
document.addEventListener('input', (e) => {
  const pid = e.target.dataset?.mixPid;
  if (!pid) return;
  const v = Number(e.target.value) / 100;
  const a = cc.mix?.apps?.find((x) => String(x.pid) === pid);
  if (a) a.volume = v;
  clearTimeout(mixTimer);
  mixTimer = setTimeout(() => window.hub.mix.app(Number(pid), v, null).catch(() => {}), 60);
});
document.addEventListener('click', (e) => {
  const m = e.target.closest?.('[data-mix-mute]');
  if (m) {
    const a = cc.mix?.apps?.find((x) => String(x.pid) === m.dataset.mixMute);
    if (!a) return;
    a.muted = !a.muted;
    window.hub.mix.app(a.pid, null, a.muted).catch(() => {});
    return renderOverlay();
  }
  if (e.target.closest?.('[data-mix="reload"]')) loadMix();
});
window.hub.onOpenControl?.(() => {
  if (overlay !== 'control') openOverlay('control');
  loadMix();
});

async function loadControl() {
  loadTimers();
  loadMix();
  if (cc.loading) return;
  cc.loading = true;
  const [v, b, p] = await Promise.all([window.hub.cc.volume().catch(() => null), window.hub.cc.brightness().catch(() => null), window.hub.cc.power().catch(() => null)]);
  cc.volume = v;
  cc.brightness = b;
  cc.power = p;
  cc.loading = false;
  if (overlay === 'control') renderOverlay();
}

function controlHtml() {
  const s = state.settings;
  const tile = (key, label, on, ic, sub = '') => `<button class="cc-tile ${on ? 'on' : ''}" data-cc="${key}"><span class="cc-ic">${icon(ic, 20)}</span><b>${esc(label)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</button>`;
  const l = pcLive;
  const timer = window.HubTools?.timerStatus?.();
  return `<div class="control">
    <div class="cc-grid">
      ${tile('island', 'Dynamic Island', state.orbit.running, 'island', state.orbit.running ? 'An' : 'Aus')}
      ${tile('dnd', 'Nicht stören', s.dnd, 'bell', s.dnd ? 'Keine Meldungen' : 'Aus')}
      ${tile('power', cc.power?.mode === 'performance' ? 'Höchstleistung' : cc.power?.mode === 'saver' ? 'Energiesparen' : 'Ausbalanciert', cc.power?.mode === 'performance', 'bolt', 'Energiemodus')}
      ${tile('screenshot', 'Screenshot', false, 'camera', 'Bereich wählen')}
      ${tile('speed', 'WLAN-Test', false, 'gauge', 'Geschwindigkeit')}
      ${tile('lock', 'PC sperren', false, 'shield', 'Win+L')}
      ${tile('game', 'Game-Modus', state.gameMode, 'crosshair', state.gameMode ? 'Nur das Nötigste' : 'Spart RAM')}
      ${tile('notes', 'Notizen', false, 'doc', 'Schnell notieren')}
      ${tile('shieldscan', 'Schutz', false, 'shield', 'Tracker & Viren')}
      ${tile('awake', 'Wach halten', state.keepAwake, 'coffee', state.keepAwake ? (state.keepAwakeUntil ? `bis ${new Date(state.keepAwakeUntil).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}` : 'Bildschirm bleibt an') : 'PC schläft normal')}
      ${tile('account', 'Konto', false, 'users', 'Sync & Login')}
      ${tile('schem', 'Schematics', false, 'cube', 'KELPI-Cloud')}
    </div>
    <div class="cc-card cc-mix"><div class="cc-trow"><span class="cc-ic sm">${icon('volume', 16)}</span><b>Apps-Lautstärke</b><small class="muted">Strg+Umschalt+M öffnet das hier – auch im Spiel</small><button class="btn small ghost" data-mix="reload" style="margin-left:auto">${icon('refresh', 14)}</button></div>
      ${!cc.mix ? '<small class="muted">wird gelesen …</small>' : cc.mix.error && !cc.mix.apps?.length ? `<small class="muted">${esc(cc.mix.error)}</small>` : (cc.mix.apps || []).length ? cc.mix.apps.map((a) => `<div class="cc-row mix-row"><span class="mix-name" title="${esc(a.name)}">${esc(a.name)}</span><input type="range" min="0" max="100" value="${Math.round((Number(a.volume) || 0) * 100)}" data-mix-pid="${a.pid}" /><button class="mix-mute ${a.muted ? 'on' : ''}" data-mix-mute="${a.pid}" title="${a.muted ? 'Ton an' : 'Stumm'}">${icon(a.muted ? 'mute' : 'volume', 14)}</button></div>`).join('') : '<small class="muted">Gerade spielt keine App Ton ab.</small>'}
    </div>
    <div class="cc-card cc-time">
      <div class="cc-trow"><span class="cc-ic sm">${icon('timer', 16)}</span><b>Timer</b>${[1, 5, 10, 15, 30].map((m) => `<button class="chip" data-cc-timer="${m}">${m} min</button>`).join('')}<input class="input cc-min" id="cc-min" placeholder="min" inputmode="numeric" /><button class="btn small" data-cc-timer="custom">Start</button></div>
      <div class="cc-trow"><span class="cc-ic sm">${icon('clock', 16)}</span><b>Wecker</b><input class="input cc-alarm" id="cc-alarm" type="time" value="${esc(cc.alarm || '07:00')}" /><button class="btn small" data-cc-alarm="1">Stellen</button><small class="muted">läuft in der Island</small></div>
      ${(cc.timers || []).length ? `<div class="cc-tlist">${cc.timers.map((x) => `<span>${esc(x.label)} · <b data-cc-until="${x.at}">${fmtLeft(x.at)}</b></span>`).join('')}</div>` : ''}
    </div>
    <div class="cc-card"><div class="cc-row"><span class="cc-ic sm">${icon('volume', 16)}</span><input type="range" min="0" max="100" value="${cc.volume?.level ?? 50}" data-cc-range="volume" ${cc.volume ? '' : 'disabled'} /><b>${cc.volume ? `${cc.volume.level}%` : '–'}</b></div>
      ${cc.brightness != null ? `<div class="cc-row"><span class="cc-ic sm">${icon('spark', 16)}</span><input type="range" min="5" max="100" value="${cc.brightness}" data-cc-range="brightness" /><b>${cc.brightness}%</b></div>` : ''}
      <div class="cc-media"><button class="btn small ghost" data-cc-media="prev">⏮</button><button class="btn small" data-cc-media="playpause">⏯</button><button class="btn small ghost" data-cc-media="next">⏭</button><small class="muted">Steuert die Musik, die gerade läuft</small></div></div>
    <div class="cc-card cc-sys" data-pc-open="1"><span class="muted">System</span>${l ? `<div class="cc-stats"><span>CPU <b style="color:${pcCol(l.cpu)}">${Math.round(l.cpu)}%</b></span><span>RAM <b style="color:${pcCol(l.ramPct)}">${Math.round(l.ramPct)}%</b></span>${l.gpu != null ? `<span>GPU <b>${Math.round(l.gpu)}%</b></span>` : ''}</div>` : '<small class="muted">wird gemessen …</small>'}${timer ? `<span class="cc-timer">⏱ ${esc(timer)}</span>` : ''}</div>
  </div>`;
}

/* ---------------------------------------------------------- Was ist neu */
function newsHtml() {
  const N = window.WHATS_NEW;
  if (!N) return '';
  return `<div class="news"><div class="news-head"><div><span class="news-kicker">Neu · Version ${esc(state?.version || N.version)}</span><h2>${esc(N.title)}</h2><p>${esc(N.sub)}</p></div><button class="btn ghost small" data-news="close">Schliessen</button></div>
    <div class="news-grid">${N.items.map((it, i) => `<button class="news-item" data-news-open="${esc(it.open)}" style="animation-delay:${i * 45}ms">${appArt(it.icon, 'news-ic')}<div><b>${esc(it.title)}</b><small>${esc(it.text)}</small></div><span class="news-go">›</span></button>`).join('')}</div></div>`;
}
document.addEventListener('click', (e) => {
  const go = e.target.closest?.('[data-news-open]')?.dataset.newsOpen;
  if (go) {
    openOverlay('news'); // schliessen
    $('#news-back').hidden = false;
    return window.hub.open(go);
  }
  if (e.target.closest?.('[data-news="close"]')) {
    $('#news-back').hidden = true;
    return openOverlay('news');
  }
  if (e.target.closest?.('#news-back')) {
    if (overlay !== 'news') openOverlay('news');
    return;
  }
  if (e.target.closest?.('[data-news="show"]')) openOverlay('news');
});
function maybeShowNews() {
  const v = state?.version;
  if (!v || !window.WHATS_NEW || state.settings?.seenVersion === v) return;
  window.hub.setSettings({ seenVersion: v }).catch(() => {});
  setTimeout(() => {
    if (overlay !== 'news') openOverlay('news');
  }, 900);
}

function renderOverlay() {
  const host = $('#overlay');
  if (!host) return;
  if (!overlay) {
    host.hidden = true;
    host.innerHTML = '';
    return;
  }
  host.hidden = false;
  host.className = `overlay ov-${overlay} dockpos-${dockCfg().pos}`;
  morph(host, `<div class="ov-sheet">${overlay === 'launcher' ? launcherHtml() : overlay === 'news' ? newsHtml() : controlHtml()}</div>`);
}

document.addEventListener('mousedown', (e) => {
  if (overlay && e.target.id === 'overlay') openOverlay('');
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && overlay) openOverlay('');
});
document.addEventListener('input', (e) => {
  if (e.target.id === 'launcher-search') {
    launcherQuery = e.target.value;
    renderOverlay();
  }
  const r = e.target.dataset?.ccRange;
  if (r === 'volume') {
    cc.volume = { ...(cc.volume || {}), level: Number(e.target.value) };
    e.target.nextElementSibling.textContent = `${e.target.value}%`;
    clearTimeout(cc.vt);
    cc.vt = setTimeout(() => window.hub.cc.volume(Number(e.target.value)).catch(() => {}), 120);
  }
  if (r === 'brightness') {
    cc.brightness = Number(e.target.value);
    e.target.nextElementSibling.textContent = `${e.target.value}%`;
    window.hub.cc.brightness(Number(e.target.value)).catch(() => {});
  }
});
document.addEventListener('click', async (e) => {
  const sp = e.target.closest?.('[data-dock-special]');
  if (sp) return openOverlay(sp.dataset.dockSpecial);
  const lo = e.target.closest?.('[data-launch]');
  if (lo) {
    openOverlay('');
    return window.hub.open(lo.dataset.launch);
  }
  const pin = e.target.closest?.('[data-pin]');
  if (pin) {
    const id = pin.dataset.pin;
    const items = dockItems();
    saveDock(items.includes(id) ? items.filter((x) => x !== id) : [...items, id]);
    return renderOverlay();
  }
  const media = e.target.closest?.('[data-cc-media]');
  if (media) return window.hub.cc.media(media.dataset.ccMedia).catch(() => {});
  const t = e.target.closest?.('[data-cc]');
  if (!t) return;
  const k = t.dataset.cc;
  if (k === 'island') await run(() => (state.orbit.running ? window.hub.orbit.stop() : window.hub.orbit.start()));
  if (k === 'dnd') await run(() => window.hub.setSettings({ dnd: !state.settings.dnd }), !state.settings.dnd ? 'Nicht stören ist an – keine Meldungen.' : 'Meldungen sind wieder an.');
  if (k === 'power') {
    cc.power = await window.hub.cc.power(cc.power?.mode === 'performance' ? 'balanced' : 'performance').catch(() => cc.power);
  }
  if (k === 'screenshot') {
    openOverlay('');
    return window.hub.cc.screenshot();
  }
  if (k === 'lock') return window.hub.cc.lock();
  if (k === 'game') {
    await run(() => window.hub.gameMode(!state.gameMode));
    return renderOverlay();
  }
  if (k === 'awake') {
    await run(() => window.hub.awake(!state.keepAwake, 0), !state.keepAwake ? 'PC bleibt wach – bis du es wieder ausschaltest.' : 'PC darf wieder schlafen.');
    return renderOverlay();
  }
  if (k === 'account' || k === 'schem') {
    openOverlay('');
    return window.hub.open(k === 'account' ? 'tool-account' : 'tool-schematics');
  }
  if (k === 'notes') {
    openOverlay('');
    return window.hub.open('tool-notes');
  }
  if (k === 'shieldscan') {
    openOverlay('');
    return window.hub.open('tool-shield');
  }
  if (k === 'speed') {
    openOverlay('');
    await window.hub.open('settings');
    return setTimeout(() => $('#speed-box')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 300);
  }
  renderOverlay();
});

/* ------------------------------------------------- Seitenleiste: Ziehen & Gruppen */
let dragNav = null;
function saveNav(nav) {
  run(() => window.hub.setSettings({ nav }));
}
document.addEventListener('dragstart', (event) => {
  const btn = event.target.closest?.('[data-nav-id]');
  if (!btn) return;
  dragNav = btn.dataset.navId;
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', dragNav);
  btn.classList.add('dragging');
  document.body.classList.add('nav-dragging');
});
document.addEventListener('dragend', () => {
  dragNav = null;
  document.body.classList.remove('nav-dragging');
  document.querySelectorAll('.nav-btn.dragging, .drop-before, .zone-over').forEach((el) => el.classList.remove('dragging', 'drop-before', 'zone-over'));
});
document.addEventListener('dragover', (event) => {
  if (!dragNav) return;
  const zone = event.target.closest?.('[data-zone]');
  if (!zone) return;
  event.preventDefault();
  document.querySelectorAll('.drop-before, .zone-over').forEach((el) => el.classList.remove('drop-before', 'zone-over'));
  const before = event.target.closest('[data-nav-id]');
  if (before && before.dataset.navId !== dragNav) before.classList.add('drop-before');
  else (zone.closest('.nav-zone') || zone).classList.add('zone-over');
});
document.addEventListener('drop', (event) => {
  if (!dragNav) return;
  const zoneEl = event.target.closest?.('[data-zone]');
  if (!zoneEl) return;
  event.preventDefault();
  const zone = zoneEl.dataset.zone;
  const beforeId = event.target.closest('[data-nav-id]')?.dataset.navId;
  const nav = navLayout();
  const lists = [nav.pinned, ...nav.groups.map((g) => g.apps)];
  for (const l of lists) {
    const i = l.indexOf(dragNav);
    if (i >= 0) l.splice(i, 1);
  }
  const target = zone === 'pinned' ? nav.pinned : nav.groups.find((g) => g.id === zone)?.apps;
  if (!target) return;
  const at = beforeId && beforeId !== dragNav ? target.indexOf(beforeId) : -1;
  if (at >= 0) target.splice(at, 0, dragNav);
  else target.push(dragNav);
  // Oben höchstens 3 – die überzählige App rutscht in die erste Gruppe
  while (nav.pinned.length > PIN_MAX) {
    const k = nav.pinned.map((x, i) => i).reverse().find((i) => nav.pinned[i] !== dragNav);
    nav.groups[0].apps.unshift(nav.pinned.splice(k, 1)[0]);
  }
  state.settings.nav = nav;
  renderNav();
  saveNav(nav);
});

/** Kleines Eingabefeld (prompt() gibt es in Electron nicht). */
function askText(title, value, done) {
  const box = document.createElement('div');
  box.className = 'ask-back';
  box.innerHTML = `<div class="ask"><b>${esc(title)}</b><input class="input" maxlength="18" value="${esc(value)}" /><div class="ask-btns"><button class="btn ghost" data-ask="no">Abbrechen</button><button class="btn primary" data-ask="ok">OK</button></div></div>`;
  document.body.appendChild(box);
  const input = box.querySelector('input');
  input.focus();
  input.select();
  const close = (ok) => {
    const v = input.value.trim().slice(0, 18);
    box.remove();
    if (ok && v) done(v);
  };
  box.addEventListener('click', (e) => {
    const a = e.target.closest('[data-ask]')?.dataset.ask;
    if (a) close(a === 'ok');
    else if (e.target === box) close(false);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') close(true);
    if (e.key === 'Escape') close(false);
  });
}

/** Rechtsklick auf die Seitenleiste: Gruppen anlegen, umbenennen, löschen, zurücksetzen. */
document.addEventListener('contextmenu', (event) => {
  const rail = event.target.closest?.('#nav');
  if (!rail) return;
  event.preventDefault();
  const groupId = event.target.closest('[data-group]')?.dataset.group || '';
  const menu = $('#nav-menu');
  menu.innerHTML = `<button data-navmenu="new">＋ Neue Gruppe</button>${groupId ? '<button data-navmenu="rename">✎ Gruppe umbenennen</button><button data-navmenu="delete">✕ Gruppe auflösen</button>' : ''}<button data-navmenu="reset">↺ Standard-Anordnung</button><small>Apps lassen sich per Ziehen verschieben. Oben max. ${PIN_MAX}.</small>`;
  menu.dataset.group = groupId;
  menu.style.left = `${event.clientX + 4}px`;
  menu.style.top = `${Math.min(event.clientY, window.innerHeight - 180)}px`;
  menu.hidden = false;
});
document.addEventListener('mousedown', (event) => {
  const menu = $('#nav-menu');
  if (menu && !menu.hidden && !event.target.closest('#nav-menu')) menu.hidden = true;
});
document.addEventListener('click', (event) => {
  const toggle = event.target.closest?.('[data-group-toggle]');
  if (toggle) {
    const id = toggle.dataset.groupToggle;
    const set = new Set(state.settings.navCollapsed || []);
    if (set.has(id)) set.delete(id);
    else set.add(id);
    state.settings.navCollapsed = [...set];
    renderNav();
    run(() => window.hub.setSettings({ navCollapsed: [...set] }));
    return;
  }
  const item = event.target.closest?.('[data-navmenu]');
  if (!item) return;
  const menu = $('#nav-menu');
  menu.hidden = true;
  const nav = navLayout();
  const gid = menu.dataset.group;
  const act = item.dataset.navmenu;
  if (act === 'new') {
    return askText('Name der neuen Gruppe', 'Neue Gruppe', (name) => {
      nav.groups.push({ id: `g-${Date.now().toString(36)}`, name, apps: [] });
      state.settings.nav = nav;
      renderNav();
      saveNav(nav);
    });
  } else if (act === 'rename') {
    const g = nav.groups.find((x) => x.id === gid);
    if (!g) return;
    return askText('Gruppe umbenennen', g.name, (name) => {
      g.name = name;
      state.settings.nav = nav;
      renderNav();
      saveNav(nav);
    });
  } else if (act === 'delete') {
    const i = nav.groups.findIndex((x) => x.id === gid);
    if (i < 0 || nav.groups.length < 2) return;
    const [g] = nav.groups.splice(i, 1);
    nav.groups[Math.max(0, i - 1)].apps.push(...g.apps);
  } else if (act === 'reset') {
    Object.assign(nav, DEFAULT_NAV());
  }
  state.settings.nav = nav;
  renderNav();
  saveNav(nav);
});

/* -------------------------------------------------------------------- pages */
function appCard(id) {
  const app = APPS[id];
  const mod = moduleState(id);
  let status = '<span class="pill ok">Bereit</span>';
  if (mod?.error) status = '<span class="pill bad">Fehler beim Laden</span>';
  else if (id === 'orbit') {
    status = !state.orbit.available ? '<span class="pill">Nicht verfügbar</span>' : state.orbit.running ? '<span class="pill ok">Läuft</span>' : '<span class="pill">Aus</span>';
  } else if (id === 'gaming') status = '<span class="pill ok">Aktiv im Hintergrund</span>';
  else if (id === 'screenshot') status = state.screenshotHotkey ? `<span class="pill ok">Hotkey ${esc(state.screenshotHotkey)}</span>` : '<span class="pill">Kein Hotkey</span>';
  return `<article class="card app" data-open="${id}">
    <div class="card-head">
      ${appArt(id, 'app-icon')}
      <div><h3>${esc(app.title)}</h3><div class="sub">${esc(app.sub)}</div></div>
    </div>
    <p class="desc">${esc(app.desc)}</p>
    <div class="card-foot">${status}<span class="open-link">Öffnen ${icon('arrow', 16)}</span></div>
  </article>`;
}

function pageHome() {
  const hour = new Date().getHours();
  const greeting = hour < 11 ? 'Guten Morgen' : hour < 18 ? 'Hallo' : 'Guten Abend';
  const failed = state.modules.filter((mod) => mod.error);
  return `<div class="page">
    <div class="hero">
      <div>
        <span class="eyebrow">Revolution Hub</span>
        <h2>${greeting}${profile?.name ? `, ${esc(profile.name)}` : ''}!</h2>
        <p>Alle deine Revolution-Apps und Werkzeuge in einem Fenster. Crosshair, Screenshot-Hotkey und Revolution Island arbeiten im Hintergrund weiter.</p>
      </div>
      ${profileCardHtml()}
    </div>
    ${failed.length ? `<div class="note" style="margin-bottom:16px">${icon('alert', 18)}<div>${failed.map((mod) => `<b>${esc(mod.name)}</b> konnte nicht geladen werden: ${esc(mod.error)}`).join('<br>')}</div></div>` : ''}
    ${upcomingHtml()}
    <div class="grid">${['dropzone', 'gaming', 'orbit', 'agenda', 'screenshot', 'video', 'docs', 'chess', 'geo', 'chats'].map(appCard).join('')}${homeSysHtml()}</div>
  </div>`;
}

/* ------------------------------------------------------------------ Profil & Shop */
let profile = null;
let shopSlot = 'pieces';
const Cos = () => window.RevCos;

function profileCardHtml() {
  if (!profile || !Cos()) return '';
  const eq = profile.cos.eq;
  return `<button class="me-card" data-open="shop">
    ${Cos().avatarHtml(eq, 54)}
    <div class="me-txt"><b ${Cos().nameStyle(eq)}>${esc(profile.name || 'Kein Name')}</b>${Cos().titleHtml(eq)}<span class="me-pts">◆ ${profile.points.toLocaleString('de-DE')} Punkte</span></div>
    <span class="me-shop">${icon('palette', 16)} Shop</span>
  </button>`;
}

const SLOT_DESC = {
  pieces: 'Wie deine Figuren im Schach aussehen – auch deine Gegner sehen sie.',
  board: 'Das Schachbrett, auf dem du spielst.',
  avatar: 'Dein Bild in Schach, Geo, Chats und Ranglisten. Oder lade dein eigenes hoch.',
  color: 'Hintergrund deines Bildes.',
  frame: 'Rahmen um dein Bild.',
  name: 'Farbe deines Namens.',
  title: 'Titel neben deinem Namen.',
  effect: 'Effekt bei jedem Schachzug.',
};

function pageShop() {
  if (!profile || !Cos()) return '<div class="page"><div class="empty">Shop wird geladen …</div></div>';
  const C = Cos();
  const eq = profile.cos.eq;
  const slots = Object.keys(C.COSMETICS);
  const items = C.COSMETICS[shopSlot] || [];
  return `<div class="page shop-page">
    <div class="shop-head">
      <div class="shop-me">${C.avatarHtml(eq, 88)}<div><b ${C.nameStyle(eq)}>${esc(profile.name || 'Kein Name')}</b>${C.titleHtml(eq)}<small>Ein Profil für Schach, Geo und Chats</small></div></div>
      <div class="shop-pts"><span>Deine Punkte</span><b>◆ ${profile.points.toLocaleString('de-DE')}</b><small>Punkte gibt es in Schach (Lernpfad, Partien) und Geo (Runden, Ranked).</small></div>
    </div>
    <div class="shop-tabs">${slots.map((sl) => `<button class="${sl === shopSlot ? 'on' : ''}" data-shop-slot="${sl}">${esc(C.SLOT_NAMES[sl]?.de || sl)}</button>`).join('')}</div>
    <p class="muted shop-desc">${esc(SLOT_DESC[shopSlot] || '')}</p>
    <div class="shop-grid">${items
      .map((it, i) => {
        const owned = it.price === 0 || (profile.cos.owned[shopSlot] || []).includes(it.id);
        const on = (eq[shopSlot] || C.COSMETICS[shopSlot][0].id) === it.id;
        const name = it.t?.de || (it.glyph ? '' : '') || '';
        const afford = profile.points >= it.price;
        const action = on ? (it.custom ? 'Neues Bild' : 'Angelegt') : owned ? (it.custom ? 'Bild hochladen' : 'Anlegen') : `◆ ${it.price.toLocaleString('de-DE')}`;
        return `<button class="shop-card ${on ? 'on' : ''} ${owned ? 'owned' : ''} ${!owned && !afford ? 'locked' : ''} ${it.anim ? 'anim' : ''}" data-shop-item="${it.id}" style="animation-delay:${Math.min(i, 12) * 35}ms">
          <div class="sc-prev">${C.preview(shopSlot, it, eq, profile.name)}</div>
          ${name ? `<span class="sc-name">${esc(name)}</span>` : ''}
          <span class="sc-act">${action}</span></button>`;
      })
      .join('')}</div>
  </div>`;
}

function uploadProfileImage() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.onchange = () => {
    const file = input.files?.[0];
    if (!file) return;
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = c.height = 96;
      const side = Math.min(img.width, img.height);
      c.getContext('2d').drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 96, 96);
      URL.revokeObjectURL(img.src);
      run(() => window.hub.profile.image(c.toDataURL('image/jpeg', 0.82)), 'Profilbild gespeichert.').then((p) => p && setProfile(p));
    };
    img.src = URL.createObjectURL(file);
  };
  input.click();
}

function setProfile(p) {
  profile = p;
  if (['home', 'shop', 'settings'].includes(state?.active)) render();
}

document.addEventListener('click', async (event) => {
  const slot = event.target.closest?.('[data-shop-slot]');
  if (slot) {
    shopSlot = slot.dataset.shopSlot;
    return render();
  }
  const item = event.target.closest?.('[data-shop-item]');
  if (!item) return;
  const C = Cos();
  const it = C.COSMETICS[shopSlot].find((x) => x.id === item.dataset.shopItem);
  const owned = it.price === 0 || (profile.cos.owned[shopSlot] || []).includes(it.id);
  if (!owned) {
    if (profile.points < it.price) return toast(`Dafür fehlen dir noch ◆ ${(it.price - profile.points).toLocaleString('de-DE')}.`, 'error');
    const p = await run(() => window.hub.profile.buy(shopSlot, it.id), 'Freigeschaltet!');
    if (p) {
      sound.play('success');
      setProfile(p);
      if (it.custom) uploadProfileImage();
    }
    return;
  }
  if (it.custom) return uploadProfileImage();
  const p = await run(() => window.hub.profile.equip(shopSlot, it.id));
  if (p) setProfile(p);
});

/** Startseite: die nächsten Termine aus der Agenda. */
function upcomingHtml() {
  const list = state.upcoming || [];
  if (!list.length) return '';
  const fmt = (e) => {
    const d = new Date(e.start);
    const today = new Date();
    const tomorrow = new Date(Date.now() + 86400000);
    const day = d.toDateString() === today.toDateString() ? 'Heute' : d.toDateString() === tomorrow.toDateString() ? 'Morgen' : d.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
    return e.allDay ? `${day} · ganztägig` : `${day} · ${d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
  };
  return `<div class="upcoming card" data-open="agenda">
    <div class="up-head">${icon('calendar', 18)}<b>Nächste Termine</b><span class="open-link">Agenda ${icon('arrow', 14)}</span></div>
    <div class="up-list">${list.map((e) => `<div class="up-item"><i style="background:${esc(e.color)}"></i><div><b>${esc(e.title)}</b><small>${esc(fmt(e))}${e.location ? ` · ${esc(e.location)}` : ''}</small></div></div>`).join('')}</div>
  </div>`;
}

function pageModule(id) {
  const mod = moduleState(id);
  if (mod?.error) {
    return `<div class="page"><div class="note">${icon('alert', 18)}<div><b>${esc(APPS[id].title)}</b> konnte nicht geladen werden.<br>${esc(mod.error)}</div></div></div>`;
  }
  // The app is drawn on top; the page stays empty so the wallpaper shows through.
  if (mod?.ready) return '';
  return `<div class="page"><div class="empty">${icon('refresh', 22).replace('class="icon"', 'class="icon spin"')}<br>${esc(APPS[id].title)} wird geladen …</div></div>`;
}

function settingRow(key, title, text, on) {
  return `<div class="list-row"><div class="grow"><strong>${esc(title)}</strong><small>${esc(text)}</small></div><button class="switch ${on ? 'on' : ''}" data-setting="${key}" aria-pressed="${on}"></button></div>`;
}

const FRIENDLY = { hub: 'Revolution Hub', dropzone: 'Dateien (Dropzone)', gaming: 'Gaming Hub', orbit: 'Revolution Island', sysmon: 'System-Monitor', screenshot: 'Screenshots', video: 'Video-Schnitt', docs: 'Dokumente', chess: 'Schach-Coach', geo: 'GeoRevolution', agenda: 'Agenda', chats: 'Chats' };

/** „PC-Stärke“: Einstufung 1–10 aus CPU, RAM und Grafikkarte. */
let pcInfo = null;
let pcLoading = false;
let pcLive = null;
let pcBig = false;
let pcTimer = null;

const pcPct = (v) => (v == null ? '–' : `${Math.round(v)} %`);
const pcCol = (v) => (v == null ? '#64748b' : v >= 85 ? '#f87171' : v >= 60 ? '#fbbf24' : '#4ade80');

function pcStatsHtml(big = false) {
  const l = pcLive;
  if (!l) return `<div class="pc-stats"><span class="pc-wait">Live-Werte werden gemessen …</span></div>`;
  const sys = l.disks.find((d) => d.d === 'C:') || l.disks[0];
  const diskPct = sys ? 100 - (sys.free / sys.size) * 100 : null;
  const stats = [
    ['CPU', l.cpu, pcPct(l.cpu)],
    ['RAM', l.ramPct, `${String(l.ramUsed).replace('.', ',')} / ${String(l.ramTotal).replace('.', ',')} GB`],
    ['GPU', l.gpu, pcPct(l.gpu)],
    [`Laufwerk ${sys?.d || ''}`, diskPct, sys ? `${Math.round(sys.free / 1024 ** 3)} GB frei` : '–'],
  ];
  return `<div class="pc-stats ${big ? 'big' : ''}">${stats
    .map(([n, v, d]) => `<div class="pc-stat" style="--c:${pcCol(v)}"><span>${n}</span><b>${v == null ? '–' : Math.round(v) + '<i>%</i>'}</b><div class="pc-mini"><i style="width:${Math.max(2, Math.min(100, v || 0))}%"></i></div><small>${esc(d)}</small></div>`)
    .join('')}</div>`;
}

function pcVerdictHtml() {
  if (!pcLive) return '';
  const v = pcLive.verdict;
  return `<div class="pc-verdict ${v.ok ? 'ok' : 'bad'}">${icon(v.ok ? 'check' : 'alert', 16)}<span>${esc(v.text)}</span>${!v.ok ? '<em>Details ›</em>' : ''}</div>`;
}

function pcBigHtml() {
  const p = pcInfo;
  const l = pcLive;
  if (!p) return '';
  const hue = 10 + p.level * 12;
  const bars = [['Prozessor', p.scores.cpu, `${p.cpu} · ${p.cores} Threads${p.ghz ? ` · ${String(p.ghz).replace('.', ',')} GHz` : ''}`], ['Arbeitsspeicher', p.scores.ram, `${String(p.ram).replace('.', ',')} GB`], ['Grafikkarte', p.scores.gpu, p.gpu ? `${p.gpu.name}${p.gpu.vram ? ` · ${String(p.gpu.vram).replace('.', ',')} GB` : ''}` : 'Nicht erkannt']];
  const procRows = (list) => `<table class="pc-procs"><tr><th>Programm</th><th>CPU</th><th>RAM</th></tr>${list.map((x) => `<tr><td>${esc(x.n)}${x.k > 1 ? ` <small>×${x.k}</small>` : ''}</td><td style="color:${pcCol(x.c * 2)}">${String(Math.round(x.c * 10) / 10).replace('.', ',')} %</td><td>${x.m >= 1024 ? String(Math.round(x.m / 102.4) / 10).replace('.', ',') + ' GB' : x.m + ' MB'}</td></tr>`).join('')}</table>`;
  const issues = l
    ? l.issues.length
      ? l.issues.map((x) => `<div class="pc-issue sev${x.sev}"><b>${esc(x.title)}</b><p>${esc(x.text)}</p>${x.procs?.length ? procRows(x.procs) : ''}</div>`).join('')
      : `<div class="pc-issue ok"><b>Alles im grünen Bereich</b><p>Keine Hintergrundprozesse, kein Energiesparmodus, genug Speicher – dein PC läuft so schnell, wie es seine Hardware erlaubt.</p></div>`
    : '<div class="pc-wait">Analyse läuft …</div>';
  return `<div class="pc-modal" data-pc-close="1"><div class="pc-sheet">
    <button class="pc-x" data-pc-close="1">${icon('close', 18)}</button>
    <div class="pc-top">
      <div class="pc-level big" style="--h:${hue}"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" class="trk"/><circle cx="60" cy="60" r="50" class="val" style="stroke-dasharray:${(p.level / 10) * 314} 314"/></svg><div><b>${p.level}</b><span>von 10</span></div></div>
      <div class="pc-info"><strong>PC-Stärke: ${esc(p.label)}</strong>
        ${l ? `<small>Gerade nutzbar: <b style="color:${l.effective >= p.level - 0.5 ? '#4ade80' : '#fbbf24'}">${String(l.effective).replace('.', ',')} / 10</b> · Aktualisiert alle paar Sekunden</small>` : ''}
        ${bars.map(([n, v, d]) => `<div class="pc-bar"><span>${n}</span><div class="pc-track"><i style="width:${v * 10}%"></i></div><small>${esc(d)}</small></div>`).join('')}
      </div>
    </div>
    <div id="pc-live-big">${pcStatsHtml(true)}</div>
    <h4 class="pc-h">Analyse – bringt dein PC seine Leistung?</h4>
    <div id="pc-analysis">${pcVerdictHtml()}${issues}</div>
    ${l ? `${l.procs.length ? `<h4 class="pc-h">Größte Prozesse gerade</h4><div id="pc-top-procs">${procRows(l.procs)}</div>` : ''}
    <p class="muted pc-foot">Energieplan: ${esc(l.planName || 'unbekannt')} · ${l.autostart} Autostart-Programme · läuft seit ${l.uptime >= 86400 ? Math.floor(l.uptime / 86400) + ' Tag(en)' : Math.floor(l.uptime / 3600) + ' Std.'}</p>` : ''}
  </div></div>`;
}

function refreshPcLive() {
  if (pcTimer) return;
  const tick = async () => {
    const visible = state?.active === 'settings' || state?.active === 'home' || pcBig || overlay === 'control';
    if (!visible) {
      pcTimer = null;
      return;
    }
    try {
      pcLive = await window.hub.pcLive();
    } catch {}
    pcPatch();
    if (overlay === 'control') renderOverlay();
    const small = $('#pc-live');
    if (small) morph(small, pcStatsHtml() + pcVerdictHtml());
    const big = $('#pc-big-host');
    if (big && pcBig) {
      const sc = big.querySelector('.pc-sheet')?.scrollTop || 0;
      morph(big, pcBigHtml());
      big.classList.add('pc-still');
      const sheet = big.querySelector('.pc-sheet');
      if (sheet) sheet.scrollTop = sc;
    }
    pcTimer = setTimeout(tick, pcBig ? 2500 : 4000);
  };
  pcTimer = setTimeout(tick, 50);
}

function setPcBig(on) {
  pcBig = on;
  let host = $('#pc-big-host');
  if (!host) {
    host = document.createElement('div');
    host.id = 'pc-big-host';
    document.body.appendChild(host);
  }
  if (on && !pcInfo) window.hub.pcInfo?.().then((r) => { pcInfo = r; if (pcBig) host.innerHTML = pcBigHtml(); }).catch(() => {});
  host.classList.remove('pc-still');
  host.innerHTML = on ? pcBigHtml() : '';
  if (on) refreshPcLive();
}

document.addEventListener('click', (event) => {
  if (event.target.closest?.('[data-pc-close]') && (event.target.dataset.pcClose || event.target.closest('.pc-x'))) return setPcBig(false);
  if (event.target.closest?.('[data-pc-open]')) setPcBig(true);
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && pcBig) setPcBig(false);
});

/* ------------------------------------------------------------------ WLAN-Speedtest */
const speed = { running: false, phase: '', pct: 0, live: {}, result: null, wlan: undefined, history: null, error: '' };
const fmtN = (v) => (v == null ? '–' : String(v).replace('.', ','));
const PHASES = { wlan: 'WLAN wird geprüft …', ping: 'Ping wird gemessen …', down: 'Download wird gemessen …', up: 'Upload wird gemessen …', done: 'Fertig' };

function speedGauge(label, value, unit, active, color) {
  return `<div class="sp-g ${active ? 'on' : ''}" style="--c:${color}"><span>${label}</span><b>${value == null ? '–' : fmtN(value)}</b><small>${unit}</small></div>`;
}

function speedInner() {
  const r = speed.result;
  const live = speed.running ? speed.live : r || {};
  const w = speed.running ? speed.wlan : r?.wlan ?? speed.wlan;
  const sig = w?.signal || 0;
  const wlanLine = w === undefined ? '<span class="muted">WLAN wird gelesen …</span>' : !w ? '<span class="muted">WLAN-Daten nicht verfügbar</span>' : !w.connected ? '<span class="muted">Nicht per WLAN verbunden (Kabel?)</span>'
    : `<span class="sp-wifi" style="--s:${sig >= 65 ? '#4ade80' : sig >= 40 ? '#fbbf24' : '#f87171'}"><i class="${sig >= 25 ? 'a' : ''}"></i><i class="${sig >= 50 ? 'a' : ''}"></i><i class="${sig >= 75 ? 'a' : ''}"></i></span>
       <b>${esc(w.ssid || 'WLAN')}</b><span>${sig} % Signal</span>${w.band ? `<span>${esc(w.band)}</span>` : ''}${w.rx ? `<span>Funkrate ${fmtN(w.rx)} MBit/s</span>` : ''}`;
  const tips = r && !speed.running
    ? (r.tips.length ? r.tips.map((x) => `<div class="pc-issue sev${x.sev}"><b>${esc(x.title)}</b><p>${esc(x.text)}</p></div>`).join('') : `<div class="pc-issue ok"><b>Alles bestens</b><p>Signal, Ping und Geschwindigkeit sind gut – da bremst nichts.</p></div>`)
    : '';
  const hist = (speed.history || []).slice(0, 5);
  return `<div class="sp-top">
      <div class="sp-wlan">${wlanLine}</div>
      <button class="btn ${speed.running ? '' : 'primary'}" data-speed="run" ${speed.running ? 'disabled' : ''}>${speed.running ? '⏳ Läuft …' : r ? 'Nochmal testen' : 'Test starten'}</button>
    </div>
    <div class="sp-gauges">
      ${speedGauge('Download', live.down, 'MBit/s', speed.phase === 'down', '#38bdf8')}
      ${speedGauge('Upload', live.up, 'MBit/s', speed.phase === 'up', '#a78bfa')}
      ${speedGauge('Ping', live.ping, 'ms', speed.phase === 'ping', '#4ade80')}
    </div>
    ${speed.running ? `<div class="sp-prog"><div class="pc-mini" style="--c:#38bdf8"><i style="width:${Math.round(speed.pct)}%"></i></div><small>${esc(PHASES[speed.phase] || '')}</small></div>` : ''}
    ${speed.error ? `<div class="pc-issue sev3"><b>Test fehlgeschlagen</b><p>${esc(speed.error)}</p></div>` : ''}
    ${r && !speed.running ? `<div class="sp-grade">Ergebnis: <b>${esc(r.grade)}</b>${r.jitter != null ? ` · Schwankung ${r.jitter} ms` : ''}${r.loss ? ` · ${r.loss} % Verlust` : ''}</div>${tips}` : ''}
    ${hist.length > 1 && !speed.running ? `<div class="sp-hist"><span>Letzte Tests</span>${hist.map((h) => `<div><small>${new Date(h.at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</small><b>↓ ${fmtN(h.down)}</b><b>↑ ${fmtN(h.up)}</b><b>${h.ping} ms</b></div>`).join('')}</div>` : ''}
    <p class="muted sp-note">Getestet über speed.cloudflare.com, ca. 20 Sekunden. Bei langsamem WLAN werden nur wenige MB geladen.</p>`;
}

function speedPatch() {
  const el = $('#speed-box');
  if (el) el.innerHTML = speedInner();
}

function speedHtml() {
  if (speed.wlan === undefined && !speed.wlanLoading) {
    speed.wlanLoading = true;
    window.hub.speed?.wlan().then((w) => { speed.wlan = w || null; speedPatch(); }).catch(() => { speed.wlan = null; speedPatch(); });
    window.hub.speed?.history().then((h) => { speed.history = h; speedPatch(); }).catch(() => {});
  }
  return `<div class="section"><h4>Internet & WLAN</h4><div class="panel sp-panel" id="speed-box">${speedInner()}</div></div>`;
}

window.hub.onSpeed?.((p) => {
  speed.phase = p.phase;
  speed.pct = p.pct;
  if (p.phase === 'ping' && p.value != null) speed.live.ping = Math.round(p.value);
  if (p.phase === 'down' && p.value != null) speed.live.down = p.value;
  if (p.phase === 'up' && p.value != null) speed.live.up = p.value;
  speedPatch();
});

document.addEventListener('click', async (event) => {
  if (!event.target.closest?.('[data-speed="run"]') || speed.running) return;
  speed.running = true;
  speed.error = '';
  speed.live = {};
  speed.phase = 'wlan';
  speed.pct = 0;
  speedPatch();
  try {
    const r = await window.hub.speed.run();
    speed.result = r;
    speed.wlan = r.wlan ?? speed.wlan;
    speed.history = [{ at: r.at, down: r.down, up: r.up, ping: r.ping }, ...(speed.history || [])].slice(0, 10);
    sound.play('success');
  } catch (error) {
    speed.error = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  }
  speed.running = false;
  speed.phase = '';
  speedPatch();
});

/** Startseite: Live-Systemkarte (ersetzt den System-Tab). Klick öffnet die große Ansicht. */
function homeSysInner() {
  const l = pcLive;
  const p = pcInfo;
  if (!l) return `<div class="hs-wait">${icon('cpu', 18)} Systemwerte werden gemessen …</div>`;
  const sys = l.disks.find((d) => d.d === 'C:') || l.disks[0];
  const diskPct = sys ? 100 - (sys.free / sys.size) * 100 : null;
  const rows = [
    ['CPU', l.cpu, p ? p.cpu.replace(/\(R\)|\(TM\)|CPU|Processor|@.*$/gi, '').replace(/\s+/g, ' ').trim() : ''],
    ['RAM', l.ramPct, `${fmtN(l.ramUsed)} / ${fmtN(l.ramTotal)} GB`],
    ['GPU', l.gpu, p?.gpu?.name || ''],
    [`Laufwerk ${sys?.d || ''}`, diskPct, sys ? `${Math.round(sys.free / 1024 ** 3)} GB frei` : ''],
  ];
  const top = l.procs.slice(0, 3);
  return `<div class="hs-stats">${rows
    .map(([n, v, d]) => `<div class="hs-stat" style="--c:${pcCol(v)}"><div class="hs-row"><span>${n}</span><b>${v == null ? '–' : `${Math.round(v)}<i>%</i>`}</b></div><div class="pc-mini"><i style="width:${Math.max(2, Math.min(100, v || 0))}%"></i></div><small>${esc(d)}</small></div>`)
    .join('')}</div>
    <div class="hs-side">
      <div class="pc-verdict ${l.verdict.ok ? 'ok' : 'bad'}">${icon(l.verdict.ok ? 'check' : 'alert', 15)}<span>${esc(l.verdict.text)}</span></div>
      ${top.length ? `<div class="hs-procs">${top.map((x) => `<div><span>${esc(x.n)}</span><b>${fmtN(Math.round(x.c * 10) / 10)} %</b></div>`).join('')}</div>` : ''}
    </div>`;
}

function homeSysHtml() {
  if (!pcInfo && !pcLoading) {
    pcLoading = true;
    window.hub.pcInfo?.().then((r) => { pcInfo = r; pcPatch(); }).catch(() => {});
  }
  refreshPcLive();
  return `<div class="card home-sys home-sys-cell" data-pc-open="1" title="Klicken für Details">
    <div class="hs-title">${icon('cpu', 16)}<b>System live</b></div>
    <div id="home-sys">${homeSysInner()}</div><span class="pc-expand">${icon('maximize', 16)}</span></div>`;
}

function pcPatch() {
  const home = $('#home-sys');
  if (home) morph(home, homeSysInner());
}

function pcHtml() {
  if (!pcInfo) {
    if (!pcLoading) {
      pcLoading = true;
      window.hub.pcInfo?.().then((r) => {
        pcInfo = r;
        if (state.active === 'settings') render();
      }).catch(() => {});
    }
    return `<div class="section"><h4>Dein PC</h4><div class="panel"><div class="list-row"><div class="grow"><strong>PC-Stärke wird gemessen …</strong></div></div></div></div>`;
  }
  const p = pcInfo;
  const hue = 10 + p.level * 12;
  refreshPcLive();
  return `<div class="section"><h4>Dein PC</h4><div class="panel pc-panel" data-pc-open="1" title="Klicken für Details">
    <div class="pc-level" style="--h:${hue}"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" class="trk"/><circle cx="60" cy="60" r="50" class="val" style="stroke-dasharray:${(p.level / 10) * 314} 314"/></svg><div><b>${p.level}</b><span>von 10</span></div></div>
    <div class="pc-info"><strong>PC-Stärke: ${esc(p.label)}</strong><small>${esc(p.cpu)} · ${String(p.ram).replace('.', ',')} GB RAM${p.gpu ? ` · ${esc(p.gpu.name)}` : ''}</small>
      <div id="pc-live">${pcStatsHtml()}${pcVerdictHtml()}</div>
    </div>
    <span class="pc-expand">${icon('maximize', 16)}</span>
  </div></div>`;
}

/* ------------------------------------------------------------------ Updates */
const upd = { busy: false, result: null, step: '', pct: 0, err: '' };
const UPD_STEPS = { download: 'Wird geladen …', unpack: 'Wird entpackt …', install: 'Wird eingespielt …', restart: 'Fertig – der Hub startet neu …' };
function updateHtml() {
  const s = state.settings;
  const r = upd.result;
  const line = upd.step ? `${UPD_STEPS[upd.step] || ''}${upd.step === 'download' && upd.pct ? ` ${upd.pct} %` : ''}` : upd.err ? upd.err : !r ? 'Noch nicht gesucht.' : !r.ok ? r.error : r.available ? `Version ${r.version} ist verfügbar.${r.notes ? ` Neu: ${r.notes}` : ''}` : `Du hast die neueste Version (${r.current}).`;
  return `<div class="section"><h4>Updates</h4><div class="panel">
    ${settingRow('updateAuto', 'Beim Start nach Updates suchen', 'Meldet sich, wenn eine neue Version bereitliegt.', s.updateAuto !== false)}
    <div class="list-row"><div class="grow"><strong>Version ${esc(state.version)}</strong><small class="${upd.err || (r && !r.ok) ? 'err' : ''}">${esc(line)}</small></div>
      <button class="btn small ghost" data-news="show">Was ist neu?</button>
      <button class="btn small" data-upd="check" ${upd.busy ? 'disabled' : ''}>${upd.busy && !upd.step ? 'Suche …' : 'Nach Updates suchen'}</button>
      ${r?.ok && r.available ? `<button class="btn small primary" data-upd="install" ${upd.busy ? 'disabled' : ''}>Jetzt einspielen</button>` : ''}</div>
  </div></div>`;
}
/* Update-Leiste unten: erscheint, wenn eine neue Version bereitliegt */
let upAvail = null;
function renderUpbar() {
  const bar = $('#upbar');
  if (!bar) return;
  const show = upAvail && !upAvail.dismissed && upAvail.version !== state?.version;
  bar.hidden = !show;
  if (!show) return;
  const step = upd.step ? (UPD_STEPS[upd.step] || '') + (upd.step === 'download' && upd.pct ? ` ${upd.pct} %` : '') : '';
  bar.innerHTML = `<span class="up-ic">${icon('download', 18)}</span><div class="up-txt"><b>Update ${esc(upAvail.version)} ist da</b><small>${esc(step || upd.err || upAvail.notes || 'Neue Funktionen und Fehlerbehebungen.')}</small></div>
    <button class="btn small primary" data-upbar="go" ${upd.busy ? 'disabled' : ''}>${upd.busy ? 'Läuft …' : 'Aktualisieren'}</button><button class="btn small ghost" data-upbar="hide" ${upd.busy ? 'disabled' : ''}>Ausblenden</button>`;
}
window.hub.onUpdateAvailable?.((u) => {
  upAvail = u;
  upd.result = { ok: true, available: true, version: u.version, notes: u.notes, current: state?.version };
  renderUpbar();
});
window.hub.update?.pending().then((u) => {
  if (u) {
    upAvail = u;
    renderUpbar();
  }
}).catch(() => {});
document.addEventListener('click', async (e) => {
  const a = e.target.closest?.('[data-upbar]')?.dataset.upbar;
  if (!a) return;
  if (a === 'hide') {
    upAvail.dismissed = true;
    window.hub.update.dismiss(upAvail.version).catch(() => {});
    return renderUpbar();
  }
  upd.busy = true;
  upd.err = '';
  renderUpbar();
  try {
    await window.hub.update.check();
    await window.hub.update.install();
  } catch (error) {
    upd.err = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    upd.step = '';
  }
  upd.busy = false;
  renderUpbar();
});
window.hub.onUpdate?.((p) => {
  upd.step = p.step;
  upd.pct = p.pct;
  renderUpbar();
  if (state?.active === 'settings') render();
});
document.addEventListener('click', async (e) => {
  const a = e.target.closest?.('[data-upd]')?.dataset.upd;
  if (!a) return;
  upd.busy = true;
  upd.err = '';
  render();
  try {
    if (a === 'check') upd.result = await window.hub.update.check();
    if (a === 'install') await window.hub.update.install();
  } catch (error) {
    upd.err = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    upd.step = '';
  }
  upd.busy = false;
  render();
});

function pageSettings() {
  const s = state.settings;
  const walls = ['none', ...state.wallpapers]
    .map((id) => {
      const thumb = id === 'none' ? '' : `<img src="${fileUrl(`${state.wallpaperDir}/thumbs/${id}.jpg`)}" alt="" draggable="false" />`;
      return `<button class="wall-card ${s.wallpaper === id ? 'on' : ''}" data-wall="${id}">${thumb || '<span class="wall-none"></span>'}<span>${id === 'none' ? 'Ohne' : WALL_NAMES[id] || id}</span></button>`;
    })
    .join('');
  return `<div class="page">
    <div class="hero"><div><span class="eyebrow">Optionen</span><h2>Einstellungen</h2><p>So sieht der Revolution Hub aus und so verhält er sich. Die Einstellungen der einzelnen Apps findest du in ihrem jeweiligen Bereich.</p></div></div>

    <div class="section"><h4>Profil</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Revolution Hub-Konto</strong><small>Anmelden, damit Elo, Punkte und Cosmetics auf jedem PC gleich sind.</small></div><button class="btn small primary" data-open="tool-account">Konto & Sync</button></div>
      <div class="list-row"><div class="grow"><strong>Anzeigename</strong><small>Gilt überall gleich: Schach, Geo, Chats und Ranglisten.</small></div>
        <div class="name-edit"><input class="input" id="hub-name" maxlength="16" value="${esc(profile?.name || '')}" placeholder="Dein Name" /><button class="btn small primary" data-save-name="1">Speichern</button></div></div>
    </div></div>

    <div class="section"><h4>App-Leiste (Dock)</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Position</strong><small>Wo die App-Leiste schwebt.</small></div>
        <div class="seg">${[['bottom', 'Unten'], ['top', 'Oben'], ['left', 'Links'], ['right', 'Rechts']].map(([v, n]) => `<button class="${dockCfg().pos === v ? 'on' : ''}" data-dock-pos="${v}">${n}</button>`).join('')}</div></div>
      <div class="list-row"><div class="grow"><strong>Größe</strong></div>
        <div class="seg">${[['s', 'Klein'], ['m', 'Mittel'], ['l', 'Groß']].map(([v, n]) => `<button class="${dockCfg().size === v ? 'on' : ''}" data-dock-size="${v}">${n}</button>`).join('')}</div></div>
      <div class="list-row"><div class="grow"><strong>Vergrößern beim Drüberfahren</strong><small>Wie beim Mac.</small></div><button class="switch ${dockCfg().magnify ? 'on' : ''}" data-dock-magnify="1"></button></div>
      <div class="list-row"><div class="grow"><strong>Apps im Dock</strong><small>Hinzufügen und entfernen im Starter („Alle Apps“), Reihenfolge per Ziehen.</small></div><button class="btn small" data-dock-special="launcher">Alle Apps</button><button class="btn small ghost" data-dock-reset="1">Standard</button></div>
    </div></div>

    ${pcHtml()}

    ${speedHtml()}

    <div class="section"><h4>Live-Hintergrund</h4><div class="panel">
      <div class="list-row column"><div class="grow"><strong>Hintergrund für die ganze App</strong><small>Läuft durchgehend hinter allen Bereichen – überall derselbe.</small></div>
        <div class="wall-grid">${walls}</div></div>
      <div class="list-row"><div class="grow"><strong>Abdunklung</strong><small>Wie stark der Hintergrund abgedunkelt wird, damit Text gut lesbar bleibt.</small></div>
        <div class="range"><input type="range" min="0" max="0.9" step="0.05" value="${s.wallpaperDim}" data-range="wallpaperDim" /><output>${Math.round(s.wallpaperDim * 100)} %</output></div></div>
      ${settingRow('wallpaperIsland', 'Auch für Revolution Island verwenden', 'Die Island zeigt denselben Live-Hintergrund wie der Hub.', s.wallpaperIsland)}
    </div></div>

    <div class="section"><h4>Sprache</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Sprache</strong><small>Für den ganzen Hub und alle Apps – Deutsch, English, Español.</small></div>
        <div class="segmented">${[['de', 'Deutsch'], ['en', 'English'], ['es', 'Español']].map(([k, n]) => `<button class="${(s.lang || state.lang) === k ? 'on' : ''}" data-lang="${k}">${n}</button>`).join('')}</div></div>
    </div></div>

    <div class="section"><h4>Klicksounds</h4><div class="panel">
      ${settingRow('sounds', 'Klicksounds', 'Ein Klick bei Knöpfen und Schaltern – in allen Bereichen gleich.', s.sounds)}
      ${settingRow('muteWinNotify', 'Windows-Ton bei Meldungen aus', 'Nur noch der Ton der Island – kein doppelter Klang mehr bei neuen Nachrichten.', s.muteWinNotify !== false)}
      <div class="list-row"><div class="grow"><strong>Klang</strong><small>Dezenter Klick oder der „Killer Queen“-Auslöser.</small></div>
        <div class="seg">${[['classic', 'Standard'], ['kq', 'Killer Queen']].map(([v, n]) => `<button class="${(s.clickSound || 'classic') === v ? 'on' : ''}" data-click-style="${v}">${n}</button>`).join('')}</div></div>
      <div class="list-row"><div class="grow"><strong>Lautstärke</strong><small>Gilt für alle Klicksounds im Hub.</small></div>
        <div class="range"><input type="range" min="0.05" max="1" step="0.05" value="${s.soundVolume}" data-range="soundVolume" /><output>${Math.round(s.soundVolume * 100)} %</output></div></div>
    </div></div>

    <div class="section"><h4>Start & Hintergrund</h4><div class="panel">
      ${settingRow('autoStart', 'Mit Windows starten', 'Der Hub startet unsichtbar im Infobereich – Crosshair, Screenshot-Hotkey und Revolution Island sind sofort da.', s.autoStart)}
      ${settingRow('closeToTray', 'Beim Schließen im Infobereich bleiben', 'Das Fenster verschwindet, Overlays, Hotkeys und Island laufen weiter. Beenden über das Tray-Symbol.', s.closeToTray)}
      ${settingRow('orbitWithHub', 'Revolution Island mitstarten', 'Startet die Dynamic Island zusammen mit dem Hub.', s.orbitWithHub)}
      <div class="list-row"><div class="grow"><strong>Startseite</strong><small>Was beim Öffnen des Hubs angezeigt wird.</small></div>
        <div class="segmented"><button class="${s.startPage === 'home' ? 'on' : ''}" data-start="home">Start</button><button class="${s.startPage === 'last' ? 'on' : ''}" data-start="last">Zuletzt geöffnet</button></div></div>
    </div></div>

    ${updateHtml()}

    <div class="section"><h4>Daten</h4><div class="panel">
      ${['hub', 'dropzone', 'gaming', 'orbit', 'screenshot', 'docs', 'chess', 'geo']
        .map((id) => `<div class="list-row"><div class="grow"><strong>${esc(FRIENDLY[id])}</strong><small>Einstellungen und Daten bleiben beim Aktualisieren erhalten.</small></div><button class="btn small" data-data="${id}">${icon('folder', 15)} Ordner öffnen</button></div>`)
        .join('')}
    </div></div>

    <div class="section"><h4>Über</h4><div class="panel kv">
      <span>Revolution Hub</span><b>${esc(state.version)}</b>
      ${state.modules.map((mod) => `<span>${esc(FRIENDLY[mod.id] || mod.name)}</span><b>${esc(mod.version)}${mod.error ? ' – Fehler' : ''}</b>`).join('')}
      <span>Revolution Island</span><b>${state.orbit.available ? '1.0.0' : 'nicht enthalten'}</b>
    </div></div>
  </div>`;
}

/* ------------------------------------------------------------------- render */
/* ------------------------------------------------------------------ flimmerfreies Neuzeichnen */
/**
 * Statt bei jeder Aktualisierung den ganzen Bereich per innerHTML neu aufzubauen (das
 * blinkt: Bilder laden neu, Animationen starten neu), werden nur die Knoten geändert,
 * die sich wirklich unterscheiden.
 */
function morphAttrs(from, to) {
  const keepStyle = from.classList?.contains('dock-item');
  for (const { name } of [...from.attributes]) if (!to.hasAttribute(name) && !(keepStyle && name === 'style')) from.removeAttribute(name);
  for (const { name, value } of [...to.attributes]) if (from.getAttribute(name) !== value) from.setAttribute(name, value);
  if (from.tagName === 'INPUT' || from.tagName === 'TEXTAREA' || from.tagName === 'SELECT') {
    if (document.activeElement !== from) {
      if (from.type === 'checkbox' || from.type === 'radio') from.checked = to.hasAttribute('checked');
      else if (from.tagName === 'SELECT') {
        const sel = [...to.options].findIndex((o) => o.hasAttribute('selected'));
        if (sel >= 0 && from.selectedIndex !== sel) from.selectedIndex = sel;
      } else if (from.tagName === 'TEXTAREA') {
        if (from.value !== to.textContent) from.value = to.textContent;
      } else if (from.value !== (to.getAttribute('value') ?? '')) from.value = to.getAttribute('value') ?? '';
    }
  }
}

function sameKind(a, b) {
  if (a.nodeType !== b.nodeType) return false;
  if (a.nodeType !== 1) return true;
  return a.tagName === b.tagName && (a.id || '') === (b.id || '') && (a.dataset.key || '') === (b.dataset.key || '');
}

function morphChildren(from, to) {
  const next = [...to.childNodes];
  let cur = from.firstChild;
  for (const node of next) {
    if (cur && sameKind(cur, node)) {
      if (cur.nodeType === 1) {
        morphAttrs(cur, node);
        if (cur.tagName !== 'TEXTAREA') morphChildren(cur, node);
      } else if (cur.nodeValue !== node.nodeValue) cur.nodeValue = node.nodeValue;
      cur = cur.nextSibling;
    } else {
      from.insertBefore(node, cur);
    }
  }
  while (cur) {
    const rest = cur.nextSibling;
    cur.remove();
    cur = rest;
  }
}

function morph(el, html) {
  const tpl = document.createElement('template');
  tpl.innerHTML = html;
  morphChildren(el, tpl.content);
}

function render() {
  if (!state) return;
  renderNav();
  applyWallpaper();
  sound.configure({ enabled: state.settings.sounds, volume: state.settings.soundVolume, style: state.settings.clickSound || 'classic' });
  if (state.settings.clickSound === 'kq' && !render.clipLoaded) {
    render.clipLoaded = true;
    window.hub.clickClip?.().then((clip) => clip && sound.configure({ clip })).catch(() => {});
  }
  const active = state.active;
  const meta = active === 'home' ? { title: 'Start', sub: 'Revolution Hub' } : active === 'settings' ? { title: 'Einstellungen', sub: 'Revolution Hub' } : active === 'shop' ? { title: 'Shop', sub: 'Cosmetics für Schach, Geo & Chats' } : TOOLS[active] || APPS[active] || { title: active, sub: '' };
  $('#page-title').textContent = meta.title;
  $('#page-sub').textContent = meta.sub;
  $('#win-max').title = state.maximized ? 'Wiederherstellen' : 'Maximieren';
  document.body.classList.toggle('module-open', MODULE_PAGES.has(active));

  const html =
    active === 'home' ? pageHome() : active === 'orbit' ? window.OrbitPage.html(state) : active === 'settings' ? pageSettings() : active === 'shop' ? pageShop() : TOOLS[active] ? window.HubTools.html(active) : pageModule(active);
  const content = $('#content');
  const body = content.querySelector('.set-body');
  const scroll = page === active ? content.scrollTop : 0;
  const innerScroll = page === active && body ? body.scrollTop : 0;
  if (page === active) {
    // Gleiche Seite: nur ändern, was anders ist – kein Blinken, keine neue Einblend-Animation
    morph(content, html.replace(/^(\s*<div class=")(page|set-page)/, '$1$2 still'));
    content.querySelector('.page')?.classList.add('still');
  } else content.innerHTML = html;
  content.scrollTop = scroll;
  const nextBody = content.querySelector('.set-body');
  if (nextBody) nextBody.scrollTop = innerScroll;
  page = active;
  if (overlay) renderOverlay();
}

/* ------------------------------------------------------------------- events */
window.OrbitPage.bind($('#content'), render, toast);

document.addEventListener('click', async (event) => {
  const target = event.target.closest('button, [data-open]');
  if (!target) return;

  if (target.dataset.win) return window.hub.window(target.dataset.win);
  if (target.dataset.open) {
    if (target.dataset.open === 'orbit') window.OrbitPage.load(true).then(render);
    return window.hub.open(target.dataset.open);
  }
  if (target.dataset.setting) {
    const key = target.dataset.setting;
    return run(() => window.hub.setSettings({ [key]: !state.settings[key] }));
  }
  if (target.dataset.wall) return run(() => window.hub.setSettings({ wallpaper: target.dataset.wall }));
  if (target.dataset.start) return run(() => window.hub.setSettings({ startPage: target.dataset.start }));
  if (target.dataset.lang) return run(() => window.hub.setSettings({ lang: target.dataset.lang }));
  if (target.dataset.data) return window.hub.openData(target.dataset.data);
  if (target.id === 'orbit-start') return run(() => window.hub.orbit.start(), 'Revolution Island wird gestartet …');
  if (target.id === 'orbit-stop') return run(() => window.hub.orbit.stop(), 'Revolution Island beendet.');
});

let rangeTimer = null;
document.addEventListener('input', (event) => {
  const el = event.target;
  if (!el.dataset.range) return;
  const value = Number(el.value);
  el.parentElement.querySelector('output').textContent = `${Math.round(value * 100)} %`;
  if (el.dataset.range === 'wallpaperDim') $('#wall-shade').style.opacity = String(value);
  if (el.dataset.range === 'soundVolume') {
    sound.configure({ volume: value });
    sound.play('tap');
  }
  clearTimeout(rangeTimer);
  rangeTimer = setTimeout(() => window.hub.setSettings({ [el.dataset.range]: value }), 200);
});

document.addEventListener('dblclick', (event) => {
  if (event.target.closest('.topbar') && !event.target.closest('.win')) window.hub.window('maximize');
});

window.hub.onProfile?.((p) => setProfile(p));
window.hub.profile?.get().then((p) => setProfile(p)).catch(() => {});
document.addEventListener('click', (event) => {
  if (!event.target.closest?.('[data-save-name]')) return;
  const v = ($('#hub-name')?.value || '').trim();
  if (v.length < 2) return toast('Mindestens 2 Zeichen.', 'error');
  run(() => window.hub.profile.name(v), 'Name gespeichert – gilt in allen Apps.').then((p) => p && setProfile(p));
});

window.hub.onState((next) => {
  const wasOrbit = state?.active === 'orbit';
  if (next.lang && next.lang !== window.RevTranslate?.lang) window.RevTranslate?.set(next.lang);
  state = next;
  if (next.active === 'orbit' && !wasOrbit) window.OrbitPage.load(true).then(render);
  // Do not wipe what the user is typing in the island editor.
  if (next.active === 'orbit' && wasOrbit && document.activeElement?.closest?.('.set-body')) {
    renderNav();
    return;
  }
  render();
});

window.hub.state().then((initial) => {
  state = initial;
  window.RevTranslate?.set(initial.lang || "de");
  render();
  maybeShowNews();
  if (initial.active === 'orbit') window.OrbitPage.load(true).then(render);
});

/* Dock-Einstellungen */
document.addEventListener('click', (e) => {
  // Nur Knöpfe – <body> trägt selbst data-dock / data-dock-size fürs Layout
  const p = e.target.closest?.('button[data-dock-pos]');
  if (p) return run(() => window.hub.setSettings({ dock: { pos: p.dataset.dockPos } }));
  const z = e.target.closest?.('button[data-dock-size]');
  if (z) return run(() => window.hub.setSettings({ dock: { size: z.dataset.dockSize } }));
  if (e.target.closest?.('[data-dock-magnify]')) return run(() => window.hub.setSettings({ dock: { magnify: !dockCfg().magnify } }));
  if (e.target.closest?.('[data-dock-reset]')) return saveDock([...DEFAULT_DOCK]);
  const cs = e.target.closest?.('[data-click-style]');
  if (cs) return run(() => window.hub.setSettings({ clickSound: cs.dataset.clickStyle })).then(() => setTimeout(() => sound.play('tap'), 250));
});
setTimeout(() => window.HubTools?.weatherCheck?.(), 8000);
window.HubTools?.init({ state: () => state, render: () => render(), toast: (m, k) => toast(m, k), settings: (patch) => run(() => window.hub.setSettings(patch)) });
