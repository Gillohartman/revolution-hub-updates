'use strict';

/*
 * Autoclicker: klickt und drückt Tasten in festen Abständen.
 * Läuft als eigener kleiner PowerShell-Prozess (C# über Add-Type, SendInput-Vorgänger
 * mouse_event/keybd_event) – Stopp = Prozess beenden. Start/Stopp auch per Hotkey.
 */
const { spawn } = require('child_process');
const { globalShortcut, screen } = require('electron');

const CS = `
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
public static class RevClick {
  [DllImport("user32.dll")] static extern void mouse_event(uint f, uint dx, uint dy, uint d, UIntPtr e);
  [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint type);
  [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint ms);
  static void Click(int button, bool dbl, int holdMs) {
    uint down = button == 1 ? 0x0008u : button == 2 ? 0x0020u : 0x0002u;
    uint up = button == 1 ? 0x0010u : button == 2 ? 0x0040u : 0x0004u;
    for (int i = 0; i < (dbl ? 2 : 1); i++) {
      mouse_event(down, 0, 0, 0, UIntPtr.Zero);
      if (holdMs > 0) Thread.Sleep(holdMs);
      mouse_event(up, 0, 0, 0, UIntPtr.Zero);
      if (dbl && i == 0) Thread.Sleep(35);
    }
  }
  static void Key(int vk, int holdMs) {
    byte scan = (byte)MapVirtualKey((uint)vk, 0);
    keybd_event((byte)vk, scan, 0, UIntPtr.Zero);
    Thread.Sleep(Math.Max(15, holdMs));
    keybd_event((byte)vk, scan, 2, UIntPtr.Zero);
  }
  public static void Run(bool click, int button, bool dbl, int interval, int jitter, int count, int holdMs, int px, int py, int startDelay, int maxSeconds, int[] vks, int[] every, int[] hold, int[] first) {
    timeBeginPeriod(1);
    var rnd = new Random();
    var sw = Stopwatch.StartNew();
    Thread.Sleep(Math.Max(0, startDelay));
    long begin = sw.ElapsedMilliseconds;
    long nextClick = begin;
    long[] nextKey = new long[vks.Length];
    for (int i = 0; i < vks.Length; i++) nextKey[i] = begin + first[i];
    int done = 0;
    while (true) {
      long now = sw.ElapsedMilliseconds;
      if (maxSeconds > 0 && now - begin > (long)maxSeconds * 1000) break;
      if (click && now >= nextClick) {
        if (px >= 0) SetCursorPos(px, py);
        Click(button, dbl, holdMs);
        done++;
        Console.WriteLine("c " + done);
        if (count > 0 && done >= count) { click = false; if (vks.Length == 0) break; }
        nextClick = now + Math.Max(1, interval + (jitter > 0 ? rnd.Next(-jitter, jitter + 1) : 0));
      }
      for (int i = 0; i < vks.Length; i++) {
        if (now >= nextKey[i]) {
          Key(vks[i], hold[i]);
          nextKey[i] = (every[i] <= 0) ? long.MaxValue : sw.ElapsedMilliseconds + every[i];
          Console.WriteLine("k " + i);
        }
      }
      if (!click) {
        bool any = false;
        for (int i = 0; i < vks.Length; i++) if (nextKey[i] != long.MaxValue) any = true;
        if (!any) break;
      }
      Thread.Sleep(1);
    }
  }
}`;

/** Tastenname (KeyboardEvent.code) → virtueller Tastencode von Windows. */
function vkOf(code) {
  const c = String(code || '');
  let m;
  if ((m = /^Key([A-Z])$/.exec(c))) return m[1].charCodeAt(0);
  if ((m = /^Digit(\d)$/.exec(c))) return 0x30 + Number(m[1]);
  if ((m = /^Numpad(\d)$/.exec(c))) return 0x60 + Number(m[1]);
  if ((m = /^F(\d{1,2})$/.exec(c)) && Number(m[1]) >= 1 && Number(m[1]) <= 24) return 0x6f + Number(m[1]);
  return (
    {
      Space: 0x20, Enter: 0x0d, Tab: 0x09, Escape: 0x1b, Backspace: 0x08, Delete: 0x2e, Insert: 0x2d, Home: 0x24, End: 0x23, PageUp: 0x21, PageDown: 0x22,
      ArrowLeft: 0x25, ArrowUp: 0x26, ArrowRight: 0x27, ArrowDown: 0x28, ShiftLeft: 0xa0, ShiftRight: 0xa1, ControlLeft: 0xa2, ControlRight: 0xa3, AltLeft: 0xa4, AltRight: 0xa5,
      CapsLock: 0x14, Comma: 0xbc, Period: 0xbe, Minus: 0xbd, Equal: 0xbb, Semicolon: 0xba, Slash: 0xbf, Backquote: 0xc0, BracketLeft: 0xdb, BracketRight: 0xdd, Backslash: 0xdc, Quote: 0xde,
    }[c] || 0
  );
}

const TIME = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/;
/** Millisekunden bis zur nächsten Uhrzeit HH:MM(:SS) – heute oder, falls vorbei, morgen. */
function msUntil(hhmm) {
  const m = TIME.exec(String(hhmm || ''));
  if (!m) return null;
  const at = new Date();
  at.setHours(Number(m[1]), Number(m[2]), Number(m[3] || 0), 0);
  if (at.getTime() <= Date.now() + 200) at.setDate(at.getDate() + 1);
  return at.getTime() - Date.now();
}
const cleanTime = (v) => (TIME.test(String(v || '')) ? String(v) : '');

const int = (v, min, max, def) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def;
};

/** Eingaben prüfen und begrenzen – nichts Ungeprüftes landet im Skript. */
function clean(raw = {}) {
  const keys = (Array.isArray(raw.keys) ? raw.keys : [])
    .slice(0, 12)
    .map((k) => ({ code: String(k?.code || '').slice(0, 20), label: String(k?.label || '').slice(0, 20), everyMs: int(k?.everyMs, 0, 86400000, 1000), holdMs: int(k?.holdMs, 0, 60000, 40), firstMs: int(k?.firstMs, 0, 86400000, 0), at: cleanTime(k?.at), on: k?.on !== false }))
    .filter((k) => vkOf(k.code));
  return {
    click: raw.click !== false,
    button: ['left', 'right', 'middle'].includes(raw.button) ? raw.button : 'left',
    double: Boolean(raw.double),
    intervalMs: int(raw.intervalMs, 1, 86400000, 100),
    jitterMs: int(raw.jitterMs, 0, 60000, 0),
    count: int(raw.count, 0, 10000000, 0),
    holdMs: int(raw.holdMs, 0, 60000, 0),
    startDelayMs: int(raw.startDelayMs, 0, 600000, 0),
    maxSeconds: int(raw.maxSeconds, 0, 86400, 0),
    pos: raw.pos && Number.isFinite(Number(raw.pos.x)) && Number.isFinite(Number(raw.pos.y)) ? { x: Math.round(Number(raw.pos.x)), y: Math.round(Number(raw.pos.y)) } : null,
    hotkey: ['F6', 'F7', 'F8', 'F9', 'F10'].includes(raw.hotkey) ? raw.hotkey : 'F6',
    startAt: cleanTime(raw.startAt),
    keys,
  };
}

class AutoClicker {
  constructor({ getConfig, onChange }) {
    this.getConfig = getConfig;
    this.onChange = onChange || (() => {});
    this.child = null;
    this.clicks = 0;
    this.presses = 0;
    this.startedAt = 0;
    this.hotkey = '';
  }

  status() {
    return { running: Boolean(this.child), clicks: this.clicks, presses: this.presses, startedAt: this.startedAt, hotkey: this.hotkey };
  }

  /** Hotkey (neu) anmelden – ruft toggle() auf. */
  bindHotkey() {
    const want = clean(this.getConfig()).hotkey;
    if (want === this.hotkey) return;
    try {
      if (this.hotkey) globalShortcut.unregister(this.hotkey);
      this.hotkey = globalShortcut.register(want, () => this.toggle()) ? want : '';
    } catch {
      this.hotkey = '';
    }
  }

  toggle() {
    return this.child ? this.stop() : this.start();
  }

  start(raw) {
    if (this.child) return this.status();
    const c = clean(raw || this.getConfig());
    // Feste Uhrzeiten in Wartezeiten umrechnen
    for (const k of c.keys) if (k.at) k.firstMs = msUntil(k.at);
    if (c.startAt) c.startDelayMs = msUntil(c.startAt);
    const keys = c.keys.filter((k) => k.on);
    if (!c.click && !keys.length) throw new Error('Nichts zu tun: Klicken ist aus und es ist keine Taste aktiv.');
    const arr = (list) => `@(${list.join(',')})`;
    const cs = CS.replace(/'/g, "''");
    const args = [
      c.click ? '$true' : '$false', { left: 0, right: 1, middle: 2 }[c.button], c.double ? '$true' : '$false', c.intervalMs, c.jitterMs, c.count, c.holdMs,
      c.pos ? c.pos.x : -1, c.pos ? c.pos.y : -1, c.startDelayMs, c.maxSeconds,
      `[int[]]${arr(keys.map((k) => vkOf(k.code)))}`, `[int[]]${arr(keys.map((k) => k.everyMs))}`, `[int[]]${arr(keys.map((k) => k.holdMs))}`, `[int[]]${arr(keys.map((k) => k.firstMs))}`,
    ].join(', ');
    const script = `$ErrorActionPreference='Stop'; Add-Type -TypeDefinition '${cs}'; [RevClick]::Run(${args})`;
    const encoded = Buffer.from(script, 'utf16le').toString('base64');
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    this.child = child;
    this.clicks = 0;
    this.presses = 0;
    this.startedAt = Date.now();
    let last = 0;
    child.stdout.on('data', (buf) => {
      for (const line of String(buf).split(/\r?\n/)) {
        if (line.startsWith('c ')) this.clicks = Number(line.slice(2)) || this.clicks;
        else if (line.startsWith('k ')) this.presses += 1;
      }
      if (Date.now() - last > 400) {
        last = Date.now();
        this.onChange(this.status());
      }
    });
    const done = () => {
      if (this.child !== child) return;
      this.child = null;
      this.onChange(this.status());
    };
    child.on('exit', done);
    child.on('error', done);
    this.onChange(this.status());
    return this.status();
  }

  stop() {
    const child = this.child;
    if (child) {
      this.child = null;
      try {
        child.kill();
      } catch {
        /* already gone */
      }
      this.onChange(this.status());
    }
    return this.status();
  }

  /** Mausposition nach kurzer Wartezeit merken (in echten Bildschirm-Pixeln). */
  pickPosition(delayMs = 3000) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const p = screen.getCursorScreenPoint();
        const real = screen.dipToScreenPoint ? screen.dipToScreenPoint(p) : p;
        resolve({ x: Math.round(real.x), y: Math.round(real.y) });
      }, Math.min(10000, Math.max(500, Number(delayMs) || 3000)));
    });
  }

  shutdown() {
    this.stop();
    try {
      if (this.hotkey) globalShortcut.unregister(this.hotkey);
    } catch {
      /* ignore */
    }
  }
}

module.exports = { AutoClicker, clean, vkOf, msUntil };
