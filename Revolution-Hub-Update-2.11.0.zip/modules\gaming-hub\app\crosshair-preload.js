const { contextBridge, ipcRenderer } = require('electron');

const listen = (channel, callback) => {
  const handler = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};

const mediaUrl = (file) => {
  const value = String(file || '');
  // Rang-Abzeichen liegen im App-Ordner, eigene Bilder im Benutzerordner.
  if (value.startsWith('ranks/')) return `xh://rank/${encodeURIComponent(value.slice(6))}`;
  return `xh://crosshair/${encodeURIComponent(value)}`;
};

contextBridge.exposeInMainWorld('xh', {
  get: () => ipcRenderer.invoke('xh:get'),
  save: (patch) => ipcRenderer.invoke('xh:save', patch),
  setActive: (id) => ipcRenderer.invoke('xh:setActive', id),
  addProfile: (profile) => ipcRenderer.invoke('xh:addProfile', profile),
  updateProfile: (profile) => ipcRenderer.invoke('xh:updateProfile', profile),
  deleteProfile: (id) => ipcRenderer.invoke('xh:deleteProfile', id),
  pickImage: () => ipcRenderer.invoke('xh:pickImage'),
  pickWallpaper: () => ipcRenderer.invoke('xh:pickWallpaper'),
  deleteImage: (id) => ipcRenderer.invoke('xh:deleteImage', id),
  exportConfig: () => ipcRenderer.invoke('xh:export'),
  importConfig: () => ipcRenderer.invoke('xh:import'),
  reset: () => ipcRenderer.invoke('xh:reset'),
  toggle: () => ipcRenderer.invoke('xh:toggle'),
  preview: (ms) => ipcRenderer.invoke('xh:preview', ms),

  scan: () => ipcRenderer.invoke('stats:scan'),
  statsData: () => ipcRenderer.invoke('state:get'),
  openPath: (target) => ipcRenderer.invoke('shell:openPath', target),
  minimize: () => ipcRenderer.send('window:minimize'),
  closeWindow: () => ipcRenderer.send('window:close'),

  /* Clips (Medal-Ersatz) */
  captureSources: () => ipcRenderer.invoke('capture:sources'),
  clipChunk: (buffer, isFirst) => ipcRenderer.send('clip:chunk', { buffer, isFirst }),
  clipReset: (options) => ipcRenderer.invoke('clip:reset', options),
  camChunk: (buffer, isFirst) => ipcRenderer.send('cam:chunk', { buffer, isFirst }),
  camReset: (options) => ipcRenderer.invoke('cam:reset', options),
  camStop: () => ipcRenderer.invoke('cam:stop'),
  recToggle: () => ipcRenderer.invoke('rec:toggle'),
  recStop: () => ipcRenderer.invoke('rec:stop'),
  recState: () => ipcRenderer.invoke('rec:state'),
  onRecState: (callback) => listen('rec:state', callback),
  onRecSaving: (callback) => listen('rec:saving', callback),
  clipSave: (options) => ipcRenderer.invoke('clip:save', options),
  clipDelete: (name) => ipcRenderer.invoke('clip:delete', name),
  clipClear: (category) => ipcRenderer.invoke('clips:clear', category),
  clipsList: () => ipcRenderer.invoke('clips:list'),
  clipDeleteMany: (names) => ipcRenderer.invoke('clips:deleteMany', names),
  clipInfo: (name) => ipcRenderer.invoke('clip:info', name),
  clipSetMeta: (name, patch) => ipcRenderer.invoke('clip:setMeta', name, patch),
  clipThumb: (name, base64) => ipcRenderer.invoke('clip:thumb', name, base64),
  clipExportSave: (source, data, ext) => ipcRenderer.invoke('clip:exportSave', source, data, ext),
  clipReveal: (name) => ipcRenderer.invoke('clip:reveal', name),
  clipUrl: (name) => `xh://clip/${encodeURIComponent(String(name || ''))}`,
  feedFrame: (base64) => ipcRenderer.invoke('ocr:feed', base64),
  victoryFrame: (base64) => ipcRenderer.invoke('ocr:victory', base64),
  elimFrame: (base64, kind) => ipcRenderer.invoke('ocr:elim', base64, kind),
  clipDebug: (payload) => ipcRenderer.send('clip:debug', payload),
  onClipDiag: (callback) => listen('clip:diag', callback),
  onClipsChanged: (callback) => listen('clips:changed', callback),
  saveSettings: (patch) => ipcRenderer.invoke('settings:save', patch),
  onClipTrigger: (callback) => listen('clip:trigger', callback),
  onClipSaved: (callback) => listen('clip:auto-saved', callback),
  onAutoGame: (callback) => listen('clip:auto-game', callback),
  onRankDetected: (callback) => listen('rank:detected', callback),

  /* Musik-Overlay */
  musicGet: () => ipcRenderer.invoke('music:get'),
  musicSet: (patch) => ipcRenderer.invoke('music:set', patch),
  musicPreview: (patch) => ipcRenderer.invoke('music:preview', patch),
  musicDemo: () => ipcRenderer.invoke('music:demo'),
  onMusicState: (callback) => listen('music:state', callback),

  /* Performance-Overlay */
  perfGet: () => ipcRenderer.invoke('perf:get'),
  perfSet: (patch) => ipcRenderer.invoke('perf:set', patch),
  onPerfState: (callback) => listen('perf:state', callback),

  /* Audio-Mixer */
  audioList: () => ipcRenderer.invoke('audio:list'),
  audioMaster: (patch) => ipcRenderer.invoke('audio:master', patch),
  audioApp: (patch) => ipcRenderer.invoke('audio:app', patch),

  /* Notizen & Bildschirmzeit */
  notesGet: () => ipcRenderer.invoke('notes:get'),
  notesSave: (notes) => ipcRenderer.invoke('notes:save', notes),
  screenTime: () => ipcRenderer.invoke('screentime:get'),

  /* Keystrokes fürs Video */
  inputStart: () => ipcRenderer.invoke('input:start'),
  inputStop: () => ipcRenderer.invoke('input:stop'),
  onInput: (callback) => listen('input:state', callback),

  onState: (callback) => listen('xh:state', callback),
  onView: (callback) => listen('xh:view', callback),

  onGame: (callback) => listen('game:status', callback),

  /* Truhen-Zähler */
  chestsGet: () => ipcRenderer.invoke('chests:get'),
  chestsSet: (patch) => ipcRenderer.invoke('chests:set', patch),
  chestsAdjust: (amount) => ipcRenderer.invoke('chests:adjust', amount),
  chestsReset: (ign) => ipcRenderer.invoke('chests:reset', ign),
  chestsPreview: () => ipcRenderer.invoke('chests:preview'),
  chestsTest: () => ipcRenderer.invoke('chests:test'),
  chestsFrame: (base64, kind, gold) => ipcRenderer.invoke('chests:frame', base64, kind, gold),
  chestsDebugShot: (frame, crop) => ipcRenderer.invoke('chests:debugShot', frame, crop),
  onChests: (callback) => listen('chests:state', callback),
  mediaUrl,
});
