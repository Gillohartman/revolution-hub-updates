'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.11.0',
  title: 'Revolution Hub 2.11',
  sub: 'Klick auf einen Eintrag – du landest direkt dort. Oben links kommst du jederzeit hierher zurück.',
  items: [
    { open: 'tool-football', icon: 'tool-football', title: 'Fußball in der Island', text: 'Folge Ländern und Clubs: Vorschau, Anpfiff, jedes Tor, Halbzeit und Abpfiff – und der Live-Stand direkt in der Island.' },
    { open: 'gaming', icon: 'gaming', title: 'Clips repariert', text: 'Kill-Clips und eigene Clips nehmen jetzt den Monitor auf, auf dem Fortnite läuft – in voller Auflösung.' },
    { open: 'gaming', icon: 'gaming', title: 'Controller in Clips', text: 'Controller-Tasten werden wieder erkannt – egal an welchem Anschluss der Controller hängt.' },
    { open: 'gaming', icon: 'gaming', title: 'Gaming Hub aufgeräumt', text: 'Neues Menü mit Gruppen und Symbolen, ohne Logo-Leiste.' },
    { open: 'chess', icon: 'chess', title: 'Natürliche Coach-Stimme', text: 'Der Coach spricht mit einer echten Neuronal-Stimme statt Computerstimme – offline, einmal geladen.' },
    { open: 'home', icon: 'home', title: 'Dock rechts, Apps dahinter', text: 'Das Dock sitzt jetzt rechts und schwebt über den Apps – die Apps nutzen die ganze Fläche. Die Vergrößerung ist viel weicher.' },
    { open: 'tool-schematics', icon: 'tool-schematics', title: 'Schematics: Bewerten & Kommentare', text: 'Die Anmeldung wird jetzt richtig erkannt – Sterne und Kommentare funktionieren.' },
    { open: 'orbit', icon: 'orbit', title: 'Revolution Island', text: 'Die Island heißt jetzt Revolution Island – auch im Task-Manager – und zeigt keinen Schriftzug mehr.' },
    { open: 'chats', icon: 'chats', title: 'Chats wie Discord', text: 'Server-Leiste, Direktnachrichten, Freunde, Emojis, Bilder und roter Punkt am App-Symbol.' },
    { open: 'geo', icon: 'geo', title: 'Team-Duell 2v2', text: 'Zwei gegen zwei in GeoRevolution.' },
  ],
};
