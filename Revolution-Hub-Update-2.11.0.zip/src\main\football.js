'use strict';

/*
 * Fußball in der Dynamic Island: Spiele der gewählten Länder und Clubs.
 * Daten von der öffentlichen ESPN-Schnittstelle (ohne Schlüssel): Spielplan pro Team,
 * Live-Stand über die Spiel-Zusammenfassung.
 *   – kurz vor Anpfiff, Anpfiff, jedes Tor, Halbzeit und Abpfiff → Meldung in der Island
 *   – solange ein Spiel läuft → Live-Stand als Statuszeile der Island
 */
const { net } = require('electron');

const API = 'https://site.api.espn.com/apis/site/v2/sports/soccer';
// Ligen für die Team-Suche (Clubs) und Wettbewerbe der Nationalteams
const LEAGUES = [
  ['sui.1', 'Schweiz'], ['ger.1', 'Deutschland'], ['ger.2', 'Deutschland 2'], ['aut.1', 'Österreich'], ['eng.1', 'England'], ['eng.2', 'England 2'], ['esp.1', 'Spanien'], ['ita.1', 'Italien'],
  ['fra.1', 'Frankreich'], ['ned.1', 'Niederlande'], ['por.1', 'Portugal'], ['tur.1', 'Türkei'], ['sco.1', 'Schottland'], ['bel.1', 'Belgien'], ['usa.1', 'USA'], ['bra.1', 'Brasilien'],
  ['arg.1', 'Argentinien'], ['ksa.1', 'Saudi-Arabien'], ['mex.1', 'Mexiko'],
];
const NATIONAL = ['uefa.nations', 'fifa.world', 'fifa.worldq.conmebol', 'fifa.worldq.concacaf', 'fifa.worldq.afc', 'fifa.worldq.caf'];

async function getJson(url) {
  const res = await net.fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

class Football {
  constructor({ getSettings, saveSettings, notify }) {
    this.getSettings = getSettings;
    this.saveSettings = saveSettings;
    this.notify = notify;
    this.catalog = null; // alle Teams für die Suche
    this.schedules = new Map(); // teamId → { at, events }
    this.live = new Map(); // eventId → letzter Stand
    this.announced = new Set();
    this.timer = null;
    this.status = '';
  }

  cfg() {
    const f = this.getSettings().football || {};
    return { teams: Array.isArray(f.teams) ? f.teams : [], notify: f.notify !== false, island: f.island !== false };
  }

  /* ---------------- Teams suchen und wählen */
  async loadCatalog() {
    if (this.catalog) return this.catalog;
    const list = new Map();
    const add = (t, group, national) => {
      if (!t?.id || list.has(t.id)) return;
      list.set(t.id, { id: String(t.id), name: t.displayName || t.name, short: t.shortDisplayName || t.displayName, abbr: t.abbreviation || '', logo: t.logos?.[0]?.href || '', group, national });
    };
    await Promise.all([
      ...LEAGUES.map(([slug, land]) => getJson(`${API}/${slug}/teams`).then((j) => j.sports?.[0]?.leagues?.[0]?.teams?.forEach((x) => add(x.team, land, false))).catch(() => {})),
      ...NATIONAL.map((slug) => getJson(`${API}/${slug}/teams`).then((j) => j.sports?.[0]?.leagues?.[0]?.teams?.forEach((x) => add(x.team, 'Nationalteam', true))).catch(() => {})),
    ]);
    this.catalog = [...list.values()];
    return this.catalog;
  }

  async search(q) {
    const all = await this.loadCatalog();
    const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    // deutsche Namen der Länder ebenfalls finden (z. B. „Schweiz“)
    let de = null;
    try {
      de = new Intl.DisplayNames(['de'], { type: 'region' });
    } catch {
      de = null;
    }
    const DE = { Switzerland: 'CH', Germany: 'DE', Austria: 'AT', France: 'FR', Italy: 'IT', Spain: 'ES', Portugal: 'PT', Netherlands: 'NL', Belgium: 'BE', England: 'GB', Croatia: 'HR', Serbia: 'RS', Turkey: 'TR', Türkiye: 'TR', Poland: 'PL', Denmark: 'DK', Sweden: 'SE', Norway: 'NO', Brazil: 'BR', Argentina: 'AR', 'United States': 'US', Mexico: 'MX', Japan: 'JP', Morocco: 'MA', Scotland: 'GB', Wales: 'GB', Slovenia: 'SI', Slovakia: 'SK', Czechia: 'CZ', 'Czech Republic': 'CZ', Hungary: 'HU', Greece: 'GR', Ukraine: 'UA', Albania: 'AL', Kosovo: 'XK', 'Bosnia and Herzegovina': 'BA', Romania: 'RO' };
    const label = (t) => (t.national && DE[t.name] && de ? `${de.of(DE[t.name])}` : t.name);
    const n = norm(q).trim();
    const hits = all
      .map((t) => ({ ...t, label: label(t) }))
      .filter((t) => !n || norm(t.name).includes(n) || norm(t.label).includes(n) || norm(t.abbr) === n)
      .sort((a, b) => (norm(a.label).startsWith(n) ? 0 : 1) - (norm(b.label).startsWith(n) ? 0 : 1) || Number(b.national) - Number(a.national) || a.label.localeCompare(b.label));
    return hits.slice(0, 40);
  }

  setTeams(teams) {
    const clean = (Array.isArray(teams) ? teams : []).slice(0, 20).map((t) => ({ id: String(t.id), name: String(t.label || t.name || '').slice(0, 40), abbr: String(t.abbr || '').slice(0, 6), logo: /^https:\/\//.test(t.logo || '') ? t.logo : '', national: Boolean(t.national) }));
    this.saveSettings({ football: { ...this.cfg(), teams: clean } });
    this.schedules.clear();
    this.tick(true).catch(() => {});
    return this.overview();
  }

  setOptions(patch) {
    const c = this.cfg();
    this.saveSettings({ football: { ...c, notify: patch?.notify ?? c.notify, island: patch?.island ?? c.island } });
    return this.overview();
  }

  /* ---------------- Spielplan und Live-Stand */
  async schedule(team) {
    const cached = this.schedules.get(team.id);
    if (cached && Date.now() - cached.at < 15 * 60000) return cached.events;
    // kommende Spiele und letzte Ergebnisse
    const [fx, res] = await Promise.all([getJson(`${API}/all/teams/${team.id}/schedule?fixture=true`), getJson(`${API}/all/teams/${team.id}/schedule`).catch(() => ({ events: [] }))]);
    const seen = new Set();
    const raw = [...(fx.events || []), ...(res.events || [])].filter((e) => !seen.has(e.id) && seen.add(e.id));
    const events = raw.map((e) => {
      const c = e.competitions?.[0] || {};
      const teams = (c.competitors || []).map((x) => ({ id: String(x.team?.id), name: x.team?.shortDisplayName || x.team?.displayName, abbr: x.team?.abbreviation, home: x.homeAway === 'home', logo: x.team?.logos?.[0]?.href || '', score: x.score?.displayValue ?? (typeof x.score === 'string' ? x.score : '') }));
      return { id: String(e.id), date: Date.parse(e.date), name: e.name, league: e.league?.name || e.season?.displayName || '', state: c.status?.type?.state || 'pre', teams };
    });
    this.schedules.set(team.id, { at: Date.now(), events });
    return events;
  }

  async summary(id) {
    const j = await getJson(`${API}/all/summary?event=${id}`);
    const c = j.header?.competitions?.[0] || {};
    const side = (h) => c.competitors?.find((x) => x.homeAway === h) || {};
    const home = side('home'), away = side('away');
    return {
      id,
      state: c.status?.type?.state || 'pre',
      detail: c.status?.type?.shortDetail || '',
      clock: c.status?.displayClock || '',
      half: c.status?.type?.name || '',
      league: j.header?.league?.name || '',
      home: { abbr: home.team?.abbreviation || '', name: home.team?.shortDisplayName || home.team?.displayName || '', score: Number(home.score) || 0 },
      away: { abbr: away.team?.abbreviation || '', name: away.team?.shortDisplayName || away.team?.displayName || '', score: Number(away.score) || 0 },
    };
  }

  line(s) {
    return `${s.home.abbr} ${s.home.score}:${s.away.score} ${s.away.abbr}`;
  }

  async tick(force = false) {
    const { teams, notify } = this.cfg();
    if (!teams.length) {
      this.status = '';
      return;
    }
    const now = Date.now();
    const watch = new Map();
    for (const team of teams) {
      let events = [];
      try {
        events = await this.schedule(team);
      } catch {
        continue;
      }
      for (const e of events) {
        // läuft gerade, beginnt in 20 Minuten oder ist vor Kurzem gestartet
        if (e.state === 'in' || (e.date - now < 20 * 60000 && now - e.date < 3 * 3600000)) watch.set(e.id, e);
      }
    }
    const lines = [];
    for (const e of watch.values()) {
      // Vorschau kurz vor Anpfiff
      if (e.date > now && e.date - now < 16 * 60000 && !this.announced.has(`pre:${e.id}`)) {
        this.announced.add(`pre:${e.id}`);
        const time = new Date(e.date).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
        if (notify) this.notify(`Gleich Anpfiff · ${time}`, `${e.name.replace(' at ', ' – ')}${e.league ? ` · ${e.league}` : ''}`);
      }
      if (e.date > now + 60000 && !force) continue;
      let s;
      try {
        s = await this.summary(e.id);
      } catch {
        continue;
      }
      const prev = this.live.get(e.id);
      this.live.set(e.id, s);
      if (s.state === 'in') lines.push(`⚽ ${this.line(s)} · ${s.clock || s.detail}`);
      if (!notify) continue;
      if (!prev) {
        if (s.state === 'in' && !this.announced.has(`ko:${e.id}`)) {
          this.announced.add(`ko:${e.id}`);
          if (s.home.score + s.away.score === 0) this.notify('Anpfiff', `${s.home.name} – ${s.away.name}${s.league ? ` · ${s.league}` : ''}`);
        }
        continue;
      }
      if (s.home.score + s.away.score > prev.home.score + prev.away.score) {
        const who = s.home.score > prev.home.score ? s.home.name : s.away.name;
        this.notify(`TOR für ${who}!`, `${this.line(s)} · ${s.clock || s.detail}`);
      }
      if (prev.state !== 'in' && s.state === 'in' && !this.announced.has(`ko:${e.id}`)) {
        this.announced.add(`ko:${e.id}`);
        this.notify('Anpfiff', `${s.home.name} – ${s.away.name}${s.league ? ` · ${s.league}` : ''}`);
      }
      if (/HALFTIME/.test(s.half) && !/HALFTIME/.test(prev.half)) this.notify('Halbzeit', this.line(s));
      if (s.state === 'post' && prev.state !== 'post') this.notify('Abpfiff', `${this.line(s)}${s.league ? ` · ${s.league}` : ''}`);
    }
    this.status = this.cfg().island ? lines.join('  ·  ') : '';
  }

  start() {
    clearTimeout(this.timer);
    const loop = async () => {
      try {
        await this.tick();
      } catch {
        /* offline */
      }
      // läuft ein Spiel: alle 30 s, sonst alle 3 Minuten
      const liveNow = [...this.live.values()].some((s) => s.state === 'in');
      this.timer = setTimeout(loop, liveNow ? 30000 : 180000);
    };
    this.timer = setTimeout(loop, 8000);
  }

  async overview() {
    const { teams, notify, island } = this.cfg();
    const now = Date.now();
    const rows = [];
    for (const team of teams) {
      let events = [];
      try {
        events = await this.schedule(team);
      } catch {
        events = [];
      }
      const live = events.find((e) => e.state === 'in');
      const next = events.filter((e) => e.state === 'pre' && e.date > now - 3 * 3600000).sort((a, b) => a.date - b.date)[0];
      const last = events.filter((e) => e.state === 'post').sort((a, b) => b.date - a.date)[0];
      rows.push({ team, live: live ? { ...live, score: this.live.get(live.id) || null } : null, next: next || null, last: last || null });
    }
    return { teams, notify, island, rows, status: this.status };
  }
}

module.exports = { Football };
