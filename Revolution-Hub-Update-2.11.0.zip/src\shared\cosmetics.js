'use strict';

/*
 * Cosmetics für den ganzen Hub: ein Profil (Name, Punkte, Cosmetics) für Schach, Geo, Chats
 * und den Shop auf der Startseite. Katalog + Darstellung (Avatar, Namensfarbe, Titel).
 */
(function (root) {
  // Cosmetics: slot → Liste. Preis in Punkten (◆). Das erste Element je Slot ist gratis.
  // Cosmetics: slot → Liste. Preis in Punkten (◆). Das erste Element je Slot ist gratis.
  // Bewusst teuer: die besten Sachen brauchen viele Lektionen und Siege.
  const COSMETICS = {
    pieces: [
      { id: 'classic', price: 0, t: { de: 'Klassisch', en: 'Classic', es: 'Clásico' } },
      { id: 'marble', price: 400, t: { de: 'Marmor', en: 'Marble', es: 'Mármol' } },
      { id: 'neon', price: 900, t: { de: 'Neon', en: 'Neon', es: 'Neón' }, anim: true },
      { id: 'ice', price: 1200, t: { de: 'Eis', en: 'Ice', es: 'Hielo' }, anim: true },
      { id: 'emerald', price: 1500, t: { de: 'Smaragd', en: 'Emerald', es: 'Esmeralda' }, anim: true },
      { id: 'gold', price: 1800, t: { de: 'Gold', en: 'Gold', es: 'Oro' }, anim: true },
      { id: 'chrome', price: 2200, t: { de: 'Chrom', en: 'Chrome', es: 'Cromo' } },
      { id: 'fire', price: 2600, t: { de: 'Feuer', en: 'Fire', es: 'Fuego' }, anim: true },
      { id: 'obsidian', price: 2900, t: { de: 'Obsidian', en: 'Obsidian', es: 'Obsidiana' } },
      { id: 'void', price: 3200, t: { de: 'Leere', en: 'Void', es: 'Vacío' }, anim: true },
      { id: 'galaxy', price: 4500, t: { de: 'Galaxie', en: 'Galaxy', es: 'Galaxia' }, anim: true },
      { id: 'rainbow', price: 6000, t: { de: 'Regenbogen', en: 'Rainbow', es: 'Arcoíris' }, anim: true },
    ],
    board: [
      { id: 'standard', price: 0, t: { de: 'Standard', en: 'Standard', es: 'Estándar' } },
      { id: 'walnut', price: 500, t: { de: 'Walnuss', en: 'Walnut', es: 'Nogal' } },
      { id: 'marble', price: 800, t: { de: 'Marmor', en: 'Marble', es: 'Mármol' } },
      { id: 'sakura', price: 950, t: { de: 'Kirschblüte', en: 'Sakura', es: 'Sakura' } },
      { id: 'ocean', price: 1100, t: { de: 'Ozean', en: 'Ocean', es: 'Océano' }, anim: true },
      { id: 'glass', price: 1400, t: { de: 'Glas', en: 'Glass', es: 'Cristal' } },
      { id: 'royal', price: 2000, t: { de: 'Königlich', en: 'Royal', es: 'Real' } },
      { id: 'neon', price: 1600, t: { de: 'Neon-Raster', en: 'Neon grid', es: 'Rejilla neón' }, anim: true },
      { id: 'lava', price: 2400, t: { de: 'Lava', en: 'Lava', es: 'Lava' }, anim: true },
      { id: 'cosmos', price: 3500, t: { de: 'Kosmos', en: 'Cosmos', es: 'Cosmos' }, anim: true },
    ],
    avatar: [
      { id: 'none', glyph: '', price: 0 },
      { id: 'pawn', glyph: '♟', price: 80 },
      { id: 'knight', glyph: '♞', price: 200 },
      { id: 'bishop', glyph: '♝', price: 200 },
      { id: 'rook', glyph: '♜', price: 300 },
      { id: 'queen', glyph: '♛', price: 500 },
      { id: 'king', glyph: '♚', price: 700 },
      { id: 'star', glyph: '★', price: 400 },
      { id: 'bolt', glyph: 'ϟ', price: 550 },
      { id: 'crown', glyph: '♔', price: 900 },
      { id: 'heart', glyph: '♥', price: 350 },
      { id: 'spade', glyph: '♠', price: 350 },
      { id: 'sun', glyph: '☀', price: 600 },
      { id: 'moon', glyph: '☾', price: 600 },
      { id: 'skull', glyph: '☠', price: 1100 },
      { id: 'infinity', glyph: '∞', price: 1400 },
      { id: 'custom', glyph: '', price: 4000, custom: true },
    ],
    color: [
      { id: 'grey', bg: 'linear-gradient(135deg,#55556a,#2c2c38)', price: 0 },
      { id: 'violet', bg: 'linear-gradient(135deg,#9a7dff,#6a45f5)', price: 150 },
      { id: 'ocean', bg: 'linear-gradient(135deg,#38bdf8,#1e3a8a)', price: 150 },
      { id: 'forest', bg: 'linear-gradient(135deg,#4ade80,#166534)', price: 150 },
      { id: 'sunset', bg: 'linear-gradient(135deg,#fb923c,#db2777)', price: 300 },
      { id: 'gold', bg: 'linear-gradient(135deg,#fde68a,#b45309)', price: 600 },
      { id: 'rose', bg: 'linear-gradient(135deg,#fb7185,#9f1239)', price: 300 },
      { id: 'midnight', bg: 'linear-gradient(135deg,#1e293b,#020617)', price: 400 },
      { id: 'aurora', bg: 'linear-gradient(135deg,#22d3ee,#a855f7,#f472b6)', price: 1000, anim: true },
      { id: 'lava', bg: 'linear-gradient(135deg,#fde047,#f97316,#b91c1c)', price: 1300, anim: true },
      { id: 'galaxy', bg: 'linear-gradient(135deg,#0f172a,#4c1d95,#1d4ed8,#0f172a)', price: 1800, anim: true },
    ],
    frame: [
      { id: 'none', price: 0 },
      { id: 'silver', price: 200 },
      { id: 'gold', price: 500 },
      { id: 'neon', price: 900, anim: true },
      { id: 'fire', price: 1500, anim: true },
      { id: 'ice', price: 1200, anim: true },
      { id: 'rainbow', price: 2200, anim: true },
      { id: 'void', price: 3000, anim: true },
    ],
    name: [
      { id: 'white', css: '#f2f1f7', price: 0 },
      { id: 'mint', css: '#4ade80', price: 150 },
      { id: 'sky', css: '#38bdf8', price: 150 },
      { id: 'gold', css: '#fbbf24', price: 500 },
      { id: 'rose', css: '#fb7185', price: 150 },
      { id: 'violet', css: '#b39dff', price: 250 },
      { id: 'ice', css: '#a5f3fc', price: 400 },
      { id: 'rainbow', css: 'rainbow', price: 1200, anim: true },
      { id: 'fire', css: 'fire', price: 1800, anim: true },
    ],
    title: [
      { id: 'none', t: { de: '', en: '', es: '' }, price: 0 },
      { id: 'rookie', t: { de: 'Neuling', en: 'Rookie', es: 'Novato' }, price: 60 },
      { id: 'tactician', t: { de: 'Taktiker', en: 'Tactician', es: 'Táctico' }, price: 400 },
      { id: 'mateking', t: { de: 'Mattkönig', en: 'Mate King', es: 'Rey del mate' }, price: 900 },
      { id: 'grandmaster', t: { de: 'Großmeister', en: 'Grandmaster', es: 'Gran maestro' }, price: 2500 },
      { id: 'strategist', t: { de: 'Stratege', en: 'Strategist', es: 'Estratega' }, price: 650 },
      { id: 'explorer', t: { de: 'Weltenbummler', en: 'Globetrotter', es: 'Trotamundos' }, price: 800 },
      { id: 'nightowl', t: { de: 'Nachteule', en: 'Night Owl', es: 'Búho' }, price: 1200 },
      { id: 'legend', t: { de: 'Legende', en: 'Legend', es: 'Leyenda' }, price: 5000 },
      { id: 'revolution', t: { de: 'Revolutionär', en: 'Revolutionary', es: 'Revolucionario' }, price: 8000 },
    ],
    effect: [
      { id: 'none', price: 0 },
      { id: 'sparks', color: '#fbbf24', price: 300 },
      { id: 'ice', color: '#7dd3fc', price: 300 },
      { id: 'toxic', color: '#a3e635', price: 450 },
      { id: 'void', color: '#c084fc', price: 700 },
      { id: 'shockwave', color: '#38bdf8', price: 1200, wave: true },
      { id: 'sakura', color: '#f9a8d4', price: 550 },
      { id: 'gold', color: '#fde047', price: 900 },
      { id: 'meteor', color: '#ff7a1a', price: 2000, wave: true, big: true },
      { id: 'supernova', color: '#e0e7ff', price: 3200, wave: true, big: true },
    ],
  };

  const SLOT_NAMES = {
    pieces: { de: 'Figuren', en: 'Pieces', es: 'Piezas' },
    board: { de: 'Brett', en: 'Board', es: 'Tablero' },
    avatar: { de: 'Bild', en: 'Avatar', es: 'Avatar' },
    color: { de: 'Hintergrund', en: 'Background', es: 'Fondo' },
    frame: { de: 'Rahmen', en: 'Frame', es: 'Marco' },
    name: { de: 'Namensfarbe', en: 'Name color', es: 'Color del nombre' },
    title: { de: 'Titel', en: 'Title', es: 'Título' },
    effect: { de: 'Zug-Effekt', en: 'Move effect', es: 'Efecto de jugada' },
  };


  const cosItem = (slot, id) => COSMETICS[slot].find((x) => x.id === id) || COSMETICS[slot][0];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  function avatarHtml(eq = {}, size = 40) {
    const av = cosItem('avatar', eq.avatar), col = cosItem('color', eq.color), fr = cosItem('frame', eq.frame);
    const img = av.custom && typeof eq.img === 'string' && eq.img.startsWith('data:image/') ? eq.img : '';
    const inner = img
      ? `<img class="av-img" src="${img}" alt="" />`
      : av.glyph
      ? `<span class="av-glyph" style="font-size:${Math.round(size * 0.62)}px">${av.glyph}&#xFE0E;</span>`
      : `<svg class="av-default" viewBox="0 0 24 24"><circle cx="12" cy="9" r="4.2"/><path d="M4 21c.8-4.4 4-7 8-7s7.2 2.6 8 7"/></svg>`;
    return `<div class="av frame-${fr.id}${col.anim ? ' av-anim' : ''}" style="width:${size}px;height:${size}px;background:${col.bg}">${inner}</div>`;
  }
  function nameStyle(eq = {}) {
    const n = cosItem('name', eq.name);
    return n.css === 'rainbow' ? 'class="name-rainbow"' : n.css === 'fire' ? 'class="name-fire"' : `style="color:${n.css}"`;
  }
  function titleHtml(eq = {}, lang = 'de') {
    const ti = cosItem('title', eq.title);
    const text = ti.t?.[lang] || ti.t?.de || '';
    return text ? ` <span class="title-tag">${esc(text)}</span>` : '';
  }
  /** Vorschau eines Shop-Artikels. */
  function preview(slot, it, eq = {}, name = '') {
    if (slot === 'pieces') return `<div class="skin-prev"><span class="piece w skin-${it.id}"><span>♚&#xFE0E;</span></span><span class="piece b skin-${it.id}"><span>♛&#xFE0E;</span></span></div>`;
    if (slot === 'board') return `<div class="board-prev bd-${it.id}">${[0, 1, 2, 3, 4, 5, 6, 7, 8].map((k) => `<i class="sq${(k % 3 + Math.floor(k / 3)) % 2 ? ' dark' : ''}"></i>`).join('')}</div>`;
    if (slot === 'avatar' && it.custom) return `<div class="custom-prev">${eq.img ? `<img src="${eq.img}" alt="" />` : '📷'}</div>`;
    if (slot === 'avatar' || slot === 'color' || slot === 'frame') return avatarHtml({ ...eq, [slot]: it.id }, 44);
    if (slot === 'name') return `<b ${nameStyle({ name: it.id })}>${esc(name || 'Name')}</b>`;
    if (slot === 'title') return `<span class="title-tag">${esc(it.t?.de || '–')}</span>`;
    return `<span class="fx-dot" style="background:${it.color || '#444'}"></span>`;
  }

  const api = { COSMETICS, SLOT_NAMES, cosItem, avatarHtml, nameStyle, titleHtml, preview };
  root.RevCos = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
