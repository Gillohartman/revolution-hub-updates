'use strict';

/*
 * Cloud-Mini-Apps: Schematics (KELPI-Cloud → alle Minecraft-Schematics-Ordner) und
 * Revolution Hub-Konto (Anmelden, Profil auf mehreren PCs).
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

  /* ================================================================ Schematics */
  const sc = { list: null, busy: false, err: '', q: '', cat: '', sort: 'new', open: null, detail: null, installing: '', targets: null, shown: 60 };
  async function scLoad(force = false) {
    if (sc.busy) return;
    sc.busy = true;
    sc.err = '';
    ctx().render();
    try {
      sc.list = await window.hub.schem.list(force);
    } catch (error) {
      sc.err = errText(error);
    }
    sc.busy = false;
    ctx().render();
    if (!sc.targets) window.hub.schem.targets().then((t) => ((sc.targets = t), ctx().render())).catch(() => {});
  }
  function scFiltered() {
    const q = sc.q.trim().toLowerCase();
    let l = (sc.list || []).filter((s) => (!sc.cat || s.cat === sc.cat) && (!q || `${s.name} ${s.desc} ${s.tags.join(' ')} ${s.by}`.toLowerCase().includes(q)));
    if (sc.sort === 'popular') l = l.slice().sort((a, b) => b.downloads - a.downloads);
    else if (sc.sort === 'top') l = l.slice().sort((a, b) => b.rating - a.rating || b.likes - a.likes);
    else l = l.slice().sort((a, b) => b.ts - a.ts);
    return l;
  }
  /* ---------------- 3D-Ansicht, Bewertungen, Kommentare */
  const sv = { id: null, busy: false, err: '', info: null, view: null, host: null, cut: 0, social: null, text: '' };
  function svClose() {
    sv.view?.view.destroy();
    sv.host?.remove();
    Object.assign(sv, { id: null, busy: false, err: '', info: null, view: null, host: null });
  }
  async function svOpen(id) {
    svClose();
    sv.id = id;
    sv.busy = true;
    ctx().render();
    try {
      const f = await window.hub.schem.file(id);
      sv.host = document.createElement('div');
      sv.host.className = 'sv-host';
      document.body.append(sv.host); // erst unsichtbar, dann in die Karte
      sv.view = await window.SchemViewer.open(sv.host, f.data instanceof Uint8Array ? f.data : new Uint8Array(f.data), f.name);
      sv.cut = sv.view.h;
    } catch (error) {
      sv.err = errText(error);
      sv.host?.remove();
      sv.host = null;
    }
    sv.busy = false;
    ctx().render();
  }
  // Die Zeichenfläche bleibt erhalten und wird nach jedem Neuzeichnen wieder eingehängt
  function svAttach() {
    const slot = document.getElementById('sv-slot');
    if (slot && sv.host && sv.host.parentElement !== slot) slot.append(sv.host);
  }
  async function socialLoad(id) {
    try {
      sc.social = await window.hub.schem.social(id);
    } catch {
      sc.social = { avg: 0, count: 0, mine: 0, comments: [], signedIn: false };
    }
    if (sc.open === id) ctx().render();
  }
  const ago = (t) => {
    const d = Date.now() - t;
    if (d < 60000) return 'gerade eben';
    if (d < 3600000) return `vor ${Math.floor(d / 60000)} Min.`;
    if (d < 86400000) return `vor ${Math.floor(d / 3600000)} Std.`;
    if (d < 30 * 86400000) return `vor ${Math.floor(d / 86400000)} Tagen`;
    return new Date(t).toLocaleDateString('de-DE');
  };
  function viewerHtml(s) {
    const v = sv.id === s.id ? sv.view : null;
    if (!v) {
      return `<div class="tool-card sv-card"><div class="sv-empty">${sv.id === s.id && sv.busy ? '<span class="spin"></span> Datei wird geladen und aufgebaut …' : sv.id === s.id && sv.err ? `<p class="err">${esc(sv.err)}</p>` : `<button class="btn primary" data-sv="open">${icon('cube', 16)} In 3D ansehen</button><small class="muted">Ziehen dreht · Rechtsklick/Umschalt zieht verschiebt · Mausrad zoomt · Regler zeigt Ebene für Ebene</small>`}</div></div>`;
    }
    setTimeout(svAttach, 0);
    const top = v.mats.slice(0, 14);
    return `<div class="tool-card sv-card"><div class="sv-stage" id="sv-slot"></div>
      <div class="sv-tools"><label class="sv-layer">Ebene <input type="range" min="1" max="${v.h}" value="${Math.min(sv.cut, v.h)}" data-sv-cut /><output>${Math.min(sv.cut, v.h)} / ${v.h}</output></label>
        <button class="btn small ghost" data-sv="top">Draufsicht</button><button class="btn small ghost" data-sv="reset">Zurücksetzen</button><button class="btn small ghost" data-sv="spin">Drehen</button><button class="btn small ghost" data-sv="close">Schliessen</button></div>
      <small class="muted">${v.w} × ${v.h} × ${v.l} Blöcke · ${v.total.toLocaleString('de-DE')} Blöcke gesamt${v.hidden ? ' · sehr groß: nur ein Teil wird gezeigt' : ''}</small>
      <details class="sv-mats"><summary>Materialliste (${v.mats.length} Blockarten)</summary><div>${top.map((m) => `<span><i style="background:rgb(${m.c.join(',')})"></i>${esc(m.name.replace(/_/g, ' '))}<b>${m.n.toLocaleString('de-DE')}</b></span>`).join('')}${v.mats.length > top.length ? `<small class="muted">… und ${v.mats.length - top.length} weitere</small>` : ''}</div></details></div>`;
  }
  function socialHtml(s) {
    const so = sc.social;
    if (!so) return `<div class="tool-card"><div class="tool-label">Bewertungen &amp; Kommentare</div><p class="muted">Wird geladen …</p></div>`;
    const stars = (n, act) => [1, 2, 3, 4, 5].map((i) => `<button class="sv-star ${i <= n ? 'on' : ''}" ${act ? `data-sv-rate="${i}"` : 'disabled'} title="${i} Stern${i > 1 ? 'e' : ''}">★</button>`).join('');
    return `<div class="tool-card sv-social"><div class="tool-label">Bewertungen &amp; Kommentare</div>
      <div class="sv-rating"><b>${so.avg ? String(so.avg).replace('.', ',') : '–'}</b><div><div class="sv-stars">${stars(Math.round(so.avg), false)}</div><small class="muted">${so.count} Bewertung${so.count === 1 ? '' : 'en'}</small></div>
        <div class="sv-mine"><small class="muted">${so.signedIn ? (so.mine ? 'Deine Bewertung' : 'Jetzt bewerten') : 'Zum Bewerten anmelden'}</small>${so.signedIn && so.email ? `<small class="muted" style="display:block">als ${esc(so.email)}</small>` : ''}<div class="sv-stars">${so.signedIn ? stars(so.mine, true) : stars(0, false)}</div></div></div>
      ${so.signedIn ? `<div class="sv-write"><textarea class="input" id="sv-text" maxlength="500" rows="2" placeholder="Schreib einen Kommentar … (z. B. wie die Farm funktioniert)">${esc(sv.text)}</textarea><button class="btn primary small" data-sv="send">Senden</button></div>` : `<p class="muted">Melde dich unter <a href="#" data-open="tool-account">Konto</a> an, um zu kommentieren.</p>`}
      <div class="sv-comments">${so.comments.length ? so.comments.map((c) => `<div class="sv-com"><div class="sv-com-h"><b>${esc(c.name)}</b>${c.src === 'KELPI' ? '<em>KELPI-Website</em>' : ''}<small class="muted">${ago(c.at)}</small>${c.mine ? `<button class="sv-del" data-sv-del="${esc(c.id)}" title="Löschen">×</button>` : ''}</div><p>${esc(c.text)}</p></div>`).join('') : '<p class="muted">Noch keine Kommentare – sei der Erste!</p>'}</div></div>`;
  }
  const kind = (f) => (/\.schem(atic)?$/i.test(f) ? 'WorldEdit' : /\.mcstructure$/i.test(f) ? 'Bedrock' : 'Litematica');

  /** Fehlende Vorschaubilder der sichtbaren Kacheln nachladen. */
  let iconBusy = false;
  async function scIcons(list) {
    if (iconBusy || !window.hub.schem.icons) return;
    const missing = list.filter((s) => !s.icon && !s.iconTried).slice(0, 24);
    if (!missing.length) return;
    iconBusy = true;
    missing.forEach((s) => (s.iconTried = true));
    try {
      const got = await window.hub.schem.icons(missing.map((s) => s.id));
      for (const s of missing) if (got[s.id]) s.icon = got[s.id];
    } catch {
      /* ohne Bild */
    }
    iconBusy = false;
    if (ctx().state()?.active === 'tool-schematics' && !sc.open) ctx().render();
  }
  function schematicsHtml() {
    if (!sc.list && !sc.busy && !sc.err) scLoad();
    if (sc.open) return scDetailHtml();
    const cats = [...new Set((sc.list || []).map((s) => s.cat).filter(Boolean))].sort();
    const list = scFiltered();
    if (sc.list) setTimeout(() => scIcons(list.slice(0, sc.shown)), 0);
    return `<div class="tool-card sc-bar">
        <input class="input" data-sc="q" value="${esc(sc.q)}" placeholder="Schematics durchsuchen … (Name, Tag, Ersteller)" />
        <div class="seg">${[['new', 'Neu'], ['popular', 'Beliebt'], ['top', 'Top bewertet']].map(([v, n]) => `<button class="${sc.sort === v ? 'on' : ''}" data-sc-sort="${v}">${n}</button>`).join('')}</div>
        <button class="btn small ghost" data-sc-act="reload" title="Neu laden">${icon('refresh', 15)}</button>
      </div>
      ${cats.length ? `<div class="chip-row"><button class="chip ${!sc.cat ? 'on' : ''}" data-sc-cat="">Alle</button>${cats.map((c) => `<button class="chip ${sc.cat === c ? 'on' : ''}" data-sc-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div>` : ''}
      ${sc.err ? `<p class="err">${esc(sc.err)}</p>` : ''}
      ${!sc.list ? `<p class="muted tool-note">${sc.busy ? 'Schematics werden geladen …' : ''}</p>` : `<p class="muted tool-note">${list.length} von ${sc.list.length} Schematics · Klick öffnet Bilder und Installation</p>
      <div class="sc-grid">${list.slice(0, sc.shown).map((s) => `<button class="sc-card" data-sc-open="${esc(s.id)}">
          <div class="sc-img">${s.icon ? `<img src="${esc(s.icon)}" alt="" loading="lazy" draggable="false" />` : `<span class="sc-ph">${icon('cube', 34)}</span>`}<em>${kind(s.fileName)}</em></div>
          <b>${esc(s.name)}</b><small>${s.by ? `von ${esc(s.by)} · ` : ''}⬇ ${s.downloads.toLocaleString('de-DE')}${s.rating ? ` · ★ ${String(s.rating).replace('.', ',')}` : ''}</small></button>`).join('')}</div>
      ${list.length > sc.shown ? `<div class="tool-row center"><button class="btn" data-sc-act="more">Mehr anzeigen (${list.length - sc.shown})</button></div>` : ''}`}`;
  }
  function scDetailHtml() {
    const s = (sc.list || []).find((x) => x.id === sc.open);
    const d = sc.detail;
    if (!s) return '';
    const imgs = d ? (d.images.length ? d.images : d.icon ? [d.icon] : s.icon ? [s.icon] : []) : s.icon ? [s.icon] : [];
    return `<div class="tool-row"><button class="btn small ghost" data-sc-act="back">← Alle Schematics</button></div>
      <div class="tool-grid two sc-detail">
        <div class="tool-card"><div class="sc-gallery">${imgs.length ? imgs.map((u, i) => `<img src="${esc(u)}" alt="" class="${i ? '' : 'main'}" draggable="false" />`).join('') : `<div class="sc-noimg">${d ? 'Kein Vorschaubild' : 'Bilder werden geladen …'}</div>`}</div></div>
        <div class="tool-card"><h3 style="margin:0">${esc(s.name)}</h3>
          <small class="muted">${s.by ? `von ${esc(s.by)} · ` : ''}${esc(s.cat || '')}${s.ts ? ` · ${new Date(s.ts).toLocaleDateString('de-DE')}` : ''}</small>
          ${s.desc ? `<p class="sc-desc">${esc(s.desc)}</p>` : ''}
          ${s.tags.length ? `<div class="chip-row">${s.tags.map((t) => `<span class="chip">${esc(t)}</span>`).join('')}</div>` : ''}
          <div class="kv sc-kv"><span>Datei</span><b>${esc(s.fileName || '–')}</b><span>Format</span><b>${kind(s.fileName)}</b><span>Downloads</span><b>${s.downloads.toLocaleString('de-DE')}</b>${s.rating ? `<span>Bewertung</span><b>★ ${String(s.rating).replace('.', ',')}</b>` : ''}</div>
          ${d?.versions?.length > 1 ? `<div class="tool-label">Versionen</div><div class="chip-row">${d.versions.map((v) => `<button class="chip" data-sc-install="${esc(s.id)}" data-v="${v.i}">${esc(v.name)} installieren</button>`).join('')}</div>` : ''}
          <button class="btn primary sc-go" data-sc-install="${esc(s.id)}" ${sc.installing ? 'disabled' : ''}>${sc.installing === s.id ? 'Wird installiert …' : `${icon('download', 16)} In alle Schematics-Ordner legen`}</button>
          <small class="muted">${sc.targets ? (sc.targets.length ? `Ziel: ${sc.targets.length} Ordner – ${esc(sc.targets.slice(0, 4).join(', '))}${sc.targets.length > 4 ? ' …' : ''}` : 'Keine Minecraft-Installation gefunden – der Ordner .minecraft\\schematics wird angelegt.') : ''}</small>
        </div>
      </div>
      ${viewerHtml(s)}
      ${socialHtml(s)}`;
  }

  document.addEventListener('input', (e) => {
    if (e.target.matches?.('[data-sv-cut]')) {
      sv.cut = Number(e.target.value);
      sv.view?.view.setCut(sv.cut - 0.5 + 0.5);
      e.target.nextElementSibling.textContent = `${sv.cut} / ${sv.view?.h}`;
      return;
    }
    if (e.target.id === 'sv-text') sv.text = e.target.value;
    if (e.target.dataset?.sc === 'q') {
      sc.q = e.target.value;
      sc.shown = 60;
      clearTimeout(sc.t);
      sc.t = setTimeout(() => ctx().render(), 150);
    }
  });
  document.addEventListener('click', async (e) => {
    if (ctx().state()?.active !== 'tool-schematics') return;
    const so = e.target.closest?.('[data-sc-sort]');
    if (so) {
      sc.sort = so.dataset.scSort;
      return ctx().render();
    }
    const ca = e.target.closest?.('[data-sc-cat]');
    if (ca) {
      sc.cat = ca.dataset.scCat;
      sc.shown = 60;
      return ctx().render();
    }
    const op = e.target.closest?.('[data-sc-open]');
    if (op) {
      sc.open = op.dataset.scOpen;
      sc.detail = null;
      sc.social = null;
      svClose();
      socialLoad(sc.open);
      ctx().render();
      document.querySelector('.content')?.scrollTo({ top: 0 });
      try {
        sc.detail = await window.hub.schem.detail(sc.open);
      } catch {
        sc.detail = { images: [], versions: [] };
      }
      return ctx().render();
    }
    const ins = e.target.closest?.('[data-sc-install]');
    if (ins) {
      if (sc.installing) return;
      sc.installing = ins.dataset.scInstall;
      ctx().render();
      try {
        const r = await window.hub.schem.install(sc.installing, ins.dataset.v != null ? Number(ins.dataset.v) : -1);
        ctx().toast(`${r.file} liegt jetzt in ${r.count} Ordner(n).`);
      } catch (error) {
        ctx().toast(errText(error), 'error');
      }
      sc.installing = '';
      return ctx().render();
    }
    const a = e.target.closest?.('[data-sc-act]')?.dataset.scAct;
    if (a === 'reload') return scLoad(true);
    if (a === 'more') {
      sc.shown += 60;
      return ctx().render();
    }
    if (a === 'back') {
      sc.open = null;
      svClose();
      return ctx().render();
    }
    const vs = e.target.closest?.('[data-sv]')?.dataset.sv;
    if (vs === 'open') return svOpen(sc.open);
    if (vs === 'close') {
      svClose();
      return ctx().render();
    }
    if (vs === 'top') return sv.view?.view.top();
    if (vs === 'reset') return sv.view?.view.reset();
    if (vs === 'spin') return sv.view?.view.spin();
    const rt = e.target.closest?.('[data-sv-rate]');
    if (rt) {
      try {
        await window.hub.schem.rate(sc.open, Number(rt.dataset.svRate));
        ctx().toast('Danke für deine Bewertung!');
      } catch (error) {
        ctx().toast(errText(error), 'error');
      }
      return socialLoad(sc.open);
    }
    if (vs === 'send') {
      sv.text = document.getElementById('sv-text')?.value || '';
      try {
        await window.hub.schem.comment(sc.open, sv.text);
        sv.text = '';
        ctx().toast('Kommentar gesendet.');
      } catch (error) {
        ctx().toast(errText(error), 'error');
      }
      return socialLoad(sc.open);
    }
    const dl = e.target.closest?.('[data-sv-del]');
    if (dl) {
      try {
        await window.hub.schem.uncomment(dl.dataset.svDel);
      } catch (error) {
        ctx().toast(errText(error), 'error');
      }
      return socialLoad(sc.open);
    }
  });
  T.register('tool-schematics', { nav: 'Schematics', title: 'Schematics', sub: 'KELPI-Cloud für Minecraft', icon: 'cube', tint: 'linear-gradient(135deg,#4ade80,#15803d)', desc: 'Alle Schematics der KELPI-Website ansehen und mit einem Klick in jeden Schematics-Ordner (Litematica, WorldEdit, Launcher) legen.' }, schematicsHtml);

  /* ================================================================ Konto */
  const ac = { st: null, mode: 'login', busy: false, err: '', info: '', setup: null };
  const qrSvg = (text) => {
    try {
      const q = window.qrcode(0, 'M');
      q.addData(text);
      q.make();
      return q.createSvgTag({ cellSize: 5, margin: 2, scalable: true });
    } catch {
      return '';
    }
  };
  window.hub.onAccount?.((st) => {
    ac.st = st;
    // Anmeldung geändert: Bewertungen/Kommentare des offenen Schematics neu laden
    if (sc.open && ctx().state()?.active === 'tool-schematics') socialLoad(sc.open);
    if (['tool-account', 'settings'].includes(ctx().state()?.active)) ctx().render();
  });
  function accountHtml() {
    if (!ac.st) window.hub.account.state().then((st) => ((ac.st = st), ctx().render())).catch(() => {});
    const st = ac.st || {};
    if (st.needCode && !st.signedIn) {
      return `<div class="tool-card acct-form"><div class="acct-head"><span class="acct-ok">${icon('shield', 22)}</span><div><b>Zwei-Faktor-Anmeldung</b><small class="muted">${esc(st.email || '')}</small></div></div>
        <p class="muted">Öffne deine Authenticator-App (z. B. Google oder Microsoft Authenticator) und gib den 6-stelligen Code für „Revolution Hub“ ein.</p>
        <input class="input acct-code" id="acct-code" inputmode="numeric" maxlength="7" autocomplete="one-time-code" placeholder="123 456" />
        ${ac.err ? `<p class="err">${esc(ac.err)}</p>` : ''}
        <div class="tool-row"><button class="btn primary" data-acct="code" ${ac.busy ? 'disabled' : ''}>${ac.busy ? 'Prüfe …' : 'Bestätigen'}</button><button class="btn ghost" data-acct="cancel">Abbrechen</button></div></div>`;
    }
    if (st.signedIn) {
      const mfaCard = ac.setup
        ? `<div class="tool-card"><div class="tool-label">2FA einrichten</div>
            <div class="acct-qr">${qrSvg(ac.setup.uri)}</div>
            <small class="muted">1. Scanne den Code mit deiner Authenticator-App. Ohne Kamera: Schlüssel <code class="acct-secret">${esc(ac.setup.secret)}</code> von Hand eingeben.<br>2. Gib den 6-stelligen Code aus der App ein:</small>
            <input class="input acct-code" id="acct-mfa-code" inputmode="numeric" maxlength="7" placeholder="123 456" />
            <div class="tool-row"><button class="btn primary" data-acct="mfaFinish" ${ac.busy ? 'disabled' : ''}>2FA einschalten</button><button class="btn ghost" data-acct="mfaCancel">Abbrechen</button></div></div>`
        : `<div class="tool-card"><div class="tool-label">Sicherheit</div>
            <div class="list-row"><div class="grow"><strong>Zwei-Faktor-Anmeldung (2FA)</strong><small>${st.mfa ? 'An – bei jeder Anmeldung brauchst du zusätzlich den Code aus deiner Authenticator-App.' : 'Aus – schütze dein Konto zusätzlich mit einer Authenticator-App.'}</small></div>${st.mfa ? '<button class="btn small ghost" data-acct="mfaRemove">Ausschalten</button>' : '<button class="btn small primary" data-acct="mfaStart">Einschalten</button>'}</div>
            <div class="list-row"><div class="grow"><strong>E-Mail bestätigt</strong><small>${st.emailVerified ? 'Ja.' : 'Noch nicht – nötig für 2FA und zum Zurücksetzen des Passworts.'}</small></div>${st.emailVerified ? `<span class="acct-badge">${icon('check', 14)}</span>` : '<button class="btn small" data-acct="verify">Link senden</button>'}</div></div>`;
      return `<div class="tool-grid two">
        <div class="tool-card acct-card"><div class="acct-head"><span class="acct-ok">${icon('check', 22)}</span><div><b>Angemeldet${st.mfa ? ' · 2FA an' : ''}</b><small class="muted">${esc(st.email)}</small></div></div>
          <p class="muted">Name, Punkte, Cosmetics und dein Schach-Profil (Elo, Statistik, Lernpfad) werden mit diesem Konto abgeglichen. Melde dich auf einem anderen PC mit derselben E-Mail an – dann ist alles da.</p>
          <div class="kv"><span>Letzter Abgleich</span><b>${st.lastSync ? new Date(st.lastSync).toLocaleString('de-DE', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : '–'}</b><span>Status</span><b>${st.syncing ? 'gleicht ab …' : st.error ? 'Fehler' : 'aktuell'}</b></div>
          ${st.error ? `<p class="err">${esc(st.error)}</p>` : ''}${ac.err ? `<p class="err">${esc(ac.err)}</p>` : ''}${ac.info ? `<p class="muted">${esc(ac.info)}</p>` : ''}
          <div class="tool-row" style="flex-wrap:wrap"><button class="btn primary" data-acct="sync" ${st.syncing ? 'disabled' : ''}>Jetzt abgleichen</button><button class="btn" data-acct="pull">Stand aus der Cloud laden</button><button class="btn ghost" data-acct="logout">Abmelden</button></div></div>
        ${mfaCard}</div>`;
    }
    const create = ac.mode === 'create';
    return `<div class="tool-card acct-form">
        <div class="seg"><button class="${!create ? 'on' : ''}" data-acct-mode="login">Anmelden</button><button class="${create ? 'on' : ''}" data-acct-mode="create">Konto erstellen</button></div>
        <label class="tool-label">E-Mail</label><input class="input" id="acct-mail" type="email" autocomplete="username" placeholder="du@beispiel.de" value="${esc(ac.mail || '')}" />
        <label class="tool-label">Passwort</label><input class="input" id="acct-pw" type="password" autocomplete="${create ? 'new-password' : 'current-password'}" placeholder="mindestens 6 Zeichen" value="${esc(ac.pw || '')}" />
        ${create ? `<label class="tool-label">Passwort bestätigen</label><input class="input" id="acct-pw2" type="password" autocomplete="new-password" placeholder="Passwort noch einmal" value="${esc(ac.pw2 || '')}" />` : ''}
        ${ac.err ? `<p class="err">${esc(ac.err)}</p>` : ''}${ac.info ? `<p class="muted">${esc(ac.info)}</p>` : ''}
        <div class="tool-row"><button class="btn primary" data-acct="go" ${ac.busy ? 'disabled' : ''}>${ac.busy ? 'Einen Moment …' : create ? 'Konto erstellen' : 'Anmelden'}</button>${!create ? '<button class="btn ghost" data-acct="reset">Passwort vergessen?</button>' : ''}</div>
        <small class="muted">Ein Konto für alle deine PCs: Elo, Punkte und Cosmetics sind überall gleich. Mit demselben Konto spielst und kaufst du auch auf der Revolution Hub-Website.</small>
      </div>`;
  }
  document.addEventListener('click', async (e) => {
    if (!['tool-account'].includes(ctx().state()?.active)) return;
    const m = e.target.closest?.('[data-acct-mode]');
    if (m) {
      ac.mode = m.dataset.acctMode;
      ac.err = '';
      return ctx().render();
    }
    const a = e.target.closest?.('[data-acct]')?.dataset.acct;
    if (!a) return;
    ac.err = '';
    ac.info = '';
    // Eingaben VOR dem Neuzeichnen lesen – sonst sind die Felder leer
    const val = (id) => document.getElementById(id)?.value || '';
    if (document.getElementById('acct-mail')) {
      ac.mail = val('acct-mail').trim();
      ac.pw = val('acct-pw');
      ac.pw2 = val('acct-pw2');
    }
    const code = val('acct-code') || val('acct-mfa-code');
    try {
      if (a === 'go') {
        if (ac.mode === 'create' && ac.pw !== ac.pw2) throw new Error('Die Passwörter stimmen nicht überein.');
        ac.busy = true;
        ctx().render();
        ac.st = await window.hub.account.login(ac.mail, ac.pw, ac.mode === 'create');
        ac.pw = ac.pw2 = '';
        ctx().toast(ac.mode === 'create' ? 'Konto erstellt – dein Stand ist gesichert.' : ac.st?.needCode ? 'Jetzt noch der Code aus deiner Authenticator-App.' : 'Angemeldet – Profil abgeglichen.');
      } else if (a === 'reset') {
        if (!ac.mail) throw new Error('Gib oben deine E-Mail ein, dann noch einmal klicken.');
        await window.hub.account.reset(ac.mail);
        ac.info = 'Wir haben dir eine E-Mail zum Zurücksetzen geschickt.';
      } else if (a === 'code') {
        ac.busy = true;
        ctx().render();
        ac.st = await window.hub.account.code(code);
        ctx().toast('Angemeldet – Profil abgeglichen.');
      } else if (a === 'cancel') ac.st = await window.hub.account.cancel();
      else if (a === 'mfaStart') ac.setup = await window.hub.account.mfaStart();
      else if (a === 'mfaCancel') ac.setup = null;
      else if (a === 'mfaFinish') {
        ac.busy = true;
        ctx().render();
        ac.st = await window.hub.account.mfaFinish(code);
        ac.setup = null;
        ctx().toast('2FA ist an – ab jetzt brauchst du beim Anmelden den Code aus der App.');
      } else if (a === 'mfaRemove') {
        ac.st = await window.hub.account.mfaRemove();
        ctx().toast('2FA ist aus.');
      } else if (a === 'verify') {
        await window.hub.account.verify();
        ac.info = 'Bestätigungs-Link gesendet – schau in dein Postfach.';
      } else if (a === 'logout') ac.st = await window.hub.account.logout();
      else if (a === 'sync') ac.st = await window.hub.account.sync('auto');
      else if (a === 'pull') {
        ac.st = await window.hub.account.sync('pull');
        ctx().toast('Stand aus der Cloud übernommen.');
      }
    } catch (error) {
      ac.err = errText(error);
    }
    ac.busy = false;
    ctx().render();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && ['acct-pw', 'acct-mail', 'acct-pw2'].includes(e.target.id)) document.querySelector('[data-acct="go"]')?.click();
    if (e.key === 'Enter' && e.target.id === 'acct-code') document.querySelector('[data-acct="code"]')?.click();
    if (e.key === 'Enter' && e.target.id === 'acct-mfa-code') document.querySelector('[data-acct="mfaFinish"]')?.click();
  });
  T.register('tool-account', { nav: 'Konto', title: 'Revolution Hub-Konto', sub: 'Profil auf allen PCs', icon: 'users', tint: 'linear-gradient(135deg,#a78bfa,#4f46e5)', desc: 'Anmelden und Elo, Punkte und Cosmetics auf jedem PC behalten.' }, accountHtml);
})();
