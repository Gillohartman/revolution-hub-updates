'use strict';

const fs = require('fs');
const path = require('path');
const { boot, bindHubProfile, bindChat } = require('../shared/boot');

const ctx = boot('chess', __dirname);
const { app, ipcMain } = ctx.electron;
bindHubProfile(ipcMain);
bindChat(ipcMain);

const file = (name) => path.join(app.getPath('userData'), name);

function readJson(name, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file(name), 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(name, data) {
  fs.mkdirSync(path.dirname(file(name)), { recursive: true });
  fs.writeFileSync(`${file(name)}.tmp`, JSON.stringify(data));
  fs.renameSync(`${file(name)}.tmp`, file(name));
  return true;
}

ipcMain.handle('profile:load', () => readJson('profile.json', null));
ipcMain.handle('profile:save', (_event, profile) => writeJson('profile.json', profile));
ipcMain.handle('game:load', () => readJson('current-game.json', null));
ipcMain.handle('game:save', (_event, game) => (game ? writeJson('current-game.json', game) : (fs.rmSync(file('current-game.json'), { force: true }), true)));
ipcMain.handle('games:list', () => readJson('games.json', []));
ipcMain.handle('games:add', (_event, game) => {
  const list = readJson('games.json', []);
  list.unshift(game);
  return writeJson('games.json', list.slice(0, 200));
});
ipcMain.handle('notify', (_event, title, body) => {
  try {
    ctx.hub.notify?.(title, body, { app: 'chess' });
  } catch {
    /* ohne Hinweis */
  }
  return true;
});

/* ------------------------------------------------------------------ Stockfish */
// „Unschlagbar“: die offizielle Stockfish-Engine (Windows) wird beim ersten Einschalten
// von GitHub geladen und läuft als eigener Prozess.

const { spawn, execFile } = require('child_process');
const sfDir = () => path.join(app.getPath('userData'), 'stockfish');
const sfInfo = () => readJson(path.join('stockfish', 'info.json'), null);
let sfProc = null;
let sfBuffer = '';
let sfWaiters = [];

function sfSend(line) {
  if (sfProc && !sfProc.killed) sfProc.stdin.write(`${line}\n`);
}

function sfWait(pattern, timeout = 15000) {
  return new Promise((resolve, reject) => {
    const waiter = { pattern, resolve, lines: [] };
    sfWaiters.push(waiter);
    setTimeout(() => {
      if (sfWaiters.includes(waiter)) {
        sfWaiters = sfWaiters.filter((w) => w !== waiter);
        reject(new Error('Stockfish antwortet nicht'));
      }
    }, timeout);
  });
}

function sfStart(exe) {
  return new Promise((resolve, reject) => {
    try {
      sfProc = spawn(exe, [], { windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'] });
    } catch (error) {
      reject(error);
      return;
    }
    sfProc.on('error', reject);
    sfProc.on('exit', () => {
      sfProc = null;
    });
    sfProc.stdout.on('data', (data) => {
      sfBuffer += data.toString();
      const lines = sfBuffer.split(/\r?\n/);
      sfBuffer = lines.pop();
      for (const line of lines) {
        for (const w of [...sfWaiters]) {
          w.lines.push(line);
          if (w.pattern.test(line)) {
            sfWaiters = sfWaiters.filter((x) => x !== w);
            w.resolve({ line, lines: w.lines });
          }
        }
      }
    });
    sfSend('uci');
    sfWait(/^uciok/, 6000)
      .then(() => {
        const threads = Math.max(1, Math.min(8, require('os').cpus().length - 1));
        sfSend(`setoption name Threads value ${threads}`);
        sfSend('setoption name Hash value 128');
        sfSend('isready');
        return sfWait(/^readyok/, 6000);
      })
      .then(() => resolve(true))
      .catch((error) => {
        try {
          sfProc?.kill();
        } catch {
          /* egal */
        }
        sfProc = null;
        reject(error);
      });
  });
}

async function sfEnsure() {
  if (sfProc) return true;
  const info = sfInfo();
  if (!info?.exe || !fs.existsSync(info.exe)) throw new Error('Stockfish ist noch nicht installiert.');
  await sfStart(info.exe);
  return true;
}

function findExe(dir) {
  for (const name of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, name.name);
    if (name.isDirectory()) {
      const inner = findExe(full);
      if (inner) return inner;
    } else if (/^stockfish.*\.exe$/i.test(name.name)) return full;
  }
  return null;
}

/**
 * Download mit Fortsetzen: bricht die (langsame) Verbindung ab, geht es ab der
 * bereits geladenen Stelle weiter (HTTP-Range) – bis zu 8 Versuche.
 */
async function download(url, file, onProgress) {
  const { net } = ctx.electron;
  const doFetch = (u, headers) => (net?.fetch ? net.fetch(u, { headers }) : fetch(u, { headers }));
  const part = `${file}.part`;
  let total = 0;
  let lastError = null;
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const have = fs.existsSync(part) ? fs.statSync(part).size : 0;
    if (total && have >= total) break;
    try {
      const headers = { 'User-Agent': 'Revolution-Hub' };
      if (have) headers.Range = `bytes=${have}-`;
      const res = await doFetch(url, headers);
      if (res.status === 404) throw Object.assign(new Error('nicht gefunden (404)'), { fatal: true });
      if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status}`);
      const resumed = res.status === 206;
      const len = Number(res.headers.get('content-length')) || 0;
      total = resumed ? have + len : len;
      const out = fs.createWriteStream(part, { flags: resumed ? 'a' : 'w' });
      let got = resumed ? have : 0;
      const reader = res.body.getReader();
      const t0 = Date.now();
      const start = got;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        got += value.length;
        if (!out.write(Buffer.from(value))) await new Promise((r) => out.once('drain', r));
        const secs = (Date.now() - t0) / 1000;
        const rate = secs > 1 ? (got - start) / secs : 0;
        onProgress?.(total ? got / total : 0, got, total, rate);
      }
      await new Promise((r) => out.end(r));
      if (!total || got >= total) {
        fs.renameSync(part, file);
        return;
      }
      lastError = new Error('Verbindung abgebrochen');
    } catch (error) {
      if (error.fatal) throw error;
      lastError = error;
    }
    await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
  }
  throw lastError || new Error('Download fehlgeschlagen');
}

let installing = null;
const progressTargets = new Set();

async function sfInstall(event) {
  if (event?.sender) progressTargets.add(event.sender);
  if (installing) return installing;
  installing = sfInstallRun().finally(() => {
    installing = null;
  });
  return installing;
}

async function sfInstallRun() {
  if (process.platform !== 'win32') throw new Error('Stockfish gibt es hier nur unter Windows.');
  const progress = (p, text) => {
    for (const s of progressTargets) if (!s.isDestroyed()) s.send('sf:progress', { p, text });
  };
  // Neueste Version zuerst – Stockfish 19 hat die Dateinamen geändert, deshalb danach
  // feste, geprüfte Versionen (18, 17.1). Je Version zuerst AVX2 (schnell), dann die
  // Varianten für ältere Prozessoren.
  const tags = ['latest/download', 'download/sf_18', 'download/sf_17.1'];
  const variants = ['stockfish-windows-x86-64-avx2.zip', 'stockfish-windows-x86-64-sse41-popcnt.zip', 'stockfish-windows-x86-64.zip'];
  fs.mkdirSync(sfDir(), { recursive: true });
  const errors = [];
  const mb = (b) => (b / 1e6).toFixed(1).replace('.', ',');
  for (const name of variants) {
    for (const tag of tags) {
      const url = `https://github.com/official-stockfish/Stockfish/releases/${tag}/${name}`;
      const ver = tag.split('/').pop() === 'download' ? 'neueste' : tag.split('/').pop();
      try {
        const zip = path.join(sfDir(), `${ver}-${name}`);
        progress(0, `Lade Stockfish (${ver}) …`);
        if (!fs.existsSync(zip))
          await download(url, zip, (p, got, total, rate) => {
            const eta = rate > 0 && total ? Math.round((total - got) / rate) : 0;
            progress(p * 0.9, `Lade Stockfish … ${mb(got)} / ${mb(total)} MB${rate ? ` · ${mb(rate)} MB/s` : ''}${eta ? ` · noch ca. ${eta >= 60 ? `${Math.round(eta / 60)} min` : `${eta} s`}` : ''}`);
          });
        progress(0.92, 'Entpacke …');
        const target = path.join(sfDir(), `${ver}-${name.replace(/\.zip$/i, '')}`);
        fs.rmSync(target, { recursive: true, force: true });
        await new Promise((resolve, reject) =>
          execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${target.replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 180000 }, (e) => (e ? reject(e) : resolve())),
        );
        const exe = findExe(target);
        if (!exe) throw new Error('Stockfish.exe nicht im Archiv');
        progress(0.97, 'Teste die Engine …');
        if (sfProc) sfProc.kill();
        sfProc = null;
        try {
          await sfStart(exe); // ältere CPUs ohne AVX2 scheitern hier → nächste Variante
        } catch (error) {
          fs.rmSync(zip, { force: true });
          throw Object.assign(error, { cpu: true });
        }
        fs.rmSync(zip, { force: true });
        writeJson(path.join('stockfish', 'info.json'), { exe, version: `${ver} ${name}`, at: Date.now() });
        progress(1, 'Stockfish ist bereit.');
        return { ok: true, version: 'Stockfish' };
      } catch (error) {
        errors.push(`${ver}/${name}: ${error.message}`);
        if (error.cpu) break; // diese CPU-Variante läuft nicht → nächste Variante
      }
    }
  }
  throw new Error(errors.join(' · '));
}

ipcMain.handle('sf:status', () => {
  const info = sfInfo();
  return { installed: Boolean(info?.exe && fs.existsSync(info.exe)), installing: Boolean(installing), version: info?.version || '', platform: process.platform };
});

// „Direkt eingebaut“: beim ersten Start des Schach-Coaches still im Hintergrund holen.
app.whenReady().then(() => {
  setTimeout(() => {
    const info = sfInfo();
    if (process.platform === 'win32' && !(info?.exe && fs.existsSync(info.exe))) sfInstall(null).catch(() => {});
  }, 4000);
});
ipcMain.handle('sf:install', async (event) => {
  try {
    return await sfInstall(event);
  } catch (error) {
    return { ok: false, error: error.message || String(error) };
  }
});
ipcMain.handle('sf:move', async (_event, { startFen, moves, movetime = 1500 }) => {
  await sfEnsure();
  sfSend(`position ${startFen && !/^rnbqkbnr\/pppppppp\/8\/8\/8\/8\/PPPPPPPP\/RNBQKBNR w KQkq - 0 1$/.test(startFen) ? `fen ${startFen}` : 'startpos'}${moves?.length ? ` moves ${moves.join(' ')}` : ''}`);
  sfSend(`go movetime ${Math.max(100, Math.min(10000, movetime))}`);
  const { line, lines } = await sfWait(/^bestmove/, movetime + 15000);
  let score = 0;
  for (const l of lines) {
    const cp = / score cp (-?\d+)/.exec(l);
    const mate = / score mate (-?\d+)/.exec(l);
    if (cp) score = Number(cp[1]);
    if (mate) score = Number(mate[1]) > 0 ? 100000 - Number(mate[1]) * 2 : -100000 - Number(mate[1]) * 2;
  }
  return { move: line.split(/\s+/)[1], score };
});
app.on('before-quit', () => {
  try {
    sfSend('quit');
    sfProc?.kill();
  } catch {
    /* egal */
  }
});


/* ================================================================ Natürliche Stimme (Piper)
 * Offline-Neuronalstimme (MIT): beim ersten Einschalten einmal herunterladen (~85 MB),
 * danach spricht der Coach ohne Internet. Deutsch: „Thorsten“, Englisch: „Lessac“. */
const PIPER_ZIP = 'https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip';
const VOICES = {
  de: 'https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx',
  en: 'https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_US/lessac/medium/en_US-lessac-medium.onnx',
  es: 'https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/es/es_ES/davefx/medium/es_ES-davefx-medium.onnx',
};
const ttsDir = () => file('tts');
const piperExe = () => {
  const exe = path.join(ttsDir(), 'piper', 'piper.exe');
  return fs.existsSync(exe) ? exe : '';
};
const voiceFile = (lang) => path.join(ttsDir(), path.basename(VOICES[lang] || VOICES.de));
let ttsInstalling = null;

function ttsStatus(lang = 'de') {
  const exe = piperExe();
  return { installed: Boolean(exe && fs.existsSync(voiceFile(lang)) && fs.existsSync(`${voiceFile(lang)}.json`)), installing: Boolean(ttsInstalling), platform: process.platform };
}
async function ttsInstall(event, lang = 'de') {
  if (process.platform !== 'win32') throw new Error('Nur unter Windows verfügbar');
  if (ttsInstalling) return ttsInstalling;
  const report = (p, label) => event?.sender && !event.sender.isDestroyed() && event.sender.send('tts:progress', { p, label });
  ttsInstalling = (async () => {
    fs.mkdirSync(ttsDir(), { recursive: true });
    if (!piperExe()) {
      const zip = path.join(ttsDir(), 'piper.zip');
      await download(PIPER_ZIP, zip, (p) => report(p * 0.25, 'Stimme wird geladen …'));
      const { execFile } = require('child_process');
      await new Promise((resolve, reject) =>
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${ttsDir().replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 180000 }, (e) => (e ? reject(e) : resolve())),
      );
      fs.rmSync(zip, { force: true });
    }
    const v = voiceFile(lang);
    if (!fs.existsSync(`${v}.json`)) await download(`${VOICES[lang] || VOICES.de}.json`, `${v}.json`, () => {});
    if (!fs.existsSync(v)) await download(VOICES[lang] || VOICES.de, v, (p) => report(0.25 + p * 0.75, 'Stimme wird geladen …'));
    report(1, 'Fertig');
    return ttsStatus(lang);
  })();
  try {
    return await ttsInstalling;
  } finally {
    ttsInstalling = null;
  }
}
/** Text → WAV (als Bytes). */
function ttsSpeak(text, lang = 'de') {
  const exe = piperExe();
  const model = voiceFile(lang);
  if (!exe || !fs.existsSync(model)) throw new Error('Stimme nicht installiert');
  const out = path.join(ttsDir(), `say-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.wav`);
  const { spawn } = require('child_process');
  return new Promise((resolve, reject) => {
    const p = spawn(exe, ['--model', model, '--output_file', out, '--length_scale', '0.98', '--sentence_silence', '0.15'], { cwd: path.dirname(exe), windowsHide: true });
    let err = '';
    p.stderr.on('data', (d) => (err += d));
    p.on('error', reject);
    p.on('close', () => {
      try {
        const bytes = fs.readFileSync(out);
        fs.rmSync(out, { force: true });
        resolve(new Uint8Array(bytes));
      } catch {
        reject(new Error(err.split('\n').slice(-3).join(' ') || 'Sprachausgabe fehlgeschlagen'));
      }
    });
    p.stdin.end(String(text).slice(0, 600), 'utf8');
  });
}
ipcMain.handle('tts:status', (_e, lang) => ttsStatus(lang));
ipcMain.handle('tts:install', async (event, lang) => {
  try {
    return await ttsInstall(event, lang);
  } catch (error) {
    return { ok: false, error: error.message || String(error) };
  }
});
ipcMain.handle('tts:speak', (_e, { text, lang }) => ttsSpeak(text, lang));
