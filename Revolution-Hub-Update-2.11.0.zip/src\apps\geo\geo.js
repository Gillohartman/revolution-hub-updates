'use strict';

(() => {
  const { PLACES, MAPS } = window.GeoPlaces;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ================================================================ Texte */

  const TXT = {
    de: {
      title: 'GeoRevolution', sub: 'Wo auf der Welt bist du?',
      classic: 'Klassisch', classicD: '5 Runden – finde heraus, wo du bist, und setz deinen Pin. Bis zu 5000 Punkte pro Runde.',
      daily: 'Tägliche Challenge', dailyD: 'Jeden Tag dieselben 5 Orte für alle. Einmal pro Tag.', dailyDone: 'Heute schon gespielt: {s} Punkte',
      streak: 'Länder-Streak', streakD: 'Errate nur das Land – wie viele schaffst du am Stück?',
      duel: 'Duell (online)', duelD: 'Du gegen einen Freund. Je näher, desto mehr Schaden. Beide starten mit 6000 Leben.', team: 'Team-Duell 2v2', teamD: 'Zwei gegen zwei. Der beste Tipp jedes Teams zählt – das Team mit dem besseren Tipp macht Schaden.', myTeam: 'Dein Team', theirTeam: 'Gegner-Team', teamNeed: 'Es braucht genau 4 Spieler.', teamA: 'Team Blau', teamB: 'Team Rot',
      party: 'Party (online)', partyD: 'Mehrere Freunde, dieselben 5 Orte. Wer hat am Ende die meisten Punkte?',
      map: 'Karte', time: 'Zeit pro Runde', noLimit: 'Ohne Limit', sec: '{n} s', movement: 'Bewegung', move: 'Bewegen', nmpz: 'Kein Bewegen, Schwenken, Zoomen',
      maps: { world: 'Welt', famous: 'Berühmte Orte', eu: 'Europa', de: 'D-A-CH', na: 'Nordamerika', sa: 'Südamerika', as: 'Asien', af: 'Afrika', oc: 'Ozeanien' },
      play: 'Spielen', guess: 'Raten', placePin: 'Setz deinen Pin auf die Karte', round: 'Runde', score: 'Punkte', next: 'Nächste Runde', results: 'Ergebnis', again: 'Nochmal', menu: 'Menü',
      away: '{d} entfernt', points: '{p} Punkte', noGuess: 'Keine Antwort – 0 Punkte', total: 'Gesamt', perfect: 'Perfekt!', ptsEarned: 'Punkte für den Shop', newPlace: 'Kein Bild? Neuer Ort',
      country: 'Welches Land ist das?', search: 'Land suchen …', right: 'Richtig! Das ist {c}.', wrong: 'Leider falsch – das war {c}.', streakNow: 'Serie: {n}', streakEnd: 'Deine Serie: {n}',
      online: 'Online', yourName: 'Dein Name', create: 'Raum erstellen', join: 'Beitreten', code: 'Code', codePh: 'Code vom Freund', shareCode: 'Schick diesen Code an deine Freunde:', copy: 'Kopieren', copied: 'Kopiert!',
      waiting: 'Warte auf Mitspieler …', players: 'Spieler', start: 'Starten', connecting: 'Verbinde …', netFail: 'Keine Verbindung zum Online-Server: {e}', left: '{name} hat das Spiel verlassen.', leave: 'Verlassen',
      hp: 'Leben', damage: '−{d} Schaden', multiplier: 'Multiplikator ×{m}', theyGuessed: '{name} hat geraten – noch {s} s!', youWin: 'Du hast gewonnen!', youLose: 'Du hast verloren', nextIn: 'Weiter in {s} …', waitOthers: 'Warte auf die anderen …',
      stats: 'Statistik', games: 'Spiele', bestScore: 'Bestwert', bestStreak: 'Beste Serie', duels: 'Duelle (S/N)', avg: 'Ø pro Spiel', history: 'Letzte Spiele',
      settings: 'Einstellungen', lang: 'Sprache', apiKey: 'Google-Maps-Schlüssel (optional)', apiKeyD: 'Ohne Schlüssel nutzt die App die frei einbettbare Street-View-Ansicht. Mit eigenem (kostenlosem) „Maps Embed API“-Schlüssel ist sie stabiler.', save: 'Speichern',
      mode: 'Modus',
      finding: 'Suche einen Ort …',
      ranked: 'Ranked', rankedD: 'Gegen zufällige Spieler deines Rangs. Gewinnen bringt Rangpunkte (GR), verlieren kostet sie.', findMatch: 'Ranked spielen', searching: 'Suche Gegner in {r} … {s} s · {n} in der Warteschlange', cancel: 'Abbrechen', found: 'Gegner gefunden: {name}',
      rank: 'Rang', ranks: 'Alle Ränge', nextRank: 'Noch {p} GR bis {r}', topRank: 'Höchster Rang erreicht', promoted: 'Aufgestiegen: {r}!', demoted: 'Abgestiegen: {r}', placement: 'Platzierung {i}/5', rankedRules: 'Welt · 60 s pro Runde · Duell mit 6000 Leben · Aufgeben = Niederlage',
      record: 'S / N', needName: 'Wähle zuerst deinen Spielernamen.', oppLeftWin: 'Dein Gegner hat das Spiel verlassen – Sieg!', leaveLoss: 'Ranked verlassen zählt als Niederlage.', you: 'Du',
      playersShort: 'Spieler', rankNames: { bronze: 'Bronze', silver: 'Silber', gold: 'Gold', platinum: 'Platin', diamond: 'Diamant', elite: 'Elite', champion: 'Champion', master: 'Master' },
    },
    en: {
      title: 'GeoRevolution', sub: 'Where in the world are you?',
      classic: 'Classic', classicD: '5 rounds – figure out where you are and drop your pin. Up to 5000 points per round.',
      daily: 'Daily challenge', dailyD: 'The same 5 places for everyone, every day. Once per day.', dailyDone: 'Already played today: {s} points',
      streak: 'Country streak', streakD: 'Just guess the country – how many in a row can you get?',
      duel: 'Duel (online)', duelD: 'You against a friend. Closer guesses deal more damage. Both start with 6000 health.', team: 'Team duel 2v2', teamD: 'Two against two. Each team’s best guess counts – the better team deals damage.', myTeam: 'Your team', theirTeam: 'Enemy team', teamNeed: 'Exactly 4 players needed.', teamA: 'Team Blue', teamB: 'Team Red',
      party: 'Party (online)', partyD: 'Several friends, the same 5 places. Who has the most points at the end?',
      map: 'Map', time: 'Time per round', noLimit: 'No limit', sec: '{n} s', movement: 'Movement', move: 'Moving', nmpz: 'No move, pan, zoom',
      maps: { world: 'World', famous: 'Famous places', eu: 'Europe', de: 'DACH', na: 'North America', sa: 'South America', as: 'Asia', af: 'Africa', oc: 'Oceania' },
      play: 'Play', guess: 'Guess', placePin: 'Place your pin on the map', round: 'Round', score: 'Score', next: 'Next round', results: 'Results', again: 'Play again', menu: 'Menu',
      away: '{d} away', points: '{p} points', noGuess: 'No guess – 0 points', total: 'Total', perfect: 'Perfect!', ptsEarned: 'points for the shop', newPlace: 'No image? New place',
      country: 'Which country is this?', search: 'Search country …', right: 'Correct! This is {c}.', wrong: 'Wrong – it was {c}.', streakNow: 'Streak: {n}', streakEnd: 'Your streak: {n}',
      online: 'Online', yourName: 'Your name', create: 'Create room', join: 'Join', code: 'Code', codePh: 'Code from your friend', shareCode: 'Send this code to your friends:', copy: 'Copy', copied: 'Copied!',
      waiting: 'Waiting for players …', players: 'Players', start: 'Start', connecting: 'Connecting …', netFail: 'Can’t reach the online server: {e}', left: '{name} left the game.', leave: 'Leave',
      hp: 'Health', damage: '−{d} damage', multiplier: 'Multiplier ×{m}', theyGuessed: '{name} guessed – {s} s left!', youWin: 'You won!', youLose: 'You lost', nextIn: 'Next in {s} …', waitOthers: 'Waiting for the others …',
      stats: 'Stats', games: 'Games', bestScore: 'Best score', bestStreak: 'Best streak', duels: 'Duels (W/L)', avg: 'Avg. per game', history: 'Recent games',
      settings: 'Settings', lang: 'Language', apiKey: 'Google Maps key (optional)', apiKeyD: 'Without a key the app uses the freely embeddable Street View. With your own (free) “Maps Embed API” key it is more reliable.', save: 'Save',
      mode: 'Mode',
      finding: 'Finding a place …',
      ranked: 'Ranked', rankedD: 'Against random players of your rank. Wins earn rank points (GR), losses cost them.', findMatch: 'Play ranked', searching: 'Searching in {r} … {s} s · {n} in queue', cancel: 'Cancel', found: 'Opponent found: {name}',
      rank: 'Rank', ranks: 'All ranks', nextRank: '{p} GR to {r}', topRank: 'Highest rank reached', promoted: 'Promoted: {r}!', demoted: 'Demoted: {r}', placement: 'Placement {i}/5', rankedRules: 'World · 60 s per round · duel with 6000 HP · leaving = loss',
      record: 'W / L', needName: 'Choose your player name first.', oppLeftWin: 'Your opponent left – victory!', leaveLoss: 'Leaving ranked counts as a loss.', you: 'You',
      playersShort: 'players', rankNames: { bronze: 'Bronze', silver: 'Silver', gold: 'Gold', platinum: 'Platinum', diamond: 'Diamond', elite: 'Elite', champion: 'Champion', master: 'Master' },
    },
    es: {
      title: 'GeoRevolution', sub: '¿Dónde del mundo estás?',
      classic: 'Clásico', classicD: '5 rondas – descubre dónde estás y coloca tu marcador. Hasta 5000 puntos por ronda.',
      daily: 'Reto diario', dailyD: 'Los mismos 5 lugares para todos, cada día. Una vez al día.', dailyDone: 'Ya jugado hoy: {s} puntos',
      streak: 'Racha de países', streakD: 'Adivina solo el país – ¿cuántos seguidos consigues?',
      duel: 'Duelo (online)', duelD: 'Tú contra un amigo. Cuanto más cerca, más daño. Ambos empezáis con 6000 de vida.', team: 'Duelo por equipos 2v2', teamD: 'Dos contra dos. Cuenta la mejor respuesta de cada equipo.', myTeam: 'Tu equipo', theirTeam: 'Equipo rival', teamNeed: 'Hacen falta 4 jugadores.', teamA: 'Equipo Azul', teamB: 'Equipo Rojo',
      party: 'Fiesta (online)', partyD: 'Varios amigos, los mismos 5 lugares. ¿Quién tiene más puntos al final?',
      map: 'Mapa', time: 'Tiempo por ronda', noLimit: 'Sin límite', sec: '{n} s', movement: 'Movimiento', move: 'Moverse', nmpz: 'Sin moverse, girar ni zoom',
      maps: { world: 'Mundo', famous: 'Lugares famosos', eu: 'Europa', de: 'DACH', na: 'Norteamérica', sa: 'Sudamérica', as: 'Asia', af: 'África', oc: 'Oceanía' },
      play: 'Jugar', guess: 'Adivinar', placePin: 'Coloca tu marcador en el mapa', round: 'Ronda', score: 'Puntos', next: 'Siguiente ronda', results: 'Resultado', again: 'Otra vez', menu: 'Menú',
      away: 'a {d}', points: '{p} puntos', noGuess: 'Sin respuesta – 0 puntos', total: 'Total', perfect: '¡Perfecto!', ptsEarned: 'puntos para la tienda', newPlace: '¿Sin imagen? Otro lugar',
      country: '¿Qué país es este?', search: 'Buscar país …', right: '¡Correcto! Es {c}.', wrong: 'Incorrecto – era {c}.', streakNow: 'Racha: {n}', streakEnd: 'Tu racha: {n}',
      online: 'Online', yourName: 'Tu nombre', create: 'Crear sala', join: 'Unirse', code: 'Código', codePh: 'Código de tu amigo', shareCode: 'Envía este código a tus amigos:', copy: 'Copiar', copied: '¡Copiado!',
      waiting: 'Esperando jugadores …', players: 'Jugadores', start: 'Empezar', connecting: 'Conectando …', netFail: 'No hay conexión con el servidor online: {e}', left: '{name} salió de la partida.', leave: 'Salir',
      hp: 'Vida', damage: '−{d} de daño', multiplier: 'Multiplicador ×{m}', theyGuessed: '¡{name} ya adivinó – quedan {s} s!', youWin: '¡Has ganado!', youLose: 'Has perdido', nextIn: 'Siguiente en {s} …', waitOthers: 'Esperando a los demás …',
      stats: 'Estadísticas', games: 'Partidas', bestScore: 'Mejor puntuación', bestStreak: 'Mejor racha', duels: 'Duelos (G/P)', avg: 'Media por partida', history: 'Últimas partidas',
      settings: 'Ajustes', lang: 'Idioma', apiKey: 'Clave de Google Maps (opcional)', apiKeyD: 'Sin clave la app usa Street View incrustable libremente. Con tu propia clave gratuita de “Maps Embed API” es más estable.', save: 'Guardar',
      mode: 'Modo',
      finding: 'Buscando un lugar …',
      ranked: 'Ranked', rankedD: 'Contra jugadores aleatorios de tu rango. Ganar da puntos de rango (GR), perder los quita.', findMatch: 'Jugar ranked', searching: 'Buscando en {r} … {s} s · {n} en cola', cancel: 'Cancelar', found: 'Rival encontrado: {name}',
      rank: 'Rango', ranks: 'Todos los rangos', nextRank: 'Faltan {p} GR para {r}', topRank: 'Rango máximo alcanzado', promoted: '¡Ascendido: {r}!', demoted: 'Descendido: {r}', placement: 'Clasificación {i}/5', rankedRules: 'Mundo · 60 s por ronda · duelo con 6000 de vida · abandonar = derrota',
      record: 'G / P', needName: 'Primero elige tu nombre de jugador.', oppLeftWin: 'Tu rival abandonó: ¡victoria!', leaveLoss: 'Abandonar ranked cuenta como derrota.', you: 'Tú',
      playersShort: 'jugadores', rankNames: { bronze: 'Bronce', silver: 'Plata', gold: 'Oro', platinum: 'Platino', diamond: 'Diamante', elite: 'Élite', champion: 'Campeón', master: 'Maestro' },
    },
  };
  let lang = 'de';
  const t = (k, p = {}) => String(TXT[lang][k] ?? TXT.de[k] ?? k).replace(/\{(\w+)\}/g, (_, x) => p[x] ?? '');
  const mapName = (id) => TXT[lang].maps[id] || id;
  let regionNames = new Intl.DisplayNames([lang], { type: 'region' });
  const countryName = (cc) => {
    try {
      return regionNames.of(cc);
    } catch {
      return cc;
    }
  };

  /* ================================================================ Profil */

  let profile = {
    name: '',
    apiKey: '',
    lang: '',
    settings: { map: 'world', time: 0, nmpz: false },
    stats: { games: 0, best: {}, bestStreak: 0, totalScore: 0, duelsWon: 0, duelsLost: 0, daily: {}, history: [] },
    ranked: { rating: 1000, games: 0, wins: 0, losses: 0, peak: 1000, history: [] },
  };

  /* ================================================================ Ränge */

  // Elo-artige Rangpunkte (GR). Start 1000 = Bronze. Bewusst schwer: K sinkt mit der Erfahrung,
  // ab Diamant gibt es weniger Punkte pro Sieg, Gegner kommen nur aus dem eigenen Rang.
  const RANKS = [
    { id: 'bronze', min: 0, c1: '#f0a35e', c2: '#7a3f12', shape: 'shield' },
    { id: 'silver', min: 1100, c1: '#f1f5f9', c2: '#64748b', shape: 'shield' },
    { id: 'gold', min: 1300, c1: '#fde047', c2: '#a16207', shape: 'shield' },
    { id: 'platinum', min: 1500, c1: '#67e8f9', c2: '#0e7490', shape: 'hex' },
    { id: 'diamond', min: 1700, c1: '#a5b4fc', c2: '#3730a3', shape: 'gem' },
    { id: 'elite', min: 1900, c1: '#f0abfc', c2: '#86198f', shape: 'wings' },
    { id: 'champion', min: 2100, c1: '#fca5a5', c2: '#991b1b', shape: 'wings' },
    { id: 'master', min: 2300, c1: '#fff7c2', c2: '#d97706', shape: 'crown' },
  ];
  const rankOf = (r) => [...RANKS].reverse().find((x) => r >= x.min) || RANKS[0];
  const rankName = (rk) => TXT[lang].rankNames?.[rk.id] || TXT.de.rankNames[rk.id];

  /** Rangabzeichen als SVG: Form und Verzierung werden mit jedem Rang aufwendiger. */
  function badgeSvg(rk, size = 56) {
    const i = RANKS.indexOf(rk);
    const g = `rk-${rk.id}-${Math.random().toString(36).slice(2, 6)}`;
    const body = {
      shield: 'M32 6 L54 14 V32 C54 46 44 54 32 59 C20 54 10 46 10 32 V14 Z',
      hex: 'M32 5 L55 18 V46 L32 59 L9 46 V18 Z',
      gem: 'M32 4 L56 24 L32 60 L8 24 Z',
      wings: 'M32 7 L50 15 V33 C50 45 42 52 32 57 C22 52 14 45 14 33 V15 Z',
      crown: 'M32 8 L52 16 V34 C52 46 43 53 32 58 C21 53 12 46 12 34 V16 Z',
    }[rk.shape];
    const wings = rk.shape === 'wings' || rk.shape === 'crown'
      ? `<path d="M14 22 C4 22 1 30 2 38 C6 34 10 33 14 34 Z M50 22 C60 22 63 30 62 38 C58 34 54 33 50 34 Z" fill="url(#${g})" opacity=".85"/>`
      : '';
    const crown = rk.shape === 'crown' ? `<path d="M20 6 L25 13 L32 3 L39 13 L44 6 L43 16 H21 Z" fill="#fde68a" stroke="#92400e" stroke-width="1"/>` : '';
    const chevrons = Array.from({ length: Math.min(3, (i % 3) + 1) }, (_, k) => `<path d="M22 ${28 + k * 7} L32 ${34 + k * 7} L42 ${28 + k * 7}" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`).join('');
    const star = i >= 4 ? `<path d="M32 15 l2.6 5.4 5.9.8-4.3 4.1 1 5.8L32 28.3l-5.2 2.8 1-5.8-4.3-4.1 5.9-.8Z" fill="#fff"/>` : '';
    return `<svg class="rank-badge ${i >= 5 ? 'glow' : ''}" width="${size}" height="${size}" viewBox="0 0 64 64" style="--rc:${rk.c1}" aria-label="${esc(rankName(rk))}">
      <defs><linearGradient id="${g}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${rk.c1}"/><stop offset="1" stop-color="${rk.c2}"/></linearGradient></defs>
      ${wings}<path d="${body}" fill="url(#${g})" stroke="rgba(255,255,255,.55)" stroke-width="1.5"/>
      <path d="${body}" fill="none" stroke="rgba(0,0,0,.25)" stroke-width="4" transform="translate(32 32) scale(.82) translate(-32 -32)"/>
      ${crown}${star}${i >= 4 ? '' : chevrons}${i >= 4 ? `<text x="32" y="47" text-anchor="middle" font-size="11" font-weight="800" fill="#fff" font-family="Segoe UI, sans-serif">${['', '', '', '', 'IV', 'V', 'VI', 'VII'][i]}</text>` : ''}
    </svg>`;
  }

  /** Neue Rangpunkte nach einem Ranked-Duell. */
  function rankedUpdate(won, oppRating) {
    const R = profile.ranked;
    const k = R.games < 5 ? 40 : R.rating >= 1700 ? 16 : R.games < 30 ? 24 : 20;
    const expect = 1 / (1 + 10 ** (((oppRating ?? R.rating) - R.rating) / 400));
    const delta = Math.round(k * ((won ? 1 : 0) - expect)) || (won ? 1 : -1);
    const before = R.rating;
    R.rating = Math.max(0, R.rating + delta);
    R.games += 1;
    if (won) R.wins += 1;
    else R.losses += 1;
    R.peak = Math.max(R.peak, R.rating);
    R.history = [{ at: Date.now(), won, delta, rating: R.rating }, ...(R.history || [])].slice(0, 30);
    save();
    return { before, after: R.rating, delta };
  }
  const save = () => window.geoApp?.save(profile).catch(() => {});

  /* Hub-Profil: ein Name und ein Punktekonto für alle Apps (Shop auf der Hub-Startseite). */
  const HP = window.hubProfile;
  let hubPoints = null;
  const applyHub = (hp) => {
    if (!hp) return;
    if (hp.name) profile.name = hp.name;
    hubPoints = hp.points;
    const el = document.getElementById('hub-pts');
    if (el) el.textContent = `◆ ${hubPoints.toLocaleString(lang)}`;
  };
  const setHubName = (v) => HP?.name(v).then(applyHub).catch(() => {});
  function earn(n) {
    n = Math.max(0, Math.round(n));
    if (n) HP?.earn(n).then(applyHub).catch(() => {});
    return n;
  }
  window.addEventListener('hub-profile', (e) => applyHub(e.detail));
  document.addEventListener('click', (e) => {
    if (e.target.closest?.('#hub-pts')) HP?.shop();
  });

  /* ================================================================ Hilfen */

  const toRad = (d) => (d * Math.PI) / 180;
  function distKm(a, b) {
    const dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
    return 2 * 6371 * Math.asin(Math.sqrt(h));
  }
  const scoreFor = (km, size) => (km < 0.025 ? 5000 : Math.round(5000 * Math.exp((-10 * km) / size)));
  const fmtDist = (km) => (km < 1 ? `${Math.round(km * 1000)} m` : km < 100 ? `${km.toFixed(1).replace('.', lang === 'en' ? '.' : ',')} km` : `${Math.round(km).toLocaleString(lang)} km`);
  function rng(seed) {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let x = a;
      x = Math.imul(x ^ (x >>> 15), x | 1);
      x ^= x + Math.imul(x ^ (x >>> 7), x | 61);
      return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
    };
  }
  function pickPlaces(mapId, seed, n) {
    const def = MAPS.find((m) => m.id === mapId) || MAPS[0];
    const pool = PLACES.filter(def.filter);
    const r = rng(seed);
    const copy = pool.slice();
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(r() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    // leicht verschieben, damit derselbe Ort nicht immer gleich aussieht; Blickrichtung zufällig
    // Zufällig um den Ort herum suchen (berühmte Orte nur wenig) – gefunden wird dann die
    // nächste echte Straße mit Street View.
    return copy.slice(0, n).map((p) => {
      const km = p.fam ? 0.3 : 4 + r() * 8;
      const ang = r() * Math.PI * 2;
      const qlat = p.lat + (Math.sin(ang) * km) / 111;
      const qlng = p.lng + (Math.cos(ang) * km) / (111 * Math.max(0.2, Math.cos((p.lat * Math.PI) / 180)));
      return { ...p, qlat, qlng, heading: Math.floor(r() * 360) };
    });
  }
  const todaySeed = () => Number(new Date().toISOString().slice(0, 10).replace(/-/g, ''));

  /* ================================================================ Panorama */

  function panoUrl(p) {
    // Offizielles Panorama (Straße) per Panorama-ID – ohne API-Schlüssel einbettbar
    if (p.pano) return `https://www.google.com/maps/embed?pb=!4v1700000000000!6m8!1m7!1s${p.pano}!2m2!1d${p.lat}!2d${p.lng}!3f${p.heading || 0}!4f0!5f0.7820865974627469`;
    if (profile.apiKey) return `https://www.google.com/maps/embed/v1/streetview?key=${encodeURIComponent(profile.apiKey)}&location=${p.lat},${p.lng}&heading=${p.heading || 0}&pitch=0&fov=90`;
    return `https://www.google.com/maps?layer=c&cbll=${p.lat},${p.lng}&cbp=12,${p.heading || 0},0,0,0&output=svembed&hl=${lang}`;
  }
  /** Echtes Straßen-Panorama zum Ort suchen (einmal je Ort, wird gemerkt). */
  async function resolvePlace(p) {
    if (!p || p.resolved) return p;
    if (!p.finding) {
      p.finding = (async () => {
        let hit = await window.geoApp?.findPano({ lat: p.qlat ?? p.lat, lng: p.qlng ?? p.lng }).catch(() => null);
        if (!hit && p.qlat != null) hit = await window.geoApp?.findPano({ lat: p.lat, lng: p.lng }).catch(() => null);
        if (hit) Object.assign(p, { lat: hit.lat, lng: hit.lng, pano: hit.pano });
        p.resolved = true;
        return p;
      })();
    }
    return p.finding;
  }

  function showPano(p, nmpz) {
    $('pano').src = panoUrl(p);
    $('blocker').hidden = !nmpz;
    $('cover').hidden = true;
    $('pano').classList.toggle('crop', !profile.apiKey);
  }

  /* ================================================================ Spielzustand */

  let G = null; // aktuelles Spiel
  let guessMap = null;
  let resultMap = null;
  let timer = null;

  function screen(id) {
    for (const s of document.querySelectorAll('.screen')) s.hidden = s.id !== id;
  }

  const HPM = (m) => m === 'duel' || m === 'team';
  function startGame({ mode = 'classic', mapId = profile.settings.map, seed = Math.floor(Math.random() * 1e9), rounds = 5, time = profile.settings.time, nmpz = profile.settings.nmpz, online = null }) {
    const n = mode === 'streak' ? 60 : HPM(mode) ? 15 : rounds;
    G = { mode, mapId, seed, rounds: n, time, nmpz, online, round: 0, results: [], total: 0, streak: 0, places: pickPlaces(mapId, seed, n), hp: null, guesses: {} };
    if (HPM(mode)) G.hp = { me: 6000, them: 6000 };
    nextRound();
  }

  async function nextRound() {
    clearInterval(timer);
    const p = G.places[G.round];
    if (!p) return finishGame();
    screen('play');
    $('loading-pano').hidden = false;
    const my = G;
    await resolvePlace(p);
    if (G !== my) return;
    $('loading-pano').hidden = true;
    resolvePlace(G.places[G.round + 1]); // nächsten Ort schon vorbereiten
    G.guess = null;
    G.guesses[G.round] = G.guesses[G.round] || {};
    G.roundStart = Date.now();
    G.deadline = G.time ? Date.now() + G.time * 1000 : 0;
    G.deadlineTotal = G.time * 1000;
    screen('play');
    showPano(p, G.nmpz);
    $('hud-map').textContent = G.mode === 'streak' ? t('streak') : mapName(G.mapId);
    $('hud-round').textContent = G.mode === 'streak' ? t('streakNow', { n: G.streak }) : `${t('round')} ${G.round + 1}${HPM(G.mode) ? '' : ` / ${G.rounds}`}`;
    $('hud-score').textContent = HPM(G.mode) ? `${t('hp')} ${G.hp.me} : ${G.hp.them}` : `${t('score')} ${G.total.toLocaleString(lang)}`;
    $('btn-guess').disabled = true;
    $('btn-guess').textContent = t('placePin');
    $('play-note').textContent = '';
    const streakMode = G.mode === 'streak';
    $('guess-box').hidden = streakMode;
    $('country-box').hidden = !streakMode;
    if (streakMode) renderCountries('');
    else {
      if (!guessMap) guessMap = new window.GeoMap($('guess-map'), { onClick: placeGuess });
      guessMap.setPins([]);
      guessMap.setLines([]);
      const def = MAPS.find((m) => m.id === G.mapId);
      if (G.mapId === 'de') guessMap.setView(49.5, 10, 5);
      else if (G.mapId === 'eu') guessMap.setView(50, 12, 3);
      else if (def && def.id !== 'world' && def.id !== 'famous') {
        const pool = PLACES.filter(def.filter);
        guessMap.fit(pool, 20);
      } else guessMap.setView(25, 0, 1);
    }
    tick();
    timer = setInterval(tick, 250);
  }

  const mmss = (ms) => {
    const sec = Math.max(0, Math.ceil(ms / 1000));
    return `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
  };
  function tick() {
    if (!G) return;
    const el = $('hud-time');
    const ring = $('cp-ring');
    if (!G.deadline) {
      // ohne Zeitlimit läuft die Uhr hoch
      $('cp-text').textContent = mmss(Date.now() - G.roundStart);
      ring.style.strokeDashoffset = '0';
      el.classList.remove('low');
      return;
    }
    const left = Math.max(0, G.deadline - Date.now());
    $('cp-text').textContent = mmss(left);
    ring.style.strokeDashoffset = String(100 - (left / Math.max(1, G.deadlineTotal || left)) * 100);
    el.classList.toggle('low', left < 10000);
    if (left <= 0) {
      clearInterval(timer);
      submitGuess(true);
    }
  }

  function placeGuess(ll) {
    if (G.locked) return;
    G.guess = ll;
    guessMap.setPins([{ ...ll, color: '#7552ff' }]);
    $('btn-guess').disabled = false;
    $('btn-guess').textContent = t('guess');
  }

  function submitGuess(timeout = false) {
    if (!G || G.locked) return;
    if (!G.guess && !timeout) return;
    G.locked = true;
    clearInterval(timer);
    const p = G.places[G.round];
    const def = MAPS.find((m) => m.id === G.mapId) || MAPS[0];
    const km = G.guess ? distKm(G.guess, p) : null;
    const score = km == null ? 0 : scoreFor(km, def.size);
    const res = { place: p, guess: G.guess, km, score };
    if (G.online) {
      G.guesses[G.round].me = res;
      Net.send('guess', { round: G.round, lat: G.guess?.lat ?? null, lng: G.guess?.lng ?? null, km, score });
      $('btn-guess').disabled = true;
      $('play-note').textContent = t('waitOthers');
      Net.checkRound();
      return;
    }
    G.results.push(res);
    G.total += score;
    showRoundResult([{ name: profile.name || 'Du', res, color: '#7552ff' }]);
  }

  function showRoundResult(entries, extra = '') {
    G.locked = false;
    const p = G.places[G.round];
    screen('result');
    if (!resultMap) resultMap = new window.GeoMap($('result-map'));
    const pins = [{ lat: p.lat, lng: p.lng, kind: 'target', color: '#16a34a' }];
    const lines = [];
    for (const e of entries) {
      if (!e.res.guess) continue;
      pins.push({ ...e.res.guess, color: e.color, label: entries.length > 1 ? esc(e.name) : '' });
      lines.push({ from: e.res.guess, to: p, color: e.color });
    }
    resultMap.setPins(pins);
    resultMap.setLines(lines);
    requestAnimationFrame(() => resultMap.fit(pins.length > 1 ? pins : [p, { lat: p.lat + 2, lng: p.lng + 2 }], 70, $('result').querySelector('.result-panel').offsetHeight + 30));
    const me = entries[0].res;
    $('result-info').innerHTML = `
      <div class="r-country">${esc(countryName(p.cc))}</div>
      ${entries
        .map(
          (e) => `<div class="r-row"><span class="dot" style="background:${e.color}"></span><b>${esc(e.name)}</b>
        <span>${e.res.km == null ? esc(t('noGuess')) : `${esc(t('away', { d: fmtDist(e.res.km) }))}`}</span>
        <b class="r-pts" data-target="${e.res.score}">0</b></div>
        <div class="r-bar"><i style="--w:${(e.res.score / 5000) * 100}%;background:${e.color}"></i></div>`,
        )
        .join('')}
      ${extra}
      ${me.score === 5000 ? `<div class="r-perfect">${esc(t('perfect'))}</div>` : ''}`;
    // Punkte hochzählen
    document.querySelectorAll('.r-pts').forEach((el) => {
      const target = Number(el.dataset.target);
      const t0 = performance.now();
      const step = (now) => {
        const k = Math.min(1, (now - t0) / 900);
        el.textContent = Math.round(target * (1 - (1 - k) ** 3)).toLocaleString(lang);
        if (k < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
    const last = HPM(G.mode) ? G.hp.me <= 0 || G.hp.them <= 0 : G.round + 1 >= G.rounds;
    $('btn-next').textContent = last ? t('results') : t('next');
    $('btn-next').hidden = Boolean(G.online);
    $('result-total').textContent = HPM(G.mode) ? '' : `${t('total')}: ${G.total.toLocaleString(lang)}`;
  }

  $('btn-guess').onclick = () => submitGuess(false);
  $('btn-next').onclick = () => {
    G.round += 1;
    const over = HPM(G.mode) ? G.hp.me <= 0 || G.hp.them <= 0 : G.round >= G.rounds;
    if (over) finishGame();
    else nextRound();
  };
  $('btn-newplace').onclick = () => {
    // Ersatzort aus demselben Kartenset (falls an der Stelle kein Bild kommt)
    if (!G || G.online) return;
    const extra = pickPlaces(G.mapId, Math.floor(Math.random() * 1e9), 1)[0];
    G.places[G.round] = extra;
    $('loading-pano').hidden = false;
    resolvePlace(extra).then(() => {
      $('loading-pano').hidden = true;
      showPano(extra, G.nmpz);
    });
  };
  $('btn-quit').onclick = () => {
    clearInterval(timer);
    if (G?.online?.ranked && !G.finished) {
      toast(t('leaveLoss'));
      rankedUpdate(false, G.online.ranked.oppRating);
      G.finished = true;
    }
    Net.leave();
    G = null;
    renderMenu();
  };

  /* ---------------------------------------------------------------- Länder-Streak */

  function renderCountries(filter) {
    const set = [...new Set(PLACES.map((p) => p.cc))].map((cc) => ({ cc, name: countryName(cc) })).sort((a, b) => a.name.localeCompare(b.name, lang));
    const f = filter.trim().toLowerCase();
    $('country-list').innerHTML = set
      .filter((c) => !f || c.name.toLowerCase().includes(f))
      .map((c) => `<button data-cc="${c.cc}">${esc(c.name)}</button>`)
      .join('');
  }
  $('country-search').addEventListener('input', (e) => renderCountries(e.target.value));
  $('country-list').addEventListener('click', (e) => {
    const b = e.target.closest('[data-cc]');
    if (!b || !G || G.locked) return;
    G.locked = true;
    clearInterval(timer);
    const p = G.places[G.round];
    const ok = b.dataset.cc === p.cc;
    if (ok) G.streak += 1;
    screen('result');
    if (!resultMap) resultMap = new window.GeoMap($('result-map'));
    resultMap.setPins([{ lat: p.lat, lng: p.lng, kind: 'target', color: ok ? '#16a34a' : '#dc2626' }]);
    resultMap.setLines([]);
    requestAnimationFrame(() => resultMap.setView(p.lat, p.lng, 4));
    $('result-info').innerHTML = `<div class="r-country ${ok ? 'ok' : 'bad'}">${esc(ok ? t('right', { c: countryName(p.cc) }) : t('wrong', { c: countryName(p.cc) }))}</div><div class="r-streak">${esc(t('streakNow', { n: G.streak }))}</div>`;
    $('result-total').textContent = '';
    $('btn-next').hidden = false;
    $('btn-next').textContent = ok ? t('next') : t('results');
    G.locked = false;
    if (!ok) G.rounds = G.round + 1; // Serie endet
  });

  /* ---------------------------------------------------------------- Ende */

  function finishGame() {
    clearInterval(timer);
    if (G?.finishedOnce) return;
    screen('summary');
    const s = profile.stats;
    let head = '';
    if (G.mode === 'streak') {
      s.bestStreak = Math.max(s.bestStreak, G.streak);
      head = `<div class="sum-big">${esc(t('streakEnd', { n: G.streak }))}</div><div class="muted">${esc(t('bestStreak'))}: ${s.bestStreak}</div>`;
    } else if (HPM(G.mode)) {
      const won = G.hp.me > 0 && G.hp.me >= G.hp.them;
      if (won) s.duelsWon += 1;
      else s.duelsLost += 1;
      head = `<div class="sum-big ${won ? 'win' : 'loss'}">${esc(won ? t('youWin') : t('youLose'))}</div><div class="muted">${G.hp.me} : ${G.hp.them}</div>`;
      if (G.online?.ranked && !G.finished) {
        const r = rankedUpdate(won, G.online.ranked.oppRating);
        RankStats.counts = null;
        const a = rankOf(r.before), b = rankOf(r.after);
        const change = a !== b ? `<div class="rank-change ${RANKS.indexOf(b) > RANKS.indexOf(a) ? 'up' : 'down'}">${esc(RANKS.indexOf(b) > RANKS.indexOf(a) ? t('promoted', { r: rankName(b) }) : t('demoted', { r: rankName(b) }))}</div>` : '';
        head += `<div class="rank-result">${badgeSvg(b, 84)}<div><b>${esc(rankName(b))}</b><span class="gr ${r.delta >= 0 ? 'plus' : 'minus'}">${r.delta >= 0 ? '+' : ''}${r.delta} GR</span><span class="muted">${r.before} → ${r.after}</span></div></div>${change}`;
      }
    } else {
      const key = G.mode === 'daily' ? 'daily' : G.mapId;
      s.best[key] = Math.max(s.best[key] || 0, G.total);
      s.totalScore += G.total;
      if (G.mode === 'daily') s.daily[todaySeed()] = G.total;
      head = `<div class="sum-big">${G.total.toLocaleString(lang)}</div><div class="muted">/ ${(G.rounds * 5000).toLocaleString(lang)} · ${esc(t('bestScore'))}: ${(s.best[key] || 0).toLocaleString(lang)}</div>`;
      if (G.online?.board) head += `<div class="board">${G.online.board()}</div>`;
    }
    // Punkte für den Hub-Shop
    const wasRanked = Boolean(G.online?.ranked);
    const pts = earn(
      G.mode === 'streak' ? G.streak * 3
      : HPM(G.mode) ? (G.hp.me > 0 && G.hp.me >= G.hp.them ? (wasRanked ? 25 : 15) : wasRanked ? 5 : 3)
      : G.total / 500 + (G.mode === 'daily' ? 10 : 0),
    );
    if (pts) head += `<div class="earned-pts">+${pts} ◆ ${esc(t('ptsEarned'))}</div>`;
    G.finished = true;
    G.finishedOnce = true;
    s.games += 1;
    s.history = [{ at: Date.now(), mode: G.mode, map: G.mapId, total: G.total, streak: G.streak, won: G.hp ? G.hp.me > 0 : null }, ...s.history].slice(0, 30);
    save();
    $('summary-head').innerHTML = head;
    $('summary-rounds').innerHTML =
      G.mode === 'streak' || HPM(G.mode)
        ? ''
        : G.results.map((r, i) => `<div class="sr-row"><span>${t('round')} ${i + 1}</span><span>${esc(countryName(r.place.cc))}</span><span>${r.km == null ? '–' : fmtDist(r.km)}</span><b>${r.score.toLocaleString(lang)}</b></div>`).join('');
    const sumMap = new window.GeoMap($('summary-map'));
    const pins = [];
    const lines = [];
    G.results.forEach((r) => {
      pins.push({ lat: r.place.lat, lng: r.place.lng, kind: 'target', color: '#16a34a' });
      if (r.guess) {
        pins.push({ ...r.guess, color: '#7552ff' });
        lines.push({ from: r.guess, to: r.place, color: '#7552ff' });
      }
    });
    sumMap.setPins(pins);
    sumMap.setLines(lines);
    requestAnimationFrame(() => (pins.length ? sumMap.fit(pins, 40, $('summary').querySelector('.summary-panel').offsetHeight + 30) : sumMap.setView(25, 0, 1)));
  }
  $('btn-again').onclick = () => {
    if (G?.online) return renderMenu();
    const mode = G?.mode === 'daily' ? 'classic' : G?.mode || 'classic';
    startGame({ mode, mapId: G?.mapId });
  };
  $('btn-menu').onclick = () => {
    if (G?.online?.ranked && !G.finished) {
      toast(t('leaveLoss'));
      rankedUpdate(false, G.online.ranked.oppRating);
      G.finished = true;
    }
    Net.leave();
    renderMenu();
  };

  /* ================================================================ Ranked-Suche */

  const Ranked = {
    mm: null,
    async start() {
      if (!profile.name) return nameModal(() => this.start());
      this.stop();
      const rk = rankOf(profile.ranked.rating);
      const box = $('ranked-box');
      if (box) box.innerHTML = `<div class="mm-search"><div class="mm-radar" style="--rc:${rk.c1}"><i></i><i></i><i></i>${badgeSvg(rk, 46)}</div><div id="rk-text">${esc(t('connecting'))}</div><button class="btn small" data-rk="cancel">${esc(t('cancel'))}</button></div>`;
      const mm = new window.RevNet.Matchmaker({ app: 'geo', bucket: `ranked-${rk.id}`, name: profile.name, info: { rating: profile.ranked.rating, rank: rk.id } });
      this.mm = mm;
      mm.on('tick', (sec, n) => {
        if ($('rk-text')) $('rk-text').textContent = t('searching', { r: rankName(rk), s: sec, n });
      });
      mm.on('match', async (match) => {
        this.mm = null;
        if ($('rk-text')) $('rk-text').textContent = t('found', { name: match.opp.name });
        try {
          await Net.open(match.code, match.host, 'duel', { oppRating: match.opp.info?.rating });
        } catch (error) {
          toast(t('netFail', { e: error.message }));
          renderMenu();
        }
      });
      try {
        await mm.start();
        if ($('rk-text')) $('rk-text').textContent = t('searching', { r: rankName(rk), s: 0, n: 0 });
      } catch (error) {
        this.mm = null;
        toast(t('netFail', { e: error.message }));
        renderMenu();
      }
    },
    stop() {
      this.mm?.stop();
      this.mm = null;
    },
  };

  function nameModal(done) {
    $('modal').innerHTML = `<h2>${esc(t('yourName'))}</h2><div class="field"><input class="input" id="g-name" maxlength="20" value="${esc(profile.name)}" /><span class="hint">${esc(t('needName'))}</span></div><div class="btns"><button class="btn primary" data-n="ok">${esc(t('save'))}</button></div>`;
    $('modal-back').hidden = false;
    $('modal').onclick = (e) => {
      if (!e.target.closest('[data-n]')) return;
      const v = ($('g-name').value || '').trim().slice(0, 20);
      if (v.length < 2) return;
      profile.name = v;
      setHubName(v);
      save();
      closeLobby();
      done?.();
    };
    setTimeout(() => $('g-name')?.focus(), 40);
  }

  /* ================================================================ Online */

  const Net = {
    room: null,
    host: false,
    players: new Map(), // id → { name, color }
    COLORS: ['#e5484d', '#f59e0b', '#0ea5e9', '#22c55e', '#ec4899', '#a855f7'],

    async open(code, host, mode, ranked = null) {
      this.leave();
      this.ranked = Boolean(ranked);
      this.oppRating = ranked?.oppRating;
      this.host = host;
      this.mode = mode;
      this.code = code;
      this.players = new Map();
      const room = new window.RevNet.Room({ app: this.ranked ? 'geo-ranked' : 'geo', code, name: profile.name || 'Spieler' });
      room.on('peer', (p) => {
        this.players.set(p.id, { name: p.name || '?', color: this.COLORS[this.players.size % this.COLORS.length] });
        room.send('chatinfo', { chat: window.GameChat?.mine() });
        this.renderLobby();
        if (this.host && this.mode === 'duel' && this.players.size === 1) this.begin();
      });
      room.on('left', (id) => {
        const pl = this.players.get(id);
        this.players.delete(id);
        if (pl) toast(t('left', { name: pl.name }));
        this.renderLobby();
        if (G?.online?.ranked && !G.finished && this.players.size === 0) {
          toast(t('oppLeftWin'));
          G.hp.them = 0;
          clearInterval(this.countdown);
          return finishGame();
        }
        if (G?.online) this.checkRound();
      });
      room.on('msg', (m) => this.onMsg(m));
      await room.join();
      this.room = room;
    },

    send(type, data = {}) {
      this.room?.send(type, data);
    },

    begin() {
      const setup = this.ranked
        ? { mode: 'duel', mapId: 'world', seed: Math.floor(Math.random() * 1e9), time: 60, nmpz: false, ranked: true, rating: profile.ranked.rating }
        : { mode: this.mode, mapId: profile.settings.map, seed: Math.floor(Math.random() * 1e9), time: HPM(this.mode) ? Math.max(profile.settings.time, 0) : profile.settings.time, nmpz: profile.settings.nmpz };
      if (this.mode === 'team') {
        if (this.players.size !== 3) return toast(t('teamNeed'));
        // Host + erster Mitspieler gegen die anderen zwei (zufällig gemischt)
        const ids = [this.room.id, ...[...this.players.keys()]].sort(() => Math.random() - 0.5);
        setup.teams = Object.fromEntries(ids.map((id, i) => [id, i < 2 ? 'A' : 'B']));
      }
      this.send('setup', setup);
      this.start(setup);
    },

    start(setup) {
      closeLobby();
      this.teams = setup.teams || null;
      Ranked.stop();
      const ranked = this.ranked ? { oppRating: this.host ? this.oppRating : setup.rating ?? this.oppRating } : null;
      if (ranked && !this.host) this.send('rating', { rating: profile.ranked.rating });
      startGame({ ...setup, rounds: 5, online: { board: () => this.board(), ranked } });
    },

    onMsg(m) {
      if (!this.players.has(m.from)) this.players.set(m.from, { name: m.name || '?', color: this.COLORS[this.players.size % this.COLORS.length] });
      if (m.t === 'chatinfo') {
        this.players.get(m.from).chat = m.chat || null;
        return this.renderLobby();
      }
      if (m.t === 'setup' && !this.host) this.start(m);
      if (m.t === 'rating' && G?.online?.ranked) G.online.ranked.oppRating = m.rating;
      if (m.t === 'guess' && G?.online) {
        const g = (G.guesses[m.round] = G.guesses[m.round] || {});
        g[m.from] = { guess: m.lat == null ? null : { lat: m.lat, lng: m.lng }, km: m.km, score: m.score, place: G.places[m.round] };
        // Duell: hat der Gegner zuerst geraten, bleiben dir noch 15 Sekunden
        if (m.round === G.round && !g.me && HPM(G.mode)) {
          const limit = Date.now() + 15000;
          if (!G.deadline || G.deadline > limit) {
            G.deadline = limit;
            G.deadlineTotal = 15000;
          }
          $('play-note').textContent = t('theyGuessed', { name: m.name, s: 15 });
          if (!timer) timer = setInterval(tick, 250);
          clearInterval(timer);
          timer = setInterval(tick, 250);
        }
        this.checkRound();
      }
    },

    checkRound() {
      if (!G?.online) return;
      const g = G.guesses[G.round] || {};
      if (!g.me) return;
      const others = [...this.players.keys()];
      const missing = others.filter((id) => !g[id]);
      if (missing.length) {
        // Wer nicht rechtzeitig rät, bekommt 0 – kurze Gnadenfrist für langsame Verbindungen
        clearTimeout(this.grace);
        const waitUntil = G.deadline ? G.deadline + 3000 : 0;
        if (waitUntil) this.grace = setTimeout(() => {
          for (const id of missing) if (!g[id]) g[id] = { guess: null, km: null, score: 0, place: G.places[G.round] };
          this.checkRound();
        }, Math.max(0, waitUntil - Date.now()));
        return;
      }
      if (g.done) return;
      g.done = true;
      clearTimeout(this.grace);
      this.resolve(g);
    },

    resolve(g) {
      G.results.push(g.me);
      G.total += g.me.score;
      const entries = [{ name: profile.name || 'Du', res: g.me, color: '#7552ff' }, ...[...this.players].map(([id, p]) => ({ name: p.name, res: g[id], color: p.color }))];
      for (const [id] of this.players) {
        const pl = this.players.get(id);
        pl.total = (pl.total || 0) + (g[id]?.score || 0);
      }
      let extra = '';
      if (G.mode === 'team' && this.teams) {
        const mine = this.teams[this.room.id];
        const best = (team) => Math.max(0, ...[...this.players.keys()].filter((id) => this.teams[id] === team).map((id) => g[id]?.score || 0), ...(team === mine ? [g.me.score] : []));
        const a = best(mine), b = best(mine === 'A' ? 'B' : 'A');
        const mult = 1 + Math.max(0, G.round - 3) * 0.5;
        const dmg = Math.round(Math.abs(a - b) * mult);
        if (a > b) G.hp.them = Math.max(0, G.hp.them - dmg);
        else if (b > a) G.hp.me = Math.max(0, G.hp.me - dmg);
        for (const en of entries) {
          const id = en.res === g.me ? this.room.id : [...this.players.keys()].find((k) => g[k] === en.res);
          en.name = `${en.name} · ${t(this.teams[id] === 'A' ? 'teamA' : 'teamB')}`;
        }
        extra = `<div class="hp-wrap"><div class="hp"><span>${esc(t('myTeam'))}</span><div class="hp-bar"><i style="--w:${(G.hp.me / 6000) * 100}%"></i></div><b>${G.hp.me}</b></div>
          <div class="hp them"><span>${esc(t('theirTeam'))}</span><div class="hp-bar"><i style="--w:${(G.hp.them / 6000) * 100}%"></i></div><b>${G.hp.them}</b></div>
          <div class="muted">${esc(t('damage', { d: dmg }))}${mult > 1 ? ` · ${esc(t('multiplier', { m: mult }))}` : ''}</div></div>`;
      } else if (HPM(G.mode)) {
        const [oppId] = [...this.players.keys()];
        const theirs = g[oppId]?.score || 0;
        const mult = 1 + Math.max(0, G.round - 3) * 0.5;
        const dmg = Math.round(Math.abs(g.me.score - theirs) * mult);
        if (g.me.score > theirs) G.hp.them = Math.max(0, G.hp.them - dmg);
        else G.hp.me = Math.max(0, G.hp.me - dmg);
        extra = `<div class="hp-wrap"><div class="hp"><span>${esc(profile.name || 'Du')}</span><div class="hp-bar"><i style="--w:${(G.hp.me / 6000) * 100}%"></i></div><b>${G.hp.me}</b></div>
          <div class="hp them"><span>${esc(this.players.get(oppId)?.name || '?')}</span><div class="hp-bar"><i style="--w:${(G.hp.them / 6000) * 100}%"></i></div><b>${G.hp.them}</b></div>
          <div class="muted">${esc(t('damage', { d: dmg }))}${mult > 1 ? ` · ${esc(t('multiplier', { m: mult }))}` : ''}</div></div>`;
      } else extra = `<div class="board">${this.board()}</div>`;
      showRoundResult(entries, extra);
      // gleiche Wartezeit auf allen Rechnern → nächste Runde startet fast gleichzeitig
      let left = 8;
      $('result-total').textContent = t('nextIn', { s: left });
      clearInterval(this.countdown);
      this.countdown = setInterval(() => {
        left -= 1;
        $('result-total').textContent = t('nextIn', { s: left });
        if (left <= 0) {
          clearInterval(this.countdown);
          G.round += 1;
          const over = HPM(G.mode) ? G.hp.me <= 0 || G.hp.them <= 0 || G.round >= G.places.length : G.round >= G.rounds;
          if (over) finishGame();
          else nextRound();
        }
      }, 1000);
    },

    board() {
      const rows = [{ name: profile.name || 'Du', total: G?.total || 0, color: '#7552ff' }, ...[...this.players.values()].map((p) => ({ name: p.name, total: p.total || 0, color: p.color }))].sort((a, b) => b.total - a.total);
      return rows.map((r, i) => `<div class="b-row"><span>${i + 1}.</span><span class="dot" style="background:${r.color}"></span><b>${esc(r.name)}</b><span>${r.total.toLocaleString(lang)}</span></div>`).join('');
    },

    renderLobby() {
      const el = $('lobby-players');
      if (!el) return;
      el.innerHTML = [`<div class="b-row"><span class="dot" style="background:#7552ff"></span><b>${esc(profile.name || 'Du')}</b></div>`, ...[...this.players.values()].map((p) => `<div class="b-row"><span class="dot" style="background:${p.color}"></span><b>${esc(p.name)}</b><span class="gc">${window.GameChat?.buttons(p.chat, p.name, 'Geo') || ''}</span></div>`)].join('');
      const start = $('lobby-start');
      if (start) start.disabled = !this.host || (this.mode === 'team' ? this.players.size !== 3 : this.players.size < 1);
    },

    leave() {
      clearInterval(this.countdown);
      clearTimeout(this.grace);
      this.room?.leave();
      this.room = null;
      this.players = new Map();
    },
  };

  function closeLobby() {
    $('modal-back').hidden = true;
  }

  function onlineModal(mode) {
    $('modal').innerHTML = `
      <h2>${esc(t(mode === 'duel' ? 'duel' : mode === 'team' ? 'team' : 'party'))}</h2>
      <div class="field"><label>${esc(t('yourName'))}</label><input class="input" id="g-name" maxlength="20" value="${esc(profile.name)}" /></div>
      <div class="field"><button class="btn primary" data-o="create">${esc(t('create'))}</button></div>
      <div class="field"><label>${esc(t('code'))}</label><div class="row"><input class="input code-in" id="g-code" maxlength="6" placeholder="${esc(t('codePh'))}" /><button class="btn" data-o="join">${esc(t('join'))}</button></div></div>
      <div class="hint" id="g-status"></div>
      <div class="btns"><button class="btn ghost" data-o="close">${esc(t('menu'))}</button></div>`;
    $('modal-back').hidden = false;
    $('modal').onclick = async (e) => {
      const o = e.target.closest('[data-o]')?.dataset.o;
      if (o === 'close') {
        Net.leave();
        closeLobby();
      }
      if (o === 'copy') {
        navigator.clipboard?.writeText(Net.code).catch(() => {});
        e.target.textContent = t('copied');
      }
      if (o === 'start') Net.begin();
      if (o === 'create' || o === 'join') {
        profile.name = ($('g-name').value || '').trim().slice(0, 20);
        if (profile.name.length >= 2) setHubName(profile.name);
        save();
        const code = o === 'create' ? window.RevNet.newCode() : ($('g-code').value || '').trim().toUpperCase();
        if (code.length < 4) return;
        $('g-status').textContent = t('connecting');
        try {
          await Net.open(code, o === 'create', mode);
        } catch (error) {
          $('g-status').textContent = t('netFail', { e: error.message });
          return;
        }
        $('modal').innerHTML = `<h2>${esc(t(mode === 'duel' ? 'duel' : mode === 'team' ? 'team' : 'party'))}</h2>
          ${o === 'create' ? `<div class="field room-wait"><span class="hint">${esc(t('shareCode'))}</span><div class="room-code">${esc(code)}</div><button class="btn small" data-o="copy">${esc(t('copy'))}</button></div>` : ''}
          <div class="field"><label>${esc(t('players'))}</label><div id="lobby-players"></div><div class="hint"><span class="spinner"></span> ${esc(t('waiting'))}</div></div>
          <div class="btns"><button class="btn ghost" data-o="close">${esc(t('leave'))}</button>${o === 'create' && (mode === 'party' || mode === 'team') ? `<button class="btn primary" id="lobby-start" data-o="start" disabled>${esc(t('start'))}</button>` : ''}</div>`;
        Net.renderLobby();
      }
    };
  }

  /* ================================================================ Menü */

  /** Ranked-Bereich der Lobby: Spieler, Rang, Fortschritt, Leiter aller Ränge. */
  function rankedHtml() {
    const R = profile.ranked;
    const rk = rankOf(R.rating);
    const i = RANKS.indexOf(rk);
    const next = RANKS[i + 1];
    const base = rk.min || 900;
    const pct = next ? Math.max(0, Math.min(100, Math.round(((R.rating - base) / (next.min - base)) * 100))) : 100;
    const placement = R.games < 5;
    return `<section class="ranked" style="--rc:${rk.c1};--rc2:${rk.c2}">
      <div class="rk-me">
        <div class="rk-badge-big">${badgeSvg(rk, 112)}</div>
        <div class="rk-info">
          <span class="muted">${esc(t('ranked'))}</span>
          <b class="rk-name">${esc(profile.name || t('you'))}</b>
          <div class="rk-tier">${esc(rankName(rk))} · <b>${R.rating} GR</b>${placement ? ` · <span class="rk-place">${esc(t('placement', { i: R.games + 1 }))}</span>` : ''}</div>
          <div class="rk-bar"><i style="width:${pct}%"></i></div>
          <small class="muted">${next ? esc(t('nextRank', { p: next.min - R.rating, r: rankName(next) })) : esc(t('topRank'))} · ${esc(t('record'))} ${R.wins}/${R.losses} · Peak ${R.peak}</small>
        </div>
        <div class="rk-play" id="ranked-box"><button class="btn primary rk-btn" data-rk="play">⚔ ${esc(t('findMatch'))}</button><small class="muted">${esc(t('rankedRules'))}</small></div>
      </div>
      <div class="rk-ladder">${RANKS.map((x, k) => `<div class="rk-step ${x === rk ? 'cur' : ''} ${k < i ? 'past' : ''}" style="animation-delay:${k * 45}ms">${badgeSvg(x, 40)}<span>${esc(rankName(x))}</span><small>${x.min ? `${x.min}+` : '0+'}</small><em class="rk-count">${RankStats.counts ? `${RankStats.counts[x.id] || 0} ${esc(t('playersShort'))}` : '…'}</em></div>`).join('')}</div>
    </section>`;
  }

  /** Wie viele Spieler welchen Rang erreicht haben (weltweit, über den öffentlichen Server). */
  const RankStats = {
    counts: null,
    loading: false,
    async load() {
      if (this.loading || !window.RevNet?.leaderboard) return;
      this.loading = true;
      try {
        if (!profile.uid) {
          profile.uid = Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => b.toString(16).padStart(2, '0')).join('');
          save();
        }
        const R = profile.ranked;
        const me = R.games > 0 && profile.name ? { id: profile.uid, name: profile.name, rating: R.rating, games: R.games } : null;
        const list = await window.RevNet.leaderboard('geo', me);
        if (me && !list.some((x) => x.id === me.id)) list.push(me);
        const counts = {};
        // „erreicht“ = aktueller Rang oder höher (Peak zählt nicht, nur aktuelle GR)
        for (const e of list) {
          const top = RANKS.indexOf(rankOf(e.rating));
          for (let k = 0; k <= top; k += 1) counts[RANKS[k].id] = (counts[RANKS[k].id] || 0) + 1;
        }
        this.counts = counts;
      } catch {
        this.counts = this.counts || null;
      } finally {
        this.loading = false;
      }
      if (!$('menu').hidden) renderMenu();
    },
  };

  function renderMenu() {
    Ranked.stop();
    if (!RankStats.counts && !RankStats.loading) setTimeout(() => RankStats.load(), 50);
    clearInterval(timer);
    screen('menu');
    lang = profile.lang || lang;
    window.GeoMapLang = lang;
    regionNames = new Intl.DisplayNames([lang], { type: 'region' });
    const s = profile.settings;
    const st = profile.stats;
    const dailyScore = st.daily[todaySeed()];
    const avg = st.games ? Math.round(st.totalScore / Math.max(1, st.history.filter((h) => h.mode === 'classic' || h.mode === 'daily' || h.mode === 'party').length || 1)) : 0;
    const menuHtml = `
      <div class="menu-head"><svg class="logo" viewBox="0 0 64 64" aria-hidden="true">
        <defs>
          <radialGradient id="gl-sea" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#5eead4"/><stop offset=".55" stop-color="#0e7490"/><stop offset="1" stop-color="#083344"/></radialGradient>
          <radialGradient id="gl-shine" cx="30%" cy="25%" r="40%"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
          <clipPath id="gl-clip"><circle cx="32" cy="32" r="27"/></clipPath>
        </defs>
        <circle cx="32" cy="32" r="27" fill="url(#gl-sea)"/>
        <g clip-path="url(#gl-clip)"><g class="globe-land" fill="#4ade80">
          ${[0, 120].map((o) => `<g transform="translate(${o} 0)"><path d="M8 18c6-5 14-4 18 1s-1 9-6 10-6 6-11 5-6-11-1-16Z"/><path d="M30 34c5-2 10 1 11 6s-3 12-8 13-6-6-6-10 0-8 3-9Z"/><path d="M44 12c7-2 15 2 17 8s-4 7-9 7-12-2-12-7 1-7 4-8Z"/><path d="M58 30c5 0 9 4 8 8s-5 5-8 3-4-11 0-11Z"/><path d="M76 16c6-4 13-2 16 3s-2 10-7 10-10 1-12-4 0-7 3-9Z"/><path d="M96 36c4-2 9 0 10 5s-2 8-6 8-8-2-8-6 1-6 4-7Z"/></g>`).join('')}
        </g></g>
        <g clip-path="url(#gl-clip)" fill="none" stroke="#fff" stroke-opacity=".18" stroke-width="1"><ellipse cx="32" cy="32" rx="12" ry="27"/><path d="M5 32h54M8 20h48M8 44h48"/></g>
        <circle cx="32" cy="32" r="27" fill="url(#gl-shine)"/>
        <circle cx="32" cy="32" r="27" fill="none" stroke="#99f6e4" stroke-opacity=".5" stroke-width="1.5"/>
      </svg><div><h1>${esc(t('title'))}</h1><span class="muted">${esc(t('sub'))}</span></div>${hubPoints != null ? `<button class="hub-pts" id="hub-pts" title="Shop">◆ ${hubPoints.toLocaleString(lang)}</button>` : ''}</div>
      ${rankedHtml()}
      <div class="modes">
        ${[
          ['classic', '◎', t('classic'), t('classicD')],
          ['daily', '☀', t('daily'), dailyScore != null ? t('dailyDone', { s: dailyScore.toLocaleString(lang) }) : t('dailyD')],
          ['streak', '⚑', t('streak'), t('streakD')],
          ['duel', '⚔', t('duel'), t('duelD')],
          ['team', '⚑⚑', t('team'), t('teamD')],
          ['party', '✦', t('party'), t('partyD')],
          ...(window.GeoQuiz ? window.GeoQuiz.cards() : []),
        ]
          .map(([id, icon, title, desc], i) => `<button class="mode-card ${id === 'daily' && dailyScore != null ? 'done' : ''}" data-mode="${id}" style="animation-delay:${i * 50}ms"><span class="mc-icon">${icon}</span><b>${esc(title)}</b><span>${esc(desc)}</span></button>`)
          .join('')}
      </div>
      <div class="menu-grid two">
        <div class="panel">
          <div class="field"><label>${esc(t('map'))}</label><div class="chips">${MAPS.map((m) => `<button class="chipbtn ${s.map === m.id ? 'on' : ''}" data-map="${m.id}">${esc(mapName(m.id))}</button>`).join('')}</div></div>
          <div class="field"><label>${esc(t('time'))}</label><div class="chips">${[0, 30, 60, 120, 180].map((n) => `<button class="chipbtn ${s.time === n ? 'on' : ''}" data-time="${n}">${esc(n ? t('sec', { n }) : t('noLimit'))}</button>`).join('')}</div></div>
          <div class="field"><label>${esc(t('movement'))}</label><div class="chips"><button class="chipbtn ${!s.nmpz ? 'on' : ''}" data-nmpz="0">${esc(t('move'))}</button><button class="chipbtn ${s.nmpz ? 'on' : ''}" data-nmpz="1">${esc(t('nmpz'))}</button></div></div>
        </div>
        <div class="panel">
          <h3>${esc(t('stats'))}</h3>
          <div class="stat-grid">
            <div class="stat"><span>${esc(t('games'))}</span><b>${st.games}</b></div>
            <div class="stat"><span>${esc(t('bestScore'))}</span><b>${(st.best[s.map] || 0).toLocaleString(lang)}</b></div>
            <div class="stat"><span>${esc(t('bestStreak'))}</span><b>${st.bestStreak}</b></div>
            <div class="stat"><span>${esc(t('duels'))}</span><b>${st.duelsWon}/${st.duelsLost}</b></div>
          </div>
          <h3>${esc(t('history'))}</h3>
          <div class="hist">${st.history.slice(0, 6).map((h) => `<div class="b-row"><span>${new Date(h.at).toLocaleDateString(lang)}</span><b>${esc(TXT[lang][h.mode] || h.mode)}</b><span>${h.mode === 'streak' ? t('streakNow', { n: h.streak }) : h.mode === 'duel' ? (h.won ? '✓' : '✗') : h.total.toLocaleString(lang)}</span></div>`).join('') || '<span class="muted">–</span>'}</div>
        </div>
      </div>`;
    if ($('menu').firstChild && window.RevMorph) window.RevMorph.morph($('menu'), menuHtml);
    else $('menu').innerHTML = menuHtml;
  }

  $('menu').addEventListener('click', (e) => {
    const s = profile.settings;
    const rk = e.target.closest('[data-rk]')?.dataset.rk;
    if (rk === 'play') return Ranked.start();
    if (rk === 'cancel') return renderMenu();
    const mode = e.target.closest('[data-mode]')?.dataset.mode;
    if (mode === 'classic') return startGame({ mode });
    if (mode === 'daily') return startGame({ mode: 'daily', mapId: 'world', seed: todaySeed(), time: 0, nmpz: false });
    if (mode === 'streak') return startGame({ mode: 'streak' });
    if (mode === 'duel' || mode === 'party' || mode === 'team') return onlineModal(mode);
    if (mode === 'quiz') return window.GeoQuiz?.openQuiz();
    if (mode === 'learn') return window.GeoWorld ? window.GeoWorld.openPath() : window.GeoQuiz?.openPath();
    if (mode === 'worldmap') return window.GeoWorld?.openQuiz();
    const m = e.target.closest('[data-map]');
    if (m) s.map = m.dataset.map;
    const tm = e.target.closest('[data-time]');
    if (tm) s.time = Number(tm.dataset.time);
    const nm = e.target.closest('[data-nmpz]');
    if (nm) s.nmpz = nm.dataset.nmpz === '1';
    const lg = e.target.closest('[data-lang]');
    if (lg) {
      profile.lang = lg.dataset.lang;
      lang = profile.lang;
      translateStatic();
    }
    if (e.target.closest('[data-savekey]')) {
      profile.apiKey = ($('api-key').value || '').trim();
      toast(t('save') + ' ✓');
    }
    if (m || tm || nm || lg || e.target.closest('[data-savekey]')) {
      save();
      renderMenu();
    }
  });

  function translateStatic() {
    document.querySelectorAll('[data-t]').forEach((el) => (el.textContent = t(el.dataset.t)));
    document.querySelectorAll('[data-t-ph]').forEach((el) => (el.placeholder = t(el.dataset.tPh)));
  }

  // Schnittstelle für das Länder-Quiz und den Lernpfad (quiz.js)
  window.GeoHost = {
    profile: () => profile,
    save: () => save(),
    earn: (n) => earn(n),
    lang: () => lang,
    countryName: (cc) => countryName(cc),
    toast: (text) => toast(text),
    menu: () => {
      screen('menu');
      renderMenu();
    },
  };

  function toast(text) {
    const el = $('toast');
    el.textContent = text;
    el.hidden = false;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (el.hidden = true), 2600);
  }

  /* ================================================================ Start */

  (async () => {
    const saved = await window.geoApp?.load().catch(() => null);
    if (saved) profile = { ...profile, ...saved, settings: { ...profile.settings, ...(saved.settings || {}) }, stats: { ...profile.stats, ...(saved.stats || {}) } };
    const hp = await HP?.get().catch(() => null);
    if (hp && !hp.name && profile.name) applyHub(await HP.name(profile.name).catch(() => hp));
    else applyHub(hp);
    lang = profile.lang || window.__hubLang || (['de', 'en', 'es'].includes((navigator.language || 'de').slice(0, 2)) ? navigator.language.slice(0, 2) : 'en');
    translateStatic();
    renderMenu();
  })();

  window.addEventListener('hub-lang', (e) => {
    const l = e.detail;
    if (!['de', 'en', 'es'].includes(l) || profile.lang === l) return;
    profile.lang = l;
    lang = l;
    save();
    translateStatic();
    if (!$('menu').hidden) renderMenu();
  });

  window.GeoUI = { state: () => ({ G, profile }), startGame, net: Net, place: (lat, lng) => placeGuess({ lat, lng }), guess: () => submitGuess(false), next: () => $('btn-next').click() };
})();
