'use strict';

/*
 * Weitere Mini-Apps: Autoclicker (Klicks + Tasten nach Zeitplan) und Schutz
 * (Tracker-Weltkarte + Virenscan über den Microsoft Defender).
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

  /* ================================================================ Autoclicker */
  const AC_DEFAULT = { click: true, button: 'left', double: false, intervalMs: 100, jitterMs: 0, count: 0, holdMs: 0, startDelayMs: 0, maxSeconds: 0, pos: null, hotkey: 'F6', keys: [] };
  const ac = { cfg: null, status: { running: false, clicks: 0, presses: 0 }, picking: 0, capture: -1, saveTimer: null, err: '' };
  const acCfg = () => {
    if (!ac.cfg) ac.cfg = { ...AC_DEFAULT, ...(ctx().state()?.settings?.autoclick || {}) };
    if (!Array.isArray(ac.cfg.keys)) ac.cfg.keys = [];
    return ac.cfg;
  };
  const acSave = (now = false) => {
    clearTimeout(ac.saveTimer);
    ac.saveTimer = setTimeout(() => ctx().settings({ autoclick: acCfg() }), now ? 0 : 350);
  };
  const UNITS = [['ms', 1], ['s', 1000], ['min', 60000], ['h', 3600000]];
  const split = (ms) => {
    for (const [u, f] of [...UNITS].reverse()) if (ms >= f && ms % f === 0) return [ms / f, u];
    return [ms, 'ms'];
  };
  const dur = (name, ms, extra = '') => {
    const [v, u] = split(Number(ms) || 0);
    return `<span class="ac-dur"><input class="input short" data-ac-num="${name}" ${extra} value="${v}" inputmode="decimal" /><select class="select" data-ac-unit="${name}">${UNITS.map(([n]) => `<option ${n === u ? 'selected' : ''}>${n}</option>`).join('')}</select></span>`;
  };
  const seg = (name, value, list) => `<div class="seg">${list.map(([v, n]) => `<button class="${String(value) === String(v) ? 'on' : ''}" data-ac-set="${name}" data-v="${esc(v)}">${esc(n)}</button>`).join('')}</div>`;
  const KEY_NAMES = { Space: 'Leertaste', Enter: 'Enter', Escape: 'Esc', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', ShiftLeft: 'Shift', ShiftRight: 'Shift rechts', ControlLeft: 'Strg', ControlRight: 'Strg rechts', AltLeft: 'Alt', AltRight: 'AltGr', Tab: 'Tab', Backspace: 'Rücktaste', Delete: 'Entf' };
  const keyLabel = (code) => KEY_NAMES[code] || String(code).replace(/^Key|^Digit/, '').replace(/^Numpad/, 'Num ');

  function autoclickHtml() {
    const c = acCfg();
    const s = ac.status;
    const cps = c.intervalMs > 0 ? 1000 / c.intervalMs : 0;
    const row = (title, hint, control) => `<div class="list-row"><div class="grow"><strong>${esc(title)}</strong>${hint ? `<small>${esc(hint)}</small>` : ''}</div>${control}</div>`;
    return `<div class="ac-top tool-card ${s.running ? 'running' : ''}">
        <button class="ac-go ${s.running ? 'stop' : ''}" data-ac="toggle">${icon(s.running ? 'stop' : 'play', 26)}<span>${s.running ? 'Stopp' : 'Start'}</span></button>
        <div class="ac-live"><b>${s.running ? 'Läuft …' : 'Bereit'}</b><small>${s.running || s.clicks || s.presses ? `${s.clicks.toLocaleString('de-DE')} Klicks · ${s.presses.toLocaleString('de-DE')} Tastendrücke` : 'Start und Stopp geht auch mit dem Hotkey – in jedem Programm.'}</small>${ac.err ? `<small class="err">${esc(ac.err)}</small>` : ''}</div>
        <div class="ac-hot"><small class="muted">Hotkey</small>${seg('hotkey', c.hotkey, ['F6', 'F7', 'F8', 'F9', 'F10'].map((k) => [k, k]))}</div>
      </div>
      <div class="tool-grid two">
        <div class="tool-card"><div class="tool-row"><span class="tool-label">Mausklicks</span><button class="switch ${c.click ? 'on' : ''}" data-ac="click" style="margin-left:auto"></button></div>
          <div class="panel ac-panel ${c.click ? '' : 'off'}">
            ${row('Maustaste', '', seg('button', c.button, [['left', 'Links'], ['right', 'Rechts'], ['middle', 'Mitte']]))}
            ${row('Art', '', seg('double', c.double, [['false', 'Einfach'], ['true', 'Doppelklick']]))}
            ${row('Abstand', cps >= 1 ? `≈ ${cps >= 10 ? Math.round(cps) : cps.toFixed(1).replace('.', ',')} Klicks pro Sekunde` : '', dur('intervalMs', c.intervalMs))}
            <div class="chip-row">${[[1, '1 ms'], [10, '10 ms'], [50, '50 ms'], [100, '100 ms'], [500, '0,5 s'], [1000, '1 s'], [60000, '1 min']].map(([v, n]) => `<button class="chip ${c.intervalMs === v ? 'on' : ''}" data-ac-set="intervalMs" data-v="${v}">${n}</button>`).join('')}</div>
            ${row('Zufällige Abweichung', 'Macht die Klicks unregelmäßig (± dieser Wert).', dur('jitterMs', c.jitterMs))}
            ${row('Gedrückt halten', '0 = normaler Klick.', dur('holdMs', c.holdMs))}
            ${row('Anzahl', '0 = endlos, bis du stoppst.', `<input class="input short" data-ac-num="count" data-raw="1" value="${c.count}" inputmode="numeric" />`)}
            ${row('Position', c.pos ? `Fest bei ${c.pos.x} × ${c.pos.y}` : 'Dort, wo der Mauszeiger gerade ist.', `<button class="btn small" data-ac="pick">${ac.picking ? `Zeig hin … ${ac.picking}` : 'Position wählen'}</button>${c.pos ? '<button class="btn small ghost" data-ac="nopos">Zeiger folgen</button>' : ''}`)}
          </div></div>
        <div class="tool-card"><div class="tool-row"><span class="tool-label">Tasten nach Zeit</span><button class="btn small" data-ac="addkey" style="margin-left:auto">${icon('plus', 14)} Taste</button></div>
          ${c.keys.length ? `<div class="ac-keys">${c.keys
            .map((k, i) => `<div class="ac-key ${k.on === false ? 'off' : ''}">
              <button class="ac-cap ${ac.capture === i ? 'wait' : ''}" data-ac-cap="${i}" title="Klicken und Taste drücken">${ac.capture === i ? 'Taste drücken …' : esc(k.label || keyLabel(k.code) || 'Taste wählen')}</button>
              <label>alle ${dur(`keys.${i}.everyMs`, k.everyMs)}</label>
              ${k.at ? '' : `<label>erstes Mal nach ${dur(`keys.${i}.firstMs`, k.firstMs)}</label>`}
              <label class="ac-at">um <input class="input" type="time" step="1" data-ac-time="keys.${i}.at" value="${esc(k.at || '')}" />${k.at ? `<button class="ac-x" data-ac-clear="keys.${i}.at" title="Uhrzeit entfernen">×</button>` : ''}</label>
              <label>halten ${dur(`keys.${i}.holdMs`, k.holdMs)}</label>
              <button class="switch ${k.on === false ? '' : 'on'}" data-ac-keyon="${i}"></button><button class="btn small ghost" data-ac-keydel="${i}">✕</button></div>`)
            .join('')}</div>
            <small class="muted">„alle 0 ms“ = die Taste wird nur ein einziges Mal gedrückt. Mit „um“ drückt der Autoclicker die Taste zu einer festen Uhrzeit (heute, sonst morgen).</small>`
            : '<p class="muted">Leg fest, welche Taste wann gedrückt wird – z. B. „E alle 30 s“ oder „F5 einmal nach 10 min“. Beliebig viele Tasten gleichzeitig.</p>'}
          <div class="panel ac-panel">
            ${row('Startzeit', c.startAt ? `Beginnt um ${c.startAt} Uhr (heute, sonst morgen).` : 'Optional: zu einer festen Uhrzeit loslegen.', `<input class="input ac-time" type="time" step="1" data-ac-time="startAt" value="${esc(c.startAt || '')}" />${c.startAt ? '<button class="ac-x" data-ac-clear="startAt">×</button>' : ''}`)}
            ${c.startAt ? '' : row('Start-Verzögerung', 'Zeit, um ins Spiel zu wechseln.', dur('startDelayMs', c.startDelayMs))}
            ${row('Automatisch stoppen nach', '0 = läuft, bis du stoppst.', `<input class="input short" data-ac-num="maxSeconds" data-raw="1" value="${c.maxSeconds}" inputmode="numeric" /><span class="muted">s</span>`)}
          </div></div>
      </div>`;
  }

  function acSet(path, value) {
    const c = acCfg();
    const parts = path.split('.');
    let o = c;
    for (let i = 0; i < parts.length - 1; i += 1) o = o[parts[i]];
    o[parts[parts.length - 1]] = value;
    acSave();
  }
  const acGet = (path) => path.split('.').reduce((o, k) => o?.[k], acCfg());

  window.hub.onAutoclick?.((s) => {
    const was = ac.status.running;
    ac.status = s;
    if (ctx().state()?.active === 'tool-autoclick') ctx().render();
    else if (was !== s.running) ctx().toast(s.running ? `Autoclicker läuft – ${s.hotkey || 'Hotkey'} stoppt ihn.` : 'Autoclicker gestoppt.');
  });
  window.hub.autoclick?.status().then((s) => (ac.status = s)).catch(() => {});

  document.addEventListener('change', (e) => {
    const t = e.target;
    if (t.dataset?.acTime) {
      acSet(t.dataset.acTime, t.value || '');
      return ctx().render();
    }
    const name = t.dataset?.acNum || t.dataset?.acUnit;
    if (!name) return;
    const wrap = t.closest('.ac-dur');
    if (!wrap) {
      acSet(name, Math.max(0, Math.round(parseFloat(String(t.value).replace(',', '.')) || 0)));
    } else {
      const v = parseFloat(String(wrap.querySelector('input').value).replace(',', '.')) || 0;
      const f = UNITS.find(([u]) => u === wrap.querySelector('select').value)?.[1] || 1;
      acSet(name, Math.max(name === 'intervalMs' ? 1 : 0, Math.round(v * f)));
    }
    ctx().render();
  });
  document.addEventListener('keydown', (e) => {
    if (ac.capture < 0 || ctx().state()?.active !== 'tool-autoclick') return;
    e.preventDefault();
    e.stopPropagation();
    const k = acCfg().keys[ac.capture];
    if (k && e.code !== 'Escape') {
      k.code = e.code;
      k.label = keyLabel(e.code);
      acSave();
    }
    ac.capture = -1;
    ctx().render();
  }, true);
  document.addEventListener('click', async (e) => {
    if (ctx().state()?.active !== 'tool-autoclick') return;
    const set = e.target.closest?.('[data-ac-set]');
    if (set) {
      const raw = set.dataset.v;
      acSet(set.dataset.acSet, raw === 'true' ? true : raw === 'false' ? false : /^\d+$/.test(raw) ? Number(raw) : raw);
      return ctx().render();
    }
    const clr = e.target.closest?.('[data-ac-clear]');
    if (clr) {
      acSet(clr.dataset.acClear, '');
      return ctx().render();
    }
    const cap = e.target.closest?.('[data-ac-cap]');
    if (cap) {
      ac.capture = Number(cap.dataset.acCap);
      return ctx().render();
    }
    const on = e.target.closest?.('[data-ac-keyon]');
    if (on) {
      const k = acCfg().keys[Number(on.dataset.acKeyon)];
      k.on = k.on === false;
      acSave();
      return ctx().render();
    }
    const del = e.target.closest?.('[data-ac-keydel]');
    if (del) {
      acCfg().keys.splice(Number(del.dataset.acKeydel), 1);
      acSave();
      return ctx().render();
    }
    const a = e.target.closest?.('[data-ac]')?.dataset.ac;
    if (!a) return;
    const c = acCfg();
    if (a === 'click') c.click = !c.click;
    if (a === 'nopos') c.pos = null;
    if (a === 'addkey') {
      if (c.keys.length >= 12) return ctx().toast('Höchstens 12 Tasten.', 'error');
      c.keys.push({ code: '', label: '', everyMs: 1000, holdMs: 40, firstMs: 0, on: true });
      ac.capture = c.keys.length - 1;
    }
    if (a === 'pick') {
      if (ac.picking) return;
      ac.picking = 3;
      ctx().render();
      const tick = setInterval(() => {
        ac.picking -= 1;
        if (ac.picking <= 0) clearInterval(tick);
        ctx().render();
      }, 1000);
      const p = await window.hub.autoclick.pick(3000).catch(() => null);
      clearInterval(tick);
      ac.picking = 0;
      if (p) c.pos = p;
    }
    if (a === 'toggle') {
      ac.err = '';
      clearTimeout(ac.saveTimer);
      await ctx().settings({ autoclick: c });
      try {
        ac.status = ac.status.running ? await window.hub.autoclick.stop() : await window.hub.autoclick.start();
      } catch (error) {
        ac.err = errText(error);
      }
      return ctx().render();
    }
    acSave();
    ctx().render();
  });

  T.register('tool-autoclick', { nav: 'Autoclicker', title: 'Autoclicker', sub: 'Klicks und Tasten automatisch', icon: 'pointer', tint: 'linear-gradient(135deg,#f472b6,#be185d)', desc: 'Klickt automatisch in jedem Abstand und drückt Tasten nach deinem Zeitplan – Start und Stopp per Hotkey.' }, autoclickHtml);

  /* ================================================================ Schutz */
  // Grobe Umrisse der Kontinente (Länge, Breite) – daraus entsteht die Punktkarte.
  const LAND = [
    [[-168, 65], [-156, 71], [-128, 70], [-110, 73], [-85, 73], [-78, 62], [-64, 60], [-56, 52], [-66, 45], [-70, 42], [-76, 35], [-81, 31], [-80, 25], [-83, 29], [-90, 29], [-97, 26], [-97, 19], [-88, 16], [-83, 9], [-78, 8], [-86, 12], [-96, 16], [-105, 20], [-110, 24], [-114, 31], [-124, 40], [-124, 48], [-135, 58], [-152, 58], [-165, 55], [-166, 62]],
    [[-55, 60], [-43, 60], [-22, 70], [-20, 80], [-40, 83], [-60, 82], [-70, 77], [-55, 70]],
    [[-78, 8], [-72, 12], [-62, 10], [-52, 5], [-50, 0], [-36, -6], [-39, -15], [-48, -26], [-57, -37], [-65, -42], [-68, -54], [-74, -50], [-72, -38], [-70, -20], [-76, -14], [-81, -5], [-79, 1]],
    [[-9, 37], [-9, 43], [-1, 44], [-4, 48], [2, 51], [8, 54], [8, 57], [11, 56], [5, 60], [6, 63], [14, 68], [25, 71], [31, 70], [41, 67], [40, 64], [60, 68], [60, 55], [50, 46], [40, 47], [36, 45], [30, 45], [28, 41], [23, 37], [20, 40], [15, 38], [12, 44], [7, 44], [3, 42], [-1, 37]],
    [[-6, 50], [1, 51], [0, 54], [-2, 58], [-6, 58], [-5, 54]],
    [[-24, 64], [-14, 64], [-14, 66], [-22, 66]],
    [[-17, 15], [-16, 21], [-10, 29], [-6, 35], [10, 37], [11, 33], [20, 31], [32, 31], [35, 24], [38, 18], [43, 12], [51, 12], [48, 5], [41, -2], [39, -10], [40, -16], [35, -24], [32, -29], [26, -34], [19, -34], [15, -27], [12, -17], [13, -8], [9, -1], [9, 4], [4, 6], [-8, 4], [-13, 8]],
    [[44, -25], [47, -25], [50, -15], [49, -12], [44, -16]],
    [[35, 28], [43, 13], [52, 16], [59, 22], [56, 26], [50, 30], [47, 30], [39, 32]],
    [[40, 47], [50, 46], [60, 55], [60, 68], [73, 72], [105, 77], [140, 73], [160, 70], [180, 68], [178, 62], [163, 60], [157, 51], [143, 54], [135, 44], [129, 41], [126, 35], [122, 39], [118, 38], [122, 31], [120, 25], [110, 20], [108, 12], [104, 9], [100, 13], [99, 8], [103, 2], [98, 8], [97, 17], [92, 21], [88, 22], [80, 15], [77, 8], [73, 17], [70, 21], [66, 25], [57, 26], [51, 28], [48, 30], [44, 38], [36, 37], [28, 41], [36, 45]],
    [[130, 32], [136, 34], [141, 38], [142, 44], [145, 44], [141, 41], [139, 36], [133, 34]],
    [[95, 5], [104, -5], [115, -8], [120, -9], [118, 2], [109, 2], [104, 1]],
    [[131, -1], [141, -3], [150, -6], [147, -10], [141, -9], [134, -4]],
    [[120, 18], [124, 13], [126, 7], [122, 7]],
    [[114, -22], [122, -17], [130, -12], [136, -12], [142, -11], [146, -19], [153, -26], [151, -34], [146, -39], [140, -38], [135, -35], [129, -32], [124, -34], [116, -35], [113, -26]],
    [[166, -46], [172, -41], [178, -38], [175, -41], [170, -46]],
  ];
  const inside = (x, y, poly) => {
    let hit = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const [xi, yi] = poly[i], [xj, yj] = poly[j];
      if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) hit = !hit;
    }
    return hit;
  };
  const MW = 1000, MH = 470;
  const px = (lon) => ((lon + 180) / 360) * MW;
  const py = (lat) => ((84 - lat) / 142) * MH;
  let landDots = '';
  function landSvg() {
    if (landDots) return landDots;
    const out = [];
    for (let lat = 82; lat >= -56; lat -= 2.4)
      for (let lon = -178; lon <= 180; lon += 2.4) if (LAND.some((p) => inside(lon, lat, p))) out.push(`<circle cx="${px(lon).toFixed(1)}" cy="${py(lat).toFixed(1)}" r="1.9"/>`);
    landDots = out.join('');
    return landDots;
  }

  const sh = { data: null, def: null, busy: false, defBusy: false, err: '', loaded: false, sel: '', updating: false };
  const COL = { tracker: '#f87171', platform: '#fbbf24', normal: '#60a5fa' };
  async function shLoad() {
    if (sh.busy) return;
    sh.busy = true;
    sh.err = '';
    ctx().render();
    try {
      sh.data = await window.hub.shield.trackers();
    } catch (error) {
      sh.err = errText(error);
    }
    sh.busy = false;
    if (ctx().state()?.active === 'tool-shield') ctx().render();
  }
  async function shDefender() {
    if (sh.defBusy) return;
    sh.defBusy = true;
    try {
      sh.def = await window.hub.shield.defender();
    } catch {
      sh.def = { ok: false };
    }
    sh.defBusy = false;
    if (ctx().state()?.active === 'tool-shield') ctx().render();
    if (sh.def?.scanning) setTimeout(shDefender, 6000);
  }
  const ago = (iso) => {
    if (!iso) return 'noch nie';
    const d = (Date.now() - new Date(iso).getTime()) / 1000;
    if (!Number.isFinite(d)) return 'unbekannt';
    return d < 3600 ? `vor ${Math.max(1, Math.round(d / 60))} min` : d < 86400 ? `vor ${Math.round(d / 3600)} Std.` : `vor ${Math.round(d / 86400)} Tag(en)`;
  };

  function shieldHtml() {
    if (!sh.loaded) {
      sh.loaded = true;
      window.hub.shield.last().then((l) => {
        if (l) sh.data = l;
        shLoad();
      }).catch(() => shLoad());
      shDefender();
    }
    const cfg = { watch: true, locate: true, ...(ctx().state()?.settings?.shield || {}) };
    const d = sh.data, def = sh.def;
    const links = (d?.links || []).filter((l) => l.lat != null);
    const home = ctx().state()?.settings?.weatherCity;
    const order = { normal: 0, platform: 1, tracker: 2 };
    const lines = home?.lat ? links.filter((l) => l.level !== 'normal').map((l) => {
      const x1 = px(home.lon), y1 = py(home.lat), x2 = px(l.lon), y2 = py(l.lat);
      return `<path d="M${x1.toFixed(1)} ${y1.toFixed(1)} Q${((x1 + x2) / 2).toFixed(1)} ${(Math.min(y1, y2) - Math.abs(x2 - x1) * 0.18).toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" class="sh-line" stroke="${COL[l.level]}"/>`;
    }).join('') : '';
    const dots = [...links].sort((a, b) => order[a.level] - order[b.level]).map((l) => `<g class="sh-dot ${l.level} ${sh.sel === l.ip ? 'sel' : ''}" data-sh-ip="${esc(l.ip)}" transform="translate(${px(l.lon).toFixed(1)} ${py(l.lat).toFixed(1)})"><circle r="11" class="halo" fill="${COL[l.level]}"/><circle r="4.2" fill="${COL[l.level]}"/><title>${esc(`${l.company || l.org || l.ip} · ${[l.city, l.country].filter(Boolean).join(', ')} · ${l.apps.join(', ')}`)}</title></g>`).join('');
    const trackers = d?.items || [];
    const sure = trackers.filter((x) => x.sure);
    const sel = sh.sel ? (d?.links || []).find((l) => l.ip === sh.sel) : null;
    const state = !def ? ['Wird geprüft …', '#9b99ad'] : !def.ok ? ['Microsoft Defender nicht gefunden', '#fbbf24'] : def.av && def.rt ? ['Geschützt', '#4ade80'] : ['Echtzeitschutz ist aus', '#f87171'];
    const countries = new Set(links.map((l) => l.country).filter(Boolean));
    return `<div class="sh-stats">
        <div class="tool-card sh-stat" style="--c:${state[1]}">${icon('shield', 22)}<div><b>${esc(state[0])}</b><small>Virenschutz</small></div></div>
        <div class="tool-card sh-stat" style="--c:${sure.length ? '#f87171' : '#4ade80'}">${icon('eye', 22)}<div><b>${d ? sure.length : '–'}</b><small>Tracker aktiv</small></div></div>
        <div class="tool-card sh-stat" style="--c:#60a5fa">${icon('globe', 22)}<div><b>${d ? countries.size : '–'}</b><small>Länder verbunden</small></div></div>
        <div class="tool-card sh-stat" style="--c:#b39dff">${icon('route', 22)}<div><b>${d ? d.connections : '–'}</b><small>offene Verbindungen</small></div></div>
      </div>
      <div class="tool-card"><div class="tool-row"><span class="tool-label">Wohin dein PC gerade Daten schickt</span><small class="muted" style="margin-left:auto">${d ? `Stand ${new Date(d.at).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}` : ''}</small><button class="btn small" data-sh="scan" ${sh.busy ? 'disabled' : ''}>${sh.busy ? 'Suche …' : 'Neu suchen'}</button></div>
        <div class="sh-map"><svg viewBox="0 0 ${MW} ${MH}" preserveAspectRatio="xMidYMid meet"><g class="sh-land">${landSvg()}</g>${lines}${home?.lat ? `<g transform="translate(${px(home.lon).toFixed(1)} ${py(home.lat).toFixed(1)})"><circle r="6" fill="#fff"/><circle r="12" fill="none" stroke="#fff" stroke-opacity=".5"/></g>` : ''}${dots}</svg>
          ${sel ? `<div class="sh-pop"><b>${esc(sel.company || sel.org || sel.ip)}</b><span>${esc([sel.city, sel.country].filter(Boolean).join(', ') || 'Ort unbekannt')}</span><small>${esc(sel.apps.join(', ') || 'Programm unbekannt')} · ${esc(sel.ip)}</small></div>` : ''}
          ${!d && sh.busy ? '<div class="sh-wait">Verbindungen werden gelesen …</div>' : ''}</div>
        <div class="sh-legend"><span style="--c:${COL.tracker}">Tracker</span><span style="--c:${COL.platform}">Große Plattform (Tracking möglich)</span><span style="--c:${COL.normal}">Normale Verbindung</span>${home?.lat ? '<span style="--c:#fff">Du</span>' : '<small class="muted">Tipp: Speichere im Wetter deinen Ort – dann zeigt die Karte Linien von dir aus.</small>'}</div>
        ${sh.err ? `<p class="err">${esc(sh.err)}</p>` : ''}</div>
      <div class="tool-grid two">
        <div class="tool-card"><div class="tool-label">Gefundene Tracker</div>
          ${trackers.length ? `<div class="sh-list">${trackers.map((x) => `<div class="sh-item ${x.sure ? 'sure' : ''}"><i></i><div><b>${esc(x.company)} <em>${esc(x.kind)}</em></b><small>${x.sure ? '' : 'möglich · '}${esc(x.apps.join(', ') || 'Programm unbekannt')}${x.places[0] ? ` → ${esc([x.places[0].city, x.places[0].country].filter(Boolean).join(', '))}` : ''}</small></div></div>`).join('')}</div>` : `<p class="muted">${d ? 'Gerade sendet kein Programm an einen bekannten Tracker.' : 'Noch nicht gesucht.'}</p>`}
          <div class="list-row"><div class="grow"><strong>Im Hintergrund wachen</strong><small>Prüft alle paar Minuten und meldet neue Tracker in der Island.</small></div><button class="switch ${cfg.watch ? 'on' : ''}" data-sh-set="watch"></button></div>
          <div class="list-row"><div class="grow"><strong>Server orten</strong><small>Für die Karte wird die Adresse des fremden Servers bei ipwho.is nachgeschlagen.</small></div><button class="switch ${cfg.locate ? 'on' : ''}" data-sh-set="locate"></button></div></div>
        <div class="tool-card"><div class="tool-label">Virenschutz (Microsoft Defender)</div>
          ${def?.ok ? `<div class="kv sh-kv"><span>Echtzeitschutz</span><b style="color:${def.rt ? '#4ade80' : '#f87171'}">${def.rt ? 'An' : 'Aus'}</b><span>Virendefinitionen</span><b>${esc(ago(def.sig))}</b><span>Letzter Schnell-Scan</span><b>${esc(ago(def.quick))}</b><span>Manipulationsschutz</span><b>${def.tamper ? 'An' : 'Aus'}</b></div>` : `<p class="muted">${def ? 'Der Microsoft Defender antwortet nicht – vielleicht ist ein anderes Virenprogramm aktiv.' : 'Status wird gelesen …'}</p>`}
          ${def?.scanning ? `<div class="sh-scan"><i></i>${def.scanning.kind === 'path' ? 'Auswahl wird geprüft …' : 'Schnell-Scan läuft …'} Du bekommst eine Meldung, wenn er fertig ist.</div>` : ''}
          <div class="tool-row" style="flex-wrap:wrap"><button class="btn primary" data-sh="quick" ${def?.scanning || !def?.ok ? 'disabled' : ''}>Schnell-Scan</button><button class="btn" data-sh="file" ${def?.scanning || !def?.ok ? 'disabled' : ''}>Datei prüfen</button><button class="btn" data-sh="folder" ${def?.scanning || !def?.ok ? 'disabled' : ''}>Ordner prüfen</button><button class="btn ghost" data-sh="update" ${sh.updating || !def?.ok ? 'disabled' : ''}>${sh.updating ? 'Aktualisiere …' : 'Definitionen aktualisieren'}</button></div>
          ${def?.threats?.length ? `<div class="tool-label">Letzte Funde</div><div class="sh-list">${def.threats.map((t) => `<div class="sh-item sure"><i></i><div><b>${esc(t.name || 'Unbekannte Bedrohung')}</b><small>${esc(ago(t.at))}${t.ok ? ' · entfernt' : ''}${t.file ? ` · ${esc(String(t.file).replace(/^file:_?/, '').slice(0, 80))}` : ''}</small></div></div>`).join('')}</div>` : def?.ok ? '<p class="muted">Keine Funde in letzter Zeit.</p>' : ''}</div>
      </div>`;
  }

  document.addEventListener('click', async (e) => {
    if (ctx().state()?.active !== 'tool-shield') return;
    const dot = e.target.closest?.('[data-sh-ip]');
    if (dot) {
      sh.sel = sh.sel === dot.dataset.shIp ? '' : dot.dataset.shIp;
      return ctx().render();
    }
    const set = e.target.closest?.('[data-sh-set]')?.dataset.shSet;
    if (set) {
      const cfg = { watch: true, locate: true, ...(ctx().state()?.settings?.shield || {}) };
      return ctx().settings({ shield: { ...cfg, [set]: !cfg[set] } });
    }
    const a = e.target.closest?.('[data-sh]')?.dataset.sh;
    if (!a) return;
    if (a === 'scan') return shLoad();
    if (a === 'update') {
      sh.updating = true;
      ctx().render();
      const ok = await window.hub.shield.update().catch(() => false);
      sh.updating = false;
      ctx().toast(ok ? 'Virendefinitionen sind aktuell.' : 'Aktualisieren hat nicht geklappt.', ok ? '' : 'error');
      return shDefender();
    }
    try {
      const r = await window.hub.shield.scan(a);
      if (r) ctx().toast('Scan gestartet – du bekommst eine Meldung, wenn er fertig ist.');
    } catch (error) {
      ctx().toast(errText(error), 'error');
    }
    shDefender();
  });

  T.register('tool-shield', { nav: 'Schutz', title: 'Schutz', sub: 'Tracker-Karte & Virenscan', icon: 'shield', tint: 'linear-gradient(135deg,#34d399,#047857)', desc: 'Zeigt auf einer Weltkarte, wohin deine Programme Daten schicken, meldet Tracker und prüft deinen PC auf Viren.' }, shieldHtml);

  /* ================================================================ Fußball */
  const fb = { data: null, q: '', hits: null, busy: false, searchT: null };
  async function fbLoad() {
    try {
      fb.data = await window.hub.football.overview();
    } catch {
      fb.data = { teams: [], rows: [], notify: true, island: true };
    }
    if (ctx().state()?.active === 'tool-football') ctx().render();
  }
  const fbTime = (t) => new Date(t).toLocaleString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const fbLogo = (u, s = 30) => (u ? `<img src="${esc(u)}" alt="" width="${s}" height="${s}" style="object-fit:contain" />` : `<span style="display:inline-block;width:${s}px"></span>`);
  function fbMatch(e, live) {
    if (!e) return '<small class="muted">–</small>';
    const [a, b] = [e.teams.find((x) => x.home) || e.teams[0], e.teams.find((x) => !x.home) || e.teams[1]];
    const sc = live?.score;
    const mid = sc ? `<b class="fb-score live">${sc.home.score}:${sc.away.score}</b>` : e.state === 'post' ? `<b class="fb-score">${esc(a?.score ?? '')}:${esc(b?.score ?? '')}</b>` : `<b class="fb-score vs">${new Date(e.date).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}</b>`;
    return `<div class="fb-match"><span class="fb-side">${esc(a?.name || '')} ${fbLogo(a?.logo, 22)}</span>${mid}<span class="fb-side r">${fbLogo(b?.logo, 22)} ${esc(b?.name || '')}</span></div><small class="muted">${sc ? `Live · ${esc(sc.clock || sc.detail)}` : e.state === 'post' ? 'Ergebnis' : esc(fbTime(e.date))}${e.league ? ` · ${esc(e.league)}` : ''}</small>`;
  }
  function footballHtml() {
    if (!fb.data) {
      fbLoad();
      return '<p class="muted tool-note">Spiele werden geladen …</p>';
    }
    const d = fb.data;
    const picked = new Set(d.teams.map((t) => t.id));
    const hits = fb.hits
      ? fb.hits.length
        ? `<div class="fb-hits">${fb.hits.map((t) => `<button class="fb-hit ${picked.has(t.id) ? 'on' : ''}" data-fb-pick="${esc(t.id)}">${fbLogo(t.logo, 26)}<span><b>${esc(t.label)}</b><small>${esc(t.group)}</small></span>${picked.has(t.id) ? icon('check', 16) : icon('plus', 16)}</button>`).join('')}</div>`
        : '<p class="muted">Nichts gefunden.</p>'
      : '';
    return `<div class="tool-grid two">
      <div class="tool-card"><div class="tool-label">Länder und Clubs folgen</div>
        <input class="input" data-fb="q" value="${esc(fb.q)}" placeholder="z. B. Schweiz, FC Basel, Bayern, Real Madrid …" />
        ${fb.busy ? '<p class="muted">Suche … (beim ersten Mal werden alle Ligen geladen)</p>' : hits}
        <div class="list-row"><div class="grow"><strong>Meldungen in der Island</strong><small>Kurz vor Anpfiff, Anpfiff, jedes Tor, Halbzeit und Abpfiff.</small></div><button class="switch ${d.notify ? 'on' : ''}" data-fb-opt="notify"></button></div>
        <div class="list-row"><div class="grow"><strong>Live-Stand in der Island</strong><small>Solange ein Spiel läuft, steht der Spielstand in der Island.</small></div><button class="switch ${d.island ? 'on' : ''}" data-fb-opt="island"></button></div>
      </div>
      <div class="tool-card"><div class="tool-label">Deine Teams</div>
        ${d.rows.length ? d.rows.map((r) => `<div class="fb-team"><div class="fb-head">${fbLogo(r.team.logo, 30)}<b>${esc(r.team.name)}</b><button class="btn small ghost" data-fb-del="${esc(r.team.id)}">Entfernen</button></div>
          ${r.live ? `<div class="fb-slot live"><em>LIVE</em>${fbMatch(r.live, r.live)}</div>` : ''}
          ${r.next ? `<div class="fb-slot"><em>Nächstes Spiel</em>${fbMatch(r.next)}</div>` : ''}
          ${r.last && !r.live ? `<div class="fb-slot"><em>Letztes Spiel</em>${fbMatch(r.last)}</div>` : ''}</div>`).join('') : '<p class="muted">Noch keine Teams. Suche links nach deinem Land oder Club.</p>'}
      </div></div>`;
  }
  document.addEventListener('input', (e) => {
    if (e.target.dataset?.fb !== 'q') return;
    fb.q = e.target.value;
    clearTimeout(fb.searchT);
    fb.searchT = setTimeout(async () => {
      if (fb.q.trim().length < 2) {
        fb.hits = null;
        return ctx().render();
      }
      fb.busy = !fb.hits;
      ctx().render();
      try {
        fb.hits = await window.hub.football.search(fb.q);
      } catch {
        fb.hits = [];
      }
      fb.busy = false;
      ctx().render();
    }, 260);
  });
  document.addEventListener('click', async (e) => {
    if (ctx().state()?.active !== 'tool-football') return;
    const pick = e.target.closest?.('[data-fb-pick]')?.dataset.fbPick;
    const del = e.target.closest?.('[data-fb-del]')?.dataset.fbDel;
    const opt = e.target.closest?.('[data-fb-opt]')?.dataset.fbOpt;
    if (!pick && !del && !opt) return;
    let teams = [...(fb.data?.teams || [])];
    if (pick) {
      const hit = fb.hits?.find((t) => t.id === pick);
      teams = teams.some((t) => t.id === pick) ? teams.filter((t) => t.id !== pick) : [...teams, hit];
    }
    if (del) teams = teams.filter((t) => t.id !== del);
    try {
      fb.data = opt ? await window.hub.football.options({ [opt]: !fb.data[opt] }) : await window.hub.football.teams(teams);
    } catch (error) {
      ctx().toast(errText(error), 'error');
    }
    ctx().render();
  });
  setInterval(() => {
    if (ctx().state()?.active === 'tool-football') fbLoad();
  }, 30000);
  T.register('tool-football', { nav: 'Fußball', title: 'Fußball', sub: 'Live-Spiele in der Island', icon: 'globe', tint: 'linear-gradient(135deg,#4ade80,#15803d)', desc: 'Folge deinen Ländern und Clubs – Anpfiff, Tore und Ergebnisse kommen in die Dynamic Island.' }, footballHtml);
})();
