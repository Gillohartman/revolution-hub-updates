'use strict';

/*
 * 2.45 Size It Up: Wie groß ist das? Ein Referenz-Objekt mit bekannter Größe steht daneben,
 * das gesuchte Objekt ist nur als Silhouette zu sehen (Name steht darunter). Mit dem Regler
 * die Größe schätzen – je näher, desto mehr Punkte. 10 Runden, Bestwert im Konto.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-sizeup';
  // [Emoji, Name, Größe in Metern, was gemessen wird]
  const ITEMS = [
    ['🦠', 'Bakterium (E. coli)', 0.000002, 'Länge'],
    ['🐜', 'Ameise', 0.005, 'Länge'],
    ['🐝', 'Honigbiene', 0.015, 'Länge'],
    ['🍓', 'Erdbeere', 0.03, 'Höhe'],
    ['🥚', 'Hühnerei', 0.057, 'Höhe'],
    ['🔑', 'Haustürschlüssel', 0.06, 'Länge'],
    ['🎾', 'Tennisball', 0.067, 'Durchmesser'],
    ['🦋', 'Tagpfauenauge', 0.06, 'Spannweite'],
    ['🍎', 'Apfel', 0.08, 'Durchmesser'],
    ['🐭', 'Hausmaus', 0.085, 'Körperlänge'],
    ['📱', 'Smartphone', 0.15, 'Höhe'],
    ['✏️', 'Bleistift', 0.175, 'Länge'],
    ['🍌', 'Banane', 0.19, 'Länge'],
    ['⚽', 'Fussball', 0.22, 'Durchmesser'],
    ['🏀', 'Basketball', 0.24, 'Durchmesser'],
    ['💻', 'Laptop (15 Zoll)', 0.36, 'Breite'],
    ['🍉', 'Wassermelone', 0.35, 'Länge'],
    ['🐇', 'Kaninchen', 0.4, 'Körperlänge'],
    ['🐈', 'Hauskatze', 0.46, 'Körperlänge'],
    ['🐕', 'Labrador', 0.57, 'Schulterhöhe'],
    ['🪑', 'Stuhl', 0.9, 'Höhe'],
    ['🎸', 'Gitarre', 1.0, 'Länge'],
    ['🐧', 'Kaiserpinguin', 1.15, 'Höhe'],
    ['🦩', 'Flamingo', 1.3, 'Höhe'],
    ['🐎', 'Pferd', 1.6, 'Schulterhöhe'],
    ['🧍', 'Erwachsener Mensch', 1.75, 'Größe'],
    ['🚲', 'Fahrrad', 1.75, 'Länge'],
    ['🐢', 'Lederschildkröte', 1.8, 'Panzerlänge'],
    ['🚪', 'Zimmertür', 2.0, 'Höhe'],
    ['🦅', 'Weißkopfseeadler', 2.0, 'Spannweite'],
    ['🛏️', 'Doppelbett', 2.0, 'Länge'],
    ['🌻', 'Sonnenblume', 2.5, 'Höhe'],
    ['🎹', 'Konzertflügel', 2.75, 'Länge'],
    ['🐘', 'Afrikanischer Elefant', 3.3, 'Schulterhöhe'],
    ['🚗', 'Auto (Golf)', 4.3, 'Länge'],
    ['🦈', 'Weißer Hai', 4.5, 'Länge'],
    ['🐊', 'Salzwasserkrokodil', 5.0, 'Länge'],
    ['🦒', 'Giraffe', 5.5, 'Höhe'],
    ['🏠', 'Einfamilienhaus', 9, 'Höhe'],
    ['🚌', 'Linienbus', 12, 'Länge'],
    ['🦖', 'Tyrannosaurus rex', 12.3, 'Länge'],
    ['🚂', 'Lokomotive', 19, 'Länge'],
    ['🐋', 'Blauwal', 25, 'Länge'],
    ['✈️', 'Airbus A380', 73, 'Länge'],
    ['🗽', 'Freiheitsstatue (mit Sockel)', 93, 'Höhe'],
    ['🌲', 'Küstenmammutbaum', 100, 'Höhe'],
    ['🏟️', 'Fussballfeld', 105, 'Länge'],
    ['🚀', 'Saturn-V-Rakete', 111, 'Höhe'],
    ['🎡', 'London Eye', 135, 'Höhe'],
    ['⛪', 'Kölner Dom', 157, 'Höhe'],
    ['🛳️', 'Titanic', 269, 'Länge'],
    ['🗼', 'Eiffelturm', 330, 'Höhe'],
    ['🏙️', 'Burj Khalifa', 828, 'Höhe'],
    ['🗻', 'Mount Everest', 8849, 'Höhe'],
    ['🌕', 'Mond', 3474800, 'Durchmesser'],
    ['🌍', 'Erde', 12742000, 'Durchmesser'],
    ['🪐', 'Jupiter', 139820000, 'Durchmesser'],
    ['☀️', 'Sonne', 1392700000, 'Durchmesser'],
  ];
  const ROUNDS = 10;
  const st = { phase: 'start', round: 0, rounds: [], guess: 0, total: 0, best: 0, root: null, loaded: false, zoom: 1 };
  const setZoom = (z) => {
    st.zoom = Math.max(0.5, Math.min(2.5, Math.round(z * 10) / 10));
    const stage = st.root?.querySelector('#su-stage');
    if (stage) stage.innerHTML = stageHtml();
  };
  document.addEventListener('wheel', (e) => {
    if (!st.root?.contains(e.target) || !e.target.closest('#su-stage') || !e.ctrlKey) return;
    e.preventDefault();
    setZoom(st.zoom * (e.deltaY < 0 ? 1.1 : 0.9));
  }, { passive: false });

  function fmt(m) {
    const n = (v, d = 0) => v.toLocaleString('de-CH', { maximumFractionDigits: d });
    if (m < 0.001) return `${n(m * 1e6, m < 0.00001 ? 1 : 0)} µm`;
    if (m < 0.01) return `${n(m * 1000, 1)} mm`;
    if (m < 1) return `${n(m * 100, m < 0.1 ? 1 : 0)} cm`;
    if (m < 1000) return `${n(m, m < 10 ? 2 : 0)} m`;
    return `${n(m / 1000, m < 10000 ? 2 : 0)} km`;
  }

  function newGame() {
    const pool = [...ITEMS].sort(() => Math.random() - 0.5);
    st.rounds = [];
    for (const target of pool) {
      if (st.rounds.length >= ROUNDS) break;
      // Referenz: ähnliche Größenordnung (Faktor 1/40 … 40), aber nicht dasselbe Objekt
      const refs = ITEMS.filter((r) => r !== target && Math.abs(Math.log10(r[2] / target[2])) < 1.6 && Math.abs(Math.log10(r[2] / target[2])) > 0.05);
      if (!refs.length) continue;
      st.rounds.push({ target, ref: refs[Math.floor(Math.random() * refs.length)], guess: null, pts: 0 });
    }
    st.round = 0;
    st.total = 0;
    st.phase = 'play';
    startRound();
  }
  function startRound() {
    const r = st.rounds[st.round];
    st.guess = Math.log10(r.ref[2]); // Regler startet bei der Größe der Referenz
    st.phase = 'play';
  }
  const range = () => {
    const r = st.rounds[st.round];
    const c = Math.log10(r.ref[2]);
    return [c - 2, c + 2];
  };
  function lock() {
    const r = st.rounds[st.round];
    const g = 10 ** st.guess;
    const err = Math.abs(Math.log10(g / r.target[2]));
    // 0 Fehler = 1000 Punkte, Faktor 2 daneben ≈ 400, Faktor 4 daneben = 0
    r.pts = Math.max(0, Math.round(1000 * (1 - err / 0.6)));
    r.guess = g;
    st.total += r.pts;
    st.phase = 'result';
  }
  async function finish() {
    st.phase = 'end';
    if (st.total > st.best) {
      st.best = st.total;
      A.store.set('sizeup', { best: st.best }, true);
    }
    A.earn(Math.round(st.total / 200));
  }

  function silhouette(item, sizePx, reveal = false) {
    return `<div class="su-fig" style="--s:${sizePx}px"><span class="su-emo ${reveal ? 'reveal' : ''}">${item[0]}</span></div>`;
  }
  function stageHtml() {
    const r = st.rounds[st.round];
    const g = st.phase === 'result' ? r.target[2] : 10 ** st.guess;
    const ratio = g / r.ref[2];
    // Größen auf der Bühne: das Größere füllt die Höhe, das Kleinere wird maßstäblich
    const H = 230 * st.zoom;
    let refPx = H;
    let tgtPx = H;
    if (ratio >= 1) refPx = Math.max(6, H / ratio);
    else tgtPx = Math.max(6, H * ratio);
    // 2.45.1: immer nur Silhouetten (auch Referenz und Auflösung), Bühne zoombar
    return `<div class="su-zoom"><button class="rv-btn sm" data-su-zoom="-1" title="Kleiner">−</button><span>${Math.round(st.zoom * 100)} %</span><button class="rv-btn sm" data-su-zoom="1" title="Größer">＋</button></div>
    <div class="su-stage" style="height:${Math.round(H + 70)}px">
      <div class="su-col">${silhouette(r.ref, refPx)}<b>${esc(r.ref[1])}</b><small>${esc(r.ref[3])}: ${fmt(r.ref[2])}</small></div>
      <div class="su-col">${silhouette(r.target, tgtPx)}<b>${esc(r.target[1])}</b><small>${st.phase === 'result' ? `${esc(r.target[3])}: ${fmt(r.target[2])}` : `${esc(r.target[3])}: ?`}</small></div>
    </div>`;
  }
  function paint() {
    if (!st.root) return;
    if (st.phase === 'start' || st.phase === 'end') {
      st.root.innerHTML = `<div class="rv-card su-start">
        <div class="su-hero">${ITEMS.slice(18, 26).map((i) => `<span class="su-emo">${i[0]}</span>`).join('')}</div>
        <h2 class="rv-h">${st.phase === 'end' ? `${st.total.toLocaleString('de-CH')} Punkte` : 'Size It Up'}</h2>
        <p class="rv-sub">${st.phase === 'end' ? `von ${(ROUNDS * 1000).toLocaleString('de-CH')} möglichen · Bestwert ${st.best.toLocaleString('de-CH')}` : `Schätze, wie groß Dinge wirklich sind. ${ITEMS.length} Objekte von Bakterium bis Sonne – ein Referenz-Objekt hilft dir.`}</p>
        ${st.phase === 'end' ? `<div class="su-recap">${st.rounds.map((r) => `<div><span class="su-emo mini">${r.target[0]}</span><span class="rv-grow">${esc(r.target[1])}<small>${fmt(r.target[2])} · du: ${fmt(r.guess)}</small></span><b>${r.pts}</b></div>`).join('')}</div>` : ''}
        <div class="rv-row" style="justify-content:center;margin-top:16px"><button class="rv-btn primary" data-su="start">${st.phase === 'end' ? 'Nochmal spielen' : 'Spiel starten'}</button></div>
        ${st.best && st.phase === 'start' ? `<p class="rv-muted" style="text-align:center;margin-top:10px">Dein Bestwert: ${st.best.toLocaleString('de-CH')}</p>` : ''}
      </div>`;
      return;
    }
    const r = st.rounds[st.round];
    const [lo, hi] = range();
    st.root.innerHTML = `<div class="rv-card">
      <div class="rv-row between"><span class="rv-pill">Runde ${st.round + 1} / ${st.rounds.length}</span><span class="rv-pill">◆ ${st.total.toLocaleString('de-CH')} Punkte</span></div>
      <h3 style="margin:14px 0 2px;text-align:center">Wie ${r.target[3] === 'Größe' || r.target[3] === 'Höhe' || r.target[3] === 'Schulterhöhe' ? 'hoch' : 'groß'} ist: ${esc(r.target[1])}?</h3>
      <p class="rv-muted" style="text-align:center;margin:0">${esc(r.target[3])} schätzen</p>
      <div id="su-stage">${stageHtml()}</div>
      ${st.phase === 'play'
        ? `<div class="su-guess"><output id="su-out">${fmt(10 ** st.guess)}</output>
           <input type="range" class="su-range" min="${lo}" max="${hi}" step="0.005" value="${st.guess}" data-su-range />
           <div class="rv-row between rv-muted" style="font-size:12px"><span>${fmt(10 ** lo)}</span><span>${fmt(10 ** hi)}</span></div>
           <div class="rv-row" style="justify-content:center;margin-top:12px"><button class="rv-btn primary" data-su="lock">Einloggen</button></div></div>`
        : `<div class="su-guess"><div class="su-res ${r.pts >= 700 ? 'good' : r.pts >= 300 ? 'ok' : 'bad'}">+${r.pts}</div><p style="text-align:center;margin:6px 0 0">Richtig: <b>${fmt(r.target[2])}</b> · Deine Schätzung: ${fmt(r.guess)}</p>
           <div class="rv-row" style="justify-content:center;margin-top:12px"><button class="rv-btn primary" data-su="next">${st.round + 1 >= st.rounds.length ? 'Ergebnis' : 'Weiter'}</button></div></div>`}
    </div>`;
  }
  function onInput(e) {
    if (!st.root?.contains(e.target) || !e.target.matches('[data-su-range]')) return;
    st.guess = Number(e.target.value);
    const out = st.root.querySelector('#su-out');
    if (out) out.textContent = fmt(10 ** st.guess);
    const stage = st.root.querySelector('#su-stage');
    if (stage) stage.innerHTML = stageHtml();
  }
  function onClick(e) {
    if (!st.root?.contains(e.target)) return;
    const z = e.target.closest('[data-su-zoom]')?.dataset.suZoom;
    if (z) return setZoom(st.zoom + Number(z) * 0.2);
    const a = e.target.closest('[data-su]')?.dataset.su;
    if (a === 'start') newGame();
    else if (a === 'lock') lock();
    else if (a === 'next') {
      st.round += 1;
      if (st.round >= st.rounds.length) finish();
      else startRound();
    } else return;
    paint();
  }
  document.addEventListener('input', onInput);
  document.addEventListener('click', onClick);

  A.define(
    ID,
    { nav: 'Size It Up', title: 'Size It Up', sub: 'Größen schätzen', icon: 'resize', tint: 'linear-gradient(135deg,#f59e0b,#7c3aed)', desc: 'Wie groß ist ein Blauwal neben einem Bus? Schätze echte Größen anhand von Silhouetten und einem Referenz-Objekt.' },
    {
      async mount(root) {
        st.root = root;
        if (!st.loaded) {
          st.loaded = true;
          st.best = Number((await A.store.get('sizeup', {}, true))?.best) || 0;
        }
        paint();
      },
      unmount() {
        st.root = null;
      },
    },
  );
})();
