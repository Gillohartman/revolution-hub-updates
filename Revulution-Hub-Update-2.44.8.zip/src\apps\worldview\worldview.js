'use strict';
(() => {
  const start = document.getElementById('start');
  if (start) {
    start.addEventListener('click', async () => {
      start.disabled = true;
      start.textContent = 'Weltansicht wird geladen …';
      document.getElementById('error').textContent = '';
      try { await window.worldview.start(); }
      catch (error) {
        document.getElementById('error').textContent = error?.message || 'Die Weltansicht konnte nicht gestartet werden.';
        start.disabled = false;
        start.textContent = 'Erneut versuchen';
      }
    });
    return;
  }
  if (document.getElementById('worldview-tools')) return;
  document.title = 'Weltansicht';
  // The globe and Stories mount asynchronously and can update these labels later.
  // 2.45: eigene Weltansicht-Marke oben links (statt des generischen Globus)
  const LOGO = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="100%" height="100%"><defs><linearGradient id="rvwg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b7bff"/><stop offset="1" stop-color="#0e8aa8"/></linearGradient></defs><rect width="48" height="48" rx="12" fill="url(#rvwg)"/><circle cx="24" cy="24" r="14.5" fill="#fff"/><path d="M9.6 24h28.8M24 9.6c4.4 4 6.6 8.8 6.6 14.4S28.4 34 24 38.4c-4.4-4.4-6.6-8.8-6.6-14.4S19.6 13.6 24 9.6Z" fill="none" stroke="#4f5fd6" stroke-width="2" opacity=".55"/><ellipse cx="24" cy="24" rx="21" ry="7.5" transform="rotate(-24 24 24)" fill="none" stroke="#fff" stroke-width="2.2"/><circle cx="41.5" cy="15.2" r="3.4" fill="#ff3b30" stroke="#fff" stroke-width="1.6"/></svg>';
  const setLogo = () => {
    const el = document.querySelector('#title-bar .title-logo');
    if (el && el.dataset.revLogo !== '1') {
      el.dataset.revLogo = '1';
      el.innerHTML = LOGO;
    }
  };
  // Großbuchstaben-Beschriftungen der Bibliothek in normale Schreibweise (wie im ganzen Hub)
  const KEEP_CAPS = new Set(['CCTV', 'GPS', 'ISS', 'NASA', 'ESA', 'UTC', 'AIS', 'ADS-B', 'HUD', 'UI', 'KI', 'KM', 'USA', 'EU']);
  const niceCase = (t) => {
    const trimmed = t.trim();
    if (trimmed.length < 4 || trimmed !== trimmed.toUpperCase() || !/[A-ZÄÖÜ]/.test(trimmed) || KEEP_CAPS.has(trimmed)) return t;
    const fixed = trimmed.toLowerCase().replace(/(^|[\s/·-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()).replace(/Strassenebene/i, 'Straßenebene');
    return t.replace(trimmed, fixed);
  };
  const cleanLabels = root => {
    setLogo();
    if (root.querySelectorAll) for (const el of [...(root.matches?.('.ui-rail__label, .ui-panel__title') ? [root] : []), ...root.querySelectorAll('.ui-rail__label, .ui-panel__title')]) {
      const n = el.firstChild;
      if (n && n.nodeType === Node.TEXT_NODE) {
        const v = niceCase(n.nodeValue);
        if (v !== n.nodeValue) n.nodeValue = v;
      }
    }
    const selectors = '#location-mini-city, #gev-stories h1, #gev-stories h2, #gev-stories .c-meta, #gev-stories .h-right button, #gev-stories .gs-opened-toast b, .omnibar-field input';
    const elements = [];
    if (root.nodeType === Node.ELEMENT_NODE && root.matches(selectors)) elements.push(root);
    if (root.querySelectorAll) elements.push(...root.querySelectorAll(selectors));
    for (const el of elements) {
      if (el.matches('input')) {
        const value = el.placeholder.replace(/\s*oder GEV fragen.*$/i, '');
        if (el.placeholder !== value) el.placeholder = value;
        continue;
      }
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const node = walker.currentNode;
        const text = node.nodeValue.replace(/📍\s*/gu, '').replace(/GEV-Szene/g, 'Weltansicht-Szene').replace(/\bGEV\b/g, 'Weltansicht').replace(/Weltansicht\s*·\s*Weltansicht-Szene/g, 'Weltansicht-Szene');
        if (node.nodeValue !== text) node.nodeValue = text;
      }
    }
  };
  // Mirror the existing Cockpit action near the top without moving Vue-owned nodes.
  const syncCockpitAction = root => {
    if (root.nodeType !== Node.ELEMENT_NODE) return;
    const cards = [];
    if (root.matches('#entity-card')) cards.push(root);
    if (root.querySelectorAll) cards.push(...root.querySelectorAll('#entity-card'));
    const owner = root.closest('#entity-card');
    if (owner) cards.push(owner);
    const container = root.closest('#global-context-panel');
    if (!owner && container) cards.push(...container.querySelectorAll('#entity-card'));
    for (const card of new Set(cards)) {
      const original = card.querySelector('[data-entity-cockpit-entry]');
      const existing = card.querySelector('.worldview-cockpit-shortcut');
      if (!original) { existing?.remove(); continue; }
      if (existing) continue;
      const hero = card.querySelector('.entity-hero');
      if (!hero) continue;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'worldview-cockpit-shortcut';
      button.textContent = original.textContent.trim() || 'Cockpit öffnen';
      button.addEventListener('click', () => card.querySelector('[data-entity-cockpit-entry]')?.click());
      hero.after(button);
    }
  };
  const labelObserver = new MutationObserver(records => {
    for (const record of records) {
      if (record.type === 'characterData') cleanLabels(record.target.parentElement);
      else if (record.type === 'attributes') cleanLabels(record.target);
      else {
        if (record.target.nodeType === Node.ELEMENT_NODE) syncCockpitAction(record.target);
        for (const node of record.addedNodes) if (node.nodeType === Node.ELEMENT_NODE) { cleanLabels(node); syncCockpitAction(node); }
      }
    }
  });
  labelObserver.observe(document.body, { childList: true, characterData: true, subtree: true, attributes: true, attributeFilter: ['placeholder'] });
  cleanLabels(document.body);
  syncCockpitAction(document.body);
  window.addEventListener('pagehide', () => labelObserver.disconnect(), { once: true });
  const panel = document.createElement('section');
  panel.id = 'worldview-tools';
  panel.setAttribute('aria-label', 'Standort und Benachrichtigungen');
  panel.innerHTML = `<button type="button" class="worldview-tools-toggle" aria-expanded="false">⌖ &nbsp; Standort & Hinweise</button>
    <div class="worldview-tools-body" hidden>
      <div class="worldview-tools-heading">Dein Standort</div>
      <p>Dein Standort wird nur auf Wunsch ermittelt und nicht an die Datenquellen dieser Hinweise gesendet. Windows-Standortdienste können ihn über einen Standortanbieter bestimmen.</p>
      <label><input type="checkbox" data-location> Standort auf Globus und Widget anzeigen</label>
      <button type="button" class="worldview-locate">⌖ &nbsp; Zu meinem Standort</button>
      <div class="worldview-tools-heading">Island-Hinweise</div>
      <label><input type="checkbox" data-alert="military"> Militärflugzeuge in der Nähe</label>
      <label><input type="checkbox" data-alert="earthquake"> Starke Erdbeben weltweit</label>
      <p>Nur bei geöffneter Weltansicht. Flugdaten können fehlen oder ungenau sein; keine offiziellen Warnungen.</p>
      <p class="worldview-status" role="status" aria-live="polite"></p>
    </div>`;
  document.body.appendChild(panel);
  const toggle = panel.querySelector('.worldview-tools-toggle');
  const body = panel.querySelector('.worldview-tools-body');
  const status = panel.querySelector('.worldview-status');
  const locate = panel.querySelector('.worldview-locate');
  const locationToggle = panel.querySelector('[data-location]');
  const military = panel.querySelector('[data-alert="military"]');
  const earthquake = panel.querySelector('[data-alert="earthquake"]');
  let position = null;
  let militaryTimer = null;
  let earthquakeTimer = null;
  let militaryAbort = null;
  let quakeAbort = null;
  let seenMilitary = new Map();
  let seenQuakes = null;
  let session = 0;
  let locationWatch = null;
  let locationGeneration = 0;
  let locationMarker = null;
  let markerRetry = null;
  let unsubscribeLayers = null;
  let layerRetry = null;
  const message = (text) => { status.textContent = text; };
  const applyAppearance = (appearance) => {
    const color = appearance?.widgetAccent;
    if (/^#[0-9a-f]{6}$/i.test(color || '')) {
      document.documentElement.style.setProperty('--wv-accent', color);
      if (locationToggle.checked && position) showLocationMarker();
    }
    if (typeof appearance?.worldviewLocation === 'boolean') {
      locationToggle.checked = appearance.worldviewLocation;
      syncLocation();
    }
  };
  const stopAppearance = window.worldview.onAppearance(applyAppearance);
  window.worldview.appearance().then(applyAppearance).catch(() => message('Darstellungseinstellungen konnten nicht geladen werden.'));

  function removeLocationMarker() {
    clearTimeout(markerRetry); markerRetry = null;
    const viewer = window.__godsEyeView?.viewer;
    if (locationMarker && viewer?.entities) viewer.entities.remove(locationMarker);
    locationMarker = null;
    viewer?.scene?.requestRender?.();
  }
  function showLocationMarker() {
    clearTimeout(markerRetry); markerRetry = null;
    if (!locationToggle.checked || !position) return;
    const viewer = window.__godsEyeView?.viewer, Cesium = window.__CESIUM__;
    if (!viewer?.entities || !Cesium?.Cartesian3) {
      markerRetry = setTimeout(showLocationMarker, 500);
      return;
    }
    const color = getComputedStyle(document.documentElement).getPropertyValue('--wv-accent').trim() || '#ff2d2d';
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 64;
    const g = canvas.getContext('2d');
    g.fillStyle = color + '33'; g.beginPath(); g.arc(32, 32, 25, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(32, 32, 12, 0, Math.PI * 2); g.fill();
    g.fillStyle = color; g.beginPath(); g.arc(32, 32, 8, 0, Math.PI * 2); g.fill();
    const point = Cesium.Cartesian3.fromDegrees(position.longitude, position.latitude);
    if (!locationMarker) locationMarker = viewer.entities.add({ position: point, billboard: { image: canvas.toDataURL(), width: 40, height: 40, heightReference: Cesium.HeightReference.CLAMP_TO_GROUND } });
    else { locationMarker.position = point; locationMarker.billboard.image = canvas.toDataURL(); }
    viewer.scene.requestRender();
  }
  function syncLocation() {
    if (!locationToggle.checked) {
      locationGeneration++;
      if (locationWatch !== null) navigator.geolocation?.clearWatch(locationWatch);
      locationWatch = null;
      removeLocationMarker();
      return;
    }
    if (position) showLocationMarker();
    if (locationWatch !== null) return;
    if (!navigator.geolocation) { message('Standortdienste sind nicht verfügbar.'); return; }
    const generation = ++locationGeneration;
    locationWatch = navigator.geolocation.watchPosition(result => {
      if (generation !== locationGeneration || !locationToggle.checked) return;
      const { latitude, longitude, accuracy } = result.coords;
      if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return;
      position = { latitude, longitude, accuracy };
      showLocationMarker();
      message('Standortanzeige aktiviert.');
    }, error => {
      if (generation !== locationGeneration) return;
      position = null;
      removeLocationMarker();
      message(error.code === 1 ? 'Standortzugriff verweigert. Bitte in Windows erlauben oder die Anzeige ausschalten.' : 'Standort nicht verfügbar. Bitte Windows-Standortdienste prüfen.');
    }, { timeout: 15000, maximumAge: 300000, enableHighAccuracy: true });
  }
  locationToggle.addEventListener('change', async () => {
    const enabled = locationToggle.checked;
    syncLocation();
    try { await window.worldview.setLocationEnabled(enabled); }
    catch { locationToggle.checked = !enabled; syncLocation(); message('Standorteinstellung konnte nicht gespeichert werden.'); }
  });

  const quick = document.createElement('nav');
  quick.id = 'worldview-quick';
  quick.setAttribute('aria-label', 'Datenebenen schnell schalten');
  quick.innerHTML = `<button type="button" data-layer="flights" aria-pressed="false">Flugzeuge</button><button type="button" data-layer="satellites" aria-pressed="false">Satelliten</button><button type="button" data-layer="military" aria-pressed="false">Militärflüge</button>`;
  document.body.appendChild(quick);
  const syncLayers = () => {
    const manager = window.__godsEyeView?.dataManager;
    for (const button of quick.querySelectorAll('button')) {
      const entry = manager?.layers?.get(button.dataset.layer);
      button.disabled = !entry;
      button.setAttribute('aria-pressed', String(Boolean(manager?.isEffectivelyEnabled?.(button.dataset.layer))));
    }
  };
  function connectLayers() {
    const manager = window.__godsEyeView?.dataManager;
    if (!manager) { layerRetry = setTimeout(connectLayers, 500); return; }
    unsubscribeLayers = manager.subscribeActivity(syncLayers);
    syncLayers();
  }
  quick.addEventListener('click', async event => {
    const button = event.target.closest('button[data-layer]');
    const manager = window.__godsEyeView?.dataManager;
    if (!button || !manager) return;
    try { await manager.toggle(button.dataset.layer, { origin: 'user' }); }
    catch { message('Datenebene konnte nicht geschaltet werden.'); }
    syncLayers();
  });
  syncLayers(); connectLayers();
  toggle.addEventListener('click', () => {
    body.hidden = !body.hidden;
    toggle.setAttribute('aria-expanded', String(!body.hidden));
  });
  document.addEventListener('click', event => {
    if (!body.hidden && !panel.contains(event.target)) {
      body.hidden = true;
      toggle.setAttribute('aria-expanded', 'false');
    }
  });
  function locateUser() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('Standortermittlung ist auf diesem Gerät nicht verfügbar.'));
      navigator.geolocation.getCurrentPosition(result => {
        const { latitude, longitude, accuracy } = result.coords;
        if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return reject(new Error('Kein gültiger Standort verfügbar.'));
        position = { latitude, longitude, accuracy };
        if (locationToggle.checked) showLocationMarker();
        resolve(position);
      }, error => reject(new Error(error.code === 1 ? 'Standortzugriff verweigert. Bitte in Windows erlauben.' : 'Standort nicht verfügbar. Bitte Windows-Standortdienste prüfen.')), { timeout: 15000, maximumAge: 300000, enableHighAccuracy: true });
    });
  }
  locate.addEventListener('click', async () => {
    locate.disabled = true;
    message('Standort wird ermittelt …');
    try {
      const current = await locateUser();
      const viewer = window.__godsEyeView?.viewer, Cesium = window.__CESIUM__;
      if (!viewer?.camera || !Cesium?.Cartesian3) throw new Error('Die Weltansicht lädt noch. Bitte versuche es erneut.');
      viewer.camera.flyTo({ destination: Cesium.Cartesian3.fromDegrees(current.longitude, current.latitude, 12000), duration: 2 });
      message(`Standort ermittelt (Genauigkeit ca. ${Math.round(current.accuracy)} m).`);
    } catch (error) { message(error.message); }
    finally { locate.disabled = false; }
  });
  function distanceKm(a, lat, lon) {
    const rad = Math.PI / 180;
    const dLat = (lat - a.latitude) * rad, dLon = (lon - a.longitude) * rad;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.latitude * rad) * Math.cos(lat * rad) * Math.sin(dLon / 2) ** 2;
    return 12742 * Math.asin(Math.sqrt(Math.min(1, h)));
  }
  async function checkMilitary() {
    if (!military.checked || !position || militaryAbort) return;
    const controller = new AbortController(); militaryAbort = controller;
    try {
      const response = await fetch('/api/military', { signal: controller.signal, cache: 'no-store' });
      if (!response.ok || response.headers.get('X-Feed-Cache') === 'STALE') throw new Error('Flugdaten vorübergehend nicht verfügbar.');
      const data = await response.json();
      if (!military.checked || controller.signal.aborted || !Array.isArray(data.ac)) return;
      const now = Date.now();
      for (const [id, time] of seenMilitary) if (now - time > 3600000) seenMilitary.delete(id);
      for (const aircraft of data.ac) {
        const lat = aircraft.lat, lon = aircraft.lon, age = aircraft.seen_pos;
        if (!aircraft.hex || typeof lat !== 'number' || typeof lon !== 'number' || !Number.isFinite(age) || age > 60 || age < 0 || aircraft.alt_baro === 'ground') continue;
        const distance = distanceKm(position, lat, lon);
        if (distance > 10 || seenMilitary.has(aircraft.hex)) continue;
        seenMilitary.set(aircraft.hex, now);
        const name = String(aircraft.flight || aircraft.r || 'Unbekannt').trim().replace(/[^a-zA-Z0-9 -]/g, '').slice(0, 24);
        await window.worldview.notice('military', `${name} · etwa ${Math.max(1, Math.round(distance))} km entfernt (ADS-B).`);
      }
    } catch (error) { if (error.name !== 'AbortError') message('Flugdaten vorübergehend nicht verfügbar.'); }
    finally { if (militaryAbort === controller) militaryAbort = null; }
  }
  async function checkEarthquakes() {
    if (!earthquake.checked || quakeAbort) return;
    const controller = new AbortController(); quakeAbort = controller;
    try {
      const response = await fetch('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson', { signal: controller.signal, cache: 'no-store' });
      if (!response.ok) throw new Error('USGS nicht verfügbar');
      const data = await response.json();
      if (!earthquake.checked || controller.signal.aborted || !Array.isArray(data.features)) return;
      const previous = seenQuakes;
      seenQuakes = new Set(data.features.map(item => item.id).filter(Boolean));
      if (!previous) return;
      for (const item of data.features) {
        const p = item.properties || {};
        if (!item.id || previous.has(item.id) || !Number.isFinite(p.mag) || p.mag < 5.5 || !Number.isFinite(p.time) || Date.now() - p.time > 3600000 || p.time > Date.now() + 60000) continue;
        const place = String(p.place || 'Ort unbekannt').replace(/[\r\n]/g, ' ').slice(0, 70);
        await window.worldview.notice('earthquake', `Magnitude ${p.mag.toFixed(1)} · ${place} (USGS).`);
      }
    } catch (error) { if (error.name !== 'AbortError') message('Erdbebendaten vorübergehend nicht verfügbar.'); }
    finally { if (quakeAbort === controller) quakeAbort = null; }
  }
  military.addEventListener('change', async () => {
    const current = ++session;
    clearInterval(militaryTimer); militaryTimer = null;
    militaryAbort?.abort(); militaryAbort = null;
    seenMilitary = new Map();
    if (!military.checked) { message('Flughinweise ausgeschaltet.'); return; }
    try {
      message('Standort für Flughinweise wird ermittelt …');
      const currentPosition = await locateUser();
      if (!military.checked || current !== session) return;
      if (currentPosition.accuracy > 10000) throw new Error('Standort zu ungenau für Hinweise im Umkreis von 10 km.');
      message('Flughinweise an: gemeldete Militärflugzeuge im Umkreis von 10 km.');
      void checkMilitary();
      militaryTimer = setInterval(checkMilitary, 60000);
    } catch (error) { if (current === session) { military.checked = false; message(error.message); } }
  });
  earthquake.addEventListener('change', () => {
    clearInterval(earthquakeTimer); earthquakeTimer = null;
    quakeAbort?.abort(); quakeAbort = null; seenQuakes = null;
    if (!earthquake.checked) { message('Erdbebenhinweise ausgeschaltet.'); return; }
    message('Erdbebenhinweise an: neue Beben ab Magnitude 5,5 weltweit.');
    void checkEarthquakes();
    earthquakeTimer = setInterval(checkEarthquakes, 120000);
  });
  window.addEventListener('pagehide', () => {
    clearInterval(militaryTimer); clearInterval(earthquakeTimer);
    militaryAbort?.abort(); quakeAbort?.abort();
    locationGeneration++;
    if (locationWatch !== null) navigator.geolocation?.clearWatch(locationWatch);
    clearTimeout(markerRetry); clearTimeout(layerRetry);
    removeLocationMarker(); unsubscribeLayers?.(); stopAppearance?.();
  }, { once: true });
})();
