'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('worldview', {
  start: () => ipcRenderer.invoke('start'),
  notice: (kind, detail) => ipcRenderer.invoke('notice', kind, detail),
  appearance: () => ipcRenderer.invoke('appearance'),
  setLocationEnabled: (enabled) => ipcRenderer.invoke('location-setting', enabled),
  onAppearance: (callback) => {
    const listener = (_event, value) => callback(value);
    ipcRenderer.on('hub:appearance', listener);
    return () => ipcRenderer.removeListener('hub:appearance', listener);
  },
});
