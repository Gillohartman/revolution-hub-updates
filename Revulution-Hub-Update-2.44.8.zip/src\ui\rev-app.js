'use strict';

/*
 * 2.45 Gemeinsamer Baustein für die neuen Hub-Apps (Spiele, Zeichnen, Präsentation, Geräte …).
 * Die Apps verwalten ihr Fenster-Innenleben selbst: die Hülle hat data-morph-keep, damit das
 * Neuzeichnen des Hubs (morph) ihr Spielfeld nicht zurücksetzt. Nach jedem Seitenwechsel wird
 * die App wieder eingehängt (mount) und baut sich aus ihrem eigenen Zustand neu auf.
 */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const apps = new Map();

  /** App anmelden: mount(root) baut die Oberfläche in root, unmount() räumt Timer auf. */
  function define(id, meta, { mount, unmount, wide = false }) {
    apps.set(id, { mount, unmount, mounted: null });
    T.register(id, meta, () => `<div class="rv-app ${wide ? 'wide' : ''}" data-key="${id}"><div class="rv-root" id="rv-root-${id}" data-morph-keep></div></div>`);
  }

  // Nach jedem Neuzeichnen prüfen, ob die sichtbare App (neu) eingehängt werden muss.
  function check() {
    const active = T.ctx().state?.()?.active;
    for (const [id, a] of apps) {
      const root = document.getElementById(`rv-root-${id}`);
      if (id === active && root && a.mounted !== root) {
        a.mounted = root;
        try {
          a.mount(root);
        } catch (e) {
          console.error(e);
          root.innerHTML = `<div class="rv-card"><b>Die App konnte nicht starten.</b><p class="muted">${esc(errText(e))}</p></div>`;
        }
      } else if (a.mounted && (id !== active || !root || !document.contains(a.mounted))) {
        a.mounted = null;
        try {
          a.unmount?.();
        } catch {
          /* egal */
        }
      }
    }
  }
  const content = document.getElementById('content');
  if (content) new MutationObserver(() => queueMicrotask(check)).observe(content, { childList: true });
  setInterval(check, 700);

  /** Speicher (Datei im Hub-Ordner; sync = mit dem Konto auf alle PCs). */
  const store = {
    async get(key, fallback, sync = false) {
      try {
        const v = await window.hub.appdata.get(key, sync);
        return v == null ? fallback : v;
      } catch {
        return fallback;
      }
    },
    set(key, value, sync = false) {
      return window.hub.appdata.set(key, value, sync).catch(() => false);
    },
  };

  const toast = (msg, kind) => T.ctx().toast?.(msg, kind);
  const h = (html) => {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  };
  /** Zufall mit Startwert (für Tagesrätsel: alle Spieler bekommen dasselbe). */
  function seeded(seed) {
    let s = 0;
    for (const ch of String(seed)) s = (Math.imul(s ^ ch.charCodeAt(0), 2654435761) >>> 0) + 1;
    return () => {
      s = (s + 0x6d2b79f5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const today = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  /** Text vergleichbar machen: klein, ohne Akzente, ß→ss, Umlaute ausgeschrieben, ohne Artikel. */
  function norm(s) {
    return String(s || '')
      .toLowerCase()
      .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/&/g, ' und ')
      .replace(/^(der|die|das|the|a|an|ein|eine|le|la|el)\s+/, '')
      .replace(/[^a-z0-9]+/g, '')
      .trim();
  }
  /** Tippfehler-Abstand (Damerau): vertauschte Nachbarbuchstaben zählen als 1 Fehler. */
  function lev(a, b) {
    if (a === b) return 0;
    const m = a.length;
    const n = b.length;
    const d = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
    for (let j = 1; j <= n; j++) d[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
      }
    }
    return d[m][n];
  }

  window.RevApp = { define, store, esc, errText, toast, h, seeded, today, norm, lev, me: () => window.hub.appdata.me().catch(() => ({ name: '', uid: '' })), earn: (n) => window.hub.appdata.earn(n).catch(() => 0) };
})();
