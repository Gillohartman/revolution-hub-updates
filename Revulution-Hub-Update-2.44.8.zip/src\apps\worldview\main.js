'use strict';

const path = require('path');
const fs = require('fs');
const os = require('os');
const { fork } = require('child_process');
const { pathToFileURL } = require('url');
const { boot } = require('../shared/boot');
const ctx = boot('worldview', __dirname);
const { app, ipcMain } = ctx.electron;
const service = path.join(__dirname, '..', '..', '..', 'modules', 'worldview', 'hub-server.mjs');
let child = null;
let timer = null;
let hangTimer = null;
let generation = 0;
let samples = 0;
let previousCpu = null;
let servicePort = null;
let lastNotice = 0;

function isGlobeUrl(value) {
  try {
    const url = new URL(value);
    return Boolean(servicePort && url.origin === `http://127.0.0.1:${servicePort}` && url.pathname === '/' && url.search === '?welcome=0');
  } catch { return false; }
}

function isGlobeFrame(event) {
  const view = ctx.view;
  return Boolean(child && servicePort && view && !view.isDestroyed() && ctx.hub.active === 'worldview' && event.sender === view.webContents && event.senderFrame === view.webContents.mainFrame && isGlobeUrl(event.senderFrame.url));
}

function stop() {
  generation += 1;
  clearInterval(timer);
  clearTimeout(hangTimer);
  hangTimer = null;
  timer = null;
  samples = 0;
  previousCpu = null;
  servicePort = null;
  if (child) { child.kill(); child = null; }
}

function cpuTotals() {
  return os.cpus().reduce((a, cpu) => {
    a.idle += cpu.times.idle;
    a.total += Object.values(cpu.times).reduce((x, y) => x + y, 0);
    return a;
  }, { idle: 0, total: 0 });
}

function emergencyStop(view, message) {
  stop();
  view.unload();
  ctx.hub.opened.delete('worldview');
  ctx.hub.open('home');
  ctx.hub.notify('Weltansicht beendet', message, { app: 'Revulution Hub' });
}

function monitor(view) {
  let ticks = 0;
  previousCpu = cpuTotals();
  timer = setInterval(() => {
    if (!child || view.isDestroyed() || ctx.hub.active !== 'worldview') return;
    const current = cpuTotals();
    const total = current.total - previousCpu.total;
    const cpu = total > 0 ? 1 - (current.idle - previousCpu.idle) / total : 0;
    previousCpu = current;
    const lowMemory = os.freemem() < Math.min(512 * 1024 * 1024, os.totalmem() * 0.05);
    // A sustained CPU saturation combined with low RAM is a conservative proxy;
    // this does not claim to detect every GPU or frame-rate problem.
    if (++ticks > 6 && lowMemory && cpu > 0.97) samples += 1;
    else samples = 0;
    if (samples >= 6) {
      emergencyStop(view, 'Der PC war längere Zeit stark ausgelastet und hatte kaum freien Arbeitsspeicher.');
    }
  }, 5000);
}

ipcMain.handle('start', async (event) => {
  const view = ctx.view;
  const warningUrl = pathToFileURL(path.join(__dirname, 'index.html')).href;
  if (!view || view.isDestroyed() || ctx.hub.active !== 'worldview' || event.sender !== view.webContents || event.senderFrame !== view.webContents.mainFrame || event.senderFrame.url !== warningUrl) throw new Error('Die Weltansicht ist nicht geöffnet.');
  if (child) return { ok: true };
  const dataDir = path.join(app.getPath('userData'), 'cache');
  fs.mkdirSync(dataDir, { recursive: true });
  const current = ++generation;
  const env = { SystemRoot: process.env.SystemRoot, WINDIR: process.env.WINDIR, PATH: process.env.PATH, TEMP: process.env.TEMP, TMP: process.env.TMP, ELECTRON_RUN_AS_NODE: '1' };
  const proc = fork(service, [], { cwd: dataDir, env, execPath: process.execPath, stdio: ['ignore', 'ignore', 'pipe', 'ipc'], windowsHide: true });
  child = proc;
  proc.stderr.on('data', (data) => console.error('[worldview]', String(data).slice(0, 2000)));
  proc.on('exit', () => { if (child === proc) { child = null; clearInterval(timer); timer = null; } });
  const port = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Der lokale Globus-Dienst startet nicht.')), 30000);
    const finish = (fn, value) => { clearTimeout(timeout); fn(value); };
    proc.once('message', (message) => finish(resolve, message?.port));
    proc.once('error', (error) => finish(reject, error));
    proc.once('exit', () => finish(reject, new Error('Der lokale Globus-Dienst wurde beendet.')));
  }).catch((error) => { if (child === proc) stop(); throw error; });
  if (current !== generation || child !== proc || ctx.hub.active !== 'worldview') { proc.kill(); throw new Error('Der Start wurde abgebrochen.'); }
  if (!Number.isInteger(port) || port < 1 || port > 65535) { stop(); throw new Error('Ungültige Dienstadresse.'); }
  servicePort = port;
  try {
    await view.webContents.loadURL(`http://127.0.0.1:${port}/?welcome=0`);
  } catch (error) {
    if (child === proc) stop();
    throw error;
  }
  if (current !== generation || child !== proc || ctx.hub.active !== 'worldview') return { ok: false };
  monitor(view);
  return { ok: true };
});

ipcMain.handle('appearance', (event) => {
  if (!isGlobeFrame(event)) throw new Error('Die Weltansicht ist nicht geöffnet.');
  const settings = ctx.hub.state().settings;
  return { widgetAccent: settings.widgetAccent || '#ff2d2d', worldviewLocation: settings.worldviewLocation === true };
});

ipcMain.handle('location-setting', (event, enabled) => {
  if (!isGlobeFrame(event) || typeof enabled !== 'boolean') throw new Error('Ungültige Standorteinstellung.');
  ctx.hub.setWorldviewLocation(enabled);
});

ipcMain.handle('notice', (event, kind, detail) => {
  if (!isGlobeFrame(event) || !['military', 'earthquake'].includes(kind) || typeof detail !== 'string' || detail.length > 120 || Date.now() - lastNotice < 3000) return false;
  lastNotice = Date.now();
  ctx.hub.notify(kind === 'military' ? 'Militärflugzeug in der Nähe' : 'Neues starkes Erdbeben', detail, { app: 'Weltansicht', open: 'revulution://open/worldview' });
  return true;
});

app.on('before-quit', stop);
app.whenReady().then(() => {
  const view = ctx.view;
  if (!view) return;
  const session = view.webContents.session;
  session.setPermissionRequestHandler((wc, permission, callback, details) => {
    callback(Boolean(child && servicePort && wc === view.webContents && ctx.hub.active === 'worldview' && permission === 'geolocation' && details.isMainFrame && isGlobeUrl(details.requestingUrl)));
  });
  session.setPermissionCheckHandler((wc, permission, origin, details) => Boolean(child && servicePort && wc === view.webContents && ctx.hub.active === 'worldview' && permission === 'geolocation' && details.isMainFrame && origin === `http://127.0.0.1:${servicePort}`));
  view.webContents.on('dom-ready', () => {
    if (!child || !servicePort || !isGlobeUrl(view.webContents.getURL())) return;
    const script = fs.readFileSync(path.join(__dirname, 'worldview.js'), 'utf8');
    view.webContents.executeJavaScript(script).catch(error => console.error('[worldview] Oberfläche:', error));
  });
  view.on('worldview-stop', stop);
  view.webContents.on('unresponsive', () => {
    if (!child || ctx.hub.active !== 'worldview' || hangTimer) return;
    hangTimer = setTimeout(() => {
      hangTimer = null;
      if (child && ctx.hub.active === 'worldview' && !view.isDestroyed()) emergencyStop(view, 'Die Weltansicht hat längere Zeit nicht mehr reagiert.');
    }, 15000);
  });
  view.webContents.on('responsive', () => { clearTimeout(hangTimer); hangTimer = null; });
  view.webContents.on('will-navigate', (event, url) => {
    const current = view.webContents.getURL();
    try {
      const next = new URL(url);
      const now = new URL(current);
      if (next.origin === now.origin && next.protocol === 'http:' && next.hostname === '127.0.0.1') return;
    } catch { /* Refuse navigation away from the local globe. */ }
    event.preventDefault();
  });
  view.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) require('electron').shell.openExternal(url);
    return { action: 'deny' };
  });
});
