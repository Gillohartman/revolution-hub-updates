'use strict';

/*
 * 2.45 Geräte-Apps (Kategorie Gaming, neben „Geräte & RGB“):
 *  - Logitech-/Maus-Studio: Mitte, Zurück, Vor und G-Tasten (F13–F24) frei belegen, Makros mit Abständen.
 *  - AJAZZ-Studio: führt direkt zu Licht & Display der AJAZZ AK820 Pro.
 *  - Stream-Deck-Studio: Tasten-Raster mit Aktionen (Spotify/Medien, Screenshot, Soundboard, Apps, Webseiten,
 *    Crosshair, Ketten) – per Klick oder per Hardware-Taste (z. B. F13–F24 vom Deck) auslösbar.
 *  - Lüfter: Windows-Kühlrichtlinie, GPU-Lüfter/Temperatur, Mainboard-Sensoren (falls verfügbar).
 * Belegungen landen in denselben Regeln wie die Tastatur-App (eine Engine für alles).
 */
(() => {
  const A = window.RevApp;
  const ME = window.RevMacroEditor;
  if (!A) return;
  const { esc } = A;
  const ctx = () => window.HubTools.ctx();

  /* ---------------------------------------------------------------- gemeinsame Regel-Helfer */
  const kbCfg = () => {
    const s = ctx().state()?.settings?.keyboard || {};
    const c = { enabled: s.enabled === true, profiles: Array.isArray(s.profiles) && s.profiles.length ? JSON.parse(JSON.stringify(s.profiles)) : [{ id: 'global', name: 'Überall', apps: [], on: true, rules: [] }] };
    if (!c.profiles.some((p) => !p.apps?.length)) c.profiles.unshift({ id: 'global', name: 'Überall', apps: [], on: true, rules: [] });
    return c;
  };
  const globalProfile = (c) => c.profiles.find((p) => !p.apps?.length);
  async function kbSave(c, enable = true) {
    if (enable) c.enabled = true;
    await window.hub.setSettings({ keyboard: c });
    const st = await window.hub.keyboard.apply();
    window.__kbReset?.();
    return st;
  }
  const findRule = (c, from) => globalProfile(c).rules.find((r) => r.from === from);
  function setRule(c, from, rule) {
    const p = globalProfile(c);
    p.rules = p.rules.filter((r) => r.from !== from);
    if (rule) p.rules.push({ from, on: true, ...rule });
  }
  const TYPE_NAMES = [['', 'Standard (unverändert)'], ['key', 'Andere Taste'], ['combo', 'Tastenkombination'], ['text', 'Text schreiben'], ['run', 'Programm / Webseite'], ['media', 'Medien'], ['macro', 'Makro'], ['off', 'Ausschalten']];
  const MEDIA = [['play', 'Play / Pause'], ['next', 'Nächster Titel'], ['prev', 'Vorheriger Titel'], ['mute', 'Stumm'], ['volup', 'Lauter'], ['voldown', 'Leiser']];

  /* ================================================================ Logitech-/Maus-Studio */
  const lg = { root: null, mice: null, capture: null, extra: [], lastBtn: '', status: null };
  const BUTTONS = [['MouseMiddle', 'Mittlere Taste (Rad)'], ['MouseBack', 'Seitentaste hinten (Zurück)'], ['MouseForward', 'Seitentaste vorne (Vor)']];
  function lgRows(c) {
    const fKeys = globalProfile(c).rules.filter((r) => /^F(1[3-9]|2[0-4])$/.test(r.from)).map((r) => r.from);
    const keys = [...BUTTONS, ...[...new Set([...fKeys, ...lg.extra])].map((k) => [k, `G-Taste → ${k}`])];
    return keys.map(([from, label]) => {
      const r = findRule(c, from);
      const type = r?.type || '';
      let target = '';
      if (type === 'key') target = `<button class="rv-btn sm ${lg.capture?.from === from && lg.capture.what === 'to' ? 'on' : ''}" data-lg-cap="to" data-from="${from}">${lg.capture?.from === from && lg.capture.what === 'to' ? 'Taste drücken …' : esc(ME?.keyName(r.to) || r.to || 'Taste wählen')}</button>`;
      else if (type === 'combo') target = `<button class="rv-btn sm ${lg.capture?.from === from && lg.capture.what === 'combo' ? 'on' : ''}" data-lg-cap="combo" data-from="${from}">${lg.capture?.from === from && lg.capture.what === 'combo' ? 'Kombination drücken …' : esc((r.to || []).map((k) => ME?.keyName(k) || k).join(' + ') || 'Kombination drücken')}</button>`;
      else if (type === 'text' || type === 'run') target = `<input class="rv-input sm" data-lg-to="${from}" value="${esc(r.to || '')}" placeholder="${type === 'run' ? 'https://… oder C:\\…exe' : 'Text'}" style="width:220px"/>`;
      else if (type === 'media') target = `<select class="rv-input sm" data-lg-to="${from}">${MEDIA.map(([v, n]) => `<option value="${v}" ${r.to === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
      else if (type === 'macro') target = `<button class="rv-btn sm primary" data-lg-macro="${from}">Makro bearbeiten</button><small class="rv-muted">${esc(ME?.summary(r.to) || '')}</small>`;
      else if (type === 'off') target = '<small class="rv-muted">Taste macht nichts mehr</small>';
      return `<div class="lg-row"><b>${esc(label)}</b><select class="rv-input sm" data-lg-type="${from}">${TYPE_NAMES.map(([v, n]) => `<option value="${v}" ${type === v ? 'selected' : ''}>${n}</option>`).join('')}</select><span class="lg-target">${target}</span>${/^F/.test(from) ? `<button class="rv-btn sm ghost" data-lg-remove="${from}">✕</button>` : ''}</div>`;
    }).join('');
  }
  function lgPaint() {
    if (!lg.root) return;
    const c = kbCfg();
    const st = lg.status;
    const mice = lg.mice?.mice || [];
    lg.root.innerHTML = `<div class="dv">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">Maus-Studio</h2><p class="rv-sub">Für Logitech und jede andere Maus – direkt im Hub, ohne G HUB.</p></div>
        <div class="rv-row"><span class="rv-pill">${!c.enabled ? 'Belegung aus' : st?.error ? esc(st.error) : st?.running ? `Aktiv · ${st.rules} Regeln` : 'Bereit'}</span><button class="rv-btn sm ${c.enabled ? 'on' : ''}" data-lg-master>${c.enabled ? 'An' : 'Aus'}</button></div></div>
        <div class="dv-devs">${lg.mice ? (mice.length ? mice.map((m) => `<span class="dv-dev ${m.logitech ? 'lg' : ''}">🖱️ ${esc(m.name)}<small>${esc(m.vendor)}${m.vid ? ` · ${m.vid}:${m.pid}` : ''}</small></span>`).join('') : '<span class="rv-muted">Keine Maus erkannt.</span>') : '<span class="rv-muted">Suche Mäuse …</span>'}</div></div>
      <div class="rv-card"><b>Tasten belegen</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 10px">Links-/Rechtsklick bleiben immer normal. G-Tasten: in G HUB (Onboard-Speicher) auf F13–F24 legen – hier dann frei belegen.</p>
        <div class="lg-rows">${lgRows(c)}</div>
        <div class="rv-row" style="margin-top:10px"><button class="rv-btn sm ${lg.capture?.what === 'gkey' ? 'on' : ''}" data-lg-addg>${lg.capture?.what === 'gkey' ? 'G-Taste drücken …' : '＋ G-Taste / Extra-Taste'}</button></div></div>
      <div class="dv-cols">
        <div class="rv-card"><b>Tastentest</b><div class="lg-test" data-lg-test>${lg.lastBtn ? `Erkannt: <b>${esc(lg.lastBtn)}</b>` : 'Hier mit einer Maustaste klicken'}</div></div>
        <div class="rv-card"><b>Licht & DPI</b><p class="rv-muted" style="font-size:12.5px;margin:6px 0 10px">Licht: über PC-RGB (OpenRGB unterstützt viele Logitech-Mäuse). DPI und Onboard-Profile speichert nur Logitechs eigenes Protokoll${lg.mice?.ghub ? ' – G HUB ist installiert.' : '.'}</p><div class="rv-row"><button class="rv-btn sm" data-lg-rgb>PC-RGB öffnen</button>${lg.mice?.ghub ? '<button class="rv-btn sm ghost" data-lg-ghub>G HUB öffnen</button>' : ''}</div></div>
      </div>
    </div>`;
  }
  async function lgUpdate(fn) {
    const c = kbCfg();
    fn(c);
    try {
      lg.status = await kbSave(c);
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    lgPaint();
  }
  document.addEventListener('click', (e) => {
    if (!lg.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    if (q('[data-lg-master]')) {
      const c = kbCfg();
      c.enabled = !c.enabled;
      return kbSave(c, false).then((s) => ((lg.status = s), lgPaint()));
    }
    const cap = q('[data-lg-cap]');
    if (cap) {
      lg.capture = { from: cap.dataset.from, what: cap.dataset.lgCap, keys: [] };
      return lgPaint();
    }
    if (q('[data-lg-addg]')) {
      lg.capture = lg.capture?.what === 'gkey' ? null : { what: 'gkey' };
      return lgPaint();
    }
    const rm = q('[data-lg-remove]')?.dataset.lgRemove;
    if (rm) {
      lg.extra = lg.extra.filter((x) => x !== rm);
      return lgUpdate((c) => setRule(c, rm, null));
    }
    const mac = q('[data-lg-macro]')?.dataset.lgMacro;
    if (mac) {
      const r = findRule(kbCfg(), mac);
      return ME?.open({ steps: r?.to || [], title: `Makro für ${mac}`, onSave: (steps) => lgUpdate((c) => setRule(c, mac, { type: 'macro', to: steps })) });
    }
    if (q('[data-lg-rgb]')) {
      window.__kbOpenTab?.('rgb');
      return window.hub.open('tool-keyboard');
    }
    if (q('[data-lg-ghub]')) return window.hub.keyboard.openTool('ghub').catch((err) => A.toast(A.errText(err), 'error'));
  });
  document.addEventListener('mousedown', (e) => {
    if (!lg.root?.contains(e.target) || !e.target.closest('[data-lg-test]')) return;
    e.preventDefault();
    lg.lastBtn = ['Linksklick', 'Mittlere Taste', 'Rechtsklick', 'Seitentaste hinten (Zurück)', 'Seitentaste vorne (Vor)'][e.button] || `Taste ${e.button}`;
    const t = lg.root.querySelector('[data-lg-test]');
    if (t) t.innerHTML = `Erkannt: <b>${esc(lg.lastBtn)}</b>`;
  });
  document.addEventListener('contextmenu', (e) => lg.root?.contains(e.target) && e.target.closest('[data-lg-test]') && e.preventDefault());
  document.addEventListener('change', (e) => {
    if (!lg.root?.contains(e.target)) return;
    const ty = e.target.dataset.lgType;
    if (ty != null) {
      const v = e.target.value;
      return lgUpdate((c) => setRule(c, ty, v ? { type: v, to: v === 'combo' || v === 'macro' ? [] : v === 'media' ? 'play' : '' } : null));
    }
    const to = e.target.dataset.lgTo;
    if (to != null) {
      const val = e.target.value;
      return lgUpdate((c) => {
        const r = findRule(c, to);
        if (r) r.to = val;
      });
    }
  });
  document.addEventListener('keydown', (e) => {
    if (!lg.root || !document.contains(lg.root) || !lg.capture) return;
    e.preventDefault();
    e.stopPropagation();
    const cp = lg.capture;
    if (cp.what === 'gkey') {
      lg.capture = null;
      if (!/^F\d+$/.test(e.code)) {
        A.toast(`„${e.code}“ ist keine Extra-Taste. Lege die G-Taste in G HUB auf F13–F24.`, 'error');
        return lgPaint();
      }
      if (!lg.extra.includes(e.code)) lg.extra.push(e.code);
      return lgPaint();
    }
    if (cp.what === 'to') {
      lg.capture = null;
      return lgUpdate((c) => {
        const r = findRule(c, cp.from);
        if (r) r.to = e.code;
      });
    }
    if (cp.what === 'combo' && !e.repeat) cp.keys.push(e.code);
  }, true);
  document.addEventListener('keyup', (e) => {
    const cp = lg.capture;
    if (!cp || cp.what !== 'combo' || !lg.root) return;
    e.preventDefault();
    lg.capture = null;
    const keys = [...new Set(cp.keys)].slice(0, 5);
    lgUpdate((c) => {
      const r = findRule(c, cp.from);
      if (r) r.to = keys;
    });
  }, true);
  A.define('tool-logitech', { nav: 'Maus-Studio', title: 'Maus-Studio', sub: 'Logitech & jede Maus belegen', icon: 'pointer', tint: 'linear-gradient(135deg,#22d3ee,#1e3a8a)', desc: 'Mittlere Taste, Seitentasten und G-Tasten frei belegen – mit Tasten, Kombinationen, Text, Programmen, Medien oder Makros mit eigenen Abständen. Ohne G HUB.' }, {
    mount(root) {
      lg.root = root;
      lgPaint();
      window.hub.keyboard.status().then((s) => ((lg.status = s), lgPaint())).catch(() => {});
      window.hub.keyboard.mice().then((m) => ((lg.mice = m), lgPaint())).catch(() => ((lg.mice = { mice: [] }), lgPaint()));
    },
    unmount() {
      lg.root = null;
      lg.capture = null;
    },
  });

  /* ================================================================ AJAZZ-Studio (Weiterleitung) */
  A.define('tool-ajazz', { nav: 'AJAZZ-Studio', title: 'AJAZZ-Studio', sub: 'AK820 Pro: Licht, Display, Tasten', icon: 'keyboard', tint: 'linear-gradient(135deg,#a78bfa,#4c1d95)', desc: 'Alles für deine AJAZZ AK820 Pro wie in der Hersteller-Software: Licht-Effekte, Display mit GIFs und Vorlagen, Uhr, Akku und Tastenbelegung.' }, {
    mount(root) {
      root.innerHTML = '<div class="rv-empty">AJAZZ-Studio wird geöffnet …</div>';
      window.__kbOpenTab?.('light');
      setTimeout(() => window.hub.open('tool-keyboard'), 60);
    },
  });

  /* ================================================================ Stream-Deck-Studio */
  const DECK_ACTIONS = [
    ['none', 'Keine Aktion'], ['media', 'Spotify / Medien'], ['screenshot', 'Screenshot'], ['sound', 'Soundboard-Sound'], ['open', 'Webseite / Programm öffnen'], ['app', 'Hub-App öffnen'], ['crosshair', 'Crosshair an/aus'], ['lock', 'PC sperren'], ['timer', 'Timer starten'], ['multi', 'Mehrere Aktionen (Kette)'],
  ];
  const ICONS = ['▶️', '⏭️', '⏮️', '🔇', '📸', '🔊', '🎵', '🌐', '💬', '🎮', '🎯', '🔒', '⏱️', '⭐', '🔥', '💡', '📁', '🖥️', '🎬', '🎤', '🎧', '🚀', '❤️', '😂', '👏', '🥁', '📣', '⚡'];
  const dk = { root: null, data: null, page: 0, sel: null, capture: false, loaded: false };
  const blankDeck = () => ({ cols: 5, rows: 3, pages: [{ name: 'Seite 1', buttons: {} }] });
  async function dkLoad() {
    if (dk.loaded) return;
    dk.loaded = true;
    dk.data = (await A.store.get('streamdeck', null)) || blankDeck();
    if (!dk.data.pages?.length) dk.data = blankDeck();
    // Beispielbelegung für den ersten Start
    const b = dk.data.pages[0].buttons;
    if (!Object.keys(b).length) {
      Object.assign(b, {
        0: { id: 'd1', icon: '⏯️', label: 'Play/Pause', color: '#1db954', action: { type: 'media', key: 'playpause' } },
        1: { id: 'd2', icon: '⏭️', label: 'Weiter', color: '#1db954', action: { type: 'media', key: 'next' } },
        2: { id: 'd3', icon: '📸', label: 'Screenshot', color: '#0a84ff', action: { type: 'screenshot' } },
        3: { id: 'd4', icon: '🔊', label: 'Sound 1', color: '#ff9f0a', action: { type: 'sound', pad: 0 } },
        4: { id: 'd5', icon: '🎯', label: 'Crosshair', color: '#ff375f', action: { type: 'crosshair' } },
      });
    }
  }
  const dkSave = () => A.store.set('streamdeck', dk.data);
  const page = () => dk.data.pages[dk.page];
  const selBtn = () => (dk.sel != null ? page().buttons[dk.sel] : null);
  async function runAction(a) {
    if (!a) return;
    try {
      switch (a.type) {
        case 'media': return await window.hub.cc.media(a.key || 'playpause');
        case 'screenshot': return await window.hub.cc.screenshot();
        case 'sound': {
          const src = await window.hub.widgetSound.data(Number(a.pad) || 0);
          if (!src) return A.toast(`Soundboard-Platz ${(Number(a.pad) || 0) + 1} ist leer – wähle einen Sound.`, 'error');
          const au = new Audio(src);
          au.volume = Math.max(0, Math.min(1, Number(a.volume ?? 1)));
          return au.play();
        }
        case 'open': return await window.hub.deck.run(a.target);
        case 'app': return await window.hub.open(a.app || 'home');
        case 'crosshair': return await window.hub.crosshair.toggle();
        case 'lock': return await window.hub.cc.lock();
        case 'timer': return await window.hub.cc.timerIsland(Math.max(1, Number(a.minutes) || 5) * 60, a.label || 'Timer');
        case 'multi':
          for (const step of a.steps || []) {
            await runAction(step);
            await new Promise((r) => setTimeout(r, Math.max(0, Number(step.after) || 150)));
          }
          return null;
        default: return null;
      }
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    return null;
  }
  // Hardware-Tasten (über die Tastatur-Engine) lösen Deck-Tasten aus
  window.hub.deck?.onAction?.(async (id) => {
    if (!String(id).startsWith('deck-')) return;
    await dkLoad();
    const bid = String(id).slice(5);
    for (const p of dk.data.pages) for (const b of Object.values(p.buttons)) if (b?.id === bid) return runAction(b.action);
    return null;
  });
  function actionForm(b) {
    const a = b.action || { type: 'none' };
    const pad = `<select class="rv-input sm" data-dk-act="pad">${Array.from({ length: 8 }, (_, i) => `<option value="${i}" ${Number(a.pad) === i ? 'selected' : ''}>Platz ${i + 1}</option>`).join('')}</select><button class="rv-btn sm" data-dk-pick>Sound wählen …</button>`;
    const apps = Object.entries({ ...window.HubTools.TOOLS }).map(([k, v]) => [k, v.title]).concat([['gaming', 'Gaming Hub'], ['chats', 'Chats'], ['docs', 'Dokumente'], ['video', 'Video-Schnitt'], ['chess', 'Schach'], ['geo', 'GeoRevulution']]);
    let extra = '';
    if (a.type === 'media') extra = `<select class="rv-input sm" data-dk-act="key">${[['playpause', 'Play / Pause'], ['next', 'Nächster Titel'], ['prev', 'Vorheriger Titel'], ['mute', 'Stumm']].map(([v, n]) => `<option value="${v}" ${a.key === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
    else if (a.type === 'sound') extra = `${pad}<label class="rv-muted">Lautstärke <input type="range" min="0" max="1" step="0.05" value="${a.volume ?? 1}" data-dk-act="volume"/></label><small class="rv-muted">Gleiche Plätze wie im Soundboard-Widget.</small>`;
    else if (a.type === 'open') extra = `<input class="rv-input sm" data-dk-act="target" value="${esc(a.target || '')}" placeholder="https://open.spotify.com oder C:\\Programm.exe" style="width:100%"/>`;
    else if (a.type === 'app') extra = `<select class="rv-input sm" data-dk-act="app">${apps.map(([k, n]) => `<option value="${k}" ${a.app === k ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>`;
    else if (a.type === 'timer') extra = `<label class="rv-muted">Minuten <input class="rv-input sm" type="number" min="1" max="600" value="${a.minutes || 5}" data-dk-act="minutes" style="width:80px"/></label>`;
    else if (a.type === 'multi') extra = `<div class="dk-chain">${(a.steps || []).map((s, i) => `<div class="rv-row"><span class="rv-pill">${i + 1}. ${esc(DECK_ACTIONS.find((x) => x[0] === s.type)?.[1] || s.type)}${s.type === 'media' ? ` · ${esc(s.key)}` : s.type === 'sound' ? ` · Platz ${(Number(s.pad) || 0) + 1}` : ''}</span><label class="rv-muted">danach <input class="rv-input sm" type="number" min="0" max="10000" step="50" value="${s.after ?? 150}" data-dk-chainafter="${i}" style="width:80px"/> ms</label><button class="rv-btn sm ghost" data-dk-chaindel="${i}">✕</button></div>`).join('')}
      <div class="rv-row"><select class="rv-input sm" data-dk-chainadd><option value="">＋ Schritt hinzufügen …</option>${DECK_ACTIONS.filter(([k]) => !['none', 'multi'].includes(k)).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></div></div>`;
    return extra;
  }
  function dkPaint() {
    if (!dk.root || !dk.data) return;
    const d = dk.data;
    const p = page();
    const b = selBtn();
    const cells = [];
    for (let i = 0; i < d.cols * d.rows; i++) {
      const x = p.buttons[i];
      cells.push(`<button class="dk-key ${dk.sel === i ? 'sel' : ''} ${x ? '' : 'empty'}" data-dk-key="${i}" style="--c:${esc(x?.color || '#2c2c34')}">${x ? `<span class="dk-ic">${esc(x.icon || '⭐')}</span><small>${esc(x.label || '')}</small>${x.hotkey ? `<i class="dk-hk">${esc(x.hotkey)}</i>` : ''}` : '<span class="dk-plus">＋</span>'}</button>`);
    }
    dk.root.innerHTML = `<div class="dv dk">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">Stream-Deck-Studio</h2><p class="rv-sub">Klicken = ausprobieren. Rechts einstellen. Mit „Hardware-Taste“ löst auch dein Deck (z. B. F13–F24) die Aktion aus.</p></div>
        <div class="rv-row"><div class="rv-tabs">${d.pages.map((pg, i) => `<button class="${i === dk.page ? 'on' : ''}" data-dk-page="${i}">${esc(pg.name)}</button>`).join('')}<button data-dk-addpage>＋</button></div>
        <select class="rv-input sm" data-dk-size>${[[3, 2], [5, 3], [8, 4]].map(([c, r]) => `<option value="${c}x${r}" ${d.cols === c && d.rows === r ? 'selected' : ''}>${c} × ${r}</option>`).join('')}</select></div></div></div>
      <div class="rv-card dk-ulanzi"><div class="rv-row between"><div><b>Ulanzi-Stream-Deck verbinden</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">1. In Ulanzi Studio eine Taste auf die Aktion „Hotkey“ legen und F13–F24 wählen. 2. Hier die Deck-Taste anklicken → „Hardware-Taste“ → die Taste am Ulanzi drücken. Ab dann löst das Ulanzi die Hub-Aktion aus (Spotify, Screenshot, Sounds …). Symbol und Bild der Ulanzi-Taste stellst du in Ulanzi Studio ein.</p></div>
        <button class="rv-btn sm" data-dk-ulanzi>Ulanzi Studio öffnen</button></div></div>
      <div class="dk-wrap"><div class="dk-grid" style="grid-template-columns:repeat(${d.cols},1fr)">${cells.join('')}</div>
      <aside class="rv-card dk-side">${b ? `<b>Taste ${dk.sel + 1}</b>
        <label>Beschriftung<input class="rv-input sm" data-dk-field="label" value="${esc(b.label || '')}" maxlength="20"/></label>
        <label>Symbol<div class="dk-icons">${ICONS.map((ic) => `<button class="dk-ico ${b.icon === ic ? 'on' : ''}" data-dk-icon="${ic}">${ic}</button>`).join('')}</div></label>
        <label class="rv-row between">Farbe<input type="color" value="${esc(b.color || '#2c2c34')}" data-dk-field="color"/></label>
        <label>Aktion<select class="rv-input sm" data-dk-type>${DECK_ACTIONS.map(([k, n]) => `<option value="${k}" ${b.action?.type === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <div class="dk-act">${actionForm(b)}</div>
        <label>Hardware-Taste<div class="rv-row"><button class="rv-btn sm ${dk.capture ? 'on' : ''}" data-dk-hotkey>${dk.capture ? 'Taste am Deck drücken …' : b.hotkey ? esc(b.hotkey) : 'Zuweisen'}</button>${b.hotkey ? '<button class="rv-btn sm ghost" data-dk-hotkeydel>✕</button>' : ''}</div></label>
        <div class="rv-row"><button class="rv-btn sm primary" data-dk-test>▶ Testen</button><button class="rv-btn sm danger" data-dk-del>Taste leeren</button></div>`
        : '<b>Taste wählen</b><p class="rv-muted">Klicke eine leere Taste (＋), um sie zu belegen. Ein Klick auf eine belegte Taste führt sie aus und öffnet ihre Einstellungen.</p>'}</aside></div>
    </div>`;
  }
  async function hotkeyRule(b, code) {
    const c = kbCfg();
    if (b.hotkey) setRule(c, b.hotkey, null);
    if (code) setRule(c, code, { type: 'hub', to: `deck-${b.id}` });
    b.hotkey = code || '';
    dkSave();
    try {
      await kbSave(c, Boolean(code) || c.enabled);
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    dkPaint();
  }
  document.addEventListener('click', async (e) => {
    if (!dk.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const key = q('[data-dk-key]')?.dataset.dkKey;
    if (key != null) {
      const i = Number(key);
      if (!page().buttons[i]) page().buttons[i] = { id: Math.random().toString(36).slice(2, 8), icon: '⭐', label: 'Neu', color: '#5e5ce6', action: { type: 'none' } };
      else runAction(page().buttons[i].action);
      const el = q('[data-dk-key]');
      el.classList.remove('press');
      void el.offsetWidth;
      el.classList.add('press');
      dk.sel = i;
      dkSave();
      return setTimeout(dkPaint, 120);
    }
    if (q('[data-dk-ulanzi]')) return window.hub.keyboard.openTool('ulanzi').catch(() => window.hub.external('https://www.ulanzi.com/pages/download'));
    const pg = q('[data-dk-page]')?.dataset.dkPage;
    if (pg != null) {
      dk.page = Number(pg);
      dk.sel = null;
      return dkPaint();
    }
    if (q('[data-dk-addpage]')) {
      dk.data.pages.push({ name: `Seite ${dk.data.pages.length + 1}`, buttons: {} });
      dk.page = dk.data.pages.length - 1;
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    const ic = q('[data-dk-icon]')?.dataset.dkIcon;
    if (ic) {
      b.icon = ic;
      dkSave();
      return dkPaint();
    }
    if (q('[data-dk-test]')) return runAction(b.action);
    if (q('[data-dk-del]')) {
      if (b.hotkey) await hotkeyRule(b, '');
      delete page().buttons[dk.sel];
      dk.sel = null;
      dkSave();
      return dkPaint();
    }
    if (q('[data-dk-pick]')) {
      const pad = Number(b.action.pad) || 0;
      const name = await window.hub.widgetSound.pick(pad).catch((err) => A.toast(A.errText(err), 'error'));
      if (name) {
        b.label = String(name).replace(/\.[^.]+$/, '').slice(0, 20);
        dkSave();
        dkPaint();
        A.toast(`„${name}“ liegt jetzt auf Platz ${pad + 1} – auch im Soundboard-Widget.`);
      }
      return;
    }
    if (q('[data-dk-hotkey]')) {
      dk.capture = !dk.capture;
      return dkPaint();
    }
    if (q('[data-dk-hotkeydel]')) return hotkeyRule(b, '');
    const cd = q('[data-dk-chaindel]')?.dataset.dkChaindel;
    if (cd != null) {
      b.action.steps.splice(Number(cd), 1);
      dkSave();
      return dkPaint();
    }
  });
  document.addEventListener('change', (e) => {
    if (!dk.root?.contains(e.target)) return;
    const t = e.target;
    if (t.matches('[data-dk-size]')) {
      const [c, r] = t.value.split('x').map(Number);
      Object.assign(dk.data, { cols: c, rows: r });
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    if (t.dataset.dkField) b[t.dataset.dkField] = t.value;
    else if (t.matches('[data-dk-type]')) b.action = { type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'sound' ? { pad: 0, volume: 1 } : t.value === 'multi' ? { steps: [] } : {}) };
    else if (t.dataset.dkAct) b.action[t.dataset.dkAct] = t.type === 'range' || t.type === 'number' || t.dataset.dkAct === 'pad' ? Number(t.value) : t.value;
    else if (t.matches('[data-dk-chainadd]') && t.value) b.action.steps.push({ type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'sound' ? { pad: 0 } : {}), after: 150 });
    else if (t.dataset.dkChainafter != null) b.action.steps[Number(t.dataset.dkChainafter)].after = Number(t.value) || 0;
    dkSave();
    dkPaint();
  });
  document.addEventListener('keydown', (e) => {
    if (!dk.capture || !dk.root || !document.contains(dk.root)) return;
    e.preventDefault();
    e.stopPropagation();
    dk.capture = false;
    const b = selBtn();
    if (!b) return dkPaint();
    if (['Escape'].includes(e.code)) return dkPaint();
    if (!/^F(1[3-9]|2[0-4])$/.test(e.code) && !window.confirm(`„${e.code}“ ist eine normale Taste – sie würde dann überall nur noch diese Deck-Aktion auslösen. Trotzdem verwenden?`)) return dkPaint();
    hotkeyRule(b, e.code);
  }, true);
  A.define('tool-streamdeck', { nav: 'Stream-Deck', title: 'Stream-Deck-Studio', sub: 'Tasten für Spotify, Screenshots, Sounds', icon: 'grid', tint: 'linear-gradient(135deg,#818cf8,#312e81)', desc: 'Dein Stream Deck im Hub: Spotify/Medien, Screenshot, Soundboard-Sounds, Apps, Webseiten, Crosshair und Ketten – per Klick oder über Hardware-Tasten (F13–F24).' }, {
    async mount(root) {
      dk.root = root;
      root.innerHTML = '<div class="rv-empty">Lädt …</div>';
      await dkLoad();
      if (dk.root === root) dkPaint();
    },
    unmount() {
      dk.root = null;
      dk.capture = false;
    },
  });

  /* ================================================================ Clips (eigene App, Engine im Gaming Hub) */
  window.HubTools.register('tool-clips', { nav: 'Clips', title: 'Clips', sub: 'Aufnehmen, Highlights, Facecam', icon: 'camera', tint: 'linear-gradient(135deg,#fb7185,#9f1239)', desc: 'Der Clipper: läuft im Hintergrund, speichert die letzten Sekunden per Hotkey, nimmt lange Aufnahmen auf, mit Facecam, Ton und Keystrokes – und alle Clips zum Ansehen und Schneiden.' }, () => '<div class="page"><div class="empty">Clips wird geöffnet …</div></div>');

  /* ================================================================ Lüfter */
  const fn = { root: null, st: null, timer: 0, busy: false };
  function fnPaint() {
    if (!fn.root) return;
    const s = fn.st;
    const pol = s?.policy?.ac === 'unknown' && fn.chosen ? fn.chosen : s?.policy?.ac;
    const fansList = (s?.sensors || []).filter((x) => x.type === 'Fan');
    const temps = (s?.sensors || []).filter((x) => x.type === 'Temperature');
    fn.root.innerHTML = `<div class="dv">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">Lüfter</h2><p class="rv-sub">Kühlung, Temperaturen und Lüfter auf einen Blick.</p></div><span class="rv-pill">${s ? `aktualisiert ${new Date(s.at).toLocaleTimeString('de-CH')}` : 'lädt …'}</span></div></div>
      <div class="rv-card"><b>Windows-Kühlrichtlinie</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 10px">Aktiv: Lüfter drehen zuerst hoch (kühler, lauter). Passiv: erst wird die CPU gedrosselt (leiser).</p>
        <div class="rv-tabs"><button class="${pol === 'active' ? 'on' : ''}" data-fn-pol="active">❄️ Aktiv – kühl</button><button class="${pol === 'passive' ? 'on' : ''}" data-fn-pol="passive">🤫 Passiv – leise</button></div>${pol === 'unknown' ? '<p class="rv-muted" style="font-size:12.5px">Windows blendet die aktuelle Einstellung in deinem Energieschema aus – Umschalten wirkt trotzdem.</p>' : ''}</div>
      <div class="dv-cols">
        <div class="rv-card"><b>Grafikkarte</b>${s?.gpus?.length ? s.gpus.map((g) => `<div class="fn-gpu"><span>${esc(g.name)}</span><div class="fn-meters"><div><small>Temperatur</small><b>${Number.isFinite(g.temp) ? `${Math.round(g.temp)}°C` : '–'}</b></div><div><small>Lüfter</small><b>${Number.isFinite(g.fan) ? `${g.fan} %${g.fan === 0 ? ' (steht)' : ''}` : '–'}</b></div><div><small>Last</small><b>${Number.isFinite(g.util) ? `${g.util} %` : '–'}</b></div><div><small>Leistung</small><b>${Number.isFinite(g.power) ? `${Math.round(g.power)} W` : '–'}</b></div></div></div>`).join('') : '<p class="rv-muted">Keine NVIDIA-Grafikkarte gefunden (Werte kommen von nvidia-smi).</p>'}</div>
        <div class="rv-card"><b>Mainboard-Lüfter</b>${fansList.length ? `<div class="fn-list">${fansList.map((f) => `<div><span>🌀 ${esc(f.name)}</span><b>${Math.round(f.value)} U/min</b></div>`).join('')}</div>` : '<p class="rv-muted">Drehzahlen liefert Windows nicht direkt. Läuft LibreHardwareMonitor, erscheinen sie hier automatisch.</p>'}
          ${temps.length ? `<b style="display:block;margin-top:10px">Temperaturen</b><div class="fn-list">${temps.slice(0, 12).map((t) => `<div><span>🌡️ ${esc(t.name)}</span><b>${Math.round(t.value)}°C</b></div>`).join('')}</div>` : ''}</div>
      </div>
      <div class="rv-card"><b>Drehzahl selbst einstellen</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 10px">Lüfterkurven pro Lüfter brauchen einen Treiber mit direktem Zugriff aufs Mainboard. Das kostenlose „Fan Control“ bringt ihn mit – der Hub öffnet es für dich.</p>
        <button class="rv-btn sm" data-fn-fc>${s?.fanControl ? 'Fan Control öffnen' : 'Fan Control herunterladen'}</button></div>
    </div>`;
  }
  async function fnLoad() {
    if (fn.busy) return;
    fn.busy = true;
    try {
      fn.st = await window.hub.fans.state();
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    fn.busy = false;
    fnPaint();
  }
  document.addEventListener('click', async (e) => {
    if (!fn.root?.contains(e.target)) return;
    const pol = e.target.closest('[data-fn-pol]')?.dataset.fnPol;
    if (pol) {
      try {
        const res = await window.hub.fans.policy(pol);
        // Ausgeblendete Einstellung: Windows meldet sie nicht zurück → die eigene Wahl anzeigen
        fn.chosen = pol;
        fn.st.policy = res;
        A.toast(pol === 'active' ? 'Kühlung: aktiv (Lüfter zuerst).' : 'Kühlung: passiv (leiser).');
      } catch (err) {
        A.toast(A.errText(err), 'error');
      }
      return fnPaint();
    }
    if (e.target.closest('[data-fn-fc]')) window.hub.fans.openFanControl(fn.st?.fanControl || '');
  });
  A.define('tool-fans', { nav: 'Lüfter', title: 'Lüfter', sub: 'Kühlung & Temperaturen', icon: 'refresh', tint: 'linear-gradient(135deg,#67e8f9,#0e7490)', desc: 'Windows-Kühlrichtlinie umschalten (kühl oder leise), Grafikkarten-Lüfter und -Temperatur, Mainboard-Lüfter und Fan Control mit einem Klick.' }, {
    mount(root) {
      fn.root = root;
      fnPaint();
      fnLoad();
      clearInterval(fn.timer);
      fn.timer = setInterval(fnLoad, 5000);
    },
    unmount() {
      clearInterval(fn.timer);
      fn.root = null;
    },
  });
})();
