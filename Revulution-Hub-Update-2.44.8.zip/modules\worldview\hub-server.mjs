import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { localProviderPlugins } from './server/providers/local.js';
import { apiNotFoundPlugin } from './server/standalone/api-not-found.js';
import { googleTokenUnavailablePlugin } from './server/standalone/google-token-unavailable.js';

const root = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(root, 'dist');
const handlers = [];
const middleware = {
  use(route, handler) {
    if (typeof route === 'function') { handler = route; route = ''; }
    handlers.push({ route, handler });
  },
};
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.wasm': 'application/wasm', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2', '.glb': 'model/gltf-binary', '.geojsonl': 'application/octet-stream' };
const server = http.createServer((req, res) => {
  const host = req.headers.host || '';
  const site = req.headers['sec-fetch-site'];
  if (host !== `127.0.0.1:${server.address().port}` || (site && site !== 'same-origin' && site !== 'none') || (req.headers.origin && req.headers.origin !== `http://${host}`)) {
    res.writeHead(403).end(); return;
  }
  res.setHeader('X-Content-Type-Options', 'nosniff');
  const pathname = (req.url || '').split('?')[0];
  if (/^\/api\/(?:transit|rail|vessels|firms|mapillary|tomtom)(?:\/|$)/i.test(pathname)) {
    res.writeHead(404).end(); return;
  }
  let index = 0;
  function next(error) {
    if (error) { console.error(error); if (!res.headersSent) res.writeHead(500); res.end(); return; }
    const item = handlers[index++];
    if (item) {
      const pathname = req.url.split('?')[0];
      if (item.route && !(pathname === item.route || pathname.startsWith(item.route + '/'))) return next();
      const original = req.url;
      if (item.route) {
        req.url = req.url.slice(item.route.length) || '/';
        if (req.url.startsWith('?')) req.url = '/' + req.url;
      }
      try {
        Promise.resolve(item.handler(req, res, (err) => { req.url = original; next(err); })).catch(next);
      } catch (err) { next(err); }
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405).end(); return; }
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, `http://${host}`).pathname); } catch { res.writeHead(400).end(); return; }
    const target = path.resolve(dist, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!target.startsWith(dist + path.sep)) { res.writeHead(403).end(); return; }
    fs.stat(target, (err, stat) => {
      if (err || !stat.isFile()) { res.writeHead(404).end(); return; }
      res.setHeader('Content-Type', types[path.extname(target).toLowerCase()] || 'application/octet-stream');
      if (pathname === '/') res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-eval' blob: https://www.youtube.com https://connect.facebook.net https://platform.twitter.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob: https:; media-src 'self' blob: https:; connect-src 'self' blob: data: https: wss: ws:; worker-src 'self' blob:; child-src 'self' blob:; frame-src 'self' blob: https://www.youtube-nocookie.com https://www.youtube.com https://www.facebook.com https://platform.twitter.com; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
      if (req.method === 'HEAD') { res.end(); return; }
      fs.createReadStream(target).on('error', () => res.destroy()).pipe(res);
    });
  }
  next();
});
const context = { middlewares: middleware, httpServer: server };
for (const plugin of [...localProviderPlugins(), googleTokenUnavailablePlugin(), apiNotFoundPlugin()]) {
  if (['openai', 'gemini', 'gev-key-setup'].some((name) => String(plugin.name || '').toLowerCase().includes(name))) continue;
  plugin.configurePreviewServer?.(context);
}
server.listen(0, '127.0.0.1', () => { if (process.send) process.send({ port: server.address().port }); });
process.on('disconnect', () => server.close(() => process.exit(0)));
