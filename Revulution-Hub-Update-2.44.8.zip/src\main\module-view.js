'use strict';

/**
 * A module's "main window", hosted as a view inside the hub window.
 *
 * The modules still talk to it like a BrowserWindow (load, show, send, minimize…); this
 * class implements that surface and forwards window-level calls to the hub window.
 */

const { WebContentsView } = require('electron');
const { EventEmitter } = require('events');
const fs = require('fs');
const path = require('path');
const { wrapWindowOptions, MODULE_PRELOAD } = require('./shim');

// The shared design layer is injected after each app's own stylesheet so every
// module keeps its layout but follows the same glass, light and motion rules.
const DESIGN_CSS = (() => {
  try {
    return fs.readFileSync(path.join(__dirname, '..', 'shared', 'design-system.css'), 'utf8');
  } catch {
    return '';
  }
})();

/** Events that belong to the real window and are forwarded from the hub window. */
const WINDOW_EVENTS = new Set(['maximize', 'unmaximize', 'minimize', 'restore', 'focus', 'blur', 'move', 'moved', 'resize', 'resized', 'enter-full-screen', 'leave-full-screen']);

class ModuleView extends EventEmitter {
  constructor(hub, mod, options = {}) {
    super();
    this.__isModuleView = true;
    this.hub = hub;
    this.mod = mod;
    this.pendingLoad = null;
    this.shownOnce = false;
    this.ready = false;

    const { webPreferences } = wrapWindowOptions(mod, options);
    webPreferences.additionalArguments = [...(webPreferences.additionalArguments || []), '--hub-view', `--hub-module=${mod.id}`];
    if (!webPreferences.preload) {
      webPreferences.preload = MODULE_PRELOAD;
      webPreferences.sandbox = false;
    }
    // Nur Aufnahmen (Gaming Hub) und Anrufe (Chats) müssen versteckt ungebremst weiterlaufen.
    webPreferences.backgroundThrottling = mod.id === 'gaming' || mod.id === 'chats' ? false : webPreferences.backgroundThrottling !== false;
    this.view = new WebContentsView({ webPreferences });
    // Transparent: the hub draws one live wallpaper behind every app.
    this.view.setBackgroundColor('#00000000');
    this.view.setVisible(false);
    this.webContents = this.view.webContents;
    this.id = this.webContents.id;
    // Video im Vollbild in einer App: die untere Leiste soll dann verschwinden.
    this.webContents.on('enter-html-full-screen', () => hub.onModuleFullscreen?.(true));
    this.webContents.on('leave-html-full-screen', () => hub.onModuleFullscreen?.(false));

    this.webContents.on('dom-ready', () => {
      (async () => {
        try {
          if (mod.css && mod.id !== 'worldview') await this.webContents.insertCSS(mod.css);
          // A <style> element is author CSS, so it wins over the app's own
          // stylesheet. insertCSS() would be a user sheet and lose the cascade.
          if (DESIGN_CSS) {
            await this.webContents.executeJavaScript(
              `(() => { const old = document.querySelector('style[data-nt-design]'); if (old) old.remove(); const style = document.createElement('style'); style.dataset.ntDesign = '1'; style.textContent = ${JSON.stringify(DESIGN_CSS)}; document.head.appendChild(style); })()`,
              true,
            );
          }
          // Weltansicht's complete theme must follow the shared design in the author cascade.
          if (mod.id === 'worldview' && mod.css && this.webContents.getURL().startsWith('http://127.0.0.1:')) {
            await this.webContents.executeJavaScript(
              `(() => { const old = document.querySelector('style[data-worldview-design]'); if (old) old.remove(); const style = document.createElement('style'); style.dataset.worldviewDesign = '1'; style.textContent = ${JSON.stringify(mod.css)}; document.head.appendChild(style); })()`,
              true,
            );
          }
        } catch {
          /* Seite kann während des Ladens ersetzt werden. */
        }
      })();
      if (mod.script) this.webContents.executeJavaScript(mod.script, true).catch(() => {});
      // Sprache: Apps mit eigener Übersetzung bekommen nur die Sprache, alle anderen den Übersetzer.
      if (mod.ownI18n) this.webContents.executeJavaScript(`window.__hubLang = ${JSON.stringify(hub.currentLang?.() || 'de')}; window.dispatchEvent(new CustomEvent('hub-lang', { detail: window.__hubLang }))`, true).catch(() => {});
      else if (hub.translatorScript) this.webContents.executeJavaScript(hub.translatorScript(), true).catch(() => {});
    });
    this.webContents.on('did-finish-load', () => {
      if (this.ready || this.webContents.getURL().startsWith('about:')) return;
      this.ready = true;
      this.emit('ready-to-show');
      if (hub.active === this.mod.id) hub.revealView(this);
      hub.pushState();
    });
    // 2.45: Abgestürzte oder hängende App-Seiten wieder laden – vorher blieb z. B. der Gaming Hub
    // dauerhaft leer, bis man den ganzen Hub neu startete.
    this.webContents.on('render-process-gone', (_event, details) => {
      console.error(`[hub] ${mod.id} renderer gone: ${details.reason}`);
      if (details.reason === 'clean-exit') return;
      this.recover('Absturz');
    });
    this.webContents.on('unresponsive', () => {
      clearTimeout(this.hangTimer);
      this.hangTimer = setTimeout(() => {
        if (this.webContents.isDestroyed()) return;
        console.error(`[hub] ${mod.id} hängt seit 10 s – wird neu geladen`);
        try {
          this.webContents.forcefullyCrashRenderer();
        } catch {
          /* egal */
        }
        this.recover('hängt');
      }, 10000);
    });
    this.webContents.on('responsive', () => clearTimeout(this.hangTimer));
    // Hauptseite konnte nicht geladen werden → neu versuchen (-3 = vom Hub selbst abgebrochen)
    this.webContents.on('did-fail-load', (_e, code, desc, _url, isMain) => {
      if (isMain && code !== -3) this.recover(`Ladefehler ${desc}`);
    });
    // Links that try to open new windows go to the default browser instead.
    this.webContents.on('did-create-window', (child) => child.setMenu?.(null));

    hub.attachView(this);
  }

  /* -------------------------------------------------------------- loading */
  loadFile(file, options) {
    return this.deferLoad(() => this.webContents.loadFile(file, options));
  }

  loadURL(url, options) {
    return this.deferLoad(() => this.webContents.loadURL(url, options));
  }

  /** Lazy modules only load their UI the first time the user opens them. */
  deferLoad(load) {
    this.lastLoad = load;
    if (this.mod.lazy && !this.hub.wasOpened(this.mod.id)) {
      this.pendingLoad = load;
      return Promise.resolve();
    }
    return load();
  }

  ensureLoaded() {
    if (!this.pendingLoad) return;
    const load = this.pendingLoad;
    this.pendingLoad = null;
    load().catch((error) => console.error(`[hub] ${this.mod.id} failed to load`, error));
  }

  /** Nach Absturz/Hänger neu laden – höchstens 3× pro Minute, damit keine Endlosschleife entsteht. */
  recover(reason) {
    if (!this.lastLoad || this.webContents.isDestroyed()) return;
    const now = Date.now();
    this.recoverLog = (this.recoverLog || []).filter((t) => now - t < 60000);
    if (this.recoverLog.length >= 3) return;
    this.recoverLog.push(now);
    this.ready = false;
    setTimeout(() => {
      if (this.webContents.isDestroyed()) return;
      console.error(`[hub] ${this.mod.id} wird wiederhergestellt (${reason})`);
      this.lastLoad().catch(() => {});
    }, 700);
  }

  /** App beenden: Seite verwerfen (spart RAM), beim nächsten Öffnen lädt sie neu. */
  unload() {
    if (!this.lastLoad || this.pendingLoad || this.webContents.isDestroyed()) return false;
    if (this.mod.id === 'worldview') this.emit('worldview-stop');
    this.pendingLoad = this.lastLoad;
    this.ready = false;
    this.webContents.loadURL('about:blank').catch(() => {});
    return true;
  }

  /* ------------------------------------------------------------ visibility */
  show() {
    // The first show() is the module's own "ready-to-show" reveal; the hub decides
    // which page is visible at start, so only later calls switch to the module.
    if (!this.shownOnce) {
      this.shownOnce = true;
      return;
    }
    this.hub.open(this.mod.id);
  }

  showInactive() {}

  focus() {
    this.hub.open(this.mod.id);
    this.webContents.focus();
  }

  hide() {
    this.hub.window?.hide();
  }

  isVisible() {
    return Boolean(this.hub.window?.isVisible() && this.hub.active === this.mod.id);
  }

  isFocused() {
    return Boolean(this.hub.window?.isFocused() && this.hub.active === this.mod.id);
  }

  isDestroyed() {
    return this.webContents.isDestroyed();
  }

  /* ------------------------------------------------- window-level forwards */
  minimize() {
    this.hub.window?.minimize();
  }
  maximize() {
    this.hub.window?.maximize();
  }
  unmaximize() {
    this.hub.window?.unmaximize();
  }
  isMaximized() {
    return Boolean(this.hub.window?.isMaximized());
  }
  isMinimized() {
    return Boolean(this.hub.window?.isMinimized());
  }
  restore() {
    this.hub.window?.restore();
  }
  close() {
    this.hub.window?.close();
  }
  isFullScreen() {
    return Boolean(this.hub.window?.isFullScreen());
  }
  setFullScreen(flag) {
    this.hub.window?.setFullScreen(flag);
  }
  getBounds() {
    return this.hub.window?.getBounds() || { x: 0, y: 0, width: 0, height: 0 };
  }
  getContentBounds() {
    return this.hub.window?.getContentBounds() || this.getBounds();
  }
  getNativeWindowHandle() {
    return this.hub.window?.getNativeWindowHandle();
  }
  setProgressBar(progress, options) {
    this.hub.window?.setProgressBar(progress, options);
  }
  flashFrame(flag) {
    this.hub.window?.flashFrame(flag);
  }
  setTitle() {}
  getTitle() {
    return this.mod.name;
  }
  setIcon() {}
  setMenu() {}
  removeMenu() {}
  setMenuBarVisibility() {}
  setAutoHideMenuBar() {}
  setAlwaysOnTop() {}
  setSkipTaskbar() {}
  center() {}
  setBounds() {}
  setSize() {}
  setMinimumSize() {}
  destroy() {}

  /* ---------------------------------------------------------------- events */
  on(event, listener) {
    if (WINDOW_EVENTS.has(event)) this.hub.window?.on(event, listener);
    else super.on(event, listener);
    return this;
  }

  addListener(event, listener) {
    return this.on(event, listener);
  }

  once(event, listener) {
    if (WINDOW_EVENTS.has(event)) this.hub.window?.once(event, listener);
    else super.once(event, listener);
    return this;
  }
}

module.exports = { ModuleView };
