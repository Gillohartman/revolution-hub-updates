'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.15.1',
  title: 'Revulution Hub 2.15.1',
  sub: 'Klick auf einen Eintrag – du landest direkt dort. Oben links kommst du jederzeit hierher zurück.',
  items: [
    { open: 'chats', icon: 'chat', title: 'Anrufe & neue Töne', text: 'In Direktnachrichten anrufen und annehmen – mit Ringtone 048, Stummschalten und Auflegen. Dazu die neuen Nachrichtentöne 053 und 054 in den Chat-Einstellungen.' },
    { open: 'beat', icon: 'music', title: 'Beat Lab ist da', text: 'Drums, Bass und Lead im Step-Sequencer: 5 Kits, 4 Patterns, Piano Roll, Mixer, Effekte, Song-Kette und WAV-Export.' },
    { open: 'video', icon: 'film', title: 'Video: Resolve-Farbseite', text: 'Color Wheels für Schatten, Mitten und Lichter, Temperatur, Tint, Vibrance, Fade und ein RGB-Histogramm als Scope. Dazu Fairlight-Fader und Liefer-Presets für YouTube, TikTok, Reels, 4K, GIF und Audio.' },
    { open: 'tool-keyboard', icon: 'keyboard', title: 'RGB mit Live-Vorschau', text: 'Die RGB-Seite zeigt jetzt immer eine animierte Vorschau, auch ohne OpenRGB. Effekte und Farben lassen sich vorab wählen, und das Flackern beim Neuladen ist weg.' },
    { open: 'chess', icon: 'chess', title: 'Magnus-Stimme', text: 'Der Coach begrüßt weiter mit dem Original-Clip und spricht Tipps danach mit einer tiefen Männerstimme statt mit der Frauenstimme.' },
  ],
};
