'use strict';

/*
 * Echtes Liquid Glass: ein SVG-Filter, der den Hintergrund hinter einer Glasfläche an den
 * Rändern verzieht – wie Licht, das durch den Rand eines Wassertropfens gebrochen wird.
 * Die Verschiebungskarte wird einmal per Canvas erzeugt (Mitte neutral, Ränder ziehen nach innen)
 * und über backdrop-filter: url(#lg-refract) auf jede Glasfläche gestreckt.
 */
(function () {
  if (window.__revLiquid || typeof document === 'undefined') return;
  window.__revLiquid = true;

  function displacementMap(size = 256, edge = 0.22, radius = 0.32) {
    const c = document.createElement('canvas');
    c.width = c.height = size;
    const g = c.getContext('2d');
    const img = g.createImageData(size, size);
    const r = radius; // Eckenradius (normiert)
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const u = (x + 0.5) / size;
        const v = (y + 0.5) / size;
        // Abstand zum Rand einer abgerundeten Fläche (signed distance, normiert 0..0.5)
        const qx = Math.abs(u - 0.5) - (0.5 - r);
        const qy = Math.abs(v - 0.5) - (0.5 - r);
        const outside = Math.hypot(Math.max(qx, 0), Math.max(qy, 0));
        const inside = Math.min(Math.max(qx, qy), 0);
        const d = r - (outside + inside); // 0 am Rand, wächst nach innen
        let s = Math.max(0, 1 - d / edge);
        s = s * s * (3 - 2 * s); // weich auslaufen
        // Richtung: zur Mitte hin (wie eine Linse, die den Rand nach innen zieht)
        let nx = 0.5 - u;
        let ny = 0.5 - v;
        const len = Math.hypot(nx, ny) || 1;
        nx /= len;
        ny /= len;
        const i = (y * size + x) * 4;
        img.data[i] = 128 + nx * s * 127;
        img.data[i + 1] = 128 + ny * s * 127;
        img.data[i + 2] = 128;
        img.data[i + 3] = 255;
      }
    }
    g.putImageData(img, 0, 0);
    return c.toDataURL('image/png');
  }

  function install() {
    if (document.getElementById('lg-defs')) return;
    const map = displacementMap();
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.id = 'lg-defs';
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.setAttribute('aria-hidden', 'true');
    svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
    // zwei Stärken: kräftig für große Flächen, fein für kleine Knöpfe
    const filter = (id, scale) => `<filter id="${id}" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
        <feImage href="${map}" x="0" y="0" width="100%" height="100%" preserveAspectRatio="none" result="map"/>
        <feDisplacementMap in="SourceGraphic" in2="map" scale="${scale}" xChannelSelector="R" yChannelSelector="G" result="bent"/>
        <feGaussianBlur in="bent" stdDeviation="0.6"/>
      </filter>`;
    svg.innerHTML = `<defs>${filter('lg-refract', 46)}${filter('lg-refract-sm', 20)}</defs>`;
    document.body.appendChild(svg);
    document.documentElement.classList.add('lg-ready');
  }
  if (document.body) install();
  else document.addEventListener('DOMContentLoaded', install);
})();
