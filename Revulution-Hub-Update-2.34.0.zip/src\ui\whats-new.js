'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.34.0',
  title: 'Revulution Hub 2.34',
  sub: 'Liquid Glass überall, eine neue Hintergründe-App und ein flüssiges Dock.',
  items: [
    { open: 'home', icon: 'spark', title: 'Liquid Glass', text: 'Karten, Knöpfe, Leisten, Eingaben und Pop-ups bestehen jetzt aus durchscheinendem Glas mit Lichtkante – mit weichen Animationen beim Darüberfahren und Seitenwechsel.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Neue Hintergründe-App', text: 'Großes Live-Titelbild mit Karussell, Reihen zum Durchscrollen, Likes, Detailansicht und eine schwebende Player-Leiste.' },
    { open: 'home', icon: 'grid', title: 'Dock ohne Ruckeln', text: 'Das Dock vergrößert die Symbole jetzt flüssig und zeigt keine dunklen Kästen mehr.' },
    { open: 'home', icon: 'eye', title: 'Keine grauen Kästen mehr', text: 'Die grauen Windows-Hinweise beim Darüberfahren sind durch kleine Glas-Schilder ersetzt.' },
    { open: 'tool-store', icon: 'users', title: 'Anmeldung wird erkannt', text: 'Store und Hintergrund-Einreichen erkennen dein Konto jetzt sofort – auch direkt nach dem Start.' },
  ],
};
