'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.35.0',
  title: 'Revulution Hub 2.35',
  sub: 'Echtes Liquid Glass, ein neues Wetter-Widget und echte Likes.',
  items: [
    { open: 'home', icon: 'spark', title: 'Echtes Liquid Glass', text: 'Glasflächen sind jetzt durchsichtig, und an den Rändern wird der Hintergrund wie in einem Wassertropfen verzogen. Dazu ein langsam wandernder Glanz.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Hintergründe', text: 'Die Detailansicht füllt die ganze Seite, der Zurück-Pfeil sitzt oben in der Leiste. Neues Monitor-Fenster mit deinem Bild als Vorschau auf jedem Monitor.' },
    { open: 'tool-backgrounds', icon: 'users', title: 'Echte Likes', text: 'Die Herzen zählen jetzt echte Likes aller Nutzer aus der Datenbank (mit Konto).' },
    { open: 'tool-desktop', icon: 'sun', title: 'Neues Wetter-Widget', text: 'Ein runder Punktkreis wie beim Gesicht: Sonne mit drehenden Strahlen, ziehende Wolken, Regen, Schnee und Blitze.' },
    { open: 'tool-airplay', icon: 'camera', title: 'iPhone-Widget', text: 'Der Verbinden-Text verschwindet, sobald das Bild kommt, und der Schleier um das Widget ist weg.' },
  ],
};
