'use strict';
/**
 * Ulanzi Stream Controller D200 direkt im Hub (2.45.2) – ohne Ulanzi Studio.
 *
 * Protokoll (nachgebaut nach strmdck von redphx, MIT-Lizenz):
 *   HID-Schnittstelle MI_00 (VID 2207, PID 0019), Berichte 1025 Byte = Report-ID 0 + 1024 Byte Paket.
 *   Paket: 7C 7C | Befehl (2 Byte, big endian) | Länge (4 Byte, little endian) | Daten (auf 1016 Byte aufgefüllt)
 *   Grosse Daten (ZIP mit Tastenbildern): erstes Paket mit Kopf + 1016 Byte, danach rohe 1024-Byte-Stücke ohne Kopf.
 *   Befehle: 0x0001 Tasten setzen (ZIP), 0x0006 kleines Fenster (Uhr, hält die Verbindung wach),
 *            0x000A Helligkeit, 0x000B Beschriftungsstil; Eingang 0x0101 Taste, 0x0303 Geräteinfo.
 *   Gerätefehler: Bytes an den Stellen 1016 + k·1024 der ZIP dürfen nicht 0x00 oder 0x7C sein –
 *   sonst wird eine Füll-Datei ergänzt und neu gepackt.
 * Die USB-Verbindung läuft in einem kleinen C#-Helfer (PowerShell), wie die Tastatur-Engine.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const { spawn } = require('child_process');

const CS = String.raw`
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class RevUlanzi {
  [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
  [DllImport("setupapi.dll", CharSet = CharSet.Auto)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int f);
  [DllImport("setupapi.dll", CharSet = CharSet.Auto)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr s, IntPtr d, ref Guid g, int i, ref DID did);
  [DllImport("setupapi.dll", CharSet = CharSet.Auto)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr s, ref DID did, IntPtr det, int size, out int req, IntPtr dd);
  [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr s);
  [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern SafeFileHandle CreateFile(string n, uint a, uint s, IntPtr sa, uint c, uint f, IntPtr t);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool ReadFile(SafeFileHandle h, byte[] b, int n, out int r, IntPtr o);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool WriteFile(SafeFileHandle h, byte[] b, int n, out int w, IntPtr o);
  [StructLayout(LayoutKind.Sequential)] struct DID { public int cbSize; public Guid g; public int f; public IntPtr r; }

  static SafeFileHandle rh, wh;
  static readonly object wlock = new object();
  static volatile bool quit;

  static void Out(string s) { lock (Console.Out) { Console.Out.WriteLine(s); Console.Out.Flush(); } }

  static string FindPath() {
    Guid g; HidD_GetHidGuid(out g);
    IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);
    try {
      for (int i = 0; ; i++) {
        var did = new DID(); did.cbSize = Marshal.SizeOf(did);
        if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref did)) return null;
        int req; SetupDiGetDeviceInterfaceDetail(set, ref did, IntPtr.Zero, 0, out req, IntPtr.Zero);
        IntPtr det = Marshal.AllocHGlobal(req); Marshal.WriteInt32(det, IntPtr.Size == 8 ? 8 : 6);
        SetupDiGetDeviceInterfaceDetail(set, ref did, det, req, out req, IntPtr.Zero);
        string p = Marshal.PtrToStringAuto(new IntPtr(det.ToInt64() + 4)); Marshal.FreeHGlobal(det);
        string l = p.ToLowerInvariant();
        if (l.Contains("vid_2207&pid_0019") && l.Contains("mi_00")) return p;
      }
    } finally { SetupDiDestroyDeviceInfoList(set); }
  }

  static bool WriteReport(byte[] pkt1024) {
    var b = new byte[1025];
    Buffer.BlockCopy(pkt1024, 0, b, 1, Math.Min(1024, pkt1024.Length));
    int w;
    var h = wh;
    return h != null && !h.IsInvalid && WriteFile(h, b, b.Length, out w, IntPtr.Zero);
  }

  static byte[] Header(int cmd, int len, byte[] data, int off, int count) {
    var p = new byte[1024];
    p[0] = 0x7C; p[1] = 0x7C; p[2] = (byte)(cmd >> 8); p[3] = (byte)cmd;
    p[4] = (byte)len; p[5] = (byte)(len >> 8); p[6] = (byte)(len >> 16); p[7] = (byte)(len >> 24);
    Buffer.BlockCopy(data, off, p, 8, Math.Min(count, 1016));
    return p;
  }

  static bool Send(int cmd, byte[] data) {
    lock (wlock) {
      if (!WriteReport(Header(cmd, data.Length, data, 0, Math.Min(1016, data.Length)))) return false;
      for (int i = 1016; i < data.Length; i += 1024) {
        var p = new byte[1024];
        Buffer.BlockCopy(data, i, p, 0, Math.Min(1024, data.Length - i));
        if (!WriteReport(p)) return false;
      }
      return true;
    }
  }

  static void Commands() {
    string line;
    while (!quit && (line = Console.In.ReadLine()) != null) {
      try {
        if (line == "QUIT") { quit = true; break; }
        // FILE <cmd> <pfad>   |   RAW <cmd> <text>
        int a = line.IndexOf(' '), b = a < 0 ? -1 : line.IndexOf(' ', a + 1);
        if (a < 0 || b < 0) continue;
        string kind = line.Substring(0, a);
        int cmd = Convert.ToInt32(line.Substring(a + 1, b - a - 1));
        string rest = line.Substring(b + 1);
        byte[] data = kind == "FILE" ? File.ReadAllBytes(rest) : Encoding.UTF8.GetBytes(rest);
        bool ok = Send(cmd, data);
        Out((ok ? "sent " : "err senden ") + cmd + " " + data.Length);
      } catch (Exception e) { Out("err " + e.Message.Replace('\n', ' ')); }
    }
    quit = true;
  }

  public static void Run() {
    new Thread(Commands) { IsBackground = true }.Start();
    bool announcedMissing = false;
    while (!quit) {
      string p = FindPath();
      if (p == null) {
        if (!announcedMissing) { Out("nodev"); announcedMissing = true; }
        Thread.Sleep(2000); continue;
      }
      announcedMissing = false;
      rh = CreateFile(p, 0x80000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
      wh = CreateFile(p, 0x40000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
      if (rh.IsInvalid || wh.IsInvalid) { Out("err open " + Marshal.GetLastWin32Error()); Thread.Sleep(3000); continue; }
      Out("ready");
      var buf = new byte[1025];
      while (!quit) {
        int r;
        if (!ReadFile(rh, buf, buf.Length, out r, IntPtr.Zero) || r < 13) { break; }
        int cmd = (buf[1] == 0x7C && buf[2] == 0x7C) ? (buf[3] << 8) | buf[4] : -1;
        if (cmd == 0x0101) Out("btn " + buf[10] + " " + (buf[12] == 1 ? 1 : 0) + " " + buf[9]);
        else if (cmd != 0x0303) Out("pkt " + BitConverter.ToString(buf, 0, Math.Min(r, 24)));
        else {
          int len = buf[5] | (buf[6] << 8);
          int end = 9; while (end < r && end < 9 + Math.Min(len, 1000) && buf[end] != 0) end++;
          Out("info " + Encoding.ASCII.GetString(buf, 9, end - 9).Replace('\n', ' '));
        }
      }
      lock (wlock) { try { rh.Dispose(); wh.Dispose(); } catch { } wh = null; }
      if (!quit) { Out("lost"); Thread.Sleep(1000); }
    }
  }
}
`;

/* ---------------------------------------------------------------- ZIP (Deflate, wie die Ulanzi-Software) */
const CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
const crc32 = (buf) => {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
function zip(entries) {
  const local = [];
  const central = [];
  let offset = 0;
  for (const { name, data } of entries) {
    const nameBuf = Buffer.from(name, 'utf8');
    const deflated = zlib.deflateRawSync(data, { level: 1 });
    const crc = crc32(data);
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0, 6); h.writeUInt16LE(8, 8);
    h.writeUInt16LE(0, 10); h.writeUInt16LE(0x21, 12); h.writeUInt32LE(crc, 14);
    h.writeUInt32LE(deflated.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nameBuf.length, 26); h.writeUInt16LE(0, 28);
    local.push(h, nameBuf, deflated);
    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0, 8); c.writeUInt16LE(8, 10);
    c.writeUInt16LE(0, 12); c.writeUInt16LE(0x21, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(deflated.length, 20); c.writeUInt32LE(data.length, 24);
    c.writeUInt16LE(nameBuf.length, 28); c.writeUInt32LE(offset, 42);
    central.push(c, nameBuf);
    offset += 30 + nameBuf.length + deflated.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, cd, end]);
}
// Gerätefehler umgehen: an 1016 + k·1024 kein 0x00 / 0x7C
const zipOk = (buf) => {
  for (let i = 1016; i < buf.length; i += 1024) if (buf[i] === 0x00 || buf[i] === 0x7c) return false;
  return true;
};
function deckZip(files) {
  let dummy = '';
  for (let attempt = 0; attempt < 400; attempt++) {
    const entries = [...(dummy ? [{ name: 'dummy.txt', data: Buffer.from(dummy) }] : []), ...files];
    const buf = zip(entries);
    if (zipOk(buf)) return buf;
    dummy += Math.random().toString(36).slice(2, 10).padEnd(8, 'x');
  }
  throw new Error('Tastenbilder konnten nicht verpackt werden.');
}

/* ---------------------------------------------------------------- Gerät */
const COLS = 5;
const KEYS = 13;

class UlanziDeck {
  constructor({ dir, onButton, onChange }) {
    this.dir = dir;
    this.onButton = onButton;
    this.onChange = onChange;
    this.child = null;
    this.connected = false;
    this.info = '';
    this.error = '';
    this.lastSent = '';
    this.keepAlive = null;
    this.brightness = null;
  }

  status() {
    return { running: Boolean(this.child), connected: this.connected, info: this.info, error: this.error, keys: KEYS, cols: COLS, lastSent: this.lastSent };
  }

  start() {
    if (this.child) return this.status();
    const file = path.join(this.dir, 'ulanzi-helper.ps1');
    fs.mkdirSync(this.dir, { recursive: true });
    fs.writeFileSync(file, `﻿$ErrorActionPreference='Stop'\r\nAdd-Type -TypeDefinition @'\r\n${CS}\r\n'@\r\n[RevUlanzi]::Run()\r\n`, 'utf8');
    this.error = '';
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    this.child = child;
    let err = '';
    let rest = '';
    child.stdout.on('data', (buf) => {
      rest += String(buf);
      const lines = rest.split(/\r?\n/);
      rest = lines.pop();
      for (const line of lines) this.line(line.trim());
    });
    child.stderr.on('data', (d) => (err += d));
    child.on('exit', () => {
      if (this.child !== child) return;
      this.child = null;
      this.setConnected(false);
      if (err.trim()) this.error = err.trim().split(/\r?\n/)[0].slice(0, 200);
      this.onChange?.(this.status());
    });
    child.stdin.on('error', () => {});
    this.onChange?.(this.status());
    return this.status();
  }

  line(line) {
    if (!line) return;
    if (line.startsWith('btn ')) {
      const [, index, pressed, state] = line.split(' ').map(Number);
      if (Number.isFinite(index)) this.onButton?.({ index, pressed: pressed === 1, state });
      return;
    }
    if (line === 'ready') return this.setConnected(true);
    if (line === 'nodev' || line === 'lost') return this.setConnected(false);
    if (line.startsWith('info ')) this.info = line.slice(5).slice(0, 200);
    else if (line.startsWith('err ')) this.error = line.slice(4).slice(0, 200);
    else return;
    this.onChange?.(this.status());
  }

  setConnected(on) {
    if (this.connected === on) return;
    this.connected = on;
    clearInterval(this.keepAlive);
    this.keepAlive = null;
    if (on) {
      this.error = '';
      // Uhr im kleinen Fenster – hält die Verbindung wach (sonst fällt das Deck in seinen eigenen Modus zurück)
      const tick = () => {
        const d = new Date();
        const t = [d.getHours(), d.getMinutes(), d.getSeconds()].map((x) => String(x).padStart(2, '0')).join(':');
        this.raw(0x0006, `1|0|0|${t}|0`);
      };
      tick();
      this.keepAlive = setInterval(tick, 5000);
      // Beschriftung steckt schon im Bild – Geräte-Titel ausblenden
      this.raw(0x000b, JSON.stringify({ Align: 'bottom', Color: 0xffffff, FontName: 'Roboto', ShowTitle: false, Size: 10, Weight: 80 }));
      if (this.brightness != null) this.raw(0x000a, String(this.brightness));
    }
    this.onChange?.(this.status());
  }

  raw(cmd, text) {
    if (!this.child || !this.connected) return false;
    this.child.stdin.write(`RAW ${cmd} ${String(text).replace(/[\r\n]/g, ' ')}\n`);
    return true;
  }

  setBrightness(value) {
    this.brightness = Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
    this.raw(0x000a, String(this.brightness));
    return this.status();
  }

  /** buttons: [{ index, png: Buffer|null }] – Bilder 196×196 PNG, Beschriftung ist im Bild. */
  setButtons(buttons) {
    if (!this.child || !this.connected) throw new Error('Das Ulanzi-Deck ist nicht verbunden.');
    const manifest = {};
    const files = [];
    for (let i = 0; i < KEYS; i++) {
      const b = buttons.find((x) => x.index === i);
      const view = {};
      if (b?.png?.length) {
        view.Icon = `icons/${i}.png`;
        files.push({ name: `icons/${i}.png`, data: b.png });
      }
      manifest[`${i % COLS}_${Math.floor(i / COLS)}`] = { State: 0, ViewParam: [view] };
    }
    const sorted = Object.fromEntries(Object.keys(manifest).sort().map((k) => [k, manifest[k]]));
    const data = deckZip([{ name: 'manifest.json', data: Buffer.from(JSON.stringify(sorted, null, 2)) }, ...files]);
    const file = path.join(this.dir, 'ulanzi-page.zip');
    fs.writeFileSync(file, data);
    this.child.stdin.write(`FILE 1 ${file}\n`);
    this.lastSent = new Date().toISOString();
    return { ok: true, bytes: data.length };
  }

  stop() {
    const c = this.child;
    this.child = null;
    this.setConnected(false);
    if (c) {
      try { c.stdin.write('QUIT\n'); } catch { /* egal */ }
      setTimeout(() => { try { c.kill(); } catch { /* egal */ } }, 500);
    }
    this.onChange?.(this.status());
    return this.status();
  }
}

module.exports = { UlanziDeck, deckZip, zipOk, _zip: zip, tmp: os.tmpdir };
