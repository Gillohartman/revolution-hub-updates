'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.37.0',
  title: 'Revulution Hub 2.37',
  sub: 'Spiele, Server mit Sprachkanälen, Videoanrufe, Revolution Coin und ein ruhigerer Desktop.',
  items: [
    { open: 'tool-games', icon: 'spark', title: 'Revolution Spiele', text: 'Würfel, Roulette, Plinko, Abflug und Duelle gegen andere – mit deinen ◆ Punkten aus Schach und Geo (Punkte sind nicht käuflich).' },
    { open: 'chats', icon: 'chat', title: 'Server, Sprachkanäle, Video', text: 'Server mit Symbol erstellen, im Sprachkanal mit mehreren reden (Leiste ausblendbar) und Videoanrufe in Direktnachrichten. „Annehmen“ direkt in der Island.' },
    { open: 'tool-store', icon: 'spark', title: 'Revolution Coin', text: 'Die neue 3D-Münze im Store, dazu Einladungscodes: 20 Coins pro Freund.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Widgets', text: 'Neue Galerie mit Vorschau. Widgets bleiben immer hinter deinen Apps, pausieren im Vollbild, lassen sich mit der rechten Maustaste verschieben. Das Gesicht singt im Takt.' },
    { open: 'settings', icon: 'pointer', title: 'Mauszeiger', text: 'Kleiner, und auf Wunsch für ganz Windows (Einstellungen → Mauszeiger). Farbige 3D-Glas-Symbole.' },
    { open: 'tool-desktop', icon: 'layers', title: 'Taskleiste', text: 'Statt eigener Leiste: die Windows-Taskleiste durchsichtig (TranslucentTB).' },
    { open: 'chess', icon: 'chess', title: 'Schach', text: 'Pfeile nur noch für erlaubte Züge, klare Frauenstimme, kein Coach-Fenster über einer laufenden Partie.' },
  ],
};
