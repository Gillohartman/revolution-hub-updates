'use strict';

/* Hintergründe und Meldungen für alle. Die Verwaltung liegt in der separaten Admin-App. */
(() => {
  const T = window.HubTools;
  if (!T) return;
  const ctx = () => T.ctx();
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hm = (at) => new Date(at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
  const WALL_NAMES = { nebula: 'Nebula', aurora: 'Aurora', galaxy: 'Galaxy', synthwave: 'Synthwave', liquid: 'Liquid', silk: 'Silk', waves: 'Waves', ocean: 'Ocean', clouds: 'Clouds', mountains: 'Mountains', fireflies: 'Fireflies', bokeh: 'Bokeh', lava: 'Lava', warp: 'Warp' };
  const st = { data: null, loading: false, busy: false, error: '', type: 'bug', app: 'Revulution Hub', cloud: null, cloudErr: '', acct: null, sub: null };

  /** Cloud: freigegebene Hintergründe + Anmeldestatus fürs Einreichen. */
  async function loadCloud(force = false) {
    if (st.cloud && !force) return;
    st.cloud = st.cloud || [];
    try {
      [st.cloud, st.acct] = await Promise.all([window.hub.community.cloud(force), window.hub.account.state().catch(() => null)]);
      st.cloudErr = '';
    } catch (e) {
      st.cloudErr = /PERMISSION|403/i.test(String(e?.message)) ? 'Die Cloud-Hintergründe sind noch nicht freigeschaltet.' : 'Cloud gerade nicht erreichbar.';
    }
    if (active()) ctx().render();
  }

  /** Bild verkleinern (max. 1920 px, JPEG) – passt so in ein Cloud-Dokument. */
  async function shrink(file) {
    const bmp = await createImageBitmap(file);
    let w = bmp.width;
    let h = bmp.height;
    const scale = Math.min(1, 1920 / Math.max(w, h));
    w = Math.round(w * scale);
    h = Math.round(h * scale);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d').drawImage(bmp, 0, 0, w, h);
    for (const q of [0.86, 0.78, 0.7, 0.6, 0.5]) {
      const url = c.toDataURL('image/jpeg', q);
      if (url.length < 900 * 1024) return { url, w, h };
    }
    throw new Error('Das Bild ist zu detailreich – bitte ein kleineres wählen.');
  }

  function submitCard() {
    const signed = st.acct?.signedIn;
    const s = st.sub;
    return `<div class="tool-card bg-submit"><div class="list-row"><div class="grow"><strong>Hintergrund einreichen</strong><small>Dein Bild geht an den Admin. Nach der Freigabe sehen es alle im Hub.</small></div></div>
      ${
        signed
          ? `<div class="bg-sub-row"><div class="bg-sub-prev">${s?.url ? `<img src="${s.url}" alt="" />` : '<span>16:9 · bis 1920 px</span>'}</div>
             <div class="bg-sub-side"><label class="btn small"><input type="file" accept="image/*" data-bg-sub-file hidden />Bild wählen</label>
               <input class="input" data-bg-sub-name maxlength="60" placeholder="Name, z. B. Neon City" value="${esc(s?.name || '')}" />
               <button class="btn primary small" data-bg-sub-send ${s?.url && !st.busy ? '' : 'disabled'}>${st.busy ? 'Wird gesendet …' : 'Einreichen'}</button>
               ${s?.w ? `<small class="muted">${s.w} × ${s.h} px · ${Math.round(s.url.length / 1365)} KB</small>` : ''}</div></div>`
          : '<p class="muted">Zum Einreichen melde dich in den Einstellungen mit deinem Revulution-Konto an.</p>'
      }</div>`;
  }

  function cloudCard() {
    loadCloud();
    const list = st.cloud || [];
    return `<div class="tool-card"><div class="list-row"><div class="grow"><strong>Aus der Community</strong><small>${st.cloudErr ? esc(st.cloudErr) : `${list.length} freigegebene${list.length === 1 ? 'r' : ''} Hintergr${list.length === 1 ? 'und' : 'ünde'}`}</small></div><button class="btn small ghost" data-bg-cloud-refresh>Aktualisieren</button></div>
      <div class="bg-grid">${list.length ? list.map((b) => `<div class="bg-card"><img src="${b.img}" alt="${esc(b.name)}" loading="lazy" /><div class="bg-meta"><strong>${esc(b.name)}</strong><small>von ${esc(b.by || 'Community')}</small></div><div class="bg-actions"><button class="btn small ghost" data-bg-cloud-desktop="${esc(b.id)}">Als Desktop</button></div></div>`).join('') : '<div class="bg-empty big">Noch nichts freigegeben – reich das erste Bild ein!</div>'}</div></div>`;
  }

  async function load(force = false) {
    if (st.loading || (st.data && !force)) return;
    st.loading = true;
    try {
      st.data = await window.hub.community.status();
      st.error = '';
    } catch (e) {
      st.error = e?.message || 'Datenbank nicht erreichbar.';
    } finally {
      st.loading = false;
      if (active()) ctx().render();
    }
  }

  const active = () => Boolean(document.querySelector('[data-tool-page="tool-backgrounds"]'));

  function bgCard(b) {
    return `<div class="bg-card">${b.data ? `<img src="${b.data}" alt="${esc(b.name)}" loading="lazy" />` : '<div class="bg-empty">Kein Vorschaubild</div>'}<div class="bg-meta"><strong>${esc(b.name)}</strong><small>${b.downloads || 0} Downloads · ${hm(b.at)}</small></div><div class="bg-actions"><button class="btn small ghost" data-bg-desktop="${esc(b.id)}">Als Desktop</button><button class="btn small ghost" data-bg-download="${esc(b.id)}">Herunterladen</button></div></div>`;
  }

  function html() {
    load();
    const d = st.data;
    const hubState = ctx().state();
    const builtins = (hubState?.wallpapers || []).map((id) => ({ id, url: fileUrl(`${hubState.wallpaperDir}/thumbs/${id}.jpg`) }));
    return `${submitCard()}${cloudCard()}<div class="tool-card"><div class="list-row"><div class="grow"><strong>Mitgelieferte Hintergründe</strong><small>Breite Desktop-Bilder – direkt als Windows-Hintergrund oder im Hub verwenden.</small></div></div><div class="bg-grid">${builtins.map((b) => `<div class="bg-card"><img src="${b.url}" alt="${esc(WALL_NAMES[b.id] || b.id)}" loading="lazy" /><div class="bg-meta"><strong>${esc(WALL_NAMES[b.id] || b.id)}</strong><small>Immer dabei · ${hubState.settings?.wallpaper === b.id ? 'aktuell im Hub' : 'bereit'}</small></div><div class="bg-actions"><button class="btn small ghost" data-bg-builtin-desktop="${b.id}">Als Desktop</button></div></div>`).join('')}</div></div>
    <div class="tool-card"><div class="list-row"><div class="grow"><strong>Desktop-Hintergründe aus der Community</strong><small>${d ? `${d.backgrounds.length} Hintergrund${d.backgrounds.length === 1 ? '' : 'e'} in der Datenbank` : 'Datenbank wird geladen …'}</small></div></div>${st.error ? `<p class="muted">${esc(st.error)}</p>` : ''}<div class="bg-grid">${d?.backgrounds?.length ? d.backgrounds.map(bgCard).join('') : '<div class="bg-empty big">Noch keine Hintergründe. Neue Bilder erscheinen hier, sobald der Admin sie im Admin-Center hinzufügt.</div>'}</div></div>\n    <div class="tool-card"><div class="list-row"><div class="grow"><strong>Bug melden oder Report senden</strong><small>Die Meldung landet direkt in der Datenbank und wird im Admin-Center bearbeitet.</small></div></div><div class="report-form"><select data-report-app>${['Revulution Hub', 'Chats', 'Beat Lab', 'Tastatur & RGB', 'Spiele', 'Dynamic Island', 'Andere App'].map((a) => `<option ${a === st.app ? 'selected' : ''}>${a}</option>`).join('')}</select><select data-report-type><option value="bug" ${st.type === 'bug' ? 'selected' : ''}>Bug</option><option value="report" ${st.type === 'report' ? 'selected' : ''}>Report</option><option value="idea" ${st.type === 'idea' ? 'selected' : ''}>Idee</option></select><textarea data-report-text rows="3" placeholder="Was ist passiert? Welche Schritte führen dazu?"></textarea><button class="btn primary small" data-report-send>Absenden</button></div></div>`;
  }

  T.register(
    'tool-backgrounds',
    { nav: 'Hintergründe', title: 'Hintergründe', sub: 'Desktop-Bilder und Meldungen', icon: 'image', tint: 'linear-gradient(135deg,#38bdf8,#6366f1)', desc: 'Lade Desktop-Hintergründe herunter oder setze sie direkt als Windows-Hintergrund. Bugs und Ideen gehen an das separate Admin-Center.' },
    html,
  );

  document.addEventListener('click', async (e) => {
    if (!active() || st.busy) return;
    const d = (sel) => e.target.closest?.(sel);
    try {
      const desk = d('[data-bg-desktop]')?.dataset.bgDesktop;
      if (desk) {
        st.busy = true;
        const target = await window.pickWallpaperTarget();
        if (!target) return;
        await window.hub.community.desktop(desk, target);
        ctx().toast('Desktop-Hintergrund gesetzt.');
        return ctx().render();
      }
      const cloudDesk = d('[data-bg-cloud-desktop]')?.dataset.bgCloudDesktop;
      if (cloudDesk) {
        st.busy = true;
        const target = await window.pickWallpaperTarget();
        if (!target) return;
        await window.hub.community.cloudDesktop(cloudDesk, target);
        ctx().toast('Desktop-Hintergrund gesetzt.');
        return ctx().render();
      }
      if (d('[data-bg-cloud-refresh]')) {
        st.cloud = null;
        return loadCloud(true);
      }
      if (d('[data-bg-sub-send]') && st.sub?.url) {
        st.busy = true;
        ctx().render();
        await window.hub.community.submit({ name: st.sub.name || 'Hintergrund', img: st.sub.url });
        st.sub = null;
        ctx().toast('Danke! Dein Hintergrund ist beim Admin zur Prüfung.');
        return ctx().render();
      }
      const builtinDesk = d('[data-bg-builtin-desktop]')?.dataset.bgBuiltinDesktop;
      if (builtinDesk) {
        st.busy = true;
        const target = await window.pickWallpaperTarget();
        if (!target) return;
        await window.hub.community.builtinDesktop(builtinDesk, target);
        ctx().toast('Windows-Hintergrund gesetzt.');
        return ctx().render();
      }
      const dl = d('[data-bg-download]')?.dataset.bgDownload;
      if (dl) {
        st.busy = true;
        const r = await window.hub.community.download(dl);
        const a = document.createElement('a');
        a.href = r.data;
        a.download = r.file || `${r.name}.png`;
        a.click();
        st.data = await window.hub.community.status();
        return ctx().render();
      }
      if (d('[data-report-send]')) {
        st.busy = true;
        await window.hub.community.report({ app: st.app, type: st.type, text: document.querySelector('[data-report-text]')?.value || '' });
        document.querySelector('[data-report-text]').value = '';
        ctx().toast('Danke – die Meldung ist in der Datenbank.');
        st.data = await window.hub.community.status();
        return ctx().render();
      }
    } catch (error) {
      ctx().toast(error.message || 'Das hat nicht geklappt.', 'error');
    } finally {
      st.busy = false;
    }
  });

  document.addEventListener('input', (e) => {
    if (active() && e.target.matches?.('[data-bg-sub-name]') && st.sub) st.sub.name = e.target.value;
  });

  document.addEventListener('change', async (e) => {
    if (!active()) return;
    if (e.target.matches?.('[data-bg-sub-file]') && e.target.files?.[0]) {
      const f = e.target.files[0];
      try {
        const r = await shrink(f);
        st.sub = { ...r, name: st.sub?.name || f.name.replace(/\.[a-z0-9]+$/i, '').slice(0, 60) };
      } catch (error) {
        ctx().toast(error.message || 'Bild konnte nicht gelesen werden.', 'error');
      }
      return ctx().render();
    }
    if (e.target.matches?.('[data-report-app]')) st.app = e.target.value;
    if (e.target.matches?.('[data-report-type]')) st.type = e.target.value;
  });
})();
