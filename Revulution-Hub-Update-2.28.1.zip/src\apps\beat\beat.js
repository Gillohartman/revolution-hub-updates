'use strict';

/* Beat Lab – kleiner aber vollständiger Step-Sequencer.
 * Drums, Bass, Lead, Mixer, Effekte, Song-Kette und WAV-Export.
 */
(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const api = window.beatApp;
  const STEPS = 16;
  const PATTERNS = 4;
  const LANES = { bass: [24, 26, 28, 29, 31, 33, 34, 36, 38, 40, 41, 43, 45, 46, 48], lead: [60, 62, 64, 65, 67, 69, 70, 72, 74, 76, 77, 79, 81, 82, 84] };
  const LANE_NAME = { bass: 'Bass', lead: 'Lead' };
  const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const noteName = (m) => `${NOTE_NAMES[m % 12]}${Math.floor(m / 12) - 1}`;
  const freq = (m) => 440 * 2 ** ((m - 69) / 12);
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  const DRUMS = [
    { id: 'kick', name: 'Kick', color: '#38bdf8' },
    { id: 'snare', name: 'Snare', color: '#a78bfa' },
    { id: 'clap', name: 'Clap', color: '#f472b6' },
    { id: 'hat', name: 'Hi-Hat', color: '#fbbf24' },
    { id: 'openhat', name: 'Open Hat', color: '#fb923c' },
    { id: 'tom', name: 'Tom', color: '#34d399' },
    { id: 'rim', name: 'Rim', color: '#f87171' },
    { id: 'cowbell', name: 'Cowbell', color: '#e879f9' },
    { id: 'shaker', name: 'Shaker', color: '#facc15' },
    { id: 'crash', name: 'Crash', color: '#94a3b8' },
    { id: 'ride', name: 'Ride', color: '#67e8f9' },
    { id: 'perc', name: 'Perc', color: '#fb7185' },
  ];

  const KITS = {
    '808': { name: '808', sub: 'Tief & rund', color: '#38bdf8', kick: [150, 44, 0.42], snare: [190, 0.2], hat: [0.055, 7200], synth: { wave: 'sine', cutoff: 900, q: 1.4 } },
    '909': { name: '909', sub: 'Club & Druck', color: '#a78bfa', kick: [180, 50, 0.3], snare: [220, 0.16], hat: [0.04, 8200], synth: { wave: 'sawtooth', cutoff: 1600, q: 1.1 } },
    lofi: { name: 'Lo-Fi', sub: 'Weich & warm', color: '#fbbf24', kick: [120, 42, 0.5], snare: [160, 0.24], hat: [0.08, 5200], synth: { wave: 'triangle', cutoff: 700, q: 1.8 } },
    electro: { name: 'Electro', sub: 'Scharf & hell', color: '#34d399', kick: [210, 55, 0.24], snare: [260, 0.12], hat: [0.03, 9800], synth: { wave: 'square', cutoff: 2200, q: 0.9 } },
    acoustic: { name: 'Acoustic', sub: 'Natürlich', color: '#fb7185', kick: [110, 48, 0.34], snare: [200, 0.2], hat: [0.07, 6000], synth: { wave: 'triangle', cutoff: 1100, q: 1.2 } },
    trap: { name: 'Trap', sub: '808 & schnelle Hats', color: '#f472b6', kick: [155, 40, 0.62], snare: [245, 0.2], hat: [0.025, 9200], synth: { wave: 'sine', cutoff: 1150, q: 1.3 } },
    house: { name: 'House', sub: 'Vier auf die Eins', color: '#22d3ee', kick: [175, 52, 0.3], snare: [230, 0.14], hat: [0.04, 8600], synth: { wave: 'sawtooth', cutoff: 1900, q: 1 } },
    dnb: { name: 'Drum & Bass', sub: 'Schnell & dunkel', color: '#c084fc', kick: [195, 46, 0.26], snare: [250, 0.11], hat: [0.028, 10400], synth: { wave: 'square', cutoff: 1450, q: 1.5 } },
  };

  const blankPattern = () => ({
    drums: Object.fromEntries(DRUMS.map((d) => [d.id, Array(STEPS).fill(0)])),
    bass: Array(STEPS).fill(null),
    lead: Array(STEPS).fill(null),
  });

  function presetPattern(index) {
    const p = blankPattern();
    const put = (id, steps, vel = 0.85) => steps.forEach((s) => (p.drums[id][s] = vel));
    if (index === 0) {
      put('kick', [0, 4, 8, 12], 0.95);
      put('snare', [4, 12], 0.75);
      put('hat', [0, 2, 4, 6, 8, 10, 12, 14], 0.5);
      put('shaker', [2, 6, 10, 14], 0.32);
      put('crash', [0], 0.38);
      p.bass[0] = 36; p.bass[3] = 36; p.bass[6] = 39; p.bass[8] = 36; p.bass[11] = 43; p.bass[14] = 34;
      p.lead[2] = 60; p.lead[6] = 63; p.lead[10] = 67; p.lead[14] = 63;
    } else if (index === 1) {
      put('kick', [0, 3, 6, 10, 14], 0.9);
      put('snare', [4, 12], 0.8);
      put('clap', [12], 0.6);
      put('hat', [0, 2, 4, 6, 8, 10, 12, 14], 0.42);
      put('openhat', [7, 15], 0.4);
      put('shaker', [1, 3, 5, 7, 9, 11, 13, 15], 0.26);
      put('perc', [5, 11], 0.45);
      p.bass[0] = 36; p.bass[2] = 36; p.bass[5] = 39; p.bass[7] = 41; p.bass[10] = 36; p.bass[12] = 43; p.bass[15] = 41;
      p.lead[0] = 72; p.lead[4] = 67; p.lead[8] = 70; p.lead[12] = 63;
    } else if (index === 2) {
      put('kick', [0, 7, 8, 11], 0.9);
      put('snare', [2, 6, 10, 14], 0.55);
      put('rim', [5, 13], 0.45);
      put('hat', [1, 3, 5, 9, 11, 13], 0.35);
      put('ride', [8], 0.38);
      put('shaker', [0, 4, 8, 12], 0.22);
      p.bass[0] = 34; p.bass[3] = 36; p.bass[6] = 38; p.bass[9] = 41; p.bass[12] = 43; p.bass[14] = 41;
      p.lead[3] = 67; p.lead[7] = 70; p.lead[11] = 74; p.lead[15] = 70;
    } else {
      put('kick', [0, 2, 4, 7, 10, 13], 0.82);
      put('snare', [4, 12], 0.72);
      put('clap', [4, 12], 0.45);
      put('hat', [0, 1, 3, 4, 6, 7, 9, 10, 12, 13, 15], 0.4);
      put('tom', [14], 0.55);
      put('cowbell', [6], 0.35);
      put('crash', [0], 0.3);
      put('ride', [8], 0.34);
      put('perc', [3, 11, 15], 0.32);
      p.bass[0] = 36; p.bass[4] = 39; p.bass[8] = 41; p.bass[12] = 43; p.bass[14] = 39;
      p.lead[2] = 64; p.lead[5] = 67; p.lead[9] = 72; p.lead[13] = 67;
    }
    return p;
  }

  const defaultProject = () => ({
    name: 'Neon Beat',
    kit: '808',
    bpm: 120,
    swing: 10,
    master: 0.8,
    scale: 'minor',
    patterns: [0, 1, 2, 3].map(presetPattern),
    chain: [0, 1, 2, 3],
    mix: Object.fromEntries(DRUMS.map((d) => [d.id, { vol: { kick: 0.9, snare: 0.62, clap: 0.5, hat: 0.42, openhat: 0.4, crash: 0.3, ride: 0.32, shaker: 0.28, perc: 0.5 }[d.id] ?? 0.58, pan: 0, mute: false, tune: 0 }])),
    synthMix: { bass: { vol: 0.52, pan: 0, mute: false }, lead: { vol: 0.34, pan: 0.08, mute: false } },
    synth: { wave: 'sawtooth', cutoff: 1800, q: 1.2, attack: 0.01, decay: 0.16, sustain: 0.32, release: 0.22, octave: 0 },
    fx: { filter: 15000, drive: 0.06, delay: 0.2, feedback: 0.28, reverb: 0.16 },
  });

  let project = defaultProject();
  let active = 0;
  let view = 'drums';
  let lane = 'bass';
  let selectedTrack = 'kick';
  let playing = false;
  let songMode = false;
  let currentStep = -1;
  let currentPattern = 0;
  let saveTimer = null;

  /* ------------------------------------------------------------------ Audio */
  const runtime = { ac: null, graph: null, buses: null, timer: 0, raf: 0, next: 0, step: 0, chainPos: 0, queue: [], stepDur: 0.125 };
  const noiseCache = new WeakMap();

  function noiseBuffer(ctx, seconds = 1) {
    let buf = noiseCache.get(ctx);
    if (buf) return buf;
    buf = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * seconds), ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i += 1) data[i] = Math.random() * 2 - 1;
    noiseCache.set(ctx, buf);
    return buf;
  }

  function curve(amount) {
    const k = amount * 80;
    const n = 1024;
    const out = new Float32Array(n);
    for (let i = 0; i < n; i += 1) {
      const x = (i * 2) / n - 1;
      out[i] = ((1 + k) * x) / (1 + k * Math.abs(x));
    }
    return out;
  }

  function impulse(ctx, seconds = 1.6) {
    return noiseBuffer(ctx, seconds);
  }

  function buildGraph(ctx, destination) {
    const input = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = project.fx.filter;
    const drive = ctx.createWaveShaper();
    drive.curve = curve(project.fx.drive);
    drive.oversample = '2x';
    const master = ctx.createGain();
    master.gain.value = project.master;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12;
    comp.ratio.value = 3;
    comp.attack.value = 0.004;
    comp.release.value = 0.18;
    input.connect(filter);
    filter.connect(drive);
    drive.connect(master);
    master.connect(comp);
    comp.connect(destination);

    const delay = ctx.createDelay(1.5);
    delay.delayTime.value = Math.round((60 / project.bpm / 2) * 1000) / 1000;
    const feedback = ctx.createGain();
    feedback.gain.value = project.fx.feedback;
    const delayWet = ctx.createGain();
    delayWet.gain.value = project.fx.delay;
    delay.connect(feedback);
    feedback.connect(delay);
    delay.connect(delayWet);
    delayWet.connect(master);

    const reverb = ctx.createConvolver();
    reverb.buffer = impulse(ctx);
    const reverbWet = ctx.createGain();
    reverbWet.gain.value = project.fx.reverb;
    reverb.connect(reverbWet);
    reverbWet.connect(master);

    return { input, filter, drive, master, comp, delay, feedback, delayWet, reverb, reverbWet };
  }

  function busFor(ctx, graph, vol, pan, mute, sends = {}) {
    const gain = ctx.createGain();
    gain.gain.value = mute ? 0 : vol;
    const p = ctx.createStereoPanner();
    p.pan.value = pan;
    gain.connect(p);
    p.connect(graph.input);
    if (sends.delay) {
      const s = ctx.createGain();
      s.gain.value = sends.delay;
      p.connect(s);
      s.connect(graph.delay);
    }
    if (sends.reverb) {
      const s = ctx.createGain();
      s.gain.value = sends.reverb;
      p.connect(s);
      s.connect(graph.reverb);
    }
    return gain;
  }

  function buildBuses(ctx, graph) {
    const drums = {};
    for (const d of DRUMS) {
      const m = project.mix[d.id] || {};
      drums[d.id] = busFor(ctx, graph, m.vol ?? 0.6, m.pan ?? 0, m.mute, { reverb: d.id === 'snare' || d.id === 'clap' ? 0.1 : 0.04, delay: d.id === 'rim' ? 0.12 : 0 });
    }
    const bass = busFor(ctx, graph, project.synthMix.bass.vol, project.synthMix.bass.pan, project.synthMix.bass.mute, { reverb: 0.05 });
    const lead = busFor(ctx, graph, project.synthMix.lead.vol, project.synthMix.lead.pan, project.synthMix.lead.mute, { delay: 0.22, reverb: 0.18 });
    return { drums, bass, lead };
  }

  function env(ctx, param, time, a, d, s, r, peak, hold) {
    param.setValueAtTime(0.0001, time);
    param.exponentialRampToValueAtTime(Math.max(0.0002, peak), time + Math.max(0.001, a));
    param.exponentialRampToValueAtTime(Math.max(0.0002, peak * s), time + a + Math.max(0.005, d));
    param.setValueAtTime(Math.max(0.0002, peak * s), time + hold);
    param.exponentialRampToValueAtTime(0.0001, time + hold + Math.max(0.01, r));
  }

  function playDrum(ctx, bus, id, time, vel) {
    const kit = KITS[project.kit] || KITS['808'];
    const tune = project.mix[id]?.tune || 0;
    const tuneK = 2 ** (tune / 12);
    const out = ctx.createGain();
    out.gain.value = clamp(vel, 0, 1);
    out.connect(bus);
    const noise = () => {
      const src = ctx.createBufferSource();
      src.buffer = noiseBuffer(ctx);
      return src;
    };
    if (id === 'kick') {
      const [f0, f1, dec] = kit.kick;
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(f0 * tuneK, time);
      o.frequency.exponentialRampToValueAtTime(f1 * tuneK, time + dec * 0.8);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, time);
      g.gain.exponentialRampToValueAtTime(1, time + 0.006);
      g.gain.exponentialRampToValueAtTime(0.0001, time + dec);
      o.connect(g);
      g.connect(out);
      o.start(time);
      o.stop(time + dec + 0.03);
      const click = noise();
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass';
      hp.frequency.value = 1800;
      const cg = ctx.createGain();
      cg.gain.setValueAtTime(0.35, time);
      cg.gain.exponentialRampToValueAtTime(0.0001, time + 0.02);
      click.connect(hp);
      hp.connect(cg);
      cg.connect(out);
      click.start(time);
      click.stop(time + 0.03);
    } else if (id === 'snare' || id === 'clap') {
      const [tone, dec] = kit.snare;
      const n = noise();
      const bp = ctx.createBiquadFilter();
      bp.type = id === 'clap' ? 'bandpass' : 'highpass';
      bp.frequency.value = id === 'clap' ? 1100 : 1400;
      bp.Q.value = id === 'clap' ? 1.6 : 0.7;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, time);
      g.gain.exponentialRampToValueAtTime(id === 'clap' ? 0.85 : 0.7, time + 0.002);
      g.gain.exponentialRampToValueAtTime(0.0001, time + (id === 'clap' ? dec * 1.4 : dec));
      n.connect(bp);
      bp.connect(g);
      g.connect(out);
      n.start(time);
      n.stop(time + dec * 1.6 + 0.02);
      if (id === 'snare') {
        const o = ctx.createOscillator();
        o.type = 'triangle';
        o.frequency.setValueAtTime(tone * tuneK, time);
        o.frequency.exponentialRampToValueAtTime(tone * 0.7 * tuneK, time + dec);
        const og = ctx.createGain();
        og.gain.setValueAtTime(0.0001, time);
        og.gain.exponentialRampToValueAtTime(0.4, time + 0.002);
        og.gain.exponentialRampToValueAtTime(0.0001, time + dec);
        o.connect(og);
        og.connect(out);
        o.start(time);
        o.stop(time + dec + 0.02);
      }
      if (id === 'clap') {
        for (const [offset, amp] of [[0, 0.55], [0.012, 0.4], [0.026, 0.28]]) {
          const c = noise();
          const cg = ctx.createGain();
          cg.gain.setValueAtTime(amp, time + offset);
          cg.gain.exponentialRampToValueAtTime(0.0001, time + offset + 0.045);
          c.connect(bp);
          cg.connect(out);
          c.start(time + offset);
          c.stop(time + offset + 0.06);
        }
      }
    } else if (id === 'hat' || id === 'openhat') {
      const dec = id === 'openhat' ? 0.28 : kit.hat[0];
      const n = noise();
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass';
      hp.frequency.value = kit.hat[1] * tuneK;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, time);
      g.gain.exponentialRampToValueAtTime(0.5, time + 0.002);
      g.gain.exponentialRampToValueAtTime(0.0001, time + dec);
      n.connect(hp);
      hp.connect(g);
      g.connect(out);
      n.start(time);
      n.stop(time + dec + 0.02);
    } else if (id === 'tom') {
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(190 * tuneK, time);
      o.frequency.exponentialRampToValueAtTime(85 * tuneK, time + 0.25);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, time);
      g.gain.exponentialRampToValueAtTime(0.75, time + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, time + 0.3);
      o.connect(g);
      g.connect(out);
      o.start(time);
      o.stop(time + 0.35);
    } else if (id === 'rim') {
      const o = ctx.createOscillator();
      o.type = 'square';
      o.frequency.setValueAtTime(1700 * tuneK, time);
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = 2400;
      bp.Q.value = 5;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.35, time);
      g.gain.exponentialRampToValueAtTime(0.0001, time + 0.035);
      o.connect(bp);
      bp.connect(g);
      g.connect(out);
      o.start(time);
      o.stop(time + 0.05);
    } else if (id === 'shaker') {
      const n = noise();
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass';
      hp.frequency.value = 5600 * tuneK;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, time);
      g.gain.exponentialRampToValueAtTime(0.16, time + 0.002);
      g.gain.exponentialRampToValueAtTime(0.0001, time + 0.075);
      n.connect(hp);
      hp.connect(g);
      g.connect(out);
      n.start(time);
      n.stop(time + 0.09);
    } else if (id === 'crash' || id === 'ride') {
      const dec = id === 'crash' ? 1.25 : 0.65;
      const n = noise();
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = (id === 'crash' ? 7200 : 8800) * tuneK;
      bp.Q.value = 0.7;
      const g = ctx.createGain();
      const peak = id === 'crash' ? 0.23 : 0.15;
      g.gain.setValueAtTime(0.0001, time);
      g.gain.exponentialRampToValueAtTime(peak, time + 0.003);
      g.gain.exponentialRampToValueAtTime(0.0001, time + dec);
      n.connect(bp);
      bp.connect(g);
      g.connect(out);
      n.start(time);
      n.stop(time + dec + 0.03);
      if (id === 'ride') {
        const o = ctx.createOscillator();
        o.type = 'triangle';
        o.frequency.value = 520 * tuneK;
        const og = ctx.createGain();
        og.gain.setValueAtTime(0.0001, time);
        og.gain.exponentialRampToValueAtTime(0.07, time + 0.002);
        og.gain.exponentialRampToValueAtTime(0.0001, time + 0.2);
        o.connect(og);
        og.connect(out);
        o.start(time);
        o.stop(time + 0.22);
      }
    } else if (id === 'perc') {
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(420 * tuneK, time);
      o.frequency.exponentialRampToValueAtTime(190 * tuneK, time + 0.14);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, time);
      g.gain.exponentialRampToValueAtTime(0.5, time + 0.003);
      g.gain.exponentialRampToValueAtTime(0.0001, time + 0.18);
      o.connect(g);
      g.connect(out);
      o.start(time);
      o.stop(time + 0.2);
    } else if (id === 'cowbell') {
      for (const f of [540, 800]) {
        const o = ctx.createOscillator();
        o.type = 'square';
        o.frequency.value = f * tuneK;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.16, time);
        g.gain.exponentialRampToValueAtTime(0.0001, time + 0.18);
        o.connect(g);
        g.connect(out);
        o.start(time);
        o.stop(time + 0.2);
      }
    }
  }

  function playSynth(ctx, bus, midi, time, duration, vel, kind) {
    const s = project.synth;
    const o = ctx.createOscillator();
    o.type = s.wave;
    const note = Math.max(24, Math.min(108, midi + (s.octave || 0) * 12));
    o.frequency.value = freq(note);
    if (kind === 'lead') o.detune.value = 6;
    const f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = s.cutoff;
    f.Q.value = s.q;
    const g = ctx.createGain();
    const peak = clamp(vel, 0, 1) * (kind === 'bass' ? 0.34 : 0.24);
    const hold = Math.max(0.03, duration * 0.72);
    env(ctx, g.gain, time, s.attack, s.decay, s.sustain, s.release, peak, hold);
    o.connect(f);
    f.connect(g);
    g.connect(bus);
    o.start(time);
    o.stop(time + hold + s.release + 0.05);
  }

  function scheduleStep(ctx, buses, pattern, step, time) {
    const p = project.patterns[pattern];
    if (!p) return;
    for (const d of DRUMS) if (p.drums[d.id]?.[step]) playDrum(ctx, buses.drums[d.id], d.id, time, p.drums[d.id][step]);
    if (p.bass[step] != null) playSynth(ctx, buses.bass, p.bass[step], time, runtime.stepDur * 0.9, 0.9, 'bass');
    if (p.lead[step] != null) playSynth(ctx, buses.lead, p.lead[step], time, runtime.stepDur * 0.8, 0.8, 'lead');
  }

  function ensureAudio() {
    if (!runtime.ac) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) throw new Error('Audio wird hier nicht unterstützt.');
      runtime.ac = new AC();
      runtime.graph = buildGraph(runtime.ac, runtime.ac.destination);
      runtime.buses = buildBuses(runtime.ac, runtime.graph);
    }
    if (runtime.ac.state === 'suspended') runtime.ac.resume().catch(() => {});
    return runtime.ac;
  }

  function syncGraph() {
    if (!runtime.graph) return;
    runtime.graph.filter.frequency.setTargetAtTime(project.fx.filter, runtime.ac.currentTime, 0.02);
    runtime.graph.drive.curve = curve(project.fx.drive);
    runtime.graph.master.gain.setTargetAtTime(project.master, runtime.ac.currentTime, 0.02);
    runtime.graph.delay.delayTime.setTargetAtTime(Math.round((60 / project.bpm / 2) * 1000) / 1000, runtime.ac.currentTime, 0.02);
    runtime.graph.feedback.gain.setTargetAtTime(project.fx.feedback, runtime.ac.currentTime, 0.02);
    runtime.graph.delayWet.gain.setTargetAtTime(project.fx.delay, runtime.ac.currentTime, 0.02);
    runtime.graph.reverbWet.gain.setTargetAtTime(project.fx.reverb, runtime.ac.currentTime, 0.02);
  }

  function paintStep() {
    document.querySelectorAll('.step.now, .pcell.now').forEach((el) => el.classList.remove('now'));
    if (currentStep < 0) {
      $('pos').textContent = '1 · 1';
      return;
    }
    document.querySelectorAll(`[data-step="${currentStep}"]`).forEach((el) => el.classList.add('now'));
    $('pos').textContent = `${currentPattern + 1} · ${currentStep + 1}`;
  }

  function tick() {
    if (!playing || !runtime.ac) return;
    const now = runtime.ac.currentTime;
    while (runtime.queue.length && runtime.queue[0].time <= now + 0.03) {
      const q = runtime.queue.shift();
      currentStep = q.step;
      currentPattern = q.pat;
      paintStep();
    }
    runtime.raf = requestAnimationFrame(tick);
  }

  function start(song = false) {
    try {
      ensureAudio();
    } catch (e) {
      return toast(e.message, 'error');
    }
    stop(false);
    playing = true;
    songMode = song;
    runtime.step = 0;
    runtime.chainPos = 0;
    runtime.queue = [];
    runtime.next = runtime.ac.currentTime + 0.06;
    runtime.stepDur = 60 / project.bpm / 4;
    $('play').textContent = '❚❚';
    $('play').classList.add('on');
    $('live-dot').classList.add('on');
    $('status').textContent = song ? 'Song läuft' : 'Pattern läuft';
    runtime.timer = setInterval(() => {
      if (!playing) return;
      const ac = runtime.ac;
      const stepDur = 60 / project.bpm / 4;
      runtime.stepDur = stepDur;
      while (runtime.next < ac.currentTime + 0.14) {
        const patIndex = songMode ? project.chain[clamp(runtime.chainPos, 0, Math.max(0, project.chain.length - 1))] ?? active : active;
        let at = runtime.next;
        if (runtime.step % 2 === 1) at += (project.swing / 100) * stepDur * 0.35;
        scheduleStep(ac, runtime.buses, patIndex, runtime.step, at);
        runtime.queue.push({ step: runtime.step, time: at, pat: patIndex });
        runtime.next += stepDur;
        runtime.step += 1;
        if (runtime.step >= STEPS) {
          runtime.step = 0;
          if (songMode && project.chain.length) runtime.chainPos = (runtime.chainPos + 1) % project.chain.length;
        }
      }
    }, 25);
    cancelAnimationFrame(runtime.raf);
    runtime.raf = requestAnimationFrame(tick);
  }

  function stop(render = true) {
    playing = false;
    clearInterval(runtime.timer);
    cancelAnimationFrame(runtime.raf);
    runtime.queue = [];
    currentStep = -1;
    $('play').textContent = '▶';
    $('play').classList.remove('on');
    $('live-dot').classList.remove('on');
    $('status').textContent = 'Bereit';
    paintStep();
    if (render) renderAll();
  }

  /* --------------------------------------------------------------------- UI */
  const pattern = () => project.patterns[active];

  function renderKits() {
    $('kits').innerHTML = Object.entries(KITS)
      .map(([id, k]) => `<button class="kit ${project.kit === id ? 'on' : ''}" data-kit="${id}" style="--kc:${k.color}"><i></i><div><b>${k.name}</b><small>${k.sub}</small></div></button>`)
      .join('');
  }

  function renderPatterns() {
    $('patterns').innerHTML = project.patterns
      .map((p, i) => {
        const count = DRUMS.reduce((a, d) => a + p.drums[d.id].filter(Boolean).length, 0) + p.bass.filter((n) => n != null).length + p.lead.filter((n) => n != null).length;
        return `<button class="pat ${active === i ? 'on' : ''}" data-pattern="${i}"><b>${'ABCD'[i]}</b><small>${count} Hits</small></button>`;
      })
      .join('');
  }

  function renderChain() {
    $('chain').innerHTML = project.chain.length
      ? project.chain.map((p, i) => `<button class="chain-chip" data-chain="${i}" title="Takt ${i + 1} entfernen">${'ABCD'[p]}<span>${i + 1}</span></button>`).join('')
      : '<span class="hint">Noch keine Takte – „+ Takt“ fügt das aktuelle Pattern hinzu.</span>';
  }

  function renderGrid() {
    const p = pattern();
    const head = `<div class="step-head"><span></span>${Array.from({ length: STEPS }, (_, i) => `<b class="${i % 4 === 0 ? 'bar' : ''}">${i + 1}</b>`).join('')}</div>`;
    if (view === 'drums') {
      $('grid').innerHTML =
        head +
        DRUMS.map(
          (d) => `<div class="drow"><div class="dname ${selectedTrack === d.id ? 'on' : ''}" data-track="${d.id}" style="--dc:${d.color}"><i></i><span>${d.name}</span><button class="dmute ${project.mix[d.id].mute ? 'on' : ''}" data-mute="${d.id}" title="Stumm">M</button></div>${Array.from({ length: STEPS }, (_, s) => `<button class="step ${p.drums[d.id][s] ? 'on' : ''} ${p.drums[d.id][s] > 0.8 ? 'accent' : ''}" data-drum="${d.id}" data-step="${s}" style="--dc:${d.color}" title="${d.name} · Schritt ${s + 1}"></button>`).join('')}</div>`,
        ).join('');
      return;
    }
    const notes = view === 'bass' ? [...LANES.bass].reverse() : [...LANES.lead].reverse();
    $('grid').innerHTML =
      head +
      notes
        .map(
          (n) => `<div class="drow note-row"><button class="dname" data-note-preview="${n}"><span>${noteName(n)}</span></button>${Array.from({ length: STEPS }, (_, s) => `<button class="step pcell ${p[view][s] === n ? 'on' : ''}" data-lane-note="${n}" data-step="${s}" style="--dc:${view === 'bass' ? '#38bdf8' : '#a78bfa'}" title="${noteName(n)} · Schritt ${s + 1}"></button>`).join('')}</div>`,
        )
        .join('');
  }

  function renderRoll() {
    $('roll-track').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.lane === lane));
    const p = pattern();
    const notes = lane === 'bass' ? [...LANES.bass].reverse() : [...LANES.lead].reverse();
    $('roll-info').textContent = `${LANE_NAME[lane]} · ${noteName(notes[notes.length - 1])}–${noteName(notes[0])}`;
    $('roll').innerHTML = notes
      .map(
        (n) => `<div class="rrow"><span>${noteName(n)}</span>${Array.from({ length: STEPS }, (_, s) => `<button class="pcell ${p[lane][s] === n ? 'on' : ''}" data-lane-note="${n}" data-step="${s}" data-lane="${lane}" title="${noteName(n)} · Schritt ${s + 1}"></button>`).join('')}</div>`,
      )
      .join('');
  }

  function mixRow(id, label, mix, color) {
    return `<div class="mix-row mix-strip" style="--mc:${color}">
      <div class="mix-head"><b>${esc(label)}</b><button class="mute ${mix.mute ? 'on' : ''}" data-mix-mute="${id}" title="${esc(label)} stumm schalten">M</button></div>
      <label class="mix-fader"><span>Vol</span><input type="range" min="0" max="1" step="0.01" value="${mix.vol}" data-mix-vol="${id}" title="Lautstärke" /></label>
      <label class="mix-fader"><span>Pan</span><input type="range" min="-1" max="1" step="0.05" value="${mix.pan}" data-mix-pan="${id}" title="Panorama" /></label>
    </div>`;
  }

  function renderMixer() {
    $('mixer').innerHTML = `<div class="mixer-grid">${DRUMS.map((d) => mixRow(d.id, d.name, project.mix[d.id], d.color)).join('') + mixRow('bass', 'Bass', project.synthMix.bass, '#38bdf8') + mixRow('lead', 'Lead', project.synthMix.lead, '#a78bfa')}</div>`;
  }

  function synthHtml() {
    const s = project.synth;
    return `<div class="synth-grid">
      <label>Welle<select data-synth="wave" class="select">${['sawtooth', 'square', 'triangle', 'sine'].map((w) => `<option value="${w}" ${s.wave === w ? 'selected' : ''}>${w}</option>`).join('')}</select></label>
      <label>Filter <b data-val="cutoff">${s.cutoff} Hz</b><input type="range" min="120" max="12000" step="10" value="${s.cutoff}" data-synth="cutoff" /></label>
      <label>Resonanz <b data-val="q">${s.q.toFixed(1)}</b><input type="range" min="0.1" max="18" step="0.1" value="${s.q}" data-synth="q" /></label>
      <label>Attack <b data-val="attack">${Math.round(s.attack * 1000)} ms</b><input type="range" min="0.002" max="1" step="0.002" value="${s.attack}" data-synth="attack" /></label>
      <label>Decay <b data-val="decay">${Math.round(s.decay * 1000)} ms</b><input type="range" min="0.01" max="1.5" step="0.01" value="${s.decay}" data-synth="decay" /></label>
      <label>Sustain <b data-val="sustain">${Math.round(s.sustain * 100)}%</b><input type="range" min="0" max="1" step="0.01" value="${s.sustain}" data-synth="sustain" /></label>
      <label>Release <b data-val="release">${Math.round(s.release * 1000)} ms</b><input type="range" min="0.01" max="2" step="0.01" value="${s.release}" data-synth="release" /></label>
      <label>Oktave <b data-val="octave">${s.octave > 0 ? '+' : ''}${s.octave}</b><input type="range" min="-2" max="2" step="1" value="${s.octave}" data-synth="octave" /></label>
    </div>
    <div class="chips-row"><button class="btn small" data-synth-preset="sub">Sub (tief)</button><button class="btn small" data-synth-preset="bass">Bass</button><button class="btn small" data-synth-preset="pluck">Pluck</button><button class="btn small" data-synth-preset="pad">Pad</button><button class="btn small" data-synth-preset="lead">Lead</button><button class="btn small" data-synth-preset="air">Air (hoch)</button></div>
    <div class="chips-row tune-row"><span>Kick-Tune</span><input type="range" min="-12" max="12" step="1" value="${project.mix.kick.tune || 0}" data-mix-tune="kick" /><b>${project.mix.kick.tune || 0}</b></div>`;
  }

  function renderSynth() {
    $('synth').innerHTML = synthHtml();
  }

  function renderFx() {
    const f = project.fx;
    $('fx').innerHTML = `
      <label class="fx-field">Filter <b>${f.filter} Hz</b><input type="range" min="200" max="18000" step="50" value="${f.filter}" data-fx="filter" /></label>
      <label class="fx-field">Drive <b>${Math.round(f.drive * 100)}%</b><input type="range" min="0" max="1" step="0.01" value="${f.drive}" data-fx="drive" /></label>
      <label class="fx-field">Delay <b>${Math.round(f.delay * 100)}%</b><input type="range" min="0" max="1" step="0.01" value="${f.delay}" data-fx="delay" /></label>
      <label class="fx-field">Feedback <b>${Math.round(f.feedback * 100)}%</b><input type="range" min="0" max="0.85" step="0.01" value="${f.feedback}" data-fx="feedback" /></label>
      <label class="fx-field">Hall <b>${Math.round(f.reverb * 100)}%</b><input type="range" min="0" max="1" step="0.01" value="${f.reverb}" data-fx="reverb" /></label>
      <div class="chips-row"><button class="btn small" data-fx-preset="clean">Clean</button><button class="btn small" data-fx-preset="warm">Warm</button><button class="btn small" data-fx-preset="dub">Dub</button><button class="btn small" data-fx-preset="acid">Acid</button></div>`;
  }

  function renderAll() {
    renderKits();
    renderPatterns();
    renderChain();
    renderGrid();
    renderRoll();
    renderMixer();
    renderSynth();
    renderFx();
    $('bpm').value = project.bpm;
    $('swing').value = project.swing;
    $('swingv').textContent = `${project.swing}%`;
    $('master').value = Math.round(project.master * 100);
    $('masterv').textContent = `${Math.round(project.master * 100)}%`;
    $('pat-name').textContent = `Pattern ${'ABCD'[active]}`;
    $('seq-info').textContent = `16 Schritte · ${KITS[project.kit].name}`;
    $('scale').value = project.scale;
    $('song').textContent = songMode ? 'Song läuft …' : 'Song abspielen';
    paintStep();
  }

  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try {
        await api.save(project);
        $('status').textContent = 'Gespeichert';
      } catch (e) {
        toast('Speichern fehlgeschlagen.', 'error');
      }
    }, 120);
  }

  function toast(text, kind = '') {
    const el = $('toast');
    el.textContent = text;
    el.className = `toast ${kind}`;
    el.hidden = false;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (el.hidden = true), 3000);
  }

  function updateProp(key, value) {
    project.synth[key] = value;
    const label = document.querySelector(`[data-val="${key}"]`);
    if (label) {
      const v = Number(value);
      label.textContent = key === 'cutoff' ? `${Math.round(v)} Hz` : key === 'q' ? v.toFixed(1) : key === 'sustain' ? `${Math.round(v * 100)}%` : key === 'octave' ? `${v > 0 ? '+' : ''}${v}` : `${Math.round(v * 1000)} ms`;
    }
  }

  function previewDrum(id) {
    try {
      const ac = ensureAudio();
      playDrum(ac, runtime.buses.drums[id], id, ac.currentTime + 0.01, 0.9);
    } catch {
      /* kein Audio */
    }
  }

  function previewNote(midi) {
    try {
      const ac = ensureAudio();
      playSynth(ac, runtime.buses[lane], midi, ac.currentTime + 0.01, runtime.stepDur * 0.8, 0.8, lane);
    } catch {
      /* kein Audio */
    }
  }

  /* ----------------------------------------------------------------- Events */
  document.addEventListener('click', (event) => {
    const t = event.target;
    const kit = t.closest('[data-kit]')?.dataset.kit;
    if (kit) {
      project.kit = kit;
      renderAll();
      save();
      return;
    }
    const pat = t.closest('[data-pattern]')?.dataset.pattern;
    if (pat) {
      active = Number(pat);
      renderAll();
      return;
    }
    const cv = t.closest('[data-view]')?.dataset.view;
    if (cv) {
      view = cv;
      $('grid-view').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.view === cv));
      if (cv !== 'drums') lane = cv;
      renderGrid();
      renderRoll();
      return;
    }
    const lt = t.closest('[data-lane]')?.dataset.lane;
    if (lt) {
      lane = lt;
      renderRoll();
      return;
    }
    const mute = t.closest('[data-mute]')?.dataset.mute;
    if (mute) {
      project.mix[mute].mute = !project.mix[mute].mute;
      renderGrid();
      renderMixer();
      if (runtime.buses) runtime.buses.drums[mute].gain.value = project.mix[mute].mute ? 0 : project.mix[mute].vol;
      save();
      return;
    }
    const track = t.closest('[data-track]')?.dataset.track;
    if (track) {
      selectedTrack = track;
      renderGrid();
      return;
    }
    const drum = t.closest('[data-drum]');
    if (drum) {
      const p = pattern();
      const s = Number(drum.dataset.step);
      p.drums[drum.dataset.drum][s] = p.drums[drum.dataset.drum][s] ? 0 : event.shiftKey ? 0.55 : 0.9;
      renderGrid();
      renderPatterns();
      previewDrum(drum.dataset.drum);
      save();
      return;
    }
    const noteCell = t.closest('[data-lane-note]');
    if (noteCell) {
      const s = Number(noteCell.dataset.step);
      const n = Number(noteCell.dataset.laneNote);
      const laneId = noteCell.dataset.lane || view;
      const p = pattern();
      p[laneId][s] = p[laneId][s] === n ? null : n;
      renderGrid();
      renderRoll();
      renderPatterns();
      previewNote(n);
      save();
      return;
    }
    const preview = t.closest('[data-note-preview]')?.dataset.notePreview;
    if (preview) return previewNote(Number(preview));
    const mixMute = t.closest('[data-mix-mute]')?.dataset.mixMute;
    if (mixMute) {
      const obj = [ 'bass', 'lead' ].includes(mixMute) ? project.synthMix[mixMute] : project.mix[mixMute];
      obj.mute = !obj.mute;
      renderMixer();
      renderGrid();
      applyMix();
      save();
      return;
    }
    const chainRemove = t.closest('[data-chain]')?.dataset.chain;
    if (chainRemove != null) {
      if (project.chain.length <= 1) return toast('Mindestens ein Takt bleibt.');
      project.chain.splice(Number(chainRemove), 1);
      renderChain();
      save();
      return;
    }
    const preset = t.closest('[data-synth-preset]')?.dataset.synthPreset;
    if (preset) {
      Object.assign(project.synth, {
        bass: { wave: 'sine', cutoff: 520, q: 1.6, attack: 0.006, decay: 0.22, sustain: 0.45, release: 0.12, octave: -1 },
        sub: { wave: 'sine', cutoff: 280, q: 1.2, attack: 0.01, decay: 0.35, sustain: 0.7, release: 0.18, octave: 0 },
        pluck: { wave: 'triangle', cutoff: 2400, q: 2.2, attack: 0.004, decay: 0.14, sustain: 0.05, release: 0.18, octave: 0 },
        pad: { wave: 'sawtooth', cutoff: 900, q: 1.1, attack: 0.35, decay: 0.5, sustain: 0.7, release: 0.9, octave: 0 },
        lead: { wave: 'square', cutoff: 3200, q: 1.4, attack: 0.008, decay: 0.2, sustain: 0.35, release: 0.2, octave: 1 },
        air: { wave: 'triangle', cutoff: 6200, q: 0.8, attack: 0.004, decay: 0.1, sustain: 0.2, release: 0.12, octave: 2 },
      }[preset]);
      renderSynth();
      save();
      return;
    }
    const groove = t.closest('[data-groove]')?.dataset.groove;
    if (groove) return applyGroove(groove);
    const transpose = t.closest('[data-transpose]')?.dataset.transpose;
    if (transpose) {
      const p = pattern();
      for (const id of ['bass', 'lead']) p[id] = p[id].map((n) => (n == null ? null : clamp(n + Number(transpose), 24, 96)));
      renderGrid();
      renderRoll();
      save();
      return toast(`Bass und Lead ${Number(transpose) > 0 ? 'eine Oktave höher' : 'eine Oktave tiefer'}.`);
    }
    const fxPreset = t.closest('[data-fx-preset]')?.dataset.fxPreset;
    if (fxPreset) {
      Object.assign(
        project.fx,
        {
          clean: { filter: 18000, drive: 0.02, delay: 0.08, feedback: 0.16, reverb: 0.08 },
          warm: { filter: 7200, drive: 0.16, delay: 0.14, feedback: 0.24, reverb: 0.24 },
          dub: { filter: 5200, drive: 0.1, delay: 0.42, feedback: 0.55, reverb: 0.34 },
          acid: { filter: 2400, drive: 0.38, delay: 0.18, feedback: 0.38, reverb: 0.12 },
        }[fxPreset],
      );
      renderFx();
      syncGraph();
      save();
      return toast(`FX-Preset „${fxPreset}“ geladen.`);
    }
  });

  document.addEventListener('input', (event) => {
    const el = event.target;
    if (el.id === 'bpm') {
      project.bpm = clamp(Number(el.value) || 120, 50, 220);
      syncGraph();
      save();
    } else if (el.id === 'swing') {
      project.swing = Number(el.value);
      $('swingv').textContent = `${project.swing}%`;
      save();
    } else if (el.id === 'master') {
      project.master = Number(el.value) / 100;
      $('masterv').textContent = `${el.value}%`;
      if (runtime.graph) runtime.graph.master.gain.setTargetAtTime(project.master, runtime.ac.currentTime, 0.02);
      save();
    } else if (el.dataset.mixVol) {
      const id = el.dataset.mixVol;
      const obj = ['bass', 'lead'].includes(id) ? project.synthMix[id] : project.mix[id];
      obj.vol = Number(el.value);
      applyMix();
      save();
    } else if (el.dataset.mixPan) {
      const id = el.dataset.mixPan;
      const obj = ['bass', 'lead'].includes(id) ? project.synthMix[id] : project.mix[id];
      obj.pan = Number(el.value);
      applyMix();
      save();
    } else if (el.dataset.mixTune) {
      project.mix[el.dataset.mixTune].tune = Number(el.value);
      el.parentElement.querySelector('b').textContent = el.value;
      save();
    } else if (el.dataset.synth) {
      const key = el.dataset.synth;
      updateProp(key, key === 'wave' ? el.value : Number(el.value));
      if (key === 'wave') renderSynth();
      save();
    } else if (el.dataset.fx) {
      const key = el.dataset.fx;
      project.fx[key] = Number(el.value);
      const b = el.parentElement.querySelector('b');
      if (b) b.textContent = key === 'filter' ? `${el.value} Hz` : `${Math.round(Number(el.value) * 100)}%`;
      syncGraph();
      save();
    }
  });

  document.addEventListener('change', (event) => {
    if (event.target.id === 'scale') {
      project.scale = event.target.value;
      save();
    }
  });

  $('play').addEventListener('click', () => (playing ? stop() : start(false)));
  $('stop').addEventListener('click', () => stop());
  $('song').addEventListener('click', () => (playing && songMode ? stop() : start(true)));
  $('save').addEventListener('click', async () => {
    try {
      await api.save(project);
      $('status').textContent = 'Gespeichert';
      toast('Projekt gespeichert.');
    } catch {
      toast('Speichern fehlgeschlagen.', 'error');
    }
  });
  $('new').addEventListener('click', () => {
    stop();
    project = { ...defaultProject(), name: 'Leeres Projekt', patterns: Array.from({ length: PATTERNS }, blankPattern), chain: [0] };
    active = 0;
    songMode = false;
    renderAll();
    save();
    toast('Leeres Projekt – leg los.');
  });
  $('copy').addEventListener('click', () => {
    const next = (active + 1) % PATTERNS;
    project.patterns[next] = JSON.parse(JSON.stringify(pattern()));
    renderPatterns();
    toast(`Pattern ${'ABCD'[active]} nach ${'ABCD'[next]} kopiert.`);
    save();
  });
  $('clear').addEventListener('click', () => {
    project.patterns[active] = blankPattern();
    renderAll();
    save();
  });
  $('random').addEventListener('click', () => {
    randomize();
  });
  $('chain-add').addEventListener('click', () => {
    project.chain.push(active);
    renderChain();
    save();
  });
  $('chain-del').addEventListener('click', () => {
    if (project.chain.length <= 1) return toast('Mindestens ein Takt bleibt.');
    project.chain.pop();
    renderChain();
    save();
  });
  $('tap').addEventListener('click', tap);

  document.addEventListener('keydown', (event) => {
    if (event.target.closest('input, textarea, select')) return;
    const key = event.key.toLowerCase();
    if (event.code === 'Space') {
      event.preventDefault();
      return playing ? stop() : start(false);
    }
    if (['1', '2', '3', '4'].includes(key)) {
      active = Number(key) - 1;
      return renderAll();
    }
    if (key === 'r') return randomize();
    if (key === 'delete' || key === 'backspace') {
      project.patterns[active] = blankPattern();
      return renderAll();
    }
    if (key === 's' && !event.ctrlKey) return $('save').click();
    if (key === 'e' && !event.ctrlKey) return $('export').click();
  });

  function applyMix() {
    if (!runtime.buses) return;
    for (const d of DRUMS) {
      const m = project.mix[d.id];
      runtime.buses.drums[d.id].gain.setTargetAtTime(m.mute ? 0 : m.vol, runtime.ac.currentTime, 0.02);
    }
    for (const id of ['bass', 'lead']) {
      const m = project.synthMix[id];
      runtime.buses[id].gain.setTargetAtTime(m.mute ? 0 : m.vol, runtime.ac.currentTime, 0.02);
    }
  }

  function randomize() {
    const p = blankPattern();
    const scale = { minor: [0, 2, 3, 5, 7, 8, 10], major: [0, 2, 4, 5, 7, 9, 11], penta: [0, 3, 5, 7, 10], blues: [0, 3, 5, 6, 7, 10], chromatic: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] }[project.scale] || [0, 2, 3, 5, 7, 8, 10];
    const chance = { kick: 0.4, snare: 0.2, clap: 0.1, hat: 0.4, openhat: 0.08, tom: 0.1, rim: 0.1, cowbell: 0.06, shaker: 0.22, crash: 0.04, ride: 0.06, perc: 0.08 };
    for (const d of DRUMS) for (let s = 0; s < STEPS; s += 1) if (Math.random() < chance[d.id]) p.drums[d.id][s] = Math.random() < 0.2 ? 0.55 : 0.9;
    p.drums.kick[0] = 0.95;
    for (const id of ['bass', 'lead']) {
      const range = id === 'bass' ? LANES.bass : LANES.lead;
      for (let s = 0; s < STEPS; s += 1) {
        if (Math.random() < (id === 'bass' ? 0.34 : 0.16)) {
          const root = id === 'bass' ? 36 : 60;
          const deg = scale[Math.floor(Math.random() * scale.length)];
          const oct = Math.random() < 0.2 ? 12 : 0;
          const note = root + deg + oct;
          if (range.includes(note)) p[id][s] = note;
        }
      }
    }
    project.patterns[active] = p;
    renderAll();
    toast('Neues Pattern gewürfelt.');
    save();
  }

  /** Fertige Grooves und Hilfen für schnelle Ideen. */
  function applyGroove(kind) {
    const p = pattern();
    const put = (id, steps, vel = 0.8) => steps.forEach((s) => (p.drums[id][s] = vel));
    const wipe = () => {
      for (const d of DRUMS) p.drums[d.id].fill(0);
      p.bass.fill(null);
      p.lead.fill(null);
    };
    const scale = { minor: [0, 2, 3, 5, 7, 8, 10], major: [0, 2, 4, 5, 7, 9, 11], penta: [0, 3, 5, 7, 10], blues: [0, 3, 5, 6, 7, 10], chromatic: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] }[project.scale] || [0, 2, 3, 5, 7, 8, 10];
    if (kind === 'humanize') {
      for (const d of DRUMS) p.drums[d.id] = p.drums[d.id].map((v) => (v ? clamp(v + (Math.random() - 0.5) * 0.2, 0.2, 1) : 0));
      renderGrid();
      save();
      return toast('Anschläge leicht variiert.');
    }
    wipe();
    if (kind === 'house') {
      put('kick', [0, 4, 8, 12], 0.95);
      put('clap', [4, 12], 0.62);
      put('openhat', [2, 6, 10, 14], 0.42);
      put('shaker', [1, 3, 5, 7, 9, 11, 13, 15], 0.25);
      [36, 36, 39, 43].forEach((n, i) => (p.bass[i * 4] = n));
      [60, 63, 67, 70].forEach((n, i) => (p.lead[i * 4 + 2] = n));
    } else if (kind === 'trap') {
      put('kick', [0, 6, 10], 0.95);
      put('snare', [8], 0.72);
      for (let s = 0; s < STEPS; s += 1) put('hat', [s], s % 2 ? 0.24 : 0.38);
      put('openhat', [14], 0.34);
      p.bass[0] = 36; p.bass[6] = 36; p.bass[10] = 39; p.bass[14] = 34;
      p.lead[2] = 72; p.lead[7] = 75; p.lead[12] = 70;
    } else if (kind === 'break') {
      put('kick', [0, 3, 6, 10, 13], 0.9);
      put('snare', [4, 12], 0.8);
      put('hat', [0, 2, 4, 6, 8, 10, 12, 14], 0.38);
      put('shaker', [1, 5, 9, 13], 0.22);
      p.bass[0] = 36; p.bass[3] = 36; p.bass[6] = 39; p.bass[10] = 41; p.bass[13] = 36;
      p.lead[4] = 64; p.lead[8] = 67; p.lead[12] = 71;
    } else if (kind === 'fill') {
      put('snare', [8, 10, 12, 13, 14, 15], 0.55);
      put('tom', [12, 13, 14, 15], 0.7);
      put('crash', [0], 0.35);
      p.lead[8] = 72; p.lead[10] = 75; p.lead[12] = 79; p.lead[14] = 84;
    } else if (kind === 'arp') {
      p.bass[0] = 36; p.bass[8] = 39;
      const notes = LANES.lead;
      for (let s = 0; s < STEPS; s += 2) p.lead[s] = notes[(s / 2) % notes.length];
    }
    project.patterns[active] = p;
    renderGrid();
    renderRoll();
    renderPatterns();
    save();
    toast(`Groove „${kind}“ eingesetzt.`);
  }

  let taps = [];
  function tap() {
    const now = performance.now();
    taps = taps.filter((t) => now - t < 2400);
    taps.push(now);
    if (taps.length >= 2) {
      const diffs = taps.slice(1).map((t, i) => t - taps[i]);
      const avg = diffs.reduce((a, b) => a + b, 0) / diffs.length;
      project.bpm = clamp(Math.round(60000 / avg), 50, 220);
      $('bpm').value = project.bpm;
      syncGraph();
      save();
    }
    $('tap').classList.add('on');
    setTimeout(() => $('tap').classList.remove('on'), 120);
  }

  /* ----------------------------------------------------------------- Export */
  function encodeWav(buffer) {
    const channels = buffer.numberOfChannels;
    const frames = buffer.length;
    const bytes = frames * channels * 2;
    const ab = new ArrayBuffer(44 + bytes);
    const view = new DataView(ab);
    const text = (offset, str) => {
      for (let i = 0; i < str.length; i += 1) view.setUint8(offset + i, str.charCodeAt(i));
    };
    text(0, 'RIFF');
    view.setUint32(4, 36 + bytes, true);
    text(8, 'WAVE');
    text(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, channels, true);
    view.setUint32(24, buffer.sampleRate, true);
    view.setUint32(28, buffer.sampleRate * channels * 2, true);
    view.setUint16(32, channels * 2, true);
    view.setUint16(34, 16, true);
    text(36, 'data');
    view.setUint32(40, bytes, true);
    let offset = 44;
    const data = Array.from({ length: channels }, (_, c) => buffer.getChannelData(c));
    for (let i = 0; i < frames; i += 1) {
      for (let c = 0; c < channels; c += 1) {
        const s = clamp(data[c][i], -1, 1);
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
        offset += 2;
      }
    }
    return ab;
  }

  async function exportWav() {
    const chain = project.chain.length ? project.chain : [active];
    const stepDur = 60 / project.bpm / 4;
    const duration = chain.length * STEPS * stepDur + 2.4;
    toast('Rendere WAV …');
    stop(false);
    try {
      const Offline = window.OfflineAudioContext || window.webkitOfflineAudioContext;
      const off = new Offline(2, Math.ceil(duration * 44100), 44100);
      const graph = buildGraph(off, off.destination);
      const buses = buildBuses(off, graph);
      let at = 0.04;
      for (const pat of chain) {
        for (let s = 0; s < STEPS; s += 1) {
          const swing = s % 2 ? (project.swing / 100) * stepDur * 0.35 : 0;
          scheduleStep(off, buses, pat, s, at + swing);
          at += stepDur;
        }
      }
      const rendered = await off.startRendering();
      const wav = encodeWav(rendered);
      const result = await api.exportWav(wav, project.name || 'beat');
      if (result?.ok) toast(`WAV gespeichert: ${result.file.split(/[\\/]/).pop()}`);
      else if (!result?.canceled) toast('Export abgebrochen.', 'error');
    } catch (e) {
      toast(`Export fehlgeschlagen: ${e.message}`, 'error');
    }
  }
  $('export').addEventListener('click', exportWav);

  /* ------------------------------------------------------------------- Start */
  (async () => {
    try {
      const saved = await api.load();
      if (saved && saved.patterns) {
        project = { ...defaultProject(), ...saved, synth: { ...defaultProject().synth, ...(saved.synth || {}) }, fx: { ...defaultProject().fx, ...(saved.fx || {}) } };
        project.patterns = (Array.isArray(saved.patterns) ? saved.patterns : []).slice(0, PATTERNS).map((p) => ({ ...blankPattern(), ...p, drums: { ...blankPattern().drums, ...(p.drums || {}) } }));
        while (project.patterns.length < PATTERNS) project.patterns.push(blankPattern());
        for (const d of DRUMS) project.mix[d.id] = { ...defaultProject().mix[d.id], ...(saved.mix?.[d.id] || {}) };
      }
    } catch {
      /* erstes Mal */
    }
    renderAll();
  })();
})();
