'use strict';

/*
 * Handy spiegeln (AirPlay): iPhone-Bildschirm auf den PC holen.
 * Der Hub richtet den freien Empfänger „AirPlay-Windows“ ein, startet ihn und
 * zeigt dessen Spiegelungsfenster direkt in dieser Seite an (Fensteraufnahme).
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const active = () => ctx().state()?.active === 'tool-airplay';
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

  const ap = { st: null, loading: false, busy: '', stream: null, poll: 0 };

  window.hub.onAirPlay?.((st) => {
    if (st && !st.running && ap.stream) {
      ap.stream.getTracks().forEach((t) => t.stop());
      ap.stream = null;
    }
    ap.st = st;
    if (active() && !ap.stream) ctx().render();
  });

  async function load() {
    if (ap.loading) return;
    ap.loading = true;
    try {
      ap.st = await window.hub.airplay.status();
    } catch (error) {
      ap.st = { installed: false, running: false, error: errText(error) };
    }
    ap.loading = false;
    if (active() && !ap.stream) ctx().render();
  }

  function attach() {
    const video = document.getElementById('ap-video');
    if (video && ap.stream) {
      video.srcObject = ap.stream;
      video.play?.().catch(() => {});
    }
  }

  async function watch() {
    if (ap.stream || ap.busy) return;
    ap.busy = 'watch';
    ctx().render();
    try {
      await window.hub.airplay.arm();
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 60 }, audio: false });
      ap.stream = stream;
      stream.getVideoTracks()[0]?.addEventListener('ended', () => {
        ap.stream = null;
        if (active()) ctx().render();
      });
      ctx().toast('Spiegelung wird angezeigt – am iPhone „Bildschirmspiegelung“ wählen.');
    } catch {
      ctx().toast('Empfänger-Fenster nicht gefunden – starte ihn und versuche es erneut.', 'error');
    }
    ap.busy = '';
    if (active()) ctx().render();
  }

  function unwatch() {
    ap.stream?.getTracks().forEach((t) => t.stop());
    ap.stream = null;
    ctx().render();
  }

  async function doStart() {
    ap.busy = 'start';
    ctx().render();
    try {
      ap.st = await window.hub.airplay.start();
      ctx().toast('Empfänger gestartet – am iPhone im Kontrollzentrum „Bildschirmspiegelung“ wählen.');
    } catch (error) {
      ctx().toast(errText(error), 'error');
    }
    ap.busy = '';
    await load();
  }

  async function doStop() {
    unwatch();
    ap.busy = 'stop';
    try {
      ap.st = await window.hub.airplay.stop();
    } catch (error) {
      ctx().toast(errText(error), 'error');
    }
    ap.busy = '';
    if (active()) ctx().render();
  }

  async function doInstall() {
    ap.busy = 'install';
    ctx().render();
    try {
      ap.st = await window.hub.airplay.install();
      if (ap.st.error) ctx().toast(ap.st.error, 'error');
      else ctx().toast('Empfänger eingerichtet.');
    } catch (error) {
      ctx().toast(errText(error), 'error');
    }
    ap.busy = '';
    if (active()) ctx().render();
  }

  function statusPill() {
    if (ap.st?.installing) return `<span class="pill warn">Wird eingerichtet … ${Math.round((ap.st.installing || 0) * 100)} %</span>`;
    if (ap.st?.running) return '<span class="pill ok">Empfänger läuft</span>';
    if (ap.st?.installed) return '<span class="pill">Bereit</span>';
    return '<span class="pill">Nicht eingerichtet</span>';
  }

  function html() {
    if (!ap.st) {
      load();
      return '<div class="tool-card"><p class="muted">Suche AirPlay-Empfänger …</p></div>';
    }
    const st = ap.st;
    clearTimeout(ap.poll);
    if (active() && !ap.stream && !ap.busy) ap.poll = setTimeout(() => active() && load(), st.installing ? 800 : 5000);

    if (st.installing) {
      return `<div class="tool-card"><div class="aj-hero"><span class="aj-ic">📱</span><div><b>AirPlay-Empfänger wird eingerichtet</b><small class="muted">Das offizielle Windows-Paket wird geladen und entpackt. Das dauert nur beim ersten Mal.</small></div></div>
        <div class="ph-bar ap-bar"><i style="width:${Math.round((st.installing || 0) * 100)}%"></i></div></div>`;
    }

    if (!st.installed) {
      return `<div class="tool-card"><div class="aj-hero"><span class="aj-ic">📱</span><div><b>iPhone auf den PC spiegeln</b><small class="muted">Der Hub richtet einen AirPlay-Empfänger ein. Danach erscheint dein PC am iPhone unter „Bildschirmspiegelung“ – die Anzeige läuft hier im Hub.</small></div></div>
        ${st.error ? `<p class="err">${esc(st.error)}</p>` : ''}
        <div class="ap-actions"><button class="btn primary" data-ap="install" ${ap.busy === 'install' ? 'disabled' : ''}>${ap.busy === 'install' ? 'Wird geladen …' : 'Empfänger einrichten'}</button>
          <button class="btn small ghost" data-ap="reload">Erneut prüfen</button></div>
        <p class="muted tool-note">Empfänger: <b>AirPlay-Windows</b> (GPL-3.0) aus den offiziellen GitHub-Releases – der Hub bündelt ihn nicht, sondern lädt ihn beim ersten Mal herunter. iPhone und PC müssen im selben WLAN sein.</p>
      </div>`;
    }

    const running = st.running;
    if (ap.stream) setTimeout(attach, 0);
    return `<div class="tool-card">
        <div class="list-row"><div class="grow"><strong>AirPlay-Empfänger</strong><small>${running ? 'Läuft – das iPhone findet den PC jetzt in der Bildschirmspiegelung.' : 'Bereit. Starten, dann am iPhone verbinden.'}${st.version ? ` · Version ${esc(st.version)}` : ''}</small></div>
          ${statusPill()}
          ${running ? `<button class="btn small" data-ap="stop" ${ap.busy ? 'disabled' : ''}>Stoppen</button>` : `<button class="btn primary small" data-ap="start" ${ap.busy ? 'disabled' : ''}>Starten</button>`}
          <button class="btn small ghost" data-ap="reload" title="Status neu prüfen">↻</button>
        </div>
        ${st.error ? `<p class="err">${esc(st.error)}</p>` : ''}
        <div class="ap-stage ${ap.stream ? 'on' : ''}">
          ${ap.stream ? '<video class="ap-video" id="ap-video" autoplay muted playsinline></video>' : `<div class="ap-empty"><span>📱</span><b>${running ? 'Bereit für dein iPhone' : 'Empfänger starten'}</b><small>${running ? 'Starte am iPhone die Bildschirmspiegelung und wähle „AirPlay-Windows“. Danach hier auf „Spiegelung anzeigen“.' : 'Danach sucht das iPhone den PC von selbst.'}</small></div>`}
        </div>
        <div class="ap-actions">
          ${ap.stream ? '<button class="btn small" data-ap="unwatch">Anzeige beenden</button>' : `<button class="btn primary" data-ap="watch" ${running && !ap.busy ? '' : 'disabled'}>${ap.busy === 'watch' ? 'Öffne …' : 'Spiegelung anzeigen'}</button>`}
          <button class="btn small ghost" data-ap="focus" ${running ? '' : 'disabled'}>Empfänger-Fenster nach vorn</button>
        </div>
        <ol class="ap-steps">
          <li>PC und iPhone im <b>selben WLAN</b>.</li>
          <li>Am iPhone: <b>Kontrollzentrum → Bildschirmspiegelung → AirPlay-Windows</b>.</li>
          <li>Wenn nach dem Verbinden nichts zu sehen ist: <b>„Spiegelung anzeigen“</b> drücken – dann wird das Empfänger-Fenster in den Hub geholt.</li>
          <li>Beim ersten Start fragt Windows nach der Firewall – <b>privates Netzwerk erlauben</b>.</li>
        </ol>
        <p class="muted tool-note">Der Empfänger läuft als eigenes Programm (GPL-3.0, <a href="#" data-ap="page">Projektseite</a>). Die Anzeige im Hub ist eine Fensteraufnahme; minimiere das Empfänger-Fenster nicht, sonst bleibt das Bild schwarz.</p>
      </div>`;
  }

  document.addEventListener('click', async (event) => {
    if (!active()) return;
    const el = event.target.closest?.('[data-ap]');
    if (!el) return;
    event.preventDefault();
    const action = el.dataset.ap;
    if (action === 'install') return doInstall();
    if (action === 'start') return doStart();
    if (action === 'stop') return doStop();
    if (action === 'watch') return watch();
    if (action === 'unwatch') return unwatch();
    if (action === 'reload') {
      ap.st = null;
      return ctx().render();
    }
    if (action === 'focus') {
      const ok = await window.hub.airplay.focus().catch(() => false);
      return ctx().toast(ok ? 'Empfänger-Fenster ist jetzt vorn.' : 'Fenster nicht gefunden – läuft der Empfänger?', ok ? '' : 'error');
    }
    if (action === 'page') {
      const page = await window.hub.airplay.page().catch(() => '');
      if (page) window.hub.external(page);
    }
  });

  T.register(
    'tool-airplay',
    { nav: 'Handy spiegeln', title: 'Handy spiegeln', sub: 'iPhone per AirPlay auf den PC', icon: 'maximize', tint: 'linear-gradient(135deg,#38bdf8,#0369a1)', desc: 'iPhone oder iPad per AirPlay auf den PC spiegeln: Empfänger einrichten, starten und die Spiegelung direkt im Hub ansehen – ohne Apple TV und ohne Konto.' },
    html,
  );
})();
