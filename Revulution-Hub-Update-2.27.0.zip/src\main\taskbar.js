'use strict';

/*
 * Windows-Taskleiste ausblenden, solange der Hub sichtbar ist.
 * Das Revulution-Dock übernimmt dann die Rolle der Taskleiste. Beim Minimieren,
 * Verstecken oder Beenden wird die Windows-Taskleiste immer wieder eingeblendet.
 */
const { execFile, execFileSync, spawn } = require('child_process');

const SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class RevTaskbar {
  private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct APPBARDATA { public int cbSize; public IntPtr hWnd; public uint uCallbackMessage; public uint uEdge; public RECT rc; public IntPtr lParam; }
  [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr extra);
  [DllImport("user32.dll")] private static extern int GetClassName(IntPtr hWnd, StringBuilder name, int max);
  [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int command);
  [DllImport("user32.dll")] private static extern void keybd_event(byte virtualKey, byte scan, uint flags, UIntPtr extra);
  [DllImport("shell32.dll")] private static extern IntPtr SHAppBarMessage(int msg, ref APPBARDATA data);
  private static int command = 5;
  public static int GetState() {
    var d = new APPBARDATA(); d.cbSize = Marshal.SizeOf(d);
    return (int)SHAppBarMessage(4, ref d);
  }
  public static void SetState(int state) {
    var d = new APPBARDATA(); d.cbSize = Marshal.SizeOf(d); d.lParam = (IntPtr)state;
    SHAppBarMessage(10, ref d);
  }
  private static bool Visit(IntPtr hWnd, IntPtr extra) {
    var name = new StringBuilder(64);
    GetClassName(hWnd, name, name.Capacity);
    var cls = name.ToString();
    if (cls == "Shell_TrayWnd" || cls == "Shell_SecondaryTrayWnd") ShowWindow(hWnd, command);
    return true;
  }
  public static void SetVisible(bool visible) {
    command = visible ? 5 : 0;
    EnumWindows(Visit, IntPtr.Zero);
  }
  public static void StartMenu() {
    keybd_event(0x5B, 0, 0, UIntPtr.Zero);
    keybd_event(0x5B, 0, 2, UIntPtr.Zero);
  }
}
'@
if (-not ('RevTaskbar' -as [type])) { Write-Output 'fail'; exit 1 }
if ($env:REVTASKBAR_ACTION -eq 'start') { [RevTaskbar]::StartMenu() }
else {
  $file = $env:REVTASKBAR_STATEFILE
  if ($env:REVTASKBAR_VISIBLE -ne '1') {
    // Auto-Hide setzen: erst dadurch wird die Arbeitsfläche bildschirmfüllend
    // und Vollbild-Apps reichen wirklich bis ganz nach unten.
    if ($file -and -not (Test-Path -LiteralPath $file)) { Set-Content -LiteralPath $file -Value ([RevTaskbar]::GetState()) }
    [RevTaskbar]::SetState(1)
    Start-Sleep -Milliseconds 120
    [RevTaskbar]::SetVisible($false)
  } else {
    [RevTaskbar]::SetVisible($true)
    if ($file -and (Test-Path -LiteralPath $file)) {
      $saved = [int](Get-Content -LiteralPath $file)
      [RevTaskbar]::SetState($saved)
      Remove-Item -LiteralPath $file -Force
    }
  }
}
Write-Output 'ok'
`;

const encodedScript = Buffer.from(SCRIPT, 'utf16le').toString('base64');
const PS_ARGS = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encodedScript];

/*
 * Ein einziger, kompilierter System-Wächter statt drei PowerShell-Schleifen:
 *  - Windows-Taste und „Esc 20 s halten“ per Tastatur-Hook (Ereignis statt Abfrage, ~0 % CPU)
 *  - Vollbild im Vordergrund: knapp einmal pro Sekunde
 *  - Windows-Taskleiste: solange sie versteckt sein soll, wird sie sofort wieder ausgeblendet,
 *    wenn Windows sie hochholt (alle 300 ms ein billiger FindWindow-Blick).
 */
const SYS_SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
public static class RevSys {
  delegate IntPtr HookProc(int n, IntPtr w, IntPtr l);
  delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [StructLayout(LayoutKind.Sequential)] struct KBD { public uint vk, scan, flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr h; public uint m; public IntPtr w, l; public uint t; public int x, y; }
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags; }
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr SetWindowsHookEx(int id, HookProc p, IntPtr h, uint t);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int n, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr h, uint a, uint b);
  [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string n);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
  [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr hWnd, uint flags);
  [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO info);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr hWnd, StringBuilder name, int max);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr hWnd, StringBuilder name, int max);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr hWnd);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int cmd);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindow(string cls, string title);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr parent, IntPtr after, string cls, string title);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc cb, IntPtr extra);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT { public ushort vk, scan; public uint flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx, dy; public uint data, flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] struct INPUTU { [FieldOffset(0)] public MOUSEINPUT m; [FieldOffset(0)] public KEYBDINPUT k; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public INPUTU u; }
  [DllImport("user32.dll")] static extern uint SendInput(uint n, INPUT[] i, int size);
  static INPUT Key(int vk, bool up, bool ext) { var i = new INPUT(); i.type = 1; i.u.k.vk = (ushort)vk; i.u.k.flags = (uint)((up ? 2 : 0) | (ext ? 1 : 0)); return i; }
  static int winVk = 0x5B;

  static HookProc proc = Hook;
  static readonly object outLock = new object();
  static volatile bool keepHidden;
  static bool winDown, combo;
  static long escSince = -1; static bool escFired;
  static int lastFull = -1, tick;

  static void Out(string s) { lock (outLock) { Console.Out.WriteLine(s); Console.Out.Flush(); } }

  /*
   * Windows-Taste: Solange die Hub-Leiste aktiv ist (keepHidden), wird sie geschluckt – kein
   * Startmenü. Allein gedrückt meldet sie „win“ (Hub-Menü). Kommt eine zweite Taste dazu
   * (Win+E, Win+D …), wird Win nachgereicht, damit die Windows-Kürzel weiter funktionieren.
   */
  static IntPtr Hook(int n, IntPtr w, IntPtr l) {
    if (n >= 0) {
      var k = (KBD)Marshal.PtrToStructure(l, typeof(KBD));
      int msg = w.ToInt32(); int vk = (int)k.vk;
      bool injected = (k.flags & 0x10) != 0;
      bool down = msg == 0x100 || msg == 0x104, up = msg == 0x101 || msg == 0x105;
      if (vk == 0x1B) {
        if (down) { if (escSince < 0) { escSince = Environment.TickCount; escFired = false; } }
        else if (up) escSince = -1;
      }
      if (!injected && (vk == 0x5B || vk == 0x5C)) {
        if (down && !winDown) { winDown = true; combo = false; winVk = vk; Out("windown"); }
        if (keepHidden) {
          if (up) {
            winDown = false;
            if (combo) SendInput(1, new[] { Key(winVk, true, true) }, Marshal.SizeOf(typeof(INPUT)));
            else Out("win");
          }
          return (IntPtr)1; // Windows bekommt die Taste nicht → kein Startmenü
        }
        if (up && winDown) { winDown = false; if (!combo) { Out("win"); CloseStartSoon(); } }
      } else if (!injected && down && winDown && !(vk >= 0xA6 && vk <= 0xBF)) {
        if (keepHidden && !combo) {
          combo = true;
          // Erst Win, dann die Taste – als ein Paket, damit die Reihenfolge stimmt.
          SendInput(2, new[] { Key(winVk, false, true), Key(vk, false, (k.flags & 1) != 0) }, Marshal.SizeOf(typeof(INPUT)));
          return (IntPtr)1;
        }
        combo = true;
      }
    }
    return CallNextHookEx(IntPtr.Zero, n, w, l);
  }

  static bool seen;
  static bool Visit(IntPtr hWnd, IntPtr extra) {
    if (!IsWindowVisible(hWnd)) return true;
    var cls = new StringBuilder(64); GetClassName(hWnd, cls, cls.Capacity);
    var title = new StringBuilder(64); GetWindowText(hWnd, title, title.Capacity);
    uint pid; GetWindowThreadProcessId(hWnd, out pid);
    string p = "";
    try { p = System.Diagnostics.Process.GetProcessById((int)pid).ProcessName; } catch { }
    string c = cls.ToString(), t = title.ToString();
    if (p == "StartMenuExperienceHost" || p == "SearchHost" || c == "XamlExplorerHostIslandWindow" || (c == "Windows.UI.Core.CoreWindow" && (t == "Start" || t == "Startmenü"))) { seen = true; ShowWindow(hWnd, 0); }
    return true;
  }
  static void CloseStartSoon() {
    if (!keepHidden) return;
    var th = new Thread(() => {
      for (int i = 0; i < 16; i++) {
        seen = false; EnumWindows(Visit, IntPtr.Zero);
        if (seen) { keybd_event(0x1B, 0, 0, UIntPtr.Zero); keybd_event(0x1B, 0, 2, UIntPtr.Zero); }
        HideTray();
        Thread.Sleep(90);
      }
    });
    th.IsBackground = true; th.Start();
  }

  static void HideTray() {
    IntPtr t = FindWindow("Shell_TrayWnd", null);
    if (t != IntPtr.Zero && IsWindowVisible(t)) ShowWindow(t, 0);
    IntPtr s = IntPtr.Zero;
    while ((s = FindWindowEx(IntPtr.Zero, s, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero) if (IsWindowVisible(s)) ShowWindow(s, 0);
  }

  static bool Fullscreen() {
    var h = GetForegroundWindow();
    if (h == IntPtr.Zero || !IsWindowVisible(h) || IsZoomed(h)) return false;
    var name = new StringBuilder(64); GetClassName(h, name, name.Capacity);
    var c = name.ToString();
    if (c == "Progman" || c == "WorkerW" || c == "Shell_TrayWnd" || c == "Shell_SecondaryTrayWnd") return false;
    RECT r; if (!GetWindowRect(h, out r)) return false;
    var info = new MONITORINFO(); info.cbSize = Marshal.SizeOf(info);
    if (!GetMonitorInfo(MonitorFromWindow(h, 2), ref info)) return false;
    return r.Left <= info.rcMonitor.Left + 2 && r.Top <= info.rcMonitor.Top + 2 && r.Right >= info.rcMonitor.Right - 2 && r.Bottom >= info.rcMonitor.Bottom - 2;
  }

  static void OnTick(object _) {
    tick++;
    if (keepHidden) HideTray();
    if (escSince >= 0 && !escFired && Environment.TickCount - escSince >= 20000) { escFired = true; Out("esc"); }
    if (tick % 3 == 0) {
      int f = Fullscreen() ? 1 : 0;
      if (f != lastFull) { lastFull = f; Out(f == 1 ? "1" : "0"); }
    }
  }

  public static void Run() {
    var reader = new Thread(() => {
      string line;
      while ((line = Console.In.ReadLine()) != null) {
        if (line == "hide") { keepHidden = true; HideTray(); }
        else if (line == "show") keepHidden = false;
      }
      Environment.Exit(0);
    });
    reader.IsBackground = true; reader.Start();
    var timer = new Timer(OnTick, null, 300, 300);
    SetWindowsHookEx(13, proc, GetModuleHandle(null), 0);
    MSG m;
    while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) { }
    GC.KeepAlive(timer);
  }
}
'@
[RevSys]::Run()
`;

const sys = { proc: null, subs: { win: new Set(), esc: new Set(), full: new Set() }, keepHidden: false };

function sysEnsure() {
  if (process.platform !== 'win32' || sys.proc) return;
  const proc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(SYS_SCRIPT, 'utf16le').toString('base64')], { windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'] });
  sys.proc = proc;
  let buffer = '';
  proc.stdout.setEncoding('utf8');
  proc.stdout.on('data', (chunk) => {
    buffer += chunk;
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() || '';
    for (const raw of lines) {
      const v = raw.trim();
      if (v === 'win' || v === 'windown') for (const cb of sys.subs.win) cb(v === 'win' ? 'up' : 'down');
      else if (v === 'esc') for (const cb of sys.subs.esc) cb();
      else if (v === '0' || v === '1') for (const cb of sys.subs.full) cb(v === '1');
    }
  });
  proc.stdin.on('error', () => {});
  proc.on('exit', () => {
    if (sys.proc !== proc) return;
    sys.proc = null;
    // Unerwartet beendet: neu starten, solange jemand ihn braucht
    if (sys.subs.win.size + sys.subs.esc.size + sys.subs.full.size > 0 || sys.keepHidden) setTimeout(sysEnsure, 2000);
  });
  if (sys.keepHidden) proc.stdin.write('hide\n');
}

function sysMaybeStop() {
  if (sys.subs.win.size + sys.subs.esc.size + sys.subs.full.size > 0 || sys.keepHidden) return;
  const p = sys.proc;
  sys.proc = null;
  try {
    p?.kill();
  } catch {
    /* schon weg */
  }
}

function subscribe(kind, cb) {
  if (process.platform !== 'win32') return () => {};
  sys.subs[kind].add(cb);
  sysEnsure();
  return () => {
    sys.subs[kind].delete(cb);
    sysMaybeStop();
  };
}

/** Windows-Leiste dauerhaft versteckt halten (true) oder freigeben (false). */
function keepTaskbarHidden(on) {
  sys.keepHidden = Boolean(on);
  if (on) sysEnsure();
  try {
    sys.proc?.stdin.write(on ? 'hide\n' : 'show\n');
  } catch {
    /* Prozess startet neu */
  }
  if (!on) sysMaybeStop();
}

/** @returns {() => void} stop function */
function watchWindowsKey(callback) {
  return subscribe('win', callback);
}

/** @returns {() => void} stop function */
function watchEscapeHold(callback) {
  return subscribe('esc', callback);
}

/** @returns {() => void} stop function */
function watchFullscreen(callback) {
  let last = null;
  return subscribe('full', (v) => {
    if (v === last) return;
    last = v;
    callback(v);
  });
}

let applied = false;
let desired = false;
let chain = Promise.resolve();

const TASKBAR_STATE_FILE = require('path').join(require('os').tmpdir(), 'revulution-taskbar-state.txt');

function psEnv(action, visible) {
  return {
    ...process.env,
    REVTASKBAR_ACTION: action,
    REVTASKBAR_VISIBLE: visible ? '1' : '0',
    REVTASKBAR_STATEFILE: TASKBAR_STATE_FILE,
  };
}

function run(action, visible) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve(false);
    execFile(
      'powershell.exe',
      PS_ARGS,
      { windowsHide: true, timeout: 15000, env: psEnv(action, visible) },
      (error, stdout) => resolve(!error && String(stdout || '').includes('ok')),
    );
  });
}

/** @returns {Promise<boolean>} */
function setHidden(value, force = false) {
  if (process.platform !== 'win32') return Promise.resolve(false);
  desired = Boolean(value);
  // Serialize visibility calls: a quick close while enabling must never race the
  // hide, otherwise the taskbar could stay hidden after the app is gone.
  chain = chain.then(async () => {
    if (!force && applied === desired) return true;
    const target = desired;
    if (!target) keepTaskbarHidden(false);
    const ok = await run('visibility', !target);
    if (ok) applied = target;
    if (ok && target) keepTaskbarHidden(true);
    return ok;
  });
  return chain;
}

/** Blocking safety net for app shutdown / crashes. */
function restoreSync() {
  if (process.platform !== 'win32') return;
  keepTaskbarHidden(false);
  if (!applied && !desired) return;
  try {
    execFileSync('powershell.exe', PS_ARGS, { windowsHide: true, timeout: 8000, env: psEnv('visibility', true) });
  } catch {
    /* Beim Beenden darf nichts mehr blockieren. */
  }
  applied = false;
  desired = false;
}

function startMenu() {
  return run('start', true);
}

module.exports = { setHidden, startMenu, restoreSync, watchFullscreen, watchWindowsKey, watchEscapeHold, keepTaskbarHidden };
