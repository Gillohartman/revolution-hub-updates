'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const call = (channel, ...args) => ipcRenderer.invoke(`hub:${channel}`, ...args);
const subscribe = (channel, callback) => {
  const listener = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
};

contextBridge.exposeInMainWorld('hub', {
  state: () => call('state'),
  open: (id) => call('open', id),
  window: (action) => call('window', action),
  setSettings: (patch) => call('settings:set', patch),
  orbit: {
    start: () => call('orbit:start'),
    stop: () => call('orbit:stop'),
    settings: () => call('orbit:settings'),
    save: (settings) => call('orbit:save', settings),
    openNative: () => call('orbit:native'),
    command: (name) => call('orbit:command', name),
  },
  music: {
    get: () => call('music:get'),
    set: (patch) => call('music:set', patch),
    demo: () => call('music:demo'),
  },
  pcInfo: (force) => call('pc:info', force),
  pcLive: () => call('pc:live'),
  overlay: (on) => call('overlay', on),
  gameMode: (on) => call('gamemode', on),
  awake: (on, minutes) => call('awake', on, minutes),
  account: { state: () => call('acct:state'), login: (email, password, create) => call('acct:login', email, password, create), logout: () => call('acct:logout'), sync: (mode) => call('acct:sync', mode), reset: (email) => call('acct:reset', email), code: (c) => call('acct:code', c), cancel: () => call('acct:cancel'), mfaStart: () => call('acct:mfaStart'), mfaFinish: (c) => call('acct:mfaFinish', c), mfaRemove: () => call('acct:mfaRemove'), verify: () => call('acct:verify') },
  onAccount: (callback) => subscribe('hub:account', callback),
  schem: { list: (force) => call('schem:list', force), detail: (id) => call('schem:detail', id), icons: (ids) => call('schem:icons', ids), install: (id, version) => call('schem:install', id, version), targets: () => call('schem:targets') },
  mix: { list: () => call('mix:list'), app: (pid, volume, mute) => call('mix:app', pid, volume, mute), master: (volume, mute) => call('mix:master', volume, mute) },
  onOpenControl: (callback) => subscribe('hub:open-control', callback),
  closeModule: (id) => call('module:close', id),
  clickClip: () => call('clickClip'),
  update: { check: () => call('update:check'), install: () => call('update:install'), pending: () => call('update:pending'), dismiss: (v) => call('update:dismiss', v) },
  onUpdateAvailable: (callback) => subscribe('hub:update-available', callback),
  onUpdate: (callback) => subscribe('hub:update', callback),
  autoclick: { status: () => call('ac:status'), start: () => call('ac:start'), stop: () => call('ac:stop'), pick: (ms) => call('ac:pick', ms) },
  onAutoclick: (callback) => subscribe('hub:autoclick', callback),
  shield: { trackers: () => call('shield:trackers'), last: () => call('shield:last'), defender: () => call('shield:defender'), scan: (kind) => call('shield:scan', kind), update: () => call('shield:update') },
  cc: {
    volume: (level) => call('cc:volume', level),
    media: (key) => call('cc:media', key),
    brightness: (level) => call('cc:brightness', level),
    power: (mode) => call('cc:power', mode),
    lock: () => call('cc:lock'),
    timer: (seconds, name) => call('cc:timer', seconds, name),
    alarm: (hhmm) => call('cc:alarm', hhmm),
    timers: () => call('cc:timers'),
    screenshot: () => call('cc:screenshot'),
  },
  tool: {
    fetch: (url) => call('tool:fetch', url),
    clipboard: (action, value) => call('tool:clipboard', action, value),
    notify: (title, body) => call('tool:notify', title, body),
  },
  speed: { run: () => call('speed:run'), wlan: () => call('speed:wlan'), history: () => call('speed:history') },
  onSpeed: (callback) => subscribe('hub:speed', callback),
  profile: {
    get: () => call('profile:get'),
    buy: (slot, id) => call('profile:buy', { slot, id }),
    equip: (slot, id) => call('profile:equip', { slot, id }),
    name: (name) => call('profile:name', name),
    image: (data) => call('profile:image', data),
  },
  openData: (id) => call('openData', id),
  external: (url) => call('external', url),
  onState: (callback) => subscribe('hub:state', callback),
  onProfile: (callback) => subscribe('hub:profile', callback),
});
