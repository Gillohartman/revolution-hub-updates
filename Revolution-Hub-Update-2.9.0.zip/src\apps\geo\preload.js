'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('geoApp', {
  load: () => ipcRenderer.invoke('load'),
  save: (profile) => ipcRenderer.invoke('save', profile),
  findPano: (q) => ipcRenderer.invoke('pano:find', q),
});
contextBridge.exposeInMainWorld('hubProfile', {
  get: () => ipcRenderer.invoke('hp:get'),
  name: (v) => ipcRenderer.invoke('hp:name', v),
  earn: (n) => ipcRenderer.invoke('hp:earn', n),
  shop: () => ipcRenderer.invoke('hp:shop'),
});
