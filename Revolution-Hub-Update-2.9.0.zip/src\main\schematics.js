'use strict';

/*
 * Schematics-Cloud (KELPI): liest die Schematics der Website und legt eine Datei auf Wunsch
 * automatisch in alle Schematics-Ordner (Litematica, WorldEdit, Revolution-Launcher,
 * Prism/MultiMC, CurseForge, Modrinth).
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const fb = require('./firebase');

let index = null;
let indexAt = 0;

async function list(force = false) {
  if (index && !force && Date.now() - indexAt < 5 * 60 * 1000) return index;
  const doc = await fb.getDoc('settings/sch_index');
  const items = Array.isArray(doc?.items) ? doc.items : [];
  index = items
    .filter((x) => x && x.id && x.name)
    .map((x) => ({
      id: String(x.id),
      name: String(x.name).slice(0, 120),
      desc: String(x.desc || '').slice(0, 600),
      tags: Array.isArray(x.tags) ? x.tags.slice(0, 12).map(String) : [],
      cat: String(x.cat || ''),
      downloads: Number(x.downloads) || 0,
      likes: Number(x.likes) || 0,
      rating: x.ratingCount ? Math.round((x.ratingSum / x.ratingCount) * 10) / 10 : 0,
      fileName: String(x.fileName || ''),
      icon: /^https:\/\//.test(String(x.icon || '')) ? String(x.icon) : '',
      hasImg: Boolean(x.hasImg),
      by: String(x.byName || ''),
      ts: Number(x.ts) || 0,
    }));
  indexAt = Date.now();
  return index;
}

/** Details mit Vorschaubild(ern). Bilder können Daten-URLs oder https-Adressen sein. */
/** Vorschaubilder für die Kacheln (nur das Feld „icon“ – nicht die ganze Datei). */
const iconCache = new Map();
async function icons(ids) {
  const out = {};
  await Promise.all(
    (Array.isArray(ids) ? ids : []).slice(0, 30).map(async (id) => {
      id = String(id);
      if (!iconCache.has(id)) {
        try {
          const d = await fb.getDoc(`schematics/${encodeURIComponent(id)}`, null, ['icon', 'images']);
          const pic = [d?.icon, ...(Array.isArray(d?.images) ? d.images : [])].find((v) => typeof v === 'string' && (v.startsWith('https://') || (v.startsWith('data:image/') && v.length < 1_500_000)));
          iconCache.set(id, pic || '');
        } catch {
          iconCache.set(id, '');
        }
      }
      out[id] = iconCache.get(id);
    }),
  );
  return out;
}

async function detail(id) {
  const d = await fb.getDoc(`schematics/${encodeURIComponent(id)}`, null, ['icon', 'images', 'fileName']);
  if (!d) throw new Error('Schematic nicht gefunden');
  const pic = (v) => (typeof v === 'string' && (v.startsWith('https://') || (v.startsWith('data:image/') && v.length < 3_000_000)) ? v : '');
  return {
    id,
    images: (Array.isArray(d.images) ? d.images : []).map(pic).filter(Boolean).slice(0, 6),
    icon: pic(d.icon),
    versions: [],
    fileName: String(d.fileName || ''),
  };
}

/** Datei holen: direkt im Dokument, in Teilen (lit_files) oder über eine Adresse. */
async function fileBytes(id, version = -1) {
  const d = await fb.getDoc(`schematics/${encodeURIComponent(id)}`);
  if (!d) throw new Error('Schematic nicht gefunden');
  const src = version >= 0 && Array.isArray(d.versions) && d.versions[version] ? d.versions[version] : d;
  const fromData = (s) => Buffer.from(String(s).replace(/^data:[^,]*,/, ''), 'base64');
  if (typeof src.fileData === 'string' && src.fileData.length > 30) return { bytes: fromData(src.fileData), name: src.fileName || d.fileName };
  if (src.litFileId) {
    const head = await fb.getDoc(`lit_files/${encodeURIComponent(src.litFileId)}`);
    if (!head) throw new Error('Datei fehlt in der Cloud');
    let b64 = '';
    for (let i = 0; i < (Number(head.n) || 0); i += 1) {
      const part = await fb.getDoc(`lit_files/${encodeURIComponent(src.litFileId)}/parts/${i}`);
      b64 += part?.d || '';
    }
    return { bytes: Buffer.from(b64, 'base64'), name: src.fileName || head.name || d.fileName };
  }
  if (typeof src.fileUrl === 'string' && src.fileUrl.startsWith('https://')) {
    const { net } = require('electron');
    const res = await net.fetch(src.fileUrl);
    if (!res.ok) throw new Error('Download fehlgeschlagen');
    return { bytes: Buffer.from(await res.arrayBuffer()), name: src.fileName || d.fileName };
  }
  throw new Error('Für dieses Schematic gibt es keine Datei');
}

const safeName = (n, id) => {
  let name = String(n || `${id}.litematic`).replace(/[\\/:*?"<>|]+/g, '_').replace(/^\.+/, '').slice(0, 120);
  if (!/\.(litematic|schem|schematic|nbt|mcstructure)$/i.test(name)) name += '.litematic';
  return name;
};
const isDir = (p) => {
  try {
    return fs.statSync(p).isDirectory();
  } catch {
    return false;
  }
};
const subdirs = (p) => {
  try {
    return fs.readdirSync(p, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => path.join(p, d.name));
  } catch {
    return [];
  }
};

/** Alle Minecraft-Installationen finden, die einen Schematics-Ordner haben (oder brauchen). */
function gameDirs() {
  const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const home = os.homedir();
  const out = [];
  const add = (dir, label) => {
    if (isDir(dir) && !out.some((x) => x.dir.toLowerCase() === dir.toLowerCase())) out.push({ dir, label });
  };
  add(path.join(appData, '.minecraft'), 'Minecraft');
  for (const inst of subdirs(path.join(appData, 'Revolution', 'instances'))) add(inst, `Revolution · ${path.basename(inst)}`);
  for (const root of [path.join(appData, 'PrismLauncher', 'instances'), path.join(appData, 'MultiMC', 'instances'), path.join(home, 'MultiMC', 'instances')])
    for (const inst of subdirs(root)) add(isDir(path.join(inst, '.minecraft')) ? path.join(inst, '.minecraft') : path.join(inst, 'minecraft'), `Prism/MultiMC · ${path.basename(inst)}`);
  for (const inst of subdirs(path.join(home, 'curseforge', 'minecraft', 'Instances'))) add(inst, `CurseForge · ${path.basename(inst)}`);
  for (const inst of subdirs(path.join(appData, 'ModrinthApp', 'profiles'))) add(inst, `Modrinth · ${path.basename(inst)}`);
  for (const inst of subdirs(path.join(appData, '.feather', 'user-mods'))) add(inst, `Feather · ${path.basename(inst)}`);
  return out;
}
/** Zielordner für eine Datei: Litematica-„schematics“ und bei .schem auch WorldEdit. */
function targets(fileName) {
  const schem = /\.(schem|schematic)$/i.test(fileName);
  const out = [];
  for (const g of gameDirs()) {
    out.push({ dir: path.join(g.dir, 'schematics'), label: `${g.label} · schematics` });
    const we = path.join(g.dir, 'config', 'worldedit', 'schematics');
    if (schem || isDir(we)) out.push({ dir: we, label: `${g.label} · WorldEdit` });
  }
  return out;
}

async function install(id, version = -1) {
  const { bytes, name } = await fileBytes(id, version);
  if (!bytes.length) throw new Error('Die Datei ist leer');
  const file = safeName(name, id);
  const done = [];
  for (const t of targets(file)) {
    try {
      fs.mkdirSync(t.dir, { recursive: true });
      fs.writeFileSync(path.join(t.dir, file), bytes);
      done.push(t.label);
    } catch {
      /* Ordner gesperrt – nächster */
    }
  }
  return { file, count: done.length, places: done, size: bytes.length };
}

module.exports = { list, detail, icons, install, gameDirs, targets };
