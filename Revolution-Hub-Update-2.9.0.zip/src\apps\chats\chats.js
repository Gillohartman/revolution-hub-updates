'use strict';

/*
 * Chats über öffentliche MQTT-Server (dieselben wie die Online-Spiele).
 * WICHTIG: nicht verschlüsselt – jeder, der den Raum-Namen/Code kennt, kann mitlesen.
 */
(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const api = window.chatApp;
  const COLORS = ['#34d399', '#38bdf8', '#a78bfa', '#f472b6', '#fbbf24', '#fb7185', '#4ade80', '#60a5fa'];
  const newCode = () => Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 32]).join('');
  const roomCode = (s) => String(s).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 24);
  const hm = (t) => new Date(t).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });

  let data = { me: null, chats: [], active: 'lobby' };
  const rooms = new Map(); // chatId → { room, peers }
  const seen = new Set();

  const save = () => api.save(data);
  const put = (id, html) => (window.RevMorph ? window.RevMorph.morph($(id), html) : ($(id).innerHTML = html));
  const chatById = (id) => data.chats.find((c) => c.id === id);
  const avatar = (name, color, size = 38) => `<span class="av" style="width:${size}px;height:${size}px;background:${esc(color)}">${esc((name || '?').slice(0, 1).toUpperCase())}</span>`;
  /* Hub-Cosmetics (aus dem Shop) – dieselben wie im Schach. Das eigene Bild wird nicht verschickt. */
  const C = window.RevCos;
  const HP = window.hubProfile;
  let myCos = {};
  const COS_KEYS = ['avatar', 'color', 'frame', 'name', 'title'];
  const cleanCos = (c) => {
    if (!c || typeof c !== 'object') return null;
    const out = {};
    for (const k of COS_KEYS) if (typeof c[k] === 'string' && c[k].length < 24) out[k] = c[k];
    return out;
  };
  const sendCos = () => cleanCos(myCos) || {};
  const cosAvatar = (cos, name, color, size = 38) => (cos && C ? C.avatarHtml(cos, size) : avatar(name, color, size));
  const nameAttr = (cos, color) => (cos && C ? C.nameStyle(cos) : `style="color:${esc(color)}"`);
  function applyHub(hp) {
    if (!hp || !data.me) return;
    myCos = hp.cos?.eq || {};
    if (hp.name && hp.name !== data.me.name) {
      data.me.name = hp.name;
      save();
    }
    renderMe();
    renderMsgs(false);
  }
  window.addEventListener('hub-profile', (e) => applyHub(e.detail));

  $('warn').innerHTML = `⚠ <span><b>Chats sind nicht verschlüsselt.</b> Teile hier keine Passwörter, Adressen, Telefonnummern oder andere sensiblen Daten.</span>`;

  /* ------------------------------------------------------------ Verbindung */
  async function connect(chat) {
    if (rooms.has(chat.id)) return;
    const entry = { room: null, peers: 0, failed: false };
    rooms.set(chat.id, entry);
    const code = chat.kind === 'public' ? 'LOBBY' : chat.kind === 'dm' ? `DM-${[data.me.code, chat.peer].sort().join('-')}` : `R-${chat.key}`;
    const room = new window.RevNet.Room({ app: 'chat', code, name: data.me.name });
    room.on('peer', () => {
      entry.peers = room.peers.size;
      if (chat.id === data.active) renderHead();
    });
    room.on('left', () => {
      entry.peers = room.peers.size;
      if (chat.id === data.active) renderHead();
    });
    room.on('msg', (m) => onMsg(chat, m));
    try {
      await room.join();
      entry.room = room;
    } catch {
      entry.failed = true;
    }
    if (chat.id === data.active) renderHead();
  }

  /** Persönlicher Posteingang: hier melden sich neue Direktnachrichten an. */
  async function connectInbox() {
    const room = new window.RevNet.Room({ app: 'chat', code: `IN-${data.me.code}`, name: data.me.name });
    room.on('msg', (m) => {
      if (m.t !== 'dm-hello' || !/^[A-Z0-9]{8}$/.test(m.code || '')) return;
      if (data.chats.some((c) => c.kind === 'dm' && c.peer === m.code)) return;
      const chat = { id: `dm-${m.code}`, kind: 'dm', name: String(m.name || 'Freund').slice(0, 24), peer: m.code, color: m.color || COLORS[0], cos: cleanCos(m.cos), msgs: [], unread: 0 };
      data.chats.push(chat);
      save();
      connect(chat);
      renderList();
      api.notify({ title: 'Neuer Chat', body: `${chat.name} möchte mit dir schreiben.` });
    });
    try {
      await room.join();
    } catch {
      /* offline */
    }
  }

  function onMsg(chat, m) {
    if (m.t !== 'msg' || typeof m.text !== 'string' || !m.id || seen.has(m.id)) return;
    seen.add(m.id);
    const msg = { id: m.id, text: m.text.slice(0, 800), from: String(m.nm || m.name || '?').slice(0, 24), code: m.code, color: m.color || COLORS[1], cos: cleanCos(m.cos), at: Date.now() };
    chat.msgs.push(msg);
    chat.msgs = chat.msgs.slice(-300);
    if (chat.kind === 'dm' && msg.cos) chat.cos = msg.cos;
    if (chat.id !== data.active || document.hidden) chat.unread = (chat.unread || 0) + 1;
    // Immer melden – der Hub entscheidet: Chats offen → nichts, sonst Dynamic Island (bzw. Windows)
    api.notify({ title: chat.kind === 'dm' ? msg.from : `${msg.from} · ${chat.name}`, body: msg.text });
    save();
    renderList();
    if (chat.id === data.active) renderMsgs(true);
  }

  function send(text) {
    const chat = chatById(data.active);
    const entry = rooms.get(data.active);
    if (!chat || !text.trim()) return;
    if (!entry?.room) {
      sys('Keine Verbindung zum Chat-Server – Nachricht nicht gesendet.');
      return;
    }
    const msg = { id: newCode() + Date.now().toString(36), text: text.trim().slice(0, 800), code: data.me.code, color: data.me.color, nm: data.me.name, cos: sendCos() };
    seen.add(msg.id);
    entry.room.send('msg', msg);
    chat.msgs.push({ ...msg, from: data.me.name, me: true, at: Date.now() });
    chat.msgs = chat.msgs.slice(-300);
    save();
    renderList();
    renderMsgs(true);
  }

  function sys(text) {
    const el = document.createElement('div');
    el.className = 'sys';
    el.textContent = text;
    $('msgs').appendChild(el);
    $('msgs').scrollTop = $('msgs').scrollHeight;
  }

  /* ---------------------------------------------------------------- Anzeige */
  function renderMe() {
    put('me', `${C ? C.avatarHtml(myCos, 38) : avatar(data.me.name, data.me.color)}<div><b ${C ? C.nameStyle(myCos) : ''}>${esc(data.me.name)}</b><small>Dein Code: <span class="code">${data.me.code}</span>${HP ? ' · <a href="#" id="to-shop">Shop</a>' : ''}</small></div>`);
  }

  function renderList() {
    put('list', data.chats
      .map((c) => {
        const last = c.msgs[c.msgs.length - 1];
        const icon = c.kind === 'public' ? '🌍' : c.kind === 'room' ? '#' : '';
        return `<button class="item ${c.id === data.active ? 'on' : ''}" data-chat="${esc(c.id)}">${c.kind === 'dm' ? cosAvatar(c.cos, c.name, c.color, 34) : `<span class="av" style="width:34px;height:34px;background:#2a2838">${icon}</span>`}<div class="grow"><b>${esc(c.name)}</b><small>${last ? esc(`${last.me ? 'Du' : last.from}: ${last.text}`) : 'Noch keine Nachrichten'}</small></div>${c.unread ? `<span class="badge">${c.unread}</span>` : ''}</button>`;
      })
      .join(''));
  }

  function renderHead() {
    const c = chatById(data.active);
    if (!c) return;
    const e = rooms.get(c.id);
    const sub = c.kind === 'public' ? 'Öffentlicher Raum für alle Hub-Nutzer' : c.kind === 'room' ? `Raum „${c.key}“ – jeder mit diesem Namen kann beitreten` : `Direktnachricht · Code ${c.peer}`;
    const status = e?.failed ? '<span class="online">offline</span>' : `<span class="online ${e?.peers ? 'on' : ''}"><i></i>${e?.peers ? `${e.peers} online` : 'niemand sonst online'}</span>`;
    put('head', `<div class="grow"><b>${esc(c.name)}</b><br><small>${esc(sub)}</small></div>${status}${c.kind !== 'public' ? '<button class="btn small ghost" id="leave">Entfernen</button>' : ''}`);
  }

  function renderMsgs(scroll) {
    const c = chatById(data.active);
    if (!c) return;
    c.unread = 0;
    put('msgs', c.msgs.length
      ? c.msgs
          .map((m) => {
            const cos = m.me ? myCos : m.cos;
            const who = !m.me && c.kind !== 'dm' ? `<span class="who" ${nameAttr(m.cos, m.color)}>${esc(m.from)}${m.cos && C ? C.titleHtml(m.cos) : ''}</span>` : '';
            return `<div class="msg-row ${m.me ? 'mine' : ''}">${!m.me ? cosAvatar(cos, m.from, m.color, 30) : ''}<div class="msg ${m.me ? 'me' : ''}">${who}${esc(m.text)}<time>${hm(m.at)}</time></div></div>`;
          })
          .join('')
      : `<div class="empty">${c.kind === 'public' ? 'Sag Hallo! Alle, die gerade im Hub-Chat sind, sehen das.' : 'Noch keine Nachrichten.'}<br><br><small>Nachrichten werden nur auf den Geräten gespeichert, die gerade verbunden sind.</small></div>`);
    if (scroll) $('msgs').scrollTop = $('msgs').scrollHeight;
  }

  function open(id) {
    data.active = id;
    save();
    renderList();
    renderHead();
    renderMsgs(true);
    $('text').focus();
  }

  /* ---------------------------------------------------------------- Dialoge */
  function modal(html, onClick) {
    $('modal').innerHTML = html;
    $('modal-back').hidden = false;
    $('modal').onclick = onClick;
  }
  const close = () => ($('modal-back').hidden = true);

  function nameModal(first) {
    modal(
      `<h2>${first ? 'Willkommen bei den Chats' : 'Dein Name'}</h2>
       <div class="field"><label>Anzeigename</label><input class="input" id="nm" maxlength="20" value="${esc(data.me?.name || '')}" /></div>
       <div class="field"><label>Farbe</label><div style="display:flex;gap:8px">${COLORS.map((c) => `<button class="btn icon" data-col="${c}" style="background:${c};width:28px;height:28px;border-radius:50%;${data.me?.color === c ? 'outline:2px solid #fff' : ''}"></button>`).join('')}</div></div>
       <p class="hint">⚠ Chats sind nicht verschlüsselt. Nutze keinen echten vollen Namen, wenn du das nicht möchtest.</p>
       <div class="err" id="nm-err"></div><div class="btns"><button class="btn primary" data-ok="1">Speichern</button></div>`,
      (e) => {
        const col = e.target.closest('[data-col]');
        if (col) {
          data.me.color = col.dataset.col;
          $('modal').querySelectorAll('[data-col]').forEach((b) => (b.style.outline = b === col ? '2px solid #fff' : ''));
          return;
        }
        if (!e.target.closest('[data-ok]')) return;
        const v = $('nm').value.trim();
        if (v.length < 2) return ($('nm-err').textContent = 'Mindestens 2 Zeichen.');
        data.me.name = v;
        HP?.name(v).catch(() => {});
        save();
        close();
        renderMe();
        if (first) start();
      },
    );
  }

  function addModal() {
    modal(
      `<h2>Neuer Chat</h2>
       <div class="field"><label>Freund per Code</label><div style="display:flex;gap:8px"><input class="input" id="dm" maxlength="8" placeholder="8-stelliger Code" style="text-transform:uppercase" /><button class="btn primary" data-add="dm">Hinzufügen</button></div><span class="hint">Dein Code: <span class="code">${data.me.code}</span> – gib ihn deinem Freund.</span></div>
       <div class="field"><label>Raum beitreten oder erstellen</label><div style="display:flex;gap:8px"><input class="input" id="rm" maxlength="24" placeholder="z. B. FortniteSquad" /><button class="btn" data-add="room">Beitreten</button></div><span class="hint">Jeder, der denselben Raumnamen eingibt, ist im selben Raum. Wähle einen ungewöhnlichen Namen.</span></div>
       <div class="err" id="add-err"></div><div class="btns"><button class="btn ghost" data-add="close">Schließen</button></div>`,
      (e) => {
        const a = e.target.closest('[data-add]')?.dataset.add;
        if (!a) return;
        if (a === 'close') return close();
        if (a === 'dm') {
          const code = $('dm').value.trim().toUpperCase();
          if (!/^[A-Z0-9]{8}$/.test(code)) return ($('add-err').textContent = 'Der Code hat 8 Zeichen.');
          if (code === data.me.code) return ($('add-err').textContent = 'Das ist dein eigener Code.');
          let chat = data.chats.find((c) => c.kind === 'dm' && c.peer === code);
          if (!chat) {
            chat = { id: `dm-${code}`, kind: 'dm', name: `Freund ${code.slice(0, 4)}`, peer: code, color: COLORS[2], msgs: [], unread: 0 };
            data.chats.push(chat);
            // dem Freund Bescheid geben (sein Posteingang)
            const hello = new window.RevNet.Room({ app: 'chat', code: `IN-${code}`, name: data.me.name });
            hello.join().then(() => {
              hello.send('dm-hello', { code: data.me.code, color: data.me.color, cos: sendCos() });
              setTimeout(() => hello.leave(), 3000);
            }).catch(() => {});
            connect(chat);
          }
          close();
          open(chat.id);
        }
        if (a === 'room') {
          const key = roomCode($('rm').value);
          if (key.length < 3) return ($('add-err').textContent = 'Mindestens 3 Buchstaben oder Zahlen.');
          let chat = data.chats.find((c) => c.kind === 'room' && c.key === key);
          if (!chat) {
            chat = { id: `room-${key}`, kind: 'room', name: $('rm').value.trim().slice(0, 24), key, msgs: [], unread: 0 };
            data.chats.push(chat);
            connect(chat);
          }
          close();
          open(chat.id);
        }
        save();
        renderList();
      },
    );
    setTimeout(() => $('dm')?.focus(), 40);
  }

  /* ----------------------------------------------------------------- Events */
  $('list').addEventListener('click', (e) => {
    const b = e.target.closest('[data-chat]');
    if (b) open(b.dataset.chat);
  });
  $('add').onclick = addModal;
  $('me').onclick = () => nameModal(false);
  $('head').addEventListener('click', (e) => {
    if (e.target.id !== 'leave') return;
    const id = data.active;
    rooms.get(id)?.room?.leave();
    rooms.delete(id);
    data.chats = data.chats.filter((c) => c.id !== id);
    open('lobby');
  });
  $('compose').addEventListener('submit', (e) => {
    e.preventDefault();
    const now = Date.now();
    // kleiner Spam-Schutz
    if (now - (send.last || 0) < 600) return;
    send.last = now;
    send($('text').value);
    $('text').value = '';
  });
  $('modal-back').addEventListener('mousedown', (e) => {
    if (e.target === $('modal-back') && data.me?.name) close();
  });

  function start() {
    if (!data.chats.some((c) => c.id === 'lobby')) data.chats.unshift({ id: 'lobby', kind: 'public', name: 'Hub-Lobby', msgs: [], unread: 0 });
    for (const c of data.chats) for (const m of c.msgs) seen.add(m.id);
    renderMe();
    renderList();
    if (!chatById(data.active)) data.active = 'lobby';
    open(data.active);
    for (const c of data.chats) connect(c);
    connectInbox();
  }

  (async () => {
    const saved = await api.load().catch(() => null);
    if (saved?.me) data = { ...data, ...saved };
    if (!data.me) data.me = { name: '', code: newCode(), color: COLORS[Math.floor(Math.random() * COLORS.length)] };
    // Ein Name für den ganzen Hub
    const hp = await HP?.get().catch(() => null);
    if (hp) {
      myCos = hp.cos?.eq || {};
      if (hp.name) data.me.name = hp.name;
      else if (data.me.name) HP.name(data.me.name).catch(() => {});
    }
    document.addEventListener('click', (e) => {
      if (e.target.id === 'to-shop') {
        e.preventDefault();
        HP?.shop();
      }
    });
    if (!data.me.name) nameModal(true);
    else start();
  })();

  window.ChatUI = { state: () => data, rooms, send, open };
})();
