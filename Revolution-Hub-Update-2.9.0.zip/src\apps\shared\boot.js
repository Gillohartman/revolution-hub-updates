'use strict';

const path = require('path');

/**
 * Boilerplate for the hub's own apps: an electron shim (prefixed IPC, own session and data
 * folder) and the app's main view inside the hub window.
 */
function boot(id, dir, { onView } = {}) {
  const electron = global.__revolutionHub.shim(id);
  const state = { view: null };
  electron.app.whenReady().then(() => {
    state.view = global.__revolutionHub.view(id, {
      backgroundColor: '#00000000',
      webPreferences: {
        preload: path.join(dir, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
        spellcheck: id === 'docs',
      },
    });
    state.view.loadFile(path.join(dir, 'index.html'));
    if (onView) onView(state.view);
  });
  return {
    electron,
    hub: global.__revolutionHub.hub,
    send(channel, payload) {
      const view = state.view;
      if (view && !view.isDestroyed()) view.webContents.send(channel, payload);
    },
    get view() {
      return state.view;
    },
  };
}

/** Runs a PowerShell snippet (UTF-16 encoded, so quoting never breaks) and returns stdout. */
function powershell(script, { timeout = 20000 } = {}) {
  const { execFile } = require('child_process');
  const encoded = Buffer.from(`$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.Encoding]::UTF8;${script}`, 'utf16le').toString('base64');
  return new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, timeout, maxBuffer: 32 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) return reject(new Error((stderr || error.message).trim().split('\n')[0]));
      resolve(stdout);
    });
  });
}

/** Single-quoted PowerShell string literal. */
const psQuote = (value) => `'${String(value).replace(/'/g, "''")}'`;

/** Hub-Profil (Name, Punkte, Cosmetics) für eine App bereitstellen: hp:get/name/earn/migrate/shop. */
function bindHubProfile(ipcMain) {
  const api = () => global.__revolutionHub.profile;
  ipcMain.handle('hp:get', () => api().get());
  ipcMain.handle('hp:name', (_e, name) => api().setName(name));
  ipcMain.handle('hp:earn', (_e, amount) => api().earn(amount));
  ipcMain.handle('hp:migrate', (_e, old) => api().migrate(old));
  ipcMain.handle('hp:shop', () => {
    global.__revolutionHub.hub.open('shop');
    return true;
  });
}

module.exports = { boot, powershell, psQuote, bindHubProfile };
