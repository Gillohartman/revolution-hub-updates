'use strict';

const fs = require('fs');
const path = require('path');
const { boot, bindHubProfile } = require('../shared/boot');

const ctx = boot('chats', __dirname);
const { app, ipcMain } = ctx.electron;
const hub = ctx.hub;
bindHubProfile(ipcMain);
const file = () => path.join(app.getPath('userData'), 'chats.json');

ipcMain.handle('load', () => {
  try {
    return JSON.parse(fs.readFileSync(file(), 'utf8'));
  } catch {
    return null;
  }
});
let timer = null;
let pending = null;
ipcMain.handle('save', (_e, data) => {
  pending = data;
  clearTimeout(timer);
  timer = setTimeout(() => {
    fs.mkdirSync(path.dirname(file()), { recursive: true });
    fs.writeFileSync(`${file()}.tmp`, JSON.stringify(pending));
    fs.renameSync(`${file()}.tmp`, file());
  }, 400);
  return true;
});
// Benachrichtigung, wenn eine Nachricht kommt und die Chats nicht offen sind
ipcMain.handle('notify', (_e, { title, body }) => {
  if (hub.active === 'chats' && hub.window?.isFocused()) return false;
  // Läuft die Dynamic Island, landet die Nachricht dort – sonst Windows-Hinweis
  hub.notify(String(title).slice(0, 60), String(body).slice(0, 140), { app: 'Chats', accent: '#38bdf8', glyph: '💬' });
  return true;
});
