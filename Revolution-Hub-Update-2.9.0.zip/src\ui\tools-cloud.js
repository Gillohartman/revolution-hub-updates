'use strict';

/*
 * Cloud-Mini-Apps: Schematics (KELPI-Cloud → alle Minecraft-Schematics-Ordner) und
 * Revolution-Konto (Anmelden, Profil auf mehreren PCs).
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

  /* ================================================================ Schematics */
  const sc = { list: null, busy: false, err: '', q: '', cat: '', sort: 'new', open: null, detail: null, installing: '', targets: null, shown: 60 };
  async function scLoad(force = false) {
    if (sc.busy) return;
    sc.busy = true;
    sc.err = '';
    ctx().render();
    try {
      sc.list = await window.hub.schem.list(force);
    } catch (error) {
      sc.err = errText(error);
    }
    sc.busy = false;
    ctx().render();
    if (!sc.targets) window.hub.schem.targets().then((t) => ((sc.targets = t), ctx().render())).catch(() => {});
  }
  function scFiltered() {
    const q = sc.q.trim().toLowerCase();
    let l = (sc.list || []).filter((s) => (!sc.cat || s.cat === sc.cat) && (!q || `${s.name} ${s.desc} ${s.tags.join(' ')} ${s.by}`.toLowerCase().includes(q)));
    if (sc.sort === 'popular') l = l.slice().sort((a, b) => b.downloads - a.downloads);
    else if (sc.sort === 'top') l = l.slice().sort((a, b) => b.rating - a.rating || b.likes - a.likes);
    else l = l.slice().sort((a, b) => b.ts - a.ts);
    return l;
  }
  const kind = (f) => (/\.schem(atic)?$/i.test(f) ? 'WorldEdit' : /\.mcstructure$/i.test(f) ? 'Bedrock' : 'Litematica');

  /** Fehlende Vorschaubilder der sichtbaren Kacheln nachladen. */
  let iconBusy = false;
  async function scIcons(list) {
    if (iconBusy || !window.hub.schem.icons) return;
    const missing = list.filter((s) => !s.icon && !s.iconTried).slice(0, 24);
    if (!missing.length) return;
    iconBusy = true;
    missing.forEach((s) => (s.iconTried = true));
    try {
      const got = await window.hub.schem.icons(missing.map((s) => s.id));
      for (const s of missing) if (got[s.id]) s.icon = got[s.id];
    } catch {
      /* ohne Bild */
    }
    iconBusy = false;
    if (ctx().state()?.active === 'tool-schematics' && !sc.open) ctx().render();
  }
  function schematicsHtml() {
    if (!sc.list && !sc.busy && !sc.err) scLoad();
    if (sc.open) return scDetailHtml();
    const cats = [...new Set((sc.list || []).map((s) => s.cat).filter(Boolean))].sort();
    const list = scFiltered();
    if (sc.list) setTimeout(() => scIcons(list.slice(0, sc.shown)), 0);
    return `<div class="tool-card sc-bar">
        <input class="input" data-sc="q" value="${esc(sc.q)}" placeholder="Schematics durchsuchen … (Name, Tag, Ersteller)" />
        <div class="seg">${[['new', 'Neu'], ['popular', 'Beliebt'], ['top', 'Top bewertet']].map(([v, n]) => `<button class="${sc.sort === v ? 'on' : ''}" data-sc-sort="${v}">${n}</button>`).join('')}</div>
        <button class="btn small ghost" data-sc-act="reload" title="Neu laden">${icon('refresh', 15)}</button>
      </div>
      ${cats.length ? `<div class="chip-row"><button class="chip ${!sc.cat ? 'on' : ''}" data-sc-cat="">Alle</button>${cats.map((c) => `<button class="chip ${sc.cat === c ? 'on' : ''}" data-sc-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div>` : ''}
      ${sc.err ? `<p class="err">${esc(sc.err)}</p>` : ''}
      ${!sc.list ? `<p class="muted tool-note">${sc.busy ? 'Schematics werden geladen …' : ''}</p>` : `<p class="muted tool-note">${list.length} von ${sc.list.length} Schematics · Klick öffnet Bilder und Installation</p>
      <div class="sc-grid">${list.slice(0, sc.shown).map((s) => `<button class="sc-card" data-sc-open="${esc(s.id)}">
          <div class="sc-img">${s.icon ? `<img src="${esc(s.icon)}" alt="" loading="lazy" draggable="false" />` : `<span class="sc-ph">${icon('cube', 34)}</span>`}<em>${kind(s.fileName)}</em></div>
          <b>${esc(s.name)}</b><small>${s.by ? `von ${esc(s.by)} · ` : ''}⬇ ${s.downloads.toLocaleString('de-DE')}${s.rating ? ` · ★ ${String(s.rating).replace('.', ',')}` : ''}</small></button>`).join('')}</div>
      ${list.length > sc.shown ? `<div class="tool-row center"><button class="btn" data-sc-act="more">Mehr anzeigen (${list.length - sc.shown})</button></div>` : ''}`}`;
  }
  function scDetailHtml() {
    const s = (sc.list || []).find((x) => x.id === sc.open);
    const d = sc.detail;
    if (!s) return '';
    const imgs = d ? (d.images.length ? d.images : d.icon ? [d.icon] : s.icon ? [s.icon] : []) : s.icon ? [s.icon] : [];
    return `<div class="tool-row"><button class="btn small ghost" data-sc-act="back">← Alle Schematics</button></div>
      <div class="tool-grid two sc-detail">
        <div class="tool-card"><div class="sc-gallery">${imgs.length ? imgs.map((u, i) => `<img src="${esc(u)}" alt="" class="${i ? '' : 'main'}" draggable="false" />`).join('') : `<div class="sc-noimg">${d ? 'Kein Vorschaubild' : 'Bilder werden geladen …'}</div>`}</div></div>
        <div class="tool-card"><h3 style="margin:0">${esc(s.name)}</h3>
          <small class="muted">${s.by ? `von ${esc(s.by)} · ` : ''}${esc(s.cat || '')}${s.ts ? ` · ${new Date(s.ts).toLocaleDateString('de-DE')}` : ''}</small>
          ${s.desc ? `<p class="sc-desc">${esc(s.desc)}</p>` : ''}
          ${s.tags.length ? `<div class="chip-row">${s.tags.map((t) => `<span class="chip">${esc(t)}</span>`).join('')}</div>` : ''}
          <div class="kv sc-kv"><span>Datei</span><b>${esc(s.fileName || '–')}</b><span>Format</span><b>${kind(s.fileName)}</b><span>Downloads</span><b>${s.downloads.toLocaleString('de-DE')}</b>${s.rating ? `<span>Bewertung</span><b>★ ${String(s.rating).replace('.', ',')}</b>` : ''}</div>
          ${d?.versions?.length > 1 ? `<div class="tool-label">Versionen</div><div class="chip-row">${d.versions.map((v) => `<button class="chip" data-sc-install="${esc(s.id)}" data-v="${v.i}">${esc(v.name)} installieren</button>`).join('')}</div>` : ''}
          <button class="btn primary sc-go" data-sc-install="${esc(s.id)}" ${sc.installing ? 'disabled' : ''}>${sc.installing === s.id ? 'Wird installiert …' : `${icon('download', 16)} In alle Schematics-Ordner legen`}</button>
          <small class="muted">${sc.targets ? (sc.targets.length ? `Ziel: ${sc.targets.length} Ordner – ${esc(sc.targets.slice(0, 4).join(', '))}${sc.targets.length > 4 ? ' …' : ''}` : 'Keine Minecraft-Installation gefunden – der Ordner .minecraft\\schematics wird angelegt.') : ''}</small>
        </div>
      </div>`;
  }

  document.addEventListener('input', (e) => {
    if (e.target.dataset?.sc === 'q') {
      sc.q = e.target.value;
      sc.shown = 60;
      clearTimeout(sc.t);
      sc.t = setTimeout(() => ctx().render(), 150);
    }
  });
  document.addEventListener('click', async (e) => {
    if (ctx().state()?.active !== 'tool-schematics') return;
    const so = e.target.closest?.('[data-sc-sort]');
    if (so) {
      sc.sort = so.dataset.scSort;
      return ctx().render();
    }
    const ca = e.target.closest?.('[data-sc-cat]');
    if (ca) {
      sc.cat = ca.dataset.scCat;
      sc.shown = 60;
      return ctx().render();
    }
    const op = e.target.closest?.('[data-sc-open]');
    if (op) {
      sc.open = op.dataset.scOpen;
      sc.detail = null;
      ctx().render();
      document.querySelector('.content')?.scrollTo({ top: 0 });
      try {
        sc.detail = await window.hub.schem.detail(sc.open);
      } catch {
        sc.detail = { images: [], versions: [] };
      }
      return ctx().render();
    }
    const ins = e.target.closest?.('[data-sc-install]');
    if (ins) {
      if (sc.installing) return;
      sc.installing = ins.dataset.scInstall;
      ctx().render();
      try {
        const r = await window.hub.schem.install(sc.installing, ins.dataset.v != null ? Number(ins.dataset.v) : -1);
        ctx().toast(`${r.file} liegt jetzt in ${r.count} Ordner(n).`);
      } catch (error) {
        ctx().toast(errText(error), 'error');
      }
      sc.installing = '';
      return ctx().render();
    }
    const a = e.target.closest?.('[data-sc-act]')?.dataset.scAct;
    if (a === 'reload') return scLoad(true);
    if (a === 'more') {
      sc.shown += 60;
      return ctx().render();
    }
    if (a === 'back') {
      sc.open = null;
      return ctx().render();
    }
  });
  T.register('tool-schematics', { nav: 'Schematics', title: 'Schematics', sub: 'KELPI-Cloud für Minecraft', icon: 'cube', tint: 'linear-gradient(135deg,#4ade80,#15803d)', desc: 'Alle Schematics der KELPI-Website ansehen und mit einem Klick in jeden Schematics-Ordner (Litematica, WorldEdit, Launcher) legen.' }, schematicsHtml);

  /* ================================================================ Konto */
  const ac = { st: null, mode: 'login', busy: false, err: '', info: '', setup: null };
  const qrSvg = (text) => {
    try {
      const q = window.qrcode(0, 'M');
      q.addData(text);
      q.make();
      return q.createSvgTag({ cellSize: 5, margin: 2, scalable: true });
    } catch {
      return '';
    }
  };
  window.hub.onAccount?.((st) => {
    ac.st = st;
    if (['tool-account', 'settings'].includes(ctx().state()?.active)) ctx().render();
  });
  function accountHtml() {
    if (!ac.st) window.hub.account.state().then((st) => ((ac.st = st), ctx().render())).catch(() => {});
    const st = ac.st || {};
    if (st.needCode && !st.signedIn) {
      return `<div class="tool-card acct-form"><div class="acct-head"><span class="acct-ok">${icon('shield', 22)}</span><div><b>Zwei-Faktor-Anmeldung</b><small class="muted">${esc(st.email || '')}</small></div></div>
        <p class="muted">Öffne deine Authenticator-App (z. B. Google oder Microsoft Authenticator) und gib den 6-stelligen Code für „Revolution Hub“ ein.</p>
        <input class="input acct-code" id="acct-code" inputmode="numeric" maxlength="7" autocomplete="one-time-code" placeholder="123 456" />
        ${ac.err ? `<p class="err">${esc(ac.err)}</p>` : ''}
        <div class="tool-row"><button class="btn primary" data-acct="code" ${ac.busy ? 'disabled' : ''}>${ac.busy ? 'Prüfe …' : 'Bestätigen'}</button><button class="btn ghost" data-acct="cancel">Abbrechen</button></div></div>`;
    }
    if (st.signedIn) {
      const mfaCard = ac.setup
        ? `<div class="tool-card"><div class="tool-label">2FA einrichten</div>
            <div class="acct-qr">${qrSvg(ac.setup.uri)}</div>
            <small class="muted">1. Scanne den Code mit deiner Authenticator-App. Ohne Kamera: Schlüssel <code class="acct-secret">${esc(ac.setup.secret)}</code> von Hand eingeben.<br>2. Gib den 6-stelligen Code aus der App ein:</small>
            <input class="input acct-code" id="acct-mfa-code" inputmode="numeric" maxlength="7" placeholder="123 456" />
            <div class="tool-row"><button class="btn primary" data-acct="mfaFinish" ${ac.busy ? 'disabled' : ''}>2FA einschalten</button><button class="btn ghost" data-acct="mfaCancel">Abbrechen</button></div></div>`
        : `<div class="tool-card"><div class="tool-label">Sicherheit</div>
            <div class="list-row"><div class="grow"><strong>Zwei-Faktor-Anmeldung (2FA)</strong><small>${st.mfa ? 'An – bei jeder Anmeldung brauchst du zusätzlich den Code aus deiner Authenticator-App.' : 'Aus – schütze dein Konto zusätzlich mit einer Authenticator-App.'}</small></div>${st.mfa ? '<button class="btn small ghost" data-acct="mfaRemove">Ausschalten</button>' : '<button class="btn small primary" data-acct="mfaStart">Einschalten</button>'}</div>
            <div class="list-row"><div class="grow"><strong>E-Mail bestätigt</strong><small>${st.emailVerified ? 'Ja.' : 'Noch nicht – nötig für 2FA und zum Zurücksetzen des Passworts.'}</small></div>${st.emailVerified ? `<span class="acct-badge">${icon('check', 14)}</span>` : '<button class="btn small" data-acct="verify">Link senden</button>'}</div></div>`;
      return `<div class="tool-grid two">
        <div class="tool-card acct-card"><div class="acct-head"><span class="acct-ok">${icon('check', 22)}</span><div><b>Angemeldet${st.mfa ? ' · 2FA an' : ''}</b><small class="muted">${esc(st.email)}</small></div></div>
          <p class="muted">Name, Punkte, Cosmetics und dein Schach-Profil (Elo, Statistik, Lernpfad) werden mit diesem Konto abgeglichen. Melde dich auf einem anderen PC mit derselben E-Mail an – dann ist alles da.</p>
          <div class="kv"><span>Letzter Abgleich</span><b>${st.lastSync ? new Date(st.lastSync).toLocaleString('de-DE', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : '–'}</b><span>Status</span><b>${st.syncing ? 'gleicht ab …' : st.error ? 'Fehler' : 'aktuell'}</b></div>
          ${st.error ? `<p class="err">${esc(st.error)}</p>` : ''}${ac.err ? `<p class="err">${esc(ac.err)}</p>` : ''}${ac.info ? `<p class="muted">${esc(ac.info)}</p>` : ''}
          <div class="tool-row" style="flex-wrap:wrap"><button class="btn primary" data-acct="sync" ${st.syncing ? 'disabled' : ''}>Jetzt abgleichen</button><button class="btn" data-acct="pull">Stand aus der Cloud laden</button><button class="btn ghost" data-acct="logout">Abmelden</button></div></div>
        ${mfaCard}</div>`;
    }
    if (false) {
      return `<div class="tool-grid two">
        <div class="tool-card acct-card"><div class="acct-head"><span class="acct-ok">${icon('check', 22)}</span><div><b>Angemeldet</b><small class="muted">${esc(st.email)}</small></div></div>
          <p class="muted">Dein Name, deine Punkte, alle Cosmetics und dein Schach-Profil (Elo, Statistik, Lernpfad) werden mit diesem Konto abgeglichen. Melde dich auf einem anderen PC mit derselben E-Mail an – dann ist alles da.</p>
          <div class="kv"><span>Letzter Abgleich</span><b>${st.lastSync ? new Date(st.lastSync).toLocaleString('de-DE', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : '–'}</b><span>Status</span><b>${st.syncing ? 'gleicht ab …' : st.error ? 'Fehler' : 'aktuell'}</b></div>
          ${st.error ? `<p class="err">${esc(st.error)}</p>` : ''}
          <div class="tool-row" style="flex-wrap:wrap"><button class="btn primary" data-acct="sync" ${st.syncing ? 'disabled' : ''}>Jetzt abgleichen</button><button class="btn" data-acct="pull">Stand aus der Cloud laden</button><button class="btn ghost" data-acct="logout">Abmelden</button></div></div>
        <div class="tool-card"><div class="tool-label">Was wird mitgenommen?</div>
          <div class="acct-list"><span>👤 Anzeigename</span><span>◆ Punkte</span><span>🎨 Cosmetics & Profilbild</span><span>♟️ Schach-Elo, Statistik, Lernpfad, Fehler</span></div>
          <small class="muted">Passwörter speichert der Hub nicht – nur einen verschlüsselten Anmelde-Schlüssel auf diesem PC.</small></div></div>`;
    }
    const create = ac.mode === 'create';
    return `<div class="tool-card acct-form">
        <div class="seg"><button class="${!create ? 'on' : ''}" data-acct-mode="login">Anmelden</button><button class="${create ? 'on' : ''}" data-acct-mode="create">Konto erstellen</button></div>
        <label class="tool-label">E-Mail</label><input class="input" id="acct-mail" type="email" autocomplete="username" placeholder="du@beispiel.de" />
        <label class="tool-label">Passwort</label><input class="input" id="acct-pw" type="password" autocomplete="${create ? 'new-password' : 'current-password'}" placeholder="mindestens 6 Zeichen" />
        ${ac.err ? `<p class="err">${esc(ac.err)}</p>` : ''}${ac.info ? `<p class="muted">${esc(ac.info)}</p>` : ''}
        <div class="tool-row"><button class="btn primary" data-acct="go" ${ac.busy ? 'disabled' : ''}>${ac.busy ? 'Einen Moment …' : create ? 'Konto erstellen' : 'Anmelden'}</button>${!create ? '<button class="btn ghost" data-acct="reset">Passwort vergessen?</button>' : ''}</div>
        <small class="muted">Ein Konto für alle deine PCs: Elo, Punkte und Cosmetics sind überall gleich. Es ist dasselbe Konto wie auf der KELPI-Website (E-Mail-Anmeldung).</small>
      </div>`;
  }
  document.addEventListener('click', async (e) => {
    if (!['tool-account'].includes(ctx().state()?.active)) return;
    const m = e.target.closest?.('[data-acct-mode]');
    if (m) {
      ac.mode = m.dataset.acctMode;
      ac.err = '';
      return ctx().render();
    }
    const a = e.target.closest?.('[data-acct]')?.dataset.acct;
    if (!a) return;
    ac.err = '';
    ac.info = '';
    try {
      if (a === 'go') {
        ac.busy = true;
        ctx().render();
        ac.st = await window.hub.account.login(document.getElementById('acct-mail')?.value, document.getElementById('acct-pw')?.value, ac.mode === 'create');
        ctx().toast(ac.mode === 'create' ? 'Konto erstellt – dein Stand ist gesichert.' : 'Angemeldet – Profil abgeglichen.');
      } else if (a === 'reset') {
        await window.hub.account.reset(document.getElementById('acct-mail')?.value);
        ac.info = 'Wir haben dir eine E-Mail zum Zurücksetzen geschickt.';
      } else if (a === 'code') {
        ac.busy = true;
        ctx().render();
        ac.st = await window.hub.account.code(document.getElementById('acct-code')?.value || '');
        ctx().toast('Angemeldet – Profil abgeglichen.');
      } else if (a === 'cancel') ac.st = await window.hub.account.cancel();
      else if (a === 'mfaStart') ac.setup = await window.hub.account.mfaStart();
      else if (a === 'mfaCancel') ac.setup = null;
      else if (a === 'mfaFinish') {
        ac.busy = true;
        ctx().render();
        ac.st = await window.hub.account.mfaFinish(document.getElementById('acct-mfa-code')?.value || '');
        ac.setup = null;
        ctx().toast('2FA ist an – ab jetzt brauchst du beim Anmelden den Code aus der App.');
      } else if (a === 'mfaRemove') {
        ac.st = await window.hub.account.mfaRemove();
        ctx().toast('2FA ist aus.');
      } else if (a === 'verify') {
        await window.hub.account.verify();
        ac.info = 'Bestätigungs-Link gesendet – schau in dein Postfach.';
      } else if (a === 'logout') ac.st = await window.hub.account.logout();
      else if (a === 'sync') ac.st = await window.hub.account.sync('auto');
      else if (a === 'pull') {
        ac.st = await window.hub.account.sync('pull');
        ctx().toast('Stand aus der Cloud übernommen.');
      }
    } catch (error) {
      ac.err = errText(error);
    }
    ac.busy = false;
    ctx().render();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.target.id === 'acct-pw' || e.target.id === 'acct-mail')) document.querySelector('[data-acct="go"]')?.click();
    if (e.key === 'Enter' && e.target.id === 'acct-code') document.querySelector('[data-acct="code"]')?.click();
    if (e.key === 'Enter' && e.target.id === 'acct-mfa-code') document.querySelector('[data-acct="mfaFinish"]')?.click();
  });
  T.register('tool-account', { nav: 'Konto', title: 'Revolution-Konto', sub: 'Profil auf allen PCs', icon: 'users', tint: 'linear-gradient(135deg,#a78bfa,#4f46e5)', desc: 'Anmelden und Elo, Punkte und Cosmetics auf jedem PC behalten.' }, accountHtml);
})();
