'use strict';

/*
 * Obere Leiste: das R-Logo, die angehefteten/laufenden Apps der echten
 * Windows-Taskleiste und rechts die Hub-Kontrollen. Alles schwarz, die Leiste
 * selbst transparent. Das Windows-Popup hängt als kleine Karte unter dem Logo.
 */
(() => {
  const $ = (selector) => document.querySelector(selector);
  const esc = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

  let state = null;
  let clockTimer = 0;
  let lastKey = '';
  let drawerWasOpen = false;
  let interactive = null;
  let screenData = null;
  let screenLoading = false;

  function setInteractive(on) {
    if (on === interactive) return;
    interactive = on;
    window.hub.taskbar?.interactive?.(on).catch(() => {});
  }

  const windowsApps = () => (state?.windowsApps || []).slice(0, 18);

  function clockHtml() {
    return '<span class="tb-clock-time" data-clock-time>--:--</span><span class="tb-clock-date" data-clock-date>Revulution</span>';
  }

  function fallback(name) {
    return `<span class="tb-win-fallback">${esc(String(name || '?').slice(0, 1).toUpperCase())}</span>`;
  }

  function appButton(item) {
    const label = item.title || item.name;
    return `<button class="tb-winbtn ${item.self ? 'is-self' : ''} ${item.focused ? 'is-focused' : ''}" data-winapp="${esc(item.id)}" title="${esc(label)}">
      ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
      ${item.kind === 'running' ? '<i class="tb-running"></i>' : ''}
    </button>`;
  }

  const windowsMark = () => `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3 5.2 10.4 4v7.2H3zm8.6-1.35L21 2.6v8.6h-9.4zM3 12.8h7.4V20L3 18.8zm8.6 0H21v8.8l-9.4-1.25z"/></svg>`;

  const TOP_ITEMS = {
    crosshair: { icon: 'crosshair', title: 'Crosshair ein- oder ausschalten' },
    screentime: { icon: 'clock', title: 'Bildschirmzeit öffnen' },
    speed: { icon: 'globe', title: 'WLAN-Test öffnen' },
    settings: { icon: 'settings', title: 'Einstellungen öffnen' },
  };

  function extraHtml() {
    const items = (state?.topbarItems || ['crosshair', 'screentime', 'speed']).filter((id) => TOP_ITEMS[id]);
    return items
      .map((id) => {
        const item = TOP_ITEMS[id];
        if (id === 'crosshair') {
          return `<button class="tb-iconbtn tb-cross ${state?.crosshairOn ? 'on' : ''}" data-tb-top="crosshair" title="${esc(item.title)}">${window.icon(item.icon, 15)}</button>`;
        }
        return `<button class="tb-iconbtn" data-tb-top="${id}" title="${esc(item.title)}">${window.icon(item.icon, 15)}</button>`;
      })
      .join('');
  }

  function barHtml() {
    return `<div class="tb-bar">
      <div class="tb-pill tb-pill-left">
      <button class="tb-logo ${state?.drawer ? 'is-open' : ''}" data-act="drawer" title="Desktop · Apps und Widgets">
        <img src="assets/mark.png" alt="R" draggable="false" /><i class="tb-logo-dot"></i>
      </button>
      <span class="tb-divider"></span>
      <div class="tb-apps">${windowsApps().map(appButton).join('')}</div>
      </div>
      <div class="tb-pill tb-pill-right">
      ${extraHtml() ? `<div class="tb-extra">${extraHtml()}</div>` : ''}
      <div class="tb-right">
        <button class="tb-iconbtn" data-act="control" title="Kontrollzentrum">${window.icon('control', 15)}</button>
        <button class="tb-iconbtn tb-power" data-act="quit" title="Revulution Hub beenden">${window.icon('power', 15)}</button>
        <button class="tb-iconbtn" data-act="settings" title="Einstellungen">${window.icon('settings', 15)}${state?.dnd ? '<i class="tb-dot"></i>' : ''}</button>
        <span class="tb-divider"></span>
        <button class="tb-clock" data-act="agenda" title="Agenda">${clockHtml()}</button>
      </div>
      </div>
    </div>`;
  }

  function drawerGrid() {
    const items = windowsApps();
    if (!items.length) {
      return `<p class="drawer-empty">${state?.windowsApps ? 'Keine Apps offen oder angeheftet.' : 'Windows-Apps werden geladen …'}</p>`;
    }
    return items
      .map(
        (item, i) =>
          `<button class="drawer-item" style="--i:${i}" data-winapp="${esc(item.id)}" title="${esc(item.title || item.name)}">
            ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
            <b>${esc(item.name)}</b>${item.kind === 'running' ? '<i class="drawer-run"></i>' : ''}
          </button>`,
      )
      .join('');
  }

  /* Suche: Apps aus dem Startmenü (auch Store-Apps) und Dateien aus dem Windows-Suchindex. */
  let searchSeq = 0;
  let searchTimer = 0;
  let firstResult = '';
  function resultsHtml(q, res, loading) {
    const ql = q.toLocaleLowerCase('de');
    const open = windowsApps().filter((item) => String(item.title || item.name).toLocaleLowerCase('de').includes(ql));
    const apps = (res?.apps || []).filter((a) => !open.some((o) => o.name.toLocaleLowerCase('de') === a.name.toLocaleLowerCase('de')));
    const files = res?.files || [];
    firstResult = open[0] ? `win:${open[0].id}` : apps[0] ? `res:${apps[0].id}` : files[0] ? `res:${files[0].id}` : '';
    const appTile = (a, i, attr) => `<button class="drawer-item" style="--i:${i}" ${attr} title="${esc(a.name)}">${a.icon ? `<img src="${esc(a.icon)}" alt="" draggable="false" />` : fallback(a.name)}<b>${esc(a.name)}</b></button>`;
    let html = '';
    const tiles = [...open.map((o, i) => appTile(o, i, `data-winapp="${esc(o.id)}"`)), ...apps.map((a, i) => appTile(a, i + open.length, `data-result="${esc(a.id)}"`))];
    if (tiles.length) html += `<div class="drawer-sec">APPS</div>${tiles.slice(0, 12).join('')}`;
    if (files.length) {
      html += `<div class="drawer-sec">DATEIEN</div><div class="drawer-files">${files
        .map((f, i) => `<button class="drawer-file" style="--i:${i}" data-result="${esc(f.id)}" title="${esc(f.name)}">${f.icon ? `<img src="${esc(f.icon)}" alt="" draggable="false" />` : '<span class="drawer-file-ic"></span>'}<b>${esc(f.name)}</b><small>${esc(f.dir)}</small></button>`)
        .join('')}</div>`;
    }
    if (loading) html += `<p class="drawer-searching"><i></i><i></i><i></i></p>`;
    if (!html) html = `<p class="drawer-empty">Nichts gefunden für „${esc(q)}“.</p>`;
    return html;
  }
  function runSearch(value) {
    const grid = $('[data-drawer-grid]');
    if (!grid) return;
    const q = String(value || '').trim();
    clearTimeout(searchTimer);
    const seq = ++searchSeq;
    grid.classList.toggle('is-search', Boolean(q));
    if (!q) {
      firstResult = '';
      grid.innerHTML = drawerGrid();
      return;
    }
    grid.innerHTML = resultsHtml(q, null, true);
    searchTimer = setTimeout(async () => {
      let res = null;
      try {
        res = await window.hub.taskbar.search(q);
      } catch {
        res = null;
      }
      if (seq !== searchSeq) return;
      const g = $('[data-drawer-grid]');
      if (g) g.innerHTML = resultsHtml(q, res, false);
    }, 140);
  }

  function drawerHtml() {
    return `<div class="tb-pop" role="dialog" aria-label="Windows-Apps">
      <section class="tb-drawer">
        <header class="drawer-head">
          <div class="drawer-title"><b>Desktop</b><span>Apps, Fenster & Widgets</span></div>
          <label class="drawer-search">${window.icon('search', 13)}<input type="text" placeholder="Apps & Dateien suchen" data-drawer-search autocomplete="off" spellcheck="false" /></label>
          <button class="drawer-close" data-act="drawer" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        <div class="drawer-grid" data-drawer-grid>${drawerGrid()}</div>
        <footer class="drawer-foot">
          <button class="drawer-action" data-act="home">${window.icon('home', 13)} Revulution Hub</button>
          <button class="drawer-action" data-act="desktop">${window.icon('grid', 13)} Desktop</button>
          <button class="drawer-action" data-act="control">${window.icon('control', 13)} Kontrollzentrum</button>
          <button class="drawer-action" data-act="settings">${window.icon('settings', 13)} Einstellungen</button>
          <button class="drawer-action danger" data-act="lock">${window.icon('shield', 13)} Sperren</button>
        </footer>
      </section>
    </div>`;
  }

  const fmtDur = (secs) => {
    const min = Math.round((Number(secs) || 0) / 60);
    if (!min) return '0 Min.';
    const h = Math.floor(min / 60);
    const m = min % 60;
    return h ? `${h} Std. ${m} Min.` : `${m} Min.`;
  };

  /* ---------------------------------------------------------------- WLAN-Test direkt in der Leiste */
  const spd = { running: false, phase: '', pct: 0, live: {}, shown: { down: 0, up: 0, ping: 0 }, result: null, raf: 0 };
  const SP_PH = { wlan: 'WLAN …', ping: 'PING', down: 'DOWNLOAD', up: 'UPLOAD', done: 'FERTIG' };
  const f1 = (v) => (v == null ? '–' : Number(v) >= 100 ? Math.round(v) : (Math.round(v * 10) / 10).toString().replace('.', ','));
  function speedHtml() {
    const r = spd.result;
    const v = spd.shown;
    const ring = spd.running ? Math.max(2, spd.pct) : r ? 100 : 0;
    return `<div class="tb-pop tb-speed" role="dialog" aria-label="WLAN-Test">
      <section class="tb-drawer tb-speed-card">
        <header class="drawer-head">
          <div class="drawer-title"><b>WLAN-Test</b><span>${spd.running ? 'Messung läuft' : r ? 'Letzte Messung' : 'Bereit'}</span></div>
          <button class="drawer-close" data-act="panel-close" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        <div class="tbs-hero">
          <div class="tbs-ring ${spd.running ? 'run' : ''}" style="--p:${ring}">
            <svg viewBox="0 0 120 120"><circle class="bg" cx="60" cy="60" r="52"/><circle class="fg" cx="60" cy="60" r="52" pathLength="100" style="stroke-dashoffset:${100 - ring}"/></svg>
            <div class="tbs-center"><b data-sp-big>${f1(spd.running ? v.down : r?.down)}</b><small>MBIT/S</small><em data-sp-phase>${spd.running ? SP_PH[spd.phase] || '…' : ''}</em></div>
          </div>
          <div class="tbs-vals">
            <div class="${spd.phase === 'down' ? 'on' : ''}"><span>DOWN</span><b data-sp="down">${f1(spd.running ? v.down : r?.down)}</b></div>
            <div class="${spd.phase === 'up' ? 'on' : ''}"><span>UP</span><b data-sp="up">${f1(spd.running ? v.up : r?.up)}</b></div>
            <div class="${spd.phase === 'ping' ? 'on' : ''}"><span>PING</span><b data-sp="ping">${f1(spd.running ? v.ping : r?.ping)}</b></div>
          </div>
        </div>
        <button class="tbs-run" data-act="speed-run" ${spd.running ? 'disabled' : ''}>${spd.running ? 'Misst …' : r ? 'Nochmal testen' : 'Test starten'}</button>
      </section>
    </div>`;
  }
  /** Werte weich hochzählen statt springen. */
  function speedTween() {
    cancelAnimationFrame(spd.raf);
    const step = () => {
      let moving = false;
      for (const k of ['down', 'up', 'ping']) {
        const target = Number(spd.live[k] ?? 0);
        const cur = spd.shown[k];
        const next = cur + (target - cur) * 0.12;
        spd.shown[k] = Math.abs(target - next) < 0.05 ? target : next;
        if (spd.shown[k] !== target) moving = true;
        const el = document.querySelector(`[data-sp="${k}"]`);
        if (el && spd.running) el.textContent = f1(spd.shown[k]);
      }
      const big = document.querySelector('[data-sp-big]');
      if (big && spd.running) big.textContent = f1(spd.shown.down || spd.shown.ping && 0);
      if (moving || spd.running) spd.raf = requestAnimationFrame(step);
    };
    spd.raf = requestAnimationFrame(step);
  }
  function speedPaint() {
    const card = document.querySelector('.tb-speed');
    if (!card) return;
    const ring = spd.running ? Math.max(2, spd.pct) : spd.result ? 100 : 0;
    card.querySelector('.tbs-ring').classList.toggle('run', spd.running);
    card.querySelector('.tbs-ring .fg').style.strokeDashoffset = String(100 - ring);
    const ph = card.querySelector('[data-sp-phase]');
    if (ph) ph.textContent = spd.running ? SP_PH[spd.phase] || '…' : '';
    card.querySelectorAll('.tbs-vals > div').forEach((d, i) => d.classList.toggle('on', spd.running && ['down', 'up', 'ping'][i] === spd.phase));
  }
  window.hub.onSpeed?.((p) => {
    if (!p) return;
    spd.phase = p.phase;
    spd.pct = Number(p.pct) || spd.pct;
    if (p.value != null && ['down', 'up', 'ping'].includes(p.phase)) spd.live[p.phase] = Number(p.value);
    speedPaint();
  });
  async function speedRun() {
    if (spd.running) return;
    spd.running = true;
    spd.live = {};
    spd.shown = { down: 0, up: 0, ping: 0 };
    spd.pct = 0;
    render.popKey = '';
    render();
    speedTween();
    try {
      spd.result = await window.hub.speed.run();
    } catch {
      spd.result = null;
    }
    spd.running = false;
    render.popKey = '';
    render();
  }

  function screenHtml() {
    const d = screenData;
    const apps = d?.apps?.slice(0, 5) || [];
    const max = Math.max(1, apps[0]?.secs || 1);
    return `<div class="tb-pop tb-screen" role="dialog" aria-label="Bildschirmzeit">
      <section class="tb-drawer tb-screen-card">
        <header class="drawer-head">
          <div class="drawer-title"><b>Bildschirmzeit</b><span>Heute am PC</span></div>
          <button class="drawer-close" data-act="panel-close" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        ${d ? `<div class="tb-sc-total"><b>${fmtDur(d.total)}</b><span>${d.pickups || 0} mal aktiv geworden</span></div>
          <div class="tb-sc-list">${apps.length ? apps.map((a) => `<div class="tb-sc-row"><span>${esc(a.name || a.exe)}</span><b>${fmtDur(a.secs)}</b><i><em style="width:${Math.max(4, Math.round((a.secs / max) * 100))}%"></em></i></div>`).join('') : '<p class="drawer-empty">Heute noch keine Zeit erfasst.</p>'}</div>` : '<p class="drawer-empty">Wird geladen …</p>'}
        <footer class="drawer-foot"><button class="drawer-action" data-act="sc-app">${window.icon('clock', 12)} App öffnen</button></footer>
      </section>
    </div>`;
  }

  async function loadScreenTime() {
    if (screenLoading) return;
    screenLoading = true;
    try {
      screenData = await window.hub.screentime.summary();
    } catch {
      screenData = null;
    } finally {
      screenLoading = false;
      lastKey = '';
      render();
    }
  }

  function render() {
    if (!state) return;
    const panel = state.panel || '';
    const drawer = panel === 'drawer';
    const screen = panel === 'screentime';
    const speed = panel === 'speed';
    document.body.classList.toggle('drawer-open', Boolean(panel));
    for (const k of ['drawer', 'screentime', 'speed']) document.body.classList.toggle(`panel-${k}`, panel === k);
    document.title = 'Revulution Leiste';
    // Leiste und Popup getrennt: Ein Klick (Menü auf/zu) baut die Leiste nicht neu auf –
    // sonst lief jedes Mal die Einblend-Animation und alles „blinkte“.
    const barKey = JSON.stringify({ windowsApps: state.windowsApps, badges: state.badges, dnd: state.dnd, topbarItems: state.topbarItems, crosshairOn: state.crosshairOn });
    const popKey = JSON.stringify({ panel, screenTotal: screenData?.total || 0, screenApps: screenData?.apps?.length || 0 });
    const tb = $('#tb');
    if (!tb.querySelector('.tb-bar') || barKey !== lastKey) {
      const old = tb.querySelector('.tb-bar');
      const fresh = document.createElement('div');
      fresh.innerHTML = barHtml();
      if (old) old.replaceWith(fresh.firstElementChild);
      else tb.prepend(fresh.firstElementChild);
      lastKey = barKey;
    }
    tb.querySelector('.tb-logo')?.classList.toggle('is-open', Boolean(state.drawer));
    // Beim Schließen bleibt das Popup stehen und gleitet weich zurück ins Logo.
    if (panel && popKey !== render.popKey) {
      render.popKey = popKey;
      render.appsKey = '';
      tb.querySelector('.tb-pop')?.remove();
      tb.insertAdjacentHTML('beforeend', speed ? speedHtml() : screen ? screenHtml() : drawerHtml());
    }
    // Offene Apps ändern sich: nur das Raster tauschen, ohne das Menü neu aufzubauen.
    const appsKey = JSON.stringify(windowsApps().map((x) => x.id + x.kind));
    const grid = tb.querySelector('[data-drawer-grid]');
    if (grid && appsKey !== render.appsKey && !grid.classList.contains('is-search')) {
      if (render.appsKey) grid.classList.add('settled');
      grid.innerHTML = drawerGrid();
    }
    render.appsKey = appsKey;
    requestAnimationFrame(() => tb.classList.add('ready'));
    tickClock();
    startClock();
    if (drawer && !drawerWasOpen) {
      const input = $('#tb')?.querySelector('[data-drawer-search]');
      if (input && input.value) {
        input.value = '';
        runSearch('');
      }
      setTimeout(() => $('#tb')?.querySelector('[data-drawer-search]')?.focus(), 120);
    }
    if (screen && !screenData) loadScreenTime();
    drawerWasOpen = drawer;
  }

  function locale() {
    return state?.lang === 'en' ? 'en-GB' : state?.lang === 'es' ? 'es-ES' : 'de-DE';
  }

  function tickClock() {
    const now = new Date();
    const time = now.toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' });
    const date = now.toLocaleDateString(locale(), { weekday: 'short', day: 'numeric', month: 'short' });
    document.querySelectorAll('[data-clock-time]').forEach((el) => { el.textContent = time; });
    document.querySelectorAll('[data-clock-date]').forEach((el) => { el.textContent = date; });
  }

  function startClock() {
    clearInterval(clockTimer);
    clockTimer = setInterval(tickClock, 15000);
  }

  function pulse(button) {
    if (!button) return;
    button.classList.remove('pressed');
    void button.offsetWidth;
    button.classList.add('pressed');
    setTimeout(() => button.classList.remove('pressed'), 200);
  }

  function closeDrawer() {
    if (state?.drawer) window.hub.taskbar?.drawer?.(false).catch(() => {});
  }

  document.addEventListener('input', (event) => {
    if (event.target.matches('[data-drawer-search]')) runSearch(event.target.value);
  });

  document.addEventListener('click', (event) => {
    const top = event.target.closest('[data-tb-top]');
    if (top) {
      pulse(top);
      const kind = top.dataset.tbTop;
      if (kind === 'crosshair') return window.hub.crosshair?.toggle?.().catch(() => {});
      if (kind === 'screentime') return window.hub.taskbar?.panel?.('screentime').catch(() => {});
      closeDrawer();
      if (kind === 'settings') return window.hub.openSettings?.().catch(() => {});
      return window.hub.taskbar?.panel?.('speed').catch(() => {});
    }
    const result = event.target.closest('[data-result]');
    if (result) {
      pulse(result);
      window.hub.taskbar?.openResult?.(result.dataset.result).catch(() => {});
      return;
    }
    const winApp = event.target.closest('[data-winapp]');
    if (winApp) {
      pulse(winApp);
      closeDrawer();
      window.hub.taskbar?.launch?.(winApp.dataset.winapp).catch(() => {});
      return;
    }
    const action = event.target.closest('[data-act]');
    if (!action) return;
    pulse(action);
    const act = action.dataset.act;
    if (act === 'drawer') return window.hub.taskbar?.drawer?.(!state?.drawer).catch(() => {});
    if (act === 'panel-close') return window.hub.taskbar?.drawer?.(false).catch(() => {});
    if (act === 'speed-run') return speedRun();
    if (act === 'sc-app') { closeDrawer(); return window.hub.open('tool-screentime').catch(() => {}); }
    if (act === 'home') { closeDrawer(); return window.hub.open('home').catch(() => {}); }
    if (act === 'desktop') { closeDrawer(); return window.hub.open('tool-desktop').catch(() => {}); }
    if (act === 'control') { closeDrawer(); return window.hub.openControl?.().catch(() => {}); }
    if (act === 'settings') { closeDrawer(); return window.hub.openSettings?.().catch(() => {}); }
    if (act === 'quit') {
      closeDrawer();
      if (window.confirm('Revulution Hub und alle laufenden Aufgaben beenden?')) window.hub.quit?.().catch(() => {});
      return;
    }
    if (act === 'agenda') { closeDrawer(); return window.hub.open('agenda').catch(() => {}); }
    if (act === 'lock') { closeDrawer(); return window.hub.cc?.lock?.().catch(() => {}); }
  });

  document.addEventListener('contextmenu', (event) => {
    const app = event.target.closest?.('[data-winapp]');
    if (!app) return;
    event.preventDefault();
    window.hub.taskbar?.context?.(app.dataset.winapp).catch(() => {});
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && event.target.matches?.('[data-drawer-search]') && firstResult) {
      const [kind, ...rest] = firstResult.split(':');
      const id = rest.join(':');
      if (kind === 'win') {
        closeDrawer();
        window.hub.taskbar?.launch?.(id).catch(() => {});
      } else window.hub.taskbar?.openResult?.(id).catch(() => {});
      return;
    }
    if (event.key === 'Escape') closeDrawer();
  });

  /* Die Leiste ist oben volle Breite, das Popup nur eine kleine Karte. Der
     transparente Rest des Fensters darf keine Klicks auf den Desktop schlucken. */
  document.addEventListener('mousemove', (event) => {
    const hit = document.elementFromPoint(event.clientX, event.clientY);
    setInteractive(Boolean(hit?.closest('.tb-pill, body.drawer-open .tb-pop')));
  });
  document.addEventListener('mouseleave', () => setInteractive(false));

  async function refreshTone() {
    try {
      const tone = await window.hub.desktopTone?.();
      $('#tb')?.classList.toggle('on-light', tone === 'light');
    } catch {
      /* dunkel bleiben */
    }
  }
  refreshTone();
  setInterval(refreshTone, 2000);

  window.hub.onTaskbar?.((payload) => {
    state = payload || null;
    render();
  });
  window.hub.taskbarReady?.().catch(() => {});
})();
