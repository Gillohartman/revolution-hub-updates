'use strict';

/*
 * 2.45 Geräte-Apps (Kategorie Gaming, neben „Geräte & RGB“):
 *  (2.45.2: Maus-Studio und AJAZZ-Studio entfernt – Tastatur/Maus/RGB bleiben in „Geräte & RGB“.)
 *
 *  - Stream-Deck-Studio: Tasten-Raster mit Aktionen (Spotify/Medien, Screenshot, Soundboard, Apps, Webseiten,
 *    Crosshair, Ketten) – per Klick oder per Hardware-Taste (z. B. F13–F24 vom Deck) auslösbar.
 *  - Lüfter: Windows-Kühlrichtlinie, GPU-Lüfter/Temperatur, Mainboard-Sensoren (falls verfügbar).
 * Belegungen landen in denselben Regeln wie die Tastatur-App (eine Engine für alles).
 */
(() => {
  const A = window.RevApp;
  const ME = window.RevMacroEditor;
  if (!A) return;
  const { esc } = A;
  const ctx = () => window.HubTools.ctx();

  /* ---------------------------------------------------------------- gemeinsame Regel-Helfer */
  const kbCfg = () => {
    const s = ctx().state()?.settings?.keyboard || {};
    const c = { enabled: s.enabled === true, profiles: Array.isArray(s.profiles) && s.profiles.length ? JSON.parse(JSON.stringify(s.profiles)) : [{ id: 'global', name: 'Überall', apps: [], on: true, rules: [] }] };
    if (!c.profiles.some((p) => !p.apps?.length)) c.profiles.unshift({ id: 'global', name: 'Überall', apps: [], on: true, rules: [] });
    return c;
  };
  const globalProfile = (c) => c.profiles.find((p) => !p.apps?.length);
  async function kbSave(c, enable = true) {
    if (enable) c.enabled = true;
    await window.hub.setSettings({ keyboard: c });
    const st = await window.hub.keyboard.apply();
    window.__kbReset?.();
    return st;
  }
  function setRule(c, from, rule) {
    const p = globalProfile(c);
    p.rules = p.rules.filter((r) => r.from !== from);
    if (rule) p.rules.push({ from, on: true, ...rule });
  }
  /* ================================================================ Stream-Deck-Studio */
  const DECK_ACTIONS = [
    ['none', 'Keine Aktion'], ['media', 'Spotify / Medien'], ['screenshot', 'Screenshot'], ['record', 'Aufnahme an/aus'], ['widgets', 'Widgets an/aus'], ['claude', 'Claude-Status'], ['sound', 'Soundboard-Sound'], ['open', 'Webseite / Programm öffnen'], ['app', 'Hub-App öffnen'], ['crosshair', 'Crosshair an/aus'], ['lock', 'PC sperren'], ['timer', 'Timer starten'], ['multi', 'Mehrere Aktionen (Kette)'],
  ];
  /* ---------------------------------------------------------------- Claude-Status (lokal aus den Claude-Verläufen) */
  const cl = { status: null };
  const clText = (s) => (!s || s.off ? 'aus' : s.working ? `arbeitet${s.agents ? ` · ${s.agents} Agent${s.agents > 1 ? 'en' : ''}` : ''}` : s.done ? 'fertig' : 'ruht');
  if (window.hub.claude) {
    const onClaude = (s) => {
      const before = clText(cl.status);
      cl.status = s;
      if (clText(s) !== before && dk.data && Object.values(page().buttons).some((b) => b?.action?.type === 'claude')) ulPush(150);
      if (dk.root) dkPaint();
    };
    window.hub.claude.status().then(onClaude).catch(() => {});
    window.hub.claude.onStatus(onClaude);
  }
  const ago = (t) => {
    const m = Math.round((Date.now() - t) / 60000);
    return m < 1 ? 'gerade eben' : m < 60 ? `vor ${m} min` : `vor ${Math.round(m / 60)} h`;
  };
  function claudeCard() {
    const s = cl.status;
    const on = ctx().state()?.settings?.claudeLink === true;
    const chip = (st) => `<span class="cl-chip ${st}">${st === 'working' ? '● arbeitet' : st === 'done' ? '✓ fertig' : '○ ruht'}</span>`;
    return `<div class="rv-card cl-card"><div class="rv-row between"><div><b>✳️ Claude</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Zeigt, ob Claude gerade arbeitet oder fertig ist – mit allen aktiven Agenten. Liest nur lokal deine Claude-Verläufe, keine Inhalte. Lege eine Taste auf „Claude-Status“: sie leuchtet orange, solange Claude arbeitet, und grün, wenn es fertig ist.</p></div>
      <label class="rv-row" style="gap:8px;white-space:nowrap"><input type="checkbox" data-cl-on ${on ? 'checked' : ''}/> Mit Claude verbinden</label></div>
      ${on ? (s?.sessions?.length ? `<div class="cl-list">${s.sessions.slice(0, 6).map((x) => `<div class="cl-row"><span class="cl-proj">${esc(x.project)}</span>${chip(x.status)}<small>${ago(x.at)}</small>${x.agents.length ? `<div class="cl-agents">${x.agents.slice(0, 6).map((a) => `<span class="cl-agent ${a.status}" title="Agent ${esc(a.id)} · ${a.status === 'working' ? 'arbeitet' : 'fertig'}">🤖 ${a.status === 'working' ? 'arbeitet' : 'fertig'}</span>`).join('')}</div>` : ''}</div>`).join('')}</div>` : '<p class="rv-muted" style="margin:10px 0 0">Keine Claude-Sitzung in den letzten 3 Stunden.</p>') : ''}
    </div>`;
  }
  const ICONS = ['▶️', '⏭️', '⏮️', '🔇', '📸', '🔊', '🎵', '🌐', '💬', '🎮', '🎯', '🔒', '⏱️', '⭐', '🔥', '💡', '📁', '🖥️', '🎬', '🎤', '🎧', '🚀', '❤️', '😂', '👏', '🥁', '📣', '⚡'];
  const dk = { root: null, data: null, page: 0, sel: null, capture: false, loaded: false };
  const blankDeck = () => ({ cols: 5, rows: 3, pages: [{ name: 'Seite 1', buttons: {} }] });
  async function dkLoad() {
    if (dk.loaded) return;
    dk.loaded = true;
    dk.data = (await A.store.get('streamdeck', null)) || blankDeck();
    if (!dk.data.pages?.length) dk.data = blankDeck();
    // Beispielbelegung für den ersten Start
    const b = dk.data.pages[0].buttons;
    if (!Object.keys(b).length) {
      Object.assign(b, {
        0: { id: 'd1', icon: '⏯️', label: 'Play/Pause', color: '#1db954', action: { type: 'media', key: 'playpause' } },
        1: { id: 'd2', icon: '⏭️', label: 'Weiter', color: '#1db954', action: { type: 'media', key: 'next' } },
        2: { id: 'd3', icon: '📸', label: 'Screenshot', color: '#0a84ff', action: { type: 'screenshot' } },
        3: { id: 'd4', icon: '🔊', label: 'Sound 1', color: '#ff9f0a', action: { type: 'sound', pad: 0 } },
        4: { id: 'd5', icon: '🎯', label: 'Crosshair', color: '#ff375f', action: { type: 'crosshair' } },
      });
    }
  }
  const dkSave = () => {
    ulPush();
    return A.store.set('streamdeck', dk.data);
  };

  /* ---------------------------------------------------------------- Ulanzi D200 direkt (ohne Ulanzi Studio) */
  const UL_KEYS = 13; // 3 × 5, unten rechts sitzt das kleine Uhr-Display
  const ul = { status: null, timer: 0, deckPage: 0, busy: false };
  function ulKeyImage(b) {
    // Claude-Taste: Farbe und Text zeigen live den Status
    if (b?.action?.type === 'claude') {
      const s = cl.status;
      const st = !s || s.off ? 'aus' : s.working ? 'working' : s.done ? 'done' : 'idle';
      b = { ...b, icon: st === 'done' ? '✅' : '✳️', color: st === 'working' ? '#d97757' : st === 'done' ? '#22c55e' : '#3f3f46', label: st === 'working' ? (s.agents ? `${s.agents + 1} aktiv` : 'arbeitet') : st === 'done' ? 'fertig' : st === 'aus' ? 'Claude' : 'ruht' };
    }
    const S = 196;
    const c = document.createElement('canvas');
    c.width = S; c.height = S;
    const g = c.getContext('2d');
    g.fillStyle = '#000';
    g.fillRect(0, 0, S, S);
    if (b) {
      const grad = g.createLinearGradient(0, 0, 0, S);
      grad.addColorStop(0, b.color || '#2c2c34');
      grad.addColorStop(1, '#0b0b10');
      g.fillStyle = grad;
      g.beginPath(); g.roundRect(6, 6, S - 12, S - 12, 34); g.fill();
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      g.font = `${b.label ? 92 : 110}px "Segoe UI Emoji", "Apple Color Emoji", sans-serif`;
      g.fillText(b.icon || '⭐', S / 2, b.label ? 86 : S / 2 + 4);
      if (b.label) {
        g.fillStyle = '#fff';
        let size = 30;
        g.font = `700 ${size}px "Segoe UI", system-ui, sans-serif`;
        while (size > 16 && g.measureText(b.label).width > S - 24) g.font = `700 ${(size -= 2)}px "Segoe UI", system-ui, sans-serif`;
        g.fillText(b.label, S / 2, 160);
      }
    }
    return c.toDataURL('image/png');
  }
  function ulPush(delay = 450) {
    if (!ul.status?.connected || !dk.data) return;
    clearTimeout(ul.timer);
    ul.timer = setTimeout(async () => {
      if (ul.busy) return ulPush(300);
      ul.busy = true;
      try {
        ul.deckPage = dk.page;
        const p = page();
        const keys = [];
        for (let i = 0; i < UL_KEYS; i++) keys.push({ index: i, png: ulKeyImage(p.buttons[i]) });
        await window.hub.ulanzi.push(keys);
      } catch (e) {
        A.toast(A.errText(e), 'error');
      } finally {
        ul.busy = false;
      }
    }, delay);
  }
  if (window.hub.ulanzi) {
    window.hub.ulanzi.status().then((s) => { ul.status = s; if (s.connected) dkLoad().then(() => ulPush(0)); if (dk.data) dkPaint(); }).catch(() => {});
    window.hub.ulanzi.onStatus((s) => {
      const was = ul.status?.connected;
      ul.status = s;
      applyDeckName();
      if (s.connected && !was) dkLoad().then(() => { // frisch verbunden: aktuelle Belegung + Helligkeit aufs Deck
        ulPush(0);
        if (dk.data.ulanziBrightness != null) window.hub.ulanzi.brightness(dk.data.ulanziBrightness).catch(() => {});
      });
      dkPaint();
    });
    window.hub.ulanzi.onButton(async (b) => {
      if (!b?.pressed) return;
      await dkLoad();
      const btn = dk.data.pages[ul.deckPage]?.buttons[b.index];
      const el = dk.root?.querySelector(`[data-dk-key="${b.index}"]`);
      if (el && dk.page === ul.deckPage) { el.classList.remove('press'); void el.offsetWidth; el.classList.add('press'); }
      if (btn) runAction(btn.action);
    });
  }
  /* Name nach angeschlossenem Gerät: Ulanzi → „Ulanzi D200“, Elgato → „Stream Deck“, sonst „Deck Studio“ */
  const dev = { elgato: false, ulanzi: false, checked: 0 };
  const deckName = () => (ul.status?.connected || dev.ulanzi ? 'Ulanzi D200' : dev.elgato ? 'Stream Deck' : 'Deck Studio');
  function applyDeckName() {
    const meta = window.HubTools.TOOLS?.['tool-streamdeck'];
    if (meta) meta.title = deckName();
    if (ctx().state()?.active === 'tool-streamdeck') {
      const t = document.getElementById('page-title');
      if (t) t.textContent = deckName();
    }
  }
  function detectDecks() {
    if (Date.now() - dev.checked < 10000) return;
    dev.checked = Date.now();
    window.hub.deck?.devices?.().then((d) => {
      const changed = d.elgato !== dev.elgato || d.ulanzi !== dev.ulanzi;
      Object.assign(dev, d);
      applyDeckName();
      if (changed) dkPaint();
    }).catch(() => {});
  }
  function ulCard() {
    const s = ul.status;
    const on = ctx().state()?.settings?.ulanziDirect === true || Boolean(s?.running);
    let info = '';
    try { info = s?.info ? JSON.parse(s.info).Dversion : ''; } catch { /* egal */ }
    const state = !on ? 'Aus' : s?.connected ? `Verbunden${info ? ` · Firmware ${esc(info)}` : ''}` : s?.error ? `Fehler: ${esc(s.error)}` : 'Kein D200 gefunden – per USB anschliessen';
    return `<div class="rv-card dk-ulanzi"><div class="rv-row between"><div><b>Ulanzi D200 – direkt im Hub</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Ohne Ulanzi Studio: Die Tasten unten erscheinen mit Symbol, Farbe und Text auf deinem Deck, ein Druck am Deck löst die Hub-Aktion aus. Die obersten 13 Felder sind die Deck-Tasten, unten rechts sitzt die Uhr. Ulanzi Studio dabei bitte schliessen.</p></div>
      <label class="rv-row" style="gap:8px;white-space:nowrap"><input type="checkbox" data-ul-on ${on ? 'checked' : ''}/> Direkt steuern</label></div>
      ${on ? `<div class="rv-row between" style="margin-top:10px"><span class="rv-pill ${s?.connected ? 'ok' : ''}">${s?.connected ? '🟢' : '⚪'} ${state}</span>
        <div class="rv-row"><label class="rv-muted">Helligkeit <input type="range" min="5" max="100" step="5" value="${dk.data.ulanziBrightness ?? 80}" data-ul-bright/></label>
        <button class="rv-btn sm" data-ul-push ${s?.connected ? '' : 'disabled'}>Jetzt übertragen</button></div></div>` : ''}
    </div>`;
  }
  const page = () => dk.data.pages[dk.page];
  const selBtn = () => (dk.sel != null ? page().buttons[dk.sel] : null);
  async function runAction(a) {
    if (!a) return;
    try {
      switch (a.type) {
        case 'media': return await window.hub.cc.media(a.key || 'playpause');
        case 'screenshot': return await window.hub.cc.screenshot();
        case 'record': {
          const r = await window.hub.deck.record();
          if (r?.error) A.toast(r.error, 'error');
          else A.toast(r?.active ? '⏺ Aufnahme läuft' : '⏹ Aufnahme gespeichert');
          return r;
        }
        case 'widgets': {
          const s = await window.hub.desktopWidgets.state();
          const on = s?.enabled === false;
          await window.hub.desktopWidgets.set(on);
          return A.toast(on ? 'Widgets eingeblendet' : 'Widgets ausgeblendet');
        }
        case 'claude': {
          const s = cl.status?.off || !cl.status ? await window.hub.claude.enable(true) : cl.status;
          cl.status = s;
          const top = s.sessions?.[0];
          return A.toast(top ? `Claude ${clText(s)} – ${top.project}` : 'Claude: keine aktive Sitzung');
        }
        case 'sound': {
          const src = await window.hub.widgetSound.data(Number(a.pad) || 0);
          if (!src) return A.toast(`Soundboard-Platz ${(Number(a.pad) || 0) + 1} ist leer – wähle einen Sound.`, 'error');
          const au = new Audio(src);
          au.volume = Math.max(0, Math.min(1, Number(a.volume ?? 1)));
          return au.play();
        }
        case 'open': return await window.hub.deck.run(a.target);
        case 'app': return await window.hub.open(a.app || 'home');
        case 'crosshair': return await window.hub.crosshair.toggle();
        case 'lock': return await window.hub.cc.lock();
        case 'timer': return await window.hub.cc.timerIsland(Math.max(1, Number(a.minutes) || 5) * 60, a.label || 'Timer');
        case 'multi':
          for (const step of a.steps || []) {
            await runAction(step);
            await new Promise((r) => setTimeout(r, Math.max(0, Number(step.after) || 150)));
          }
          return null;
        default: return null;
      }
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    return null;
  }
  // Hardware-Tasten (über die Tastatur-Engine) lösen Deck-Tasten aus
  window.hub.deck?.onAction?.(async (id) => {
    if (!String(id).startsWith('deck-')) return;
    await dkLoad();
    const bid = String(id).slice(5);
    for (const p of dk.data.pages) for (const b of Object.values(p.buttons)) if (b?.id === bid) return runAction(b.action);
    return null;
  });
  function actionForm(b) {
    const a = b.action || { type: 'none' };
    const pad = `<select class="rv-input sm" data-dk-act="pad">${Array.from({ length: 8 }, (_, i) => `<option value="${i}" ${Number(a.pad) === i ? 'selected' : ''}>Platz ${i + 1}</option>`).join('')}</select><button class="rv-btn sm" data-dk-pick>Sound wählen …</button>`;
    const apps = Object.entries({ ...window.HubTools.TOOLS }).map(([k, v]) => [k, v.title]).concat([['gaming', 'Gaming Hub'], ['chats', 'Chats'], ['docs', 'Dokumente'], ['video', 'Video-Schnitt'], ['chess', 'Schach'], ['geo', 'GeoRevulution']]);
    let extra = '';
    if (a.type === 'media') extra = `<select class="rv-input sm" data-dk-act="key">${[['playpause', 'Play / Pause'], ['next', 'Nächster Titel'], ['prev', 'Vorheriger Titel'], ['mute', 'Stumm']].map(([v, n]) => `<option value="${v}" ${a.key === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
    else if (a.type === 'sound') extra = `${pad}<label class="rv-muted">Lautstärke <input type="range" min="0" max="1" step="0.05" value="${a.volume ?? 1}" data-dk-act="volume"/></label><small class="rv-muted">Gleiche Plätze wie im Soundboard-Widget.</small>`;
    else if (a.type === 'open') extra = `<input class="rv-input sm" data-dk-act="target" value="${esc(a.target || '')}" placeholder="https://open.spotify.com oder C:\\Programm.exe" style="width:100%"/>`;
    else if (a.type === 'app') extra = `<select class="rv-input sm" data-dk-act="app">${apps.map(([k, n]) => `<option value="${k}" ${a.app === k ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>`;
    else if (a.type === 'timer') extra = `<label class="rv-muted">Minuten <input class="rv-input sm" type="number" min="1" max="600" value="${a.minutes || 5}" data-dk-act="minutes" style="width:80px"/></label>`;
    else if (a.type === 'multi') extra = `<div class="dk-chain">${(a.steps || []).map((s, i) => `<div class="rv-row"><span class="rv-pill">${i + 1}. ${esc(DECK_ACTIONS.find((x) => x[0] === s.type)?.[1] || s.type)}${s.type === 'media' ? ` · ${esc(s.key)}` : s.type === 'sound' ? ` · Platz ${(Number(s.pad) || 0) + 1}` : ''}</span><label class="rv-muted">danach <input class="rv-input sm" type="number" min="0" max="10000" step="50" value="${s.after ?? 150}" data-dk-chainafter="${i}" style="width:80px"/> ms</label><button class="rv-btn sm ghost" data-dk-chaindel="${i}">✕</button></div>`).join('')}
      <div class="rv-row"><select class="rv-input sm" data-dk-chainadd><option value="">＋ Schritt hinzufügen …</option>${DECK_ACTIONS.filter(([k]) => !['none', 'multi'].includes(k)).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></div></div>`;
    return extra;
  }
  function dkPaint() {
    if (!dk.root || !dk.data) return;
    const d = dk.data;
    const p = page();
    const b = selBtn();
    const cells = [];
    const ulOn = ctx().state()?.settings?.ulanziDirect === true && d.cols === 5 && d.rows === 3;
    for (let i = 0; i < d.cols * d.rows; i++) {
      if (ulOn && i === UL_KEYS) { cells.push('<div class="dk-key dk-clock" style="grid-column:span 2" title="Kleines Display des D200 (Uhr)"><span class="dk-ic">🕒</span><small>Uhr-Display</small></div>'); break; }
      const x = p.buttons[i];
      cells.push(`<button class="dk-key ${dk.sel === i ? 'sel' : ''} ${x ? '' : 'empty'}" data-dk-key="${i}" style="--c:${esc(x?.color || '#2c2c34')}">${x ? `<span class="dk-ic">${esc(x.icon || '⭐')}</span><small>${esc(x.label || '')}</small>${x.hotkey ? `<i class="dk-hk">${esc(x.hotkey)}</i>` : ''}` : '<span class="dk-plus">＋</span>'}</button>`);
    }
    dk.root.innerHTML = `<div class="dv dk">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">${esc(deckName())}</h2><p class="rv-sub">${ul.status?.connected ? 'Dein Ulanzi D200 ist verbunden – Änderungen erscheinen sofort auf dem Deck.' : dev.elgato ? 'Elgato Stream Deck erkannt: Tasten in der Elgato-Software auf „Hotkey“ F13–F24 legen und hier unter „Hardware-Taste“ zuweisen.' : 'Klicken = ausprobieren. Rechts einstellen. Mit „Hardware-Taste“ löst auch ein Deck (z. B. F13–F24) die Aktion aus.'}</p></div>
        <div class="rv-row"><div class="rv-tabs">${d.pages.map((pg, i) => `<button class="${i === dk.page ? 'on' : ''}" data-dk-page="${i}">${esc(pg.name)}</button>`).join('')}<button data-dk-addpage>＋</button></div>
        <select class="rv-input sm" data-dk-size>${[[3, 2], [5, 3], [8, 4]].map(([c, r]) => `<option value="${c}x${r}" ${d.cols === c && d.rows === r ? 'selected' : ''}>${c} × ${r}</option>`).join('')}</select></div></div></div>
      ${ulCard()}
      ${claudeCard()}
      <div class="dk-wrap"><div class="dk-grid" style="grid-template-columns:repeat(${d.cols},1fr)">${cells.join('')}</div>
      <aside class="rv-card dk-side">${b ? `<b>Taste ${dk.sel + 1}</b>
        <label>Beschriftung<input class="rv-input sm" data-dk-field="label" value="${esc(b.label || '')}" maxlength="20"/></label>
        <label>Symbol<div class="dk-icons">${ICONS.map((ic) => `<button class="dk-ico ${b.icon === ic ? 'on' : ''}" data-dk-icon="${ic}">${ic}</button>`).join('')}</div></label>
        <label class="rv-row between">Farbe<input type="color" value="${esc(b.color || '#2c2c34')}" data-dk-field="color"/></label>
        <label>Aktion<select class="rv-input sm" data-dk-type>${DECK_ACTIONS.map(([k, n]) => `<option value="${k}" ${b.action?.type === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <div class="dk-act">${actionForm(b)}</div>
        <label>Hardware-Taste<div class="rv-row"><button class="rv-btn sm ${dk.capture ? 'on' : ''}" data-dk-hotkey>${dk.capture ? 'Taste am Deck drücken …' : b.hotkey ? esc(b.hotkey) : 'Zuweisen'}</button>${b.hotkey ? '<button class="rv-btn sm ghost" data-dk-hotkeydel>✕</button>' : ''}</div></label>
        <div class="rv-row"><button class="rv-btn sm primary" data-dk-test>▶ Testen</button><button class="rv-btn sm danger" data-dk-del>Taste leeren</button></div>`
        : '<b>Taste wählen</b><p class="rv-muted">Klicke eine leere Taste (＋), um sie zu belegen. Ein Klick auf eine belegte Taste führt sie aus und öffnet ihre Einstellungen.</p>'}</aside></div>
    </div>`;
  }
  async function hotkeyRule(b, code) {
    const c = kbCfg();
    if (b.hotkey) setRule(c, b.hotkey, null);
    if (code) setRule(c, code, { type: 'hub', to: `deck-${b.id}` });
    b.hotkey = code || '';
    dkSave();
    try {
      await kbSave(c, Boolean(code) || c.enabled);
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    dkPaint();
  }
  document.addEventListener('click', async (e) => {
    if (!dk.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const key = q('[data-dk-key]')?.dataset.dkKey;
    if (key != null) {
      const i = Number(key);
      if (!page().buttons[i]) page().buttons[i] = { id: Math.random().toString(36).slice(2, 8), icon: '⭐', label: 'Neu', color: '#5e5ce6', action: { type: 'none' } };
      else runAction(page().buttons[i].action);
      const el = q('[data-dk-key]');
      el.classList.remove('press');
      void el.offsetWidth;
      el.classList.add('press');
      dk.sel = i;
      dkSave();
      return setTimeout(dkPaint, 120);
    }
    if (q('[data-ul-push]')) return ulPush(0);
    const pg = q('[data-dk-page]')?.dataset.dkPage;
    if (pg != null) {
      dk.page = Number(pg);
      dk.sel = null;
      return dkPaint();
    }
    if (q('[data-dk-addpage]')) {
      dk.data.pages.push({ name: `Seite ${dk.data.pages.length + 1}`, buttons: {} });
      dk.page = dk.data.pages.length - 1;
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    const ic = q('[data-dk-icon]')?.dataset.dkIcon;
    if (ic) {
      b.icon = ic;
      dkSave();
      return dkPaint();
    }
    if (q('[data-dk-test]')) return runAction(b.action);
    if (q('[data-dk-del]')) {
      if (b.hotkey) await hotkeyRule(b, '');
      delete page().buttons[dk.sel];
      dk.sel = null;
      dkSave();
      return dkPaint();
    }
    if (q('[data-dk-pick]')) {
      const pad = Number(b.action.pad) || 0;
      const name = await window.hub.widgetSound.pick(pad).catch((err) => A.toast(A.errText(err), 'error'));
      if (name) {
        b.label = String(name).replace(/\.[^.]+$/, '').slice(0, 20);
        dkSave();
        dkPaint();
        A.toast(`„${name}“ liegt jetzt auf Platz ${pad + 1} – auch im Soundboard-Widget.`);
      }
      return;
    }
    if (q('[data-dk-hotkey]')) {
      dk.capture = !dk.capture;
      return dkPaint();
    }
    if (q('[data-dk-hotkeydel]')) return hotkeyRule(b, '');
    const cd = q('[data-dk-chaindel]')?.dataset.dkChaindel;
    if (cd != null) {
      b.action.steps.splice(Number(cd), 1);
      dkSave();
      return dkPaint();
    }
  });
  document.addEventListener('change', (e) => {
    if (!dk.root?.contains(e.target)) return;
    const t = e.target;
    if (t.matches('[data-ul-on]')) {
      return window.hub.ulanzi.enable(t.checked).then((s) => {
        ul.status = s;
        if (t.checked && (dk.data.cols !== 5 || dk.data.rows !== 3)) Object.assign(dk.data, { cols: 5, rows: 3 }); // Raster wie am D200
        if (ctx().state()?.settings) ctx().state().settings.ulanziDirect = t.checked;
        dkSave();
        dkPaint();
      }).catch((err) => A.toast(A.errText(err), 'error'));
    }
    if (t.matches('[data-cl-on]')) {
      return window.hub.claude.enable(t.checked).then((s) => {
        cl.status = s;
        if (ctx().state()?.settings) ctx().state().settings.claudeLink = t.checked;
        ulPush(100);
        dkPaint();
      }).catch((err) => A.toast(A.errText(err), 'error'));
    }
    if (t.matches('[data-ul-bright]')) {
      dk.data.ulanziBrightness = Number(t.value);
      A.store.set('streamdeck', dk.data);
      return window.hub.ulanzi.brightness(Number(t.value)).catch(() => {});
    }
    if (t.matches('[data-dk-size]')) {
      const [c, r] = t.value.split('x').map(Number);
      Object.assign(dk.data, { cols: c, rows: r });
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    if (t.dataset.dkField) b[t.dataset.dkField] = t.value;
    else if (t.matches('[data-dk-type]')) b.action = { type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'sound' ? { pad: 0, volume: 1 } : t.value === 'multi' ? { steps: [] } : {}) };
    else if (t.dataset.dkAct) b.action[t.dataset.dkAct] = t.type === 'range' || t.type === 'number' || t.dataset.dkAct === 'pad' ? Number(t.value) : t.value;
    else if (t.matches('[data-dk-chainadd]') && t.value) b.action.steps.push({ type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'sound' ? { pad: 0 } : {}), after: 150 });
    else if (t.dataset.dkChainafter != null) b.action.steps[Number(t.dataset.dkChainafter)].after = Number(t.value) || 0;
    dkSave();
    dkPaint();
  });
  document.addEventListener('keydown', (e) => {
    if (!dk.capture || !dk.root || !document.contains(dk.root)) return;
    e.preventDefault();
    e.stopPropagation();
    dk.capture = false;
    const b = selBtn();
    if (!b) return dkPaint();
    if (['Escape'].includes(e.code)) return dkPaint();
    if (!/^F(1[3-9]|2[0-4])$/.test(e.code) && !window.confirm(`„${e.code}“ ist eine normale Taste – sie würde dann überall nur noch diese Deck-Aktion auslösen. Trotzdem verwenden?`)) return dkPaint();
    hotkeyRule(b, e.code);
  }, true);
  A.define('tool-streamdeck', { nav: 'Deck Studio', title: 'Deck Studio', sub: 'Stream Deck & Ulanzi: Tasten für alles', icon: 'grid', tint: 'linear-gradient(135deg,#818cf8,#312e81)', desc: 'Dein Stream Deck oder Ulanzi-Deck im Hub: Spotify/Medien, Screenshot, Sounds, Aufnahme, Widgets, Claude-Status, Apps, Webseiten, Crosshair und Ketten.' }, {
    async mount(root) {
      dk.root = root;
      applyDeckName();
      detectDecks();
      root.innerHTML = '<div class="rv-empty">Lädt …</div>';
      await dkLoad();
      if (dk.root === root) dkPaint();
    },
    unmount() {
      dk.root = null;
      dk.capture = false;
    },
  });

  /* ================================================================ Clips (eigene App, Engine im Gaming Hub) */
  window.HubTools.register('tool-clips', { nav: 'Clips', title: 'Clips', sub: 'Aufnehmen, Highlights, Facecam', icon: 'camera', tint: 'linear-gradient(135deg,#fb7185,#9f1239)', desc: 'Der Clipper: läuft im Hintergrund, speichert die letzten Sekunden per Hotkey, nimmt lange Aufnahmen auf, mit Facecam, Ton und Keystrokes – und alle Clips zum Ansehen und Schneiden.' }, () => '<div class="page"><div class="empty">Clips wird geöffnet …</div></div>');

  /* ================================================================ Lüfter – wie Fan Control (2.45.3)
     Alle Lüfter-Anschlüsse (Mainboard + Grafikkarte) mit drehendem Lüfter in echter Drehzahl,
     je Anschluss: Auto (BIOS) · Fest (%) · Kurve (Temperatur → %). Der Helfer RevFans.exe
     (Administrator, PawnIO-Treiber) liest und steuert; Kurven laufen dort auch bei geschlossenem Hub-Fenster.
     Windows-Kühlrichtlinie bleibt unten als Zusatz. */
  const fn = { root: null, st: null, timer: 0, busy: false, ctl: null, snap: null, cfg: { controls: {} }, saveT: 0, curveDrag: null, starting: false, err: '' };
  const DEF_CURVE = [[30, 25], [50, 40], [65, 60], [75, 80], [85, 100]];
  function fnPorts() {
    const ports = [];
    for (const h of fn.snap?.hardware || []) {
      for (const s of h.sensors) {
        if (s.type !== 'Control') continue;
        const fan = h.sensors.find((x) => x.type === 'Fan' && x.id === s.id.replace('/control/', '/fan/'));
        ports.push({ id: s.id, name: s.name, hw: h.name, hwType: h.type, pct: s.value, rpm: fan?.value ?? null, control: s.control });
      }
    }
    return ports;
  }
  const fnTemps = () => (fn.snap?.hardware || []).flatMap((h) => h.sensors.filter((s) => s.type === 'Temperature' && Number.isFinite(s.value) && s.value > 0).map((s) => ({ ...s, hw: h.name })));
  const fanSvg = (rpm) => {
    const dur = rpm > 0 ? Math.max(0.12, Math.min(3, 900 / rpm)) : 0;
    return `<svg class="fc-fan ${dur ? 'spin' : ''}" style="--dur:${dur}s" viewBox="0 0 48 48"><circle cx="24" cy="24" r="22" class="fc-ring"/>${[0, 72, 144, 216, 288].map((a) => `<path transform="rotate(${a} 24 24)" d="M24 24c-2-6-1-13 5-16 5 2 4 9 0 13-1.6 1.6-3.4 2.6-5 3z" class="fc-blade"/>`).join('')}<circle cx="24" cy="24" r="4.2" class="fc-hub"/></svg>`;
  };
  function curveSvg(id, points, temp) {
    const W = 300, H = 140, x = (t) => ((t - 20) / 80) * W, y = (p) => H - (p / 100) * H;
    const path = points.map((p, i) => `${i ? 'L' : 'M'}${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join(' ');
    const cur = Number.isFinite(temp) ? `<line x1="${x(temp)}" x2="${x(temp)}" y1="0" y2="${H}" class="fc-now"/>` : '';
    const grid = [40, 60, 80].map((t) => `<line x1="${x(t)}" x2="${x(t)}" y1="0" y2="${H}" class="fc-grid"/><text x="${x(t) + 3}" y="${H - 4}" class="fc-ax">${t}°</text>`).join('') + [25, 50, 75].map((p) => `<line x1="0" x2="${W}" y1="${y(p)}" y2="${y(p)}" class="fc-grid"/><text x="3" y="${y(p) - 3}" class="fc-ax">${p}%</text>`).join('');
    return `<svg class="fc-curve" viewBox="0 0 ${W} ${H}" data-fc-curve="${esc(id)}">${grid}${cur}<path d="${path} L${W},${y(points[points.length - 1][1])}" class="fc-line"/>${points.map((p, i) => `<circle cx="${x(p[0])}" cy="${y(p[1])}" r="7" class="fc-pt" data-fc-pt="${i}"/>`).join('')}</svg>`;
  }
  function fnPaint() {
    if (!fn.root) return;
    const s = fn.st;
    const pol = s?.policy?.ac === 'unknown' && fn.chosen ? fn.chosen : s?.policy?.ac;
    const ctl = fn.ctl;
    const ports = fnPorts();
    const temps = fnTemps();
    const tempOpts = (sel) => temps.map((t) => `<option value="${esc(t.id)}" ${t.id === sel ? 'selected' : ''}>${esc(t.hw)} · ${esc(t.name)} (${Math.round(t.value)}°)</option>`).join('');
    const defaultTemp = (temps.find((t) => /Tctl|Package|CPU/i.test(t.name) && /cpu/i.test(t.id)) || temps[0])?.id;
    let main;
    if (!ctl) main = '<div class="rv-card"><p class="rv-muted">Prüfe Lüftersteuerung …</p></div>';
    else if (!ctl.helper) main = '<div class="rv-card"><b>Lüftersteuerung nicht verfügbar</b><p class="rv-muted">Der Lüfter-Helfer fehlt in dieser Installation – bitte den Hub aktualisieren.</p></div>';
    else if (!ctl.pawnio) main = `<div class="rv-card fc-start"><div><b>Mainboard-Treiber installieren</b><p class="rv-muted">Für die Lüfter braucht Windows den Treiber „PawnIO“ (derselbe wie bei Fan Control, Open Source, signiert). Der Hub lädt den offiziellen Installer, prüft die Signatur und installiert ihn – Windows fragt dabei nach Administratorrechten.</p>${fn.err ? `<p class="fc-err">${esc(fn.err)}</p>` : ''}</div><button class="rv-btn primary" data-fc-driver ${fn.starting ? 'disabled' : ''}>${fn.starting ? 'Installiert …' : 'Treiber installieren'}</button></div>`;
    else if (!fn.snap) main = `<div class="rv-card fc-start"><div><b>Lüftersteuerung starten</b><p class="rv-muted">Wie Fan Control: alle Lüfter sehen und jeden Anschluss einzeln steuern. Windows fragt einmal nach Administratorrechten – die braucht der Zugriff aufs Mainboard.</p>${fn.err ? `<p class="fc-err">${esc(fn.err)}</p>` : ''}</div><button class="rv-btn primary" data-fc-start ${fn.starting ? 'disabled' : ''}>${fn.starting ? 'Startet …' : 'Starten'}</button></div>`;
    else {
      main = `<div class="fc-grid">${ports.map((p) => {
        const c = fn.cfg.controls[p.id] || { mode: 'auto' };
        const temp = c.sensor ? temps.find((t) => t.id === c.sensor)?.value : null;
        return `<div class="fc-card ${c.mode !== 'auto' ? 'manual' : ''}" data-fc-port="${esc(p.id)}">
          <div class="fc-head">${fanSvg(p.rpm)}<div class="fc-names"><b>${esc(p.name)}</b><small>${esc(p.hw)}</small></div></div>
          <div class="fc-vals"><div><small>Drehzahl</small><b>${p.rpm == null ? '–' : `${Math.round(p.rpm)}`}<i>U/min</i></b></div><div><small>Leistung</small><b>${p.pct == null ? '–' : Math.round(p.pct)}<i>%</i></b></div></div>
          <div class="fc-modes">${[['auto', 'Auto'], ['fixed', 'Fest'], ['curve', 'Kurve']].map(([m, n]) => `<button class="${c.mode === m ? 'on' : ''}" data-fc-mode="${m}">${n}</button>`).join('')}</div>
          ${c.mode === 'fixed' ? `<label class="fc-fixed"><input type="range" min="0" max="100" step="1" value="${c.value ?? 50}" data-fc-value/><b>${c.value ?? 50} %</b></label>` : ''}
          ${c.mode === 'curve' ? `<select class="rv-input sm fc-sensor" data-fc-sensor>${tempOpts(c.sensor || defaultTemp)}</select>${curveSvg(p.id, c.points || DEF_CURVE, temp)}<small class="rv-muted">Punkte ziehen · x = Temperatur, y = Lüfter-%</small>` : ''}
          ${c.mode === 'auto' ? '<small class="rv-muted">Steuert das Mainboard (BIOS-Kurve).</small>' : ''}
        </div>`;
      }).join('')}</div>
      <div class="rv-card"><b>Temperaturen</b><div class="fc-temps">${temps.map((t) => `<div><span>${esc(t.name)}<small>${esc(t.hw)}</small></span><b class="${t.value >= 80 ? 'hot' : t.value >= 65 ? 'warm' : ''}">${t.value.toFixed(1)}°C</b></div>`).join('')}</div></div>`;
    }
    fn.root.innerHTML = `<div class="dv">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">Lüfter</h2><p class="rv-sub">Alle Lüfter und Anschlüsse – wie Fan Control, direkt im Hub.</p></div><div class="rv-row">${fn.snap ? `<span class="rv-pill ok">● Steuerung aktiv · ${esc(fn.snap.at || '')}</span><button class="rv-btn sm" data-fc-stop title="Alle Lüfter zurück auf Automatik und Helfer beenden">Beenden</button>` : ''}</div></div>${fn.snap?.error ? `<p class="fc-err">${esc(fn.snap.error)}</p>` : ''}</div>
      ${main}
      <div class="rv-card"><b>Windows-Kühlrichtlinie</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 10px">Aktiv: Lüfter drehen zuerst hoch (kühler, lauter). Passiv: erst wird die CPU gedrosselt (leiser).</p>
        <div class="rv-tabs"><button class="${pol === 'active' ? 'on' : ''}" data-fn-pol="active">❄️ Aktiv – kühl</button><button class="${pol === 'passive' ? 'on' : ''}" data-fn-pol="passive">🤫 Passiv – leise</button></div></div>
    </div>`;
  }
  function fnSave() {
    clearTimeout(fn.saveT);
    fn.saveT = setTimeout(async () => {
      try {
        fn.snap = await window.hub.fanctl.config(fn.cfg);
      } catch (e) {
        A.toast(A.errText(e), 'error');
      }
      fnPaint();
    }, 250);
  }
  async function fnLoad() {
    if (fn.busy || fn.curveDrag) return;
    fn.busy = true;
    try {
      fn.ctl = await window.hub.fanctl.status();
      if (fn.ctl.running) {
        fn.snap = await window.hub.fanctl.list();
        if (fn.snap?.config?.controls && !fn.cfgLoaded) { fn.cfg = { controls: { ...fn.snap.config.controls } }; fn.cfgLoaded = true; }
      } else fn.snap = null;
      if (!fn.st || Date.now() - (fn.stAt || 0) > 15000) { fn.st = await window.hub.fans.state(); fn.stAt = Date.now(); }
    } catch (e) {
      fn.err = A.errText(e);
    }
    fn.busy = false;
    if (!fn.root?.querySelector('select:focus, input[type=range]:active')) fnPaint();
  }
  const portCfg = (id) => (fn.cfg.controls[id] ||= { mode: 'auto' });
  document.addEventListener('click', async (e) => {
    if (!fn.root?.contains(e.target)) return;
    const pol = e.target.closest('[data-fn-pol]')?.dataset.fnPol;
    if (pol) {
      try {
        fn.st.policy = await window.hub.fans.policy(pol);
        fn.chosen = pol;
        A.toast(pol === 'active' ? 'Kühlung: aktiv (Lüfter zuerst).' : 'Kühlung: passiv (leiser).');
      } catch (err) { A.toast(A.errText(err), 'error'); }
      return fnPaint();
    }
    if (e.target.closest('[data-fc-start]')) {
      fn.starting = true; fn.err = ''; fnPaint();
      try {
        fn.snap = await window.hub.fanctl.start();
        fn.cfg = { controls: { ...(fn.snap?.config?.controls || {}) } };
        fn.cfgLoaded = true;
        fn.ctl = await window.hub.fanctl.status();
      } catch (err) { fn.err = A.errText(err); }
      fn.starting = false;
      return fnPaint();
    }
    if (e.target.closest('[data-fc-driver]')) {
      fn.starting = true; fn.err = ''; fnPaint();
      try {
        const r = await window.hub.fanctl.installDriver();
        if (!r?.ok) fn.err = 'Der Treiber wurde nicht installiert.';
        fn.ctl = await window.hub.fanctl.status();
      } catch (err) { fn.err = A.errText(err); }
      fn.starting = false;
      return fnPaint();
    }
    if (e.target.closest('[data-fc-stop]')) {
      await window.hub.fanctl.stop().catch(() => {});
      fn.snap = null; fn.cfgLoaded = false;
      A.toast('Lüfter laufen wieder automatisch (BIOS).');
      return fnPaint();
    }
    const mode = e.target.closest('[data-fc-mode]')?.dataset.fcMode;
    if (mode) {
      const id = e.target.closest('[data-fc-port]').dataset.fcPort;
      const c = portCfg(id);
      c.mode = mode;
      if (mode === 'fixed' && c.value == null) c.value = Math.round(fnPorts().find((p) => p.id === id)?.pct ?? 50);
      if (mode === 'curve') { c.points ||= DEF_CURVE.map((p) => [...p]); c.sensor ||= (fnTemps().find((t) => /Tctl|Package|CPU/i.test(t.name) && /cpu/i.test(t.id)) || fnTemps()[0])?.id; }
      fnPaint();
      return fnSave();
    }
  });
  document.addEventListener('input', (e) => {
    if (!fn.root?.contains(e.target) || !e.target.matches('[data-fc-value]')) return;
    const id = e.target.closest('[data-fc-port]').dataset.fcPort;
    portCfg(id).value = Number(e.target.value);
    e.target.nextElementSibling.textContent = `${e.target.value} %`;
    fnSave();
  });
  document.addEventListener('change', (e) => {
    if (!fn.root?.contains(e.target) || !e.target.matches('[data-fc-sensor]')) return;
    portCfg(e.target.closest('[data-fc-port]').dataset.fcPort).sensor = e.target.value;
    fnSave();
  });
  // Kurvenpunkte ziehen
  document.addEventListener('pointerdown', (e) => {
    const pt = e.target.closest?.('[data-fc-pt]');
    if (!pt || !fn.root?.contains(pt)) return;
    const svg = pt.closest('[data-fc-curve]');
    fn.curveDrag = { id: svg.dataset.fcCurve, i: Number(pt.dataset.fcPt), svg };
    e.preventDefault();
  });
  window.addEventListener('pointermove', (e) => {
    const d = fn.curveDrag;
    if (!d) return;
    const r = d.svg.getBoundingClientRect();
    const t = Math.round(20 + ((e.clientX - r.left) / r.width) * 80);
    const p = Math.round(100 - ((e.clientY - r.top) / r.height) * 100);
    const pts = portCfg(d.id).points;
    const lo = d.i > 0 ? pts[d.i - 1][0] + 1 : 20, hi = d.i < pts.length - 1 ? pts[d.i + 1][0] - 1 : 100;
    pts[d.i] = [Math.max(lo, Math.min(hi, t)), Math.max(0, Math.min(100, p))];
    const temp = fnTemps().find((x) => x.id === portCfg(d.id).sensor)?.value;
    d.svg.outerHTML = curveSvg(d.id, pts, temp);
    d.svg = fn.root.querySelector(`[data-fc-curve="${CSS.escape(d.id)}"]`);
  });
  window.addEventListener('pointerup', () => {
    if (!fn.curveDrag) return;
    fn.curveDrag = null;
    fnSave();
  });
  A.define('tool-fans', { nav: 'Lüfter', title: 'Lüfter', sub: 'Alle Lüfter steuern – wie Fan Control', icon: 'refresh', tint: 'linear-gradient(135deg,#67e8f9,#0e7490)', desc: 'Alle Lüfter mit Drehzahl, jeden Anschluss einzeln steuern: Automatik, fester Wert oder Kurve nach Temperatur – direkt im Hub, ohne Fan Control.' }, {
    mount(root) {
      fn.root = root;
      fnPaint();
      fnLoad();
      clearInterval(fn.timer);
      fn.timer = setInterval(fnLoad, 2000);
    },
    unmount() {
      clearInterval(fn.timer);
      fn.root = null;
    },
  });
})();
