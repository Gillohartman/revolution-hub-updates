'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.45.15',
  title: 'Revulution Hub 2.45.15',
  sub: 'Die Dynamic Island klappt sich für Kopfhörer auf – mit drehenden 3D-AirPods Pro, AirPods Max und dem Akku im Kreis.',
  items: [
    {
      open: 'orbit',
      icon: 'island',
      title: 'Dynamic Island weitet sich',
      text: 'Beim Verbinden von Kopfhörern startet die geschlossene Island und klappt sich direkt auf – kein separates Fenster mehr.',
    },
    {
      open: 'orbit',
      icon: 'airpods',
      title: 'AirPods Pro in 3D',
      text: 'AirPods und AirPods Pro drehen sich links in der Island. Rechts steht der Akku im Kreis, darunter links, rechts und Etui.',
    },
    {
      open: 'orbit',
      icon: 'headphones',
      title: 'AirPods Max & Over-Ear',
      text: 'Andere Kopfhörer zeigen das AirPods-Max-Modell mit Netz-Bügel, ovalen Muscheln und Digital Crown – mit Geräteakku im Ring.',
    },
  ],
};
