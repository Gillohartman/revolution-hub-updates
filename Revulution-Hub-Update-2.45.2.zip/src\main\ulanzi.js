'use strict';
/**
 * Ulanzi Stream Controller D200 direkt im Hub (2.45.2) – ohne Ulanzi Studio.
 *
 * Protokoll (nachgebaut nach strmdck von redphx, MIT-Lizenz):
 *   HID-Schnittstelle MI_00 (VID 2207, PID 0019), Berichte 1025 Byte = Report-ID 0 + 1024 Byte Paket.
 *   Paket: 7C 7C | Befehl (2 Byte, big endian) | Länge (4 Byte, little endian) | Daten (auf 1016 Byte aufgefüllt)
 *   Grosse Daten (ZIP mit Tastenbildern): erstes Paket mit Kopf + 1016 Byte, danach rohe 1024-Byte-Stücke ohne Kopf.
 *   Befehle: 0x0001 Tasten setzen (ZIP), 0x0006 kleines Fenster (Uhr, hält die Verbindung wach),
 *            0x000A Helligkeit, 0x000B Beschriftungsstil; Eingang 0x0101 Taste, 0x0303 Geräteinfo.
 *   Gerätefehler: Bytes an den Stellen 1016 + k·1024 der ZIP dürfen nicht 0x00 oder 0x7C sein –
 *   sonst wird eine Füll-Datei ergänzt und neu gepackt.
 * Die USB-Verbindung läuft in einem kleinen C#-Helfer (PowerShell), wie die Tastatur-Engine.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const { spawn } = require('child_process');

const CS = String.raw`
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class RevUlanzi {
  [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
  [DllImport("setupapi.dll", CharSet = CharSet.Auto)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int f);
  [DllImport("setupapi.dll", CharSet = CharSet.Auto)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr s, IntPtr d, ref Guid g, int i, ref DID did);
  [DllImport("setupapi.dll", CharSet = CharSet.Auto)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr s, ref DID did, IntPtr det, int size, out int req, IntPtr dd);
  [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr s);
  [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern SafeFileHandle CreateFile(string n, uint a, uint s, IntPtr sa, uint c, uint f, IntPtr t);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool ReadFile(SafeFileHandle h, byte[] b, int n, out int r, IntPtr o);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool WriteFile(SafeFileHandle h, byte[] b, int n, out int w, IntPtr o);
  [StructLayout(LayoutKind.Sequential)] struct DID { public int cbSize; public Guid g; public int f; public IntPtr r; }

  static SafeFileHandle rh, wh;
  static readonly object wlock = new object();
  static volatile bool quit;

  static void Out(string s) { lock (Console.Out) { Console.Out.WriteLine(s); Console.Out.Flush(); } }

  static string FindPath() {
    Guid g; HidD_GetHidGuid(out g);
    IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);
    try {
      for (int i = 0; ; i++) {
        var did = new DID(); did.cbSize = Marshal.SizeOf(did);
        if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref did)) return null;
        int req; SetupDiGetDeviceInterfaceDetail(set, ref did, IntPtr.Zero, 0, out req, IntPtr.Zero);
        IntPtr det = Marshal.AllocHGlobal(req); Marshal.WriteInt32(det, IntPtr.Size == 8 ? 8 : 6);
        SetupDiGetDeviceInterfaceDetail(set, ref did, det, req, out req, IntPtr.Zero);
        string p = Marshal.PtrToStringAuto(new IntPtr(det.ToInt64() + 4)); Marshal.FreeHGlobal(det);
        string l = p.ToLowerInvariant();
        if (l.Contains("vid_2207&pid_0019") && l.Contains("mi_00")) return p;
      }
    } finally { SetupDiDestroyDeviceInfoList(set); }
  }

  static bool WriteReport(byte[] pkt1024) {
    var b = new byte[1025];
    Buffer.BlockCopy(pkt1024, 0, b, 1, Math.Min(1024, pkt1024.Length));
    int w;
    var h = wh;
    return h != null && !h.IsInvalid && WriteFile(h, b, b.Length, out w, IntPtr.Zero);
  }

  static byte[] Header(int cmd, int len, byte[] data, int off, int count) {
    var p = new byte[1024];
    p[0] = 0x7C; p[1] = 0x7C; p[2] = (byte)(cmd >> 8); p[3] = (byte)cmd;
    p[4] = (byte)len; p[5] = (byte)(len >> 8); p[6] = (byte)(len >> 16); p[7] = (byte)(len >> 24);
    Buffer.BlockCopy(data, off, p, 8, Math.Min(count, 1016));
    return p;
  }

  static bool Send(int cmd, byte[] data) {
    lock (wlock) {
      if (!WriteReport(Header(cmd, data.Length, data, 0, Math.Min(1016, data.Length)))) return false;
      for (int i = 1016; i < data.Length; i += 1024) {
        var p = new byte[1024];
        Buffer.BlockCopy(data, i, p, 0, Math.Min(1024, data.Length - i));
        if (!WriteReport(p)) return false;
      }
      return true;
    }
  }

  static void Commands() {
    string line;
    while (!quit && (line = Console.In.ReadLine()) != null) {
      try {
        if (line == "QUIT") { quit = true; break; }
        // FILE <cmd> <pfad>   |   RAW <cmd> <text>
        int a = line.IndexOf(' '), b = a < 0 ? -1 : line.IndexOf(' ', a + 1);
        if (a < 0 || b < 0) continue;
        string kind = line.Substring(0, a);
        int cmd = Convert.ToInt32(line.Substring(a + 1, b - a - 1));
        string rest = line.Substring(b + 1);
        byte[] data = kind == "FILE" ? File.ReadAllBytes(rest) : Encoding.UTF8.GetBytes(rest);
        bool ok = Send(cmd, data);
        Out((ok ? "sent " : "err senden ") + cmd + " " + data.Length);
      } catch (Exception e) { Out("err " + e.Message.Replace('\n', ' ')); }
    }
    quit = true;
  }

  public static void Run() {
    new Thread(Commands) { IsBackground = true }.Start();
    bool announcedMissing = false;
    while (!quit) {
      string p = FindPath();
      if (p == null) {
        if (!announcedMissing) { Out("nodev"); announcedMissing = true; }
        Thread.Sleep(2000); continue;
      }
      announcedMissing = false;
      rh = CreateFile(p, 0x80000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
      wh = CreateFile(p, 0x40000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
      if (rh.IsInvalid || wh.IsInvalid) { Out("err open " + Marshal.GetLastWin32Error()); Thread.Sleep(3000); continue; }
      Out("ready");
      var buf = new byte[1025];
      while (!quit) {
        int r;
        if (!ReadFile(rh, buf, buf.Length, out r, IntPtr.Zero) || r < 13) { break; }
        int cmd = (buf[1] == 0x7C && buf[2] == 0x7C) ? (buf[3] << 8) | buf[4] : -1;
        if (cmd == 0x0101) Out("btn " + buf[10] + " " + (buf[12] == 1 ? 1 : 0) + " " + buf[9]);
        else if (cmd != 0x0303) Out("pkt " + BitConverter.ToString(buf, 0, Math.Min(r, 24)));
        else {
          int len = buf[5] | (buf[6] << 8);
          int end = 9; while (end < r && end < 9 + Math.Min(len, 1000) && buf[end] != 0) end++;
          Out("info " + Encoding.ASCII.GetString(buf, 9, end - 9).Replace('\n', ' '));
        }
      }
      lock (wlock) { try { rh.Dispose(); wh.Dispose(); } catch { } wh = null; }
      if (!quit) { Out("lost"); Thread.Sleep(1000); }
    }
  }
}
`;

/* ---------------------------------------------------------------- ZIP (Deflate, wie die Ulanzi-Software) */
const CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
const crc32 = (buf) => {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
function zip(entries) {
  const local = [];
  const central = [];
  let offset = 0;
  for (const { name, data } of entries) {
    const nameBuf = Buffer.from(name, 'utf8');
    const deflated = zlib.deflateRawSync(data, { level: 1 });
    const crc = crc32(data);
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0, 6); h.writeUInt16LE(8, 8);
    h.writeUInt16LE(0, 10); h.writeUInt16LE(0x21, 12); h.writeUInt32LE(crc, 14);
    h.writeUInt32LE(deflated.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nameBuf.length, 26); h.writeUInt16LE(0, 28);
    local.push(h, nameBuf, deflated);
    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0, 8); c.writeUInt16LE(8, 10);
    c.writeUInt16LE(0, 12); c.writeUInt16LE(0x21, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(deflated.length, 20); c.writeUInt32LE(data.length, 24);
    c.writeUInt16LE(nameBuf.length, 28); c.writeUInt32LE(offset, 42);
    central.push(c, nameBuf);
    offset += 30 + nameBuf.length + deflated.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, cd, end]);
}
// Gerätefehler umgehen: an 1016 + k·1024 kein 0x00 / 0x7C
const zipOk = (buf) => {
  for (let i = 1016; i < buf.length; i += 1024) if (buf[i] === 0x00 || buf[i] === 0x7c) return false;
  return true;
};
/* 2.45.5: ZIP, das den Gerätefehler sicher umgeht – auch bei mehreren MB (Live-GIFs).
   Vor jeder Datei (und jedem Verzeichniseintrag) wird ein „Extra-Feld“ passender Länge eingefügt, sodass
   an keiner Prüfstelle 1016 + k·1024 ein 0x00 oder 0x7C landet. Die alte Methode (Zufalls-Fülldatei vorne)
   fand bei grossen Paketen praktisch nie eine passende Variante. */
function deckZip(files) {
  const bad = (b) => b === 0x00 || b === 0x7c;
  const fits = (buf, start) => {
    let p = 1016 + Math.max(0, Math.ceil((start - 1016) / 1024)) * 1024;
    for (; p < start + buf.length; p += 1024) if (bad(buf[p - start])) return false;
    return true;
  };
  const extra = (n) => {
    if (!n) return Buffer.alloc(0);
    const e = Buffer.alloc(n, 0x20); // Füllbytes = Leerzeichen
    e.writeUInt16LE(0x5052, 0); e.writeUInt16LE(n - 4, 2);
    return e;
  };
  const pads = [0]; for (let n = 4; n < 6000; n++) pads.push(n);
  // Prüft buf ab Position start und – direkt dahinter – die festen Bytes des nächsten Kopfes (next),
  // ohne dessen Felder, die erst später gewählt werden (skip = Indizes im next-Puffer).
  const fitsWith = (buf, start, next, skip) => {
    if (!fits(buf, start)) return false;
    if (!next) return true;
    const ns = start + buf.length;
    let p = 1016 + Math.max(0, Math.ceil((ns - 1016) / 1024)) * 1024;
    for (; p < ns + next.length; p += 1024) { const k = p - ns; if (!skip.includes(k) && bad(next[k])) return false; }
    return true;
  };
  const prep = files.map(({ name, data }) => ({ nameBuf: Buffer.from(name, 'utf8'), deflated: zlib.deflateRawSync(data, { level: 1 }), crc: crc32(data), size: data.length }));
  const localHead = (m, pad) => {
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0, 6); h.writeUInt16LE(8, 8);
    h.writeUInt16LE(0, 10); h.writeUInt16LE(0x21, 12); h.writeUInt32LE(m.crc, 14);
    h.writeUInt32LE(m.deflated.length, 18); h.writeUInt32LE(m.size, 22); h.writeUInt16LE(m.nameBuf.length, 26); h.writeUInt16LE(pad, 28);
    return Buffer.concat([h, m.nameBuf]);
  };
  const centralHead = (m, pad, offset) => {
    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0, 8); c.writeUInt16LE(8, 10);
    c.writeUInt16LE(0, 12); c.writeUInt16LE(0x21, 14); c.writeUInt32LE(m.crc, 16); c.writeUInt32LE(m.deflated.length, 20); c.writeUInt32LE(m.size, 24);
    c.writeUInt16LE(m.nameBuf.length, 28); c.writeUInt16LE(pad, 30); c.writeUInt32LE(offset, 42);
    return Buffer.concat([c, m.nameBuf]);
  };
  const local = [];
  let off = 0;
  for (let i = 0; i < prep.length; i++) {
    const m = prep[i];
    // nächster Kopf: lokaler Kopf der nächsten Datei (ohne Extra-Länge 28–29) bzw. erster Verzeichniseintrag
    // (ohne Extra-Länge 30–31 und Offset 42–45, der vom ersten Eintrag ist aber schon bekannt: 0)
    const next = i + 1 < prep.length ? localHead(prep[i + 1], 0) : centralHead(prep[0], 0, 0);
    const skip = i + 1 < prep.length ? [28, 29] : [30, 31];
    let chosen = null;
    for (const pad of pads) {
      const buf = Buffer.concat([localHead(m, pad), extra(pad), m.deflated]);
      if (fitsWith(buf, off, next, skip)) { chosen = buf; break; }
    }
    if (!chosen) throw new Error('Tastenbilder konnten nicht verpackt werden.');
    m.offset = off;
    local.push(chosen);
    off += chosen.length;
  }
  const cdStart = off;
  const central = [];
  for (let i = 0; i < prep.length; i++) {
    const m = prep[i];
    const last = i === prep.length - 1;
    const next = last ? null : centralHead(prep[i + 1], 0, prep[i + 1].offset);
    let chosen = null;
    for (const pad of pads) {
      let buf = Buffer.concat([centralHead(m, pad, m.offset), extra(pad)]);
      if (last) {
        // Ende-Datensatz gleich mitprüfen (er hängt direkt dahinter)
        const cdSize = off + buf.length - cdStart;
        const end = Buffer.alloc(22);
        end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(prep.length, 8); end.writeUInt16LE(prep.length, 10);
        end.writeUInt32LE(cdSize, 12); end.writeUInt32LE(cdStart, 16);
        buf = Buffer.concat([buf, end]);
      }
      if (fitsWith(buf, off, next, [30, 31])) { chosen = buf; break; }
    }
    if (!chosen) throw new Error('Tastenbilder konnten nicht verpackt werden.');
    central.push(chosen);
    off += chosen.length;
  }
  const out = Buffer.concat([...local, ...central]);
  if (!zipOk(out)) throw new Error('Tastenbilder konnten nicht verpackt werden.');
  return out;
}

/* ---------------------------------------------------------------- Gerät */
const COLS = 5;
const KEYS = 13;

class UlanziDeck {
  constructor({ dir, onButton, onChange }) {
    this.dir = dir;
    this.onButton = onButton;
    this.onChange = onChange;
    this.child = null;
    this.connected = false;
    this.info = '';
    this.error = '';
    this.lastSent = '';
    this.keepAlive = null;
    this.brightness = null;
  }

  status() {
    return { running: Boolean(this.child), connected: this.connected, info: this.info, error: this.error, keys: KEYS, cols: COLS, lastSent: this.lastSent };
  }

  start() {
    if (this.child) return this.status();
    const file = path.join(this.dir, 'ulanzi-helper.ps1');
    fs.mkdirSync(this.dir, { recursive: true });
    fs.writeFileSync(file, `﻿$ErrorActionPreference='Stop'\r\nAdd-Type -TypeDefinition @'\r\n${CS}\r\n'@\r\n[RevUlanzi]::Run()\r\n`, 'utf8');
    this.error = '';
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    this.child = child;
    let err = '';
    let rest = '';
    child.stdout.on('data', (buf) => {
      rest += String(buf);
      const lines = rest.split(/\r?\n/);
      rest = lines.pop();
      for (const line of lines) this.line(line.trim());
    });
    child.stderr.on('data', (d) => (err += d));
    child.on('exit', () => {
      if (this.child !== child) return;
      this.child = null;
      this.setConnected(false);
      if (err.trim()) this.error = err.trim().split(/\r?\n/)[0].slice(0, 200);
      this.onChange?.(this.status());
    });
    child.stdin.on('error', () => {});
    this.onChange?.(this.status());
    return this.status();
  }

  line(line) {
    if (!line) return;
    if (line.startsWith('btn ')) {
      const [, index, pressed, state] = line.split(' ').map(Number);
      if (Number.isFinite(index)) this.onButton?.({ index, pressed: pressed === 1, state });
      return;
    }
    if (line === 'ready') return this.setConnected(true);
    if (line === 'nodev' || line === 'lost') return this.setConnected(false);
    if (line.startsWith('info ')) this.info = line.slice(5).slice(0, 200);
    else if (line.startsWith('err ')) this.error = line.slice(4).slice(0, 200);
    else return;
    this.onChange?.(this.status());
  }

  setConnected(on) {
    if (this.connected === on) return;
    this.connected = on;
    clearInterval(this.keepAlive);
    this.keepAlive = null;
    if (on) {
      this.error = '';
      // Uhr im kleinen Fenster – hält die Verbindung wach (sonst fällt das Deck in seinen eigenen Modus zurück)
      // kleines Display: 1 = Uhr, 0 = PC-Werte (CPU/RAM), 2 = Hintergrund (aus)
      const tick = () => {
        const d = new Date();
        const t = [d.getHours(), d.getMinutes(), d.getSeconds()].map((x) => String(x).padStart(2, '0')).join(':');
        const mode = this.smallMode === 'stats' ? 0 : this.smallMode === 'off' ? 2 : 1;
        const s = mode === 0 && this.statsFn ? this.statsFn() : { cpu: 0, mem: 0, gpu: 0 };
        this.raw(0x0006, `${mode}|${s.cpu}|${s.mem}|${t}|${s.gpu}`);
      };
      tick();
      this.keepAlive = setInterval(tick, 5000);
      // Beschriftung steckt schon im Bild – Geräte-Titel ausblenden
      this.raw(0x000b, JSON.stringify({ Align: 'bottom', Color: 0xffffff, FontName: 'Roboto', ShowTitle: false, Size: 10, Weight: 80 }));
      if (this.brightness != null) this.raw(0x000a, String(this.brightness));
    }
    this.onChange?.(this.status());
  }

  raw(cmd, text) {
    if (!this.child || !this.connected) return false;
    this.child.stdin.write(`RAW ${cmd} ${String(text).replace(/[\r\n]/g, ' ')}\n`);
    return true;
  }

  setBrightness(value) {
    this.brightness = Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
    this.raw(0x000a, String(this.brightness));
    return this.status();
  }

  /** buttons: [{ index, png: Buffer|null }] – Bilder 196×196 PNG, Beschriftung ist im Bild.
      partial: nur die übergebenen Tasten ändern (Befehl 0x000D), z. B. für die animierte Claude-Taste. */
  setButtons(buttons, { partial = false } = {}) {
    if (!this.child || !this.connected) throw new Error('Das Ulanzi-Deck ist nicht verbunden.');
    const manifest = {};
    const files = [];
    const indexes = partial ? buttons.map((b) => b.index) : [...Array(KEYS).keys()];
    for (const i of indexes) {
      const b = buttons.find((x) => x.index === i);
      const view = {};
      // animierte Tasten (Live-Hintergrund) als GIF, sonst PNG
      const pic = b?.gif?.length ? { ext: 'gif', data: b.gif } : b?.png?.length ? { ext: 'png', data: b.png } : null;
      if (pic) {
        view.Icon = `icons/${i}.${pic.ext}`;
        files.push({ name: `icons/${i}.${pic.ext}`, data: pic.data });
      }
      manifest[`${i % COLS}_${Math.floor(i / COLS)}`] = { State: 0, ViewParam: [view] };
    }
    const sorted = Object.fromEntries(Object.keys(manifest).sort().map((k) => [k, manifest[k]]));
    const data = deckZip([{ name: 'manifest.json', data: Buffer.from(JSON.stringify(sorted, null, 2)) }, ...files]);
    const file = path.join(this.dir, 'ulanzi-page.zip');
    fs.writeFileSync(file, data);
    this.child.stdin.write(`FILE ${partial ? 13 : 1} ${file}\n`);
    this.lastSent = new Date().toISOString();
    return { ok: true, bytes: data.length };
  }

  stop() {
    const c = this.child;
    this.child = null;
    this.setConnected(false);
    if (c) {
      try { c.stdin.write('QUIT\n'); } catch { /* egal */ }
      setTimeout(() => { try { c.kill(); } catch { /* egal */ } }, 500);
    }
    this.onChange?.(this.status());
    return this.status();
  }
}

module.exports = { UlanziDeck, deckZip, zipOk, _zip: zip, tmp: os.tmpdir };
