'use strict';

/*
 * 2.45 Geräte-Apps (Kategorie Gaming, neben „Geräte & RGB“):
 *  (2.45.2: Maus-Studio und AJAZZ-Studio entfernt – Tastatur/Maus/RGB bleiben in „Geräte & RGB“.)
 *
 *  - Stream-Deck-Studio: Tasten-Raster mit Aktionen (Spotify/Medien, Screenshot, Soundboard, Apps, Webseiten,
 *    Crosshair, Ketten) – per Klick oder per Hardware-Taste (z. B. F13–F24 vom Deck) auslösbar.
 *  - Lüfter: Windows-Kühlrichtlinie, GPU-Lüfter/Temperatur, Mainboard-Sensoren (falls verfügbar).
 * Belegungen landen in denselben Regeln wie die Tastatur-App (eine Engine für alles).
 */
(() => {
  const A = window.RevApp;
  const ME = window.RevMacroEditor;
  if (!A) return;
  const { esc } = A;
  const ctx = () => window.HubTools.ctx();

  /* ---------------------------------------------------------------- gemeinsame Regel-Helfer */
  const kbCfg = () => {
    const s = ctx().state()?.settings?.keyboard || {};
    const c = { enabled: s.enabled === true, profiles: Array.isArray(s.profiles) && s.profiles.length ? JSON.parse(JSON.stringify(s.profiles)) : [{ id: 'global', name: 'Überall', apps: [], on: true, rules: [] }] };
    if (!c.profiles.some((p) => !p.apps?.length)) c.profiles.unshift({ id: 'global', name: 'Überall', apps: [], on: true, rules: [] });
    return c;
  };
  const globalProfile = (c) => c.profiles.find((p) => !p.apps?.length);
  async function kbSave(c, enable = true) {
    if (enable) c.enabled = true;
    await window.hub.setSettings({ keyboard: c });
    const st = await window.hub.keyboard.apply();
    window.__kbReset?.();
    return st;
  }
  function setRule(c, from, rule) {
    const p = globalProfile(c);
    p.rules = p.rules.filter((r) => r.from !== from);
    if (rule) p.rules.push({ from, on: true, ...rule });
  }
  /* ================================================================ Deck Studio (2.45.4)
     Stream Deck / Ulanzi D200: Tasten als echte Bilder (eigenes Bild je Taste oder ein Hintergrundbild über
     alle Tasten), Rechtsklick-Menü, installierte Programme, Tastenkombinationen, Lautstärke, Seiten, Uhren,
     Claude-Status (animiert, Ton + Aufleuchten wenn fertig, rot bei Limit). Das Studio zeigt dieselben Bilder
     wie das Deck. Der Hub läuft bei geschlossenem Fenster weiter, damit das Deck funktioniert. */
  const DECK_ACTIONS = [
    ['none', 'Keine Aktion'], ['media', 'Spotify / Medien'], ['volume', 'Lautstärke'], ['program', 'Programm öffnen'], ['app', 'Hub-App öffnen'], ['open', 'Webseite / Datei öffnen'],
    ['keys', 'Tastenkombination'], ['screenshot', 'Screenshot'], ['record', 'Aufnahme an/aus'], ['widgets', 'Widgets an/aus'], ['agent', 'KI-Agent (Claude, ChatGPT, Freebuff)'], ['clock', 'Uhr'],
    ['sound', 'Soundboard-Sound'], ['page', 'Seite wechseln'], ['crosshair', 'Crosshair an/aus'], ['lock', 'PC sperren'], ['timer', 'Timer starten'], ['multi', 'Mehrere Aktionen (Kette)'],
  ];
  const CLOCKS = [['digital', 'Digital'], ['analog', 'Analog'], ['sbb', 'Bahnhofsuhr'], ['date', 'Datum']];
  const ICONS = ['▶️', '⏯️', '⏭️', '⏮️', '🔇', '🔊', '🔉', '📸', '⏺️', '🎵', '🎧', '🎤', '🌐', '💬', '🎮', '🎯', '🔒', '⏱️', '🕒', '⭐', '🔥', '💡', '📁', '🖥️', '🎬', '🚀', '❤️', '😂', '👏', '🥁', '📣', '⚡', '🧠', '✳️', '🤖', '📝', '📅', '☕', '🏠', '🛒'];

  /* ---------------------------------------------------------------- Claude-Status */
  const cl = { status: null, flashUntil: 0, frame: 0 };
  const clText = (s) => (!s || s.off ? 'aus' : s.limit ? 'Limit erreicht' : s.question ? 'Frage' : s.working ? `arbeitet${s.agents ? ` · ${s.agents} Agent${s.agents > 1 ? 'en' : ''}` : ''}` : s.done ? 'fertig' : 'ruht');
  function clState() {
    const s = cl.status;
    if (!s || s.off) return 'off';
    if (s.limit) return 'limit';
    if (s.question) return 'question';
    if (Date.now() < cl.flashUntil) return 'flash';
    if (s.working) return 'working';
    if (s.done) return 'done';
    return 'idle';
  }
  // Ton, wenn Claude fertig ist (kein Fenster unten rechts)
  function chime() {
    try {
      const ac = new (window.AudioContext || window.webkitAudioContext)();
      const now = ac.currentTime;
      [[880, 0], [1318.5, 0.16], [1760, 0.32]].forEach(([f, t]) => {
        const o = ac.createOscillator(), g = ac.createGain();
        o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0, now + t);
        g.gain.linearRampToValueAtTime(0.22, now + t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, now + t + 0.55);
        o.connect(g).connect(ac.destination);
        o.start(now + t); o.stop(now + t + 0.6);
      });
      setTimeout(() => ac.close(), 1500);
    } catch { /* kein Ton möglich */ }
  }
  // Tasten, die sich bewegen: KI-Agenten, die gerade arbeiten (Ring dreht) und Claude, wenn es fertig wird (leuchtet auf)
  const agentState = (agent) => {
    if (agent === 'claude' || !agent) { const st = clState(); return st === 'flash' ? 'done' : st; }
    const o = cl.status?.others?.[agent];
    return !cl.status || cl.status.off ? 'off' : o?.status || 'off';
  };
  const claudeKeys = () => (dk.data ? Object.entries(dk.data.pages[ul.deckPage]?.buttons || {}).filter(([, b]) => {
    if (b?.action?.type !== 'agent') return false;
    const ag = b.action.agent || 'claude';
    return agentState(ag) === 'working' || (ag === 'claude' && clState() === 'flash');
  }).map(([i]) => Number(i)) : []);
  if (window.hub.claude) {
    const sigOf = (s) => `${clText(s)}|${s?.others?.codex?.status}|${s?.others?.freebuff?.status}|${Boolean(s?.others?.claudeLogo)}`;
    const onClaude = (s) => {
      const before = sigOf(cl.status);
      cl.status = s;
      if (sigOf(s) !== before) { ulPush(150); if (dk.root) dkPaint(); }
    };
    window.hub.claude.status().then(onClaude).catch(() => {});
    window.hub.claude.onStatus(onClaude);
    window.hub.claude.onDone(() => {
      cl.flashUntil = Date.now() + 6000; // Taste leuchtet 6 s orange auf
      chime();
      ulPush(0);
    });
  }
  // Animation der Claude-Taste (arbeitet: Claude-Symbole; fertig: orange aufleuchten)
  setInterval(() => {
    const keys = claudeKeys();
    if (!keys.length) return;
    cl.frame++;
    if (ul.status?.connected && !ul.busy) {
      ul.busy = true;
      window.hub.ulanzi.push(keys.map((i) => ({ index: i, png: keyImage(dk.data.pages[ul.deckPage].buttons[i], i) })), { partial: true }).catch(() => {}).finally(() => { ul.busy = false; });
    }
    if (dk.root && dk.page === ul.deckPage) for (const i of keys) { const im = dk.root.querySelector(`[data-dk-key="${i}"] img`); if (im) im.src = keyImage(page().buttons[i], i); }
  }, 450);
  const ago = (t) => {
    const m = Math.round((Date.now() - t) / 60000);
    return m < 1 ? 'gerade eben' : m < 60 ? `vor ${m} min` : `vor ${Math.round(m / 60)} h`;
  };
  function claudeCard() {
    const s = cl.status;
    const on = ctx().state()?.settings?.claudeLink === true;
    const chip = (st) => `<span class="cl-chip ${st}">${st === 'working' ? '● arbeitet' : st === 'done' ? '✓ fertig' : st === 'question' ? '? Frage' : st === 'limit' ? '⛔ Limit' : '○ ruht'}</span>`;
    return `<div class="rv-card cl-card"><div class="rv-row between"><div><b>✳️ Claude</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Zeigt, ob Claude arbeitet oder fertig ist – mit allen aktiven Agenten. Eine Taste „KI-Agent“ zeigt das App-Logo mit drehendem Ring, solange gearbeitet wird, leuchtet orange auf und spielt einen Ton, wenn Claude fertig ist, und wird rot beim Limit. Drücken öffnet die App – bei Claude direkt den passenden Chat. Liest nur lokal deine Claude-Verläufe.</p></div>
      <label class="rv-row" style="gap:8px;white-space:nowrap"><input type="checkbox" data-cl-on ${on ? 'checked' : ''}/> Mit Claude verbinden</label></div>
      ${on ? (s?.sessions?.length ? `<div class="cl-list">${s.sessions.slice(0, 6).map((x) => `<div class="cl-row"><span class="cl-proj">${esc(x.project)}</span>${chip(x.status)}<small>${ago(x.at)}</small>${x.agents.length ? `<div class="cl-agents">${x.agents.slice(0, 6).map((a) => `<span class="cl-agent ${a.status}" title="Agent ${esc(a.id)}">🤖 ${a.status === 'working' ? 'arbeitet' : 'fertig'}</span>`).join('')}</div>` : ''}</div>`).join('')}</div>` : '<p class="rv-muted" style="margin:10px 0 0">Keine Claude-Sitzung in den letzten 3 Stunden.</p>') : ''}
    </div>`;
  }

  /* ---------------------------------------------------------------- Daten */
  const dk = { root: null, data: null, page: 0, sel: null, capture: false, loaded: false, clip: null, apps: null };
  const blankDeck = () => ({ cols: 5, rows: 3, pages: [{ name: 'Seite 1', buttons: {} }] });
  async function dkLoad() {
    if (dk.loaded) return;
    dk.loaded = true;
    dk.data = (await A.store.get('streamdeck', null)) || blankDeck();
    if (!dk.data.pages?.length) dk.data = blankDeck();
    // 2.45.6: alte „Claude-Status“-Tasten (wechselnde Symbole) → KI-Agent Claude (Logo mit Ring); Live-Hintergrund → Standbild
    let migrated = false;
    for (const p of dk.data.pages) {
      for (const btn of Object.values(p.buttons || {})) {
        if (btn?.action?.type === 'claude') { btn.action = { type: 'agent', agent: 'claude' }; migrated = true; }
        for (const st of btn?.action?.steps || []) if (st.type === 'claude') { st.type = 'none'; migrated = true; }
      }
    }
    if (dk.data.bg?.kind === 'live') { dk.data.bg = { ...dk.data.bg, kind: 'image', from: dk.data.bg.id }; delete dk.data.bg.id; migrated = true; }
    if (migrated) A.store.set('streamdeck', dk.data);
    const b = dk.data.pages[0].buttons;
    if (!Object.keys(b).length) {
      Object.assign(b, {
        0: { id: 'd1', icon: '⏯️', label: 'Play/Pause', color: '#1db954', action: { type: 'media', key: 'playpause' } },
        1: { id: 'd2', icon: '⏭️', label: 'Weiter', color: '#1db954', action: { type: 'media', key: 'next' } },
        2: { id: 'd3', icon: '📸', label: 'Screenshot', color: '#0a84ff', action: { type: 'screenshot' } },
        3: { id: 'd4', icon: '🔊', label: 'Sound 1', color: '#ff9f0a', action: { type: 'sound', pad: 0 } },
        4: { id: 'd5', icon: '🎯', label: 'Crosshair', color: '#ff375f', action: { type: 'crosshair' } },
      });
    }
  }
  const dkSave = () => {
    ulPush();
    return A.store.set('streamdeck', dk.data);
  };
  const page = () => dk.data.pages[dk.page];
  const selBtn = () => (dk.sel != null ? page().buttons[dk.sel] : null);
  const newId = () => Math.random().toString(36).slice(2, 8);

  /* ---------------------------------------------------------------- Tastenbilder */
  const S = 196;
  const imgCache = new Map();
  let repaintT = 0;
  function img(src) {
    if (!src) return null;
    let e = imgCache.get(src);
    if (!e) {
      e = { el: new Image(), ok: false };
      e.el.onload = () => { e.ok = true; clearTimeout(repaintT); repaintT = setTimeout(() => { if (dk.root) dkPaint(); ulPush(100); }, 60); };
      e.el.src = src;
      imgCache.set(src, e);
    }
    return e.ok ? e.el : null;
  }
  const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect(x, y, w, h, r); };
  function drawCover(g, im, x, y, w, h) {
    const k = Math.max(w / im.width, h / im.height);
    const dw = im.width * k, dh = im.height * k;
    g.drawImage(im, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  }
  // Ausschnitt des Deck-Hintergrunds für Taste i (Raster 5 × 3, ein Bild über alle Tasten)
  function drawDeckBg(g, i) {
    const bg = dk.data?.bg;
    const im = img(bg?.src);
    if (!im) return false;
    const cols = 5, rows = 3, W = cols * S, H = rows * S;
    const z = Math.max(1, Number(bg.zoom) || 1);
    const k = Math.max(W / im.width, H / im.height) * z;
    const dw = im.width * k, dh = im.height * k;
    const ox = (W - dw) / 2 + (Number(bg.x) || 0) * ((dw - W) / 2);
    const oy = (H - dh) / 2 + (Number(bg.y) || 0) * ((dh - H) / 2);
    const col = i % cols, row = Math.floor(i / cols);
    g.drawImage(im, ox - col * S, oy - row * S, dw, dh);
    if (bg.dim) { g.fillStyle = `rgba(0,0,0,${Math.min(0.8, Number(bg.dim))})`; g.fillRect(0, 0, S, S); }
    return true;
  }
  function drawClock(g, style) {
    const d = new Date();
    const hh = d.getHours(), mm = d.getMinutes();
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
    if (style === 'digital' || style === 'date') {
      g.font = '800 64px "Segoe UI", system-ui, sans-serif';
      g.fillText(`${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`, S / 2, style === 'date' ? 74 : S / 2 - 6);
      g.font = '600 24px "Segoe UI", system-ui, sans-serif';
      g.fillStyle = 'rgba(255,255,255,.8)';
      g.fillText(style === 'date' ? d.toLocaleDateString('de-CH', { weekday: 'short', day: 'numeric', month: 'short' }) : d.toLocaleDateString('de-CH', { weekday: 'long' }), S / 2, style === 'date' ? 130 : 148);
      return;
    }
    const cx = S / 2, cy = S / 2, R = 76;
    g.fillStyle = style === 'sbb' ? '#fff' : 'rgba(255,255,255,.08)';
    g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
    g.strokeStyle = style === 'sbb' ? '#111' : 'rgba(255,255,255,.85)';
    for (let i = 0; i < 60; i++) {
      const a = (i / 60) * Math.PI * 2, big = i % 5 === 0;
      g.lineWidth = big ? 5 : 2;
      if (!big && style !== 'sbb') continue;
      g.beginPath(); g.moveTo(cx + Math.sin(a) * (R - (big ? 16 : 7)), cy - Math.cos(a) * (R - (big ? 16 : 7))); g.lineTo(cx + Math.sin(a) * (R - 3), cy - Math.cos(a) * (R - 3)); g.stroke();
    }
    const hand = (a, len, w, col) => { g.strokeStyle = col; g.lineWidth = w; g.lineCap = style === 'sbb' ? 'butt' : 'round'; g.beginPath(); g.moveTo(cx - Math.sin(a) * 12, cy + Math.cos(a) * 12); g.lineTo(cx + Math.sin(a) * len, cy - Math.cos(a) * len); g.stroke(); };
    const handCol = style === 'sbb' ? '#111' : '#fff';
    hand(((hh % 12) + mm / 60) / 12 * Math.PI * 2, R * 0.55, 9, handCol);
    hand(mm / 60 * Math.PI * 2, R * 0.82, 6, handCol);
    if (style === 'sbb') {
      const a = d.getSeconds() / 60 * Math.PI * 2;
      g.strokeStyle = '#e2001a'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - Math.sin(a) * 18, cy + Math.cos(a) * 18); g.lineTo(cx + Math.sin(a) * (R * 0.62), cy - Math.cos(a) * (R * 0.62)); g.stroke();
      g.fillStyle = '#e2001a'; g.beginPath(); g.arc(cx + Math.sin(a) * (R * 0.62), cy - Math.cos(a) * (R * 0.62), 8, 0, Math.PI * 2); g.fill();
    }
  }
  function keyImage(b, i) {
    const c = document.createElement('canvas');
    c.width = S; c.height = S;
    const g = c.getContext('2d');
    g.fillStyle = '#000';
    g.fillRect(0, 0, S, S);
    const hasBg = drawDeckBg(g, i);
    if (!b) return c.toDataURL('image/png');
    const type = b.action?.type;
    // KI-Agent: echtes App-Logo + Status (arbeitet / Frage / fertig / bereit / aus); Claude leuchtet orange auf, wenn fertig
    if (type === 'agent') {
      const ag = b.action.agent || 'claude';
      const st = agentState(ag);
      const flash = ag === 'claude' && clState() === 'flash';
      const col = flash ? (cl.frame % 2 ? '#ff8a3d' : '#d97757') : { working: '#1e293b', question: '#eab308', done: '#15803d', limit: '#dc2626', ready: '#27272f', idle: '#27272f', off: '#18181b' }[st] || '#27272f';
      rr(g, 6, 6, S - 12, S - 12, 34); g.fillStyle = col; g.fill();
      const logo = img(ag === 'claude' ? cl.status?.others?.claudeLogo : cl.status?.others?.[ag]?.logo);
      if (st === 'working') {
        const a = (cl.frame % 12) / 12 * Math.PI * 2;
        g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 7; g.beginPath(); g.arc(S / 2, 80, 58, 0, Math.PI * 2); g.stroke();
        g.strokeStyle = ag === 'claude' ? '#f4a284' : ag === 'codex' ? '#a7f3d0' : '#93c5fd'; g.lineCap = 'round';
        g.beginPath(); g.arc(S / 2, 80, 58, a, a + Math.PI * 0.7); g.stroke();
      }
      if (logo) { g.save(); g.globalAlpha = st === 'off' ? 0.45 : 1; g.beginPath(); g.arc(S / 2, 80, 46, 0, Math.PI * 2); g.clip(); drawCover(g, logo, S / 2 - 46, 34, 92, 92); g.restore(); }
      else { g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff'; g.font = '80px "Segoe UI Emoji", sans-serif'; g.fillText(ag === 'claude' ? '✳️' : ag === 'codex' ? '🤖' : '🦾', S / 2, 82); }
      g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillStyle = st === 'question' ? '#1c1400' : '#fff';
      g.font = '700 28px "Segoe UI", system-ui, sans-serif';
      g.fillText({ working: 'arbeitet', question: 'Frage', done: 'fertig', limit: 'Limit', ready: 'bereit', idle: 'bereit', off: 'aus' }[st] || st, S / 2, 162);
      return c.toDataURL('image/png');
    }
    const own = img(b.image);
    if (own) { g.save(); rr(g, 6, 6, S - 12, S - 12, 34); g.clip(); drawCover(g, own, 6, 6, S - 12, S - 12); g.restore(); }
    else if (!hasBg) {
      const grad = g.createLinearGradient(0, 0, 0, S);
      grad.addColorStop(0, b.color || '#2c2c34'); grad.addColorStop(1, '#0b0b10');
      rr(g, 6, 6, S - 12, S - 12, 34); g.fillStyle = grad; g.fill();
    }
    if (type === 'clock') { drawClock(g, b.action.style || 'digital'); return c.toDataURL('image/png'); }
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = hasBg || own ? 10 : 0;
    g.fillStyle = '#fff'; // Farb-Emojis übernehmen sonst die Deckkraft der letzten Füllfarbe (blass)
    if (!own || b.showIcon) { g.font = `${b.label ? 92 : 110}px "Segoe UI Emoji", "Apple Color Emoji", sans-serif`; g.fillText(b.icon || '⭐', S / 2, b.label ? 86 : S / 2 + 4); }
    if (b.label) {
      g.fillStyle = '#fff';
      let size = 30;
      g.font = `700 ${size}px "Segoe UI", system-ui, sans-serif`;
      while (size > 16 && g.measureText(b.label).width > S - 24) g.font = `700 ${(size -= 2)}px "Segoe UI", system-ui, sans-serif`;
      g.fillText(b.label, S / 2, own && !b.showIcon ? 166 : 160);
    }
    return c.toDataURL('image/png');
  }
  // Bild aus Datei: verkleinert als Data-URL (Taste 196², Hintergrund max. 1400 px)
  function pickImage(maxSide, square) {
    return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/*';
      inp.onchange = () => {
        const f = inp.files?.[0];
        if (!f) return resolve(null);
        const r = new FileReader();
        r.onload = () => {
          const im = new Image();
          im.onload = () => {
            const c = document.createElement('canvas');
            if (square) { c.width = c.height = maxSide; drawCover(c.getContext('2d'), im, 0, 0, maxSide, maxSide); }
            else { const k = Math.min(1, maxSide / Math.max(im.width, im.height)); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); }
            resolve(c.toDataURL('image/jpeg', 0.88));
          };
          im.onerror = () => resolve(null);
          im.src = r.result;
        };
        r.readAsDataURL(f);
      };
      inp.click();
    });
  }

  /* ---------------------------------------------------------------- Ulanzi D200 direkt */
  const UL_KEYS = 13;
  const ul = { status: null, timer: 0, deckPage: 0, busy: false };
  // 2.45.6: Hintergründe aus der Bibliothek sind ein Standbild (das Live-Abspielen auf dem Deck ruckelte)
  function ulPush(delay = 450) {
    if (!ul.status?.connected || !dk.data) return;
    clearTimeout(ul.timer);
    ul.timer = setTimeout(async () => {
      if (ul.busy) return ulPush(300);
      ul.busy = true;
      try {
        ul.deckPage = dk.page;
        const p = page();
        const keys = [];
        for (let i = 0; i < UL_KEYS; i++) keys.push({ index: i, png: keyImage(p.buttons[i], i) });
        await window.hub.ulanzi.push(keys);
      } catch (e) {
        A.toast(A.errText(e), 'error');
      } finally {
        ul.busy = false;
      }
    }, delay);
  }
  // Uhr-Tasten jede Minute (Bahnhofsuhr: alle 2 s für den Sekundenzeiger) neu zeichnen
  setInterval(() => {
    if (!dk.data) return;
    const p = dk.data.pages[ul.deckPage];
    const clocks = Object.entries(p?.buttons || {}).filter(([, b]) => b?.action?.type === 'clock');
    if (!clocks.length) return;
    const sbb = clocks.some(([, b]) => b.action.style === 'sbb');
    if (!sbb && new Date().getSeconds() > 2) return;
    if (ul.status?.connected && !ul.busy) {
      ul.busy = true;
      window.hub.ulanzi.push(clocks.map(([i, b]) => ({ index: Number(i), png: keyImage(b, Number(i)) })), { partial: true }).catch(() => {}).finally(() => { ul.busy = false; });
    }
    if (dk.root && dk.page === ul.deckPage) for (const [i, b] of clocks) { const im = dk.root.querySelector(`[data-dk-key="${i}"] img`); if (im) im.src = keyImage(b, Number(i)); }
  }, 2000);
  if (window.hub.ulanzi) {
    window.hub.ulanzi.status().then((s) => { ul.status = s; if (s.connected) dkLoad().then(() => ulPush(0)); if (dk.data) dkPaint(); }).catch(() => {});
    window.hub.ulanzi.onStatus((s) => {
      const was = ul.status?.connected;
      ul.status = s;
      applyDeckName();
      if (s.connected && !was) dkLoad().then(() => {
        ulPush(0);
        if (dk.data.ulanziBrightness != null) window.hub.ulanzi.brightness(dk.data.ulanziBrightness).catch(() => {});
        window.hub.ulanzi.small(dk.data.ulanziSmall || 'clock').catch(() => {});
      });
      dkPaint();
    });
    window.hub.ulanzi.onButton(async (b) => {
      if (!b?.pressed) return;
      await dkLoad();
      const btn = dk.data.pages[ul.deckPage]?.buttons[b.index];
      const el = dk.root?.querySelector(`[data-dk-key="${b.index}"]`);
      if (el && dk.page === ul.deckPage) { el.classList.remove('press'); void el.offsetWidth; el.classList.add('press'); }
      if (btn) runAction(btn.action);
    });
  }
  /* Name nach angeschlossenem Gerät */
  const dev = { elgato: false, ulanzi: false, checked: 0 };
  const deckName = () => (ul.status?.connected || dev.ulanzi ? 'Ulanzi D200' : dev.elgato ? 'Stream Deck' : 'Deck Studio');
  function applyDeckName() {
    const meta = window.HubTools.TOOLS?.['tool-streamdeck'];
    if (meta) meta.title = deckName();
    if (ctx().state()?.active === 'tool-streamdeck') {
      const t = document.getElementById('page-title');
      if (t) t.textContent = deckName();
    }
  }
  function detectDecks() {
    if (Date.now() - dev.checked < 10000) return;
    dev.checked = Date.now();
    window.hub.deck?.devices?.().then((d) => {
      const changed = d.elgato !== dev.elgato || d.ulanzi !== dev.ulanzi;
      Object.assign(dev, d);
      applyDeckName();
      if (changed) dkPaint();
    }).catch(() => {});
  }
  function ulCard() {
    const s = ul.status;
    const on = ctx().state()?.settings?.ulanziDirect === true || Boolean(s?.running);
    let info = '';
    try { info = s?.info ? JSON.parse(s.info).Dversion : ''; } catch { /* egal */ }
    const state = !on ? 'Aus' : s?.connected ? `Verbunden${info ? ` · Firmware ${esc(info)}` : ''}` : s?.error ? `Fehler: ${esc(s.error)}` : 'Kein D200 gefunden – per USB anschliessen';
    const small = dk.data.ulanziSmall || 'clock';
    return `<div class="rv-card dk-ulanzi"><div class="rv-row between"><div><b>Ulanzi D200 – direkt im Hub</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Ohne Ulanzi Studio. Läuft weiter, wenn du das Hub-Fenster schliesst. Ulanzi Studio dabei bitte beenden.</p></div>
      <label class="rv-row" style="gap:8px;white-space:nowrap"><input type="checkbox" data-ul-on ${on ? 'checked' : ''}/> Direkt steuern</label></div>
      ${on ? `<div class="rv-row between" style="margin-top:10px;flex-wrap:wrap;gap:10px"><span class="rv-pill ${s?.connected ? 'ok' : ''}">${s?.connected ? '🟢' : '⚪'} ${state}</span>
        <div class="rv-row" style="flex-wrap:wrap;gap:10px"><label class="rv-muted">Kleines Display <select class="rv-input sm" data-ul-small>${[['clock', 'Uhr'], ['stats', 'PC-Werte (CPU/RAM)'], ['off', 'Aus']].map(([k, n]) => `<option value="${k}" ${small === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <label class="rv-muted">Helligkeit <input type="range" min="5" max="100" step="5" value="${dk.data.ulanziBrightness ?? 80}" data-ul-bright/></label>
        <button class="rv-btn sm" data-ul-push ${s?.connected ? '' : 'disabled'}>Jetzt übertragen</button></div></div>` : ''}
    </div>`;
  }
  // Hintergründe aus der Hub-Bibliothek: Revulution Live (Videos, für alle) und Premium (nur mit Pro)
  const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
  function libHtml() {
    const hs = ctx().state() || {};
    const pro = Boolean(window.RevStore?.pro?.());
    const live = (hs.wallpapers || []).map((id) => `<button class="dk-lib-item ${dk.data.bg?.id === id ? 'on' : ''}" data-dk-live="${esc(id)}"><img src="${fileUrl(`${hs.wallpaperDir}/thumbs/${id}.jpg`)}" alt=""/><em>LIVE</em><span>${esc(id.charAt(0).toUpperCase() + id.slice(1))}</span></button>`).join('');
    const prem = (dk.premium || []).map((x, i) => `<button class="dk-lib-item ${pro ? '' : 'locked'}" data-dk-prem="${i}"><img src="${esc(x.img)}" alt=""/><em class="prem">${pro ? 'PREMIUM' : '🔒 PREMIUM'}</em><span>${esc(x.name || 'Premium')}</span></button>`).join('');
    return `<div class="dk-lib"><b>Revulution Live</b><small class="rv-muted"> · läuft als Animation auf dem Deck</small><div class="dk-lib-grid">${live || '<p class="rv-muted">Keine Live-Hintergründe gefunden.</p>'}</div>
      <b>Premium</b><small class="rv-muted"> · ${pro ? 'mit deinem Pro-Abo freigeschaltet' : 'mit Pro freischalten'}</small><div class="dk-lib-grid">${prem || `<p class="rv-muted">${dk.premiumLoading ? 'Lädt …' : 'Gerade keine Premium-Hintergründe verfügbar.'}</p>`}</div></div>`;
  }
  function loadPremium() {
    if (dk.premium || dk.premiumLoading) return;
    dk.premiumLoading = true;
    Promise.all([window.hub.community.cloud(false).catch(() => []), window.hub.community.status().catch(() => null)]).then(([cloud, local]) => {
      dk.premium = [...(cloud || []).map((x) => ({ name: x.name, img: x.img })), ...((local?.backgrounds || []).filter((x) => x.data).map((x) => ({ name: x.name, img: x.data })))].filter((x) => /^data:image\//.test(x.img || ''));
    }).finally(() => { dk.premiumLoading = false; if (dk.root) dkPaint(); });
  }
  function bgCard() {
    const bg = dk.data.bg;
    return `<div class="rv-card dk-bgcard"><div class="rv-row between"><div><b>🖼️ Hintergrund über alle Tasten</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Ein Bild über das ganze Deck – Tasten mit Symbol und Text liegen darüber. Hintergründe aus der Bibliothek kommen als Standbild aufs Deck (ruckelfrei).</p></div>
      <div class="rv-row"><button class="rv-btn sm ${dk.libOpen ? 'on' : ''}" data-dk-lib>Aus der Bibliothek …</button><button class="rv-btn sm" data-dk-bgpick>${bg?.src ? 'Eigenes Bild …' : 'Bild wählen …'}</button>${bg?.src ? '<button class="rv-btn sm ghost" data-dk-bgdel>Entfernen</button>' : ''}</div></div>
      ${dk.libOpen ? libHtml() : ''}
      ${bg?.src ? `<div class="dk-bgctl"><label>Zoom<input type="range" min="1" max="3" step="0.05" value="${bg.zoom || 1}" data-dk-bg="zoom"/></label><label>Links/Rechts<input type="range" min="-1" max="1" step="0.02" value="${bg.x || 0}" data-dk-bg="x"/></label><label>Oben/Unten<input type="range" min="-1" max="1" step="0.02" value="${bg.y || 0}" data-dk-bg="y"/></label><label>Abdunkeln<input type="range" min="0" max="0.7" step="0.05" value="${bg.dim || 0}" data-dk-bg="dim"/></label></div>` : ''}
    </div>`;
  }

  /* ---------------------------------------------------------------- Aktionen */
  async function runAction(a) {
    if (!a) return;
    try {
      switch (a.type) {
        case 'media': return await window.hub.cc.media(a.key || 'playpause');
        case 'volume': return await window.hub.cc.media(a.key || 'volup');
        case 'program':
          if (!a.appId) return A.toast('Wähle zuerst ein Programm.', 'error');
          return await window.hub.deck.launch(a.appId);
        case 'keys':
          if (!a.combo) return A.toast('Gib zuerst eine Tastenkombination ein.', 'error');
          return await window.hub.deck.keys(a.combo);
        case 'screenshot': return await window.hub.cc.screenshot();
        case 'record': {
          const r = await window.hub.deck.record();
          if (r?.error) A.toast(r.error, 'error');
          else A.toast(r?.active ? '⏺ Aufnahme läuft' : '⏹ Aufnahme gespeichert');
          return r;
        }
        case 'widgets': {
          const s = await window.hub.desktopWidgets.state();
          const on = s?.enabled === false;
          await window.hub.desktopWidgets.set(on);
          return A.toast(on ? 'Widgets eingeblendet' : 'Widgets ausgeblendet');
        }
        case 'agent': {
          // Taste drücken → App nach vorne holen bzw. starten; bei Claude direkt den passenden Chat
          const r = await window.hub.deck.openAgent(a.agent || 'claude');
          if (cl.status?.off || !cl.status) window.hub.claude.enable(true).then((s) => { cl.status = s; ulPush(100); }).catch(() => {});
          return r;
        }
        case 'clock': return A.toast(new Date().toLocaleString('de-CH', { weekday: 'long', hour: '2-digit', minute: '2-digit' }));
        case 'page': {
          const n = dk.data.pages.length;
          dk.page = a.to === 'next' ? (ul.deckPage + 1) % n : a.to === 'prev' ? (ul.deckPage - 1 + n) % n : Math.max(0, Math.min(n - 1, Number(a.to) || 0));
          dk.sel = null;
          ulPush(0);
          if (dk.root) dkPaint();
          return null;
        }
        case 'sound': {
          const src = await window.hub.widgetSound.data(Number(a.pad) || 0);
          if (!src) return A.toast(`Soundboard-Platz ${(Number(a.pad) || 0) + 1} ist leer – wähle einen Sound.`, 'error');
          const au = new Audio(src);
          au.volume = Math.max(0, Math.min(1, Number(a.volume ?? 1)));
          return au.play();
        }
        case 'open': return await window.hub.deck.run(a.target);
        case 'app': return await window.hub.open(a.app || 'home');
        case 'crosshair': return await window.hub.crosshair.toggle();
        case 'lock': return await window.hub.cc.lock();
        case 'timer': return await window.hub.cc.timerIsland(Math.max(1, Number(a.minutes) || 5) * 60, a.label || 'Timer');
        case 'multi':
          for (const step of a.steps || []) {
            await runAction(step);
            await new Promise((r) => setTimeout(r, Math.max(0, Number(step.after) || 150)));
          }
          return null;
        default: return null;
      }
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    return null;
  }
  // Hardware-Tasten (über die Tastatur-Engine, z. B. Elgato mit F13–F24) lösen Deck-Tasten aus
  window.hub.deck?.onAction?.(async (id) => {
    if (!String(id).startsWith('deck-')) return;
    await dkLoad();
    const bid = String(id).slice(5);
    for (const p of dk.data.pages) for (const b of Object.values(p.buttons)) if (b?.id === bid) return runAction(b.action);
    return null;
  });
  function loadApps() {
    if (dk.apps || dk.appsLoading) return;
    dk.appsLoading = true;
    window.hub.deck.apps().then((list) => { dk.apps = list; if (dk.root) dkPaint(); }).catch(() => { dk.apps = []; }).finally(() => { dk.appsLoading = false; });
  }
  function actionForm(b) {
    const a = b.action || { type: 'none' };
    const sel = (key, opts) => `<select class="rv-input sm" data-dk-act="${key}">${opts.map(([v, n]) => `<option value="${v}" ${String(a[key]) === String(v) ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>`;
    const apps = Object.entries({ ...window.HubTools.TOOLS }).map(([k, v]) => [k, v.title]).concat([['gaming', 'Gaming Hub'], ['chats', 'Chats'], ['docs', 'Dokumente'], ['video', 'Video-Schnitt'], ['chess', 'Schach'], ['geo', 'GeoRevulution'], ['worldview', 'Weltansicht']]);
    switch (a.type) {
      case 'media': return sel('key', [['playpause', 'Play / Pause'], ['next', 'Nächster Titel'], ['prev', 'Vorheriger Titel'], ['stop', 'Stopp'], ['mute', 'Stumm']]);
      case 'volume': return sel('key', [['volup', 'Lauter'], ['voldown', 'Leiser'], ['mute', 'Stumm an/aus']]);
      case 'program':
        loadApps();
        return `<input class="rv-input sm" list="dk-apps" data-dk-program value="${esc(a.name || '')}" placeholder="${dk.apps ? 'Programm suchen …' : 'Programme werden geladen …'}" style="width:100%"/><datalist id="dk-apps">${(dk.apps || []).map((x) => `<option value="${esc(x.name)}"></option>`).join('')}</datalist><small class="rv-muted">${dk.apps ? `${dk.apps.length} installierte Programme` : ''}</small>`;
      case 'keys': return `<input class="rv-input sm" data-dk-act="combo" value="${esc(a.combo || '')}" placeholder="z. B. ^c  ·  ^+{ESC}  ·  %{F4}" style="width:100%"/><small class="rv-muted">^ = Strg, + = Umschalt, % = Alt, {F5} {ENTER} {TAB} {DEL} …</small>`;
      case 'clock': return sel('style', CLOCKS);
      case 'agent': {
        const o = cl.status?.others || {};
        const info = (k) => (k === 'claude' ? clText(cl.status) : o[k]?.status ? { working: 'arbeitet', question: 'Frage', done: 'fertig', ready: 'bereit', idle: 'bereit', off: 'aus' }[o[k].status] || o[k].status : 'aus');
        return `${sel('agent', [['claude', 'Claude'], ['codex', 'ChatGPT / Codex'], ['freebuff', 'Freebuff']])}<small class="rv-muted">Jetzt: ${esc(info(a.agent || 'claude'))}${(a.agent || 'claude') === 'freebuff' ? ' · erkannt am Freebuff-Agenten (Chat-Speicher + Werkzeuge)' : ''}</small><small class="rv-muted">Drücken öffnet ${(a.agent || 'claude') === 'claude' ? 'Claude direkt im Chat mit Frage bzw. dem zuletzt fertigen Chat' : (a.agent === 'codex' ? 'ChatGPT' : 'Freebuff')} – startet die App, falls sie zu ist.</small>`;
      }
      case 'page': return sel('to', [['next', 'Nächste Seite'], ['prev', 'Vorherige Seite'], ...dk.data.pages.map((p, i) => [i, p.name])]);
      case 'sound': return `<select class="rv-input sm" data-dk-act="pad">${Array.from({ length: 8 }, (_, i) => `<option value="${i}" ${Number(a.pad) === i ? 'selected' : ''}>Platz ${i + 1}</option>`).join('')}</select><button class="rv-btn sm" data-dk-pick>Sound wählen …</button><label class="rv-muted">Lautstärke <input type="range" min="0" max="1" step="0.05" value="${a.volume ?? 1}" data-dk-act="volume"/></label>`;
      case 'open': return `<input class="rv-input sm" data-dk-act="target" value="${esc(a.target || '')}" placeholder="https://… oder C:\\Pfad\\Datei" style="width:100%"/>`;
      case 'app': return sel('app', apps);
      case 'timer': return `<label class="rv-muted">Minuten <input class="rv-input sm" type="number" min="1" max="600" value="${a.minutes || 5}" data-dk-act="minutes" style="width:80px"/></label>`;
      case 'multi': return `<div class="dk-chain">${(a.steps || []).map((s, i) => `<div class="rv-row"><span class="rv-pill">${i + 1}. ${esc(DECK_ACTIONS.find((x) => x[0] === s.type)?.[1] || s.type)}${s.key ? ` · ${esc(s.key)}` : ''}</span><label class="rv-muted">danach <input class="rv-input sm" type="number" min="0" max="10000" step="50" value="${s.after ?? 150}" data-dk-chainafter="${i}" style="width:80px"/> ms</label><button class="rv-btn sm ghost" data-dk-chaindel="${i}">✕</button></div>`).join('')}
      <div class="rv-row"><select class="rv-input sm" data-dk-chainadd><option value="">＋ Schritt hinzufügen …</option>${DECK_ACTIONS.filter(([k]) => !['none', 'multi', 'claude', 'clock', 'page', 'program', 'keys'].includes(k)).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></div></div>`;
      default: return '';
    }
  }

  /* ---------------------------------------------------------------- Oberfläche */
  function dkPaint() {
    if (!dk.root || !dk.data) return;
    const d = dk.data;
    const p = page();
    const b = selBtn();
    const cells = [];
    const ulOn = ctx().state()?.settings?.ulanziDirect === true && d.cols === 5 && d.rows === 3;
    for (let i = 0; i < d.cols * d.rows; i++) {
      if (ulOn && i === UL_KEYS) { cells.push(`<div class="dk-key dk-clock" style="grid-column:span 2" title="Kleines Display des D200"><span class="dk-ic">${(d.ulanziSmall || 'clock') === 'stats' ? '📊' : '🕒'}</span><small>${(d.ulanziSmall || 'clock') === 'stats' ? 'PC-Werte' : (d.ulanziSmall || 'clock') === 'off' ? 'Display aus' : 'Uhr-Display'}</small></div>`); break; }
      const x = p.buttons[i];
      const showImg = x || d.bg?.src;
      cells.push(`<button class="dk-key ${dk.sel === i ? 'sel' : ''} ${x ? '' : 'empty'} ${showImg ? 'img' : ''}" data-dk-key="${i}" style="--c:${esc(x?.color || '#2c2c34')}">${showImg ? `<img src="${keyImage(x, i)}" alt="" draggable="false"/>` : ''}${x ? (x.hotkey ? `<i class="dk-hk">${esc(x.hotkey)}</i>` : '') : `<span class="dk-plus">＋</span>`}</button>`);
    }
    const t = b?.action?.type;
    dk.root.innerHTML = `<div class="dv dk">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">${esc(deckName())}</h2><p class="rv-sub">${ul.status?.connected ? 'Dein Ulanzi D200 ist verbunden – Änderungen erscheinen sofort auf dem Deck. Rechtsklick auf eine Taste für mehr.' : dev.elgato ? 'Elgato Stream Deck erkannt: Tasten in der Elgato-Software auf „Hotkey“ F13–F24 legen und hier unter „Hardware-Taste“ zuweisen.' : 'Klicken = ausprobieren, rechts einstellen, Rechtsklick für mehr.'}</p></div>
        <div class="rv-row"><div class="rv-tabs">${d.pages.map((pg, i) => `<button class="${i === dk.page ? 'on' : ''}" data-dk-page="${i}">${esc(pg.name)}</button>`).join('')}<button data-dk-addpage title="Neue Seite">＋</button></div>
        <select class="rv-input sm" data-dk-size>${[[3, 2], [5, 3], [8, 4]].map(([c, r]) => `<option value="${c}x${r}" ${d.cols === c && d.rows === r ? 'selected' : ''}>${c} × ${r}</option>`).join('')}</select></div></div></div>
      ${ulCard()}
      <div class="dk-wrap"><div class="dk-grid" style="grid-template-columns:repeat(${d.cols},1fr)">${cells.join('')}</div>
      <aside class="rv-card dk-side">${b ? `<b>Taste ${dk.sel + 1}</b>
        <label>Aktion<select class="rv-input sm" data-dk-type>${DECK_ACTIONS.map(([k, n]) => `<option value="${k}" ${t === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <div class="dk-act">${actionForm(b)}</div>
        ${t === 'claude' || t === 'clock' || t === 'agent' ? '' : `<label>Beschriftung<input class="rv-input sm" data-dk-field="label" value="${esc(b.label || '')}" maxlength="20"/></label>
        <label>Symbol<div class="dk-icons">${ICONS.map((ic) => `<button class="dk-ico ${b.icon === ic ? 'on' : ''}" data-dk-icon="${ic}">${ic}</button>`).join('')}</div></label>`}
        ${t === 'claude' || t === 'agent' ? '' : `<div class="rv-row between"><span>Bild</span><div class="rv-row"><button class="rv-btn sm" data-dk-img>${b.image ? 'Anderes …' : 'Bild wählen …'}</button>${b.image ? '<button class="rv-btn sm ghost" data-dk-imgdel>✕</button>' : ''}</div></div>
        ${b.image ? `<label class="rv-row" style="gap:8px"><input type="checkbox" data-dk-showicon ${b.showIcon ? 'checked' : ''}/> Symbol über dem Bild</label>` : `<label class="rv-row between">Farbe<input type="color" value="${esc(b.color || '#2c2c34')}" data-dk-field="color"/></label>`}`}
        <label>Hardware-Taste<div class="rv-row"><button class="rv-btn sm ${dk.capture ? 'on' : ''}" data-dk-hotkey>${dk.capture ? 'Taste am Deck drücken …' : b.hotkey ? esc(b.hotkey) : 'Zuweisen'}</button>${b.hotkey ? '<button class="rv-btn sm ghost" data-dk-hotkeydel>✕</button>' : ''}</div></label>
        <div class="rv-row"><button class="rv-btn sm primary" data-dk-test>▶ Testen</button><button class="rv-btn sm danger" data-dk-del>Taste löschen</button></div>`
        : '<b>Taste wählen</b><p class="rv-muted">Klicke eine leere Taste (＋), um sie zu belegen. Ein Klick auf eine belegte Taste führt sie aus und öffnet ihre Einstellungen. Rechtsklick: Bild, Kopieren, Einfügen, Duplizieren, Löschen.</p>'}</aside></div>
      ${bgCard()}
      ${claudeCard()}
    </div>`;
  }
  async function hotkeyRule(b, code) {
    const c = kbCfg();
    if (b.hotkey) setRule(c, b.hotkey, null);
    if (code) setRule(c, code, { type: 'hub', to: `deck-${b.id}` });
    b.hotkey = code || '';
    dkSave();
    try {
      await kbSave(c, Boolean(code) || c.enabled);
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    dkPaint();
  }
  async function deleteKey(i) {
    const b = page().buttons[i];
    if (!b) return;
    if (b.hotkey) await hotkeyRule(b, '');
    delete page().buttons[i];
    if (dk.sel === i) dk.sel = null;
    dkSave();
    dkPaint();
  }

  // Rechtsklick-Menü auf einer Taste
  let menuEl = null;
  const closeMenu = () => { menuEl?.remove(); menuEl = null; };
  document.addEventListener('contextmenu', (e) => {
    const key = e.target.closest?.('[data-dk-key]');
    if (!key || !dk.root?.contains(key)) return;
    e.preventDefault();
    closeMenu();
    const i = Number(key.dataset.dkKey);
    const b = page().buttons[i];
    const items = b
      ? [['edit', '✏️ Bearbeiten'], ['run', '▶ Ausführen'], ['img', '🖼️ Bild wählen …'], ...(b.image ? [['imgdel', '🧹 Bild entfernen']] : []), ['copy', '📋 Kopieren'], ...(dk.clip ? [['paste', '📥 Einfügen (ersetzen)']] : []), ['dup', '🧬 Duplizieren'], ['del', '🗑️ Löschen']]
      : [['new', '＋ Neue Taste'], ...(dk.clip ? [['paste', '📥 Einfügen']] : [])];
    menuEl = document.createElement('div');
    menuEl.className = 'dk-menu';
    menuEl.innerHTML = items.map(([k, n]) => `<button data-dkm="${k}" class="${k === 'del' ? 'danger' : ''}">${n}</button>`).join('');
    document.body.appendChild(menuEl);
    const r = menuEl.getBoundingClientRect();
    menuEl.style.left = `${Math.min(e.clientX, innerWidth - r.width - 8)}px`;
    menuEl.style.top = `${Math.min(e.clientY, innerHeight - r.height - 8)}px`;
    menuEl.onclick = async (ev) => {
      const a = ev.target.closest('[data-dkm]')?.dataset.dkm;
      if (!a) return;
      closeMenu();
      const btns = page().buttons;
      if (a === 'edit' || a === 'new') { if (!btns[i]) btns[i] = { id: newId(), icon: '⭐', label: 'Neu', color: '#5e5ce6', action: { type: 'none' } }; dk.sel = i; dkSave(); return dkPaint(); }
      if (a === 'run') return runAction(btns[i]?.action);
      if (a === 'img') { const src = await pickImage(S, true); if (src) { btns[i].image = src; dkSave(); dkPaint(); } return; }
      if (a === 'imgdel') { delete btns[i].image; dkSave(); return dkPaint(); }
      if (a === 'copy') { dk.clip = JSON.parse(JSON.stringify(btns[i])); return A.toast('Taste kopiert.'); }
      if (a === 'paste') { btns[i] = { ...JSON.parse(JSON.stringify(dk.clip)), id: newId(), hotkey: '' }; dk.sel = i; dkSave(); return dkPaint(); }
      if (a === 'dup') {
        const max = dk.data.cols * dk.data.rows;
        let free = -1;
        for (let k = 0; k < max; k++) if (!btns[k] && !(ctx().state()?.settings?.ulanziDirect && k >= UL_KEYS)) { free = k; break; }
        if (free < 0) return A.toast('Keine freie Taste auf dieser Seite.', 'error');
        btns[free] = { ...JSON.parse(JSON.stringify(btns[i])), id: newId(), hotkey: '' };
        dk.sel = free; dkSave(); return dkPaint();
      }
      if (a === 'del') return deleteKey(i);
    };
  });
  document.addEventListener('pointerdown', (e) => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); }, true);
  window.addEventListener('blur', closeMenu);

  document.addEventListener('click', async (e) => {
    if (!dk.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const key = q('[data-dk-key]')?.dataset.dkKey;
    if (key != null) {
      const i = Number(key);
      if (!page().buttons[i]) page().buttons[i] = { id: newId(), icon: '⭐', label: 'Neu', color: '#5e5ce6', action: { type: 'none' } };
      else runAction(page().buttons[i].action);
      const el = q('[data-dk-key]');
      el.classList.remove('press');
      void el.offsetWidth;
      el.classList.add('press');
      dk.sel = i;
      dkSave();
      return setTimeout(dkPaint, 120);
    }
    if (q('[data-ul-push]')) return ulPush(0);
    if (q('[data-dk-bgpick]')) {
      const src = await pickImage(1400, false);
      if (src) { dk.data.bg = { src, zoom: 1, x: 0, y: 0, dim: 0.15 }; dkSave(); dkPaint(); }
      return;
    }
    if (q('[data-dk-bgdel]')) { delete dk.data.bg; dkSave(); return dkPaint(); }
    if (q('[data-dk-lib]')) { dk.libOpen = !dk.libOpen; if (dk.libOpen) loadPremium(); return dkPaint(); }
    const liveId = q('[data-dk-live]')?.dataset.dkLive;
    if (liveId) {
      try {
        // Standbild aus dem Live-Hintergrund (erstes Bild des Videos) – nicht animiert, damit nichts ruckelt
        const src = await window.hub.ulanzi.liveThumb(liveId);
        dk.data.bg = { kind: 'image', from: liveId, src, zoom: 1, x: 0, y: 0, dim: 0.15 };
        dkSave();
        dkPaint();
      } catch (err) { A.toast(A.errText(err), 'error'); }
      return;
    }
    const premI = q('[data-dk-prem]')?.dataset.dkPrem;
    if (premI != null) {
      if (!window.RevStore?.pro?.()) { A.toast('Premium-Hintergründe gibt es mit Pro.', 'error'); return window.RevStore?.open?.('pro'); }
      const it = dk.premium?.[Number(premI)];
      if (it) { dk.data.bg = { kind: 'image', src: it.img, zoom: 1, x: 0, y: 0, dim: 0.15 }; dkSave(); dkPaint(); }
      return;
    }
    const pg = q('[data-dk-page]')?.dataset.dkPage;
    if (pg != null) {
      dk.page = Number(pg);
      dk.sel = null;
      ulPush(0);
      return dkPaint();
    }
    if (q('[data-dk-addpage]')) {
      dk.data.pages.push({ name: `Seite ${dk.data.pages.length + 1}`, buttons: {} });
      dk.page = dk.data.pages.length - 1;
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    const ic = q('[data-dk-icon]')?.dataset.dkIcon;
    if (ic) { b.icon = ic; dkSave(); return dkPaint(); }
    if (q('[data-dk-img]')) { const src = await pickImage(S, true); if (src) { b.image = src; dkSave(); dkPaint(); } return; }
    if (q('[data-dk-imgdel]')) { delete b.image; dkSave(); return dkPaint(); }
    if (q('[data-dk-test]')) return runAction(b.action);
    if (q('[data-dk-del]')) return deleteKey(dk.sel);
    if (q('[data-dk-pick]')) {
      const pad = Number(b.action.pad) || 0;
      const name = await window.hub.widgetSound.pick(pad).catch((err) => A.toast(A.errText(err), 'error'));
      if (name) {
        b.label = String(name).replace(/\.[^.]+$/, '').slice(0, 20);
        dkSave();
        dkPaint();
        A.toast(`„${name}“ liegt jetzt auf Platz ${pad + 1} – auch im Soundboard-Widget.`);
      }
      return;
    }
    if (q('[data-dk-hotkey]')) { dk.capture = !dk.capture; return dkPaint(); }
    if (q('[data-dk-hotkeydel]')) return hotkeyRule(b, '');
    const cd = q('[data-dk-chaindel]')?.dataset.dkChaindel;
    if (cd != null) { b.action.steps.splice(Number(cd), 1); dkSave(); return dkPaint(); }
  });
  // Hintergrund-Regler live (ohne die ganze Seite neu zu bauen)
  document.addEventListener('input', (e) => {
    if (!dk.root?.contains(e.target) || !e.target.matches('[data-dk-bg]') || !dk.data.bg) return;
    dk.data.bg[e.target.dataset.dkBg] = Number(e.target.value);
    dk.root.querySelectorAll('[data-dk-key] img').forEach((im) => { const i = Number(im.closest('[data-dk-key]').dataset.dkKey); im.src = keyImage(page().buttons[i], i); });
    ulPush(350);
    clearTimeout(dk.bgSaveT);
    dk.bgSaveT = setTimeout(() => A.store.set('streamdeck', dk.data), 500);
  });
  document.addEventListener('change', (e) => {
    if (!dk.root?.contains(e.target)) return;
    const t = e.target;
    if (t.matches('[data-dk-bg]')) return;
    if (t.matches('[data-ul-on]')) {
      return window.hub.ulanzi.enable(t.checked).then((s) => {
        ul.status = s;
        if (t.checked && (dk.data.cols !== 5 || dk.data.rows !== 3)) Object.assign(dk.data, { cols: 5, rows: 3 });
        if (ctx().state()?.settings) ctx().state().settings.ulanziDirect = t.checked;
        dkSave();
        dkPaint();
      }).catch((err) => A.toast(A.errText(err), 'error'));
    }
    if (t.matches('[data-cl-on]')) {
      return window.hub.claude.enable(t.checked).then((s) => {
        cl.status = s;
        if (ctx().state()?.settings) ctx().state().settings.claudeLink = t.checked;
        ulPush(100);
        dkPaint();
      }).catch((err) => A.toast(A.errText(err), 'error'));
    }
    if (t.matches('[data-ul-small]')) {
      dk.data.ulanziSmall = t.value;
      A.store.set('streamdeck', dk.data);
      window.hub.ulanzi.small(t.value).catch(() => {});
      return dkPaint();
    }
    if (t.matches('[data-ul-bright]')) {
      dk.data.ulanziBrightness = Number(t.value);
      A.store.set('streamdeck', dk.data);
      return window.hub.ulanzi.brightness(Number(t.value)).catch(() => {});
    }
    if (t.matches('[data-dk-size]')) {
      const [c, r] = t.value.split('x').map(Number);
      Object.assign(dk.data, { cols: c, rows: r });
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    if (t.matches('[data-dk-showicon]')) b.showIcon = t.checked;
    else if (t.matches('[data-dk-program]')) {
      const app = (dk.apps || []).find((x) => x.name === t.value) || (dk.apps || []).find((x) => x.name.toLowerCase() === t.value.trim().toLowerCase());
      if (!app) { A.toast('Programm nicht gefunden – wähle einen Eintrag aus der Liste.', 'error'); return; }
      b.action.appId = app.id; b.action.name = app.name;
      if (!b.label || b.label === 'Neu') b.label = app.name.slice(0, 20);
    } else if (t.dataset.dkField) b[t.dataset.dkField] = t.value;
    else if (t.matches('[data-dk-type]')) {
      b.action = { type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'volume' ? { key: 'volup' } : t.value === 'sound' ? { pad: 0, volume: 1 } : t.value === 'multi' ? { steps: [] } : t.value === 'clock' ? { style: 'digital' } : t.value === 'page' ? { to: 'next' } : {}) };
      if (t.value === 'agent') b.action.agent = 'claude';
      // Agenten-Tasten brauchen die (lokale) Verbindung zu den KI-Apps
      if (t.value === 'agent' && ctx().state()?.settings?.claudeLink !== true) {
        window.hub.claude.enable(true).then((s) => { cl.status = s; if (ctx().state()?.settings) ctx().state().settings.claudeLink = true; dkPaint(); ulPush(100); }).catch(() => {});
      }
      if (t.value === 'program') loadApps();
    } else if (t.dataset.dkAct) b.action[t.dataset.dkAct] = t.type === 'range' || t.type === 'number' || t.dataset.dkAct === 'pad' ? Number(t.value) : t.value;
    else if (t.matches('[data-dk-chainadd]') && t.value) b.action.steps.push({ type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'volume' ? { key: 'volup' } : t.value === 'sound' ? { pad: 0 } : {}), after: 150 });
    else if (t.dataset.dkChainafter != null) b.action.steps[Number(t.dataset.dkChainafter)].after = Number(t.value) || 0;
    dkSave();
    dkPaint();
  });
  document.addEventListener('keydown', (e) => {
    if (!dk.capture || !dk.root || !document.contains(dk.root)) return;
    e.preventDefault();
    e.stopPropagation();
    dk.capture = false;
    const b = selBtn();
    if (!b) return dkPaint();
    if (['Escape'].includes(e.code)) return dkPaint();
    if (!/^F(1[3-9]|2[0-4])$/.test(e.code) && !window.confirm(`„${e.code}“ ist eine normale Taste – sie würde dann überall nur noch diese Deck-Aktion auslösen. Trotzdem verwenden?`)) return dkPaint();
    hotkeyRule(b, e.code);
  }, true);
  // Beim Start des Hubs: Deck-Daten laden, damit Deck-Tasten auch ohne geöffnetes Studio funktionieren
  dkLoad();
  A.define('tool-streamdeck', { nav: 'Deck Studio', title: 'Deck Studio', sub: 'Stream Deck & Ulanzi: Tasten für alles', icon: 'grid', tint: 'linear-gradient(135deg,#818cf8,#312e81)', desc: 'Dein Stream Deck oder Ulanzi-Deck im Hub: Programme, Medien, Lautstärke, Tastenkombinationen, Uhren, Claude-Status, Aufnahme, Widgets, Bilder und ein Hintergrund über alle Tasten.' }, {
    async mount(root) {
      dk.root = root;
      applyDeckName();
      detectDecks();
      root.innerHTML = '<div class="rv-empty">Lädt …</div>';
      await dkLoad();
      if (dk.root === root) dkPaint();
    },
    unmount() {
      dk.root = null;
      dk.capture = false;
      closeMenu();
    },
  });


  /* ================================================================ Clips (eigene App, Engine im Gaming Hub) */
  window.HubTools.register('tool-clips', { nav: 'Clips', title: 'Clips', sub: 'Aufnehmen, Highlights, Facecam', icon: 'camera', tint: 'linear-gradient(135deg,#fb7185,#9f1239)', desc: 'Der Clipper: läuft im Hintergrund, speichert die letzten Sekunden per Hotkey, nimmt lange Aufnahmen auf, mit Facecam, Ton und Keystrokes – und alle Clips zum Ansehen und Schneiden.' }, () => '<div class="page"><div class="empty">Clips wird geöffnet …</div></div>');

  /* ================================================================ Lüfter – wie Fan Control (2.45.3)
     Alle Lüfter-Anschlüsse (Mainboard + Grafikkarte) mit drehendem Lüfter in echter Drehzahl,
     je Anschluss: Auto (BIOS) · Fest (%) · Kurve (Temperatur → %). Der Helfer RevFans.exe
     (Administrator, PawnIO-Treiber) liest und steuert; Kurven laufen dort auch bei geschlossenem Hub-Fenster.
     Windows-Kühlrichtlinie bleibt unten als Zusatz. */
  const fn = { root: null, st: null, timer: 0, busy: false, ctl: null, snap: null, cfg: { controls: {} }, saveT: 0, curveDrag: null, starting: false, err: '' };
  const DEF_CURVE = [[30, 25], [50, 40], [65, 60], [75, 80], [85, 100]];
  function fnPorts() {
    const ports = [];
    for (const h of fn.snap?.hardware || []) {
      for (const s of h.sensors) {
        if (s.type !== 'Control') continue;
        const fan = h.sensors.find((x) => x.type === 'Fan' && x.id === s.id.replace('/control/', '/fan/'));
        ports.push({ id: s.id, name: s.name, hw: h.name, hwType: h.type, pct: s.value, rpm: fan?.value ?? null, control: s.control });
      }
    }
    return ports;
  }
  const fnTemps = () => (fn.snap?.hardware || []).flatMap((h) => h.sensors.filter((s) => s.type === 'Temperature' && Number.isFinite(s.value) && s.value > 0).map((s) => ({ ...s, hw: h.name })));
  const fanSvg = (rpm) => {
    const dur = rpm > 0 ? Math.max(0.12, Math.min(3, 900 / rpm)) : 0;
    return `<svg class="fc-fan ${dur ? 'spin' : ''}" style="--dur:${dur}s" viewBox="0 0 48 48"><circle cx="24" cy="24" r="22" class="fc-ring"/>${[0, 72, 144, 216, 288].map((a) => `<path transform="rotate(${a} 24 24)" d="M24 24c-2-6-1-13 5-16 5 2 4 9 0 13-1.6 1.6-3.4 2.6-5 3z" class="fc-blade"/>`).join('')}<circle cx="24" cy="24" r="4.2" class="fc-hub"/></svg>`;
  };
  function curveSvg(id, points, temp) {
    const W = 300, H = 140, x = (t) => ((t - 20) / 80) * W, y = (p) => H - (p / 100) * H;
    const path = points.map((p, i) => `${i ? 'L' : 'M'}${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join(' ');
    const cur = Number.isFinite(temp) ? `<line x1="${x(temp)}" x2="${x(temp)}" y1="0" y2="${H}" class="fc-now"/>` : '';
    const grid = [40, 60, 80].map((t) => `<line x1="${x(t)}" x2="${x(t)}" y1="0" y2="${H}" class="fc-grid"/><text x="${x(t) + 3}" y="${H - 4}" class="fc-ax">${t}°</text>`).join('') + [25, 50, 75].map((p) => `<line x1="0" x2="${W}" y1="${y(p)}" y2="${y(p)}" class="fc-grid"/><text x="3" y="${y(p) - 3}" class="fc-ax">${p}%</text>`).join('');
    return `<svg class="fc-curve" viewBox="0 0 ${W} ${H}" data-fc-curve="${esc(id)}">${grid}${cur}<path d="${path} L${W},${y(points[points.length - 1][1])}" class="fc-line"/>${points.map((p, i) => `<circle cx="${x(p[0])}" cy="${y(p[1])}" r="7" class="fc-pt" data-fc-pt="${i}"/>`).join('')}</svg>`;
  }
  function fnPaint() {
    if (!fn.root) return;
    const s = fn.st;
    const pol = s?.policy?.ac === 'unknown' && fn.chosen ? fn.chosen : s?.policy?.ac;
    const ctl = fn.ctl;
    const ports = fnPorts();
    const temps = fnTemps();
    const tempOpts = (sel) => temps.map((t) => `<option value="${esc(t.id)}" ${t.id === sel ? 'selected' : ''}>${esc(t.hw)} · ${esc(t.name)} (${Math.round(t.value)}°)</option>`).join('');
    const defaultTemp = (temps.find((t) => /Tctl|Package|CPU/i.test(t.name) && /cpu/i.test(t.id)) || temps[0])?.id;
    let main;
    if (!ctl) main = '<div class="rv-card"><p class="rv-muted">Prüfe Lüftersteuerung …</p></div>';
    else if (!ctl.helper) main = '<div class="rv-card"><b>Lüftersteuerung nicht verfügbar</b><p class="rv-muted">Der Lüfter-Helfer fehlt in dieser Installation – bitte den Hub aktualisieren.</p></div>';
    else if (!ctl.pawnio) main = `<div class="rv-card fc-start"><div><b>Mainboard-Treiber installieren</b><p class="rv-muted">Für die Lüfter braucht Windows den Treiber „PawnIO“ (derselbe wie bei Fan Control, Open Source, signiert). Der Hub lädt den offiziellen Installer, prüft die Signatur und installiert ihn – Windows fragt dabei nach Administratorrechten.</p>${fn.err ? `<p class="fc-err">${esc(fn.err)}</p>` : ''}</div><button class="rv-btn primary" data-fc-driver ${fn.starting ? 'disabled' : ''}>${fn.starting ? 'Installiert …' : 'Treiber installieren'}</button></div>`;
    else if (!fn.snap) main = `<div class="rv-card fc-start"><div><b>Lüftersteuerung starten</b><p class="rv-muted">Wie Fan Control: alle Lüfter sehen und jeden Anschluss einzeln steuern. Windows fragt einmal nach Administratorrechten – die braucht der Zugriff aufs Mainboard.</p>${fn.err ? `<p class="fc-err">${esc(fn.err)}</p>` : ''}</div><button class="rv-btn primary" data-fc-start ${fn.starting ? 'disabled' : ''}>${fn.starting ? 'Startet …' : 'Starten'}</button></div>`;
    else {
      main = `<div class="fc-grid">${ports.map((p) => {
        const c = fn.cfg.controls[p.id] || { mode: 'auto' };
        const temp = c.sensor ? temps.find((t) => t.id === c.sensor)?.value : null;
        return `<div class="fc-card ${c.mode !== 'auto' ? 'manual' : ''}" data-fc-port="${esc(p.id)}">
          <div class="fc-head">${fanSvg(p.rpm)}<div class="fc-names"><b>${esc(p.name)}</b><small>${esc(p.hw)}</small></div></div>
          <div class="fc-vals"><div><small>Drehzahl</small><b>${p.rpm == null ? '–' : `${Math.round(p.rpm)}`}<i>U/min</i></b></div><div><small>Leistung</small><b>${p.pct == null ? '–' : Math.round(p.pct)}<i>%</i></b></div></div>
          <div class="fc-modes">${[['auto', 'Auto'], ['fixed', 'Fest'], ['curve', 'Kurve']].map(([m, n]) => `<button class="${c.mode === m ? 'on' : ''}" data-fc-mode="${m}">${n}</button>`).join('')}</div>
          ${c.mode === 'fixed' ? `<label class="fc-fixed"><input type="range" min="0" max="100" step="1" value="${c.value ?? 50}" data-fc-value/><b>${c.value ?? 50} %</b></label>` : ''}
          ${c.mode === 'curve' ? `<select class="rv-input sm fc-sensor" data-fc-sensor>${tempOpts(c.sensor || defaultTemp)}</select>${curveSvg(p.id, c.points || DEF_CURVE, temp)}<small class="rv-muted">Punkte ziehen · x = Temperatur, y = Lüfter-%</small>` : ''}
          ${c.mode === 'auto' ? '<small class="rv-muted">Steuert das Mainboard (BIOS-Kurve).</small>' : ''}
        </div>`;
      }).join('')}</div>
      <div class="rv-card"><b>Temperaturen</b><div class="fc-temps">${temps.map((t) => `<div><span>${esc(t.name)}<small>${esc(t.hw)}</small></span><b class="${t.value >= 80 ? 'hot' : t.value >= 65 ? 'warm' : ''}">${t.value.toFixed(1)}°C</b></div>`).join('')}</div></div>`;
    }
    fn.root.innerHTML = `<div class="dv">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">Lüfter</h2><p class="rv-sub">Alle Lüfter und Anschlüsse – wie Fan Control, direkt im Hub.</p></div><div class="rv-row">${fn.snap ? `<span class="rv-pill ok">● Steuerung aktiv · ${esc(fn.snap.at || '')}</span><button class="rv-btn sm" data-fc-stop title="Alle Lüfter zurück auf Automatik und Helfer beenden">Beenden</button>` : ''}</div></div>${fn.snap?.error ? `<p class="fc-err">${esc(fn.snap.error)}</p>` : ''}</div>
      ${main}
      <div class="rv-card"><b>Windows-Kühlrichtlinie</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 10px">Aktiv: Lüfter drehen zuerst hoch (kühler, lauter). Passiv: erst wird die CPU gedrosselt (leiser).</p>
        <div class="rv-tabs"><button class="${pol === 'active' ? 'on' : ''}" data-fn-pol="active">❄️ Aktiv – kühl</button><button class="${pol === 'passive' ? 'on' : ''}" data-fn-pol="passive">🤫 Passiv – leise</button></div></div>
    </div>`;
  }
  function fnSave() {
    clearTimeout(fn.saveT);
    fn.saveT = setTimeout(async () => {
      try {
        fn.snap = await window.hub.fanctl.config(fn.cfg);
      } catch (e) {
        A.toast(A.errText(e), 'error');
      }
      fnPaint();
    }, 250);
  }
  async function fnLoad() {
    if (fn.busy || fn.curveDrag) return;
    fn.busy = true;
    try {
      fn.ctl = await window.hub.fanctl.status();
      if (fn.ctl.running) {
        fn.snap = await window.hub.fanctl.list();
        if (fn.snap?.config?.controls && !fn.cfgLoaded) { fn.cfg = { controls: { ...fn.snap.config.controls } }; fn.cfgLoaded = true; }
      } else fn.snap = null;
      if (!fn.st || Date.now() - (fn.stAt || 0) > 15000) { fn.st = await window.hub.fans.state(); fn.stAt = Date.now(); }
    } catch (e) {
      fn.err = A.errText(e);
    }
    fn.busy = false;
    if (!fn.root?.querySelector('select:focus, input[type=range]:active')) fnPaint();
  }
  const portCfg = (id) => (fn.cfg.controls[id] ||= { mode: 'auto' });
  document.addEventListener('click', async (e) => {
    if (!fn.root?.contains(e.target)) return;
    const pol = e.target.closest('[data-fn-pol]')?.dataset.fnPol;
    if (pol) {
      try {
        fn.st.policy = await window.hub.fans.policy(pol);
        fn.chosen = pol;
        A.toast(pol === 'active' ? 'Kühlung: aktiv (Lüfter zuerst).' : 'Kühlung: passiv (leiser).');
      } catch (err) { A.toast(A.errText(err), 'error'); }
      return fnPaint();
    }
    if (e.target.closest('[data-fc-start]')) {
      fn.starting = true; fn.err = ''; fnPaint();
      try {
        fn.snap = await window.hub.fanctl.start();
        fn.cfg = { controls: { ...(fn.snap?.config?.controls || {}) } };
        fn.cfgLoaded = true;
        fn.ctl = await window.hub.fanctl.status();
      } catch (err) { fn.err = A.errText(err); }
      fn.starting = false;
      return fnPaint();
    }
    if (e.target.closest('[data-fc-driver]')) {
      fn.starting = true; fn.err = ''; fnPaint();
      try {
        const r = await window.hub.fanctl.installDriver();
        if (!r?.ok) fn.err = 'Der Treiber wurde nicht installiert.';
        fn.ctl = await window.hub.fanctl.status();
      } catch (err) { fn.err = A.errText(err); }
      fn.starting = false;
      return fnPaint();
    }
    if (e.target.closest('[data-fc-stop]')) {
      await window.hub.fanctl.stop().catch(() => {});
      fn.snap = null; fn.cfgLoaded = false;
      A.toast('Lüfter laufen wieder automatisch (BIOS).');
      return fnPaint();
    }
    const mode = e.target.closest('[data-fc-mode]')?.dataset.fcMode;
    if (mode) {
      const id = e.target.closest('[data-fc-port]').dataset.fcPort;
      const c = portCfg(id);
      c.mode = mode;
      if (mode === 'fixed' && c.value == null) c.value = Math.round(fnPorts().find((p) => p.id === id)?.pct ?? 50);
      if (mode === 'curve') { c.points ||= DEF_CURVE.map((p) => [...p]); c.sensor ||= (fnTemps().find((t) => /Tctl|Package|CPU/i.test(t.name) && /cpu/i.test(t.id)) || fnTemps()[0])?.id; }
      fnPaint();
      return fnSave();
    }
  });
  document.addEventListener('input', (e) => {
    if (!fn.root?.contains(e.target) || !e.target.matches('[data-fc-value]')) return;
    const id = e.target.closest('[data-fc-port]').dataset.fcPort;
    portCfg(id).value = Number(e.target.value);
    e.target.nextElementSibling.textContent = `${e.target.value} %`;
    fnSave();
  });
  document.addEventListener('change', (e) => {
    if (!fn.root?.contains(e.target) || !e.target.matches('[data-fc-sensor]')) return;
    portCfg(e.target.closest('[data-fc-port]').dataset.fcPort).sensor = e.target.value;
    fnSave();
  });
  // Kurvenpunkte ziehen
  document.addEventListener('pointerdown', (e) => {
    const pt = e.target.closest?.('[data-fc-pt]');
    if (!pt || !fn.root?.contains(pt)) return;
    const svg = pt.closest('[data-fc-curve]');
    fn.curveDrag = { id: svg.dataset.fcCurve, i: Number(pt.dataset.fcPt), svg };
    e.preventDefault();
  });
  window.addEventListener('pointermove', (e) => {
    const d = fn.curveDrag;
    if (!d) return;
    const r = d.svg.getBoundingClientRect();
    const t = Math.round(20 + ((e.clientX - r.left) / r.width) * 80);
    const p = Math.round(100 - ((e.clientY - r.top) / r.height) * 100);
    const pts = portCfg(d.id).points;
    const lo = d.i > 0 ? pts[d.i - 1][0] + 1 : 20, hi = d.i < pts.length - 1 ? pts[d.i + 1][0] - 1 : 100;
    pts[d.i] = [Math.max(lo, Math.min(hi, t)), Math.max(0, Math.min(100, p))];
    const temp = fnTemps().find((x) => x.id === portCfg(d.id).sensor)?.value;
    d.svg.outerHTML = curveSvg(d.id, pts, temp);
    d.svg = fn.root.querySelector(`[data-fc-curve="${CSS.escape(d.id)}"]`);
  });
  window.addEventListener('pointerup', () => {
    if (!fn.curveDrag) return;
    fn.curveDrag = null;
    fnSave();
  });
  A.define('tool-fans', { nav: 'Lüfter', title: 'Lüfter', sub: 'Alle Lüfter steuern – wie Fan Control', icon: 'refresh', tint: 'linear-gradient(135deg,#67e8f9,#0e7490)', desc: 'Alle Lüfter mit Drehzahl, jeden Anschluss einzeln steuern: Automatik, fester Wert oder Kurve nach Temperatur – direkt im Hub, ohne Fan Control.' }, {
    mount(root) {
      fn.root = root;
      fnPaint();
      fnLoad();
      clearInterval(fn.timer);
      fn.timer = setInterval(fnLoad, 2000);
    },
    unmount() {
      clearInterval(fn.timer);
      fn.root = null;
    },
  });
})();
