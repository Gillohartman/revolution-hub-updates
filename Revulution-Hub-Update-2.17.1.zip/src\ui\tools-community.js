'use strict';

/* Hintergründe, Meldungen und der Admin-Bereich des Hubs. */
(() => {
  const T = window.HubTools;
  if (!T) return;
  const ctx = () => T.ctx();
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hm = (at) => new Date(at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const st = { data: null, loading: false, busy: false, error: '', type: 'bug', app: 'Revulution Hub' };

  async function load(force = false) {
    if (st.loading || (st.data && !force)) return;
    st.loading = true;
    try {
      st.data = await window.hub.community.status();
      st.error = '';
    } catch (e) {
      st.error = e?.message || 'Datenbank nicht erreichbar.';
    } finally {
      st.loading = false;
      if (active()) ctx().render();
    }
  }

  const active = () => Boolean(document.querySelector('[data-tool-page="tool-backgrounds"]'));

  function bgCard(b, admin) {
    return `<div class="bg-card">${b.data ? `<img src="${b.data}" alt="${esc(b.name)}" loading="lazy" />` : '<div class="bg-empty">Kein Vorschaubild</div>'}<div class="bg-meta"><strong>${esc(b.name)}</strong><small>${b.downloads || 0} Downloads · ${hm(b.at)}</small></div><div class="bg-actions"><button class="btn small ghost" data-bg-desktop="${esc(b.id)}">Als Desktop</button><button class="btn small ghost" data-bg-download="${esc(b.id)}">Herunterladen</button>${admin ? `<button class="btn small danger" data-bg-remove="${esc(b.id)}">Löschen</button>` : ''}</div></div>`;
  }

  function html() {
    load();
    const d = st.data;
    const admin = d?.admin === true;
    const reports = d?.reports || [];
    return `<div class="tool-card"><div class="list-row"><div class="grow"><strong>Desktop-Hintergründe</strong><small>${d ? `${d.backgrounds.length} Hintergrund${d.backgrounds.length === 1 ? '' : 'e'} in der Datenbank` : 'Datenbank wird geladen …'}</small></div><button class="btn small ghost" data-bg-admin="${admin ? 'off' : 'on'}">${admin ? 'Admin aktiv' : 'Admin-Bereich'}</button>${admin ? '<input class="input bg-name" data-bg-name placeholder="Name (optional)" maxlength="60" /><button class="btn primary small" data-bg-upload>Hintergrund hochladen</button>' : ''}</div>${st.error ? `<p class="muted">${esc(st.error)}</p>` : ''}<div class="bg-grid">${d?.backgrounds?.length ? d.backgrounds.map((b) => bgCard(b, admin)).join('') : '<div class="bg-empty big">Noch keine Hintergründe. Im Admin-Bereich kannst du Bilder hochladen.</div>'}</div></div>\n    <div class="tool-card"><div class="list-row"><div class="grow"><strong>Bug melden oder Report senden</strong><small>Landet in der lokalen Community-Datenbank und wird im Admin-Bereich angezeigt.</small></div></div><div class="report-form"><select data-report-app>${['Revulution Hub', 'Chats', 'Beat Lab', 'Tastatur & RGB', 'Spiele', 'Dynamic Island', 'Andere App'].map((a) => `<option ${a === st.app ? 'selected' : ''}>${a}</option>`).join('')}</select><select data-report-type><option value="bug" ${st.type === 'bug' ? 'selected' : ''}>Bug</option><option value="report" ${st.type === 'report' ? 'selected' : ''}>Report</option><option value="idea" ${st.type === 'idea' ? 'selected' : ''}>Idee</option></select><textarea data-report-text rows="3" placeholder="Was ist passiert? Welche Schritte führen dazu?"></textarea><button class="btn primary small" data-report-send>Absenden</button></div></div>\n    ${admin ? `<div class="tool-card"><div class="list-row"><div class="grow"><strong>Reports · Admin</strong><small>${reports.filter((r) => r.status !== 'done').length} offen · ${reports.length} gesamt</small></div></div>${reports.length ? `<div class="report-list">${reports.map((r) => `<div class="report-row ${r.status === 'done' ? 'done' : ''}"><div class="grow"><strong>${r.type === 'bug' ? '🐞' : r.type === 'idea' ? '💡' : '📝'} ${esc(r.app)}</strong><p>${esc(r.text)}</p><small>${hm(r.at)} · ${esc(r.by || 'Nutzer')}</small></div><button class="btn small ghost" data-report-done="${esc(r.id)}">${r.status === 'done' ? 'Wieder öffnen' : 'Erledigt'}</button></div>`).join('')}</div>` : '<p class="muted">Noch keine Meldungen.</p>'}</div>` : ''}`;
  }

  T.register(
    'tool-backgrounds',
    { nav: 'Hintergründe', title: 'Hintergründe & Admin', sub: 'Desktop-Bilder, Datenbank, Meldungen', icon: 'image', tint: 'linear-gradient(135deg,#38bdf8,#6366f1)', desc: 'Lade Hintergründe in die Community-Datenbank, setze sie als Windows-Desktop oder lade sie herunter – und melde Bugs direkt an den Admin-Bereich.' },
    html,
  );

  document.addEventListener('click', async (e) => {
    if (!active() || st.busy) return;
    const d = (sel) => e.target.closest?.(sel);
    try {
      if (d('[data-bg-admin]')) {
        st.busy = true;
        const on = d('[data-bg-admin]').dataset.bgAdmin === 'on';
        await window.hub.community.admin(on);
        st.data = await window.hub.community.status();
        return ctx().render();
      }
      if (d('[data-bg-upload]')) {
        const file = await window.hub.community.pick();
        if (!file) return;
        const fallback = file.split(/[\\/]/).pop().replace(/\.[^.]+$/, '');
        const name = document.querySelector('[data-bg-name]')?.value?.trim() || fallback;
        st.busy = true;
        await window.hub.community.add(file, name);
        st.data = await window.hub.community.status();
        ctx().toast('Hintergrund gespeichert.');
        return ctx().render();
      }
      const rm = d('[data-bg-remove]')?.dataset.bgRemove;
      if (rm) {
        st.busy = true;
        await window.hub.community.remove(rm);
        st.data = await window.hub.community.status();
        return ctx().render();
      }
      const desk = d('[data-bg-desktop]')?.dataset.bgDesktop;
      if (desk) {
        st.busy = true;
        await window.hub.community.desktop(desk);
        ctx().toast('Desktop-Hintergrund gesetzt.');
        return ctx().render();
      }
      const dl = d('[data-bg-download]')?.dataset.bgDownload;
      if (dl) {
        st.busy = true;
        const r = await window.hub.community.download(dl);
        const a = document.createElement('a');
        a.href = r.data;
        a.download = r.file || `${r.name}.png`;
        a.click();
        st.data = await window.hub.community.status();
        return ctx().render();
      }
      const done = d('[data-report-done]')?.dataset.reportDone;
      if (done) {
        st.busy = true;
        const row = d('[data-report-done]')?.closest('.report-row');
        await window.hub.community.reportStatus(done, row?.classList.contains('done') ? 'open' : 'done');
        st.data = await window.hub.community.status();
        return ctx().render();
      }
      if (d('[data-report-send]')) {
        st.busy = true;
        await window.hub.community.report({ app: st.app, type: st.type, text: document.querySelector('[data-report-text]')?.value || '' });
        document.querySelector('[data-report-text]').value = '';
        ctx().toast('Danke – die Meldung ist in der Datenbank.');
        st.data = await window.hub.community.status();
        return ctx().render();
      }
    } catch (error) {
      ctx().toast(error.message || 'Das hat nicht geklappt.', 'error');
    } finally {
      st.busy = false;
    }
  });

  document.addEventListener('change', (e) => {
    if (!active()) return;
    if (e.target.matches?.('[data-report-app]')) st.app = e.target.value;
    if (e.target.matches?.('[data-report-type]')) st.type = e.target.value;
  });
})();
