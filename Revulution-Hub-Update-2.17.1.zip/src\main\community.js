'use strict';

/*
 * Kleine lokale Community-Datenbank für Desktop-Hintergründe und Meldungen.
 * Die Daten liegen als JSON + Bilddateien im Hub-Datenordner, damit sie auch
 * ohne Cloud funktionieren. Veröffentlichte Hintergründe kommen über das Hub-Update.
 */
const fs = require('fs');
const path = require('path');

const IMAGE = /\.(png|jpe?g|webp|gif|bmp)$/i;
const clean = (value, max = 80) => String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);

class Community {
  constructor({ dir, getSettings, saveSettings, onChange } = {}) {
    this.dir = path.join(dir, 'community');
    this.imgDir = path.join(this.dir, 'backgrounds');
    this.file = path.join(this.dir, 'community.json');
    this.getSettings = getSettings || (() => ({}));
    this.saveSettings = saveSettings || (() => {});
    this.onChange = onChange || null;
    this.db = this.read();
  }

  ensure() {
    fs.mkdirSync(this.imgDir, { recursive: true });
    if (!fs.existsSync(this.file)) fs.writeFileSync(this.file, JSON.stringify(this.db, null, 2));
  }

  read() {
    try {
      const data = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      return { backgrounds: Array.isArray(data.backgrounds) ? data.backgrounds : [], reports: Array.isArray(data.reports) ? data.reports : [] };
    } catch {
      return { backgrounds: [], reports: [] };
    }
  }

  write() {
    fs.mkdirSync(this.imgDir, { recursive: true });
    fs.writeFileSync(`${this.file}.tmp`, JSON.stringify(this.db, null, 2));
    fs.renameSync(`${this.file}.tmp`, this.file);
    if (this.onChange) this.onChange(this.status());
  }

  imageData(entry) {
    try {
      const file = path.join(this.imgDir, entry.file);
      const stat = fs.statSync(file);
      if (stat.size > 12 * 1024 * 1024) return '';
      const ext = path.extname(file).slice(1).toLowerCase();
      const mime = ext === 'jpg' ? 'jpeg' : ext === 'svg' ? 'svg+xml' : ext;
      return `data:image/${mime};base64,${fs.readFileSync(file).toString('base64')}`;
    } catch {
      return '';
    }
  }

  list() {
    return this.db.backgrounds.map((b) => ({ ...b, data: this.imageData(b) }));
  }

  status() {
    return {
      backgrounds: this.list(),
      reports: this.db.reports.slice().sort((a, b) => b.at - a.at),
      admin: this.getSettings().communityAdmin === true,
    };
  }

  add(file, name) {
    if (!file || !IMAGE.test(file)) throw new Error('Bitte ein Bild (PNG, JPG, WebP, GIF oder BMP) wählen.');
    const src = fs.statSync(file);
    if (!src.isFile() || src.size > 12 * 1024 * 1024) throw new Error('Das Bild darf höchstens 12 MB groß sein.');
    this.ensure();
    const id = `bg-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
    const ext = path.extname(file).toLowerCase();
    const target = `${id}${ext}`;
    fs.copyFileSync(file, path.join(this.imgDir, target));
    const entry = { id, name: clean(name || path.basename(file, ext), 60) || 'Hintergrund', file: target, at: Date.now(), downloads: 0, by: 'Admin' };
    this.db.backgrounds.unshift(entry);
    this.write();
    return { ...entry, data: this.imageData(entry) };
  }

  remove(id) {
    const i = this.db.backgrounds.findIndex((b) => b.id === id);
    if (i < 0) return false;
    const [entry] = this.db.backgrounds.splice(i, 1);
    try {
      fs.rmSync(path.join(this.imgDir, entry.file), { force: true });
    } catch {
      /* egal */
    }
    this.write();
    return true;
  }

  download(id) {
    const entry = this.db.backgrounds.find((b) => b.id === id);
    if (!entry) throw new Error('Hintergrund nicht gefunden.');
    entry.downloads = (entry.downloads || 0) + 1;
    this.write();
    return { name: entry.name, file: entry.file, data: this.imageData(entry) };
  }

  /** Windows-Desktop-Hintergrund setzen (füllt den Bildschirm). */
  async desktop(id) {
    const entry = this.db.backgrounds.find((b) => b.id === id);
    if (!entry) throw new Error('Hintergrund nicht gefunden.');
    const file = path.join(this.imgDir, entry.file);
    if (!fs.existsSync(file)) throw new Error('Bilddatei fehlt.');
    const dst = path.join(this.dir, 'desktop-wallpaper' + path.extname(file));
    fs.copyFileSync(file, dst);
    const { execFile } = require('child_process');
    const script = `Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public class W { [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int SystemParametersInfo(int a,int b,string c,int d); }'; [W]::SystemParametersInfo(20,0,'${dst.replace(/'/g, "''")}',3)`;
    await new Promise((resolve, reject) => {
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout: 15000 }, (error, stdout, stderr) => (error ? reject(new Error((stderr || error.message).trim().split(/\r?\n/)[0])) : resolve(stdout)));
    });
    this.saveSettings({ desktopBackground: id });
    return true;
  }

  report({ type = 'bug', text = '', app = 'Revulution Hub' } = {}) {
    const body = clean(text, 2000);
    if (body.length < 4) throw new Error('Bitte beschreibe das Problem kurz.');
    const entry = {
      id: `report-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      type: type === 'idea' ? 'idea' : type === 'report' ? 'report' : 'bug',
      text: body,
      app: clean(app, 40) || 'Revulution Hub',
      at: Date.now(),
      status: 'open',
      by: this.getSettings().profile?.name || 'Nutzer',
    };
    this.db.reports.unshift(entry);
    this.db.reports = this.db.reports.slice(0, 500);
    this.write();
    return entry;
  }

  setReport(id, status) {
    const r = this.db.reports.find((x) => x.id === id);
    if (!r) return false;
    r.status = ['open', 'done'].includes(status) ? status : 'open';
    this.write();
    return true;
  }

  setAdmin(on) {
    this.saveSettings({ communityAdmin: Boolean(on) });
    this.write();
    return true;
  }
}

module.exports = { Community };
