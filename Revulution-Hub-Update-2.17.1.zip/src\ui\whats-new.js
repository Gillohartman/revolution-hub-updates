'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.17.1',
  title: 'Revulution Hub 2.17.1',
  sub: 'Klick auf einen Eintrag – du landest direkt dort. Oben links kommst du jederzeit hierher zurück.',
  items: [
    { open: 'orbit', icon: 'island', title: 'Alte Orbit-Island-App gesperrt', text: 'Der Einstieg „Island-Fenster“ ist weg. Alte Startmenü-Verknüpfungen werden entfernt und eine alte Orbit-Island-Installation kann sich nicht mehr neben dem Hub öffnen – auch nicht über einen Song-Recognition-Token.' },
    { open: 'tool-keyboard', icon: 'keyboard', title: 'Tastatur-RGB separat', text: 'Die AJAZZ hat jetzt einen eigenen RGB-Bereich mit Modi, Farbe, Helligkeit, Tempo und einer Vorschau – unabhängig vom Mainboard. Die PC-LEDs folgen Verlauf, Zweifarbig und Farbverläufen jetzt pro Zone.' },
    { open: 'tool-keyboard', icon: 'keyboard', title: 'Vorlagen mit echter Vorschau', text: 'Die Display-Vorlagen zeigen oben dieselbe Bildkachel wie die GIFs – du siehst vorher, wie Uhr, Text, Regenbogen und PC-Werte auf der Tastatur aussehen.' },
    { open: 'beat', icon: 'music', title: 'Beat Lab: leer starten, tiefer und höher', text: '„Neues Projekt“ öffnet ein leeres Projekt. Bass und Lead haben mehr tiefe und hohe Noten, dazu die Presets „Sub (tief)“ und „Air (hoch)“.' },
    { open: 'chats', icon: 'chat', title: 'Verpasste Anrufe im Chat', text: 'Anrufe, die niemand annimmt, stehen jetzt als „Verpasster Anruf“ im Chat. Der aktive Anruf erscheint zusätzlich in der Dynamic Island – mit deutschem Status.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Hintergründe, Reports & Admin', text: 'Neue Seite für Desktop-Hintergründe mit Upload, Download und „Als Desktop“. Bug-Meldungen und Reports landen in der Datenbank und werden im Admin-Bereich verwaltet.' },
    { open: 'home', icon: 'spark', title: 'Weniger runde Ecken', text: 'Alle Apps haben etwas kantigere Karten, Buttons und Fenster – nur ein bisschen, Kreise bleiben rund.' },
  ],
};
