'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('admin', {
  status: () => ipcRenderer.invoke('admin:status'),
  pick: () => ipcRenderer.invoke('admin:pick'),
  add: (file, name) => ipcRenderer.invoke('admin:add', file, name),
  remove: (id) => ipcRenderer.invoke('admin:remove', id),
  desktop: (id) => ipcRenderer.invoke('admin:desktop', id),
  reportStatus: (id, status) => ipcRenderer.invoke('admin:report-status', id, status),
  openData: () => ipcRenderer.invoke('admin:open-data'),
  path: () => ipcRenderer.invoke('admin:path'),
});
