'use strict';

/*
 * Revolution Hub Admin – eigene App für Hintergründe und Meldungen.
 * Startet über "Revolution Hub.exe --admin" (bzw. electron . --admin) und hat
 * mit der normalen Hub-Oberfläche nichts zu tun. Die Datenbank bleibt dieselbe.
 */
const { app, BrowserWindow, Menu, dialog, ipcMain, shell } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Community } = require('../main/community');

function start() {
  const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dataRoot = path.join(appData, 'Revolution Hub');
  app.setName('Revulution Hub Admin');
  app.setPath('userData', path.join(appData, 'Revolution Hub Admin'));
  if (process.platform === 'win32') app.setAppUserModelId('com.revolution.hub.admin');

  if (!app.requestSingleInstanceLock()) {
    app.quit();
    return;
  }

  const community = new Community({ dir: dataRoot, getSettings: () => ({}), saveSettings: () => {} });
  community.ensure();
  let win = null;

  const createWindow = () => {
    const icon = path.join(__dirname, '..', 'ui', 'assets', 'logo.png');
    win = new BrowserWindow({
      width: 1180,
      height: 800,
      minWidth: 860,
      minHeight: 560,
      show: false,
      backgroundColor: '#09090d',
      autoHideMenuBar: true,
      title: 'Revulution Hub Admin',
      ...(fs.existsSync(icon) ? { icon } : {}),
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
      },
    });
    win.loadFile(path.join(__dirname, 'index.html'));
    win.once('ready-to-show', () => win.show());
    win.on('closed', () => {
      win = null;
    });
  };

  ipcMain.handle('admin:status', () => community.adminStatus());
  ipcMain.handle('admin:pick', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'Hintergrundbilder auswählen',
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'Bilder', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'] }],
    });
    return r.canceled ? [] : r.filePaths;
  });
  ipcMain.handle('admin:add', (event, file, name) => community.add(String(file || ''), String(name || '')));
  ipcMain.handle('admin:remove', (event, id) => community.remove(String(id || '')));
  ipcMain.handle('admin:desktop', (event, id) => community.desktop(String(id || '')));
  ipcMain.handle('admin:report-status', (event, id, status) => community.setReport(String(id || ''), String(status || 'open')));
  ipcMain.handle('admin:open-data', async () => {
    const error = await shell.openPath(dataRoot);
    if (error) throw new Error(error);
    return true;
  });
  ipcMain.handle('admin:path', () => dataRoot);

  app.on('second-instance', () => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
  });

  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    createWindow();
    app.on('activate', () => {
      if (!win) createWindow();
    });
  });
  app.on('window-all-closed', () => app.quit());
}

module.exports = { start };
