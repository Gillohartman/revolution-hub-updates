'use strict';

/*
 * Windows-Taskleisten-Apps für die Revulution-Leiste:
 * angeheftete Verknüpfungen und laufende Fenster, inklusive echter Symbole.
 * Die Symbole werden als PNG zwischengespeichert, damit die Leiste sie ohne
 * Zugriff auf fremde Programme laden kann.
 */
const { execFile, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { app, shell } = require('electron');

const CACHE = path.join(app.getPath('userData'), 'windows-taskbar');
let entries = [];
let busy = null;
let last = 0;

function iconUrl(file) {
  if (!file) return '';
  try {
    return require('url').pathToFileURL(file).href;
  } catch {
    return '';
  }
}

const SCRIPT = String.raw`
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Drawing
$dir = $env:REV_TASKBAR_ICONS
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Get-ChildItem -LiteralPath $dir -Filter '*.png' -ErrorAction SilentlyContinue | Remove-Item -Force
$shell = New-Object -ComObject WScript.Shell
$items = New-Object System.Collections.ArrayList
$seen = @{}

function Save-Icon([string]$source, [string]$prefix) {
  try {
    if (-not $source) { return $null }
    $ico = [System.Drawing.Icon]::ExtractAssociatedIcon($source)
    if ($null -eq $ico) { return $null }
    $bmp = $ico.ToBitmap()
    $file = Join-Path $dir ($prefix + '_' + [Guid]::NewGuid().ToString('N') + '.png')
    $bmp.Save($file, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    $ico.Dispose()
    return $file
  } catch { return $null }
}

$pinnedDir = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
Get-ChildItem -LiteralPath $pinnedDir -Filter '*.lnk' -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object {
  $lnk = $_.FullName
  $target = ''
  try { $target = $shell.CreateShortcut($lnk).TargetPath } catch {}
  $key = if ($target) { $target.ToLowerInvariant() } else { $lnk.ToLowerInvariant() }
  if ($seen.ContainsKey($key)) { return }
  $seen[$key] = $true
  $icon = Save-Icon $(if ($target) { $target } else { $lnk }) 'pin'
  $name = [System.IO.Path]::GetFileNameWithoutExtension($_.Name)
  if ($name -match '(?i)revulution|revolution hub') { return }
  [void]$items.Add([pscustomobject]@{
    id = 'pin:' + $_.BaseName
    name = $name
    icon = $icon
    kind = 'pinned'
    path = $lnk
    target = $target
    handle = 0
  })
}

$self = $PID
Get-Process -ErrorAction SilentlyContinue | Where-Object {
  $_.MainWindowHandle -ne 0 -and $_.Path -and $_.Id -ne $self -and
  $_.ProcessName -notmatch '^(electron|Revulution|RevulutionHub|TextInputHost|ApplicationFrameHost|ShellExperienceHost|StartMenuExperienceHost|SearchHost|Widgets|LockApp|NVIDIA|NVIDIA Overlay|NVDisplay\.Container)$'
} | Sort-Object StartTime | ForEach-Object {
  $exe = $_.Path
  $key = $exe.ToLowerInvariant()
  if ($exe -match '(?i)Revolution Hub|electron\.exe') { return }
  if ($seen.ContainsKey($key)) { return }
  $seen[$key] = $true
  $icon = Save-Icon $exe 'run'
  $name = [System.IO.Path]::GetFileNameWithoutExtension($exe)
  if ($_.ProcessName -eq 'explorer') { $name = 'Explorer' }
  [void]$items.Add([pscustomobject]@{
    id = 'run:' + $_.Id
    pid = [int]$_.Id
    name = $name
    icon = $icon
    kind = 'running'
    path = $exe
    target = $exe
    handle = [int64]$_.MainWindowHandle
    title = $_.MainWindowTitle
  })
}

$items | Select-Object -First 18 | ConvertTo-Json -Compress -Depth 3
`;

function parse(raw) {
  const text = String(raw || '').trim();
  if (!text) return [];
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return [];
  }
  const list = Array.isArray(parsed) ? parsed : [parsed];
  return list
    .filter((item) => item && item.id && item.name)
    .map((item) => ({
      id: String(item.id),
      name: String(item.name).slice(0, 54),
      icon: iconUrl(item.icon ? String(item.icon) : ''),
      kind: item.kind === 'running' ? 'running' : 'pinned',
      path: String(item.path || ''),
      target: String(item.target || ''),
      handle: Number(item.handle) || 0,
      pid: Number(item.pid) || 0,
    }));
}

async function refresh(force = false) {
  if (process.platform !== 'win32') return entries;
  if (busy) return busy;
  if (!force && Date.now() - last < 15000) return entries;
  busy = (async () => {
    try {
      fs.mkdirSync(CACHE, { recursive: true });
    } catch {
      /* Cache ist optional */
    }
    const out = await new Promise((resolve) => {
      execFile(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', SCRIPT],
        { windowsHide: true, timeout: 15000, maxBuffer: 4 * 1024 * 1024, env: { ...process.env, REV_TASKBAR_ICONS: CACHE } },
        (error, stdout) => resolve(error ? '' : stdout),
      );
    });
    const next = parse(out);
    if (next.length) entries = next;
    last = Date.now();
    return entries;
  })();
  try {
    return await busy;
  } finally {
    busy = null;
  }
}

function find(id) {
  return entries.find((entry) => entry.id === id) || null;
}

async function focusRunning(entry) {
  if (!entry.handle) return false;
  const script = `$ErrorActionPreference='SilentlyContinue'; Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class RevFocus { [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); }'; $h=[IntPtr]${Number(entry.handle)}; [RevFocus]::ShowWindow($h,9); [RevFocus]::SetForegroundWindow($h)`;
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 5000 }, (error) => resolve(!error));
  });
}

async function launch(id) {
  const entry = find(id);
  if (!entry) return false;
  if (entry.kind === 'running' && entry.handle) {
    const focused = await focusRunning(entry);
    if (focused) return true;
  }
  if (entry.kind === 'pinned' && entry.path) {
    const error = await shell.openPath(entry.path).catch(() => 'open failed');
    if (!error) return true;
    const child = spawn('cmd.exe', ['/c', 'start', '', entry.path], { windowsHide: true, detached: true, stdio: 'ignore' });
    child.unref();
    return true;
  }
  if (entry.target) {
    const error = await shell.openPath(entry.target).catch(() => 'open failed');
    if (!error) return true;
    spawn(entry.target, [], { windowsHide: true, detached: true, stdio: 'ignore' }).unref();
    return true;
  }
  return false;
}

async function closeWindow(id) {
  const entry = find(id);
  if (!entry || !entry.handle) return false;
  const script = `$ErrorActionPreference='SilentlyContinue'; Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class RevClose { [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l); }'; [RevClose]::PostMessage([IntPtr]${Number(entry.handle)},0x0010,[IntPtr]::Zero,[IntPtr]::Zero)`;
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 5000 }, (error) => resolve(!error));
  });
}

async function endTask(id) {
  const entry = find(id);
  if (!entry) return false;
  if (entry.pid) {
    return new Promise((resolve) => {
      execFile('taskkill.exe', ['/PID', String(entry.pid), '/T', '/F'], { windowsHide: true, timeout: 8000 }, (error) => resolve(!error));
    });
  }
  if (!entry.target) return false;
  const script = "$ErrorActionPreference='SilentlyContinue'; Get-Process | Where-Object { $_.Path -eq $env:REV_TARGET } | Stop-Process -Force";
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], {
      windowsHide: true,
      timeout: 8000,
      env: { ...process.env, REV_TARGET: entry.target },
    }, (error) => resolve(!error));
  });
}

async function pin(id) {
  const entry = find(id);
  if (!entry || entry.kind === 'pinned' || !entry.target) return false;
  const script = `$ErrorActionPreference='Stop'; $dir=Join-Path $env:APPDATA 'Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\TaskBar'; New-Item -ItemType Directory -Force -Path $dir | Out-Null; $file=Join-Path $dir ($env:REV_NAME + '.lnk'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($file); $s.TargetPath=$env:REV_TARGET; $s.WorkingDirectory=Split-Path $env:REV_TARGET; $s.IconLocation=($env:REV_TARGET + ',0'); $s.Save()`;
  const name = String(entry.name || 'App').replace(/[\\/:*?"<>|]/g, '').slice(0, 54) || 'App';
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], {
      windowsHide: true,
      timeout: 8000,
      env: { ...process.env, REV_NAME: name, REV_TARGET: entry.target },
    }, (error) => resolve(!error));
  });
}

async function unpin(id) {
  const entry = find(id);
  if (!entry || entry.kind !== 'pinned' || !entry.path) return false;
  try {
    const pinnedDir = path.join(process.env.APPDATA || '', 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned', 'TaskBar');
    const resolved = path.resolve(entry.path);
    if (!resolved.startsWith(path.resolve(pinnedDir) + path.sep) || path.extname(resolved).toLowerCase() !== '.lnk') return false;
    fs.unlinkSync(resolved);
    return true;
  } catch {
    return false;
  }
}

function reveal(id) {
  const entry = find(id);
  if (!entry) return false;
  const target = entry.target || entry.path;
  if (!target) return false;
  shell.showItemInFolder(target);
  return true;
}

module.exports = { refresh, launch, closeWindow, endTask, pin, unpin, reveal, list: () => entries };
