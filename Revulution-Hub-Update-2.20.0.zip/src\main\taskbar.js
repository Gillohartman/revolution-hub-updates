'use strict';

/*
 * Windows-Taskleiste ausblenden, solange der Hub sichtbar ist.
 * Das Revulution-Dock übernimmt dann die Rolle der Taskleiste. Beim Minimieren,
 * Verstecken oder Beenden wird die Windows-Taskleiste immer wieder eingeblendet.
 */
const { execFile, execFileSync, spawn } = require('child_process');

const SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class RevTaskbar {
  private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr extra);
  [DllImport("user32.dll")] private static extern int GetClassName(IntPtr hWnd, StringBuilder name, int max);
  [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int command);
  [DllImport("user32.dll")] private static extern void keybd_event(byte virtualKey, byte scan, uint flags, UIntPtr extra);
  private static int command = 5;
  private static bool Visit(IntPtr hWnd, IntPtr extra) {
    var name = new StringBuilder(64);
    GetClassName(hWnd, name, name.Capacity);
    var cls = name.ToString();
    if (cls == "Shell_TrayWnd" || cls == "Shell_SecondaryTrayWnd") ShowWindow(hWnd, command);
    return true;
  }
  public static void SetVisible(bool visible) {
    command = visible ? 5 : 0;
    EnumWindows(Visit, IntPtr.Zero);
  }
  public static void StartMenu() {
    keybd_event(0x5B, 0, 0, UIntPtr.Zero);
    keybd_event(0x5B, 0, 2, UIntPtr.Zero);
  }
}
'@
if (-not ('RevTaskbar' -as [type])) { Write-Output 'fail'; exit 1 }
if ($env:REVTASKBAR_ACTION -eq 'start') { [RevTaskbar]::StartMenu() }
else { [RevTaskbar]::SetVisible($env:REVTASKBAR_VISIBLE -eq '1') }
Write-Output 'ok'
`;

const encodedScript = Buffer.from(SCRIPT, 'utf16le').toString('base64');
const PS_ARGS = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encodedScript];

/*
 * Windows-Taste: Windows reserviert das Kürzel für sein Startmenü, deshalb
 * registriert Electron es nicht zuverlässig. Der kleine Beobachter erkennt
 * einen einzelnen Druck (ohne Kombination), meldet ihn an den Hub und schließt
 * das Startmenü, damit die Revulution-App-Übersicht sichtbar bleibt.
 */
const WINKEY_SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class RevWinKey {
  private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int vKey);
  [DllImport("user32.dll")] private static extern void keybd_event(byte virtualKey, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr extra);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(IntPtr hWnd, StringBuilder name, int max);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowText(IntPtr hWnd, StringBuilder name, int max);
  [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern bool IsZoomed(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int command);
  [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  private static bool Visit(IntPtr hWnd, IntPtr extra) {
    if (!IsWindowVisible(hWnd)) return true;
    var cls = new StringBuilder(64);
    GetClassName(hWnd, cls, cls.Capacity);
    var title = new StringBuilder(64);
    GetWindowText(hWnd, title, title.Capacity);
    uint pid;
    GetWindowThreadProcessId(hWnd, out pid);
    string proc = "";
    try { proc = System.Diagnostics.Process.GetProcessById((int)pid).ProcessName; } catch { }
    if (proc == "StartMenuExperienceHost" || (cls.ToString() == "Windows.UI.Core.CoreWindow" && (title.ToString() == "Start" || title.ToString() == "Startmenü"))) {
      ShowWindow(hWnd, 0);
    }
    return true;
  }
  public static bool WinDown() { return (GetAsyncKeyState(0x5B) & 0x8000) != 0; }
  public static bool OtherDown() {
    for (int key = 8; key < 255; key++) {
      if (key == 0x5B || key == 0x5C) continue;
      // Media-/Browser-Tasten können auf manchen Geräten dauerhaft als gedrückt
      // gemeldet werden und dürfen die Windows-Taste nicht blockieren.
      if ((key >= 0xA6 && key <= 0xAF) || (key >= 0xB0 && key <= 0xBF)) continue;
      if ((GetAsyncKeyState(key) & 0x8000) != 0) return true;
    }
    return false;
  }
  public static void CloseStart() {
    for (int i = 0; i < 10; i++) {
      EnumWindows(Visit, IntPtr.Zero);
      System.Threading.Thread.Sleep(60);
    }
  }
}
'@
$was = $false
while ($true) {
  $down = [RevWinKey]::WinDown()
  if ($was -and -not $down -and -not [RevWinKey]::OtherDown()) {
    [Console]::Out.WriteLine('win')
    [Console]::Out.Flush()
    Start-Sleep -Milliseconds 30
    [RevWinKey]::CloseStart()
  }
  $was = $down
  Start-Sleep -Milliseconds 25
}
`;

/** @returns {() => void} stop function */
function watchWindowsKey(callback) {
  if (process.platform !== 'win32') return () => {};
  let stopped = false;
  let buffer = '';
  const proc = spawn(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(WINKEY_SCRIPT, 'utf16le').toString('base64')],
    { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] },
  );
  proc.stdout.setEncoding('utf8');
  proc.stdout.on('data', (chunk) => {
    buffer += chunk;
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() || '';
    for (const line of lines) {
      if (line.trim() === 'win' && !stopped) callback();
    }
  });
  return () => {
    stopped = true;
    try {
      proc.kill();
    } catch {
      /* Prozess ist schon weg. */
    }
  };
}

/*
 * Ein kleiner, dauerhaft laufender Beobachter: Erkennt, ob im Vordergrund ein
 * randloses Vollbildfenster liegt. Dann blendet der Hub seine Taskleiste aus.
 * Einmal gestartet kostet das kaum CPU – kein PowerShell-Start pro Messung.
 */
const FULLSCREEN_SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class RevFullscreen {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags; }
  [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
  [DllImport("user32.dll")] private static extern IntPtr MonitorFromWindow(IntPtr hWnd, uint flags);
  [DllImport("user32.dll")] private static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO info);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(IntPtr hWnd, StringBuilder name, int max);
  [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
  public static bool Check() {
    var hWnd = GetForegroundWindow();
    if (hWnd == IntPtr.Zero || !IsWindowVisible(hWnd)) return false;
    if (IsZoomed(hWnd)) return false;
    var name = new StringBuilder(64);
    GetClassName(hWnd, name, name.Capacity);
    var cls = name.ToString();
    if (cls == "Progman" || cls == "WorkerW" || cls == "Shell_TrayWnd" || cls == "Shell_SecondaryTrayWnd") return false;
    RECT rect;
    if (!GetWindowRect(hWnd, out rect)) return false;
    var info = new MONITORINFO();
    info.cbSize = Marshal.SizeOf(info);
    var monitor = MonitorFromWindow(hWnd, 2);
    if (!GetMonitorInfo(monitor, ref info)) return false;
    return rect.Left <= info.rcMonitor.Left + 2 && rect.Top <= info.rcMonitor.Top + 2 &&
           rect.Right >= info.rcMonitor.Right - 2 && rect.Bottom >= info.rcMonitor.Bottom - 2;
  }
}
'@
while ($true) {
  [Console]::Out.WriteLine($(if ([RevFullscreen]::Check()) { '1' } else { '0' }))
  [Console]::Out.Flush()
  Start-Sleep -Milliseconds 850
}
`;

/** @returns {() => void} stop function */
function watchFullscreen(callback) {
  if (process.platform !== 'win32') return () => {};
  let stopped = false;
  let buffer = '';
  let last = '';
  const proc = spawn(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(FULLSCREEN_SCRIPT, 'utf16le').toString('base64')],
    { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] },
  );
  const emit = (value) => {
    if (stopped || value === last) return;
    last = value;
    callback(value === '1');
  };
  proc.stdout.setEncoding('utf8');
  proc.stdout.on('data', (chunk) => {
    buffer += chunk;
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() || '';
    for (const line of lines) {
      const value = line.trim();
      if (value === '0' || value === '1') emit(value);
    }
  });
  proc.on('error', () => emit('0'));
  proc.on('exit', () => emit('0'));
  return () => {
    stopped = true;
    try {
      proc.kill();
    } catch {
      /* Prozess ist schon weg. */
    }
  };
}

let applied = false;
let desired = false;
let chain = Promise.resolve();

function psEnv(action, visible) {
  return {
    ...process.env,
    REVTASKBAR_ACTION: action,
    REVTASKBAR_VISIBLE: visible ? '1' : '0',
  };
}

function run(action, visible) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve(false);
    execFile(
      'powershell.exe',
      PS_ARGS,
      { windowsHide: true, timeout: 15000, env: psEnv(action, visible) },
      (error, stdout) => resolve(!error && String(stdout || '').includes('ok')),
    );
  });
}

/** @returns {Promise<boolean>} */
function setHidden(value, force = false) {
  if (process.platform !== 'win32') return Promise.resolve(false);
  desired = Boolean(value);
  // Serialize visibility calls: a quick close while enabling must never race the
  // hide, otherwise the taskbar could stay hidden after the app is gone.
  chain = chain.then(async () => {
    if (!force && applied === desired) return true;
    const target = desired;
    const ok = await run('visibility', !target);
    if (ok) applied = target;
    return ok;
  });
  return chain;
}

/** Blocking safety net for app shutdown / crashes. */
function restoreSync() {
  if (process.platform !== 'win32') return;
  if (!applied && !desired) return;
  try {
    execFileSync('powershell.exe', PS_ARGS, { windowsHide: true, timeout: 8000, env: psEnv('visibility', true) });
  } catch {
    /* Beim Beenden darf nichts mehr blockieren. */
  }
  applied = false;
  desired = false;
}

function startMenu() {
  return run('start', true);
}

module.exports = { setHidden, startMenu, restoreSync, watchFullscreen, watchWindowsKey };
