'use strict';

(() => {
  const $ = (sel) => document.querySelector(sel);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const when = (at) => new Date(at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
  const state = { data: null, tab: 'backgrounds', filter: 'open', busy: false, error: '' };

  let toastTimer = 0;
  function toast(message, error = false) {
    const el = $('#toast');
    el.textContent = message;
    el.className = `toast show${error ? ' error' : ''}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.className = 'toast'; }, 3200);
  }

  function setBusy(on) {
    state.busy = on;
    document.querySelectorAll('button').forEach((btn) => {
      if (btn.id === 'upload' || btn.dataset.bgRemove || btn.dataset.bgDesktop || btn.dataset.reportToggle) btn.disabled = on;
    });
  }

  async function refresh(force = false) {
    if (state.busy && !force) return;
    try {
      state.data = await window.admin.status();
      state.error = '';
    } catch (error) {
      state.error = error?.message || 'Datenbank nicht erreichbar.';
    }
    render();
  }

  function bgCard(b) {
    return `<div class="bg-card">
      ${b.data ? `<img src="${b.data}" alt="${esc(b.name)}" loading="lazy" />` : '<div class="bg-empty">Kein Vorschaubild</div>'}
      <div class="bg-meta"><strong>${esc(b.name)}</strong><small>${b.downloads || 0} Downloads · ${when(b.at)}</small></div>
      <div class="bg-actions">
        <button class="btn" data-bg-desktop="${esc(b.id)}">Als Desktop</button>
        <button class="btn danger" data-bg-remove="${esc(b.id)}">Löschen</button>
      </div>
    </div>`;
  }

  function reportCard(r) {
    const type = r.type === 'idea' ? 'Idee' : r.type === 'report' ? 'Report' : 'Bug';
    return `<div class="report-row${r.status === 'done' ? ' done' : ''}">
      <div class="report-main">
        <div class="report-head"><span class="type ${esc(r.type || 'bug')}">${type}</span><strong>${esc(r.app || 'Revulution Hub')}</strong><small>${when(r.at)} · ${esc(r.by || 'Nutzer')}</small></div>
        <p>${esc(r.text)}</p>
      </div>
      <button class="btn" data-report-toggle="${esc(r.id)}">${r.status === 'done' ? 'Wieder öffnen' : 'Erledigt'}</button>
    </div>`;
  }

  function render() {
    const d = state.data;
    const bgs = d?.backgrounds || [];
    const reports = d?.reports || [];
    const open = reports.filter((r) => r.status !== 'done').length;
    const downloads = bgs.reduce((sum, b) => sum + (Number(b.downloads) || 0), 0);

    $('#stat-bg').textContent = d ? bgs.length : '–';
    $('#stat-dl').textContent = d ? downloads : '–';
    $('#stat-open').textContent = d ? open : '–';
    $('#tab-bg').textContent = bgs.length;
    $('#tab-reports').textContent = reports.length;

    document.querySelectorAll('[data-tab]').forEach((btn) => btn.classList.toggle('on', btn.dataset.tab === state.tab));
    $('#panel-backgrounds').hidden = state.tab !== 'backgrounds';
    $('#panel-reports').hidden = state.tab !== 'reports';

    const empty = $('#empty');
    if (state.error) {
      empty.hidden = false;
      empty.textContent = state.error;
    } else {
      empty.hidden = true;
    }

    const grid = $('#bg-grid');
    grid.innerHTML = bgs.length ? bgs.map(bgCard).join('') : '<div class="bg-empty big">Noch keine Hintergründe. Klicke auf „Bilder hinzufügen“, um den ersten hochzuladen.</div>';

    const filtered = reports.filter((r) => state.filter === 'all' || (state.filter === 'done' ? r.status === 'done' : r.status !== 'done'));
    $('#report-list').innerHTML = filtered.length
      ? filtered.map(reportCard).join('')
      : `<div class="empty">${state.filter === 'done' ? 'Noch keine erledigten Meldungen.' : 'Keine offenen Meldungen. Alles erledigt.'}</div>`;
  }

  async function upload() {
    if (state.busy) return;
    try {
      const files = await window.admin.pick();
      if (!files.length) return;
      setBusy(true);
      let added = 0;
      const errors = [];
      for (const file of files) {
        const name = String(file).split(/[\\/]/).pop().replace(/\.[^.]+$/, '');
        try {
          await window.admin.add(file, name);
          added++;
        } catch (error) {
          errors.push(`${name}: ${error.message || 'Fehler'}`);
        }
      }
      await refresh(true);
      if (added) toast(`${added} Hintergrund${added === 1 ? '' : 'e'} hinzugefügt.`);
      if (errors.length) toast(errors[0], true);
    } catch (error) {
      toast(error.message || 'Bilder konnten nicht geladen werden.', true);
    } finally {
      setBusy(false);
    }
  }

  document.addEventListener('click', async (event) => {
    const target = event.target.closest?.('button');
    if (!target || state.busy) return;

    if (target.dataset.tab) {
      state.tab = target.dataset.tab;
      render();
      return;
    }
    if (target.id === 'upload') return upload();
    if (target.id === 'refresh') return refresh();
    if (target.id === 'open-data') {
      try {
        await window.admin.openData();
      } catch (error) {
        toast(error.message || 'Ordner konnte nicht geöffnet werden.', true);
      }
      return;
    }

    const remove = target.dataset.bgRemove;
    if (remove) {
      const bg = state.data?.backgrounds?.find((b) => b.id === remove);
      if (!bg || !window.confirm(`„${bg.name}“ wirklich aus der Datenbank löschen?`)) return;
      setBusy(true);
      try {
        await window.admin.remove(remove);
        await refresh(true);
        toast('Hintergrund gelöscht.');
      } catch (error) {
        toast(error.message || 'Löschen fehlgeschlagen.', true);
      } finally {
        setBusy(false);
      }
      return;
    }

    const desk = target.dataset.bgDesktop;
    if (desk) {
      setBusy(true);
      try {
        await window.admin.desktop(desk);
        toast('Desktop-Hintergrund gesetzt.');
      } catch (error) {
        toast(error.message || 'Desktop-Hintergrund konnte nicht gesetzt werden.', true);
      } finally {
        setBusy(false);
      }
      return;
    }

    const reportId = target.dataset.reportToggle;
    if (reportId) {
      const report = state.data?.reports?.find((r) => r.id === reportId);
      setBusy(true);
      try {
        await window.admin.reportStatus(reportId, report?.status === 'done' ? 'open' : 'done');
        await refresh(true);
        toast(report?.status === 'done' ? 'Meldung wieder geöffnet.' : 'Meldung als erledigt markiert.');
      } catch (error) {
        toast(error.message || 'Meldung konnte nicht geändert werden.', true);
      } finally {
        setBusy(false);
      }
    }
  });

  document.addEventListener('change', (event) => {
    if (event.target.id === 'report-filter') {
      state.filter = event.target.value;
      render();
    }
  });

  window.admin.path().then((p) => { $('#db-path').textContent = p; }).catch(() => {});
  refresh();
  setInterval(() => { if (!state.busy && state.tab === 'reports') refresh(); }, 15000);
})();
