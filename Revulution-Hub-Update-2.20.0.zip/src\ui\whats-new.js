'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.20.0',
  title: 'Revulution Hub 2.20.0',
  sub: 'Die Revulution-Leiste ist jetzt kompakt, transparent und verbindet sich nahtlos mit dem Startmenü.',
  items: [
    { open: 'home', icon: 'spark', title: 'Kompakte, transparente Leiste', text: 'Die obere Leiste ist flacher, App-Symbole und Funktionen stehen ohne schwarze Kacheln direkt auf dem Hintergrund. Nur Symbole und Uhr bleiben schwarz.' },
    { open: 'settings', icon: 'control', title: 'Nahtloses Windows-Menü', text: 'Beim Drücken der Windows-Taste wächst das Popup direkt aus der Leiste – ohne Lücke. Das alte Windows-Startmenü und die untere Leiste werden zuverlässig ausgeblendet.' },
    { open: 'home', icon: 'layers', title: 'Ruhig und flackerfrei', text: 'Die Leiste bleibt beim Klicken und Fensterwechsel sichtbar. Nur echte Vollbild-Apps blenden sie noch aus; maximierte Fenster zählen nicht mehr als Vollbild.' },
    { open: 'home', icon: 'spark', title: 'Rechtsklick wie in Windows', text: 'Rechtsklick auf eine App öffnet die gewohnten Aktionen – öffnen, Fenster schließen, anheften oder lösen, Dateispeicherort – plus „Task beenden“.' },
  ],
};
