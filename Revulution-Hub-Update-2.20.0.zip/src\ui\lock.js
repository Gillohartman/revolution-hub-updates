'use strict';

(() => {
  const $ = (selector) => document.querySelector(selector);
  const clock = $('#clock');
  const date = $('#date');
  const state = $('#state');
  const lock = $('#lock');
  let payload = null;

  const pad = (n) => String(n).padStart(2, '0');
  const timeFmt = new Intl.DateTimeFormat('de-DE', { hour: '2-digit', minute: '2-digit' });
  const dateFmt = new Intl.DateTimeFormat('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });

  function paintClock() {
    const now = new Date();
    clock.textContent = timeFmt.format(now);
    date.textContent = dateFmt.format(now);
    clock.setAttribute('datetime', now.toISOString());
    document.title = `${timeFmt.format(now)} · Gesperrt`;
  }

  function setLocked(locked) {
    lock.classList.toggle('unlocked', !locked);
    state.textContent = locked ? 'GESPERRT' : 'ENTSPERRT';
  }

  function weatherText(code) {
    const map = {
      0: 'Klar', 1: 'Überwiegend klar', 2: 'Teils bewölkt', 3: 'Bewölkt',
      45: 'Nebel', 48: 'Reifnebel', 51: 'Leichter Niesel', 53: 'Niesel', 55: 'Starker Niesel',
      61: 'Leichter Regen', 63: 'Regen', 65: 'Starker Regen', 71: 'Leichter Schneefall',
      73: 'Schneefall', 75: 'Starker Schneefall', 80: 'Regenschauer', 81: 'Schauer',
      82: 'Starke Schauer', 95: 'Gewitter', 96: 'Gewitter mit Hagel', 99: 'Starkes Gewitter',
    };
    return map[code] || 'Außen';
  }

  async function loadWeather() {
    const hubState = await window.hub.state().catch(() => null);
    const city = hubState?.settings?.weatherCity;
    if (!city?.lat || !city?.lon) {
      $('#weather-card').hidden = true;
      return;
    }
    $('#weather-city').textContent = city.name || 'Wetter';
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(city.lat)}&longitude=${encodeURIComponent(city.lon)}&current=temperature_2m,weather_code,apparent_temperature&timezone=auto`;
      const data = await window.hub.tool.fetch(url);
      const current = data?.current;
      if (!current) throw new Error('no data');
      $('#weather-temp').textContent = `${Math.round(current.temperature_2m)}°`;
      $('#weather-sub').textContent = `${weatherText(current.weather_code)} · gefühlt ${Math.round(current.apparent_temperature)}°`;
    } catch {
      $('#weather-sub').textContent = 'Wetter gerade nicht erreichbar';
    }
  }

  function paintMusic(track) {
    const playing = Boolean(track?.playing || track?.title);
    $('#music-title').textContent = track?.title || 'Nichts läuft';
    $('#music-artist').textContent = track?.artist || (playing ? '' : 'Starte Musik, um sie hier zu sehen.');
  }

  async function loadMusic() {
    try {
      paintMusic(await window.hub.music.get());
    } catch {
      paintMusic(null);
    }
  }

  function apply(next) {
    if (!next) return;
    payload = next;
    if (payload.wallpaper) {
      $('#wall').src = payload.wallpaper;
      $('#wall').hidden = false;
    } else {
      $('#wall').hidden = true;
    }
    if (payload.host) $('#host').textContent = payload.host;
    setLocked(payload.locked !== false);
  }

  window.hub.lock.on(apply);
  window.hub.lock.onState((next) => {
    if (!next) return;
    setLocked(next.locked !== false);
    if (next.locked === false) state.textContent = 'ENTSPERRT';
  });

  const dismiss = () => window.hub.lock.dismiss().catch(() => {});
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-unlock]')) dismiss();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === 'Escape' || event.key === ' ') {
      event.preventDefault();
      dismiss();
    }
  });

  window.hub.lock.state().then(apply).catch(() => {});
  paintClock();
  setInterval(paintClock, 1000);
  loadWeather();
  loadMusic();
  setInterval(loadMusic, 6000);
})();
