const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

/**
 * Liest globale Eingaben (Tastatur, Maustasten, Controller) über ein
 * PowerShell-Helferskript und meldet Änderungen als Liste von Kürzeln.
 * Ohne dieses Modul gäbe es keine Keystrokes in den Clips – Electron allein
 * sieht nur Tasten, die im eigenen Fenster gedrückt werden.
 */

let child = null;
let callback = null;
let buffer = '';
let stopping = false;
let lastState = '';

function scriptPath() {
  const packaged = process.resourcesPath ? path.join(process.resourcesPath, 'input-hook.ps1') : '';
  const local = path.join(__dirname, '..', 'build', 'input-hook.ps1');
  if (packaged && fs.existsSync(packaged)) return packaged;
  return local;
}

function emit(payload) {
  if (typeof callback !== 'function') return;
  try {
    callback(payload);
  } catch {
    /* Ein Fehler im Empfänger darf den Hook nicht beenden. */
  }
}

function handleLine(line) {
  const text = line.trim();
  if (!text) return;
  let parsed = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    return;
  }
  if (!parsed || typeof parsed.keys !== 'string') return;
  if (parsed.keys === lastState) return;
  lastState = parsed.keys;
  const keys = parsed.keys ? parsed.keys.split(',').filter(Boolean) : [];
  emit({ keys, at: Date.now() });
}

function start(onState) {
  callback = typeof onState === 'function' ? onState : callback;
  if (child) return true;

  const file = scriptPath();
  if (!fs.existsSync(file)) {
    emit({ keys: [], at: Date.now(), error: 'input-hook-missing' });
    return false;
  }

  stopping = false;
  lastState = '';

  try {
    child = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file],
      { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] },
    );
  } catch (error) {
    emit({ keys: [], at: Date.now(), error: error.message });
    child = null;
    return false;
  }

  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    buffer += chunk;
    const parts = buffer.split(/\r?\n/);
    buffer = parts.pop() || '';
    for (const line of parts) handleLine(line);
    if (buffer.length > 8192) buffer = '';
  });

  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk) => {
    const text = String(chunk).trim();
    if (text) console.log('[input]', text.slice(0, 300));
  });

  child.on('exit', () => {
    child = null;
    if (!stopping) emit({ keys: [], at: Date.now(), stopped: true });
  });

  return true;
}

function stop() {
  stopping = true;
  callback = null;
  if (!child) return;
  try {
    child.kill();
  } catch {
    /* egal */
  }
  child = null;
}

module.exports = { start, stop, scriptPath };
