'use strict';

(() => {
  const { Position, WHITE, BLACK, typeOf, colorOf, sqName, sqFrom, uci, START_FEN, F_CAPTURE, F_CASTLE, F_EP, KING, POINTS } = window.ChessCore;
  // Elo wie auf chess.com: dort stehen Einsteiger deutlich tiefer. Unter 2000 wird die alte Skala abgesenkt
  // (400 -> 100, 600 -> 300, 1000 -> ~790, 2000 bleibt).
  const cal = (e) => Math.max(100, Math.round(e - 300 * Math.max(0, Math.min(1, (2000 - e) / 1400))));
  const LEVELS = [...window.ChessEngine.LEVELS.map((L) => ({ ...L, elo: Math.round(cal(L.elo) / 50) * 50 })), { elo: 3200, name: 'Unschlagbar', sf: true }];
  const SF_LEVEL = LEVELS.length - 1;
  const Coach = window.ChessCoach;
  const Sound = window.ChessSound;
  const I = window.ChessI18n;
  const t = (k, p) => I.t(k, p);
  const $ = (id) => document.getElementById(id);
  const GLYPH = { 1: '♟', 2: '♞', 3: '♝', 4: '♜', 5: '♛', 6: '♚' };
  const glyph = (x) => `${GLYPH[x]}︎`;
  const today = () => new Date().toLocaleDateString('sv-SE');
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const L3 = (de, en, es) => ({ de, en, es })[I.lang] || de;
  const BAD = ['inaccuracy', 'mistake', 'miss', 'blunder'];
  const ORDER = ['brilliant', 'great', 'best', 'excellent', 'good', 'book', 'inaccuracy', 'mistake', 'miss', 'blunder'];
  const THEMES = { green: ['#ebecd0', '#779556'], brown: ['#f0d9b5', '#b58863'], blue: ['#dee3e6', '#8ca2ad'], purple: ['#e8e1f7', '#8a6fc9'], night: ['#9aa4b5', '#4b5568'] };
  const PIECE_NAMES = {
    de: ['', 'deinen Bauern', 'deinen Springer', 'deinen Läufer', 'deinen Turm', 'deine Dame', 'deinen König'],
    en: ['', 'your pawn', 'your knight', 'your bishop', 'your rook', 'your queen', 'your king'],
    es: ['', 'tu peón', 'tu caballo', 'tu alfil', 'tu torre', 'tu dama', 'tu rey'],
  };

  const DEFAULT_PROFILE = {
    rating: 500, peak: 500, games: 0, wins: 0, draws: 0, losses: 0,
    streak: 0, bestStreak: 0, dayStreak: 0, bestDayStreak: 0, lastDay: '', lastDelta: 0,
    ratingHistory: [500], counts: {}, accSum: 0, accGames: 0, perfBest: 0,
    name: '',
    username: '',
    points: 0,
    cos: { owned: {}, eq: {} },
    learn: { done: {} },
    uid: '',
    placed: false,
    beginner: false,
    settings: { lang: '', level: 3, color: 'w', mode: 'auto', paused: false, sensitivity: 2, badges: true, sound: true, legal: true, theme: 'green', evalbar: true, arrows: true, review: true, tc: 10, view3d: true, voice: true, demo: true },
  };

  let profile = structuredClone(DEFAULT_PROFILE);
  let game = null;
  let pos = new Position();
  let flipped = false;
  let busy = false;
  let token = 0;
  let viewPly = null; // null = aktuelle Stellung
  let selected = -1;
  let coachMarks = { arrows: [], squares: [] }; // vom Coach (Pfeile/Felder)
  let userArrows = []; // Rechtsklick-Pfeile: [from, to, color]
  let userSquares = []; // Rechtsklick-Felder: [sq, color]
  let modalOpen = false;
  const analyses = new Map(); // Halbzug → { before, verdict }

  const label = (cls) => I.CLASS_TEXT[I.lang]?.[cls]?.[0] || Coach.CLASSES[cls]?.label || cls;
  const phrase = (cls) => I.CLASS_TEXT[I.lang]?.[cls]?.[1] || cls;
  const levelName = (i) => t('levels')[i] || LEVELS[i].name;
  const san = (p, m) => p.san(m, I.lang);
  // Online gibt es während der Partie weder Coach noch Tipps (Fairness); in der Analyse schon.
  const paused = () => profile.settings.paused || Boolean(game?.online && !game.over) || Boolean(game?.scenario) || Boolean(game?.placement && !game.over);
  /** Eingreifen oder nur bewerten – „Automatisch“ hängt von der Elo ab. */
  const mode = () => (profile.settings.mode === 'auto' ? (profile.rating >= 1000 ? 'rate' : 'popup') : profile.settings.mode);

  /* ================================================================ Engine */

  let worker = null;
  let seq = 0;
  const pending = new Map();
  try {
    worker = new Worker('engine-worker.js');
    worker.onmessage = (event) => {
      const job = pending.get(event.data.id);
      if (!job) return;
      pending.delete(event.data.id);
      if (event.data.ok) job.resolve(event.data.result);
      else job.reject(new Error(event.data.error));
    };
    worker.onerror = () => {
      worker = null;
    };
  } catch {
    worker = null;
  }
  const localEngine = new window.ChessEngine.Engine();

  function ask(cmd, payload = {}) {
    const data = { cmd, startFen: game?.startFen || START_FEN, moves: (game?.moves || []).map((m) => m.uci), ...payload };
    if (worker) {
      return new Promise((resolve, reject) => {
        const id = ++seq;
        pending.set(id, { resolve, reject });
        worker.postMessage({ id, ...data });
      });
    }
    return new Promise((resolve) => {
      setTimeout(() => {
        const p = new Position(data.startFen);
        for (const u of data.moves) p.make(p.find(u));
        if (cmd === 'play') resolve(window.ChessEngine.pickMove(localEngine, p, data.level));
        else if (cmd === 'analyse') resolve({ rows: localEngine.scoreAll(p, { maxDepth: data.maxDepth || 5, timeMs: data.timeMs || 800, minDepth: 2 }), played: data.played });
        else resolve(localEngine.think(p, { maxDepth: data.maxDepth || 8, timeMs: data.timeMs || 800 }));
      }, 20);
    });
  }

  /* ================================================================ Profil & Sprache */

  async function loadProfile() {
    const saved = await window.chessApp?.loadProfile().catch(() => null);
    if (saved) {
      profile = { ...structuredClone(DEFAULT_PROFILE), ...saved, settings: { ...DEFAULT_PROFILE.settings, ...(saved.settings || {}) } };
      // ältere Version: „Coach greift ein“ aus → nur bewerten
      if (saved.settings && saved.settings.coach === false && !saved.settings.mode) profile.settings.mode = 'rate';
      // einmalig: alte Elo-Werte auf die chess.com-nahe Skala umrechnen
      if ((saved.eloV || 0) < 2) {
        profile.rating = cal(profile.rating);
        profile.peak = cal(profile.peak || profile.rating);
        profile.ratingHistory = (profile.ratingHistory || []).map(cal);
        profile.ratingLog = (profile.ratingLog || []).map((x) => ({ ...x, r: cal(x.r) }));
        if (profile.perfBest) profile.perfBest = cal(profile.perfBest);
      }
    }
    profile.eloV = 2;
    if (!profile.settings.lang) profile.settings.lang = window.__hubLang || I.detect();
    profile.cos = { owned: { ...(profile.cos?.owned || {}) }, eq: { ...(profile.cos?.eq || {}) } };
    profile.learn = { ...(profile.learn || {}), done: { ...(profile.learn?.done || {}) } };
    // v3: neuer Lernpfad (Eröffnung → Mittelspiel → Endspiel) und neue, strengere Einstufung
    if ((profile.resetV || 0) < 3) {
      profile.resetV = 3;
      profile.learn = { ...profile.learn, done: {} };
      if (profile.placed) {
        profile.placed = false;
        profile.replace = true;
      }
      delete profile.placeRun;
    }
    if (!profile.uid) profile.uid = Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => b.toString(16).padStart(2, '0')).join('');
    if (!profile.username && profile.name) profile.username = profile.name;
    const y = new Date(Date.now() - 864e5).toLocaleDateString('sv-SE');
    if (profile.lastDay && profile.lastDay !== today() && profile.lastDay !== y) profile.dayStreak = 0;
    applySettings();
  }

  const saveProfile = () => window.chessApp?.saveProfile(profile).catch(() => {});
  // Online-Partie durch Schliessen verlassen → beim nächsten Start als Niederlage werten
  function applyAbandon() {
    let a = null;
    try {
      a = JSON.parse(localStorage.getItem('chessAbandon') || 'null');
    } catch {
      a = null;
    }
    localStorage.removeItem('chessAbandon');
    if (!a || !profile) return;
    const before = profile.rating;
    profile.rating = Math.max(100, Coach.eloUpdate(before, Number(a.opp) || before, 0, profile.games));
    profile.lastDelta = profile.rating - before;
    profile.games += 1;
    profile.losses += 1;
    profile.streak = 0;
    saveProfile();
    setTimeout(() => bubble?.(`<b>${esc(L3('Online-Partie verlassen', 'Online game abandoned', 'Partida online abandonada'))}</b> ${esc(L3(`Sie zählt als Niederlage (${profile.lastDelta} Elo).`, `It counts as a loss (${profile.lastDelta} Elo).`, `Cuenta como derrota (${profile.lastDelta} Elo).`))}`, 'think'), 1500);
  }

  /* Ein Profil für den ganzen Hub: Name, Punkte und Cosmetics kommen vom Hub. */
  const HP = window.hubProfile;
  function applyHub(hp) {
    if (!hp) return;
    profile.points = hp.points;
    profile.cos = { owned: { ...(hp.cos?.owned || {}) }, eq: { ...(hp.cos?.eq || {}) } };
    if (hp.name) profile.username = hp.name;
  }
  async function syncHub() {
    if (!HP) return;
    const hp = await HP.migrate({ name: profile.username || profile.name, points: profile.points, cos: profile.cos }).catch(() => null);
    applyHub(hp);
  }
  function earn(n) {
    if (!n) return;
    profile.points += n;
    HP?.earn(n).then(applyHub).catch(() => {});
  }
  window.addEventListener('hub-profile', (e) => {
    applyHub(e.detail);
    try {
      refresh();
      if (!$('lobby').hidden) Lobby.render();
    } catch {}
  });
  const saveGame = () => window.chessApp?.saveGame(game && !game.over && !game.online && !game.review && !game.scenario ? game : null).catch(() => {});

  function applySettings() {
    const s = profile.settings;
    I.lang = s.lang;
    document.documentElement.lang = I.lang;
    Sound.enabled = s.sound;
    $('shell').className = `shell theme-${s.theme}${s.evalbar && !s.paused ? '' : ' no-eval'}${s.paused ? ' paused' : ''}`;
    apply3d();
    translateStatic();
  }

  function translateStatic() {
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      el.textContent = t(el.dataset.i18n);
    });
    document.querySelectorAll('[data-i18n-title]').forEach((el) => {
      el.title = t(el.dataset.i18nTitle);
    });
    const mute = $('btn-mute');
    if (mute) {
      const on = profile.settings.sound;
      mute.classList.toggle('on', !on);
      mute.title = on ? t('muteOn') : t('muteOff');
      mute.innerHTML = on
        ? '<svg viewBox="0 0 24 24"><path d="M11 5 6 9H3v6h3l5 4Z"/><path d="M15.500 8.500a5 5 0 0 1 0 7M18.500 5.500a9.500 9.500 0 0 1 0 13" fill="none" stroke="currentColor" stroke-width="1.800" stroke-linecap="round"/></svg>'
        : '<svg viewBox="0 0 24 24"><path d="M11 5 6 9H3v6h3l5 4Z"/><path d="m16 9.500 5 5M21 9.500l-5 5" fill="none" stroke="currentColor" stroke-width="1.800" stroke-linecap="round"/></svg>';
    }
    const p = $('btn-pause');
    p.classList.toggle('on', paused());
    p.title = paused() ? t('resume') : t('pause');
    p.innerHTML = paused()
      ? '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7Z"/></svg>'
      : '<svg viewBox="0 0 24 24"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>';
  }

  /* ================================================================ Brett */

  const squaresEl = $('squares');
  const piecesEl = $('pieces');
  const boardEl = $('board');

  function cell(sq) {
    const f = sq & 7, r = sq >> 4;
    return flipped ? { col: 7 - f, row: r } : { col: f, row: 7 - r };
  }

  /* ---------------- 3D-Brett (WebGL). Das DOM-Brett bleibt die Logik-Ebene darunter. */
  let b3 = null;
  let b3Failed = false;
  const is3d = () => Boolean(b3 && profile.settings.view3d);
  function apply3d() {
    if (profile.settings.view3d && !b3 && !b3Failed) {
      try {
        b3 = window.Board3D?.create(boardEl, {
          onView: () => {
            if (!is3d()) return;
            renderBadges();
            drawArrows();
          },
        }) || null;
      } catch {
        b3 = null;
      }
      b3Failed = !b3;
    }
    const on = is3d();
    boardEl.classList.toggle('is3d', on);
    b3?.setActive(on);
    $('view-chips')?.classList.toggle('on', on);
    $('view-chips')?.classList.toggle('unavailable', b3Failed);
  }
  /** Mitte eines Feldes in Prozent des Bretts (in 3D perspektivisch, h = Höhe über dem Brett). */
  function spot(sq, h = 0) {
    if (is3d()) {
      const p = b3.project(sq, h);
      return { x: p.x * 100, y: p.y * 100 };
    }
    const { col, row } = cell(sq);
    return { x: col * 12.5 + 6.25, y: row * 12.5 + 6.25 };
  }

  function sqAt(clientX, clientY) {
    if (is3d()) return b3.pick(clientX, clientY);
    const rect = boardEl.getBoundingClientRect();
    const col = Math.floor(((clientX - rect.left) / rect.width) * 8);
    const row = Math.floor(((clientY - rect.top) / rect.height) * 8);
    if (col < 0 || col > 7 || row < 0 || row > 7) return -1;
    return (flipped ? row : 7 - row) * 16 + (flipped ? 7 - col : col);
  }

  function buildSquares() {
    squaresEl.innerHTML = '';
    for (let row = 0; row < 8; row += 1) {
      for (let col = 0; col < 8; col += 1) {
        const f = flipped ? 7 - col : col;
        const r = flipped ? row : 7 - row;
        const div = document.createElement('div');
        div.className = `sq${(f + r) % 2 === 0 ? ' dark' : ''}`;
        div.dataset.sq = r * 16 + f;
        if (row === 7) div.insertAdjacentHTML('beforeend', `<span class="coord file">${'abcdefgh'[f]}</span>`);
        if (col === 0) div.insertAdjacentHTML('beforeend', `<span class="coord rank">${r + 1}</span>`);
        squaresEl.appendChild(div);
      }
    }
    $('evalbar').classList.toggle('flipped', flipped);
  }

  const sqEl = (sq) => squaresEl.querySelector(`[data-sq="${sq}"]`);

  function shown() {
    if (viewPly === null || !game) return pos;
    const p = new Position(game.startFen);
    for (const m of game.moves.slice(0, viewPly)) p.make(p.find(m.uci));
    return p;
  }

  function placePiece(el, sq) {
    const { col, row } = cell(sq);
    el.style.transform = `translate(${col * 100}%, ${row * 100}%)`;
  }

  /** Figuren-Skin: eigene Farbe = eigener Skin, Gegner online = dessen Skin, sonst klassisch. */
  function skinFor(color) {
    if (!game || game.self) return profile.cos.eq.pieces || 'classic';
    if (color === game.userColor) return profile.cos.eq.pieces || 'classic';
    return game.online?.oppCos?.pieces || 'classic';
  }

  function renderPieces() {
    const p = shown();
    boardEl.className = boardEl.className.replace(/\s?bd-\S+/g, '') + ` bd-${profile.cos.eq.board || 'standard'}`;
    piecesEl.innerHTML = '';
    const size = boardEl.clientWidth / 8;
    for (let sq = 0; sq < 128; sq += 1) {
      if (sq & 0x88) continue;
      const piece = p.b[sq];
      if (!piece) continue;
      const el = document.createElement('div');
      el.className = `piece ${colorOf(piece) === WHITE ? 'w' : 'b'} skin-${skinFor(colorOf(piece))}`;
      el.dataset.sq = sq;
      el.innerHTML = `<span style="font-size:${Math.round(size * 0.78)}px">${glyph(typeOf(piece))}</span>`;
      placePiece(el, sq);
      piecesEl.appendChild(el);
    }
    renderHighlights();
  }

  function renderHighlights() {
    const p = shown();
    squaresEl.querySelectorAll('.sq').forEach((el) => {
      el.classList.remove('last', 'sel', 'check');
      el.querySelectorAll('.dot, .ring, .mk').forEach((x) => x.remove());
    });
    const ply = viewPly === null ? game?.moves.length || 0 : viewPly;
    const last = ply > 0 ? game.moves[ply - 1] : null;
    if (last) {
      sqEl(sqFrom(last.uci.slice(0, 2)))?.classList.add('last');
      sqEl(sqFrom(last.uci.slice(2, 4)))?.classList.add('last');
    }
    if (p.inCheck()) sqEl(p.kings[p.turn >> 3])?.classList.add('check');
    for (const [sq, color] of [...coachMarks.squares, ...userSquares, ...pmMarks()]) {
      sqEl(sq)?.insertAdjacentHTML('beforeend', `<i class="mk" style="--mk:${color}"></i>`);
    }
    if (selected >= 0 && viewPly === null) {
      sqEl(selected)?.classList.add('sel');
      if (profile.settings.legal)
        for (const m of pos.legalMoves().filter((x) => x.from === selected)) {
          const el = sqEl(m.to);
          if (el && !el.querySelector('.dot, .ring')) el.insertAdjacentHTML('beforeend', pos.b[m.to] || m.flags & F_EP ? '<i class="ring"></i>' : '<i class="dot"></i>');
        }
    }
    for (const [sq, cap] of planDots) sqEl(sq)?.insertAdjacentHTML('beforeend', cap ? '<i class="ring plan"></i>' : '<i class="dot plan"></i>');
    if (is3d()) {
      const pieces = [];
      for (let sq = 0; sq < 128; sq += 1) {
        if (sq & 0x88 || !p.b[sq]) continue;
        pieces.push({ sq, type: typeOf(p.b[sq]), white: colorOf(p.b[sq]) === WHITE, skin: skinFor(colorOf(p.b[sq])) });
      }
      const dots = [];
      if (selected >= 0 && viewPly === null && profile.settings.legal)
        for (const m of pos.legalMoves().filter((x) => x.from === selected)) dots.push([m.to, Boolean(pos.b[m.to] || m.flags & F_EP), false]);
      for (const [sq, cap] of planDots) dots.push([sq, cap, true]);
      const theme = THEMES[profile.settings.theme] || THEMES.green;
      b3.sync({
        pieces,
        flipped,
        last: last ? [sqFrom(last.uci.slice(0, 2)), sqFrom(last.uci.slice(2, 4))] : [],
        check: p.inCheck() ? p.kings[p.turn >> 3] : -1,
        sel: selected >= 0 && viewPly === null ? selected : -1,
        dots,
        marks: [...coachMarks.squares, ...userSquares, ...pmMarks()],
        board: profile.cos.eq.board || 'standard',
        light: theme[0],
        dark: theme[1],
      });
    }
    renderBadges();
    drawArrows();
  }

  function renderBadges() {
    $('fx').querySelectorAll('.badge').forEach((b) => b.remove());
    if (!game || !profile.settings.badges || paused()) return;
    const ply = viewPly === null ? game.moves.length : viewPly;
    for (let i = ply - 1; i >= Math.max(0, ply - 2); i -= 1) {
      const m = game.moves[i];
      if (!m?.cls) continue;
      addBadge(sqFrom(m.uci.slice(2, 4)), m.cls, i === ply - 1 && viewPly === null && m.fresh);
      m.fresh = false;
      break;
    }
  }

  function addBadge(sq, cls, animate = true) {
    const info = Coach.CLASSES[cls];
    if (!info) return;
    const { col, row } = cell(sq);
    const b = document.createElement('div');
    b.className = 'badge';
    if (is3d()) {
      const top = spot(sq, b3.height(typeOf(shown().b[sq])) + 0.12);
      b.style.left = `${top.x + 3.6}%`;
      b.style.top = `${top.y}%`;
    } else {
      b.style.left = `${(col + 1) * 12.5 - 2.4}%`;
      b.style.top = `${row * 12.5 + 2.4}%`;
    }
    b.style.background = info.color;
    if (!animate) b.style.animation = 'none';
    b.textContent = info.mark;
    b.title = label(cls);
    $('fx').appendChild(b);
  }

  /* ---------------- Rechtsklick-Plan: mögliche Züge simulieren, Pfeile nummerieren */
  let planDots = [];
  let annotationColorNow = '';
  let planPreview = null;
  const PLAN_GLYPH = ['', '♟', '♞', '♝', '♜', '♛', '♚'];

  /** Zug im Plan ausführen – auch für die Seite, die gerade nicht dran ist (Nullzug). */
  function planMove(p, from, to) {
    const piece = p.b[from];
    if (!piece) return null;
    let nulled = false;
    if (colorOf(piece) !== p.turn) {
      if (p.inCheck()) return null;
      p.makeNull();
      nulled = true;
    }
    const m = p.legalMoves().find((x) => x.from === from && x.to === to);
    if (!m) {
      if (nulled) p.unmakeNull();
      return null;
    }
    p.make(m);
    return m;
  }

  /** Alle Pfeile der Reihe nach im Plan durchspielen und durchnummerieren. */
  function replan() {
    const p = shown().clone();
    let n = 0;
    for (const a of userArrows) {
      const piece = p.b[a[0]];
      const m = planMove(p, a[0], a[1]);
      a[3] = m ? ++n : 0;
      a[4] = m ? piece : 0;
    }
    return p;
  }

  function planTargets(sq) {
    const p = replan();
    const piece = p.b[sq];
    if (!piece) return [];
    if (colorOf(piece) !== p.turn) {
      if (p.inCheck()) return [];
      p.makeNull();
    }
    return p.legalMoves().filter((m) => m.from === sq).map((m) => [m.to, Boolean(p.b[m.to])]);
  }

  /**
   * Pfeile wie auf chess.com: flache Pfeile mit breiter Spitze, Springerzüge als „L“.
   * Ein Pfeil ist ein gefülltes Vieleck (Schaft + Spitze), kein Strich mit Marker.
   */
  function arrowShape(pts, w = 22, head = 50, headLen = 42) {
    // pts: Mittelpunkte [Start, (Knick), Ziel]; der Pfeil beginnt etwas vom Startfeld-Rand entfernt
    const p = pts.map((q) => q.slice());
    const n = p.length;
    const [ax, ay] = p[n - 2], [bx, by] = p[n - 1];
    const L = Math.hypot(bx - ax, by - ay) || 1;
    const ux = (bx - ax) / L, uy = (by - ay) / L;
    // Spitze endet knapp vor der Feldmitte
    const tipX = bx - ux * 12, tipY = by - uy * 12;
    const baseX = tipX - ux * headLen, baseY = tipY - uy * headLen;
    p[n - 1] = [baseX, baseY];
    const half = w / 2;
    const left = [], right = [];
    for (let k = 0; k < p.length; k += 1) {
      const prev = p[Math.max(0, k - 1)], next = p[Math.min(p.length - 1, k + 1)];
      let dx = next[0] - prev[0], dy = next[1] - prev[1];
      if (k > 0 && k < p.length - 1) {
        // Ecke des „L“: Normale halbieren, damit der Schaft sauber abknickt
        const d1 = [p[k][0] - prev[0], p[k][1] - prev[1]], d2 = [next[0] - p[k][0], next[1] - p[k][1]];
        const l1 = Math.hypot(...d1) || 1, l2 = Math.hypot(...d2) || 1;
        const n1 = [-d1[1] / l1, d1[0] / l1], n2 = [-d2[1] / l2, d2[0] / l2];
        const m = [n1[0] + n2[0], n1[1] + n2[1]];
        const ml = Math.hypot(...m) || 1;
        const scale = half / Math.max(0.5, (m[0] * n1[0] + m[1] * n1[1]) / ml);
        left.push([p[k][0] + (m[0] / ml) * scale, p[k][1] + (m[1] / ml) * scale]);
        right.push([p[k][0] - (m[0] / ml) * scale, p[k][1] - (m[1] / ml) * scale]);
        continue;
      }
      const l = Math.hypot(dx, dy) || 1;
      dx /= l;
      dy /= l;
      left.push([p[k][0] - dy * half, p[k][1] + dx * half]);
      right.push([p[k][0] + dy * half, p[k][1] - dx * half]);
    }
    const nx = -uy, ny = ux;
    const headPts = [[baseX + nx * head / 2, baseY + ny * head / 2], [tipX, tipY], [baseX - nx * head / 2, baseY - ny * head / 2]];
    const poly = [...left, headPts[0], headPts[1], headPts[2], ...right.reverse()];
    return poly.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  }

  function drawArrows() {
    const svg = $('arrows');
    const center = (sq) => {
      const c = spot(sq);
      return [c.x * 8, c.y * 8];
    };
    replan();
    const all = [...coachMarks.arrows, ...userArrows, ...pmArrows(), ...(planPreview ? [[...planPreview, annotationColorNow || 'rgba(255,170,0,0.8)']] : [])];
    svg.innerHTML = all
      .map(([from, to, color]) => {
        const a = center(from), b = center(to);
        const df = (to & 7) - (from & 7), dr = (to >> 4) - (from >> 4);
        // Springer: erst die lange Richtung, dann um die Ecke (wie auf chess.com)
        const knight = (Math.abs(df) === 1 && Math.abs(dr) === 2) || (Math.abs(df) === 2 && Math.abs(dr) === 1);
        let pts = [a, b];
        if (knight) {
          const longFile = Math.abs(df) === 2;
          const corner = longFile ? [b[0], a[1]] : [a[0], b[1]];
          // im 3D-Brett perspektivisch richtig: Knick über dem Feld berechnen
          if (is3d()) {
            const cornerSq = longFile ? (from & 0x70) | (to & 7) : (to & 0x70) | (from & 7);
            pts = [a, center(cornerSq), b];
          } else pts = [a, corner, b];
        }
        // Start etwas vom Mittelpunkt weg, damit die Figur sichtbar bleibt
        const [s0, s1] = [pts[0], pts[1]];
        const sl = Math.hypot(s1[0] - s0[0], s1[1] - s0[1]) || 1;
        pts[0] = [s0[0] + ((s1[0] - s0[0]) / sl) * 26, s0[1] + ((s1[1] - s0[1]) / sl) * 26];
        return `<polygon class="a" points="${arrowShape(pts)}" fill="${color}"/>`;
      })
      .join('');
  }

  function setMarks(marks) {
    coachMarks = { arrows: marks?.arrows || [], squares: marks?.squares || [] };
    renderHighlights();
  }

  async function animateMove(m) {
    if (is3d()) {
      b3.move({
        from: m.from,
        to: m.to,
        ep: m.flags & F_EP ? m.to + (colorOf(m.piece) === WHITE ? -16 : 16) : -1,
        castle: m.flags & F_CASTLE ? (m.to === 6 ? [7, 5] : m.to === 2 ? [0, 3] : m.to === 118 ? [119, 117] : [112, 115]) : null,
      });
      await sleep(m.flags & F_CASTLE || typeOf(m.piece) === 2 ? 330 : 290);
      return;
    }
    const fromEl = piecesEl.querySelector(`[data-sq="${m.from}"]`);
    const toEl = piecesEl.querySelector(`[data-sq="${m.to}"]`);
    if (toEl && toEl !== fromEl) toEl.classList.add('fade');
    if (m.flags & F_EP) piecesEl.querySelector(`[data-sq="${m.to + (colorOf(m.piece) === WHITE ? -16 : 16)}"]`)?.classList.add('fade');
    if (fromEl) {
      fromEl.classList.remove('drag');
      fromEl.style.zIndex = 4;
      placePiece(fromEl, m.to);
    }
    if (m.flags & F_CASTLE) {
      const [rf, rt] = m.to === 6 ? [7, 5] : m.to === 2 ? [0, 3] : m.to === 118 ? [119, 117] : [112, 115];
      const rook = piecesEl.querySelector(`[data-sq="${rf}"]`);
      if (rook) placePiece(rook, rt);
    }
    await sleep(230);
  }

  function particles(sq, color, count = 26) {
    const c0 = spot(sq);
    const [col, row] = [(c0.x - 6.25) / 12.5, (c0.y - 6.25) / 12.5];
    const fx = $('fx');
    const glow = document.createElement('div');
    glow.className = 'glow';
    glow.style.cssText = `left:${col * 12.5}%;top:${row * 12.5}%;--c:${color}`;
    fx.appendChild(glow);
    setTimeout(() => glow.remove(), 1500);
    for (let i = 0; i < count; i += 1) {
      const p = document.createElement('i');
      p.className = 'p';
      const ang = Math.random() * Math.PI * 2;
      const dist = 40 + Math.random() * 140;
      p.style.cssText = `left:calc(${col * 12.5 + 6.25}% - 4px);top:calc(${row * 12.5 + 6.25}% - 4px);--c:${color};--dx:${Math.cos(ang) * dist}px;--dy:${Math.sin(ang) * dist}px;animation-delay:${Math.random() * 0.15}s`;
      fx.appendChild(p);
      setTimeout(() => p.remove(), 1500);
    }
  }

  function celebrate(kind, sq) {
    const el = $('celebrate');
    const brilliant = kind === 'brilliant';
    el.innerHTML = `${brilliant ? '<div class="flash"></div><div class="rays"></div>' : ''}<div class="medal"><div class="ring-big ${kind}">${brilliant ? '!!' : '!'}</div><div class="word">${esc(label(kind))}!</div></div>`;
    el.hidden = false;
    particles(sq, brilliant ? '#6ff3ea' : '#a6c9ea', brilliant ? 44 : 22);
    Sound.play(brilliant ? 'brilliant' : 'great');
    clearTimeout(celebrate.t);
    celebrate.t = setTimeout(() => {
      el.hidden = true;
      el.innerHTML = '';
    }, 2300);
  }

  /* ================================================================ Eingabe */

  let drag = null;
  let rightStart = -1;

  boardEl.addEventListener('contextmenu', (e) => e.preventDefault());

  function annotationColor(e) {
    if (e.shiftKey) return 'rgba(129,182,76,0.9)';
    if (e.ctrlKey) return 'rgba(229,72,77,0.9)';
    if (e.altKey) return 'rgba(74,163,223,0.9)';
    return 'rgba(255,170,0,0.85)';
  }

  boardEl.addEventListener('pointerdown', (event) => {
    if (event.button === 2) {
      if (premoves.length || pmSel >= 0) {
        // Rechtsklick verwirft die Vorzüge
        premoves = [];
        pmSel = -1;
        planDots = [];
        renderHighlights();
        return;
      }
      if (!profile.settings.arrows) return;
      rightStart = sqAt(event.clientX, event.clientY);
      // Rechtsklick auf eine Figur: mögliche Züge (im geplanten Ablauf) anzeigen
      planDots = [];
      planPreview = null;
      renderHighlights();
      return;
    }
    if (event.button !== 0) return;
    // Linksklick löscht eigene Pfeile und Markierungen (wie auf chess.com)
    if (userArrows.length || userSquares.length) {
      userArrows = [];
      userSquares = [];
      renderHighlights();
    }
    const sq = sqAt(event.clientX, event.clientY);
    if (sq < 0) return;
    if (viewPly !== null) {
      viewPly = null;
      setMarks(null);
      refresh();
      return;
    }
    if (premoveClick(sq)) return;
    if (!canMove()) return;
    const piece = pos.b[sq];
    if (selected >= 0 && selected !== sq && pos.legalMoves().some((m) => m.from === selected && m.to === sq)) {
      tryMove(selected, sq);
      return;
    }
    if (piece && colorOf(piece) === game.userColor) {
      selected = sq;
      renderHighlights();
      const el = piecesEl.querySelector(`[data-sq="${sq}"]`);
      if (el) {
        drag = { el, from: sq, x: event.clientX, y: event.clientY };
        boardEl.setPointerCapture(event.pointerId);
        if (is3d()) b3.dragStart(sq);
        else moveDrag(event);
      }
    } else {
      selected = -1;
      renderHighlights();
    }
  });

  function moveDrag(event) {
    if (rightStart >= 0 && !drag) {
      const over = sqAt(event.clientX, event.clientY);
      annotationColorNow = annotationColor(event);
      const next = over >= 0 && over !== rightStart ? [rightStart, over] : null;
      if (String(next) !== String(planPreview)) {
        planPreview = next;
        drawArrows();
      }
      return;
    }
    if (!drag) return;
    const over = sqAt(event.clientX, event.clientY);
    if (is3d()) {
      // erst nach ein paar Pixeln anheben – ein Klick wählt die Figur nur aus
      if (!drag.lifted && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 5) return;
      drag.lifted = true;
      b3.dragMove(event.clientX, event.clientY);
      b3.setHover(over >= 0 && over !== drag.from ? over : -1);
      return;
    }
    const rect = boardEl.getBoundingClientRect();
    const size = rect.width / 8;
    drag.el.classList.add('drag');
    drag.el.style.transform = `translate(${event.clientX - rect.left - size / 2}px, ${event.clientY - rect.top - size / 2}px)`;
    squaresEl.querySelectorAll('.hover').forEach((e) => e.classList.remove('hover'));
    if (over >= 0 && over !== drag.from) sqEl(over)?.classList.add('hover');
  }

  boardEl.addEventListener('pointermove', moveDrag);
  boardEl.addEventListener('pointerup', (event) => {
    if (event.button === 2) {
      const end = sqAt(event.clientX, event.clientY);
      const from = rightStart;
      const legal = planDots.some(([s]) => s === end);
      rightStart = -1;
      planDots = [];
      planPreview = null;
      if (from < 0 || end < 0) return renderHighlights();
      const color = annotationColor(event);
      if (from === end) {
        const i = userSquares.findIndex(([s]) => s === end);
        if (i >= 0) userSquares.splice(i, 1);
        else userSquares.push([end, color]);
      } else {
        const i = userArrows.findIndex(([a, b]) => a === from && b === end);
        if (i >= 0) userArrows.splice(i, 1);
        else userArrows.push([from, end, color]);
      }
      renderHighlights();
      return;
    }
    if (!drag) return;
    const d = drag;
    drag = null;
    squaresEl.querySelectorAll('.hover').forEach((e) => e.classList.remove('hover'));
    const to = sqAt(event.clientX, event.clientY);
    b3?.setHover(-1);
    if (to >= 0 && to !== d.from && pos.legalMoves().some((m) => m.from === d.from && m.to === to)) {
      tryMove(d.from, to, true);
      return;
    }
    b3?.dragEnd();
    d.el.classList.remove('drag');
    placePiece(d.el, d.from);
  });

  let moveLock = false;
  const canMove = () => game && !game.over && !busy && !moveLock && !modalOpen && pos.turn === game.userColor && viewPly === null;

  /* ---------------- Vorzüge: Züge vormachen, während der Gegner dran ist – sie werden der Reihe nach gespielt */
  let premoves = []; // [von, nach]
  let pmSel = -1;
  let pmBusy = false;
  const PM_COLOR = 'rgba(229,72,77,0.85)';
  const canPremove = () => Boolean(game && !game.over && !modalOpen && viewPly === null && !game.self && !game.review && !game.lesson && !game.scenario && !game.placement && pos.turn !== game.userColor);
  /** Stellung, wie sie nach allen Vorzügen aussähe (der Gegner „passt“ dazwischen). */
  function pmPosition() {
    const p = pos.clone();
    for (const [from, to] of premoves) if (!planMove(p, from, to)) break;
    return p;
  }
  function pmTargets(sq) {
    const p = pmPosition();
    const piece = p.b[sq];
    if (!piece || colorOf(piece) !== game.userColor) return null;
    if (p.turn !== game.userColor) {
      if (p.inCheck()) return [];
      p.makeNull();
    }
    return p.legalMoves().filter((m) => m.from === sq).map((m) => [m.to, Boolean(p.b[m.to])]);
  }
  const pmMarks = () => premoves.flatMap(([from, to]) => [[from, 'rgba(229,72,77,0.45)'], [to, 'rgba(229,72,77,0.7)']]);
  function pmArrows() {
    if (!premoves.length) return [];
    const p = pos.clone();
    return premoves.map(([from, to], i) => {
      const piece = p.b[from];
      planMove(p, from, to);
      return [from, to, PM_COLOR, i + 1, piece];
    });
  }
  function premoveClick(sq) {
    if (!canPremove()) return false;
    if (pmSel >= 0 && sq !== pmSel && planDots.some(([to]) => to === sq)) {
      premoves.push([pmSel, sq]);
      pmSel = -1;
      planDots = [];
      renderHighlights();
      return true;
    }
    const targets = pmTargets(sq);
    if (targets && targets.length) {
      pmSel = sq;
      planDots = targets;
    } else {
      pmSel = -1;
      planDots = [];
      if (!targets) premoves = [];
    }
    renderHighlights();
    return true;
  }
  function runPremove() {
    if (!premoves.length || pmBusy) return;
    if (!game || game.over || game.self) {
      premoves = [];
      return;
    }
    if (!canMove()) return;
    const [from, to] = premoves.shift();
    const options = pos.legalMoves().filter((m) => m.from === from && m.to === to);
    pmSel = -1;
    planDots = [];
    if (!options.length) {
      // geht nicht mehr (z. B. Figur geschlagen): Rest verwerfen
      premoves = [];
      renderHighlights();
      return;
    }
    pmBusy = true;
    userMove(options.find((o) => o.promo === 5) || options[0], false).finally(() => {
      pmBusy = false;
    });
  }

  async function tryMove(from, to, dragged = false) {
    if (Lesson.active?.locked || moveLock) return;
    const options = pos.legalMoves().filter((m) => m.from === from && m.to === to);
    if (!options.length) return;
    let m = options[0];
    if (options.length > 1) {
      const promo = await pickPromotion(to);
      if (!promo) {
        b3?.dragEnd();
        renderPieces();
        return;
      }
      m = options.find((o) => o.promo === promo) || options[0];
    }
    selected = -1;
    if (dragged) {
      b3?.dragEnd(to);
      const el = piecesEl.querySelector(`[data-sq="${from}"]`);
      if (el) {
        el.classList.remove('drag');
        el.style.transition = 'none';
        placePiece(el, to);
      }
    }
    userMove(m, dragged);
  }

  function pickPromotion(to) {
    return new Promise((resolve) => {
      const box = $('promo');
      const { col, row } = cell(to);
      const color = game.userColor;
      if (is3d()) {
        const c = spot(to);
        box.style.left = `${Math.max(0, Math.min(87.5, c.x - 6.25))}%`;
        box.style.top = `${Math.max(0, Math.min(50, c.y - 6.25))}%`;
        box.style.bottom = 'auto';
      } else {
        box.style.left = `${col * 12.5}%`;
        box.style.top = row === 0 ? '0' : 'auto';
        box.style.bottom = row === 0 ? 'auto' : '0';
      }
      const size = boardEl.clientWidth / 8;
      box.innerHTML = [5, 2, 4, 3]
        .map((x) => `<button data-t="${x}"><span style="font-size:${Math.round(size * 0.72)}px;color:${color === WHITE ? '#fff' : '#222'};-webkit-text-stroke:1.4px #222">${glyph(x)}</span></button>`)
        .join('');
      box.hidden = false;
      const done = (value) => {
        box.hidden = true;
        document.removeEventListener('pointerdown', outside, true);
        resolve(value);
      };
      const outside = (e) => {
        if (!box.contains(e.target)) done(0);
      };
      box.onclick = (e) => {
        const b = e.target.closest('button');
        if (b) done(Number(b.dataset.t));
      };
      setTimeout(() => document.addEventListener('pointerdown', outside, true), 0);
    });
  }

  /* ================================================================ Ablauf */

  function moveSound(m, p) {
    if (p.inCheck()) Sound.play('check');
    else if (m.flags & F_CASTLE) Sound.play('castle');
    else if (m.flags & F_CAPTURE) Sound.play('capture');
    else Sound.play('move');
  }

  async function play(m, { animate = true } = {}) {
    const s = san(pos, m);
    if (animate) await animateMove(m);
    pos.make(m);
    game.moves.push({ uci: uci(m), san: s, color: colorOf(m.piece) === WHITE ? 'w' : 'b' });
    moveSound(m, pos);
    refresh();
  }

  /** SAN in der aktuellen Sprache neu berechnen (nach Sprachwechsel). */
  function relabelMoves() {
    if (!game) return;
    const p = new Position(game.startFen);
    for (const m of game.moves) {
      const mm = p.find(m.uci);
      if (!mm) break;
      m.san = san(p, mm);
      p.make(mm);
    }
  }

  async function userMove(m, dragged) {
    const my = token;
    const before = pos.clone();
    const prevMoves = game.moves.map((x) => x.uci);
    const ply = game.moves.length;
    // Hat der Coach diesen Zug gezeigt (Tipp oder „Besten Zug zeigen“), gibt es dafür keine Punkte.
    const assisted = Boolean(game.assist);
    game.assist = null;
    setMarks(null);
    moveLock = true; // waehrend der Zug-Animation keinen zweiten Zug annehmen
    try {
      await play(m, { animate: !dragged });
    } finally {
      moveLock = false;
    }
    const entry = game.moves[ply];
    if (assisted) entry.assisted = true;
    effectBurst(m.to);
    if (game.self) {
      if (profile.settings.selfFlip) {
        flipped = pos.turn === BLACK;
        buildSquares();
      }
      refresh();
      saveGame();
      await checkEnd();
      return;
    }
    if (game.lesson && Lesson.active) {
      await Lesson.onMove(m, before, prevMoves);
      return;
    }
    if (game.scenario) {
      await Scenario.onMove(m, before, prevMoves);
      return;
    }
    if (game.online) {
      Online.sendMove(entry.uci, ply + 1);
      await checkEnd();
      return;
    }
    if (await checkEnd()) {
      if (!paused()) analyseOnly(before, prevMoves, uci(m), ply);
      return;
    }
    if (paused()) {
      await botMove();
      return;
    }
    busy = true;
    setThinking(true, t('checking'));
    let result = null;
    try {
      result = await ask('analyse', { moves: prevMoves, played: uci(m), timeMs: 750, maxDepth: 6 });
    } catch {
      result = null;
    }
    if (my !== token) return;
    const verdict = result ? Coach.classify(before, result.rows, uci(m), { ply }) : null;
    if (verdict) {
      const concrete = Coach.explain(before, verdict, I.lang).concrete;
      analyses.set(ply, { before, verdict, concrete });
      Object.assign(entry, { cls: assisted ? 'assisted' : verdict.cls, real: verdict.cls, acc: verdict.accuracy, loss: verdict.loss, best: verdict.best.uci, fresh: true });
      recordWeak(before, verdict, entry);
      if (!assisted) setEval(verdict.played.score, before.turn);
      reactTo(before, verdict, entry, ply);
    }
    renderHighlights();
    renderMoves();
    saveGame();

    // Eingreifen nur, wenn es einen konkreten Grund zu erklären gibt
    const bad = verdict && !assisted && analyses.get(ply)?.concrete && Coach.TRIGGERS[profile.settings.sensitivity]?.includes(verdict.cls);
    if (bad && mode() === 'popup') {
      Sound.play('oops');
      shake();
      setThinking(false);
      const choice = await explainModal(ply, { live: true });
      if (my !== token) return;
      if (choice === 'retry' || choice === 'show') return;
      Sound.play('nice');
      setMarks(null);
    } else if (bad) {
      Sound.play('oops');
      if (profile.settings.demo !== false && verdict?.best?.uci) {
        setThinking(false);
        await Idea.show(before, verdict);
        if (my !== token) return;
      }
    }
    setThinking(false);
    busy = false;
    await botMove();
  }

  /* Der Coach führt die bessere Idee vor: Pfeil für Pfeil, mit Stimme. */
  const Idea = {
    run: 0,
    async show(before, verdict) {
      const id = ++this.run;
      const best = before.find(verdict.best.uci);
      if (!best) return;
      const p = before.clone();
      const steps = [{ m: best, san: san(p, best), mine: true }];
      p.make(best);
      for (const u of (verdict.best.reply || []).slice(0, 2)) {
        const mv = p.find(u);
        if (!mv) break;
        steps.push({ m: mv, san: san(p, mv), mine: steps.length % 2 === 0 });
        p.make(mv);
      }
      const x = Coach.explain(before, verdict, I.lang);
      const why = (x.reasons[0]?.html || x.tips[0]?.html || '').replace(/<[^>]+>/g, '');
      const voiceOn = profile.settings.voice !== false && profile.settings.sound !== false;
      const say = (html) => {
        $('bubble-text').innerHTML = html;
        return window.CoachAvatar?.say(html, { on: voiceOn, lang: I.lang, cls: 'think' }) || Promise.resolve();
      };
      const arrows = [];
      const line = [
        L3(`Nee, warte – mach lieber <b class="san">${esc(steps[0].san)}</b>.`, `Hmm, wait – better play <b class="san">${esc(steps[0].san)}</b>.`, `Espera – mejor juega <b class="san">${esc(steps[0].san)}</b>.`),
        steps[1] ? L3(`Dann antwortet der Gegner zum Beispiel <b class="san">${esc(steps[1].san)}</b> …`, `Then your opponent plays something like <b class="san">${esc(steps[1].san)}</b> …`, `Luego el rival juega <b class="san">${esc(steps[1].san)}</b> …`) : '',
        steps[2] ? L3(`… und du hast <b class="san">${esc(steps[2].san)}</b>.`, `… and you have <b class="san">${esc(steps[2].san)}</b>.`, `… y tienes <b class="san">${esc(steps[2].san)}</b>.`) : '',
      ];
      for (let i = 0; i < steps.length; i += 1) {
        if (id !== this.run) return;
        arrows.push([steps[i].m.from, steps[i].m.to, i % 2 ? 'rgba(255,120,80,0.9)' : 'rgba(130,200,80,0.95)']);
        setMarks({ arrows: arrows.slice(), squares: [steps[i].m.to] });
        if (line[i]) await Promise.race([say(line[i]), sleep(4200)]);
        await sleep(450);
      }
      if (id !== this.run) return;
      if (why) await Promise.race([say(`${L3('Warum?', 'Why?', '¿Por qué?')} ${esc(why)}`), sleep(7000)]);
      setTimeout(() => {
        if (id === this.run) setMarks(null);
      }, 2500);
    },
    stop() {
      this.run += 1;
      window.CoachAvatar?.quiet();
    },
  };

  function shake() {
    boardEl.classList.remove('shake');
    void boardEl.offsetWidth;
    boardEl.classList.add('shake');
  }

  async function analyseOnly(before, prevMoves, played, ply) {
    try {
      const result = await ask('analyse', { moves: prevMoves, played, timeMs: 500, maxDepth: 5 });
      const verdict = Coach.classify(before, result.rows, played, { ply });
      const entry = game.moves[ply];
      if (verdict && entry) {
        analyses.set(ply, { before, verdict, concrete: Coach.explain(before, verdict, I.lang).concrete });
        Object.assign(entry, { cls: entry.assisted ? 'assisted' : verdict.cls, real: verdict.cls, acc: verdict.accuracy, loss: verdict.loss, best: verdict.best.uci });
        recordWeak(before, verdict, entry);
      }
      renderMoves();
    } catch {
      /* egal */
    }
  }

  function explainButton(ply) {
    if (analyses.get(ply) && !analyses.get(ply).concrete) return '';
    return ` <button class="btn small explain-btn" data-explain="${ply}">${esc(t('explain'))}</button>`;
  }

  function reactTo(before, verdict, entry, ply) {
    const cls = entry.cls;
    const info = Coach.CLASSES[cls];
    const to = sqFrom(entry.uci.slice(2, 4));
    if (cls === 'assisted') {
      bubble(`<b style="color:${info.color}">${esc(label(cls))}.</b> ${esc(t('assistedNote'))}`, cls);
      return;
    }
    if (cls === 'brilliant' || cls === 'great') {
      const text = Coach.praise(before, verdict, I.lang);
      entry.note = text;
      bubble(`<b style="color:${info.color}">${esc(label(cls))}!</b> ${text}`, cls);
      celebrate(cls, to);
      return;
    }
    if (cls === 'best') Sound.play('best');
    const lines = t('react')[cls] || [''];
    let extra = '';
    if (BAD.includes(cls)) {
      const best = before.find(verdict.best.uci);
      if (mode() === 'rate') extra = ` ${esc(t('explainHint'))}${explainButton(ply)}`;
      if (verdict.best?.uci) extra += ` <button class="btn small explain-btn" data-idea="${ply}">${esc(L3('Zeig’s mir', 'Show me', 'Muéstramelo'))}</button>`;
      else if (best && !Coach.TRIGGERS[profile.settings.sensitivity]?.includes(cls)) extra = ` ${t('better', { san: `<b class="san">${esc(san(before, best))}</b>` })}${explainButton(ply)}`;
    } else if (cls === 'good' && mode() === 'rate') extra = explainButton(ply);
    bubble(`<b style="color:${info.color}">${esc(label(cls))}.</b> ${esc(lines[Math.floor(Math.random() * lines.length)])}${extra}`, cls);
  }

  async function botMove(forced = null) {
    if (!game || game.over || game.online || game.review || game.self || pos.turn === game.userColor) return;
    const my = token;
    busy = true;
    setThinking(true);
    const started = Date.now();
    let result = null;
    try {
      if (forced) result = { move: forced };
      else if (game.level === SF_LEVEL) {
        try {
          result = await window.stockfish.move({ startFen: game.startFen, moves: game.moves.map((m) => m.uci), movetime: 1500 });
        } catch {
          bubble(esc(t('sfFallback')), 'book');
          result = await ask('play', { level: SF_LEVEL - 1 });
        }
      } else result = await ask('play', { level: game.level });
    } catch {
      result = null;
    }
    if (my !== token) return;
    await sleep(Math.max(0, 420 - (Date.now() - started)));
    if (my !== token) return;
    const m = result && pos.find(result.move);
    setThinking(false);
    if (!m) {
      busy = false;
      return;
    }
    await play(m);
    if (typeof result.score === 'number') setEval(result.score, colorOf(m.piece));
    busy = false;
    refresh();
    saveGame();
    await checkEnd();
  }

  function takeback(plies) {
    token += 1;
    const keep = Math.max(0, game.moves.length - plies);
    game.moves = game.moves.slice(0, keep);
    for (const k of [...analyses.keys()]) if (k >= keep) analyses.delete(k);
    pos = new Position(game.startFen);
    for (const m of game.moves) pos.make(pos.find(m.uci));
    selected = -1;
    viewPly = null;
    premoves = [];
    pmSel = -1;
    coachMarks = { arrows: [], squares: [] };
    setThinking(false);
    busy = false;
    refresh();
    saveGame();
  }

  async function checkEnd() {
    const status = pos.status();
    if (!status) return false;
    await finish(status);
    return true;
  }

  /* ================================================================ Anzeige */

  function setEval(score, perspective) {
    game.evalWhite = perspective === WHITE ? score : -score;
    paintEval();
  }

  function paintEval() {
    const white = game?.evalWhite ?? 0;
    const p = Coach.wp(white);
    $('eval-fill').style.height = `${(flipped ? 1 - p : p) * 100}%`;
    const num = $('eval-num');
    num.textContent = Coach.evalText(Math.abs(white), I.lang).replace(/^[+−±]/, '');
    num.className = `eval-num${white >= 0 === flipped ? ' top' : ''}`;
  }

  function setThinking(on, text) {
    document.querySelector('.player-bar.top .thinking')?.classList.toggle('on', Boolean(on));
    if (on && text) bubble(esc(text), 'think');
  }

  function bubble(html, cls) {
    $('bubble-text').innerHTML = html;
    if (cls !== 'pause' && !game?.online) window.CoachAvatar?.say(html, { on: profile.settings.voice !== false && profile.settings.sound !== false, lang: I.lang, cls });
    const icon = $('bubble-icon');
    const info = Coach.CLASSES[cls];
    icon.textContent = info ? info.mark : cls === 'think' ? '…' : cls === 'pause' ? 'II' : '♞';
    icon.style.background = info ? info.color : '#3a3f55';
    const b = $('bubble');
    b.classList.remove('flash');
    void b.offsetWidth;
    b.classList.add('flash');
  }

  $('bubble').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-explain]');
    if (btn) explainModal(Number(btn.dataset.explain), { live: false });
    const idea = e.target.closest('[data-idea]');
    if (idea) {
      const a = analyses.get(Number(idea.dataset.idea));
      if (a) Idea.show(a.before, a.verdict);
    }
  });

  function capturedFor(color) {
    const start = { 1: 8, 2: 2, 3: 2, 4: 2, 5: 1 };
    const p = shown();
    const have = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    for (let sq = 0; sq < 128; sq += 1) {
      if (sq & 0x88) continue;
      const x = p.b[sq];
      if (x && colorOf(x) !== color && typeOf(x) !== KING) have[typeOf(x)] += 1;
    }
    let out = '';
    for (const x of [1, 2, 3, 4, 5]) out += glyph(x).repeat(Math.max(0, start[x] - have[x]));
    const diff = p.material(color) - p.material(color ^ 8);
    return out + (diff > 0 ? `<em>+${diff}</em>` : '');
  }

  function renderBars() {
    if (!game) {
      $('bar-top').innerHTML = '';
      $('bar-bottom').innerHTML = '';
      return;
    }
    const L = LEVELS[game.level] || LEVELS[0];
    const me = game.userColor;
    const thinking = document.querySelector('.player-bar.top .thinking.on');
    const clock = (c) => `<div class="clock" data-clock="${c}"></div>`;
    const oppTitle = game.self ? esc(L3('Zu zweit', 'Two players', 'Dos jugadores')) : game.names ? esc(me === WHITE ? game.names.black : game.names.white) : game.online ? `${esc(game.online.oppName)} <span class="tag-online">${esc(t('online'))}</span>` : `${esc(t('bot'))} · ${esc(levelName(game.level))}`;
    const oppSub = game.self ? esc(L3('Ein PC, zwei Spieler · ohne Wertung', 'One PC, two players · unrated', 'Un PC, dos jugadores · sin Elo')) : game.online ? `${game.online.oppRating || '?'} Elo${game.online.oppStreak >= 2 ? ` · 🔥 ${game.online.oppStreak} ${esc(L3('Siege in Folge', 'wins in a row', 'victorias seguidas'))}` : ''}` : game.names ? esc(t('review')) : `≈ ${L.elo} Elo · ${esc(t('level'))} ${game.level + 1}`;
    const oppAvatar = game.online ? avatarHtml(game.online.oppCos || {}, 36) : '<div class="avatar bot">♚</div>';
    $('bar-top').innerHTML = `${oppAvatar}<div class="who"><b ${game.online ? nameStyle(game.online.oppCos) : ''}>${oppTitle} <span class="thinking"><i></i><i></i><i></i></span></b><span>${oppSub}</span></div><div class="captured">${capturedFor(me ^ 8)}</div>${clock(me === WHITE ? 'b' : 'w')}`;
    $('bar-bottom').innerHTML = `${avatarHtml(profile.cos.eq, 36)}<div class="who"><b ${nameStyle(profile.cos.eq)}>${esc(game.names ? (me === WHITE ? game.names.white : game.names.black) : profile.username || t('you'))}${titleHtml(profile.cos.eq)}</b><span>${profile.rating} Elo · ${esc(me === WHITE ? t('white') : t('black'))}</span></div><div class="captured">${capturedFor(me)}</div>${clock(me === WHITE ? 'w' : 'b')}`;
    if (thinking) document.querySelector('.player-bar.top .thinking').classList.add('on');
  }

  function renderMoves() {
    const box = $('moves');
    if (!game || !game.moves.length) {
      box.innerHTML = `<div class="empty">${esc(t('noMoves'))}</div>`;
      return;
    }
    const cur = viewPly === null ? game.moves.length : viewPly;
    const startBlack = game.startFen.split(' ')[1] === 'b';
    const list = startBlack ? [null, ...game.moves] : game.moves;
    let html = '';
    for (let i = 0; i < list.length; i += 2) {
      html += `<span class="no">${i / 2 + 1}.</span>`;
      for (const j of [i, i + 1]) {
        const m = list[j];
        const ply = startBlack ? j : j + 1;
        if (!m) {
          html += '<span></span>';
          continue;
        }
        const info = m.cls && profile.settings.badges && !paused() ? Coach.CLASSES[m.cls] : null;
        html += `<span class="mv${ply === cur ? ' cur' : ''}" data-ply="${ply}" title="${info ? esc(label(m.cls)) : ''}">${info ? `<i class="m" style="background:${info.color}">${info.mark}</i>` : ''}${esc(m.san)}</span>`;
      }
    }
    box.innerHTML = html;
    box.querySelector('.cur')?.scrollIntoView({ block: 'nearest' });
  }

  function renderChips() {
    $('elo').textContent = profile.rating;
    const d = $('elo-delta');
    d.textContent = profile.lastDelta ? `${profile.lastDelta > 0 ? '▲' : '▼'}${Math.abs(profile.lastDelta)}` : '';
    d.className = profile.lastDelta > 0 ? 'up' : profile.lastDelta < 0 ? 'down' : '';
    $('streak').textContent = profile.streak;
    $('chip-streak').classList.toggle('hot', profile.streak >= 3);
    $('chip-streak').title = t('streakTitle', { s: profile.streak, b: profile.bestStreak, d: profile.dayStreak });
    $('chip-elo').title = t('eloTitle');
  }

  function refresh() {
    if (game?.self && !game.over) game.userColor = pos.turn; // zu zweit: wer dran ist, zieht
    renderPieces();
    renderBars();
    renderMoves();
    renderChips();
    paintEval();
    $('btn-undo').disabled = !game || !game.moves.length || busy || modalOpen || Boolean(game.online) || Boolean(game.review);
    $('btn-hint').disabled = !canMove() || paused();
    $('btn-resign').disabled = !game || Boolean(game.over);
    $('btn-analyse').hidden = !game || !game.over;
    $('shell').classList.toggle('online-game', Boolean(game?.online && !game.over));
    renderClocks();
    if (premoves.length) setTimeout(runPremove, 90);
  }

  /* ================================================================ Dialoge */

  function modal(html, { side = false, onClick } = {}) {
    $('modal').innerHTML = html;
    $('modal-back').classList.toggle('side-left', side);
    $('modal-back').hidden = false;
    $('modal').onclick = onClick || null;
    modalOpen = true;
  }

  function closeModal() {
    if (typeof Matchmaking !== 'undefined') Matchmaking.stop();
    $('modal-back').hidden = true;
    $('modal').innerHTML = '';
    modalOpen = false;
  }

  /**
   * Erklärung zu einem eigenen Zug. live = direkt nach dem Zug (Bot wartet).
   * Ergebnis: 'retry' | 'show' | 'continue'.
   */
  function explainModal(ply, { live, tour = null }) {
    const a = analyses.get(ply);
    const entry = game?.moves[ply];
    if (!a || !entry) return Promise.resolve('continue');
    const { before, verdict } = a;
    const x = Coach.explain(before, verdict, I.lang);
    const cls = verdict.cls;
    const info = Coach.CLASSES[cls];
    if (!entry.note) entry.note = x.reasons[0]?.html || x.tips[0]?.html || '';
    // Brett zeigt die Stellung direkt nach dem Zug
    const atMove = viewPly === null && game.moves.length === ply + 1;
    if (!atMove) {
      viewPly = ply + 1;
      refresh();
    }
    const cards = [...x.reasons, ...x.tips];
    setMarks(x.marks);
    const canTakeBack = !game.over;
    return new Promise((resolve) => {
      refresh();
      modal(
        `<div class="lead oops"><div class="big" style="background:${info.color}">${info.mark}</div>
           <div><h2>${esc(x.title)}</h2><div class="sub">${entry.color !== (game.userColor === WHITE ? 'w' : 'b') ? `<b>${esc(t('moveOf', { who: entry.color === 'w' ? t('white') : t('black') }))}:</b> ` : ''}${t('yourMove', { san: `<b class="san">${esc(x.playedSan)}</b>`, phrase: `<b style="color:${info.color}">${esc(phrase(cls))}</b>` })}</div></div></div>
         <ul class="reasons">${cards.map((r, i) => `<li class="${r.tip ? 'tip' : ''}${i === 0 ? ' active' : ''}" data-card="${i}">${r.html}</li>`).join('')}</ul>
         <div class="muted small-note">${esc(t('clickCard'))}</div>
         <div class="better" id="better"><span class="reveal" id="reveal">${esc(t('revealBetter'))}</span></div>
         <div class="evalchange">${esc(t('evalFromYou'))} <b>${x.evalBefore}</b> → <b style="color:${info.color}">${x.evalAfter}</b></div>
         ${tour ? `<div class="tour-bar"><span>${esc(t('tourMistake', tour))}</span><div class="tour-dots">${Array.from({ length: tour.n }, (_, k) => `<i class="${k < tour.i ? 'on' : ''}"></i>`).join('')}</div></div>` : ''}
         <div class="btns">
           ${tour ? `<button class="btn" data-c="end">${esc(t('endTour'))}</button>` : canTakeBack ? `<button class="btn" data-c="retry">${esc(t('btnRetry'))}</button><button class="btn" data-c="show">${esc(t('btnShow'))}</button>` : ''}
           <button class="btn primary" data-c="continue">${esc(tour ? `${t('understood')} ✓` : live ? t('btnThanks') : t('btnOk'))}</button>
         </div>`,
        {
          side: true,
          onClick: (e) => {
            const card = e.target.closest('[data-card]');
            if (card) {
              const i = Number(card.dataset.card);
              $('modal').querySelectorAll('[data-card]').forEach((c) => c.classList.toggle('active', c === card));
              setMarks(cards[i]);
              return;
            }
            if (e.target.id === 'reveal') {
              $('better').innerHTML = `${t('better', { san: `<b class="san">${esc(x.bestSan)}</b>` })}${x.bestWhy ? ` ${x.bestWhy}` : ''}${x.bestLine ? `<br><span class="muted">${t('possibleLine', { line: esc(x.bestLine) })}</span>` : ''}`;
              setMarks({ arrows: x.bestArrow.length ? [[...x.bestArrow[0]]] : [], squares: [] });
              // Auf der Stellung VOR dem Zug ist der Pfeil richtig
              viewPly = ply;
              refresh();
              return;
            }
            const c = e.target.closest('[data-c]')?.dataset.c;
            if (!c) return;
            closeModal();
            if (c === 'end') {
              viewPly = null;
              setMarks(null);
              refresh();
              resolve('end');
              return;
            }
            if (c === 'retry' || c === 'show') {
              game.takebacks += 1;
              takeback(game.moves.length - ply);
              if (c === 'show') {
                game.assist = verdict.best.uci;
                setMarks({ arrows: x.bestArrow, squares: [] });
                bubble(t('tryIt', { san: `<b class="san">${esc(x.bestSan)}</b>`, why: x.bestWhy || '' }), 'best');
              } else bubble(esc(t('retryText')), 'good');
              saveGame();
              if (pos.turn !== game.userColor) botMove();
            } else {
              if (viewPly !== null) {
                viewPly = null;
                setMarks(null);
                refresh();
              }
              if (!live) setMarks(null);
            }
            resolve(c);
          },
        },
      );
    });
  }

  /** Zufällige Gegner: Warteschlange pro Bedenkzeit, Elo-Fenster wächst mit der Wartezeit. */
  const Matchmaking = {
    mm: null,
    async start(tc) {
      this.stop();
      const box = $('mm-box');
      if (box) box.innerHTML = `<div class="mm-search"><div class="mm-radar"><i></i><i></i><i></i><span>♞</span></div><div id="mm-text">${esc(t('connecting'))}</div><button class="btn small" data-a="unseek">${esc(t('cancelSearch'))}</button></div>`;
      const myElo = profile.rating;
      const mm = new window.RevNet.Matchmaker({
        app: 'chess',
        bucket: `tc${tc}`,
        name: profile.username || t('you'),
        info: { elo: myElo, tc },
        accept: (peer) => {
          const waited = Math.max(peer.waited || 0, (Date.now() - mm.started) / 1000);
          return Math.abs((peer.info?.elo ?? myElo) - myElo) <= 150 + waited * 25;
        },
      });
      this.mm = mm;
      mm.on('tick', (sec, n) => {
        if ($('mm-text')) $('mm-text').textContent = t('searching', { s: sec, n: Math.max(0, n) });
      });
      mm.on('match', async (match) => {
        this.mm = null;
        if ($('mm-text')) $('mm-text').textContent = t('found', { name: match.opp.name, elo: match.opp.info?.elo ?? '?' });
        Sound.play('start');
        try {
          await Online.open(match.code, match.host, tc);
        } catch (error) {
          if ($('net-status')) $('net-status').textContent = t('netFail', { e: error.message });
        }
      });
      try {
        await mm.start();
        if ($('mm-text')) $('mm-text').textContent = t('searching', { s: 0, n: 0 });
      } catch (error) {
        this.mm = null;
        if ($('net-status')) $('net-status').textContent = t('netFail', { e: error.message });
        if (box) box.innerHTML = `<button class="btn primary big-btn" data-a="seek">⚡ ${esc(t('findOpp'))}</button>`;
      }
    },
    stop() {
      this.mm?.stop();
      this.mm = null;
    },
  };

  function newGameModal(tab = 'bot') {
    const s = profile.settings;
    let level = Math.min(s.level, LEVELS.length - 1);
    let color = s.color;
    let tc = s.tc ?? 10;
    let sf = { installed: false };
    const levelHtml = () => `<div class="level-head"><div class="avatar bot">${level === SF_LEVEL ? '♛' : '♚'}</div><div><b>${esc(levelName(level))}</b><div class="muted">≈ ${LEVELS[level].elo} Elo · ${esc(t('ofLevels', { n: level + 1, total: LEVELS.length }))}</div></div></div>${
      level === SF_LEVEL && !sf.installed ? `<div class="sf-box"><span class="hint">${esc(t('sfNeed'))}</span>${sf.installing ? '' : `<button class="btn small" data-a="sf">${esc(t('sfInstall'))}</button>`}<div class="sf-bar"><i id="sf-bar"></i></div><span class="hint" id="sf-text">${sf.installing ? '…' : ''}</span></div>` : ''
    }`;
    const suggest = LEVELS.slice(0, SF_LEVEL).reduce((best, L, i) => (Math.abs(L.elo - profile.rating) < Math.abs(LEVELS[best].elo - profile.rating) ? i : best), 0);
    const modeName = profile.settings.paused ? t('paused').split(' – ')[0] : { auto: t('modeAuto'), popup: t('modePopup'), rate: t('modeRate') }[s.mode];
    const tcButtons = () => [0, 3, 5, 10, 15].map((n) => `<button data-tc="${n}" class="${tc === n ? 'on' : ''}">${esc(n ? t('minutes', { n }) : t('noClock'))}</button>`).join('');
    // Alle KI-Stufen auf einen Blick (Name, Elo, Stufe)
    const BOT_GLYPH = ['♙', '♙', '♘', '♘', '♗', '♗', '♖', '♖', '♕', '♔', '♛'];
    const levelGrid = () => `<div class="lvl-grid" id="lvl-grid">${LEVELS.map((L, i) => `<button class="lvl-card ${i === level ? 'on' : ''} ${i === suggest ? 'sug' : ''}" data-lvl="${i}" style="--h:${130 - i * 12}"><span class="lvl-g">${BOT_GLYPH[i] || '♚'}&#xFE0E;</span><b>${esc(levelName(i))}</b><span>${L.elo} Elo</span><small>${esc(t('level'))} ${i + 1}</small></button>`).join('')}</div>`;
    const botPane = `
       <button class="quick-start" data-a="quick"><span class="qs-ic">⚡</span><span><b>${esc(L3('Schnellstart', 'Quick start', 'Inicio rápido'))}</b><small>${esc(L3(`Passender Gegner: ${levelName(suggest)} (≈ ${LEVELS[suggest].elo} Elo), Farbe zufällig`, `Matching opponent: ${levelName(suggest)} (≈ ${LEVELS[suggest].elo} Elo), random colour`, `Rival adecuado: ${levelName(suggest)} (≈ ${LEVELS[suggest].elo} Elo)`))}</small></span><i>→</i></button>
       <div class="field levels"><label>${esc(t('levelPick'))}</label>${levelGrid()}<div id="lvl">${levelHtml()}</div>
         <span class="hint">${esc(t('suggest', { elo: profile.rating, n: suggest + 1 }))} <a href="#" id="lvl-suggest" style="color:var(--accent-2)">${esc(t('take'))}</a></span></div>
       <div class="field"><label>${esc(t('yourColor'))}</label>
         <div class="colors" id="colors">
           <button data-col="w" class="${color === 'w' ? 'on' : ''}">♔<span>${esc(t('white'))}</span></button>
           <button data-col="r" class="${color === 'r' ? 'on' : ''}">⚄<span>${esc(t('random'))}</span></button>
           <button data-col="b" class="${color === 'b' ? 'on' : ''}">♚<span>${esc(t('black'))}</span></button>
         </div></div>
       <div class="field"><label>${esc(t('coach'))}</label>
         <div class="sens" id="coach-pick">${[['off', L3('Aus', 'Off', 'No')], ['auto', t('modeAuto')], ['popup', t('modePopup')], ['rate', t('modeRate')]].map(([k, n]) => `<button data-cm="${k}" class="${(profile.settings.paused ? 'off' : s.mode) === k ? 'on' : ''}">${esc(n)}</button>`).join('')}</div></div>
       <div class="btns">${game && !game.over ? `<button class="btn" data-a="cancel">${esc(t('cancel'))}</button>` : ''}<button class="btn primary" data-a="start">${esc(t('start'))}</button></div>`;
    const onlinePane = `
       <div class="field"><label>${esc(t('username'))}</label><div class="me-line">${avatarHtml(profile.cos.eq, 30)}<b ${nameStyle(profile.cos.eq)}>${esc(profile.username)}</b></div></div>
       <div class="field"><label>${esc(t('timeControl'))}</label><div class="sens five" id="tcs">${tcButtons()}</div></div>
       <div class="field"><button class="btn primary" data-a="create">${esc(t('createRoom'))}</button></div>
       <div class="field"><label>${esc(t('roomCode'))}</label><div class="row"><input class="input code-in" id="join-code" maxlength="6" placeholder="${esc(t('codePh'))}" /><button class="btn" data-a="join">${esc(t('joinRoom'))}</button></div></div>
       <div class="hint" id="net-status">${esc(t('fairPlay'))}</div>`;
    const randomPane = `
       <div class="field"><div class="me-line">${avatarHtml(profile.cos.eq, 30)}<b ${nameStyle(profile.cos.eq)}>${esc(profile.username)}</b><span class="muted">${profile.rating} Elo</span></div></div>
       <div class="field"><label>${esc(t('timeControl'))}</label><div class="sens five" id="tcs">${tcButtons()}</div></div>
       <div class="hint">${esc(t('randomHint'))}</div>
       <div class="field mm-box" id="mm-box"><button class="btn primary big-btn" data-a="seek">⚡ ${esc(t('findOpp'))}</button></div>
       <div class="hint" id="net-status">${esc(t('fairPlay'))}</div>`;
    const localPane = `
       <div class="local-hero"><span>♔</span><i>vs</i><span>♚</span></div>
       <p class="muted" style="text-align:center;margin:0">${esc(L3('Beide Seiten werden an diesem PC gezogen – ideal zum Ausprobieren von Ideen oder für eine Partie mit jemandem neben dir. Ohne Coach und ohne Elo-Wertung.', 'Both sides are played on this PC – great for trying ideas or a game with someone next to you. No coach, unrated.', 'Ambos bandos se juegan en este PC. Sin coach y sin Elo.'))}</p>
       <div class="field"><div class="row"><label>${esc(L3('Brett nach jedem Zug drehen', 'Flip board after every move', 'Girar el tablero tras cada jugada'))}</label><button class="switch ${profile.settings.selfFlip ? 'on' : ''}" data-a="selfflip"></button></div><span class="hint">${esc(L3('Praktisch, wenn ihr euch gegenübersitzt und den Platz tauscht.', 'Handy when you swap seats.', 'Práctico si cambiáis de sitio.'))}</span></div>
       <div class="btns">${game && !game.over ? `<button class="btn" data-a="cancel">${esc(t('cancel'))}</button>` : ''}<button class="btn primary" data-a="self">${esc(t('start'))}</button></div>`;
    Matchmaking.stop();
    modal(
      `<div class="ng-head"><h2>${esc(t('newGame'))}</h2><button class="btn small ghost" data-a="lobby">⌂ ${esc(t('toLobby'))}</button></div>
       <nav class="mode-cards">${[
         ['bot', 'bot', t('vsBot'), L3('11 Stufen, mit Coach', '11 levels, with coach', '11 niveles, con coach')],
         ['local', 'users', L3('Zu zweit', 'Two players', 'Dos jugadores'), L3('Gegen dich selbst oder am selben PC', 'Against yourself or on one PC', 'Contra ti o en un PC')],
         ['random', 'bolt', t('vsRandom'), L3('Schnelle Online-Partie', 'Quick online game', 'Partida rápida online')],
         ['online', 'chat', t('vsFriend'), L3('Per Raum-Code', 'With a room code', 'Con código de sala')],
       ].map(([id, ic, name, sub]) => `<button data-pane="${id}" class="${tab === id ? 'on' : ''}"><span class="mc-ic">${window.icon ? window.icon(ic, 22) : ''}</span><b>${esc(name)}</b><small>${esc(sub)}</small></button>`).join('')}</nav>
       <div id="ng-pane">${tab === 'bot' ? botPane : tab === 'random' ? randomPane : tab === 'local' ? localPane : onlinePane}</div>`,
    );
    const pickLevel = (i) => {
      level = i;
      $('lvl-grid')?.querySelectorAll('[data-lvl]').forEach((b) => b.classList.toggle('on', Number(b.dataset.lvl) === i));
      if ($('lvl')) $('lvl').innerHTML = levelHtml();
    };
    window.stockfish?.status().then((st) => {
      sf = st || sf;
      if ($('lvl')) $('lvl').innerHTML = levelHtml();
    });
    const saveName = () => {
      /* Name kommt aus dem Profil (Benutzername) */
    };
    $('modal').onclick = async (e) => {
      const paneBtn = e.target.closest('[data-pane]');
      if (paneBtn) {
        newGameModal(paneBtn.dataset.pane);
        return;
      }
      if (e.target.id === 'lvl-suggest') {
        e.preventDefault();
        pickLevel(suggest);
        return;
      }
      const lv = e.target.closest('[data-lvl]');
      if (lv) {
        pickLevel(Number(lv.dataset.lvl));
        return;
      }
      const tcb = e.target.closest('[data-tc]');
      if (tcb) {
        tc = Number(tcb.dataset.tc);
        profile.settings.tc = tc;
        $('tcs').innerHTML = tcButtons();
        return;
      }
      const cm = e.target.closest('[data-cm]');
      if (cm) {
        profile.settings.paused = cm.dataset.cm === 'off';
        if (cm.dataset.cm !== 'off') profile.settings.mode = cm.dataset.cm;
        applySettings();
        saveProfile();
        $('coach-pick').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === cm));
        return;
      }
      const col = e.target.closest('[data-col]');
      if (col) {
        color = col.dataset.col;
        $('colors').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === col));
        return;
      }
      const a = e.target.closest('[data-a]')?.dataset.a;
      if (a === 'cancel') closeModal();
      if (a === 'lobby') {
        Matchmaking.stop();
        closeModal();
        Lobby.show('home');
        return;
      }
      if (a === 'quick') {
        profile.settings.level = suggest;
        saveProfile();
        closeModal();
        return startGame(suggest, Math.random() < 0.5 ? 'w' : 'b');
      }
      if (a === 'selfflip') {
        profile.settings.selfFlip = !profile.settings.selfFlip;
        saveProfile();
        return newGameModal('local');
      }
      if (a === 'self') {
        closeModal();
        return startGame(profile.settings.level, 'w', START_FEN, { self: true });
      }
      if (a === 'seek') return Matchmaking.start(tc);
      if (a === 'unseek') {
        Matchmaking.stop();
        newGameModal('random');
        return;
      }
      if (a === 'sf') {
        const btn = e.target.closest('[data-a]');
        btn.disabled = true;
        const r = await window.stockfish.install();
        if (r?.ok) {
          sf = { installed: true, version: r.version };
          $('lvl').innerHTML = levelHtml();
          showToast(t('sfReady', { v: r.version || '' }));
        } else {
          btn.disabled = false;
          if ($('sf-text')) $('sf-text').textContent = t('sfFail', { e: r?.error || '?' });
        }
        return;
      }
      if (a === 'start') {
        profile.settings.level = level;
        profile.settings.color = color;
        saveProfile();
        closeModal();
        startGame(level, color === 'r' ? (Math.random() < 0.5 ? 'w' : 'b') : color);
      }
      if (a === 'create' || a === 'join') {
        saveName();
        const code = a === 'create' ? window.RevNet.newCode() : ($('join-code').value || '').trim().toUpperCase();
        if (code.length < 4) return;
        $('net-status').textContent = t('connecting');
        try {
          await Online.open(code, a === 'create', tc);
        } catch (error) {
          $('net-status').textContent = t('netFail', { e: error.message });
          return;
        }
        if (a === 'create') {
          $('ng-pane').innerHTML = `<div class="field room-wait"><span class="hint">${esc(t('shareCode'))}</span><div class="room-code">${esc(code)}</div>
            <button class="btn small" data-a="copy">${esc(t('copy'))}</button><div class="hint"><span class="spinner"></span> ${esc(t('waiting'))}</div>
            <button class="btn small ghost" data-a="leave">${esc(t('leaveRoom'))}</button></div>`;
        } else $('net-status').textContent = t('waiting');
      }
      if (a === 'copy') {
        navigator.clipboard?.writeText(Online.code || '').catch(() => {});
        e.target.textContent = t('copied');
      }
      if (a === 'leave') {
        Online.leave();
        newGameModal('online');
      }
    };
  }

  function showToast(text) {
    const el = $('toast');
    el.textContent = text;
    el.className = 'toast';
    el.hidden = false;
    clearTimeout(showToast.t);
    showToast.t = setTimeout(() => (el.hidden = true), 2600);
  }

  window.stockfish?.onProgress?.(({ p, text }) => {
    const bar = $('sf-bar');
    if (bar) bar.style.width = `${Math.round(p * 100)}%`;
    if ($('sf-text')) $('sf-text').textContent = text || '';
  });

  /* ================================================================ Online */

  const Online = {
    room: null,
    code: '',
    host: false,
    tc: 0,
    clocks: null,
    rematchWanted: { me: false, them: false },

    async open(code, host, tc) {
      this.leave();
      this.code = code;
      this.host = host;
      this.tc = tc;
      const room = new window.RevNet.Room({ app: 'chess', code, name: profile.username || t('you') });
      room.on('peer', (p) => {
        this.peerName = p.name || 'Gegner';
        clearTimeout(this.leftTimer);
        if (this.host && !game?.online) this.sendSetup();
      });
      room.on('msg', (m) => this.onMsg(m));
      room.on('left', () => {
        if (!game?.online || game.over) return;
        // Gegner weg: nach kurzer Wartezeit (falls nur die Verbindung hakt) gewinnst du automatisch
        bubble(`${esc(t('oppLeft', { name: game.online.oppName }))} ${esc(L3('Kommt er nicht in 8 Sekunden zurück, gewinnst du.', 'If they are not back within 8 seconds, you win.', 'Si no vuelve en 8 segundos, ganas.'))}`, 'think');
        clearTimeout(this.leftTimer);
        const g = game;
        this.leftTimer = setTimeout(() => {
          if (game === g && !g.over) finish({ result: g.userColor === WHITE ? '1-0' : '0-1', reason: L3(`${g.online.oppName} hat das Spiel verlassen`, `${g.online.oppName} left the game`, `${g.online.oppName} abandonó la partida`) });
        }, 8000);
      });
      await room.join();
      this.room = room;
    },

    sendSetup(swap = false) {
      const hostWhite = swap ? !(game?.online?.hostWhite ?? true) : Math.random() < 0.5;
      this.send('setup', { hostWhite, tc: this.tc, rating: profile.rating, cos: profile.cos.eq, streak: profile.streak || 0, chat: window.GameChat?.mine() });
      this.setupPending = { hostWhite };
    },

    send(type, data = {}) {
      this.room?.send(type, data);
    },

    start(hostWhite, tc, oppRating) {
      const iAmWhite = this.host ? hostWhite : !hostWhite;
      closeModal();
      this.tc = tc;
      this.clocks = tc ? { w: tc * 60000, b: tc * 60000, at: 0 } : null;
      this.rematchWanted = { me: false, them: false };
      startGame(3, iAmWhite ? 'w' : 'b', START_FEN, { online: { code: this.code, oppName: this.peerName || 'Gegner', oppRating, hostWhite, oppCos: this.peerCos || {}, oppStreak: this.peerStreak || 0 } });
      localStorage.setItem('chessAbandon', JSON.stringify({ opp: oppRating || profile.rating, at: Date.now() }));
      const gc = window.GameChat?.buttons(this.peerChat, this.peerName, 'Schach', this.peerCos);
      if (gc) setTimeout(() => bubble(`${esc(L3(`Du spielst gegen ${this.peerName}.`, `You are playing ${this.peerName}.`, `Juegas contra ${this.peerName}.`))} ${gc}`, 'book'), 1800);
      this.lastSent = null;
      this.startTick();
    },

    onMsg(m) {
      if (m.t === 'setup' && !this.host) {
        this.peerName = m.name;
        this.peerCos = m.cos || {};
        this.peerStreak = Number(m.streak) || 0;
        this.peerChat = m.chat || null;
        this.send('ready', { rating: profile.rating, cos: profile.cos.eq, streak: profile.streak || 0, chat: window.GameChat?.mine() });
        this.start(m.hostWhite, m.tc, m.rating);
      } else if (m.t === 'ready' && this.host && this.setupPending) {
        this.peerCos = m.cos || {};
        this.peerChat = m.chat || null;
        this.peerStreak = Number(m.streak) || 0;
        this.start(this.setupPending.hostWhite, this.tc, m.rating);
        this.setupPending = null;
      } else if (m.t === 'move' && game?.online && !game.over) {
        if (m.ply !== game.moves.length + 1 || pos.turn === game.userColor) return;
        const mv = pos.find(m.uci);
        if (!mv) return;
        if (this.clocks && m.clock != null) this.clocks[game.userColor === WHITE ? 'b' : 'w'] = m.clock;
        if (this.clocks) this.clocks.at = Date.now();
        this.send('ack', { ply: m.ply });
        play(mv).then(() => checkEnd());
      } else if (m.t === 'ack') {
        if (this.lastSent?.ply === m.ply) this.lastSent = null;
      } else if (m.t === 'resign' && game?.online && !game.over) {
        bubble(esc(t('oppResigned', { name: game.online.oppName })), 'best');
        finish({ result: game.userColor === WHITE ? '1-0' : '0-1', reason: 'Aufgegeben' });
      } else if (m.t === 'flag' && game?.online && !game.over) {
        finish({ result: game.userColor === WHITE ? '1-0' : '0-1', reason: t('timeout') });
      } else if (m.t === 'rematch') {
        this.rematchWanted.them = true;
        bubble(esc(t('rematchAsk', { name: this.peerName })) + ` <button class="btn small explain-btn" data-rematch="1">${esc(t('rematch'))}</button>`, 'book');
        if (this.rematchWanted.me && this.host) this.sendSetup(true);
      }
    },

    sendMove(u, ply) {
      if (this.clocks) {
        const mine = game.userColor === WHITE ? 'w' : 'b';
        this.clocks.at = Date.now();
        this.lastSent = { uci: u, ply, clock: this.clocks[mine] };
      } else this.lastSent = { uci: u, ply };
      this.send('move', this.lastSent);
      // bis zur Bestätigung wiederholen (falls ein Paket verloren geht)
      clearInterval(this.resend);
      this.resend = setInterval(() => {
        if (!this.lastSent || !game?.online || game.over) return clearInterval(this.resend);
        this.send('move', this.lastSent);
      }, 2500);
    },

    startTick() {
      clearInterval(this.tick);
      if (!this.clocks) return;
      this.clocks.at = Date.now();
      this.tick = setInterval(() => {
        if (!game?.online || game.over || !this.clocks) return clearInterval(this.tick);
        if (!game.moves.length) return; // Uhr läuft erst ab dem ersten Zug
        const side = pos.turn === WHITE ? 'w' : 'b';
        const now = Date.now();
        this.clocks[side] = Math.max(0, this.clocks[side] - (now - this.clocks.at));
        this.clocks.at = now;
        renderClocks();
        const mine = game.userColor === WHITE ? 'w' : 'b';
        if (this.clocks[mine] <= 0 && side === mine) {
          this.send('flag');
          finish({ result: game.userColor === WHITE ? '0-1' : '1-0', reason: t('timeout') });
        }
      }, 200);
    },

    rematch() {
      this.rematchWanted.me = true;
      this.send('rematch');
      if (this.rematchWanted.them && this.host) this.sendSetup(true);
    },

    leave() {
      clearTimeout(this.leftTimer);
      // Wer eine laufende Online-Partie verlässt, verliert (mit Elo-Abzug)
      if (game?.online && !game.over && game.moves.length) finish({ result: game.userColor === WHITE ? '0-1' : '1-0', reason: L3('Partie verlassen', 'Left the game', 'Abandonaste la partida') });
      clearInterval(this.tick);
      clearInterval(this.resend);
      this.room?.leave();
      this.room = null;
      this.setupPending = null;
    },
  };

  function renderClocks() {
    document.querySelectorAll('[data-clock]').forEach((el) => {
      const c = Online.clocks && game?.online ? Online.clocks[el.dataset.clock] : null;
      el.hidden = c == null;
      if (c == null) return;
      const sec = Math.ceil(c / 1000);
      el.textContent = `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;
      const running = game && !game.over && game.moves.length && (pos.turn === WHITE ? 'w' : 'b') === el.dataset.clock;
      el.classList.toggle('run', Boolean(running));
      el.classList.toggle('low', c < 20000);
    });
  }

  $('bubble').addEventListener('click', (e) => {
    if (e.target.closest('[data-claim]') && game?.online && !game.over) finish({ result: game.userColor === WHITE ? '1-0' : '0-1', reason: t('oppLeft', { name: game.online.oppName }) });
    if (e.target.closest('[data-rematch]')) Online.rematch();
  });

  /* ================================================================ Analyse der ganzen Partie */

  let analysing = false;
  async function analyseGame(tour = true) {
    if (!game || analysing || !game.moves.length) return;
    analysing = true;
    const my = token;
    const n = game.moves.length;
    const p = new Position(game.startFen);
    try {
      for (let ply = 0; ply < n; ply += 1) {
        const entry = game.moves[ply];
        const before = p.clone();
        if (!analyses.has(ply)) {
          bubble(esc(t('analysing', { i: ply + 1, n })), 'think');
          const res = await ask('analyse', { moves: game.moves.slice(0, ply).map((m) => m.uci), played: entry.uci, timeMs: 380, maxDepth: 5 });
          if (my !== token) return;
          const verdict = Coach.classify(before, res.rows, entry.uci, { ply });
          if (verdict) {
            analyses.set(ply, { before, verdict, concrete: Coach.explain(before, verdict, I.lang).concrete });
            Object.assign(entry, { cls: entry.assisted ? 'assisted' : verdict.cls, real: verdict.cls, acc: verdict.accuracy, loss: verdict.loss, best: verdict.best.uci });
            recordWeak(before, verdict, entry);
            if (ply % 4 === 3) renderMoves();
          }
        }
        p.make(p.find(entry.uci));
      }
    } catch {
      /* abgebrochen */
    } finally {
      analysing = false;
    }
    if (my !== token) return;
    const accOf = (c) => {
      const list = game.moves.filter((m) => m.color === c && typeof m.acc === 'number');
      return list.length ? Math.round(list.reduce((a, m) => a + m.acc, 0) / list.length) : 0;
    };
    renderMoves();
    saveProfile();
    bubble(`${esc(t('analysed', { w: accOf('w'), b: accOf('b') }))} <button class="btn small explain-btn" data-tour="1">${esc(t('understood'))} → ${esc(t('tourMistake', { i: 1, n: tourPlies().length || 0 }))}</button>`, 'best');
    if (tour && !modalOpen) runTour();
  }

  /** Eigene Fehler (ohne Ungenauigkeiten) in Zugreihenfolge. */
  function tourPlies() {
    if (!game) return [];
    const me = game.userColor === WHITE ? 'w' : 'b';
    return game.moves.map((m, i) => ({ m, i })).filter(({ m, i }) => m.color === me && ['mistake', 'miss', 'blunder'].includes(m.real || m.cls) && analyses.get(i)).map(({ i }) => i);
  }

  /** Analyse-Tour: springt zum ersten Fehler, „Verstanden“ → nächster Fehler. */
  async function runTour() {
    const plies = tourPlies();
    if (!plies.length) {
      bubble(esc(t('tourNone')), 'best');
      return;
    }
    for (let i = 0; i < plies.length; i += 1) {
      const choice = await explainModal(plies[i], { live: false, tour: { i: i + 1, n: plies.length } });
      if (choice !== 'continue') return;
    }
    viewPly = null;
    setMarks(null);
    refresh();
    bubble(esc(t('tourDone')), 'best');
    Sound.play('nice');
  }

  $('bubble').addEventListener('click', (e) => {
    if (e.target.closest('[data-tour]')) runTour();
  });

  /* ================================================================ Archiv */

  async function renderArchive() {
    const games = (await window.chessApp?.games().catch(() => [])) || [];
    $('archive').innerHTML = games.length
      ? `<div class="history">${games
          .slice(0, 80)
          .map((g, i) => {
            const res = g.result === 1 ? t('win') : g.result === 0 ? t('loss') : t('draw');
            const when = new Date(g.at).toLocaleString(I.lang, { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
            const who = g.white && g.black ? `${g.white} – ${g.black}` : `${t('vs')} ${levelName(g.level)}`;
            return `<div class="hist-row arch"><span class="res ${g.result === 1 ? 'win' : g.result === 0 ? 'loss' : 'draw'}">${esc(res)}</span>
              <span><b>${esc(who)}</b><br><span class="muted">${esc(when)} · ${g.moves || 0} · ${esc(reasonText(g.reason))}${g.type === 'online' ? ` · ${esc(t('online'))}` : ''}</span></span>
              ${g.uci ? `<button class="btn small" data-arch="${i}">${esc(t('open'))}</button>` : `<span class="muted">${esc(t('oldGame'))}</span>`}</div>`;
          })
          .join('')}</div>`
      : `<div class="muted">${esc(t('archiveEmpty'))}</div>`;
    $('archive').onclick = (e) => {
      const b = e.target.closest('[data-arch]');
      if (b) openReview(games[Number(b.dataset.arch)]);
    };
  }

  function openReview(rec) {
    if (!rec?.uci) return;
    Online.leave();
    token += 1;
    const p = new Position(rec.startFen || START_FEN);
    const moves = [];
    for (const u of rec.uci) {
      const m = p.find(u);
      if (!m) break;
      moves.push({ uci: u, san: san(p, m), color: p.turn === WHITE ? 'w' : 'b' });
      p.make(m);
    }
    game = { id: rec.id || rec.at, review: true, startFen: rec.startFen || START_FEN, moves, userColor: rec.color === 'b' ? BLACK : WHITE, level: rec.level ?? 3, over: { result: rec.resultStr || '', reason: rec.reason }, names: { white: rec.white || (rec.color === 'w' ? t('you') : t('bot')), black: rec.black || (rec.color === 'b' ? t('you') : t('bot')) }, evalWhite: 0, hints: 0, takebacks: 0 };
    pos = p;
    analyses.clear();
    flipped = game.userColor === BLACK;
    viewPly = null;
    coachMarks = { arrows: [], squares: [] };
    buildSquares();
    document.querySelector('[data-tab="game"]').click();
    refresh();
    bubble(`${esc(t('reviewOf', { w: game.names.white, b: game.names.black }))} <button class="btn small explain-btn" data-analyse="1">${esc(t('analyse'))}</button>`, 'book');
  }

  $('bubble').addEventListener('click', (e) => {
    if (e.target.closest('[data-analyse]')) analyseGame();
  });

  async function startGame(level, color, fen = START_FEN, extra = null) {
    token += 1;
    game = { id: Date.now(), startFen: fen, moves: [], userColor: color === 'b' ? BLACK : WHITE, level, over: null, hints: 0, takebacks: 0, evalWhite: 0, started: Date.now(), assist: null, ...(extra || {}) };
    pos = new Position(fen);
    analyses.clear();
    flipped = game.userColor === BLACK;
    viewPly = null;
    selected = -1;
    busy = false;
    userArrows = [];
    userSquares = [];
    premoves = [];
    pmSel = -1;
    planDots = [];
    coachMarks = { arrows: [], squares: [] };
    ask('reset').catch(() => {});
    buildSquares();
    refresh();
    Sound.play('start');
    if (game.self) bubble(esc(L3('Zu zweit an einem PC: Weiß beginnt, danach wird abwechselnd gezogen. Diese Partie zählt nicht für deine Elo.', 'Two players, one PC: White starts, then you take turns. This game is unrated.', 'Dos jugadores en un PC: empiezan las blancas. Esta partida no cuenta para tu Elo.')), 'book');
    else if (game.online) bubble(`${t('joined', { name: esc(game.online.oppName) })} ${esc(t('fairPlay'))}`, 'book');
    else bubble(t('newGameText', { name: esc(levelName(level)), elo: LEVELS[level].elo, color: game.userColor === WHITE ? t('youStart') : t('black') }), 'book');
    saveGame();
    if (game.userColor === BLACK) await botMove();
  }

  async function finish(status) {
    if (game.over) return;
    if (game.online) localStorage.removeItem('chessAbandon');
    if (game.lesson) {
      game.over = status;
      return;
    }
    if (game.scenario) {
      game.over = status;
      Scenario.onEnd(status);
      return;
    }
    if (game.self) {
      game.over = status;
      busy = false;
      setThinking(false);
      Sound.play('nice');
      const who = status.result === '1-0' ? t('white') : status.result === '0-1' ? t('black') : '';
      bubble(`<b>${esc(who ? L3(`${who} gewinnt!`, `${who} wins!`, `¡Ganan las ${who}!`) : L3('Remis!', 'Draw!', '¡Tablas!'))}</b> ${esc(status.reason || '')}`, 'best');
      refresh();
      saveGame();
      return;
    }
    game.over = status;
    busy = false;
    setThinking(false);
    await sleep(500);
    const me = game.userColor;
    const score = status.result === '1/2-1/2' ? 0.5 : (status.result === '1-0') === (me === WHITE) ? 1 : 0;
    // Züge mit Hilfe zählen nicht für Genauigkeit und Statistik
    const mine = game.moves.filter((m) => m.color === (me === WHITE ? 'w' : 'b') && typeof m.acc === 'number' && !m.assisted);
    const acc = mine.length ? mine.reduce((s, m) => s + m.acc, 0) / mine.length : 0;
    const perf = mine.length >= 4 ? cal(Coach.accuracyToElo(acc)) : 0;
    const before = profile.rating;
    // Mit Hilfe gespielt (Tipp oder gezeigter Zug) → keine Elo-Wertung
    const helped = game.moves.some((m) => m.assisted);
    const oppElo = game.online ? game.online.oppRating || before : LEVELS[game.level].elo;
    let after = helped ? before : Math.max(100, Coach.eloUpdate(before, oppElo, score, profile.games));
    game.unrated = helped;
    let placeMore = false;
    if (game.placement) {
      // Einstufung: 3 Partien, der Gegner passt sich an. Gewertet wird vor allem das
      // ERGEBNIS gegen die jeweilige Stärke – die Genauigkeit zählt nur wenig, weil sie
      // gegen schwache Gegner geschönt ist. Wer gegen 400 verliert, landet nicht bei 740.
      const run = profile.placeRun || { res: [] };
      run.res.push({ opp: LEVELS[game.level].elo, lvl: game.level, s: score, acc: mine.length >= 6 ? acc : null });
      if (run.res.length < 3) {
        profile.placeRun = run;
        after = before;
        placeMore = true;
      } else {
        after = placementElo(run.res);
        delete profile.placeRun;
        profile.placed = true;
        profile.beginner = after < 700;
        profile.peak = after;
        profile.ratingHistory = [];
      }
    }
    const counts = {};
    for (const m of mine) counts[m.cls] = (counts[m.cls] || 0) + 1;
    const earned = helped ? 0 : game.online ? (score === 1 ? 20 : score === 0.5 ? 8 : 3) : score === 1 ? 5 + game.level * 3 : score === 0.5 ? 3 : 1;
    earn(earned);
    game.earned = earned;
    profile.games += 1;
    if (score === 1) profile.wins += 1;
    else if (score === 0) profile.losses += 1;
    else profile.draws += 1;
    profile.streak = score === 1 ? profile.streak + 1 : score === 0 ? 0 : profile.streak;
    profile.bestStreak = Math.max(profile.bestStreak, profile.streak);
    const y = new Date(Date.now() - 864e5).toLocaleDateString('sv-SE');
    if (profile.lastDay !== today()) profile.dayStreak = profile.lastDay === y ? profile.dayStreak + 1 : 1;
    profile.lastDay = today();
    profile.bestDayStreak = Math.max(profile.bestDayStreak, profile.dayStreak);
    profile.lastDelta = after - before;
    profile.rating = after;
    profile.peak = Math.max(profile.peak, after);
    profile.ratingHistory = [...profile.ratingHistory, after].slice(-60);
    if (profile.placed && !helped) profile.ratingLog = [...(profile.ratingLog || []), { at: Date.now(), r: after }].slice(-200);
    for (const [k, v] of Object.entries(counts)) profile.counts[k] = (profile.counts[k] || 0) + v;
    if (mine.length >= 4) {
      profile.accSum += acc;
      profile.accGames += 1;
      profile.perfBest = Math.max(profile.perfBest, perf);
    }
    saveProfile();
    saveGame();
    const myName = profile.name || t('you');
    const oppName = game.online ? game.online.oppName : `${t('bot')} · ${levelName(game.level)}`;
    window.chessApp?.addGame({
      id: game.id, at: Date.now(), type: game.online ? 'online' : 'bot', result: score, resultStr: status.result, reason: status.reason,
      color: me === WHITE ? 'w' : 'b', level: game.level, acc: Math.round(acc), perf, before, after, unrated: helped,
      white: me === WHITE ? myName : oppName, black: me === WHITE ? oppName : myName,
      startFen: game.startFen, uci: game.moves.map((m) => m.uci), moves: game.moves.length, san: game.moves.map((m) => m.san).join(' '),
    }).catch(() => {});
    if (profile.settings.review) setTimeout(() => analyseGame(false), 400);
    Sound.play(score === 1 ? 'win' : score === 0 ? 'lose' : 'draw');
    refresh();
    if (placeMore) placementNext();
    else if (game.placement) placementResult(after);
    else resultModal({ score, status, acc, perf, before, after, counts, unrated: helped });
  }

  const reasonText = (r) => t('reasons')[r] || r;

  function resultModal({ score, status, acc, perf, before, after, counts, unrated }) {
    const title = score === 1 ? t('won') : score === 0 ? t('lost') : t('draw');
    const cls = score === 1 ? 'win' : score === 0 ? 'loss' : '';
    const r = 50, c = 2 * Math.PI * r;
    const moments = game.moves.map((m, i) => ({ m, i })).filter(({ m }) => ['brilliant', 'great', 'blunder', 'mistake', 'miss'].includes(m.cls)).slice(0, 8);
    modal(
      `<div class="result-hero">
         <div class="big ${cls}">${esc(title)}</div><div class="muted">${esc(reasonText(status.reason))}</div>
         ${perf ? `<svg class="acc-ring" viewBox="0 0 120 120"><circle cx="60" cy="60" r="${r}" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="10"/>
           <circle id="acc-arc" cx="60" cy="60" r="${r}" fill="none" stroke="#81b64c" stroke-width="10" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c}" transform="rotate(-90 60 60)" style="transition:stroke-dashoffset 1.2s cubic-bezier(.2,.9,.3,1)"/>
           <text x="60" y="58" text-anchor="middle" fill="#fff" font-size="26" font-weight="800">${Math.round(acc)}%</text><text x="60" y="78" text-anchor="middle" fill="#9b99ad" font-size="11">${esc(t('accuracy'))}</text></svg>
           <div>${t('playedLike', { elo: perf })}</div>` : ''}
         ${unrated ? `<div class="muted">${esc(t('unrated'))}</div>` : `<div class="elo-change">Elo <b id="elo-roll">${before}</b> <span style="color:${after >= before ? 'var(--ok)' : 'var(--danger)'}">${after >= before ? '▲' : '▼'} ${Math.abs(after - before)}</span></div>`}
         ${game.earned ? `<div class="earned">${esc(t('earned', { p: game.earned }))}</div>` : ''}
         ${profile.streak >= 2 ? `<div class="muted">${esc(t('winStreak'))}: <b style="color:#ff8a3d">${profile.streak}</b></div>` : ''}
       </div>
       <div class="dist">${ORDER.filter((k) => counts[k]).map((k) => `<div class="dist-row"><i class="m" style="background:${Coach.CLASSES[k].color}">${Coach.CLASSES[k].mark}</i><span>${esc(label(k))}</span><span></span><b>${counts[k]}</b></div>`).join('')}</div>
       ${moments.length ? `<div class="card-title">${esc(t('keyMoments'))}</div><div class="key-moments">${moments.map(({ m, i }) => `<button data-ply="${i + 1}"><i class="m" style="background:${Coach.CLASSES[m.cls].color}">${Coach.CLASSES[m.cls].mark}</i>${Math.floor(i / 2) + 1}${m.color === 'w' ? '.' : '…'} ${esc(m.san)} – ${esc(label(m.cls))}</button>`).join('')}</div>` : ''}
       <div class="btns">${game.online ? `<button class="btn" data-a="rematch">${esc(t('rematch'))}</button>` : ''}<button class="btn" data-a="review">${esc(t('review'))}</button><button class="btn primary" data-a="new">${esc(t('newGame'))}</button></div>`,
      {
        onClick: (e) => {
          const k = e.target.closest('[data-ply]');
          if (k) {
            closeModal();
            view(Number(k.dataset.ply));
            return;
          }
          const a = e.target.closest('[data-a]')?.dataset.a;
          if (a === 'review') closeModal();
          if (a === 'rematch') {
            closeModal();
            Online.rematch();
          }
          if (a === 'new') {
            Online.leave();
            newGameModal();
          }
        },
      },
    );
    requestAnimationFrame(() => {
      const arc = $('acc-arc');
      if (arc) arc.style.strokeDashoffset = String(c * (1 - acc / 100));
      const el = $('elo-roll');
      const t0 = performance.now();
      const step = (now) => {
        const k = Math.min(1, (now - t0) / 1100);
        if (el) el.textContent = Math.round(before + (after - before) * (1 - (1 - k) ** 3));
        if (k < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
    $('chip-elo').classList.remove('bump');
    void $('chip-elo').offsetWidth;
    $('chip-elo').classList.add('bump');
  }

  /* ================================================================ Ansicht / Navigation */

  function view(ply) {
    if (!game) return;
    const max = game.moves.length;
    ply = Math.max(0, Math.min(max, ply));
    viewPly = ply === max ? null : ply;
    selected = -1;
    const m = game.moves[ply - 1];
    coachMarks = { arrows: [], squares: [] };
    if (m?.cls && !paused()) {
      const info = Coach.CLASSES[m.cls];
      const hasExplain = analyses.get(ply - 1)?.concrete && (BAD.includes(m.real || m.cls) || m.cls === 'good');
      if (m.best && m.uci !== m.best && BAD.includes(m.real || m.cls)) {
        // Der bessere Zug gehört zur Stellung VOR dem Zug – also dort anzeigen
        viewPly = ply - 1;
        coachMarks = { arrows: [[sqFrom(m.best.slice(0, 2)), sqFrom(m.best.slice(2, 4)), '#81b64c']], squares: [] };
      }
      bubble(`<b style="color:${info.color}">${esc(label(m.cls))}:</b> ${esc(m.san)}${m.note && !hasExplain ? `. ${m.note}` : ''} ${coachMarks.arrows.length ? `<span class="muted">${esc(t('greenArrow'))}</span>` : ''}${hasExplain ? explainButton(ply - 1) : ''}`, m.cls);
    }
    refresh();
  }

  $('moves').addEventListener('click', (e) => {
    const el = e.target.closest('[data-ply]');
    if (el) view(Number(el.dataset.ply));
  });

  document.querySelector('.nav-row').addEventListener('click', (e) => {
    const n = e.target.closest('[data-nav]')?.dataset.nav;
    if (!n || !game) return;
    const cur = viewPly === null ? game.moves.length : viewPly;
    if (n === 'first') view(0);
    if (n === 'prev') view(cur - 1);
    if (n === 'next') view(cur + 1);
    if (n === 'last') view(game.moves.length);
  });

  window.addEventListener('keydown', (e) => {
    if (!game || modalOpen || /input|textarea/i.test(e.target.tagName)) return;
    const cur = viewPly === null ? game.moves.length : viewPly;
    if (e.key === 'ArrowLeft') view(cur - 1);
    if (e.key === 'ArrowRight') view(cur + 1);
    if (e.key === 'Home') view(0);
    if (e.key === 'End') view(game.moves.length);
  });

  /* ================================================================ Knöpfe */

  $('btn-new').onclick = () => (game?.scenario ? Lobby.show('learn') : newGameModal(game?.online ? 'online' : 'bot'));
  $('btn-lobby').onclick = () => Lobby.show();
  $('btn-analyse').onclick = () => analyseGame();
  $('view-chips').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.id === 'btn-3d') {
      profile.settings.view3d = !profile.settings.view3d;
      applySettings();
      saveProfile();
      renderSettings();
      refresh();
      return;
    }
    b3?.view(b.dataset.view);
  });
  $('btn-mute').onclick = () => {
    profile.settings.sound = !profile.settings.sound;
    applySettings();
    saveProfile();
    renderSettings();
    if (profile.settings.sound) Sound.play('move');
  };
  $('btn-flip').onclick = () => {
    flipped = !flipped;
    buildSquares();
    refresh();
  };
  $('btn-pause').onclick = () => {
    profile.settings.paused = !profile.settings.paused;
    applySettings();
    saveProfile();
    setMarks(null);
    bubble(esc(paused() ? t('paused') : t('resumed')), paused() ? 'pause' : 'book');
    refresh();
    if (!$('settings').closest('.tab').hidden) renderSettings();
  };
  $('btn-undo').onclick = () => {
    if (!game || !game.moves.length || busy) return;
    if (game.over) game.over = null;
    const last = game.moves[game.moves.length - 1];
    const plies = last.color === (game.userColor === WHITE ? 'w' : 'b') ? 1 : Math.min(2, game.moves.length);
    game.takebacks += 1;
    takeback(plies);
    bubble(esc(t('takenBack')), 'good');
    if (pos.turn !== game.userColor) botMove();
  };
  $('btn-hint').onclick = async () => {
    if (!canMove() || paused()) return;
    const my = token;
    busy = true;
    refresh();
    bubble(esc(t('thinkingHint')), 'think');
    try {
      // Tipp: sicherer Zug statt riskanter Tausche (Dame gegen Dame usw.)
      const res = await ask('analyse', { timeMs: 900, maxDepth: 7 });
      if (my !== token) return;
      const pick = res?.rows?.length ? Coach.safeBest(pos, res.rows) : null;
      const r = pick ? { move: pick.uci } : await ask('hint', { timeMs: 800, maxDepth: 10 });
      if (my !== token) return;
      const m = r && pos.find(r.move);
      if (m) {
        game.hints += 1;
        game.assist = r.move;
        setMarks({ arrows: [[m.from, m.to, '#81b64c']], squares: [] });
        bubble(t('hintText', { piece: esc(PIECE_NAMES[I.lang]?.[typeOf(m.piece)] || ''), sq: sqName(m.from) }), 'best');
      }
    } finally {
      busy = false;
      refresh();
    }
  };
  let resignArmed = 0;
  $('btn-resign').onclick = () => {
    if (!game || game.over) return;
    const label = $('btn-resign').querySelector('[data-i18n]');
    if (Date.now() - resignArmed > 3000) {
      resignArmed = Date.now();
      label.textContent = t('resignSure');
      setTimeout(() => (label.textContent = t('resign')), 3000);
      return;
    }
    token += 1;
    label.textContent = t('resign');
    if (game.online) Online.send('resign');
    finish({ result: game.userColor === WHITE ? '0-1' : '1-0', reason: 'Aufgegeben' });
  };

  /* ================================================================ Tabs */

  $('tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    $('tabs').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
    document.querySelectorAll('.tab').forEach((x) => (x.hidden = x.dataset.pane !== b.dataset.tab));
    if (b.dataset.tab === 'stats') renderStats();
    if (b.dataset.tab === 'settings') renderSettings();
    if (b.dataset.tab === 'archive') renderArchive();
  });

  async function renderStats() {
    const p = profile;
    const hist = p.ratingHistory.length > 1 ? p.ratingHistory : [p.rating, p.rating];
    const min = Math.min(...hist) - 20, max = Math.max(...hist) + 20;
    const pts = hist.map((v, i) => `${(i / (hist.length - 1)) * 300},${80 - ((v - min) / (max - min)) * 70}`).join(' ');
    const total = Object.values(p.counts).reduce((a, b) => a + b, 0) || 1;
    const games = (await window.chessApp?.games().catch(() => [])) || [];
    $('stats').innerHTML = `
      <div class="stat-grid">
        <div class="stat"><span>${esc(t('sElo'))}</span><b>${p.rating}</b></div>
        <div class="stat"><span>${esc(t('sPeak'))}</span><b>${p.peak}</b></div>
        <div class="stat"><span>${esc(t('sStreak'))}</span><b>${p.streak} <small class="muted">/ ${p.bestStreak}</small></b></div>
        <div class="stat"><span>${esc(t('sDays'))}</span><b>${p.dayStreak} <small class="muted">/ ${p.bestDayStreak}</small></b></div>
        <div class="stat"><span>${esc(t('sGames'))}</span><b>${p.games} <small class="muted">${p.wins}/${p.draws}/${p.losses}</small></b></div>
        <div class="stat"><span>${esc(t('sAcc'))}</span><b>${p.accGames ? Math.round(p.accSum / p.accGames) : '–'}%</b></div>
        <div class="stat"><span>${esc(t('sBrill'))}</span><b style="color:#1bada6">${p.counts.brilliant || 0}</b></div>
        <div class="stat"><span>${esc(t('sBest'))}</span><b>${p.perfBest ? `≈ ${p.perfBest}` : '–'}</b></div>
      </div>
      <div class="card-title">${esc(t('sHistory'))}</div>
      <svg class="spark" viewBox="0 0 300 90" preserveAspectRatio="none"><polyline points="${pts}" fill="none" stroke="#9a7dff" stroke-width="2.5" vector-effect="non-scaling-stroke"/></svg>
      <div class="card-title">${esc(t('sMoves'))}</div>
      <div class="dist">${ORDER.map((k) => `<div class="dist-row"><i class="m" style="background:${Coach.CLASSES[k].color}">${Coach.CLASSES[k].mark}</i><span>${esc(label(k))}</span><div class="bar"><i style="width:${((p.counts[k] || 0) / total) * 100}%;background:${Coach.CLASSES[k].color}"></i></div><b>${p.counts[k] || 0}</b></div>`).join('')}</div>
      <div class="card-title">${esc(t('sRecent'))}</div>
      <div class="history">${
        games.slice(0, 15).map((g) => `<div class="hist-row"><span class="res ${g.result === 1 ? 'win' : g.result === 0 ? 'loss' : 'draw'}">${esc(g.result === 1 ? t('win') : g.result === 0 ? t('loss') : t('draw'))}</span><span class="muted">${esc(t('vs'))} ${esc(levelName(g.level) || '')} · ${g.acc ? `${g.acc}%` : ''} · ${esc(reasonText(g.reason))}</span><b style="color:${g.after >= g.before ? 'var(--ok)' : 'var(--danger)'}">${g.after >= g.before ? '+' : ''}${g.after - g.before}</b></div>`).join('') ||
        `<div class="muted">${esc(t('sNone'))}</div>`
      }</div>`;
  }

  function renderSettings() {
    const s = profile.settings;
    const toggle = (key, title, hint) => `<div class="field"><div class="row"><label>${esc(title)}</label><button class="switch ${s[key] ? 'on' : ''}" data-t="${key}"></button></div>${hint ? `<span class="hint">${esc(hint)}</span>` : ''}</div>`;
    const sens = t('sens');
    const modeDesc = { auto: t('modeAutoDesc'), popup: t('modePopupDesc'), rate: t('modeRateDesc') }[s.mode];
    $('settings').innerHTML = `
      <div class="field"><div class="row"><label>${esc(t('retest'))}</label><button class="btn small" data-retest="1">${esc(t('retestD'))}</button></div><span class="hint">${profile.placed ? `${profile.rating} Elo` : ''}</span></div>
      <div class="field"><label>${esc(t('setLang'))}</label>
        <div class="sens three">${[['de', 'Deutsch'], ['en', 'English'], ['es', 'Español']].map(([k, n]) => `<button data-lang="${k}" class="${I.lang === k ? 'on' : ''}">${n}</button>`).join('')}</div></div>
      <div class="field"><label>${esc(t('setMode'))}</label>
        <div class="sens three">${[['auto', t('modeAuto')], ['popup', t('modePopup')], ['rate', t('modeRate')]].map(([k, n]) => `<button data-mode="${k}" class="${s.mode === k ? 'on' : ''}">${esc(n)}</button>`).join('')}</div>
        <span class="hint">${esc(modeDesc)}</span></div>
      <div class="field"><label>${esc(t('setSens'))}</label>
        <div class="sens">${[1, 2, 3, 4].map((n) => `<button data-s="${n}" class="${s.sensitivity === n ? 'on' : ''}">${esc(sens[n][0])}</button>`).join('')}</div>
        <span class="hint">${esc(sens[s.sensitivity][1])}</span></div>
      ${toggle('paused', t('pause'), t('paused'))}
      ${toggle('review', t('setReview'), t('setReviewDesc'))}
      ${toggle('badges', t('setBadges'), t('setBadgesDesc'))}
      ${toggle('arrows', t('setArrows'), t('setArrowsDesc'))}
      ${b3Failed ? '' : toggle('view3d', t('set3d'), t('set3dDesc'))}
      ${toggle('legal', t('setLegal'), t('setLegalDesc'))}
      ${toggle('evalbar', t('setEval'), t('setEvalDesc'))}
      ${toggle('sound', t('setSound'), '')}
      ${toggle('voice', L3('Coach spricht', 'Coach speaks', 'El coach habla'), L3('Der Coach liest seine Tipps mit der Windows-Stimme vor.', 'The coach reads tips aloud with the Windows voice.', 'El coach lee sus consejos en voz alta.'))}
      ${toggle('demo', L3('Bessere Züge vorführen', 'Demonstrate better moves', 'Mostrar mejores jugadas'), L3('Nach einem Fehler zeigt der Coach mit Pfeilen, was besser gewesen wäre – und warum.', 'After a mistake the coach shows with arrows what was better – and why.', 'Tras un error, el coach muestra con flechas qué era mejor y por qué.'))}
      <div class="field"><label>${esc(t('setBoard'))}</label><div class="themes">${Object.entries(THEMES).map(([k, [l, d]]) => `<button data-th="${k}" class="${s.theme === k ? 'on' : ''}" style="--l:${l};--d:${d}" title="${k}"></button>`).join('')}</div></div>
      <div class="field"><div class="row"><label>${esc(t('resetElo'))}</label><button class="btn small danger" id="reset-elo">${esc(t('reset'))}</button></div><span class="hint">${esc(t('resetEloDesc'))}</span></div>`;
  }

  $('settings').addEventListener('click', (e) => {
    if (e.target.closest('[data-retest]')) return placementModal(true);
    const s = profile.settings;
    let changed = false;
    const tg = e.target.closest('[data-t]');
    if (tg) {
      s[tg.dataset.t] = !s[tg.dataset.t];
      changed = true;
    }
    const sens = e.target.closest('[data-s]');
    if (sens) {
      s.sensitivity = Number(sens.dataset.s);
      changed = true;
    }
    const md = e.target.closest('[data-mode]');
    if (md) {
      s.mode = md.dataset.mode;
      changed = true;
    }
    const th = e.target.closest('[data-th]');
    if (th) {
      s.theme = th.dataset.th;
      changed = true;
    }
    const lg = e.target.closest('[data-lang]');
    if (lg) {
      s.lang = lg.dataset.lang;
      I.lang = s.lang;
      relabelMoves();
      changed = true;
    }
    if (e.target.id === 'reset-elo') {
      if (e.target.dataset.armed !== '1') {
        e.target.dataset.armed = '1';
        e.target.textContent = t('sure');
        return;
      }
      profile = { ...structuredClone(DEFAULT_PROFILE), settings: s };
      changed = true;
    }
    if (!changed) return;
    applySettings();
    saveProfile();
    renderSettings();
    refresh();
  });

  window.addEventListener('resize', () => renderPieces());
  // Sprache kommt vom Hub (Einstellungen › Sprache gilt für alle Apps)
  window.addEventListener('hub-lang', (e) => {
    const l = e.detail;
    if (!['de', 'en', 'es'].includes(l) || profile.settings.lang === l) return;
    profile.settings.lang = l;
    I.lang = l;
    relabelMoves();
    applySettings();
    saveProfile();
    refresh();
    if (!$('lobby').hidden) Lobby.render();
  });


  /* ================================================================ Cosmetics */

  const COS = window.ChessLearn.COSMETICS;
  const cosItem = (slot, id) => COS[slot].find((x) => x.id === id) || COS[slot][0];
  function avatarHtml(eq = {}, size = 40) {
    const av = cosItem('avatar', eq.avatar), col = cosItem('color', eq.color), fr = cosItem('frame', eq.frame);
    const img = av.custom && typeof eq.img === 'string' && eq.img.startsWith('data:image/') ? eq.img : '';
    const inner = img
      ? `<img class="av-img" src="${img}" alt="" />`
      : av.glyph
      ? `<span class="av-glyph" style="font-size:${Math.round(size * 0.62)}px">${av.glyph}︎</span>`
      : `<svg class="av-default" viewBox="0 0 24 24"><circle cx="12" cy="9" r="4.2"/><path d="M4 21c.8-4.4 4-7 8-7s7.2 2.6 8 7"/></svg>`;
    return `<div class="av frame-${fr.id}${col.anim ? ' av-anim' : ''}" style="width:${size}px;height:${size}px;background:${col.bg}">${inner}</div>`;
  }
  function nameStyle(eq = {}) {
    const n = cosItem('name', eq.name);
    return n.css === 'rainbow' ? 'class="name-rainbow"' : `style="color:${n.css}"`;
  }
  function titleHtml(eq = {}) {
    const ti = cosItem('title', eq.title);
    const text = ti.t?.[I.lang] || '';
    return text ? ` <span class="title-tag">${esc(text)}</span>` : '';
  }
  function effectBurst(sq) {
    const fx = cosItem('effect', profile.cos.eq.effect);
    if (fx.wave) {
      const c0 = spot(sq);
      const w = document.createElement('div');
      w.className = `wave${fx.big ? ' big' : ''}`;
      w.style.cssText = `left:${c0.x}%;top:${c0.y}%;--c:${fx.color}`;
      $('fx').appendChild(w);
      setTimeout(() => w.remove(), 1200);
      if (fx.big) {
        boardEl.classList.remove('quake');
        void boardEl.offsetWidth;
        boardEl.classList.add('quake');
      }
    }
    if (fx.id !== 'none' && game && !game.online) particles(sq, fx.color, 16);
    else if (fx.id !== 'none' && game?.online) particles(sq, fx.color, 16);
  }

  /* ================================================================ Lernen (Szenarien) */

  const Scenario = {
    cur: null,
    async start(s) {
      this.cur = s;
      this.fails = 0;
      this.shown = false;
      this.rows = null;
      Lobby.hide();
      await startGame(9, 'w', s.fen, { scenario: s.id });
      const text = s.type === 'goal' ? t(s.goal === 'mate' ? 'goalMate' : 'goalPromote', { n: s.moves }) : s.mate ? t('solveMate') : t('solveTask');
      bubble(`<b>${esc(s.t[I.lang] || s.t.de)}</b> – ${esc(text)}${s.type === 'tactic' ? ` <button class="btn small explain-btn" data-solution="1">${esc(t('showSolution'))}</button>` : ''}`, 'book');
      if (s.type === 'tactic') {
        // Lösung vorab berechnen (alle Züge bewertet)
        ask('analyse', { moves: [], played: '', timeMs: 1200, maxDepth: 6 }).then((r) => (this.rows = r.rows)).catch(() => {});
      }
    },
    async onMove(m, before, prevMoves) {
      const s = this.cur;
      if (!s) return;
      if (s.type === 'tactic') {
        busy = true;
        if (!this.rows) {
          const r = await ask('analyse', { moves: prevMoves, played: uci(m), timeMs: 1200, maxDepth: 6 }).catch(() => null);
          this.rows = r?.rows || [];
        }
        const best = this.rows[0];
        const mine = this.rows.find((r) => r.uci === uci(m));
        const ok = s.mate ? pos.status()?.reason === 'Schachmatt' : Boolean(best && mine && mine.score >= best.score - 80 && mine.score >= 150);
        busy = false;
        if (ok) return this.success();
        this.fails += 1;
        Sound.play('oops');
        shake();
        bubble(`${esc(t('wrongMove'))} <button class="btn small explain-btn" data-solution="1">${esc(t('showSolution'))}</button>`, 'mistake');
        await sleep(700);
        takeback(1);
        return;
      }
      // Ziel-Szenario: Zugzahl prüfen, Umwandlung erkennen, sonst KI antwortet
      const myMoves = game.moves.filter((x) => x.color === 'w').length;
      if (s.goal === 'promote' && m.promo) return this.success();
      if (await checkEnd()) return;
      if (myMoves >= s.moves) return this.fail();
      bubble(esc(t('movesLeft', { n: s.moves - myMoves })), 'book');
      await botMove();
    },
    onEnd(status) {
      const s = this.cur;
      if (!s) return;
      if (s.type === 'goal' && s.goal === 'mate' && status.reason === 'Schachmatt' && status.result === '1-0') this.success();
      else if (s.type === 'goal') this.fail();
    },
    solution() {
      const best = this.rows?.[0];
      if (!best) return;
      this.shown = true;
      const m = pos.find(best.uci);
      if (m) setMarks({ arrows: [[m.from, m.to, '#81b64c']], squares: [] });
      bubble(esc(t('solutionNoPoints')), 'best');
    },
    success() {
      const s = this.cur;
      game.over = { result: '1-0', reason: 'scenario' };
      const first = !profile.learn.done[s.id];
      const pts = first && !this.shown ? (this.fails ? Math.ceil(s.points / 2) : s.points) : 0;
      profile.learn.done[s.id] = true;
      earn(pts);
      saveProfile();
      Sound.play('brilliant');
      particles(pos.kings[1], '#fbbf24', 40);
      celebrateText(pts ? t(s.type === 'goal' ? 'goalDone' : 'correct', { p: pts }) : t('correctAgain'));
      this.after(true);
    },
    fail() {
      game.over = { result: '0-1', reason: 'scenario' };
      Sound.play('lose');
      this.after(false);
    },
    after(ok) {
      const list = window.ChessLearn.SCENARIOS;
      const next = list[list.indexOf(this.cur) + 1];
      setTimeout(() => {
        modal(
          `<h2>${esc(ok ? t('solved') : t('goalFail'))}</h2><div class="muted">${esc(this.cur.t[I.lang] || this.cur.t.de)} · ◆ ${profile.points}</div>
           <div class="btns"><button class="btn" data-sc="lobby">${esc(t('learn'))}</button><button class="btn" data-sc="retry">${esc(t('retry'))}</button>${next ? `<button class="btn primary" data-sc="next">${esc(t('nextTask'))}</button>` : ''}</div>`,
          {
            onClick: (e) => {
              const a = e.target.closest('[data-sc]')?.dataset.sc;
              if (!a) return;
              closeModal();
              if (a === 'retry') this.start(this.cur);
              if (a === 'next') this.start(next);
              if (a === 'lobby') Lobby.show('learn');
            },
          },
        );
      }, ok ? 1600 : 600);
    },
  };

  $('bubble').addEventListener('click', (e) => {
    if (e.target.closest('[data-solution]')) Scenario.solution();
  });

  function celebrateText(text) {
    const el = $('celebrate');
    el.innerHTML = `<div class="flash"></div><div class="medal"><div class="ring-big">◆</div><div class="word">${esc(text)}</div></div>`;
    el.hidden = false;
    clearTimeout(celebrate.t);
    celebrate.t = setTimeout(() => {
      el.hidden = true;
      el.innerHTML = '';
    }, 2200);
  }

  /* ================================================================ Schwächen */

  /** Merkt sich eigene Fehler (Fehler, Patzer, verpasste Chancen) als Trainingsstellungen. */
  function recordWeak(before, verdict, entry) {
    if (!game || game.lesson || game.scenario || !entry || !verdict?.best) return;
    if (!['mistake', 'miss', 'blunder'].includes(verdict.cls)) return;
    if (entry.color !== (game.userColor === WHITE ? 'w' : 'b')) return;
    const fen = before.fen();
    const list = (profile.weak ||= []);
    if (list.some((w) => w.fen === fen)) return;
    const pieces = fen.split(' ')[0].replace(/[^pnbrqPNBRQ]/g, '').length;
    const bm = before.find(verdict.best.uci);
    let theme = 'position';
    if (verdict.best.score > 90000) theme = 'mate';
    else if (pieces <= 7) theme = 'endgame';
    else if (bm && bm.flags & F_CAPTURE && verdict.loss >= 150) theme = 'tactic';
    else if (verdict.loss >= 250) theme = 'hanging';
    list.unshift({ fen, best: verdict.best.uci, played: entry.uci, san: entry.san, theme, cls: verdict.cls, at: Date.now(), ok: 0 });
    profile.weak = list.slice(0, 80);
  }

  function weakStats() {
    const out = {};
    for (const w of profile.weak || []) out[w.theme] = (out[w.theme] || 0) + 1;
    return Object.entries(out).sort((a, b) => b[1] - a[1]);
  }

  function trainWeak(theme) {
    const list = (profile.weak || []).filter((w) => !theme || w.theme === theme).slice(0, 6);
    if (!list.length) return;
    Lesson.start(
      list.map((w, i) => ({ id: `weak-${i}`, fen: w.fen, kind: 'best', weak: w, sol: [w.best] })),
      { id: `weak-${theme || 'all'}`, title: t('weakT'), color: '#ff4b4b', weak: true },
    );
  }

  /* ================================================================ Lektionen (Lernpfad) */

  const PUZ = () => Object.fromEntries(window.ChessLearn.PUZZLES.map((p) => [p.id, p]));

  /** Lernpfad als Liste: alle Lektionen und Bosse in Reihenfolge. */
  function pathNodes() {
    const L = window.ChessLearn;
    const nodes = [];
    for (const u of L.UNITS) {
      (u.lessons || []).forEach((ids, i) => nodes.push({ id: `${u.id}-${i + 1}`, unit: u, n: i + 1, ids }));
      for (const b of u.bosses || []) {
        const s = L.SCENARIOS.find((x) => x.id === b);
        if (s) nodes.push({ id: s.id, unit: u, boss: s });
      }
    }
    let open = true;
    for (const n of nodes) {
      n.done = Boolean(profile.learn.done[n.id]);
      n.stars = typeof profile.learn.done[n.id] === 'number' ? profile.learn.done[n.id] : n.done ? 3 : 0;
      // Grundlagen sind für erfahrene Spieler freiwillig (blockieren nichts)
      if (n.unit.id === 'u-basics' && !profile.beginner) {
        n.optional = true;
        n.locked = false;
        continue;
      }
      n.locked = !open;
      if (!n.done && open) {
        n.current = true;
        open = false;
      }
    }
    return nodes;
  }

  function startNode(n) {
    if (!n || n.locked) return;
    if (n.boss) return Scenario.start(n.boss);
    const P = PUZ();
    Lesson.start(n.ids.map((id) => P[id]).filter(Boolean), { id: n.id, title: `${n.unit.t[I.lang] || n.unit.t.de} · ${t('lessonN', { n: n.n })}`, color: n.unit.color, diff: n.unit.diff || 1 });
  }

  /** Kleiner Matt-Löser für Matt-in-n-Aufgaben (n ≤ 3, wenige Figuren). */
  function mateForced(p, n) {
    for (const m of p.legalMoves()) {
      p.make(m);
      let ok;
      const replies = p.legalMoves();
      if (!replies.length) ok = p.inCheck();
      else if (n > 1) {
        ok = true;
        for (const r of replies) {
          p.make(r);
          const w = mateForced(p, n - 1);
          p.unmake();
          if (!w) {
            ok = false;
            break;
          }
        }
      } else ok = false;
      p.unmake();
      if (ok) return true;
    }
    return false;
  }
  function mateFirst(pos0, n) {
    const p = pos0.clone();
    const out = [];
    for (const m of p.legalMoves()) {
      p.make(m);
      const replies = p.legalMoves();
      let ok;
      if (!replies.length) ok = p.inCheck();
      else if (n > 1) {
        ok = true;
        for (const r of replies) {
          p.make(r);
          const w = mateForced(p, n - 1);
          p.unmake();
          if (!w) {
            ok = false;
            break;
          }
        }
      } else ok = false;
      p.unmake();
      if (ok) out.push(uci(m));
    }
    return out;
  }

  /**
   * Antwort des Verteidigers in Matt-Aufgaben: so lange wie möglich wehren, aber KEINE
   * sinnlosen Opfer (Dame dazwischenstellen usw.) – sonst wirken die Lektionen albern.
   */
  function defenderReply(pos0, left) {
    const p = pos0.clone();
    const def = p.turn;
    const att = def === WHITE ? BLACK : WHITE;
    let best = null;
    for (const r of p.legalMoves()) {
      const captured = p.b[r.to] ? POINTS[typeOf(p.b[r.to])] : 0;
      const moved = POINTS[typeOf(r.piece)] || 0;
      p.make(r);
      let score = captured * 2;
      // Figur auf ein angegriffenes Feld gestellt → verschenkt
      if (typeOf(r.piece) !== KING && p.attacked(r.to, att)) score -= Math.max(0, moved - captured) * 3;
      // schneller matt als nötig → schlechte Verteidigung
      if (left > 2 && mateFirst(p, left - 2).length) score -= 50;
      if (typeOf(r.piece) === KING) score += 0.5;
      p.unmake();
      score += Math.random() * 0.3;
      if (!best || score > best.score) best = { r, score };
    }
    return best ? uci(best.r) : null;
  }

  function findMateMove(p) {
    for (const m of p.legalMoves()) {
      p.make(m);
      const mate = p.status()?.reason === 'Schachmatt';
      p.unmake();
      if (mate) return m;
    }
    return null;
  }

  const Lesson = {
    active: null,

    start(items, meta) {
      Scenario.cur = null;
      clearInterval(this.tipTimer);
      this.active = { items: [...items], i: 0, right: 0, wrong: 0, tips: 0, failed: false, ...meta };
      Lobby.hide();
      closeModal();
      this.load();
    },

    get item() {
      return this.active?.items[this.active.i];
    },

    async load() {
      const a = this.active;
      const p = this.item;
      if (!p) return;
      a.step = 0;
      a.rows = null;
      a.locked = false;
      a.tipUntil = 0;
      clearInterval(this.tipTimer);
      await startGame(9, p.fen.split(' ')[1] === 'b' ? 'b' : 'w', p.fen, { scenario: 'lesson', lesson: true });
      this.sheet(null);
      this.hud();
      const me = p.fen.split(' ')[1] === 'b' ? t('black') : t('white');
      const userSteps = p.steps ? p.steps.filter((x) => x.ok).length : 1;
      const task = p.weak ? t('weakTask', { san: `<b class="san">${esc(p.weak.san)}</b>` }) : p.task ? esc(p.task[I.lang] || p.task.de) : esc(p.kind === 'mate' ? (p.n === 3 ? t('findMate3') : p.n === 2 ? t('findMate2') : t('findMate1')) : userSteps > 1 ? t('findLine', { n: userSteps }) : t('findBest'));
      $('lesson-task').innerHTML = `${task} <span class="muted">${esc(t('yourSide', { c: me }))}</span>`;
      bubble(task, 'book');
      if (p.kind !== 'mate' && !p.strict) {
        ask('analyse', { moves: [], played: '', timeMs: 1500, maxDepth: 7 })
          .then((r) => {
            if (this.item === p) a.rows = r.rows;
          })
          .catch(() => {});
      }
    },

    hud() {
      const a = this.active;
      const el = $('lesson-hud');
      if (!a) {
        el.hidden = true;
        document.body.classList.remove('in-lesson');
        return;
      }
      document.body.classList.add('in-lesson');
      el.hidden = false;
      const total = a.items.length;
      el.style.setProperty('--lc', a.color || '#58cc02');
      el.innerHTML = `<button class="lh-x" data-lh="quit" title="${esc(t('toLobby'))}">✕</button>
        <div class="lh-bar"><i style="width:${Math.round((a.i / total) * 100)}%"></i></div>
        <button class="lh-tip" data-lh="tip" id="lh-tip">💡 ${esc(t('tipBtn'))}</button>
        <div class="lh-task" id="lesson-task"></div>`;
    },

    async onMove(m, before, prevMoves) {
      const a = this.active;
      const p = this.item;
      if (!a || !p || a.locked) return;
      const u = uci(m);
      let ok = false;
      if (p.kind === 'mate') {
        const left = (p.n || 1) - (a.step || 0);
        if (pos.status()?.reason === 'Schachmatt') ok = true;
        else if (left > 1 && ((a.step === 0 && (p.sol || []).includes(u)) || mateFirst(before, left).includes(u))) {
          a.step = (a.step || 0) + 1;
          Sound.play('best');
          bubble(esc(left - 1 === 1 ? t('nowMate') : t('keepGoing', { n: left - 1 })), 'good');
          busy = false;
          await botMove(defenderReply(pos, left));
          return;
        }
      } else if (p.steps) {
        // Mehrzügige Aufgabe: jeder eigene Zug muss stimmen, dazwischen antwortet der Gegner
        const st = p.steps[a.step || 0];
        if (st?.ok?.includes(u)) {
          const next = p.steps[(a.step || 0) + 1];
          if (next?.reply && p.steps[(a.step || 0) + 2]) {
            a.step = (a.step || 0) + 2;
            Sound.play('best');
            bubble(esc(t('goodGoOn')), 'good');
            busy = false;
            await botMove(next.reply);
            return;
          }
          ok = true;
        }
      } else if ((p.sol || []).includes(u)) ok = true;
      else if (p.strict) ok = false;
      else {
        busy = true;
        setThinking(true, t('checking'));
        let rows = a.rows;
        if (!rows) rows = (await ask('analyse', { moves: prevMoves, played: u, timeMs: 1500, maxDepth: 7 }).catch(() => null))?.rows || [];
        setThinking(false);
        busy = false;
        const best = rows[0];
        const mine = rows.find((r) => r.uci === u);
        const played = p.weak ? rows.find((r) => r.uci === p.weak.played) : null;
        ok = Boolean(best && mine && mine.score >= best.score - 40 && (!played || mine.score > played.score + 60));
      }
      if (ok) this.right(m);
      else this.wrong(before);
    },

    /** Tipp kostet Zeit: das Brett ist 60 Sekunden gesperrt, dann wird die Figur markiert. */
    tip() {
      const a = this.active;
      const p = this.item;
      if (!a || !p || a.locked || a.tipUntil) return;
      a.tips += 1;
      a.locked = true;
      a.tipUntil = Date.now() + 60000;
      const btn = $('lh-tip');
      const tick = () => {
        const left = Math.ceil((a.tipUntil - Date.now()) / 1000);
        if (this.active !== a || this.item !== p) return clearInterval(this.tipTimer);
        if (left > 0) {
          if (btn) btn.innerHTML = `⏳ ${left}s`;
          $('lesson-task').innerHTML = `<span class="tip-lock">${esc(t('tipLock', { s: left }))}</span>`;
          return;
        }
        clearInterval(this.tipTimer);
        a.locked = false;
        if (btn) {
          btn.innerHTML = `💡 ${esc(t('tipBtn'))}`;
          btn.disabled = true;
        }
        let mv = null;
        if (p.kind === 'mate') {
          const left2 = (p.n || 1) - (a.step || 0);
          const list = a.step === 0 && p.sol?.length ? p.sol : mateFirst(pos, left2);
          mv = list[0] && pos.find(list[0]);
        } else if (p.steps) mv = pos.find(p.steps[a.step || 0]?.ok?.[0] || '');
        else if (p.sol?.[0]) mv = pos.find(p.sol[0]);
        else if (a.rows?.[0]) mv = pos.find(a.rows[0].uci);
        if (mv) setMarks({ arrows: [], squares: [[mv.from, '#fbbf24']] });
        $('lesson-task').innerHTML = esc(t('tipShow'));
        bubble(esc(t('tipShow')), 'best');
      };
      tick();
      this.tipTimer = setInterval(tick, 250);
    },

    right(m) {
      const a = this.active;
      const p = this.item;
      a.locked = true;
      a.right += 1;
      if (p.weak) {
        p.weak.ok += 1;
        if (p.weak.ok >= 2) profile.weak = (profile.weak || []).filter((w) => w !== p.weak);
        saveProfile();
      }
      Sound.play('brilliant');
      particles(m.to, a.color || '#58cc02', 30);
      const praise = [t('checkOk'), '🔥 ' + t('checkOk'), '⭐ ' + t('checkOk')][Math.min(2, a.right - 1)] || t('checkOk');
      this.sheet({ ok: true, title: praise, text: p.tip ? esc(p.tip[I.lang] || p.tip.de) : '' });
    },

    wrong(before) {
      const a = this.active;
      const p = this.item;
      a.locked = true;
      a.wrong += 1;
      a.failed = true;
      Sound.play('oops');
      shake();
      // Lösung auf der Ausgangsstellung zeigen
      const start = new Position(p.fen);
      if (p.steps && a.step > 0 && before) {
        const want = before.find(p.steps[a.step].ok[0]);
        takeback(game.moves.length);
        const tip0 = p.tip ? `<br>${esc(t('whyTip', { tip: p.tip[I.lang] || p.tip.de }))}` : '';
        this.sheet({ ok: false, title: t('checkBad'), text: `${want ? t('solutionWas', { san: `<b class="san">${esc(san(before, want))}</b>` }) : ''}${tip0}<br><small>${esc(t('failRestart'))}</small>` });
        return;
      }
      let sol = p.sol?.[0] ? start.find(p.sol[0]) : p.steps ? start.find(p.steps[0].ok[0]) : null;
      if (!sol && p.kind === 'mate') sol = findMateMove(start);
      if (!sol && a.rows?.[0]) sol = start.find(a.rows[0].uci);
      takeback(game.moves.length);
      if (sol) setMarks({ arrows: [[sol.from, sol.to, '#58cc02']], squares: [] });
      // Ein Fehler = Lektion von vorn (keine Herzen)
      const tip = p.tip ? `<br>${esc(t('whyTip', { tip: p.tip[I.lang] || p.tip.de }))}` : '';
      this.sheet({ ok: false, title: t('checkBad'), text: `${sol ? t('solutionWas', { san: `<b class="san">${esc(san(start, sol))}</b>` }) : ''}${tip}<br><small>${esc(t('failRestart'))}</small>` });
      void before;
    },

    sheet(info) {
      const el = $('lesson-sheet');
      if (!info) {
        el.hidden = true;
        return;
      }
      el.hidden = false;
      el.className = `lesson-sheet ${info.ok ? 'ok' : 'bad'}`;
      el.innerHTML = `<div class="ls-ic">${info.ok ? '✓' : '✕'}</div><div class="ls-txt"><b>${esc(info.title)}</b><span>${info.text || ''}</span></div><button class="btn ls-next" data-lh="next">${esc(t('continueL'))}</button>`;
      setTimeout(() => el.querySelector('.ls-next')?.focus(), 30);
    },

    next() {
      const a = this.active;
      if (!a) return;
      setMarks(null);
      if (a.failed) return this.finish(false);
      a.i += 1;
      if (a.i >= a.items.length) return this.finish(true);
      this.load();
    },

    finish(ok) {
      const a = this.active;
      this.sheet(null);
      const first = !profile.learn.done[a.id];
      // Je schwerer die Einheit, desto mehr Punkte
      const diff = a.diff || 1;
      // Tipps kosten nur Zeit, keine Punkte – aber ohne Tipp gibt es einen kleinen Bonus
      const clean = a.tips ? 0 : 1;
      // Wiederholte Lektionen geben keine Punkte mehr
      const xp = ok && (first || a.weak) ? (a.weak ? 8 + clean * 4 : Math.round((8 + diff * 10) * (1 + clean * 0.2)) + diff * 8) : 0;
      a.repeat = ok && !first && !a.weak;
      if (ok) {
        earn(xp);
        if (!a.weak) profile.learn.done[a.id] = Math.max(Number(profile.learn.done[a.id]) || 0, a.tips ? 2 : 3);
        const y = new Date(Date.now() - 864e5).toLocaleDateString('sv-SE');
        if (profile.learn.last !== today()) profile.learn.streak = profile.learn.last === y ? (profile.learn.streak || 0) + 1 : 1;
        profile.learn.last = today();
        profile.learnLog = [...(profile.learnLog || []), { at: Date.now(), id: a.id, right: a.right, wrong: a.wrong, tips: a.tips }].slice(-300);
        saveProfile();
        Sound.play('win');
        celebrateText(t('lessonDone'));
      } else Sound.play('lose');
      this.active = null;
      this.hud();
      const acc = Math.round((a.right / Math.max(1, a.right + a.wrong)) * 100);
      const next = pathNodes().find((n) => n.current);
      setTimeout(() => {
        modal(
          `<div class="lesson-end ${ok ? 'ok' : 'bad'}"><div class="le-badge">${ok ? '🏆' : '💔'}</div>
            <h2>${esc(ok ? t('lessonDone') : t('lessonFail'))}</h2>${ok ? (a.repeat ? `<p class="muted">${esc(t('repeatNoPts'))}</p>` : '') : `<p class="muted">${esc(t('lessonFailD'))}</p>`}
            <div class="le-stats"><div><b>${ok ? `+${xp}` : 0}</b><span>◆</span></div><div><b>${acc}%</b><span>${esc(t('accuracyL'))}</span></div><div><b>${a.tips}</b><span>${esc(t('tipsUsed'))}</span></div>${profile.learn.streak ? `<div><b>🔥 ${profile.learn.streak}</b><span>${esc(t('dailyStreak', { n: profile.learn.streak }).replace(/^\d+\s*/, ''))}</span></div>` : ''}</div>
            <div class="btns"><button class="btn" data-le="path">${esc(t('path'))}</button>${ok ? (next && !a.weak ? `<button class="btn primary" data-le="next">${esc(t('continueL'))} →</button>` : '') : `<button class="btn primary" data-le="retry">${esc(t('retry'))}</button>`}</div></div>`,
          {
            onClick: (e) => {
              const c = e.target.closest('[data-le]')?.dataset.le;
              if (!c) return;
              closeModal();
              if (c === 'path') Lobby.show(a.weak ? 'home' : 'learn');
              if (c === 'next') startNode(next);
              if (c === 'retry') this.start(a.items, { id: a.id, title: a.title, color: a.color, weak: a.weak, diff: a.diff });
            },
          },
        );
      }, ok ? 1400 : 500);
    },

    quit() {
      clearInterval(this.tipTimer);
      this.active = null;
      this.sheet(null);
      this.hud();
      setMarks(null);
      game = null;
      refresh();
      Lobby.show('learn');
    },
  };

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-lh]');
    if (!b) return;
    if (b.dataset.lh === 'quit') Lesson.quit();
    if (b.dataset.lh === 'next') Lesson.next();
    if (b.dataset.lh === 'tip') Lesson.tip();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !$('lesson-sheet').hidden) Lesson.next();
  });

  /* ================================================================ Lobby */

  /* ================================================================ Einstufung */

  function placementModal(cancelable = false) {
    const keep = profile.games > 0;
    modal(
      `<div class="place">
        <div class="place-hero">♞&#xFE0E;</div>
        <h2>${esc(t('placeT'))}</h2><p class="muted">${esc(t('placeD'))}</p>
        <div class="place-opts">
          <button class="place-opt main" data-pl="game"><span class="po-ic">${window.icon ? window.icon('target', 26) : ''}</span><div><b>${esc(t('placeGame'))}</b><span>${esc(t('placeGameD'))}</span></div></button>
          <button class="place-opt" data-pl="new"><span class="po-ic">${window.icon ? window.icon('route', 26) : ''}</span><div><b>${esc(t('placeNew'))}</b><span>${esc(t('placeNewD'))}</span></div></button>
          ${keep ? `<button class="place-opt ghost" data-pl="keep"><span class="po-ic">${window.icon ? window.icon('check', 24) : ''}</span><div><b>${esc(t('placeKeep', { elo: profile.rating }))}</b><span>${esc(t('placeKeepD'))}</span></div></button>` : ''}
        </div>
        ${cancelable ? `<div class="btns"><button class="btn ghost" data-pl="cancel">${esc(t('cancel'))}</button></div>` : ''}
      </div>`,
      {
        onClick: (e) => {
          const a = e.target.closest('[data-pl]')?.dataset.pl;
          if (!a) return;
          closeModal();
          if (a === 'cancel') return Lobby.show('home');
          if (a === 'keep') {
            profile.placed = true;
            saveProfile();
            return Lobby.show('home');
          }
          if (a === 'new') {
            profile.placed = true;
            profile.beginner = true;
            profile.rating = 200;
            profile.peak = Math.max(200, profile.games ? profile.peak : 200);
            profile.ratingHistory = [200];
            profile.settings.level = 0;
            saveProfile();
            refresh();
            return Lobby.show('learn');
          }
          delete profile.placeRun;
          saveProfile();
          startPlacementGame();
        },
      },
    );
  }

  /** Leistungs-Elo aus den Einstufungspartien (Ergebnis zählt, Genauigkeit nur ein bisschen). */
  function placementEstimate(res) {
    const v = res.map((r) => r.opp + (r.s - 0.5) * 800);
    return v.reduce((a, b) => a + b, 0) / v.length;
  }
  function placementElo(res) {
    let elo = placementEstimate(res);
    const accs = res.filter((r) => r.acc != null).map((r) => cal(Coach.accuracyToElo(r.acc)));
    if (accs.length) elo = elo * 0.9 + Math.min(...accs, elo + 200) * 0.1;
    // Harte Grenzen: wer gegen X verliert, steht UNTER X – wer gegen X gewinnt, steht nicht weit darunter
    const cap = Math.min(...res.filter((r) => r.s === 0).map((r) => r.opp - 60), ...res.filter((r) => r.s === 0.5).map((r) => r.opp + 60), Infinity);
    const floor = Math.max(...res.filter((r) => r.s === 1).map((r) => r.opp - 100), -Infinity);
    if (floor > cap) elo = (floor + cap) / 2;
    else elo = Math.max(floor, Math.min(cap, elo));
    return Math.max(100, Math.min(2200, Math.round(elo)));
  }
  const nearestLevel = (elo) => LEVELS.slice(0, SF_LEVEL).reduce((best, L, i) => (Math.abs(L.elo - elo) < Math.abs(LEVELS[best].elo - elo) ? i : best), 0);

  function startPlacementGame() {
    const res = profile.placeRun?.res || [];
    // Start gegen 600 – wer verliert, spielt danach gegen den 400er
    const lvl = res.length ? nearestLevel(Math.min(placementEstimate(res), ...res.filter((r) => r.s === 0).map((r) => r.opp - 200))) : 1;
    Lobby.hide();
    startGame(lvl, Math.random() < 0.5 ? 'w' : 'b', START_FEN, { placement: true }).then(() => bubble(esc(t('placeRunning', { n: res.length + 1 })), 'book'));
  }

  function placementNext() {
    const res = profile.placeRun.res;
    const lvl = nearestLevel(Math.min(placementEstimate(res), ...res.filter((r) => r.s === 0).map((r) => r.opp - 200)));
    setTimeout(() => {
      modal(
        `<div class="place"><div class="place-hero">♞&#xFE0E;</div><h2>${esc(t('placeNext', { n: res.length + 1 }))}</h2>
          <div class="place-sofar">${res.map((r, i) => `<span class="ps ${r.s === 1 ? 'w' : r.s === 0 ? 'l' : 'd'}"><b>${i + 1}</b>${esc(r.s === 1 ? t('placeWin') : r.s === 0 ? t('placeLoss') : t('placeDraw'))}<small>vs ${r.opp}</small></span>`).join('')}</div>
          <p class="muted">${esc(t('placeNextD', { name: levelName(lvl), elo: LEVELS[lvl].elo }))}</p>
          <div class="btns"><button class="btn primary" data-pn="go">${esc(t('placeGo'))}</button></div></div>`,
        {
          onClick: (e) => {
            if (!e.target.closest('[data-pn]')) return;
            closeModal();
            startPlacementGame();
          },
        },
      );
    }, 900);
  }

  function placementResult(elo) {
    const rk = nearestLevel(elo);
    profile.settings.level = rk;
    saveProfile();
    setTimeout(() => {
      modal(
        `<div class="place done"><div class="place-elo"><span>${esc(t('placeDone'))}</span><b id="place-num">0</b><small>Elo</small></div>
          <p class="muted">${esc(t('placeDoneD'))}</p>
          <div class="btns"><button class="btn" data-pr="lobby">${esc(t('lobby'))}</button><button class="btn primary" data-pr="play">${esc(t('playNow'))} · ${esc(levelName(rk))}</button></div></div>`,
        {
          onClick: (e) => {
            const a = e.target.closest('[data-pr]')?.dataset.pr;
            if (!a) return;
            closeModal();
            if (a === 'lobby') Lobby.show('home');
            else newGameModal('bot');
          },
        },
      );
      // Zahl hochzählen
      const el = $('place-num');
      const t0 = performance.now();
      const step = (now) => {
        const k = Math.min(1, (now - t0) / 1400);
        if (el) el.textContent = String(Math.round(elo * (1 - (1 - k) ** 3)));
        if (k < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
      Sound.play('brilliant');
    }, 900);
  }

  /** Eigenes Profilbild: quadratisch zuschneiden, 96 px JPEG (klein genug für Online). */
  function uploadAvatar(done) {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = c.height = 96;
        const side = Math.min(img.width, img.height);
        c.getContext('2d').drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 96, 96);
        profile.cos.eq.img = c.toDataURL('image/jpeg', 0.82);
        profile.cos.eq.avatar = 'custom';
        saveProfile();
        URL.revokeObjectURL(img.src);
        refresh();
        done?.();
      };
      img.src = URL.createObjectURL(file);
    };
    input.click();
  }

  /* ================================================================ Rangliste */

  const Ranking = {
    list: null,
    error: '',
    loading: false,
    async load() {
      if (this.loading) return;
      this.loading = true;
      this.error = '';
      try {
        const me = profile.placed && profile.username ? { id: profile.uid, name: profile.username, rating: profile.rating, games: profile.games, cos: profile.cos.eq } : null;
        const list = await window.RevNet.leaderboard('chess', me);
        if (me && !list.some((x) => x.id === me.id)) list.push(me);
        this.list = list.filter((x) => x.rating >= 100 && x.rating <= 3500).sort((a, b) => b.rating - a.rating);
        profile.lbTop = this.list.slice(0, 3).map((x) => ({ name: x.name, rating: x.rating }));
        profile.lbPos = this.list.findIndex((x) => x.id === profile.uid) + 1;
      } catch (error) {
        this.error = String(error?.message || error);
      } finally {
        this.loading = false;
      }
      if (Lobby.page === 'ranking' || Lobby.page === 'home') Lobby.render();
    },
  };

  /* ================================================================ Mini-Brett */

  function miniBoard(fen, marks = {}) {
    const rows = fen.split(' ')[0].split('/');
    const black = fen.split(' ')[1] === 'b';
    const cells = [];
    rows.forEach((row, r) => {
      let f = 0;
      for (const ch of row) {
        if (/\d/.test(ch)) for (let k = 0; k < Number(ch); k += 1) cells.push({ r, f: f++, p: '' });
        else cells.push({ r, f: f++, p: ch });
      }
    });
    const G = { p: '♟', n: '♞', b: '♝', r: '♜', q: '♛', k: '♚' };
    const name = (c) => 'abcdefgh'[c.f] + (8 - c.r);
    const order = black ? [...cells].reverse() : cells;
    return `<div class="mini-board">${order
      .map((c) => {
        const sq = name(c);
        const cls = [(c.r + c.f) % 2 ? 'd' : 'l', marks.bad?.includes(sq) ? 'bad' : '', marks.good?.includes(sq) ? 'good' : ''].join(' ');
        return `<i class="${cls}">${c.p ? `<span class="${c.p === c.p.toUpperCase() ? 'w' : 'b'}">${G[c.p.toLowerCase()]}&#xFE0E;</span>` : ''}</i>`;
      })
      .join('')}</div>`;
  }

  /* ================================================================ Lobby */

  const ic = (name, size = 22) => (window.icon ? window.icon(name, size) : '');

  /* ================================================================ Prognose */
  /** Wie schnell lernst du? Trend der Elo (Regression) + Trainingsaktivität. */
  function forecast() {
    const now = Date.now();
    const day = 864e5;
    const log = (profile.ratingLog || []).filter((x) => x.at > now - 60 * day);
    const lessons7 = (profile.learnLog || []).filter((x) => x.at > now - 7 * day).length;
    const games7 = log.filter((x) => x.at > now - 7 * day).length;
    let slope = null;
    if (log.length >= 5) {
      const xs = log.map((x) => (x.at - log[0].at) / day), ys = log.map((x) => x.r);
      const mx = xs.reduce((a, b) => a + b, 0) / xs.length, my = ys.reduce((a, b) => a + b, 0) / ys.length;
      const den = xs.reduce((s, x) => s + (x - mx) ** 2, 0);
      if (den > 0.5) slope = xs.reduce((s, x, i) => s + (x - mx) * (ys[i] - my), 0) / den;
    }
    // IQ-Test gemacht? Dann fließt er ein: wie schnell du lernst und wie weit es realistisch geht.
    const iq = profile.iq ? Number(profile.iq.chessIq || profile.iq.iq) || null : null;
    const iqSpeed = iq ? Math.max(0.7, Math.min(1.6, 1 + (iq - 100) / 90)) : 1;
    const potential = iq ? Math.max(700, Math.min(2500, Math.round((900 + (iq - 85) * 26) / 50) * 50)) : 2000;
    const room = Math.max(0.2, (potential - profile.rating) / Math.max(800, potential - 400)); // je näher am Potenzial, desto langsamer
    const activity = ((lessons7 * 5 + games7 * 1.5) / 7) * room * iqSpeed;
    let perDay = slope == null ? activity : slope * 0.6 + activity * 0.4;
    perDay = Math.max(-3, Math.min(12 * iqSpeed, perDay));
    const lessonsAll = profile.learnLog || [];
    const lessonAcc = lessonsAll.length ? Math.round((lessonsAll.reduce((s, x) => s + (x.right || 0), 0) / Math.max(1, lessonsAll.reduce((s, x) => s + (x.right || 0) + (x.wrong || 0), 0))) * 100) : null;
    const at = (days) => {
      const raw = profile.rating + perDay * days * Math.pow(0.985, days / 7);
      // oberhalb des Potenzials geht es nur noch zäh weiter
      return Math.max(100, Math.round(iq && raw > potential ? potential + (raw - potential) * 0.25 : raw));
    };
    const perWeek = Math.round(perDay * 7);
    const pace = perWeek >= 25 ? t('paceFast') : perWeek >= 8 ? t('paceNormal') : perWeek >= 0 ? t('paceSlow') : t('paceDown');
    return { perWeek, in30: at(30), in90: at(90), in365: at(365), pace, lessons7, games7, basis: log.length, lessonAcc, iq, iqSpeed, potential };
  }

  function forecastModal() {
    const f = forecast();
    modal(
      `<h2>${esc(t('forecast'))}</h2>
       <div class="fc-stats3"><div><span>${esc(t('fcNow'))}</span><b>${profile.rating}</b></div><div><span>${esc(t('fcIn', { n: 30 }))}</span><b>${f.in30}</b></div><div><span>${esc(t('fcIn', { n: 90 }))}</span><b>${f.in90}</b></div><div><span>${esc(t('fcYear'))}</span><b>${f.in365}</b></div></div>
       <p class="muted">${esc(t('fcPace', { pace: f.pace, n: (f.perWeek >= 0 ? '+' : '') + f.perWeek }))}</p>
       <p class="muted">${esc(t('fcBasis', { g: f.games7, l: f.lessons7 }))}${f.lessonAcc != null ? ` · ${esc(t('fcLessonAcc', { n: f.lessonAcc }))}` : ''}</p>
       <div class="fc-iq ${f.iq ? 'on' : ''}">${f.iq ? `<b>IQ ${f.iq}</b><span>${esc(L3(`eingerechnet: Lerntempo ×${String(Math.round(f.iqSpeed * 100) / 100).replace('.', ',')} · realistisches Potenzial ≈ ${f.potential} Elo`, `included: learning speed ×${Math.round(f.iqSpeed * 100) / 100} · realistic potential ≈ ${f.potential} Elo`, `incluido: ritmo ×${Math.round(f.iqSpeed * 100) / 100} · potencial ≈ ${f.potential} Elo`))}</span>` : `<span>${esc(L3('Mach den IQ-Test – dann rechnet die Prognose dein Lerntempo und dein Potenzial mit ein.', 'Take the IQ test – the forecast will then include your learning speed and potential.', 'Haz el test de CI: la previsión incluirá tu ritmo y tu potencial.'))}</span><button class="btn small" data-fc="iq">${esc(t('iqTitle'))}</button>`}</div>
       <p class="hint">${esc(t('fcHint'))}</p>
       <div class="btns"><button class="btn primary" data-fc="ok">OK</button></div>`,
      {
        onClick: (e) => {
          const b = e.target.closest('[data-fc]');
          if (!b) return;
          closeModal();
          if (b.dataset.fc === 'iq') IQ.start();
        },
      },
    );
  }

  /* ================================================================ Coach-Training */
  /**
   * Der Coach stellt einen Plan für heute zusammen (Fehler wiederholen, Endspiele, Lernpfad,
   * Partie) und erklärt warum. Rechts kann man stattdessen selbst etwas wählen.
   */
  const CoachPlan = {
    options() {
      const weak = profile.weak || [];
      const ends = window.ChessLearn.SCENARIOS.filter((x) => x.cat === 'endgame');
      const endOpen = ends.filter((x) => !profile.learn.done[x.id]);
      const next = pathNodes().find((n) => n.current);
      const lvl = LEVELS.slice(0, SF_LEVEL).reduce((best, L, i) => (Math.abs(L.elo - profile.rating) < Math.abs(LEVELS[best].elo - profile.rating) ? i : best), 0);
      const themes = weakStats();
      return [
        weak.length && { id: 'mistakes', ic: 'target', c: '#ff4b4b', t: L3('Deine Fehler', 'Your mistakes', 'Tus errores'), d: L3(`${weak.length} Stellungen aus deinen Partien – zweimal richtig, dann sind sie weg.`, `${weak.length} positions from your games.`, `${weak.length} posiciones de tus partidas.`), say: L3(`Heute schauen wir uns deine Fehler an. ${themes[0] ? `Am häufigsten passiert dir: ${themes[0][0] === 'hanging' ? 'Figuren hängen lassen' : themes[0][0] === 'tactic' ? 'Taktiken übersehen' : themes[0][0] === 'mate' ? 'Matt übersehen' : themes[0][0] === 'endgame' ? 'Fehler im Endspiel' : 'Stellungsfehler'}.` : ''} Wer seine eigenen Fehler versteht, gewinnt am schnellsten Elo.`, 'Today we review your mistakes – the fastest way to gain rating.', 'Hoy repasamos tus errores.'), run: () => trainWeak('') },
        next && { id: 'learn', ic: 'route', c: '#58cc02', t: L3('Lernpfad', 'Learning path', 'Ruta'), d: L3('Die nächste Lektion wartet.', 'Your next lesson is waiting.', 'Te espera la siguiente lección.'), say: L3('Heute lernen wir etwas Neues: die nächste Lektion in deinem Lernpfad.', "Today we learn something new: your next lesson.", 'Hoy aprendemos algo nuevo.'), run: () => startNode(next) },
        endOpen.length && { id: 'endgame', ic: 'shield', c: '#ff9600', t: L3('Endspiele', 'Endgames', 'Finales'), d: L3(`${endOpen.length} Endspiele noch offen.`, `${endOpen.length} endgames left.`, `${endOpen.length} finales pendientes.`), say: L3('Heute trainieren wir Endspiele – da werden die meisten Partien entschieden.', 'Today we train endgames – where most games are decided.', 'Hoy entrenamos finales.'), run: () => Scenario.start(endOpen[0]) },
        { id: 'game', ic: 'bot', c: '#81b64c', t: L3('Partie mit Coach', 'Game with coach', 'Partida con coach'), d: L3(`Gegen ${levelName(lvl)} (≈ ${LEVELS[lvl].elo} Elo) – ich schaue jeden Zug an.`, `Against ${levelName(lvl)} – I'll check every move.`, `Contra ${levelName(lvl)}.`), say: L3('Heute spielst du eine Partie gegen einen passenden Gegner. Ich schaue dir bei jedem Zug über die Schulter.', 'Today you play a game against a matching opponent.', 'Hoy juegas una partida.'), run: () => { profile.settings.paused = false; applySettings(); startGame(lvl, Math.random() < 0.5 ? 'w' : 'b'); } },
        { id: 'iq', ic: 'spark', c: '#f472b6', t: L3('Denk-Training', 'Brain training', 'Entrenamiento mental'), d: L3('Der Schach-IQ-Test – fließt in deine Prognose ein.', 'The chess IQ test – feeds your forecast.', 'El test de CI.'), say: L3('Heute trainieren wir dein Mustererkennen mit dem IQ-Test.', 'Today we train pattern recognition.', 'Hoy entrenamos patrones.'), run: () => IQ.start() },
      ].filter(Boolean);
    },
    /** Was der Coach heute vorschlägt: Fehler zuerst, dann Lernpfad, Endspiele, Partie. */
    pick() {
      const o = this.options();
      const day = new Date().getDate();
      const weak = (profile.weak || []).length;
      return o.find((x) => x.id === 'mistakes' && weak >= 3) || o.find((x) => x.id === (day % 2 ? 'learn' : 'endgame')) || o.find((x) => x.id === 'learn') || o[0];
    },
    teaser() {
      try {
        return this.pick().say.split('.')[0] + '.';
      } catch {
        return '';
      }
    },
    open() {
      const o = this.options();
      const main = this.pick();
      const greet = new Date().getHours() < 11 ? L3('Guten Morgen', 'Good morning', 'Buenos días') : new Date().getHours() < 18 ? L3('Hallo', 'Hi', 'Hola') : L3('Guten Abend', 'Good evening', 'Buenas noches');
      Lobby.hide?.();
      modal(
        `<div class="cp-wrap">
          <div class="cp-main">
            <div class="cp-coach"><span class="cp-face">♞</span><div class="cp-bubble"><b>${esc(greet)}, ${esc(profile.username || '')}!</b><p id="cp-say"></p></div></div>
            <button class="cp-go" data-cp="${main.id}" style="--c:${main.c}"><span class="cp-gic">${ic(main.ic, 26)}</span><span><b>${esc(main.t)}</b><small>${esc(main.d)}</small></span><i>${esc(L3("Los geht's", "Let's go", '¡Vamos!'))} →</i></button>
            <div class="cp-stats"><div><b>${profile.rating}</b><span>Elo</span></div><div><b>${(profile.weak || []).length}</b><span>${esc(L3('offene Fehler', 'open mistakes', 'errores'))}</span></div><div><b>${profile.learn.streak || profile.dayStreak || 0}🔥</b><span>${esc(L3('Tage am Stück', 'day streak', 'racha'))}</span></div></div>
          </div>
          <div class="cp-side"><span class="cp-label">${esc(L3('Oder selbst wählen', 'Or pick yourself', 'O elige tú'))}</span>
            ${o.filter((x) => x.id !== main.id).map((x, i) => `<button class="cp-opt" data-cp="${x.id}" style="--c:${x.c};animation-delay:${120 + i * 60}ms"><span class="cp-oic">${ic(x.ic, 18)}</span><span><b>${esc(x.t)}</b><small>${esc(x.d)}</small></span></button>`).join('')}
            <button class="btn ghost small" data-cp="close">${esc(t('cancel'))}</button>
          </div>
        </div>`,
        {
          onClick: (e) => {
            const id = e.target.closest('[data-cp]')?.dataset.cp;
            if (!id) return;
            closeModal();
            if (id === 'close') return Lobby.show('home');
            const pick = this.options().find((x) => x.id === id);
            Sound.play('start');
            pick?.run();
          },
        },
      );
      document.getElementById('modal')?.classList.add('cp-modal');
      // Der Coach „spricht“: Text erscheint Wort für Wort
      const el = document.getElementById('cp-say');
      const words = main.say.split(' ');
      let k = 0;
      clearInterval(this.typer);
      this.typer = setInterval(() => {
        if (!el?.isConnected || k >= words.length) return clearInterval(this.typer);
        el.textContent = words.slice(0, ++k).join(' ');
      }, 55);
    },
  };

  /* ================================================================ IQ-Test */
  const IQ = {
    run: null,
    timer: null,
    start() {
      this.run = { qs: window.ChessIQ.build(Date.now()), i: 0, answers: [], started: Date.now() };
      clearInterval(this.timer);
      this.timer = setInterval(() => this.tick(), 1000);
      Lobby.show('iq');
    },
    left() {
      return Math.max(0, 30 * 60 - Math.floor((Date.now() - this.run.started) / 1000));
    },
    tick() {
      if (!this.run || this.run.done) return clearInterval(this.timer);
      const l = this.left();
      const el = document.getElementById('iq-time');
      if (el) el.textContent = `${Math.floor(l / 60)}:${String(l % 60).padStart(2, '0')}`;
      if (!l) this.finish();
    },
    answer(v) {
      const r = this.run;
      r.answers[r.i] = v;
      Sound.play('move');
      if (r.i < r.qs.length - 1) r.i += 1;
      else return this.finish();
      Lobby.render();
    },
    finish() {
      const r = this.run;
      if (!r || r.done) return;
      r.done = true;
      clearInterval(this.timer);
      const secs = Math.round((Date.now() - r.started) / 1000);
      const sc = window.ChessIQ.score(r.qs, r.answers, secs);
      const f = forecast();
      const acc = profile.accGames ? profile.accSum / profile.accGames : null;
      const adj = window.ChessIQ.chessAdjust(sc.iq, { acc, lessonAcc: f.lessonAcc, perWeek: profile.placed && f.basis >= 3 ? f.perWeek : null });
      r.result = { ...sc, secs, chessIq: adj.iq, delta: adj.delta, note: adj.note };
      profile.iq = { at: Date.now(), iq: sc.iq, chessIq: adj.iq, right: sc.right, total: sc.total, secs };
      saveProfile();
      Sound.play('win');
      Lobby.render();
    },
    html() {
      const r = this.run;
      if (!r) return `<div class="lb-empty"><p>${esc(t('iqIntro'))}</p><button class="btn primary" data-lb="iqstart">${esc(t('iqStart'))}</button></div>`;
      if (r.done) {
        const x = r.result;
        return `<div class="iq-result">
          <div class="iq-big"><span>${esc(t('iqTest'))}</span><b>${x.iq}</b><small>${x.right}/${x.total} · ${Math.floor(x.secs / 60)}:${String(x.secs % 60).padStart(2, '0')} min</small></div>
          <div class="iq-big chess"><span>${esc(t('iqChess'))}</span><b>${x.chessIq}</b><small>${x.delta >= 0 ? '+' : ''}${x.delta} ${esc(t('iqByChess'))}</small></div>
          <div class="iq-cats">${Object.entries(x.cats).map(([k, v]) => `<div><span>${esc(k)}</span><div class="fc-bar"><i style="width:${Math.round((v.right / v.total) * 100)}%"></i></div><b>${v.right}/${v.total}</b></div>`).join('')}</div>
          ${x.note ? `<p class="muted">${esc(x.note)}</p>` : ''}
          <p class="hint">${esc(t('iqDisclaimer'))}</p>
          <div class="btns"><button class="btn" data-lb="home">${esc(t('toLobby'))}</button><button class="btn primary" data-lb="iqstart">${esc(t('iqAgain'))}</button></div></div>`;
      }
      const q = r.qs[r.i];
      const l = this.left();
      return `<div class="iq-run">
        <div class="iq-top"><span>${esc(t('iqQ', { n: r.i + 1, m: r.qs.length }))} · ${esc(q.cat)}</span><div class="fc-bar"><i style="width:${Math.round((r.i / r.qs.length) * 100)}%"></i></div><b id="iq-time">${Math.floor(l / 60)}:${String(l % 60).padStart(2, '0')}</b></div>
        <h2 class="iq-q">${esc(q.q)}</h2>
        ${q.show || ''}
        <div class="iq-opts ${q.optHtml ? 'pics' : ''}">${q.opts.map((o, k) => `<button class="iq-opt" data-iq="${esc(o)}">${q.optHtml ? q.optHtml[k] : esc(o)}<em>${'ABCD'[k]}</em></button>`).join('')}</div>
        <div class="iq-nav"><button class="btn ghost small" data-lb="iqskip">${esc(t('iqSkip'))}</button><button class="btn ghost small" data-lb="iqend">${esc(t('iqEnd'))}</button></div></div>`;
    },
  };

  const Lobby = {
    page: 'home',
    show(page = 'home') {
      this.page = page;
      if (!profile.username) return this.nameModal(() => this.show(page));
      $('lobby').hidden = false;
      this.render();
      // Die Frage „Wie gut spielst du?“ kommt nur ein einziges Mal von selbst.
      if (!profile.placed && !profile.placeAsked && page === 'home') {
        profile.placeAsked = true;
        saveProfile();
        placementModal(false);
      }
      if ((page === 'ranking' || (page === 'home' && !Ranking.list)) && !Ranking.loading) Ranking.load();
    },
    hide() {
      $('lobby').hidden = true;
    },
    nameModal(done) {
      modal(
        `<h2>${esc(t('chooseName'))}</h2>
         <div class="name-pick">${avatarHtml(profile.cos.eq, 64)}<input class="input" id="uname" maxlength="16" value="${esc(profile.username || profile.name || '')}" placeholder="${esc(t('username'))}" /></div>
         <span class="hint" id="uname-hint">${esc(t('nameHint'))}</span>
         <div class="btns"><button class="btn primary" data-u="save">${esc(t('save'))}</button></div>`,
        {
          onClick: (e) => {
            if (!e.target.closest('[data-u]')) return;
            const v = $('uname').value.trim();
            if (!/^[\p{L}\p{N}_-]{3,16}$/u.test(v)) {
              $('uname-hint').textContent = t('nameTaken');
              return;
            }
            profile.username = v;
            HP?.name(v).then(applyHub).catch(() => {});
            saveProfile();
            closeModal();
            refresh();
            done?.();
          },
        },
      );
      setTimeout(() => $('uname')?.focus(), 50);
    },
    spark() {
      const h = (profile.ratingHistory || []).slice(-30);
      if (h.length < 2) return '';
      const min = Math.min(...h), max = Math.max(...h), span = Math.max(20, max - min);
      const pts = h.map((v, i) => `${((i / (h.length - 1)) * 120).toFixed(1)},${(34 - ((v - min) / span) * 30).toFixed(1)}`).join(' ');
      const up = h[h.length - 1] >= h[0];
      return `<svg class="spark" viewBox="0 0 120 36"><polyline points="${pts}" fill="none" stroke="${up ? '#81b64c' : '#ff6b6b'}" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
    },
    head() {
      const back = this.page !== 'home' ? `<button class="btn lb-back" data-lb="home">${esc(t('back'))}</button>` : game && !game.over && !game.scenario && !game.lesson ? `<button class="btn primary lb-back" data-lb="continue">${esc(t('continueGame'))} →</button>` : '';
      return `<div class="lb-head">
        <div class="lb-me"><button class="lb-me-main" data-lb="name">${avatarHtml(profile.cos.eq, 60)}<div><b ${nameStyle(profile.cos.eq)}>${esc(profile.username)}</b>${titleHtml(profile.cos.eq)}<span>${profile.placed ? `${profile.rating} Elo` : '– Elo'}${profile.streak ? ` · 🔥 ${profile.streak}` : ''}</span></div>${this.spark()}</button>
          <button class="lb-retest" data-lb="retest" title="${esc(t('retestD'))}">${ic('refresh', 15)}<span>${esc(t('retest'))}</span></button></div>
        ${profile.learn.streak ? `<div class="lb-flame" title="${esc(t('dailyStreak', { n: profile.learn.streak }))}">🔥<b>${profile.learn.streak}</b></div>` : ''}
        <div class="lb-points">◆ <b>${profile.points}</b><span>${esc(t('points'))}</span></div>
        ${back}
      </div>`;
    },
    card(id, iconName, color, title, sub, body = '', wide = false) {
      return `<button class="fc ${wide ? 'wide' : ''}" data-lb="${id}" style="--fc:${color}"><div class="fc-top"><span class="fc-ic">${ic(iconName, 22)}</span><div><b>${esc(title)}</b><small>${esc(sub)}</small></div><span class="fc-go">${ic('arrow', 16)}</span></div>${body}</button>`;
    },
    homeHtml() {
      const nodes = pathNodes();
      const cur = nodes.find((n) => n.current);
      const done = nodes.filter((n) => n.done && !n.optional).length;
      const all = nodes.filter((n) => !n.optional).length;
      const weak = profile.weak || [];
      const TH = window.ChessLearn.THEMES;
      const ends = window.ChessLearn.SCENARIOS.filter((x) => x.cat === 'endgame');
      const endsDone = ends.filter((x) => profile.learn.done[x.id]).length;
      const top = Ranking.list ? Ranking.list.slice(0, 3) : profile.lbTop || [];
      const pos = profile.lbPos;
      const curTitle = cur ? (cur.boss ? `${t('boss')}: ${cur.boss.t[I.lang] || cur.boss.t.de}` : `${cur.unit.t[I.lang] || cur.unit.t.de} · ${t('lessonN', { n: cur.n })}`) : '✓';
      const play = [
        ['bot', 'bot', '#81b64c', t('lobbyBot'), t('lobbyBotD')],
        ['random', 'bolt', '#f43f5e', t('vsRandom'), t('randomHint')],
        ['online', 'users', '#38bdf8', t('lobbyOnline'), t('lobbyOnlineD')],
      ];
      return `
        <h1 class="lb-greet">${esc(t('greet', { name: profile.username }))}</h1>
        ${this.statsHtml()}
        <h3 class="lb-label">${esc(t('playNow'))}</h3>
        <div class="play-row">${play.map(([id, icn, c, title, desc], i) => `<button class="play-card" data-lb="${id}" style="--fc:${c};animation-delay:${i * 60}ms"><span class="pc-ic">${ic(icn, 30)}</span><b>${esc(title)}</b><span>${esc(desc)}</span></button>`).join('')}</div>
        <h3 class="lb-label">${esc(t('learnMore'))}</h3>
        <div class="feat-grid">
          ${this.card('learn', 'route', '#58cc02', t('path'), t('pathD'), `<div class="fc-body"><span class="fc-big">${esc(curTitle)}</span><div class="fc-bar"><i style="width:${Math.round((done / Math.max(1, all)) * 100)}%"></i></div><small class="muted">${done}/${all}</small></div>`)}
          ${this.card('mistakes', 'target', '#ff4b4b', t('myMistakes'), t('myMistakesD'), weak.length ? `<div class="fc-body"><span class="fc-big">${weak.length}</span><div class="fc-chips">${weakStats().slice(0, 3).map(([k, n]) => `<span>${TH[k]?.icon || ''} ${esc(TH[k]?.[I.lang] || k)} · ${n}</span>`).join('')}</div></div>` : `<div class="fc-body"><small class="muted">${esc(t('noMistakes'))}</small></div>`)}
          ${this.card('endgames', 'shield', '#ff9600', t('endgames'), t('endgamesD'), `<div class="fc-body"><span class="fc-big">${endsDone}/${ends.length}</span><div class="fc-dots">${ends.map((x) => `<i class="${profile.learn.done[x.id] ? 'on' : ''}"></i>`).join('')}</div></div>`)}
          ${this.card('ranking', 'trophy', '#fbbf24', t('ranking'), t('rankingD'), `<div class="fc-body">${top.length ? `<ol class="fc-top3">${top.map((x) => `<li><b>${esc(x.name)}</b><span>${x.rating}</span></li>`).join('')}</ol>` : `<small class="muted">${esc(Ranking.error ? t('lbOffline') : t('lbLoading'))}</small>`}${pos ? `<small class="fc-pos">${esc(t('lbPlace', { n: pos }))}</small>` : ''}</div>`)}
          ${this.card('games', 'doc', '#94a3b8', t('lobbyGames'), t('lobbyGamesD'), `<div class="fc-body"><span class="fc-big">${profile.games}</span><small class="muted">${esc(t('statsGames'))}</small></div>`)}
          ${(() => {
            const f = forecast();
            return this.card('forecast', 'gauge', '#22d3ee', t('forecast'), t('forecastD'), `<div class="fc-body">${profile.placed ? `<span class="fc-big">${f.in90} <small class="muted">Elo</small></span><small class="muted">${esc(t('fcIn', { n: 90 }))} · ${esc(f.pace)}</small>` : `<small class="muted">${esc(t('lbNeedPlace'))}</small>`}</div>`);
          })()}
          ${this.card('iq', 'spark', '#f472b6', t('iqTitle'), t('iqD'), `<div class="fc-body">${profile.iq ? `<span class="fc-big">${profile.iq.iq}<small class="muted"> · ♞ ${profile.iq.chessIq}</small></span><small class="muted">${esc(t('iqLast'))}</small>` : `<small class="muted">${esc(t('iqNone'))}</small>`}</div>`)}
          ${this.card('coach', 'bot', '#a78bfa', L3('Coach-Training', 'Coach training', 'Entrenamiento'), L3('Dein Plan für heute', 'Your plan for today', 'Tu plan de hoy'), `<div class="fc-body fc-coach"><span class="coach-face">♞</span><small>${esc(CoachPlan.teaser())}</small></div>`)}
          ${this.card('shop', 'palette', '#c084fc', t('lobbyShop'), t('lobbyShopD'), `<div class="fc-body fc-shop">${avatarHtml(profile.cos.eq, 40)}<small class="muted">${esc(t('cosD', { p: profile.points }))}</small></div>`)}
        </div>`;
    },
    statsHtml() {
      const acc = profile.accGames ? Math.round(profile.accSum / profile.accGames) : 0;
      return `<div class="lb-stats"><div><b>${profile.placed ? profile.rating : '–'}</b><span>Elo</span></div><div><b>${profile.games}</b><span>${esc(t('statsGames'))}</span></div><div><b>${profile.wins}</b><span>${esc(t('statsWins'))}</span></div><div><b>${acc ? `${acc}%` : '–'}</b><span>${esc(t('statsAcc'))}</span></div></div>`;
    },
    pathHtml() {
      const nodes = pathNodes();
      let html = '';
      let unit = null;
      let k = 0;
      for (const n of nodes) {
        if (n.unit !== unit) {
          if (unit) html += '</div></section>';
          unit = n.unit;
          k = 0;
          const list = nodes.filter((x) => x.unit === unit);
          html += `<section class="unit" style="--uc:${unit.color}"><div class="unit-head"><span class="unit-ic">${unit.icon}&#xFE0E;</span><div><b>${esc(unit.t[I.lang] || unit.t.de)}</b><span>${esc(unit.d[I.lang] || unit.d.de)}</span></div><span class="unit-prog">${list.filter((x) => x.done).length}/${list.length}</span></div><div class="nodes">`;
        }
        const offset = [0, 56, 84, 56, 0, -56, -84, -56][k % 8];
        k += 1;
        const label = n.boss ? n.boss.t[I.lang] || n.boss.t.de : t('lessonN', { n: n.n });
        html += `<div class="node-wrap" style="--x:${offset}px">${n.current ? `<span class="node-start">${esc(t('startL'))}</span>` : ''}<button class="node ${n.done ? 'done' : ''} ${n.current ? 'current' : ''} ${n.locked ? 'locked' : ''} ${n.boss ? 'boss' : ''}" data-node="${n.id}" title="${esc(label)}">${n.locked ? ic('shield', 24) : n.done ? '★' : `${unit.icon}&#xFE0E;`}</button><span class="node-label">${esc(label)}${n.done && !n.boss ? ` <i>${'★'.repeat(n.stars)}${'☆'.repeat(Math.max(0, 3 - n.stars))}</i>` : ''}</span></div>`;
      }
      if (unit) html += '</div></section>';
      return `<div class="path">${html}</div>`;
    },
    mistakesHtml() {
      const weak = profile.weak || [];
      const TH = window.ChessLearn.THEMES;
      if (!weak.length) return `<div class="lb-empty">${ic('target', 40)}<p>${esc(t('noMistakes'))}</p></div>`;
      const sq = (u) => [u.slice(0, 2), u.slice(2, 4)];
      return `<div class="pg-head"><div class="fc-chips big">${weakStats().map(([k, n]) => `<button data-weak="${k}">${TH[k]?.icon || ''} ${esc(TH[k]?.[I.lang] || k)} · ${n}</button>`).join('')}</div><div class="pg-acts"><button class="btn ghost small" data-weak-clear="1">${ic('trash', 14)} ${esc(t('delAllMistakes'))}</button><button class="btn primary" data-weak="">${esc(t('trainAll'))} (${weak.length})</button></div></div>
        <div class="mist-grid">${weak
          .slice(0, 40)
          .map((w, i) => {
            const p = new Position(w.fen);
            const bm = p.find(w.best);
            return `<div class="mist" style="animation-delay:${Math.min(i, 12) * 40}ms">${miniBoard(w.fen, { bad: sq(w.played), good: sq(w.best) })}
              <div class="mist-txt"><span class="mist-tag">${TH[w.theme]?.icon || ''} ${esc(TH[w.theme]?.[I.lang] || w.theme)}</span><span class="mist-boxes" title="${esc(L3('Zweimal richtig lösen – dann verschwindet der Fehler.', 'Solve it right twice and the mistake disappears.', 'Resuélvelo bien dos veces y desaparece.'))}">${[0, 1].map((k) => `<i class="${(w.ok || 0) > k ? 'on' : ''}">${(w.ok || 0) > k ? '✓' : ''}</i>`).join('')}<em>${w.ok || 0}/2</em></span><span class="bad">${esc(t('yourMove', { san: w.san }))}</span><span class="good">${esc(t('bestMoveIs', { san: bm ? san(p, bm) : w.best }))}</span>
              <div class="mist-btns"><button class="btn small" data-weak-one="${i}">${esc(t('trainThis'))}</button><button class="btn small ghost" data-weak-del="${i}" title="${esc(t('delMistake'))}">${ic('trash', 14)}</button></div></div></div>`;
          })
          .join('')}</div>`;
    },
    endgamesHtml() {
      const ends = window.ChessLearn.SCENARIOS.filter((x) => x.cat === 'endgame');
      return `<div class="end-grid">${ends
        .map((s, i) => {
          const goal = s.goal === 'mate' ? t('goalMate', { n: s.moves }) : t('goalPromote', { n: s.moves });
          const done = profile.learn.done[s.id];
          return `<button class="end-card ${done ? 'done' : ''}" data-sc-id="${s.id}" style="animation-delay:${i * 60}ms">${miniBoard(s.fen)}<div><b>${esc(s.t[I.lang] || s.t.de)}</b><span>${esc(goal)}</span><em>${done ? `✓ ${esc(t('doneTag'))}` : `◆ ${s.points}`}</em></div></button>`;
        })
        .join('')}</div>`;
    },
    rankingHtml() {
      if (!Ranking.list) return `<div class="lb-empty">${Ranking.error ? `${ic('alert', 36)}<p>${esc(t('lbOffline'))}</p>` : `<div class="spinner"></div><p>${esc(t('lbLoading'))}</p>`}<button class="btn" data-lb="lbrefresh">${esc(t('lbRefresh'))}</button></div>`;
      const list = Ranking.list;
      return `<div class="pg-head"><span class="muted">${list.length} · ${esc(t('rankingD'))}${profile.placed ? '' : ` · ${esc(t('lbNeedPlace'))}`}</span><button class="btn small" data-lb="lbrefresh">${ic('refresh', 14)} ${esc(t('lbRefresh'))}</button></div>
        ${list.length >= 3 ? `<div class="podium">${[1, 0, 2].map((k) => list[k] ? `<div class="pod p${k + 1}">${avatarHtml(list[k].cos || {}, k === 0 ? 72 : 56)}<b>${esc(list[k].name)}</b><span>${list[k].rating}</span><div class="pod-bar">${k + 1}</div></div>` : '').join('')}</div>` : ''}
        <div class="rank-list">${list
          .slice(0, 100)
          .map((x, i) => `<div class="rank-row ${x.id === profile.uid ? 'me' : ''}"><span class="rr-n">${i + 1}</span>${avatarHtml(x.cos || {}, 32)}<b>${esc(x.name)}${x.id === profile.uid ? ` <em>${esc(t('lbYou'))}</em>` : ''}</b><span class="muted">${x.games || 0} ${esc(t('statsGames'))}</span><span class="rr-elo">${x.rating}</span></div>`)
          .join('') || `<p class="muted">${esc(t('lbEmpty'))}</p>`}</div>`;
    },
    render() {
      const el = $('lobby');
      const titles = { learn: t('path'), mistakes: t('myMistakes'), endgames: t('endgames'), ranking: t('ranking'), iq: t('iqTitle') };
      let body = '';
      if (this.page === 'home') body = this.homeHtml();
      else {
        const inner = { learn: () => this.pathHtml(), mistakes: () => this.mistakesHtml(), endgames: () => this.endgamesHtml(), ranking: () => this.rankingHtml(), iq: () => IQ.html() }[this.page]?.() || '';
        body = `<h1 class="lb-greet">${esc(titles[this.page] || '')}</h1>${inner}`;
      }
      const html = `<div class="lb-float" aria-hidden="true">${['♞', '♛', '♜', '♝', '♚', '♟', '♞', '♜'].map((g, i) => `<span style="--i:${i}">${g}&#xFE0E;</span>`).join('')}</div><div class="lb-inner">${this.head()}${body}</div>`;
      // Gleiche Seite aktualisiert → nur Änderungen übernehmen (kein Blinken)
      const same = this.drawn === this.page && !el.hidden && el.firstChild && window.RevMorph;
      if (same) window.RevMorph.morph(el, html);
      else el.innerHTML = html;
      this.drawn = this.page;
      if (this.page === 'learn' && !same) setTimeout(() => el.querySelector('.node.current')?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 80);
    },
    click(e) {
      const node = e.target.closest('[data-node]');
      if (node) return startNode(pathNodes().find((n) => n.id === node.dataset.node));
      const iqo = e.target.closest('[data-iq]');
      if (iqo) return IQ.answer(iqo.dataset.iq);
      const del = e.target.closest('[data-weak-del]');
      if (del) {
        profile.weak = (profile.weak || []).filter((_, k) => k !== Number(del.dataset.weakDel));
        saveProfile();
        return this.render();
      }
      const clear = e.target.closest('[data-weak-clear]');
      if (clear) {
        if (clear.dataset.armed !== '1') {
          clear.dataset.armed = '1';
          clear.textContent = t('sureDelAll');
          return;
        }
        profile.weak = [];
        saveProfile();
        return this.render();
      }
      const one = e.target.closest('[data-weak-one]');
      if (one) {
        const w = (profile.weak || [])[Number(one.dataset.weakOne)];
        if (w) Lesson.start([{ id: 'weak-one', fen: w.fen, kind: 'best', weak: w, sol: [w.best] }], { id: 'weak-one', title: t('myMistakes'), color: '#ff4b4b', weak: true });
        return;
      }
      const weak = e.target.closest('[data-weak]');
      if (weak) return trainWeak(weak.dataset.weak || '');
      const sc = e.target.closest('[data-sc-id]');
      if (sc) return Scenario.start(window.ChessLearn.SCENARIOS.find((x) => x.id === sc.dataset.scId));
      const cos = e.target.closest('[data-cos]');
      if (cos) {
        const [slot, id] = cos.dataset.cos.split(':');
        const it = cosItem(slot, id);
        const owned = it.price === 0 || (profile.cos.owned[slot] || []).includes(id);
        if (!owned) {
          if (profile.points < it.price) return showToast(t('notEnough'));
          profile.points -= it.price;
          profile.cos.owned[slot] = [...(profile.cos.owned[slot] || []), id];
          Sound.play('great');
        }
        if (it.custom || HP) return HP?.shop();
        profile.cos.eq[slot] = id;
        saveProfile();
        this.render();
        refresh();
        return;
      }
      const a = e.target.closest('[data-lb]')?.dataset.lb;
      if (!a) return;
      if (a === 'shop') return HP ? HP.shop() : null;
      if (a === 'forecast') return forecastModal();
      if (a === 'coach') return CoachPlan.open();
      if (a === 'iq') return IQ.run && !IQ.run.done ? this.show('iq') : (IQ.run = null, this.show('iq'));
      if (a === 'iqstart') return IQ.start();
      if (a === 'iqskip') return IQ.answer(null);
      if (a === 'iqend') return IQ.finish();
      if (['home', 'learn', 'mistakes', 'endgames', 'ranking'].includes(a)) return this.show(a);
      if (a === 'lbrefresh') {
        Ranking.list = null;
        Ranking.error = '';
        this.render();
        return Ranking.load();
      }
      if (a === 'retest') return placementModal(true);
      if (a === 'name') return this.nameModal(() => this.render());
      if (a === 'continue') return this.hide();
      if (a === 'games') {
        this.hide();
        document.querySelector('[data-tab="archive"]').click();
        return;
      }
      if (a === 'bot' || a === 'online' || a === 'random') {
        this.hide();
        newGameModal(a);
      }
    },
  };
  $('lobby').addEventListener('click', (e) => Lobby.click(e));

  /* ================================================================ Start */

  (async () => {
    buildSquares();
    window.CoachAvatar?.mount($('coach-face'));
    await loadProfile();
    applyAbandon();
    await syncHub();
    $('bubble-text').textContent = t('welcome');
    const saved = await window.chessApp?.loadGame().catch(() => null);
    if (saved && saved.moves) {
      game = { assist: null, ...saved };
      pos = new Position(game.startFen);
      for (const m of game.moves) {
        const mm = pos.find(m.uci);
        if (!mm) break;
        pos.make(mm);
      }
      relabelMoves();
      flipped = game.userColor === BLACK;
      buildSquares();
      refresh();
      bubble(esc(t('resumeGame')), 'book');
    } else {
      game = null;
      refresh();
    }
    Lobby.show();
  })();

  window.ChessUI = {
    lobby: Lobby,
    scenario: Scenario,
    lesson: Lesson,
    trainWeak,
    runTour,
    newGame: (tab) => newGameModal(tab),
    online: Online,
    analyseGame,
    openReview,
    state: () => ({ game, fen: pos.fen(), busy, profile, marks: coachMarks, userArrows, userSquares, viewPly }),
    startGame,
    play: (u) => tryMove(sqFrom(u.slice(0, 2)), sqFrom(u.slice(2, 4))),
    explain: (ply) => explainModal(ply, { live: false }),
  };
})();
