'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('chessApp', {
  loadProfile: () => ipcRenderer.invoke('profile:load'),
  saveProfile: (profile) => ipcRenderer.invoke('profile:save', profile),
  loadGame: () => ipcRenderer.invoke('game:load'),
  saveGame: (game) => ipcRenderer.invoke('game:save', game),
  games: () => ipcRenderer.invoke('games:list'),
  addGame: (game) => ipcRenderer.invoke('games:add', game),
});
contextBridge.exposeInMainWorld('stockfish', {
  status: () => ipcRenderer.invoke('sf:status'),
  install: () => ipcRenderer.invoke('sf:install'),
  move: (data) => ipcRenderer.invoke('sf:move', data),
  onProgress: (fn) => ipcRenderer.on('sf:progress', (_e, p) => fn(p)),
});
contextBridge.exposeInMainWorld('hubProfile', {
  get: () => ipcRenderer.invoke('hp:get'),
  name: (v) => ipcRenderer.invoke('hp:name', v),
  earn: (n) => ipcRenderer.invoke('hp:earn', n),
  migrate: (old) => ipcRenderer.invoke('hp:migrate', old),
  shop: () => ipcRenderer.invoke('hp:shop'),
});

// Chats: Gegner anschreiben oder als Freund hinzufügen (je nach dessen Einstellungen)
contextBridge.exposeInMainWorld('hubChat', {
  identity: () => ipcRenderer.invoke('hc:identity'),
  dm: (peer) => ipcRenderer.invoke('hc:dm', peer),
  friend: (peer) => ipcRenderer.invoke('hc:friend', peer),
});
