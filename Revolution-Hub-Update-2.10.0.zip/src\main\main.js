'use strict';

/**
 * Revolution Hub – one app for Dropzone, the Gaming Hub, Orbit Island and the hub's own
 * tools (System-Monitor, Screenshot, Video-Schnitt, Dokumente, Schach-Coach).
 */

const electron = require('electron');
const { app, BrowserWindow, Menu, Tray, ipcMain, nativeImage, protocol, shell, Notification, powerSaveBlocker } = electron;
const fs = require('fs');
const path = require('path');
const { createShim, privilegedSchemes } = require('./shim');
const { ModuleView } = require('./module-view');
const { OrbitIsland } = require('./orbit');

const APP_ROOT = path.join(__dirname, '..', '..');
const UI_DIR = path.join(APP_ROOT, 'src', 'ui');
const APPS_DIR = path.join(APP_ROOT, 'src', 'apps');
const ICON = path.join(UI_DIR, 'assets', 'logo.png');
const WALLPAPER_DIR = path.join(APP_ROOT, 'modules', 'gaming-hub', 'assets', 'wallpapers');
const START_HIDDEN = process.argv.includes('--hidden');

const RAIL_WIDTH = 0; // Seitenleiste ersetzt durch das Dock
const DOCK_SPACE = { s: 80, m: 96, l: 112 };
const TOOL_PAGES = ['translate', 'calc', 'convert', 'currency', 'weather', 'notes', 'timer', 'password', 'clipboard', 'worldclock', 'autoclick', 'shield', 'schematics', 'account'].map((x) => `tool-${x}`);
const TOPBAR_HEIGHT = 44;

app.setName('Revolution Hub');
// Aufnahmen (Clips, Facecam) laufen im Hintergrund weiter, während ein Spiel im Vordergrund ist:
// Chromium soll versteckte Ansichten und Timer dabei nicht drosseln – sonst ruckeln die Clips.
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.commandLine.appendSwitch('disable-features', 'IntensiveWakeUpThrottling,CalculateNativeWinOcclusion');
app.setPath('userData', path.join(app.getPath('appData'), 'Revolution Hub'));
if (process.platform === 'win32') app.setAppUserModelId('com.revolution.hub');

// One hub at a time: the overlays, hotkeys and tray must not exist twice.
if (!app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}

/* ------------------------------------------------------------------ settings */

const WALLPAPERS = ['nebula', 'aurora', 'galaxy', 'synthwave', 'liquid', 'silk', 'waves', 'ocean', 'clouds', 'mountains', 'fireflies', 'bokeh', 'lava', 'warp'];

const DEFAULT_SETTINGS = {
  autoStart: false,
  closeToTray: true,
  orbitWithHub: true,
  startPage: 'home',
  lastPage: 'home',
  trayHintShown: false,
  wallpaper: 'nebula',
  wallpaperDim: 0.45,
  wallpaperIsland: false,
  sounds: true,
  soundVolume: 0.5,
  lang: '',
  dock: { pos: 'bottom', size: 'm', items: null, magnify: true },
  updateAuto: true,
  muteWinNotify: true,
  updateUrl: '',
  dnd: false,
  notes: '',
};

const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');

function readSettings() {
  try {
    return { ...DEFAULT_SETTINGS, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

let settings = readSettings();

/* ------------------------------------------------------------------ Sprache */
// Ganze App dreisprachig: der Hub und alle Apps übersetzen ihre Oberfläche zur Laufzeit.
let translatorCode = '';
function translatorScript() {
  if (!translatorCode) {
    try {
      translatorCode = fs.readFileSync(path.join(APP_ROOT, 'src', 'shared', 'i18n-dict.js'), 'utf8') + '\n' + fs.readFileSync(path.join(APP_ROOT, 'src', 'shared', 'translate.js'), 'utf8');
    } catch {
      translatorCode = '';
    }
  }
  return `${translatorCode}\n;window.RevTranslate && window.RevTranslate.set(${JSON.stringify(currentLang())});`;
}
function currentLang() {
  if (['de', 'en', 'es'].includes(settings.lang)) return settings.lang;
  const loc = String(app.getLocale?.() || 'de').slice(0, 2);
  return ['de', 'en', 'es'].includes(loc) ? loc : 'en';
}

function saveSettings(patch) {
  settings = { ...settings, ...patch };
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch (error) {
    console.error('[hub] could not save settings', error);
  }
  return settings;
}

function applyAutoStart() {
  if (!app.isPackaged || process.platform !== 'win32') return;
  app.setLoginItemSettings({ openAtLogin: Boolean(settings.autoStart), path: process.execPath, args: ['--hidden'] });
}

let clickClipCache = null;
function clickClip() {
  if (settings.clickSound !== 'kq') return '';
  if (clickClipCache === null) {
    try {
      clickClipCache = fs.readFileSync(path.join(__dirname, '..', 'shared', 'assets', 'click-kq.mp3')).toString('base64');
    } catch {
      clickClipCache = '';
    }
  }
  return clickClipCache;
}

function appearance() {
  return { sounds: settings.sounds, volume: settings.soundVolume, clickSound: settings.clickSound || 'classic', clickClip: clickClip(), wallpaper: settings.wallpaper, dim: settings.wallpaperDim, lang: currentLang() };
}

/* ------------------------------------------------------------------- modules */

function readVersion(dir) {
  try {
    return JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).version || '1.0.0';
  } catch {
    return '1.0.0';
  }
}

const appData = app.getPath('appData');
const hubData = (name) => path.join(app.getPath('userData'), name);

// The hub paints one live wallpaper behind everything; the apps are made see-through.
const DROPZONE_CSS = `
html, body, #root { background: transparent !important; }
.app-shell { background: transparent !important; border: 0 !important; border-radius: 0 !important; box-shadow: none !important; }
.wallpaper-layer { display: none !important; }
section.panel:has(.wp-name) { display: none !important; }
.titlebar .win-btn, .titlebar .mx-1\\.5.h-4.w-px { display: none !important; }
.hub-copy-path { display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 11px; margin-right: 8px;
  border-radius: 8px; border: 1px solid var(--line-2); background: color-mix(in srgb, var(--surface-2) 70%, transparent);
  color: var(--text); font-size: 12px; font-weight: 600; cursor: pointer; transition: background .15s, border-color .15s; }
.hub-copy-path:hover { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 45%, transparent); }
.hub-copy-path svg { width: 14px; height: 14px; }
.hub-copy-crumb { flex: none; display: inline-grid; place-items: center; width: 28px; height: 28px; margin-left: 6px; border-radius: 8px;
  border: 1px solid var(--line-2); background: color-mix(in srgb, var(--surface-2) 70%, transparent); color: var(--text); cursor: pointer;
  transition: background .15s, border-color .15s, transform .1s; -webkit-app-region: no-drag; }
.hub-copy-crumb:hover { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 45%, transparent); }
.hub-copy-crumb:active { transform: scale(.92); }
.hub-copy-crumb.done { border-color: #3ddc97; color: #3ddc97; }
.hub-copy-crumb svg { width: 14px; height: 14px; }
`;

// "Pfad kopieren": copies the selected items, or the open folder when nothing is selected.
const DROPZONE_SCRIPT = `(() => {
  if (window.__hubCopyPath) return;
  window.__hubCopyPath = true;
  const ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
  function paths() {
    const store = window.__dropzoneStore;
    if (!store) return [];
    const state = store.getState();
    const pane = state.panes[state.activePane];
    const tab = pane.tabs.find((t) => t.id === pane.activeId) || pane.tabs[0];
    const selection = Array.from(tab.selection || []);
    return selection.length ? selection : tab.path ? [tab.path] : [];
  }
  function copy() {
    const list = paths();
    if (!list.length) return;
    const text = list.join('\\r\\n');
    if (window.dropzone && window.dropzone.copyText) window.dropzone.copyText(text);
    else navigator.clipboard.writeText(text).catch(() => {});
    const state = window.__dropzoneStore.getState();
    if (state.toast) state.toast(list.length > 1 ? list.length + ' Pfade kopiert' : 'Pfad kopiert: ' + list[0], 'ok');
  }
  function mount() {
    const bar = document.querySelector('.titlebar .no-drag.flex');
    if (!bar || bar.querySelector('.hub-copy-path')) return;
    const button = document.createElement('button');
    button.className = 'hub-copy-path';
    button.title = 'Pfad der Auswahl kopieren – ohne Auswahl den Pfad des Ordners (Strg+Umschalt+C)';
    button.innerHTML = ICON + '<span>Pfad kopieren</span>';
    button.addEventListener('click', copy);
    bar.insertBefore(button, bar.firstChild);
  }
  // Zusätzlich: ein Kopier-Knopf direkt neben der Pfadleiste jedes Fensterteils
  function copyPane(index, button) {
    const store = window.__dropzoneStore;
    if (!store) return copy();
    const state = store.getState();
    const panes = Array.isArray(state.panes) ? state.panes : Object.values(state.panes || {});
    const pane = panes[index] || state.panes[state.activePane];
    const tab = pane && (pane.tabs.find((t) => t.id === pane.activeId) || pane.tabs[0]);
    if (!tab || !tab.path) return copy();
    if (window.dropzone && window.dropzone.copyText) window.dropzone.copyText(tab.path);
    else navigator.clipboard.writeText(tab.path).catch(() => {});
    if (state.toast) state.toast('Pfad kopiert: ' + tab.path, 'ok');
    button.classList.add('done');
    setTimeout(() => button.classList.remove('done'), 900);
  }
  function mountCrumbs() {
    document.querySelectorAll('.crumbs').forEach((crumbs, index) => {
      const next = crumbs.nextElementSibling;
      if (next && next.classList.contains('hub-copy-crumb')) return;
      const button = document.createElement('button');
      button.className = 'hub-copy-crumb';
      button.title = 'Pfad dieses Ordners kopieren';
      button.innerHTML = ICON;
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        copyPane([...document.querySelectorAll('.crumbs')].indexOf(crumbs), button);
      });
      crumbs.insertAdjacentElement('afterend', button);
    });
  }
  let pending = 0;
  const mountAll = () => {
    if (pending) return;
    pending = requestAnimationFrame(() => {
      pending = 0;
      mount();
      mountCrumbs();
    });
  };
  new MutationObserver(mountAll).observe(document.documentElement, { childList: true, subtree: true });
  mountAll();
  window.addEventListener('keydown', (event) => {
    if (event.ctrlKey && event.shiftKey && !event.altKey && event.key.toLowerCase() === 'c') {
      const target = event.target;
      if (target && (target.isContentEditable || /^(input|textarea)$/i.test(target.tagName))) return;
      event.preventDefault();
      copy();
    }
  }, true);
})();`;

const GAMING_CSS = `
body { background: transparent !important; }
.wall, .wall-shade { display: none !important; }
.card:has(#wall-grid) { display: none !important; }
.win-controls { display: none !important; }
[data-view="music"] { display: none !important; }
.app { background: rgba(8, 9, 13, 0.34); }
`;

// The hub plays the click sounds and the wallpaper for every app.
const GAMING_SCRIPT = `(() => {
  try { playClick = function () {}; } catch (e) {}
  try { applyWallpaper = function () {}; } catch (e) {}
  const video = document.getElementById('wall');
  if (video) { video.pause(); video.removeAttribute('src'); video.load(); }
})();`;

const MODULES = [
  {
    id: 'dropzone',
    name: 'Dropzone by Revolution',
    dir: path.join(APP_ROOT, 'modules', 'dropzone'),
    entry: path.join('dist', 'main', 'main.cjs'),
    dataDir: path.join(appData, 'Dropzone by Revolution'),
    lazy: true,
    css: DROPZONE_CSS,
    script: DROPZONE_SCRIPT,
  },
  {
    id: 'gaming',
    name: 'Revolution Gaming Hub',
    dir: path.join(APP_ROOT, 'modules', 'gaming-hub'),
    entry: path.join('app', 'main.js'),
    dataDir: path.join(appData, 'Revolution Gaming Hub'),
    // Crosshair, clips and overlays run all the time, so this one loads at start.
    lazy: false,
    css: GAMING_CSS,
    script: GAMING_SCRIPT,
  },
  { id: 'screenshot', name: 'Screenshot', dir: path.join(APPS_DIR, 'screenshot'), entry: 'main.js', dataDir: hubData('screenshot'), lazy: true },
  { id: 'video', name: 'Video-Schnitt', dir: path.join(APPS_DIR, 'video'), entry: 'main.js', dataDir: hubData('video'), lazy: true },
  { id: 'docs', name: 'Dokumente', dir: path.join(APPS_DIR, 'docs'), entry: 'main.js', dataDir: hubData('docs'), lazy: true },
  { id: 'chess', name: 'Schach-Coach', dir: path.join(APPS_DIR, 'chess'), entry: 'main.js', dataDir: hubData('chess'), lazy: true, ownI18n: true },
  // Agenda läuft immer (Erinnerungen), die Ansicht ist klein.
  { id: 'agenda', name: 'Agenda', dir: path.join(APPS_DIR, 'agenda'), entry: 'main.js', dataDir: hubData('agenda'), lazy: false },
  // Chats laufen immer mit, damit Nachrichten (Island, roter Punkt) auch ohne Öffnen ankommen.
  { id: 'chats', name: 'Chats', dir: path.join(APPS_DIR, 'chats'), entry: 'main.js', dataDir: hubData('chats'), lazy: false },
  { id: 'geo', name: 'GeoRevolution', dir: path.join(APPS_DIR, 'geo'), entry: 'main.js', dataDir: hubData('geo'), lazy: true, ownI18n: true },
];
for (const mod of MODULES) {
  mod.partition = `persist:${mod.id}`;
  mod.version = mod.dir.startsWith(APPS_DIR) ? app.getVersion() : readVersion(mod.dir);
  mod.error = null;
}
const moduleById = (id) => MODULES.find((mod) => mod.id === id);

/* ----------------------------------------------------------------------- hub */

const PAGES = new Set(['home', 'orbit', 'settings', 'shop', ...TOOL_PAGES, ...MODULES.map((mod) => mod.id)]);

/** Aktueller Screenshot-Hotkey (aus den Einstellungen der Screenshot-App), lesbar formatiert. */
function screenshotHotkey() {
  let key = 'CommandOrControl+Shift+X';
  try {
    const saved = JSON.parse(fs.readFileSync(path.join(hubData('screenshot'), 'settings.json'), 'utf8'));
    if (typeof saved.hotkey === 'string') key = saved.hotkey;
  } catch {
    /* Standard */
  }
  if (!key) return '';
  return key
    .split('+')
    .map((part) => ({ CommandOrControl: 'Strg', CmdOrCtrl: 'Strg', Control: 'Strg', Ctrl: 'Strg', Shift: 'Umschalt', Alt: 'Alt', Super: 'Win', Meta: 'Win', PrintScreen: 'Druck' })[part] || part)
    .join('+');
}

const hub = {
  window: null,
  tray: null,
  active: 'home',
  views: new Map(),
  opened: new Set(),
  moduleTrays: new Map(),
  quitting: false,
  visible: new Map(),

  wasOpened(id) {
    return this.opened.has(id);
  },

  attachView(view) {
    this.views.set(view.mod.id, view);
    if (this.window) this.window.contentView.addChildView(view.view);
    if (this.opened.has(view.mod.id)) view.ensureLoaded();
    // Chats laufen im Hintergrund mit, sobald man sie einmal benutzt hat – sonst
    // kämen neue Nachrichten erst an, wenn man den Bereich öffnet.
    else if (view.mod.id === 'chats' && settings.chatsUsed) setTimeout(() => view.ensureLoaded(), 4000);
    this.layout();
  },

  viewForContents(contents) {
    for (const view of this.views.values()) if (view.webContents === contents) return view;
    return null;
  },

  open(id) {
    if (!PAGES.has(id)) return;
    this.active = id;
    const view = this.views.get(id);
    if (view) {
      this.opened.add(id);
      view.ensureLoaded();
    }
    saveSettings({ lastPage: id, openedPages: [...this.opened].slice(0, 20), ...(id === 'chats' && !settings.chatsUsed ? { chatsUsed: true } : {}) });
    this.layout();
    this.showWindow();
    if (view) view.webContents.focus();
    this.pushState();
  },

  layout() {
    if (!this.window || this.window.isDestroyed()) return;
    const [width, height] = this.window.getContentSize();
    // Platz für das schwebende Dock frei lassen (unten, oben, links oder rechts)
    const dock = settings.dock || {};
    const space = DOCK_SPACE[dock.size] || DOCK_SPACE.m;
    const pos = ['bottom', 'top', 'left', 'right'].includes(dock.pos) ? dock.pos : 'bottom';
    const bounds = { x: RAIL_WIDTH, y: TOPBAR_HEIGHT, width: Math.max(0, width - RAIL_WIDTH), height: Math.max(0, height - TOPBAR_HEIGHT) };
    if (pos === 'bottom') bounds.height = Math.max(0, bounds.height - space);
    if (pos === 'top') {
      bounds.y += space;
      bounds.height = Math.max(0, bounds.height - space);
    }
    if (pos === 'left') {
      bounds.x += space;
      bounds.width = Math.max(0, bounds.width - space);
    }
    if (pos === 'right') bounds.width = Math.max(0, bounds.width - space);
    const windowShown = this.window.isVisible() && !this.window.isMinimized();
    for (const [id, view] of this.views) {
      view.view.setBounds(bounds);
      // Starter, Kontrollzentrum usw. liegen im Hub-Fenster – solange sie offen sind, App ausblenden
      view.view.setVisible(id === this.active && !this.overlay);
      // Apps pause live work (e.g. the system sampler) while they are not on screen.
      const shown = windowShown && id === this.active;
      if (this.visible.get(id) !== shown) {
        this.visible.set(id, shown);
        if (!view.isDestroyed()) view.webContents.send('hub:visibility', shown);
        view.emit('hub-visibility', shown);
      }
    }
  },

  showWindow() {
    if (!this.window || this.window.isDestroyed()) return;
    if (this.window.isMinimized()) this.window.restore();
    if (!this.window.isVisible()) this.window.show();
    this.window.focus();
  },

  quit() {
    this.quitting = true;
    app.quit();
  },

  /**
   * One place for every message of the ecosystem: while Orbit Island runs it shows the
   * message (with the app's icon), otherwise Windows does.
   */
  islandRunning() {
    return Boolean(orbit.running);
  },

  notify(title, body, { open = '', app = 'Revolution Hub', icon = ICON, accent = '', glyph = '' } = {}) {
    if (settings.dnd) return; // Nicht stören
    if (orbit.running && orbit.post({ title, message: body || '', app, icon, open, ...(accent ? { accent } : {}), ...(glyph ? { glyph } : {}) })) return;
    if (!Notification.isSupported()) return;
    const note = new Notification({ title, body, icon: ICON });
    if (open) note.on('click', () => shell.openPath(open));
    note.show();
  },

  registerModuleTray(id, tray) {
    this.moduleTrays.set(id, tray);
  },

  refreshTray() {
    if (this.tray && !this.tray.isDestroyed()) this.tray.setContextMenu(buildTrayMenu());
  },

  state() {
    return {
      lang: currentLang(),
      active: this.active,
      maximized: Boolean(this.window?.isMaximized()),
      modules: MODULES.map((mod) => ({
        id: mod.id,
        name: mod.name,
        version: mod.version,
        error: mod.error,
        ready: Boolean(this.views.get(mod.id)?.ready),
      })),
      orbit: { available: orbit.available(), running: orbit.running },
      opened: [...this.opened],
      gameMode: Boolean(settings.gameMode),
      keepAwake: Boolean(settings.keepAwake),
      keepAwakeUntil: Number(settings.keepAwakeUntil) || 0,
      screenshotHotkey: screenshotHotkey(),
      upcoming: global.__revolutionHub?.agenda?.upcoming?.() || [],
      badges: { ...badges },
      settings,
      wallpapers: WALLPAPERS,
      wallpaperDir: WALLPAPER_DIR,
      version: app.getVersion(),
    };
  },

  /** Profil (Name, Punkte, Cosmetics) an Hub-Oberfläche und alle Apps schicken. */
  pushProfile() {
    const p = hubProfile();
    if (this.window && !this.window.isDestroyed()) this.window.webContents.send('hub:profile', p);
    const js = `window.dispatchEvent(new CustomEvent('hub-profile', { detail: ${JSON.stringify(p)} }))`;
    for (const view of this.views.values()) if (!view.webContents.isDestroyed()) view.webContents.executeJavaScript(js, true).catch(() => {});
  },

  pushState() {
    if (this.window && !this.window.isDestroyed()) this.window.webContents.send('hub:state', this.state());
  },

  pushAppearance() {
    const payload = appearance();
    for (const view of this.views.values()) if (!view.isDestroyed()) view.webContents.send('hub:appearance', payload);
  },

  /** Neue Sprache an den Hub und alle Apps weitergeben. */
  applyLang() {
    const lang = currentLang();
    this.window?.webContents.executeJavaScript(`window.RevTranslate && window.RevTranslate.set(${JSON.stringify(lang)})`, true).catch(() => {});
    for (const [id, view] of this.views) {
      if (view.isDestroyed()) continue;
      const mod = moduleById(id);
      const code = mod?.ownI18n
        ? `window.dispatchEvent(new CustomEvent('hub-lang', { detail: ${JSON.stringify(lang)} }))`
        : `window.RevTranslate ? window.RevTranslate.set(${JSON.stringify(lang)}) : 0`;
      view.webContents.executeJavaScript(code, true).catch(() => {});
    }
    this.pushAppearance();
  },
  translatorScript: () => translatorScript(),
  currentLang: () => currentLang(),

  /** Lets an app inside the hub run a hub action (e.g. hide the window for a screenshot). */
  api: {},

  /** Data folder of another area, so the apps can share files (e.g. Gaming Hub clips → Video). */
  moduleDataDir(id) {
    return moduleById(id)?.dataDir || '';
  },
};

/* ------------------------------------------------------------- Hub-Profil */
// Ein Profil für alle Apps: Anzeigename, Punkte (◆) und Cosmetics.
const RevCos = require('../shared/cosmetics.js');
const defaultProfile = () => ({ name: '', points: 0, cos: { owned: {}, eq: {} }, migrated: false });
function hubProfile() {
  const p = { ...defaultProfile(), ...(settings.profile || {}) };
  p.cos = { owned: { ...(p.cos?.owned || {}) }, eq: { ...(p.cos?.eq || {}) } };
  return p;
}
const cleanName = (v) => String(v || '').trim().replace(/\s+/g, ' ').slice(0, 16);
const profileApi = {
  get: () => hubProfile(),
  save(p) {
    saveSettings({ profile: p, profileAt: Date.now() });
    hub.pushProfile();
    accountChanged();
    return p;
  },
  setName(name) {
    const p = hubProfile();
    const v = cleanName(name);
    if (v.length < 2) return p;
    p.name = v;
    return this.save(p);
  },
  earn(amount) {
    const n = Math.max(0, Math.min(1000, Math.round(Number(amount) || 0)));
    const p = hubProfile();
    p.points += n;
    return this.save(p);
  },
  buy(slot, id) {
    const p = hubProfile();
    const it = RevCos.COSMETICS[slot]?.find((x) => x.id === id);
    if (!it) throw new Error('Unbekannter Artikel');
    const owned = it.price === 0 || (p.cos.owned[slot] || []).includes(id);
    if (!owned) {
      if (p.points < it.price) throw new Error('Nicht genug Punkte');
      p.points -= it.price;
      p.cos.owned[slot] = [...(p.cos.owned[slot] || []), id];
    }
    if (!(it.custom && !p.cos.eq.img)) p.cos.eq[slot] = id;
    return this.save(p);
  },
  equip(slot, id) {
    const p = hubProfile();
    const it = RevCos.COSMETICS[slot]?.find((x) => x.id === id);
    if (!it || !(it.price === 0 || (p.cos.owned[slot] || []).includes(id))) return p;
    p.cos.eq[slot] = id;
    return this.save(p);
  },
  setImage(dataUrl) {
    const p = hubProfile();
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/') || dataUrl.length > 60000) throw new Error('Bild zu groß');
    if (!(p.cos.owned.avatar || []).includes('custom')) throw new Error('Erst im Shop freischalten');
    p.cos.eq.img = dataUrl;
    p.cos.eq.avatar = 'custom';
    return this.save(p);
  },
  /** Einmalig: Punkte, Name und Cosmetics aus dem alten Schach-Profil übernehmen. */
  migrate(old) {
    const p = hubProfile();
    if (p.migrated) return p;
    p.migrated = true;
    if (old && typeof old === 'object') {
      if (!p.name && old.name) p.name = cleanName(old.name);
      p.points += Math.max(0, Math.min(100000, Number(old.points) || 0));
      for (const [slot, list] of Object.entries(old.cos?.owned || {})) if (RevCos.COSMETICS[slot] && Array.isArray(list)) p.cos.owned[slot] = [...new Set([...(p.cos.owned[slot] || []), ...list.filter((x) => typeof x === 'string')])];
      for (const [slot, id] of Object.entries(old.cos?.eq || {})) if (typeof id === 'string' && (RevCos.COSMETICS[slot] || slot === 'img')) p.cos.eq[slot] = id;
    }
    return this.save(p);
  },
};

/* ------------------------------------------------- Badges (roter Punkt) */
const badges = {};
let overlayIcon = null;
function badgeIcon() {
  if (overlayIcon) return overlayIcon;
  const { nativeImage } = require('electron');
  const S = 32, buf = Buffer.alloc(S * S * 4);
  for (let y = 0; y < S; y += 1)
    for (let x = 0; x < S; x += 1) {
      const d = Math.hypot(x - S / 2 + 0.5, y - S / 2 + 0.5), a = Math.max(0, Math.min(1, S / 2 - 1 - d));
      const i = (y * S + x) * 4;
      // BGRA
      buf[i] = 48; buf[i + 1] = 59; buf[i + 2] = 255; buf[i + 3] = Math.round(a * 255);
    }
  overlayIcon = nativeImage.createFromBitmap(buf, { width: S, height: S });
  return overlayIcon;
}
function setBadge(id, n) {
  const v = Math.max(0, Math.min(999, Number(n) || 0));
  if ((badges[id] || 0) === v) return;
  if (v) badges[id] = v;
  else delete badges[id];
  const total = Object.values(badges).reduce((a, b) => a + b, 0);
  try {
    if (hub.window && !hub.window.isDestroyed()) hub.window.setOverlayIcon(total ? badgeIcon() : null, total ? `${total} ungelesen` : '');
  } catch {
    /* egal */
  }
  hub.pushState();
}

/* ------------------------------------------- Chats ↔ Spiele (Brücke) */
const chatBridge = {
  pending: [],
  onDm: null,
  identity() {
    const c = settings.chat || {};
    return c.code ? { code: c.code, name: hubProfile().name || c.name || '', allowGameDMs: c.allowGameDMs !== false, allowFriendReq: c.allowFriendReq !== false } : null;
  },
  setIdentity(id) {
    if (!id || !/^[A-Z0-9]{8}$/.test(String(id.code || ''))) return;
    saveSettings({ chat: { code: id.code, name: String(id.name || '').slice(0, 24), allowGameDMs: id.allowGameDMs !== false, allowFriendReq: id.allowFriendReq !== false } });
  },
  /** Aus einem Spiel: Chat mit dem Gegner öffnen oder ihn als Freund hinzufügen. */
  request(peer, kind) {
    if (!peer || !/^[A-Z0-9]{8}$/.test(String(peer.code || ''))) throw new Error('Der Gegner hat keinen Chat-Code');
    const item = { kind: kind === 'friend' ? 'friend' : 'dm', code: peer.code, name: String(peer.name || 'Spieler').slice(0, 24), cos: peer.cos || null, game: String(peer.game || '') };
    if (this.onDm) this.onDm(item);
    else this.pending.push(item);
    if (item.kind === 'dm') hub.open('chats');
    return true;
  },
  take() {
    const p = this.pending;
    this.pending = [];
    return p;
  },
};

global.__revolutionHub = {
  hub,
  profile: profileApi,
  chat: chatBridge,
  setBadge,
  shim: (id) => createShim(moduleById(id), hub),
  view: (id, options) => new ModuleView(hub, moduleById(id), options),
};

const orbit = new OrbitIsland(() => {
  hub.pushState();
  hub.refreshTray();
});

/* -------------------------------------------------------------------- window */

function createWindow() {
  hub.window = new BrowserWindow({
    width: 1460,
    height: 920,
    minWidth: 1140,
    minHeight: 720,
    show: false,
    frame: false,
    backgroundColor: '#07070b',
    title: 'Revolution Hub',
    icon: ICON,
    webPreferences: {
      preload: path.join(APP_ROOT, 'src', 'preload', 'hub-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });

  for (const view of hub.views.values()) hub.window.contentView.addChildView(view.view);

  hub.window.loadFile(path.join(UI_DIR, 'index.html'));
  hub.window.once('ready-to-show', () => {
    hub.layout();
    if (!START_HIDDEN) hub.window.show();
  });
  for (const event of ['resize', 'show', 'hide', 'minimize', 'restore']) hub.window.on(event, () => hub.layout());
  hub.window.on('maximize', () => hub.pushState());
  hub.window.on('unmaximize', () => hub.pushState());
  hub.window.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  hub.window.on('close', (event) => {
    if (hub.quitting) return;
    // Laufen Crosshair, Clipper oder der Autoclicker, bleibt der Hub immer im Hintergrund offen.
    let working = false;
    try {
      working = Boolean(global.__revolutionHub?.gamingActive?.()) || autoclick.status().running;
    } catch {
      working = false;
    }
    if (!settings.closeToTray && !working) {
      // Overlay windows would keep the process alive, so quit explicitly.
      hub.quitting = true;
      setImmediate(() => app.quit());
      return;
    }
    event.preventDefault();
    hub.window.hide();
    if (!settings.trayHintShown) {
      hub.notify('Revolution Hub läuft weiter', 'Crosshair, Overlays, Screenshot-Hotkey und Orbit Island bleiben aktiv. Beenden über das Symbol im Infobereich.');
      saveSettings({ trayHintShown: true });
    }
  });
}

/* ---------------------------------------------------------------------- tray */

const TRAY_SECTIONS = { gaming: 'Gaming Hub', dropzone: 'Dateien' };

function moduleTraySubmenu(id, tray) {
  if (!tray?.menu || tray.isDestroyed()) return null;
  const items = tray.menu.items
    .filter((item) => !/^(beenden|quit|exit|fenster öffnen)$/i.test(item.label) && item.label !== moduleById(id).name)
    .map((item) => ({
      label: item.label,
      type: item.type,
      checked: item.checked,
      enabled: item.enabled,
      click: item.click
        ? (...args) => {
            if (/statistik/i.test(item.label)) hub.open(id);
            item.click(...args);
          }
        : undefined,
    }));
  while (items.length && items[0].type === 'separator') items.shift();
  while (items.length && items[items.length - 1].type === 'separator') items.pop();
  return items.length ? Menu.buildFromTemplate(items) : null;
}

function buildTrayMenu() {
  const template = [
    { label: 'Revolution Hub öffnen', click: () => hub.open(hub.active) },
    { label: 'Screenshot aufnehmen', click: () => hub.api?.screenshot?.() },
    { type: 'separator' },
    { label: 'Dateien', click: () => hub.open('dropzone') },
    { label: 'Gaming Hub', click: () => hub.open('gaming') },
    { label: 'Video-Schnitt', click: () => hub.open('video') },
    { label: 'Dokumente', click: () => hub.open('docs') },
    { label: 'Schach-Coach', click: () => hub.open('chess') },
    { label: 'GeoRevolution', click: () => hub.open('geo') },
    { label: 'Agenda', click: () => hub.open('agenda') },
    { label: 'Chats', click: () => hub.open('chats') },
  ];
  const sections = [];
  for (const [id, tray] of hub.moduleTrays) {
    const submenu = moduleTraySubmenu(id, tray);
    if (submenu) sections.push({ label: TRAY_SECTIONS[id] || moduleById(id).name, submenu });
  }
  if (sections.length) template.push({ type: 'separator' }, ...sections);
  if (orbit.available()) {
    template.push(
      { type: 'separator' },
      {
        label: 'Orbit Island',
        type: 'checkbox',
        checked: orbit.running,
        click: () => (orbit.running ? orbit.stop() : orbit.start()).catch(() => {}),
      },
    );
  }
  template.push({ type: 'separator' }, { label: 'Beenden', click: () => hub.quit() });
  return Menu.buildFromTemplate(template);
}

function createTray() {
  const image = nativeImage.createFromPath(ICON).resize({ width: 16, height: 16 });
  hub.tray = new Tray(image);
  hub.tray.setToolTip('Revolution Hub');
  hub.tray.on('click', () => hub.open(hub.active));
  hub.refreshTray();
}

/* ----------------------------------------------------------------------- IPC */

function handle(channel, fn) {
  ipcMain.handle(`hub:${channel}`, async (event, ...args) => {
    if (event.sender !== hub.window?.webContents) throw new Error('Unzulässiger Aufrufer');
    return fn(...args);
  });
}

// Read-only appearance for the apps inside the hub (click sounds).
ipcMain.handle('hub-view:appearance', () => appearance());

handle('state', () => hub.state());
handle('open', (id) => hub.open(id));
handle('window', (action) => {
  const win = hub.window;
  if (!win) return false;
  if (action === 'minimize') win.minimize();
  else if (action === 'maximize') (win.isMaximized() ? win.unmaximize() : win.maximize());
  else if (action === 'close') win.close();
  return true;
});
handle('settings:set', async (patch) => {
  const allowed = {};
  for (const key of ['autoStart', 'closeToTray', 'orbitWithHub', 'sounds', 'wallpaperIsland', 'updateAuto']) if (typeof patch?.[key] === 'boolean') allowed[key] = patch[key];
  if (patch?.startPage === 'home' || patch?.startPage === 'last') allowed.startPage = patch.startPage;
  if (typeof patch?.soundVolume === 'number') allowed.soundVolume = Math.min(1, Math.max(0, patch.soundVolume));
  if (typeof patch?.wallpaperDim === 'number') allowed.wallpaperDim = Math.min(0.9, Math.max(0, patch.wallpaperDim));
  if (patch?.wallpaper === 'none' || WALLPAPERS.includes(patch?.wallpaper)) allowed.wallpaper = patch.wallpaper;
  if (['de', 'en', 'es'].includes(patch?.lang)) allowed.lang = patch.lang;
  // Seitenleiste: angeheftete Apps (max. 3) + Gruppen
  if (patch?.nav && Array.isArray(patch.nav.pinned) && Array.isArray(patch.nav.groups)) {
    const ids = (list) => (Array.isArray(list) ? list.filter((x) => typeof x === 'string' && x.length < 30).slice(0, 40) : []);
    allowed.nav = {
      pinned: ids(patch.nav.pinned).slice(0, 3),
      groups: patch.nav.groups.slice(0, 12).map((g) => ({ id: String(g.id || '').slice(0, 30), name: String(g.name || 'Gruppe').slice(0, 18), apps: ids(g.apps) })),
    };
  }
  if (Array.isArray(patch?.navCollapsed)) allowed.navCollapsed = patch.navCollapsed.filter((x) => typeof x === 'string').slice(0, 12);
  if (patch?.dock && typeof patch.dock === 'object') {
    const d = { ...(settings.dock || {}) };
    if (['bottom', 'top', 'left', 'right'].includes(patch.dock.pos)) d.pos = patch.dock.pos;
    if (['s', 'm', 'l'].includes(patch.dock.size)) d.size = patch.dock.size;
    if (typeof patch.dock.magnify === 'boolean') d.magnify = patch.dock.magnify;
    if (Array.isArray(patch.dock.items)) d.items = [...new Set(patch.dock.items.filter((x) => typeof x === 'string' && x.length < 30))].slice(0, 30);
    allowed.dock = d;
  }
  if (typeof patch?.dnd === 'boolean') allowed.dnd = patch.dnd;
  if (typeof patch?.muteWinNotify === 'boolean') allowed.muteWinNotify = patch.muteWinNotify;
  if (['classic', 'kq'].includes(patch?.clickSound)) allowed.clickSound = patch.clickSound;
  if (typeof patch?.updateAuto === 'boolean') allowed.updateAuto = patch.updateAuto;
  if (typeof patch?.seenVersion === 'string') allowed.seenVersion = patch.seenVersion.slice(0, 20);
  if (patch?.autoclick && typeof patch.autoclick === 'object') allowed.autoclick = cleanAutoclick(patch.autoclick);
  if (patch?.shield && typeof patch.shield === 'object') allowed.shield = { watch: patch.shield.watch !== false, locate: patch.shield.locate !== false };
  if (Array.isArray(patch?.weatherCities)) allowed.weatherCities = patch.weatherCities.filter((c) => c && typeof c === 'object').slice(0, 8).map((c) => ({ name: String(c.name || '').slice(0, 60), lat: Number(c.lat) || 0, lon: Number(c.lon) || 0 }));
  if (typeof patch?.weatherWarned === 'string') allowed.weatherWarned = patch.weatherWarned.slice(0, 40);
  if (typeof patch?.notes === 'string') allowed.notes = patch.notes.slice(0, 20000);
  if (patch?.worldclocks && Array.isArray(patch.worldclocks)) allowed.worldclocks = patch.worldclocks.filter((x) => typeof x === 'string' && x.length < 40).slice(0, 8);
  if (patch?.weatherCity && typeof patch.weatherCity === 'object') allowed.weatherCity = { name: String(patch.weatherCity.name || '').slice(0, 60), lat: Number(patch.weatherCity.lat) || 0, lon: Number(patch.weatherCity.lon) || 0 };
  saveSettings(allowed);
  if ('dock' in allowed) hub.layout();
  if ('muteWinNotify' in allowed) applyWinSound();
  if ('autoclick' in allowed) autoclick.bindHotkey();
  if ('lang' in allowed) hub.applyLang();
  if ('autoStart' in allowed) applyAutoStart();
  if ('sounds' in allowed || 'soundVolume' in allowed || 'clickSound' in allowed) hub.pushAppearance();
  if (('wallpaper' in allowed || 'wallpaperIsland' in allowed) && settings.wallpaperIsland) await syncIslandWallpaper().catch(() => {});
  hub.pushState();
  return settings;
});
handle('profile:get', () => profileApi.get());
handle('profile:buy', ({ slot, id }) => profileApi.buy(slot, id));
handle('profile:equip', ({ slot, id }) => profileApi.equip(slot, id));
handle('profile:name', (name) => profileApi.setName(name));
handle('profile:image', (data) => profileApi.setImage(data));
handle('pc:info', (force) => require('./pcinfo').info(Boolean(force)));
handle('pc:live', () => require('./pcinfo').live());
handle('speed:wlan', () => require('./speedtest').wlanInfo());
// Starter / Kontrollzentrum offen → App-Ansicht kurz ausblenden
handle('overlay', (on) => {
  hub.overlay = Boolean(on);
  hub.layout();
  return hub.overlay;
});
const control = require('./control');
handle('cc:volume', (level) => (level == null ? control.getVolume() : control.setVolume(level)));
handle('cc:media', (key) => control.media(key));
handle('cc:brightness', (level) => (level == null ? control.getBrightness() : control.setBrightness(level)));
handle('cc:power', (mode) => (mode ? control.setPower(mode) : control.getPower()));
handle('cc:lock', () => control.lockPc());

/* Timer und Wecker: laufen sichtbar in der Island (sonst als normale Meldung) */
const hubTimers = new Map();
function islandTimer(seconds, name) {
  const secs = Math.max(1, Math.min(7 * 86400, Math.round(Number(seconds) || 0)));
  const label = String(name || 'Timer').replace(/[:\r\n]/g, ' ').slice(0, 40);
  if (orbit.running) orbit.post({ command: `timer:${secs}:${label}` });
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  // Fallback, falls die Island nicht läuft: der Hub meldet sich selbst
  const t = setTimeout(() => {
    hubTimers.delete(id);
    if (!orbit.running) hub.notify(`⏰ ${label}`, 'Die Zeit ist um.', { app: 'Revolution Hub', glyph: '⏰' });
  }, secs * 1000);
  hubTimers.set(id, { t, at: Date.now() + secs * 1000, label });
  return { id, at: Date.now() + secs * 1000, label };
}
handle('cc:timer', (seconds, name) => islandTimer(seconds, name));
handle('cc:alarm', (hhmm) => {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || ''));
  if (!m) throw new Error('Uhrzeit bitte als HH:MM eingeben.');
  const at = new Date();
  at.setHours(Number(m[1]), Number(m[2]), 0, 0);
  if (at <= new Date()) at.setDate(at.getDate() + 1);
  return islandTimer((at - Date.now()) / 1000, `Wecker ${m[1].padStart(2, '0')}:${m[2]}`);
});
handle('mix:list', async () => {
  const m = global.__revolutionHub?.mixer;
  if (!m) return { apps: [], error: 'Mixer nicht verfügbar' };
  try {
    return await m.list();
  } catch (error) {
    return { apps: [], error: String(error?.message || error) };
  }
});
handle('mix:app', (pid, volume, mute) => global.__revolutionHub?.mixer?.setApp(pid, volume == null ? -1 : Number(volume), mute == null ? -1 : mute ? 1 : 0));
handle('mix:master', (volume, mute) => global.__revolutionHub?.mixer?.setMaster(volume == null ? -1 : Number(volume), mute == null ? -1 : mute ? 1 : 0));
/* ---------------- Konto (Login + Sync von Profil, Punkten, Cosmetics und Schach) */
const { Account } = require('./account');
const chessProfileFile = () => path.join(hubData('chess'), 'profile.json');
const readChessProfile = () => {
  try {
    return JSON.parse(fs.readFileSync(chessProfileFile(), 'utf8'));
  } catch {
    return null;
  }
};
const account = new Account({
  getLocal: () => {
    let chessAt = 0;
    try {
      chessAt = fs.statSync(chessProfileFile()).mtimeMs;
    } catch {
      chessAt = 0;
    }
    return { profile: hubProfile(), chess: readChessProfile(), updatedAt: Math.max(Number(settings.profileAt) || 0, chessAt) };
  },
  applyRemote: (data, at) => {
    if (data?.profile && typeof data.profile === 'object') saveSettings({ profile: { ...hubProfile(), ...data.profile }, profileAt: at });
    if (data?.chess && typeof data.chess === 'object') {
      try {
        fs.mkdirSync(path.dirname(chessProfileFile()), { recursive: true });
        fs.writeFileSync(chessProfileFile(), JSON.stringify(data.chess));
        hub.views.get('chess')?.unload?.(); // lädt beim nächsten Öffnen mit dem neuen Stand
        hub.opened.delete('chess');
      } catch {
        /* egal */
      }
    }
    hub.pushProfile();
    hub.pushState();
  },
  onChange: (st) => {
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:account', st);
  },
});
account.markLocal = (at) => saveSettings({ profileAt: at });
function accountChanged() {
  account.changed();
}
// Schach speichert sein Profil selbst – Änderungen an der Datei ebenfalls hochladen
setInterval(() => {
  try {
    const m = fs.statSync(chessProfileFile()).mtimeMs;
    if (account.lastChess && m > account.lastChess) accountChanged();
    account.lastChess = m;
  } catch {
    /* noch kein Schach-Profil */
  }
}, 30000);
handle('acct:state', () => account.state());
handle('acct:login', (email, password, create) => account.login(email, password, Boolean(create)));
handle('acct:logout', () => account.logout());
handle('acct:sync', (mode) => account.sync(['push', 'pull'].includes(mode) ? mode : 'auto'));
handle('acct:reset', (email) => account.reset(email));
handle('acct:code', (code) => account.verifyCode(code));
handle('acct:cancel', () => account.cancelCode());
handle('acct:mfaStart', () => account.mfaStart());
handle('acct:mfaFinish', (code) => account.mfaFinish(code));
handle('acct:mfaRemove', () => account.mfaRemove());
handle('acct:verify', () => account.resendVerify());

/* ---------------- Schematics-Cloud (KELPI) */
const schematics = require('./schematics');
handle('schem:list', (force) => schematics.list(Boolean(force)));
handle('schem:detail', (id) => schematics.detail(String(id)));
handle('schem:icons', (ids) => schematics.icons(ids));
handle('schem:install', async (id, version) => {
  const r = await schematics.install(String(id), Number.isInteger(version) ? version : -1);
  hub.notify('Schematic installiert', `${r.file} liegt jetzt in ${r.count} Ordner(n).`, { app: 'Schematics', glyph: '🧱' });
  return r;
});
handle('schem:targets', () => schematics.targets('x.litematic').map((t) => t.label));
handle('schem:file', (id) => schematics.file(String(id)));
handle('schem:social', (id) => schematics.social(String(id), account));
handle('schem:rate', (id, stars) => schematics.rate(String(id), stars, account, hubProfile().name));
handle('schem:comment', (id, text) => schematics.comment(String(id), text, account, hubProfile().name));
handle('schem:uncomment', (docId) => schematics.uncomment(String(docId), account));

/* ---------------- Island-Status: zeigt dauerhaft, was im Hub gerade läuft */
let islandStatusLast = null;
function islandStatus() {
  const parts = [];
  try {
    const ac = autoclick.status();
    if (ac.running) parts.push(`🖱️ Autoclicker läuft${ac.clicks ? ` · ${ac.clicks.toLocaleString('de-DE')} Klicks` : ''}`);
  } catch {
    /* noch nicht bereit */
  }
  if (settings.gameMode) parts.push('🎮 Game-Modus');
  if (settings.keepAwake) parts.push('☕ PC bleibt wach');
  const next = [...hubTimers.values()].sort((a, b) => a.at - b.at)[0];
  if (next && !orbit.running) parts.push(`⏰ ${next.label}`);
  if (account.status.syncing) parts.push('☁️ Konto wird abgeglichen');
  const text = parts.join('  ·  ');
  if (text === islandStatusLast || !orbit.running) return;
  islandStatusLast = text;
  orbit.post({ command: `status:${text}` });
}
setInterval(islandStatus, 3000);

/* ---------------- PC wach halten */
let awakeId = null;
function applyAwake(on) {
  if (on && awakeId === null) awakeId = powerSaveBlocker.start('prevent-display-sleep');
  if (!on && awakeId !== null) {
    powerSaveBlocker.stop(awakeId);
    awakeId = null;
  }
  return Boolean(on);
}
handle('awake', (on, minutes) => {
  const v = Boolean(on);
  saveSettings({ keepAwake: v, keepAwakeUntil: v && minutes ? Date.now() + Number(minutes) * 60000 : 0 });
  applyAwake(v);
  hub.pushState();
  islandStatus();
  hub.notify(v ? 'PC bleibt wach' : 'PC darf wieder schlafen', v ? 'Bildschirm und PC gehen nicht in den Ruhezustand.' : 'Energiesparen ist wieder normal.', { app: 'Revolution Hub', glyph: '☕' });
  return v;
});
setInterval(() => {
  if (settings.keepAwake && settings.keepAwakeUntil && Date.now() > settings.keepAwakeUntil) {
    saveSettings({ keepAwake: false, keepAwakeUntil: 0 });
    applyAwake(false);
    hub.notify('PC darf wieder schlafen', 'Die Wach-Zeit ist abgelaufen.', { app: 'Revolution Hub', glyph: '☕' });
    hub.pushState();
  }
}, 30000);

/* ---------------- Windows-Ton bei Meldungen aus (die Island spielt ihren eigenen) */
const SOUND_KEY = 'HKCU\\AppEvents\\Schemes\\Apps\\.Default\\Notification.Default\\.Current';
function regRead() {
  try {
    const out = require('child_process').execFileSync('reg', ['query', SOUND_KEY, '/ve'], { windowsHide: true, encoding: 'utf8' });
    const m = /REG_(?:EXPAND_)?SZ\s+(.*)$/m.exec(out);
    return m ? m[1].trim() : '';
  } catch {
    return null;
  }
}
function regWrite(value) {
  try {
    require('child_process').execFileSync('reg', ['add', SOUND_KEY, '/ve', '/t', 'REG_SZ', '/d', value, '/f'], { windowsHide: true, stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}
function applyWinSound() {
  if (process.platform !== 'win32') return;
  const off = settings.muteWinNotify !== false;
  const cur = regRead();
  if (cur === null) return;
  if (off && cur) {
    saveSettings({ winSoundBackup: cur });
    regWrite('');
  } else if (!off && !cur && settings.winSoundBackup) regWrite(settings.winSoundBackup);
}

handle('cc:timers', () => [...hubTimers.entries()].map(([id, x]) => ({ id, at: x.at, label: x.label })).sort((a, b) => a.at - b.at));

/* Game-Modus: nur Crosshair, Clipper, Aufnahmen und Island laufen – alles andere wird entladen */
function applyGameMode(on) {
  if (on) {
    for (const [id, view] of hub.views) {
      if (id === 'gaming') continue;
      if (view.unload?.()) hub.opened.delete(id);
    }
    if (hub.active !== 'gaming' && hub.active !== 'home') hub.active = 'home';
  }
  hub.layout();
  hub.pushState();
}
handle('gamemode', (on) => {
  saveSettings({ gameMode: Boolean(on) });
  applyGameMode(Boolean(on));
  islandStatus();
  if (!on) hub.notify('Game-Modus aus', 'Alle Apps sind wieder verfügbar.', { app: 'Revolution Hub', glyph: '🎮' });
  if (on) hub.notify('Game-Modus an', 'Nur Crosshair, Clipper, Aufnahmen und die Island laufen – der Rest ist entladen.', { app: 'Revolution Hub', glyph: '🎮' });
  return Boolean(on);
});
/* Rechtsklick im Dock → App beenden */
handle('module:close', (id) => {
  const view = hub.views.get(id);
  if (!view || id === 'gaming') return false;
  const ok = view.unload();
  hub.opened.delete(id);
  if (hub.active === id) hub.active = 'home';
  hub.layout();
  hub.pushState();
  return ok;
});
handle('cc:screenshot', () => control.screenshot());
handle('tool:fetch', (url) => control.toolFetch(url));
handle('clickClip', () => clickClip());

/* Autoclicker und Schutz (Tracker-Karte, Virenscan) */
const { AutoClicker, clean: cleanAutoclick } = require('./autoclick');
const { Shield } = require('./shield');
let autoclickWasRunning = false;
const autoclick = new AutoClicker({
  getConfig: () => settings.autoclick || {},
  onChange: (status) => {
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:autoclick', status);
    if (status.running !== autoclickWasRunning) {
      autoclickWasRunning = status.running;
      hub.notify(status.running ? 'Autoclicker gestartet' : 'Autoclicker gestoppt', status.running ? `Stopp mit ${status.hotkey || 'dem Hotkey'}.` : `${status.clicks.toLocaleString('de-DE')} Klicks · ${status.presses.toLocaleString('de-DE')} Tastendrücke`, { app: 'Autoclicker', glyph: '🖱️' });
    }
    islandStatus();
  },
});
const shield = new Shield({ notify: (title, body) => hub.notify(title, body, { app: 'Schutz', accent: '#f87171', glyph: '🛡️' }), getSettings: () => settings.shield || {} });
/* Updates über das Internet (Adresse in den Optionen) */
const { Updater, httpsUrl } = require('./updater');
// Offizielle Update-Adresse (GitHub). In den Optionen lässt sie sich überschreiben.
const DEFAULT_UPDATE_URL = (() => {
  try {
    return require('./update-source.json').url || '';
  } catch {
    return '';
  }
})();
const updater = new Updater({
  getUrl: () => DEFAULT_UPDATE_URL, // fest: unser GitHub-Update-Server
  onProgress: (p) => {
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:update', p);
  },
});
let updateFound = null;
async function checkForUpdate(manual = false) {
  const r = await updater.check();
  if (r.ok && r.available) {
    updateFound = { version: r.version, notes: r.notes || '', dismissed: settings.updateDismissed === r.version };
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:update-available', updateFound);
  } else if (manual) updateFound = null;
  return r;
}
handle('update:check', () => checkForUpdate(true));
handle('update:pending', () => updateFound);
handle('update:dismiss', (version) => {
  saveSettings({ updateDismissed: String(version || '') });
  if (updateFound) updateFound.dismissed = true;
  return true;
});
handle('update:install', () => updater.install());
handle('ac:status', () => autoclick.status());
handle('ac:start', () => autoclick.start());
handle('ac:stop', () => autoclick.stop());
handle('ac:pick', (ms) => autoclick.pickPosition(ms));
handle('shield:trackers', () => shield.trackers({ quiet: true }));
handle('shield:last', () => shield.last);
handle('shield:defender', () => shield.defender());
handle('shield:update', () => shield.updateSignatures());
handle('shield:scan', async (kind) => {
  if (kind === 'quick') return shield.scan('quick');
  const picked = await electron.dialog.showOpenDialog(hub.window, { title: kind === 'folder' ? 'Ordner prüfen' : 'Datei prüfen', properties: [kind === 'folder' ? 'openDirectory' : 'openFile'] });
  if (picked.canceled || !picked.filePaths[0]) return null;
  return shield.scan('path', picked.filePaths[0]);
});
handle('tool:clipboard', (action, value) => control.clipboardApi(action, value));
handle('tool:notify', (title, body) => {
  hub.notify(String(title).slice(0, 60), String(body || '').slice(0, 140), { app: 'Revolution Hub' });
  return true;
});
handle('speed:history', () => settings.speedHistory || []);
handle('speed:run', async () => {
  const send = (p) => hub.window && !hub.window.isDestroyed() && hub.window.webContents.send('hub:speed', p);
  const r = await require('./speedtest').run(send);
  saveSettings({ speedHistory: [{ at: r.at, down: r.down, up: r.up, ping: r.ping }, ...(settings.speedHistory || [])].slice(0, 10) });
  hub.notify(`WLAN-Test: ${String(r.down).replace('.', ',')} MBit/s`, `↑ ${String(r.up).replace('.', ',')} MBit/s · Ping ${r.ping} ms · ${r.grade || ''}`, { app: 'WLAN-Test', glyph: '📶' });
  return r;
});
handle('music:get', () => global.__revolutionHub.music?.get() || null);
handle('music:set', (patch) => global.__revolutionHub.music?.set(patch) || null);
handle('music:demo', () => global.__revolutionHub.music?.demo() || null);
handle('orbit:start', () => applyIslandMonitor().catch(() => {}).then(() => orbit.start()).then(() => hub.pushState()));
handle('orbit:stop', () => orbit.stop().then(() => hub.pushState()));
/** Angeschlossene Monitore mit ihrem Windows-Gerätenamen (so erwartet ihn die Island). */
let monitorNames = null;
function monitorDevices() {
  if (monitorNames) return Promise.resolve(monitorNames);
  return new Promise((resolve) => {
    require('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::AllScreens | ForEach-Object { '{0}|{1}|{2}|{3}x{4}' -f $_.DeviceName, $_.Primary, $_.Bounds.X, $_.Bounds.Width, $_.Bounds.Height }"], { windowsHide: true, timeout: 8000 }, (error, stdout) => {
      const rows = error ? [] : String(stdout).trim().split(/\r?\n/).map((l) => l.trim().split('|')).filter((p) => p.length >= 4);
      monitorNames = rows.sort((a, b) => Number(a[2]) - Number(b[2])).map((p, i) => ({ name: p[0], primary: p[1] === 'True', text: `Monitor ${i + 1} · ${p[3].replace('x', '×')}${p[1] === 'True' ? ' · Hauptmonitor' : ''}` }));
      setTimeout(() => (monitorNames = null), 15000);
      resolve(monitorNames);
    });
  });
}
handle('orbit:settings', async () => {
  const current = orbit.readSettings();
  return { ...current, defaults: orbit.defaults(), wallpapers: orbit.wallpapers(), running: orbit.running, monitors: await monitorDevices().catch(() => []) };
});
/**
 * Island sitzt von selbst auf dem zweiten Bildschirm (das Crosshair bleibt auf dem Hauptbildschirm).
 * Sobald du in den Island-Einstellungen selbst einen Monitor wählst, gilt deine Wahl.
 */
async function applyIslandMonitor() {
  if (settings.islandMonitorAuto === false) return;
  const mons = await monitorDevices().catch(() => []);
  if (!mons.length) return;
  const second = mons.find((m) => !m.primary);
  const want = second ? second.name : '';
  const cur = orbit.readSettings().settings?.Position?.MonitorId || '';
  if (cur !== want) await orbit.writeSettings({ Position: { MonitorId: want } });
}
handle('orbit:save', async (patch) => {
  const chosen = patch?.Position?.MonitorId;
  if (chosen === '__auto__') {
    saveSettings({ islandMonitorAuto: true });
    delete patch.Position.MonitorId;
    await orbit.writeSettings(patch);
    return applyIslandMonitor();
  }
  if (typeof chosen === 'string') saveSettings({ islandMonitorAuto: false });
  return orbit.writeSettings(patch);
});
handle('orbit:native', () => orbit.openNativeSettings());
handle('orbit:command', (name) => (['face', 'newevent', 'settings'].includes(name) ? orbit.command(name) : false));
handle('openData', (id) => {
  const dir = id === 'hub' ? app.getPath('userData') : id === 'orbit' ? path.dirname(orbit.settingsFile()) : moduleById(id)?.dataDir;
  if (dir) {
    fs.mkdirSync(dir, { recursive: true });
    shell.openPath(dir);
  }
});
handle('external', (url) => {
  if (/^https:\/\//.test(url)) shell.openExternal(url);
});

/** "Auch für Orbit Island": the island plays the same live wallpaper as the hub. */
async function syncIslandWallpaper() {
  const current = orbit.readSettings();
  const base = current.settings || { ...orbit.defaults().settings, FirstRun: false };
  const file = settings.wallpaper === 'none' ? '' : orbit.wallpaperPath(settings.wallpaper);
  if ((base.Appearance?.WallpaperFile || '') === file) return;
  await orbit.writeSettings({ Appearance: { WallpaperFile: file, Wallpaper: file ? base.Appearance?.Wallpaper || 'Nebula' : 'Off' } });
}

/* ----------------------------------------------------------------- lifecycle */

app.on('second-instance', (_event, argv) => {
  if (argv.includes('--hidden')) return;
  // z. B. aus der Island: "Revolution Hub.exe --open=settings"
  const page = argv.find((a) => a.startsWith('--open='))?.slice(7);
  hub.open(page && PAGES.has(page) ? page : hub.active);
});

// The hub's ready handler is registered before the modules load, so the hub window
// exists by the time each module creates its main view.
app.whenReady().then(() => {
  control.startClipboard();
  // Benachrichtigungstöne für die Island (Auswahl in den Island-Einstellungen)
  try {
    const dir = path.join(process.env.APPDATA || app.getPath('appData'), 'PulseIsland', 'sounds');
    fs.mkdirSync(dir, { recursive: true });
    for (const f of ['chime-a.wav', 'chime-b.wav']) {
      const from = path.join(__dirname, '..', 'shared', 'assets', f);
      const to = path.join(dir, f);
      if (fs.existsSync(from) && (!fs.existsSync(to) || fs.statSync(to).size !== fs.statSync(from).size)) fs.copyFileSync(from, to);
    }
  } catch {
    /* ohne eigene Töne spielt die Island ihren Standardton */
  }
  if (settings.gameMode) setTimeout(() => applyGameMode(true), 1500);
  if (settings.keepAwake) applyAwake(true);
  applyWinSound();
  setTimeout(() => account.restore(), 3000);
  autoclick.bindHotkey();
  shield.watch();
  try {
    electron.globalShortcut.register('CommandOrControl+Shift+M', () => {
      hub.showWindow();
      hub.window?.webContents.send('hub:open-control', 'mixer');
    });
  } catch {
    /* Tastenkürzel belegt */
  }
  // Einmal kurz nach dem Start nach Updates sehen (wenn eine Adresse eingetragen ist)
  // Automatisch nach Updates suchen: kurz nach dem Start und dann alle 4 Stunden
  const autoCheck = () => {
    if (settings.updateAuto === false || !DEFAULT_UPDATE_URL) return;
    checkForUpdate().then((r) => {
      if (r.ok && r.available && settings.updateNotified !== r.version) {
        saveSettings({ updateNotified: r.version });
        hub.notify(`Update ${r.version} ist da`, 'Unten im Hub: „Aktualisieren“ spielt es mit einem Klick ein.', { app: 'Revolution Hub', glyph: '⬆️' });
      }
    }).catch(() => {});
  };
  setTimeout(autoCheck, 12000);
  setInterval(autoCheck, 4 * 60 * 60 * 1000);
  Menu.setApplicationMenu(null);
  hub.active = settings.startPage === 'last' && PAGES.has(settings.lastPage) ? settings.lastPage : 'home';
  if (hub.active === 'settings' || hub.active === 'orbit') hub.active = 'home';
  hub.opened.add(hub.active);
  // Was beim letzten Mal offen war, ist wieder da (z. B. die laufende Schachpartie)
  for (const id of Array.isArray(settings.openedPages) ? settings.openedPages : []) if (PAGES.has(id) && moduleById(id)) hub.opened.add(id);
  createWindow();
  createTray();
  applyAutoStart();
  // Alte Einzel-Apps (Island, Gaming Hub, Dropzone) dürfen nicht parallel laufen –
  // alles kommt aus dem Hub.
  orbit
    .takeOver()
    .catch(() => {})
    .then(() => {
      orbit.autoReplace = true;
      orbit.watch();
      orbit.watchCamera((active) => {
        const view = hub.views.get('gaming');
        if (view && !view.webContents.isDestroyed()) view.webContents.executeJavaScript(`window.__revCamPause && window.__revCamPause(${active})`, true).catch(() => {});
      });
      if (settings.orbitWithHub && orbit.available()) applyIslandMonitor().catch(() => {}).then(() => orbit.start()).catch(() => {});
    });
});

for (const mod of MODULES) {
  try {
    require(path.join(mod.dir, mod.entry));
  } catch (error) {
    mod.error = error?.message || String(error);
    console.error(`[hub] module ${mod.id} failed to load`, error);
  }
}

protocol.registerSchemesAsPrivileged(privilegedSchemes);

app.on('before-quit', () => {
  hub.quitting = true;
  autoclick.shutdown();
  shield.shutdown();
  orbit.shutdown();
});

app.on('window-all-closed', () => {
  if (hub.quitting) app.quit();
});
