'use strict';

/*
 * Schematics-Cloud (KELPI): liest die Schematics der Website und legt eine Datei auf Wunsch
 * automatisch in alle Schematics-Ordner (Litematica, WorldEdit, Revolution-Launcher,
 * Prism/MultiMC, CurseForge, Modrinth).
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const fb = require('./firebase');

let index = null;
let indexAt = 0;

async function list(force = false) {
  if (index && !force && Date.now() - indexAt < 5 * 60 * 1000) return index;
  const doc = await fb.getDoc('settings/sch_index');
  const items = Array.isArray(doc?.items) ? doc.items : [];
  index = items
    .filter((x) => x && x.id && x.name)
    .map((x) => ({
      id: String(x.id),
      name: String(x.name).slice(0, 120),
      desc: String(x.desc || '').slice(0, 600),
      tags: Array.isArray(x.tags) ? x.tags.slice(0, 12).map(String) : [],
      cat: String(x.cat || ''),
      downloads: Number(x.downloads) || 0,
      likes: Number(x.likes) || 0,
      rating: x.ratingCount ? Math.round((x.ratingSum / x.ratingCount) * 10) / 10 : 0,
      ratingSum: Number(x.ratingSum) || 0,
      ratingCount: Number(x.ratingCount) || 0,
      fileName: String(x.fileName || ''),
      icon: /^https:\/\//.test(String(x.icon || '')) ? String(x.icon) : '',
      hasImg: Boolean(x.hasImg),
      by: String(x.byName || ''),
      ts: Number(x.ts) || 0,
    }));
  indexAt = Date.now();
  return index;
}

/** Details mit Vorschaubild(ern). Bilder können Daten-URLs oder https-Adressen sein. */
/** Vorschaubilder für die Kacheln (nur das Feld „icon“ – nicht die ganze Datei). */
const iconCache = new Map();
async function icons(ids) {
  const out = {};
  await Promise.all(
    (Array.isArray(ids) ? ids : []).slice(0, 30).map(async (id) => {
      id = String(id);
      if (!iconCache.has(id)) {
        try {
          const d = await fb.getDoc(`schematics/${encodeURIComponent(id)}`, null, ['icon', 'images']);
          const pic = [d?.icon, ...(Array.isArray(d?.images) ? d.images : [])].find((v) => typeof v === 'string' && (v.startsWith('https://') || (v.startsWith('data:image/') && v.length < 1_500_000)));
          iconCache.set(id, pic || '');
        } catch {
          iconCache.set(id, '');
        }
      }
      out[id] = iconCache.get(id);
    }),
  );
  return out;
}

async function detail(id) {
  const d = await fb.getDoc(`schematics/${encodeURIComponent(id)}`, null, ['icon', 'images', 'fileName']);
  if (!d) throw new Error('Schematic nicht gefunden');
  const pic = (v) => (typeof v === 'string' && (v.startsWith('https://') || (v.startsWith('data:image/') && v.length < 3_000_000)) ? v : '');
  return {
    id,
    images: (Array.isArray(d.images) ? d.images : []).map(pic).filter(Boolean).slice(0, 6),
    icon: pic(d.icon),
    versions: [],
    fileName: String(d.fileName || ''),
  };
}

/** Datei holen: direkt im Dokument, in Teilen (lit_files) oder über eine Adresse. */
async function fileBytes(id, version = -1) {
  const d = await fb.getDoc(`schematics/${encodeURIComponent(id)}`);
  if (!d) throw new Error('Schematic nicht gefunden');
  const src = version >= 0 && Array.isArray(d.versions) && d.versions[version] ? d.versions[version] : d;
  const fromData = (s) => Buffer.from(String(s).replace(/^data:[^,]*,/, ''), 'base64');
  if (typeof src.fileData === 'string' && src.fileData.length > 30) return { bytes: fromData(src.fileData), name: src.fileName || d.fileName };
  if (src.litFileId) {
    const head = await fb.getDoc(`lit_files/${encodeURIComponent(src.litFileId)}`);
    if (!head) throw new Error('Datei fehlt in der Cloud');
    let b64 = '';
    for (let i = 0; i < (Number(head.n) || 0); i += 1) {
      const part = await fb.getDoc(`lit_files/${encodeURIComponent(src.litFileId)}/parts/${i}`);
      b64 += part?.d || '';
    }
    return { bytes: Buffer.from(b64, 'base64'), name: src.fileName || head.name || d.fileName };
  }
  if (typeof src.fileUrl === 'string' && src.fileUrl.startsWith('https://')) {
    const { net } = require('electron');
    const res = await net.fetch(src.fileUrl);
    if (!res.ok) throw new Error('Download fehlgeschlagen');
    return { bytes: Buffer.from(await res.arrayBuffer()), name: src.fileName || d.fileName };
  }
  throw new Error('Für dieses Schematic gibt es keine Datei');
}

const safeName = (n, id) => {
  let name = String(n || `${id}.litematic`).replace(/[\\/:*?"<>|]+/g, '_').replace(/^\.+/, '').slice(0, 120);
  if (!/\.(litematic|schem|schematic|nbt|mcstructure)$/i.test(name)) name += '.litematic';
  return name;
};
const isDir = (p) => {
  try {
    return fs.statSync(p).isDirectory();
  } catch {
    return false;
  }
};
const subdirs = (p) => {
  try {
    return fs.readdirSync(p, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => path.join(p, d.name));
  } catch {
    return [];
  }
};

/** Alle Minecraft-Installationen finden, die einen Schematics-Ordner haben (oder brauchen). */
function gameDirs() {
  const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const home = os.homedir();
  const out = [];
  const add = (dir, label) => {
    if (isDir(dir) && !out.some((x) => x.dir.toLowerCase() === dir.toLowerCase())) out.push({ dir, label });
  };
  add(path.join(appData, '.minecraft'), 'Minecraft');
  for (const inst of subdirs(path.join(appData, 'Revolution', 'instances'))) add(inst, `Revolution · ${path.basename(inst)}`);
  for (const root of [path.join(appData, 'PrismLauncher', 'instances'), path.join(appData, 'MultiMC', 'instances'), path.join(home, 'MultiMC', 'instances')])
    for (const inst of subdirs(root)) add(isDir(path.join(inst, '.minecraft')) ? path.join(inst, '.minecraft') : path.join(inst, 'minecraft'), `Prism/MultiMC · ${path.basename(inst)}`);
  for (const inst of subdirs(path.join(home, 'curseforge', 'minecraft', 'Instances'))) add(inst, `CurseForge · ${path.basename(inst)}`);
  for (const inst of subdirs(path.join(appData, 'ModrinthApp', 'profiles'))) add(inst, `Modrinth · ${path.basename(inst)}`);
  for (const inst of subdirs(path.join(appData, '.feather', 'user-mods'))) add(inst, `Feather · ${path.basename(inst)}`);
  return out;
}
/** Zielordner für eine Datei: Litematica-„schematics“ und bei .schem auch WorldEdit. */
function targets(fileName) {
  const schem = /\.(schem|schematic)$/i.test(fileName);
  const out = [];
  for (const g of gameDirs()) {
    out.push({ dir: path.join(g.dir, 'schematics'), label: `${g.label} · schematics` });
    const we = path.join(g.dir, 'config', 'worldedit', 'schematics');
    if (schem || isDir(we)) out.push({ dir: we, label: `${g.label} · WorldEdit` });
  }
  return out;
}

async function install(id, version = -1) {
  const { bytes, name } = await fileBytes(id, version);
  if (!bytes.length) throw new Error('Die Datei ist leer');
  const file = safeName(name, id);
  const done = [];
  for (const t of targets(file)) {
    try {
      fs.mkdirSync(t.dir, { recursive: true });
      fs.writeFileSync(path.join(t.dir, file), bytes);
      done.push(t.label);
    } catch {
      /* Ordner gesperrt – nächster */
    }
  }
  return { file, count: done.length, places: done, size: bytes.length };
}

/** Datei für die 3D-Vorschau (kurz zwischengespeichert). */
const fileCache = new Map();
async function file(id) {
  if (!fileCache.has(id)) {
    const r = await fileBytes(id);
    fileCache.set(id, r);
    if (fileCache.size > 6) fileCache.delete(fileCache.keys().next().value);
  }
  const { bytes, name } = fileCache.get(id);
  return { name: safeName(name, id), data: new Uint8Array(bytes) };
}

/* ---------------- Bewertungen und Kommentare
 * Bestehende Werte der KELPI-Website werden angezeigt; neue Bewertungen und Kommentare aus dem Hub
 * landen im Revolution-Projekt (schem_ratings, schem_comments) mit dem Revolution-Konto. */
async function social(id, acct) {
  const s = (index || []).find((x) => x.id === id) || {};
  let kelpiComments = [];
  try {
    kelpiComments = (await fb.kelpi.query('sch_comments', 'schId', id)).map((c) => ({ id: `k:${c.id}`, name: String(c.name || 'KELPI'), text: String(c.text || '').slice(0, 1000), at: Number(c.at) || 0, src: 'KELPI' }));
  } catch {
    kelpiComments = [];
  }
  let hubComments = [], ratings = [];
  try {
    const c = acct.client();
    hubComments = (await c.query('schem_comments', 'schId', id)).map((x) => ({ id: x.id, uid: x.uid, name: String(x.name || 'Spieler'), text: String(x.text || '').slice(0, 1000), at: Number(x.at) || 0, src: 'Hub' }));
    ratings = await c.query('schem_ratings', 'schId', id);
  } catch {
    /* Regeln fehlen oder offline */
  }
  const uid = acct.status.uid;
  const sum = (s.ratingSum || 0) + ratings.reduce((a, r) => a + (Number(r.rating) || 0), 0);
  const count = (s.ratingCount || 0) + ratings.length;
  return {
    avg: count ? Math.round((sum / count) * 10) / 10 : 0,
    count,
    mine: Number(ratings.find((r) => r.uid === uid)?.rating) || 0,
    comments: [...hubComments.map((c) => ({ ...c, mine: Boolean(uid) && c.uid === uid })), ...kelpiComments].sort((a, b) => b.at - a.at),
    signedIn: Boolean(acct.status.signedIn),
  };
}
async function rate(id, stars, acct, name) {
  const n = Math.round(Number(stars));
  if (!(n >= 1 && n <= 5)) throw new Error('Bewertung 1 bis 5 Sterne');
  if (!acct.status.signedIn) throw new Error('Melde dich unter Konto an, um zu bewerten.');
  const uid = acct.status.uid;
  await acct.client().setDoc(`schem_ratings/${encodeURIComponent(`${id}__${uid}`)}`, { schId: id, uid, rating: n, name: String(name || ''), at: Date.now() }, await acct.token());
  return true;
}
async function comment(id, text, acct, name) {
  const t = String(text || '').trim().slice(0, 500);
  if (t.length < 2) throw new Error('Der Kommentar ist zu kurz.');
  if (!acct.status.signedIn) throw new Error('Melde dich unter Konto an, um zu kommentieren.');
  await acct.client().addDoc('schem_comments', { schId: id, uid: acct.status.uid, name: String(name || acct.status.email.split('@')[0]).slice(0, 24), text: t, at: Date.now() }, await acct.token());
  return true;
}
async function uncomment(docId, acct) {
  if (!acct.status.signedIn) throw new Error('Nicht angemeldet');
  await acct.client().delDoc(`schem_comments/${encodeURIComponent(docId)}`, await acct.token());
  return true;
}

module.exports = { list, detail, icons, install, gameDirs, targets, file, social, rate, comment, uncomment };
