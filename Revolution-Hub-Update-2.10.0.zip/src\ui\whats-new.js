'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.10.0',
  title: 'Revolution Hub 2.10',
  sub: 'Klick auf einen Eintrag – du landest direkt dort. Oben links kommst du jederzeit hierher zurück.',
  items: [
    { open: 'chats', icon: 'chats', title: 'Chats wie Discord', text: 'Server-Leiste, Direktnachrichten, Mitgliederliste, Emojis, Bilder senden und eigene Chat-Einstellungen.' },
    { open: 'chats', icon: 'chats', title: 'Gegner anschreiben & Freunde', text: 'In Schach und Geo: „Nachricht“ oder „Freund hinzufügen“ direkt beim Gegner. In den Chat-Einstellungen abschaltbar.' },
    { open: 'chats', icon: 'chats', title: 'Roter Punkt am App-Symbol', text: 'Ungelesene Nachrichten zeigt der Hub wie bei Apple – im Dock und in der Windows-Taskleiste. Neue Nachrichten kommen in die Island.' },
    { open: 'geo', icon: 'geo', title: 'Team-Duell 2v2', text: 'Zwei gegen zwei in GeoRevolution. Der beste Tipp jedes Teams zählt.' },
    { open: 'chess', icon: 'chess', title: 'Coach mit Stimme', text: 'Der Schach-Coach spricht, hat ein Gesicht und zeigt dir mit Animationen, welcher Zug besser gewesen wäre – und warum.' },
    { open: 'chess', icon: 'chess', title: 'Fair Play online', text: 'Verlässt dein Gegner die Partie, gewinnst du. Wer geht, verliert Elo.' },
    { open: 'tool-schematics', icon: 'tool-schematics', title: 'Schematics in 3D', text: 'Jedes Schematic in 3D drehen, Ebene für Ebene ansehen, Materialliste, Sterne und Kommentare.' },
    { open: 'tool-account', icon: 'tool-account', title: 'Konto mit 2FA', text: 'Anmelden repariert, Passwort bestätigen beim Erstellen, Zwei-Faktor-Anmeldung mit Authenticator-App.' },
    { open: 'gaming', icon: 'gaming', title: 'Ruhigere Overlays', text: 'Separater Player, Truhen-Widget und Leistungs-Widget sind jetzt standardmäßig aus – einschalten im Gaming Hub.' },
    { open: 'settings', icon: 'settings', title: 'Updates automatisch', text: 'Der Hub sucht selbst nach neuen Versionen. Unten erscheint „Aktualisieren“ – ein Klick genügt.' },
  ],
};
