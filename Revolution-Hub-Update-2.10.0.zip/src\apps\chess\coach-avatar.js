'use strict';
/*
 * Der Coach als Charakter: Gesicht mit Augen und Mund, spricht mit der Windows-Stimme
 * (Web Speech, offline) und bewegt dabei den Mund. Stimmung je nach Zug (froh, besorgt, nachdenklich).
 */
(function () {
  const svg = `<svg viewBox="0 0 120 120" class="ca-svg" aria-hidden="true">
    <defs>
      <radialGradient id="ca-skin" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#ffe2c4"/><stop offset="1" stop-color="#f1b98e"/></radialGradient>
      <linearGradient id="ca-hat" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9b7bff"/><stop offset="1" stop-color="#5b3df0"/></linearGradient>
    </defs>
    <ellipse cx="60" cy="112" rx="34" ry="6" fill="rgba(0,0,0,.25)"/>
    <path d="M26 112c2-18 16-28 34-28s32 10 34 28Z" fill="#2d2a44"/>
    <path d="M50 86l10 12 10-12" fill="#fff" opacity=".9"/>
    <circle cx="60" cy="56" r="34" fill="url(#ca-skin)"/>
    <ellipse cx="27" cy="58" rx="5" ry="8" fill="#f1b98e"/><ellipse cx="93" cy="58" rx="5" ry="8" fill="#f1b98e"/>
    <path class="ca-hat" d="M24 46c2-22 18-32 36-32s34 10 36 32c-10-6-22-9-36-9s-26 3-36 9Z" fill="url(#ca-hat)"/>
    <path d="M60 14l6-10 6 10" fill="#ffd166" class="ca-crown"/>
    <g class="ca-brows"><path class="ca-brow l" d="M38 42q8-5 15 0"/><path class="ca-brow r" d="M67 42q7-5 15 0"/></g>
    <g class="ca-eyes"><ellipse class="ca-eye" cx="46" cy="54" rx="5" ry="6"/><ellipse class="ca-eye" cx="74" cy="54" rx="5" ry="6"/>
      <circle cx="47.5" cy="52" r="1.6" fill="#fff"/><circle cx="75.5" cy="52" r="1.6" fill="#fff"/></g>
    <g class="ca-glasses"><circle cx="46" cy="54" r="10"/><circle cx="74" cy="54" r="10"/><path d="M56 54h8"/></g>
    <ellipse cx="36" cy="68" rx="6" ry="3.5" fill="#ff8f8f" opacity=".35"/><ellipse cx="84" cy="68" rx="6" ry="3.5" fill="#ff8f8f" opacity=".35"/>
    <path class="ca-mouth" d="M48 72q12 8 24 0"/>
  </svg>`;
  const MOUTH = {
    smile: 'M48 72q12 9 24 0',
    flat: 'M50 74q10 1 20 0',
    worried: 'M50 77q10-6 20 0',
    o: 'M54 72q6-6 12 0q-6 9-12 0Z',
    open: 'M48 70q12-2 24 0q-12 14-24 0Z',
    half: 'M49 71q11 0 22 0q-11 8-22 0Z',
    wide: 'M46 70q14-3 28 0q-14 12-28 0Z',
  };
  const MOODS = { brilliant: 'happy', great: 'happy', best: 'happy', excellent: 'happy', good: 'happy', book: 'happy', inaccuracy: 'think', mistake: 'worried', miss: 'worried', blunder: 'worried', think: 'think' };

  let el = null, mouth = null, mood = 'happy', talking = null, lastText = '', voice = null;
  const pickVoice = (lang) => {
    const vs = window.speechSynthesis?.getVoices() || [];
    return vs.find((v) => v.lang?.toLowerCase().startsWith(lang) && /natural|online/i.test(v.name)) || vs.find((v) => v.lang?.toLowerCase().startsWith(lang)) || null;
  };
  window.speechSynthesis?.addEventListener?.('voiceschanged', () => (voice = null));

  function rest() {
    if (mouth) mouth.setAttribute('d', mood === 'worried' ? MOUTH.worried : mood === 'think' ? MOUTH.flat : MOUTH.smile);
  }
  function setMood(m) {
    mood = m || 'happy';
    if (el) el.dataset.mood = mood;
    if (!talking) rest();
  }
  function stopTalking() {
    clearInterval(talking);
    talking = null;
    el?.classList.remove('talking');
    rest();
  }
  function startTalking() {
    clearInterval(talking);
    el?.classList.add('talking');
    const shapes = [MOUTH.half, MOUTH.open, MOUTH.o, MOUTH.wide, MOUTH.half, MOUTH.flat];
    talking = setInterval(() => mouth?.setAttribute('d', shapes[Math.floor(Math.random() * shapes.length)]), 95);
  }
  const clean = (html) => {
    const d = document.createElement('div');
    d.innerHTML = String(html || '');
    d.querySelectorAll('button').forEach((b) => b.remove());
    return d.textContent.replace(/\s+/g, ' ').replace(/[♔-♟◆★✓✗⏱]/g, '').trim();
  };
  // Schachnotation vorlesbar machen: Sf3 → Springer f3, exd5 → e schlägt d5
  const speakable = (t, lang) => {
    if (lang !== 'de') return t;
    const P = { K: 'König', D: 'Dame', T: 'Turm', L: 'Läufer', S: 'Springer' };
    return t
      .replace(/\b([KDTLS])([a-h]?[1-8]?)x([a-h][1-8])[+#]?/g, (_, p, _d, sq) => `${P[p]} schlägt ${sq}`)
      .replace(/\b([KDTLS])[a-h]?[1-8]?([a-h][1-8])[+#]?/g, (_, p, sq) => `${P[p]} ${sq}`)
      .replace(/\b([a-h])x([a-h][1-8])[+#]?/g, '$1 schlägt $2')
      .replace(/\bO-O-O\b/g, 'lange Rochade')
      .replace(/\bO-O\b/g, 'kurze Rochade');
  };

  window.CoachAvatar = {
    mount(host) {
      if (!host) return;
      host.innerHTML = svg;
      el = host;
      el.classList.add('coach-avatar');
      mouth = host.querySelector('.ca-mouth');
      setMood('happy');
      // Blinzeln
      setInterval(() => {
        el?.classList.add('blink');
        setTimeout(() => el?.classList.remove('blink'), 140);
      }, 3800 + Math.random() * 1500);
    },
    mood: setMood,
    moodFor: (cls) => MOODS[cls] || 'happy',
    /** Spricht den Text (HTML erlaubt). on = Stimme an, sonst nur Mundbewegung. */
    say(html, { on = true, lang = 'de', cls = '' } = {}) {
      const text = clean(html);
      if (cls) setMood(MOODS[cls] || 'happy');
      if (!text || text === lastText) return Promise.resolve();
      lastText = text;
      const synth = window.speechSynthesis;
      if (!on || !synth) {
        startTalking();
        clearTimeout(this.t);
        this.t = setTimeout(stopTalking, Math.min(4000, 300 + text.length * 45));
        return Promise.resolve();
      }
      synth.cancel();
      return new Promise((resolve) => {
        const u = new SpeechSynthesisUtterance(speakable(text, lang).slice(0, 400));
        voice = voice || pickVoice(lang);
        if (voice) u.voice = voice;
        u.lang = { de: 'de-DE', en: 'en-US', es: 'es-ES' }[lang] || 'de-DE';
        u.rate = 1.04;
        u.pitch = 1.05;
        u.onstart = startTalking;
        const done = () => {
          stopTalking();
          resolve();
        };
        u.onend = done;
        u.onerror = done;
        synth.speak(u);
        // Sicherheitsnetz, falls Windows kein Ende meldet
        setTimeout(done, 1500 + text.length * 90);
      });
    },
    quiet() {
      window.speechSynthesis?.cancel();
      stopTalking();
      lastText = '';
    },
  };
})();
