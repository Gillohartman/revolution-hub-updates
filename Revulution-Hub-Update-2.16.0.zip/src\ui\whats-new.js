'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.16.0',
  title: 'Revulution Hub 2.16.0',
  sub: 'Klick auf einen Eintrag – du landest direkt dort. Oben links kommst du jederzeit hierher zurück.',
  items: [
    { open: 'tool-keyboard', icon: 'keyboard', title: 'PC-RGB jetzt direkt', text: 'Mainboard-LEDs werden ohne OpenRGB und ohne Download direkt über den ASRock-Controller angesteuert. Die Effekte laufen im Controller und setzen nicht mehr nach zwei Minuten aus.' },
    { open: 'tool-keyboard', icon: 'keyboard', title: 'GIFs & Tastatur-Vorschau', text: 'GIFs bleiben als animierte Vorschau im Display-Fenster und werden nicht mehr von Uhr oder Nachrichten verdrängt. Unter den RGB-Effekten zeigt eine Tastatur den Effekt direkt.' },
    { open: 'beat', icon: 'music', title: 'Beat Lab: mehr drin', text: 'Jetzt mit 12 Drum-Spuren, 8 Kits, Groove-Generator für House, Trap, Break und Fill, Oktav-Transpose und vier FX-Presets. Der Mixer hat mittige M-Tasten.' },
    { open: 'chats', icon: 'chat', title: 'Wählton beim Anrufen', text: 'Beim Wählen klingelt es jetzt auf beiden Seiten – der Ton stoppt automatisch beim Annehmen, Ablehnen oder Auflegen.' },
    { open: 'chess', icon: 'chess', title: 'Schach-Ergebnis neu', text: 'Das „Lektion nicht geschafft“-Fenster hat ein neues Design, klare Statistiken und einen direkten Lobby-Button.' },
  ],
};
