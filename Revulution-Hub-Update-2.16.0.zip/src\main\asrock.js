'use strict';

/*
 * Direkte ASRock-Polychrome-USB-Steuerung (VID 26CE / PID 01A2) über HID.
 * Kein OpenRGB-Download und kein Hintergrundprogramm: Der Hub spricht den
 * LED-Controller direkt an und lässt die Effekte im Controller laufen.
 */
const path = require('path');
const { spawn } = require('child_process');
const { EFFECTS } = require('./openrgb');

const MODES = [
  { id: 0, name: 'Statisch', code: 1, speed: false, color: true },
  { id: 1, name: 'Atmen', code: 2, speed: true, color: true },
  { id: 2, name: 'Blitzlicht', code: 3, speed: true, color: true },
  { id: 3, name: 'Spektrum', code: 4, speed: true, color: false },
  { id: 4, name: 'Regenbogen', code: 14, speed: true, color: false },
  { id: 5, name: 'Welle', code: 7, speed: true, color: true },
  { id: 6, name: 'Lauflicht', code: 11, speed: true, color: true },
  { id: 7, name: 'Zufall', code: 5, speed: true, color: true },
  { id: 8, name: 'Neon', code: 12, speed: true, color: true },
  { id: 9, name: 'Wasser', code: 13, speed: true, color: true },
  { id: 10, name: 'Aus', code: 0, speed: false, color: false },
];

const EFFECT_MODE = {
  static: 1,
  wave: 7,
  spectrum: 4,
  breath: 2,
  gradient: 1,
  pulse: 2,
  rainbow: 14,
  comet: 11,
  sparkle: 5,
  fire: 1,
  lava: 1,
  ocean: 7,
  aurora: 7,
  strobe: 3,
  chase: 11,
  split: 1,
  radar: 11,
  twinkle: 5,
  heartbeat: 2,
  off: 0,
};

const hex = (v) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(v || ''));
  const h = m ? m[1] : 'ffffff';
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
};

class AsrockRgb {
  constructor({ onChange } = {}) {
    this.onChange = onChange || (() => {});
    this.proc = null;
    this.buf = '';
    this.waiters = [];
    this.ready = false;
    this.found = false;
    this.error = '';
    this.connecting = null;
    this.stopping = false;
    this.fx = null;
    this.lastMode = 1;
    this.lastColor = '#8b6cff';
    this.lastSpeed = 128;
    this.devices = [];
    this.ledCount = 247;
  }

  status() {
    return {
      installed: this.found,
      installing: 0,
      running: this.ready,
      error: this.error,
      effect: this.fx,
      effects: EFFECTS,
      devices: this.devices.map((d, i) => this.publicDevice(d, i)),
    };
  }

  publicDevice(d) {
    return {
      id: 0,
      name: d.name,
      vendor: 'ASRock',
      type: 'Mainboard',
      typeId: 0,
      leds: d.leds,
      zones: d.zones.map((z) => ({ name: z, leds: 1, swap: false })),
      activeMode: d.activeMode,
      color: d.color,
      modes: MODES.map((m) => ({ id: m.id, name: m.name, speed: m.speed, brightness: false, color: m.color, colorsMax: m.color ? 1 : 0, speedMin: 0, speedMax: 255, curSpeed: this.lastSpeed, brightnessMin: 0, brightnessMax: 100, curBrightness: 100 })),
    };
  }

  onLine(line) {
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      return;
    }
    if (!this.ready) {
      const init = this.waiters.shift();
      if (msg.ok && Array.isArray(msg.sizes)) {
        this.ready = true;
        this.found = true;
        this.error = '';
        const sizes = msg.sizes.map(Number).filter((n) => n > 0 && n !== 0x1e);
        const sum = sizes.reduce((a, b) => a + b, 0);
        this.ledCount = /B650 Steel Legend/i.test(msg.name) ? 247 : sum || 247;
        this.devices = [{ name: msg.name || 'ASRock RGB Controller', leds: this.ledCount, zones: sizes.map((n, i) => `RGB ${i + 1}`), activeMode: MODES.findIndex((m) => m.code === this.lastMode), color: this.lastColor }];
        init?.resolve?.();
        this.onChange(this.status());
      } else {
        this.error = msg.error || 'Kein ASRock RGB-Controller gefunden';
        init?.reject?.(new Error(this.error));
      }
      return;
    }
    const job = this.waiters.shift();
    if (job) {
      clearTimeout(job.timer);
      job.resolve(msg);
    }
  }

  start() {
    if (this.proc) return Promise.resolve();
    return new Promise((resolve, reject) => {
      let settled = false;
      const script = path.join(__dirname, 'asrock-helper.ps1');
      const proc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
      this.proc = proc;
      this.buf = '';
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        this.error = 'RGB-Controller antwortet nicht';
        reject(new Error(this.error));
      }, 12000);
      const initJob = {
        resolve: () => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          resolve();
        },
        reject: (e) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          reject(e);
        },
        timer,
      };
      this.waiters.push(initJob);
      proc.stdout.setEncoding('utf8');
      proc.stdout.on('data', (chunk) => {
        this.buf += chunk;
        let i;
        while ((i = this.buf.indexOf('\n')) >= 0) {
          const line = this.buf.slice(0, i).trim();
          this.buf = this.buf.slice(i + 1);
          if (line) this.onLine(line);
        }
      });
      proc.stderr.on('data', () => {
        /* PowerShell diagnostics must never be shown as RGB output */
      });
      proc.on('error', (e) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        this.error = e.message || String(e);
        reject(new Error(this.error));
      });
      proc.on('exit', () => {
        const wasReady = this.ready;
        this.proc = null;
        this.ready = false;
        for (const job of this.waiters.splice(0)) {
          clearTimeout(job.timer);
          job.reject(new Error('RGB-Helfer beendet'));
        }
        if (wasReady && !this.stopping) {
          this.error = 'RGB-Helfer beendet – erneut verbinden';
          this.onChange(this.status());
        }
      });
      this.connecting = initJob;
    });
  }

  request(payload, timeout = 8000) {
    return new Promise((resolve, reject) => {
      if (!this.proc || !this.ready) return reject(new Error('RGB-Controller nicht verbunden'));
      const job = { resolve, reject };
      job.timer = setTimeout(() => {
        const i = this.waiters.indexOf(job);
        if (i >= 0) this.waiters.splice(i, 1);
        reject(new Error('RGB-Controller antwortet nicht'));
      }, timeout);
      this.waiters.push(job);
      try {
        this.proc.stdin.write(JSON.stringify(payload) + '\n');
      } catch (e) {
        clearTimeout(job.timer);
        this.waiters.splice(this.waiters.indexOf(job), 1);
        reject(e);
      }
    });
  }

  async connect() {
    if (this.ready) return this.status();
    if (this.connecting) {
      await this.connecting;
      return this.status();
    }
    this.error = '';
    this.connecting = (async () => {
      try {
        await this.start();
        this.found = true;
        this.ready = true;
      } catch (e) {
        this.found = false;
        this.ready = false;
        const raw = String(e?.message || e).replace(/^Error: /, '');
        this.error = raw === 'NO_DEVICE' ? 'Kein ASRock-RGB-Controller gefunden – Mainboard prüfen.' : /^OPEN_/.test(raw) ? 'RGB-Controller lässt sich nicht öffnen.' : raw;
      }
      if (this.ready) {
        try {
          const st = await this.request({ cmd: 'status' });
          const z = st?.zones?.[0];
          if (st?.ok && z) {
            this.lastMode = z.mode;
            this.lastSpeed = z.speed;
            this.lastColor = `#${[z.r, z.g, z.b].map((v) => Number(v).toString(16).padStart(2, '0')).join('')}`;
            if (this.devices[0]) {
              this.devices[0].activeMode = MODES.findIndex((m) => m.code === z.mode);
              this.devices[0].color = this.lastColor;
            }
          }
        } catch {
          /* Status ist optional */
        }
      }
      this.connecting = null;
      this.onChange(this.status());
    })();
    await this.connecting;
    return this.status();
  }

  install() {
    return this.connect();
  }

  async rescan() {
    await this.stop();
    this.found = false;
    this.devices = [];
    return this.connect();
  }

  async apply(code, color, speed = 128) {
    await this.connect();
    if (!this.ready) throw new Error(this.error || 'RGB-Controller nicht verbunden');
    const [r0, g0, b0] = hex(color);
    const k = Math.max(0, Math.min(100, Number(this.brightness ?? 100))) / 100;
    const r = Math.round(r0 * k);
    const g = Math.round(g0 * k);
    const b = Math.round(b0 * k);
    // PCH-Zone des ASRock-Boards ist ab Werk rot/grün vertauscht.
    const res = await this.request({ cmd: 'apply', mode: code, r, g, b, speed, swap: 1 << 4 });
    if (!res?.ok) throw new Error(res?.error || 'RGB-Controller hat den Befehl abgelehnt');
    this.lastMode = code;
    this.lastColor = color || '#8b6cff';
    this.lastSpeed = speed;
    if (this.devices[0]) {
      this.devices[0].activeMode = MODES.findIndex((m) => m.code === code);
      this.devices[0].color = this.lastColor;
    }
    this.onChange(this.status());
  }

  async startEffect({ effect = 'static', color = '#8b6cff', color2 = '#00d5ff', speed = 55, brightness = 100, devices = null } = {}) {
    await this.connect();
    if (!this.ready) throw new Error(this.error || 'RGB-Controller nicht verbunden');
    this.brightness = brightness;
    const code = EFFECT_MODE[effect] ?? 1;
    const speedByte = effect === 'static' || effect === 'off' ? 0xff : Math.max(0, Math.min(255, Math.round(255 - (Number(speed) / 100) * 255)));
    await this.apply(code, effect === 'off' ? '#000000' : color, speedByte);
    this.fx = { effect, color, color2, speed, brightness, devices: [0] };
    this.onChange(this.status());
    return this.status();
  }

  async setMode(i, modeIdx, { color = '#ffffff', speed = null, brightness = 100 } = {}) {
    const mode = MODES[Number(modeIdx)] || MODES[0];
    this.brightness = brightness;
    await this.apply(mode.code, color, speed == null ? (mode.code === 1 ? 0xff : this.lastSpeed) : Math.max(0, Math.min(255, Math.round(255 - (Number(speed) / 100) * 255))));
    this.fx = null;
    return this.status();
  }

  stopEffect() {
    if (this.fx) {
      this.fx = null;
      this.onChange(this.status());
    }
  }

  stop() {
    this.stopping = true;
    this.fx = null;
    this.ready = false;
    try {
      this.proc?.stdin.write(JSON.stringify({ cmd: 'quit' }) + '\n');
    } catch {
      /* egal */
    }
    const proc = this.proc;
    this.proc = null;
    setTimeout(() => {
      try {
        proc?.kill();
      } catch {
        /* egal */
      }
      this.stopping = false;
    }, 600);
  }
}

module.exports = { AsrockRgb, MODES, EFFECT_MODE, EFFECTS };
