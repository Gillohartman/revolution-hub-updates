'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.13.1',
  title: 'Revulution Hub 2.13',
  sub: 'Klick auf einen Eintrag – du landest direkt dort. Oben links kommst du jederzeit hierher zurück.',
  items: [
    { open: 'gaming', icon: 'gaming', title: 'Echte Spiel-FPS', text: 'Das Crosshair-Overlay zeigt jetzt die echten FPS von Fortnite (Gaming Hub → Leistung → „Echte Spiel-FPS“ einmal einrichten).' },
    { open: 'home', icon: 'home', title: 'Neue Startseite', text: 'Kategorien (Allgemein, Gaming, Produktivität, Unterhaltung, Desktop), Suche und „Zuletzt benutzt“.' },
    { open: 'home', icon: 'launcher', title: 'Dock zum Einklappen', text: 'Das Dock wird zur kleinen Glas-Kapsel. Fahr drüber – es fährt heraus und bleibt offen, solange du drauf bist. Mit echtem Glas-Effekt.' },
    { open: 'tool-screentime', icon: 'tool-screentime', title: 'Bildschirmzeit', text: 'Wie am iPhone: Zeit pro App und Kategorie, Tag und Woche, Tageslimit mit Hinweis in der Island.' },
    { open: 'tool-phone', icon: 'tool-phone', title: 'Handy spiegeln', text: 'Android per USB anschliessen, Bild auf dem PC sehen und mit Maus und Tastatur bedienen.' },
    { open: 'tool-football', icon: 'tool-football', title: 'Fußball-App repariert', text: 'Lässt sich jetzt öffnen – alle Live-Spiele, Teams per + folgen.' },
    { open: 'chess', icon: 'chess', title: 'Coach: weiter & Stimmen', text: 'Nach einer richtigen Lösung geht es automatisch weiter, das Brett baut sich neu auf. Mehrere Stimmen zur Auswahl.' },
    { open: 'tool-autoclick', icon: 'tool-autoclick', title: 'Autoclicker mit Maustasten', text: 'Links-, Mittel-, Rechtsklick und Maus 4/5 als Tasten – und als Start/Stopp.' },
    { open: 'video', icon: 'video', title: 'Video-Schnitt kompakter', text: 'Kleinere Knöpfe, mehr Platz für dein Video.' },
    { open: 'orbit', icon: 'orbit', title: 'Island ohne App-Namen', text: 'Oben in der Island steht nicht mehr, welche App Musik abspielt.' },
  ],
};
