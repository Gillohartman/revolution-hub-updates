'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.39.0',
  title: 'Revulution Hub 2.39',
  sub: 'Erfolge, neue Pflanze, Melden in Chats, ruhiger Gaming Hub und zwei neue Spiele.',
  items: [
    { open: 'tool-achievements', icon: 'spark', title: 'Erfolge & Profile', text: 'Sammle Erfolge mit Pflanze, Clips, Bildschirmzeit und mehr – jede Stufe gibt ◆ Punkte. In den Chats siehst du die Profile deiner Freunde.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Widgets im Nothing-Stil', text: 'Ohne Hintergrund, Pflanze mit 27 Stufen und Gießkanne zum Ziehen, Rechtsklick zum Anpassen (Sounds, Mikrofon, Kamera). Soundboard und Schnellzugriff sind jetzt Premium.' },
    { open: 'chats', icon: 'chat', title: 'Chats', text: 'Durchsichtig wie die Startseite, neue Fenster für Server und Einstellungen, Nummer statt Code und Melden mit Bildschirmfoto.' },
    { open: 'gaming', icon: 'crosshair', title: 'Gaming Hub', text: 'Kein Blinken mehr, hell und durchsichtig, runde Knöpfe. Neu: Crosshair an die Taskleiste anheften.' },
    { open: 'tool-games', icon: 'spark', title: 'Minen & Höher/Tiefer', text: 'Zwei neue Spiele mit ◆ Punkten, Roulette-Zeiger repariert.' },
    { open: 'tool-store', icon: 'spark', title: 'Coins & Abos', text: 'Münzberge auf den Paketen, erhabener Ring – und Revulution Max (bald).' },
    { open: 'video', icon: 'layers', title: 'Video-Schnitt', text: 'Runde Leisten und Tabs, viel weniger Text.' },
    { open: 'home', icon: 'pointer', title: 'Kleinigkeiten', text: 'Mauszeiger flackert nicht mehr, Favoriten-Widget neu, Store füllt das Fenster, Kontrollzentrum aus Glas, Likes ohne Konto.' },
  ],
};
