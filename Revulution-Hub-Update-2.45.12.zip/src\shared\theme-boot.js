/* Runde 11b – Design „Pro“: setzt html[data-theme] so früh wie möglich (im <head>, vor dem ersten
   Zeichnen), damit es kein Aufblitzen gibt. Quelle: localStorage 'rh-design' (vom Hub bzw. vom
   Hauptprozess geschrieben). Wechsel in einem anderen Fenster derselben Herkunft kommen per
   'storage'-Ereignis sofort an; Modul-Fenster mit eigener Partition setzt der Hauptprozess. */
(function () {
  var root = document.documentElement;
  // Durchsichtige Fenster (Leiste, Dock, Widgets, Kontrollzentrum, Overlays) behalten ihren
  // durchsichtigen Grund – Pro färbt dort nur die Bauteile, nicht die ganze Fläche.
  try {
    var page = (location.pathname.split('/').pop() || '').toLowerCase();
    if (/^(taskbar|dock|desktop-widgets|airplay-widget|wp-switch|stream-chat|client|lock|parental-lock|crosshair-overlay|monitor-glow)\.html$/.test(page)) root.setAttribute('data-surface', 'overlay');
  } catch (e) {}
  function apply(v) {
    if (v === 'pro') root.setAttribute('data-theme', 'pro');
    else root.removeAttribute('data-theme');
  }
  try { apply(localStorage.getItem('rh-design')); } catch (e) {}
  try {
    window.addEventListener('storage', function (e) {
      if (e.key === 'rh-design') apply(e.newValue);
    });
  } catch (e) {}
})();
