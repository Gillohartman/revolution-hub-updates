'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.36.0',
  title: 'Revulution Hub 2.36',
  sub: 'Federnde Leisten, sauberes Glas ohne Kästen, neue Widgets und ein ruhigerer Hub.',
  items: [
    { open: 'home', icon: 'spark', title: 'Federnde Tab-Leisten', text: 'Beim Wechseln wischt eine Glas-Kapsel rüber und federt nach – überall, auch in der Gaming-Hub-Seitenleiste und den Hintergründen.' },
    { open: 'home', icon: 'eye', title: 'Keine Kästen mehr', text: 'Die eckigen Streifen und Kästen in Chats und anderen Apps sind weg, die Anruf-Karte hat runde Glas-Ecken.' },
    { open: 'settings', icon: 'settings', title: 'Glas nach deinem Geschmack', text: 'Unter Einstellungen → Liquid Glass stellst du ein, wie durchsichtig das Glas ist. Der Rand bricht das Licht jetzt sauber, ohne Lupe.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Neue Widgets', text: 'Fußball und Autoclicker, das Punkt-Wetter ist jetzt an. Verdeckte Widgets pausieren und sparen Leistung, Positionen bleiben nach dem Neustart.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Hintergründe', text: 'Hochgeladene zuerst, eigener Tab „Revulution Live“, Karten mit Bild über die ganze Fläche und Premium-Abzeichen.' },
    { open: 'orbit', icon: 'island', title: 'Island', text: 'Federt beim Aufklappen, läuft flüssiger und ist im Game-Modus ohne Animationen.' },
    { open: 'gaming', icon: 'crosshair', title: 'Gaming Hub in Glas', text: 'Schwebende Seitenleiste, Glas-Karten und saubere Abstände.' },
  ],
};
