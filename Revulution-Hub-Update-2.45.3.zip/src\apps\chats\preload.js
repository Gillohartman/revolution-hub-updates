'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('chatApp', {
  load: () => ipcRenderer.invoke('load'),
  save: (data) => ipcRenderer.invoke('save', data),
  notify: (n) => ipcRenderer.invoke('notify', n),
  relay: (m) => ipcRenderer.invoke('relay', m),
  callState: (s) => ipcRenderer.invoke('call-state', s),
  identity: (id) => ipcRenderer.invoke('identity', id),
  unread: (n) => ipcRenderer.invoke('unread', n),
  pending: () => ipcRenderer.invoke('pending'),
  isOpen: () => ipcRenderer.invoke('is-open'),
  onGameRequest: (fn) => ipcRenderer.on('game-request', (_e, item) => fn(item)),
  onAcceptCall: (fn) => ipcRenderer.on('accept-call', () => fn()),
  snap: () => ipcRenderer.invoke('snap'),
  myCard: () => ipcRenderer.invoke('my-card'),
  report: (r) => ipcRenderer.invoke('report', r),
  shareSources: () => ipcRenderer.invoke('share-sources'),
  sharePick: (id) => ipcRenderer.invoke('share-pick', id),
});
contextBridge.exposeInMainWorld('hubProfile', {
  get: () => ipcRenderer.invoke('hp:get'),
  name: (v) => ipcRenderer.invoke('hp:name', v),
  shop: () => ipcRenderer.invoke('hp:shop'),
});
