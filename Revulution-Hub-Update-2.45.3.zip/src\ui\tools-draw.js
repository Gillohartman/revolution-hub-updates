'use strict';

/*
 * 2.45 Zeichnen: Malen mit Maus, Touch und Stift (Druckstufen über Windows Ink / Pointer Events).
 * Pinsel werden breiter, wenn man verweilt oder fester drückt, und schmaler bei schnellen Strichen.
 * Pinsel: Füller, Bleistift (körnig), Kreide/Kohle (bröckelig), Marker, Airbrush, Radierer.
 * Dazu Ebenen, Formen, Füllen, Pipette, Rückgängig/Wiederholen, Zoom/Verschieben, PNG speichern/öffnen.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-draw';
  const W = 1920;
  const H = 1200;
  const BRUSHES = [
    ['pen', 'Füller', '✒️'], ['pencil', 'Bleistift', '✏️'], ['chalk', 'Kreide', '🖍️'], ['marker', 'Marker', '🖊️'], ['air', 'Airbrush', '💨'], ['eraser', 'Radierer', '🧽'],
    ['line', 'Linie', '╱'], ['rect', 'Rechteck', '▭'], ['ellipse', 'Ellipse', '◯'], ['fill', 'Füllen', '🪣'], ['pick', 'Pipette', '💧'], ['hand', 'Verschieben', '✋'],
  ];
  const SWATCHES = ['#111111', '#ffffff', '#ff3b30', '#ff9500', '#ffcc00', '#34c759', '#00c7be', '#0a84ff', '#5e5ce6', '#bf5af2', '#ff2d55', '#a2845e', '#8e8e93', '#1c3d5a', '#f5d0a9', '#7cfc00'];
  const st = {
    root: null, tool: 'pen', color: '#111111', size: 12, opacity: 1, smooth: 0.45, bg: '#ffffff',
    layers: [], active: 0, undo: [], redo: [], zoom: 1, panX: 0, panY: 0, ptrs: new Map(), stroke: null, view: null, ctxView: null, overlay: null, dirty: false, saveTimer: 0, loaded: false,
  };

  /* ---------------------------------------------------------------- Ebenen */
  function newLayer(name) {
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    return { id: Math.random().toString(36).slice(2, 8), name, canvas: c, ctx: c.getContext('2d', { willReadFrequently: true }), visible: true, opacity: 1 };
  }
  function ensureLayers() {
    if (!st.layers.length) st.layers = [newLayer('Ebene 1')];
  }
  const layer = () => st.layers[st.active];

  /* ---------------------------------------------------------------- Ansicht */
  function compose() {
    const v = st.ctxView;
    if (!v) return;
    const { width: vw, height: vh } = st.view;
    v.setTransform(1, 0, 0, 1, 0, 0);
    v.clearRect(0, 0, vw, vh);
    v.setTransform(st.zoom, 0, 0, st.zoom, st.panX, st.panY);
    v.fillStyle = st.bg;
    v.shadowColor = 'rgba(0,0,0,.35)';
    v.shadowBlur = 24 / st.zoom;
    v.fillRect(0, 0, W, H);
    v.shadowBlur = 0;
    for (const l of st.layers) {
      if (!l.visible) continue;
      v.globalAlpha = l.opacity;
      v.drawImage(l.canvas, 0, 0);
    }
    v.globalAlpha = st.overlayAlpha ?? 1;
    if (st.overlay) v.drawImage(st.overlay, 0, 0);
    v.globalAlpha = 1;
  }
  let rafPending = false;
  const redraw = () => {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => {
      rafPending = false;
      compose();
    });
  };
  function fit() {
    if (!st.view) return;
    const box = st.view.parentElement.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    st.view.width = Math.max(10, Math.round(box.width * dpr));
    st.view.height = Math.max(10, Math.round(box.height * dpr));
    st.view.style.width = `${box.width}px`;
    st.view.style.height = `${box.height}px`;
    st.zoom = Math.min(st.view.width / W, st.view.height / H) * 0.94;
    st.panX = (st.view.width - W * st.zoom) / 2;
    st.panY = (st.view.height - H * st.zoom) / 2;
    redraw();
  }
  function toCanvas(e) {
    const r = st.view.getBoundingClientRect();
    const dpr = st.view.width / r.width;
    return { x: ((e.clientX - r.left) * dpr - st.panX) / st.zoom, y: ((e.clientY - r.top) * dpr - st.panY) / st.zoom };
  }

  /* ---------------------------------------------------------------- Rückgängig */
  function snapshot() {
    const l = layer();
    st.undo.push({ id: l.id, data: l.ctx.getImageData(0, 0, W, H) });
    if (st.undo.length > 25) st.undo.shift();
    st.redo = [];
  }
  function undo(back = true) {
    const from = back ? st.undo : st.redo;
    const to = back ? st.redo : st.undo;
    const s = from.pop();
    if (!s) return;
    const l = st.layers.find((x) => x.id === s.id);
    if (!l) return;
    to.push({ id: l.id, data: l.ctx.getImageData(0, 0, W, H) });
    l.ctx.putImageData(s.data, 0, 0);
    redraw();
    queueSave();
  }

  /* ---------------------------------------------------------------- Pinsel */
  const hexToRgb = (h) => {
    const n = parseInt(h.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  };
  /** Breite aus Druck, Tempo und Verweildauer. */
  function widthFor(p, speed, dwell) {
    const pressure = p.pointerType === 'mouse' || !p.pressure ? 0.5 : p.pressure;
    const press = 0.3 + pressure * 1.4; // 0.3 … 1.7
    const fast = Math.max(0.35, Math.min(1.25, 1.25 - speed * 0.35)); // schneller → schmaler
    const stay = 1 + Math.min(1.6, dwell / 600); // verweilen → bis 2,6× breiter
    return Math.max(0.6, st.size * press * fast * stay);
  }
  function stampPen(ctx, a, b, wa, wb) {
    // Linie mit sich ändernder Breite: viele kleine Kreise entlang der Strecke (glatt, ohne Lücken)
    const d = Math.hypot(b.x - a.x, b.y - a.y);
    const steps = Math.max(1, Math.ceil(d / Math.max(0.6, Math.min(wa, wb) * 0.25)));
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const w = wa + (wb - wa) * t;
      ctx.beginPath();
      ctx.arc(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, w / 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  function stampPencil(ctx, a, b, w) {
    // Bleistift: feine Körnung, leicht unregelmäßige Deckkraft
    const d = Math.hypot(b.x - a.x, b.y - a.y);
    const steps = Math.max(1, Math.ceil(d / 0.8));
    const [r, g, bl] = hexToRgb(st.color);
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const x = a.x + (b.x - a.x) * t;
      const y = a.y + (b.y - a.y) * t;
      const n = Math.max(2, Math.round(w * 0.9));
      for (let k = 0; k < n; k++) {
        const rr = (Math.random() * w) / 2;
        const ang = Math.random() * Math.PI * 2;
        ctx.fillStyle = `rgba(${r},${g},${bl},${(0.12 + Math.random() * 0.35) * st.opacity})`;
        ctx.fillRect(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr, 1.1, 1.1);
      }
    }
  }
  function stampChalk(ctx, a, b, w) {
    // Kreide/Kohle: bröckelige Flecken mit Lücken
    const d = Math.hypot(b.x - a.x, b.y - a.y);
    const steps = Math.max(1, Math.ceil(d / Math.max(1.5, w * 0.18)));
    const [r, g, bl] = hexToRgb(st.color);
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const x = a.x + (b.x - a.x) * t;
      const y = a.y + (b.y - a.y) * t;
      for (let k = 0; k < 6; k++) {
        if (Math.random() < 0.28) continue; // Lücken = bröckelig
        const rr = Math.random() * w * 0.55;
        const ang = Math.random() * Math.PI * 2;
        const s = 0.8 + Math.random() * w * 0.16;
        ctx.fillStyle = `rgba(${r},${g},${bl},${(0.35 + Math.random() * 0.5) * st.opacity})`;
        ctx.beginPath();
        ctx.ellipse(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr, s, s * (0.4 + Math.random() * 0.6), Math.random() * Math.PI, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  function stampAir(ctx, p, w) {
    const [r, g, bl] = hexToRgb(st.color);
    const n = Math.round(w * 1.6);
    for (let k = 0; k < n; k++) {
      const rr = Math.sqrt(Math.random()) * w;
      const ang = Math.random() * Math.PI * 2;
      ctx.fillStyle = `rgba(${r},${g},${bl},${0.08 * st.opacity})`;
      ctx.fillRect(p.x + Math.cos(ang) * rr, p.y + Math.sin(ang) * rr, 1.4, 1.4);
    }
  }

  function strokeStart(e) {
    const p = toCanvas(e);
    const tool = st.tool;
    if (tool === 'pick') {
      const c = st.view.getContext('2d').getImageData(Math.round(e.offsetX * (st.view.width / st.view.clientWidth)), Math.round(e.offsetY * (st.view.height / st.view.clientHeight)), 1, 1).data;
      st.color = `#${[c[0], c[1], c[2]].map((v) => v.toString(16).padStart(2, '0')).join('')}`;
      paintTools();
      return null;
    }
    if (tool === 'fill') {
      snapshot();
      flood(Math.round(p.x), Math.round(p.y));
      redraw();
      queueSave();
      return null;
    }
    snapshot();
    const s = { tool, pts: [{ ...p, t: performance.now(), pressure: e.pressure, pointerType: e.pointerType }], start: p, lastW: 0, dwell: 0, lastMoveAt: performance.now(), smooth: { ...p } };
    // Füller mit Deckkraft < 100 %: erst auf eine Zwischenebene (sonst addieren sich Überlappungen)
    s.viaOverlay = tool === 'pen' && st.opacity < 1;
    if (tool === 'marker' || ['line', 'rect', 'ellipse'].includes(tool) || s.viaOverlay) {
      st.overlay = document.createElement('canvas');
      st.overlay.width = W;
      st.overlay.height = H;
      s.octx = st.overlay.getContext('2d');
      st.overlayAlpha = s.viaOverlay ? st.opacity : 1;
    }
    const ctx = layer().ctx;
    ctx.save();
    ctx.globalCompositeOperation = tool === 'eraser' ? 'destination-out' : 'source-over';
    ctx.fillStyle = st.color;
    ctx.globalAlpha = 1;
    s.ctx = ctx;
    if (s.viaOverlay) {
      s.octx.fillStyle = st.color;
      s.ctx = s.octx;
      s.layerCtx = ctx;
    }
    if (tool === 'pen' || tool === 'eraser') {
      s.lastW = widthFor(s.pts[0], 0, 0);
      ctx.beginPath();
      ctx.arc(p.x, p.y, s.lastW / 2, 0, Math.PI * 2);
      ctx.fill();
    }
    if (tool === 'air') stampAir(ctx, p, st.size * 2);
    // Verweilen: auch ohne Bewegung wird der Strich langsam breiter
    s.dwellTimer = setInterval(() => {
      if (!st.stroke || !['pen', 'air', 'chalk'].includes(st.tool)) return;
      const now = performance.now();
      if (now - s.lastMoveAt < 60) return;
      s.dwell += 60;
      const last = s.pts[s.pts.length - 1];
      const w = widthFor(last, 0, s.dwell);
      if (st.tool === 'pen') {
        s.ctx.beginPath();
        s.ctx.arc(last.x, last.y, w / 2, 0, Math.PI * 2);
        s.ctx.fill();
        s.lastW = w;
      } else if (st.tool === 'air') stampAir(s.ctx, last, st.size * 2);
      else stampChalk(s.ctx, last, last, w);
      redraw();
    }, 60);
    redraw();
    return s;
  }
  function strokeMove(e) {
    const s = st.stroke;
    if (!s) return;
    const events = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    for (const ev of events.length ? events : [e]) {
      const raw = toCanvas(ev);
      // Glätten (Stabilisator)
      const k = 1 - st.smooth * 0.85;
      s.smooth.x += (raw.x - s.smooth.x) * k;
      s.smooth.y += (raw.y - s.smooth.y) * k;
      const now = performance.now();
      const prev = s.pts[s.pts.length - 1];
      const p = { x: s.smooth.x, y: s.smooth.y, t: now, pressure: ev.pressure, pointerType: ev.pointerType };
      const dist = Math.hypot(p.x - prev.x, p.y - prev.y);
      if (dist < 0.4) continue;
      const speed = dist / Math.max(1, now - prev.t) / Math.max(0.3, st.zoom);
      if (dist > 1.5) {
        s.lastMoveAt = now;
        s.dwell = Math.max(0, s.dwell - dist * 8); // beim Weiterziehen schmilzt der Verweil-Bonus
      }
      s.pts.push(p);
      const w = widthFor(p, speed, s.dwell);
      if (s.tool === 'pen' || s.tool === 'eraser') {
        const smoothW = s.lastW + (w - s.lastW) * 0.35;
        stampPen(s.ctx, prev, p, s.lastW, smoothW);
        s.lastW = smoothW;
      } else if (s.tool === 'pencil') stampPencil(s.ctx, prev, p, Math.max(1, w * 0.45));
      else if (s.tool === 'chalk') stampChalk(s.ctx, prev, p, w * 1.9);
      else if (s.tool === 'air') stampAir(s.ctx, p, st.size * 2);
      else if (s.tool === 'marker') {
        const o = s.octx;
        o.clearRect(0, 0, W, H);
        o.strokeStyle = st.color;
        o.lineWidth = st.size * 1.6;
        o.lineCap = 'square';
        o.lineJoin = 'round';
        o.globalAlpha = 0.45 * st.opacity;
        o.beginPath();
        o.moveTo(s.pts[0].x, s.pts[0].y);
        for (const q of s.pts) o.lineTo(q.x, q.y);
        o.stroke();
      } else if (['line', 'rect', 'ellipse'].includes(s.tool)) shapePreview(s, p, e.shiftKey);
    }
    redraw();
  }
  function shapePreview(s, p, square) {
    const o = s.octx;
    o.clearRect(0, 0, W, H);
    o.strokeStyle = st.color;
    o.globalAlpha = st.opacity;
    o.lineWidth = st.size;
    o.lineCap = 'round';
    let w = p.x - s.start.x;
    let h = p.y - s.start.y;
    if (square && s.tool !== 'line') {
      const m = Math.max(Math.abs(w), Math.abs(h));
      w = Math.sign(w || 1) * m;
      h = Math.sign(h || 1) * m;
    }
    o.beginPath();
    if (s.tool === 'line') {
      o.moveTo(s.start.x, s.start.y);
      o.lineTo(p.x, p.y);
    } else if (s.tool === 'rect') o.rect(s.start.x, s.start.y, w, h);
    else o.ellipse(s.start.x + w / 2, s.start.y + h / 2, Math.abs(w / 2), Math.abs(h / 2), 0, 0, Math.PI * 2);
    o.stroke();
  }
  function strokeEnd() {
    const s = st.stroke;
    if (!s) return;
    clearInterval(s.dwellTimer);
    const target = s.layerCtx || s.ctx;
    if (st.overlay && (s.viaOverlay || s.tool === 'marker' || ['line', 'rect', 'ellipse'].includes(s.tool))) {
      target.globalAlpha = s.viaOverlay ? st.opacity : 1;
      target.drawImage(st.overlay, 0, 0);
    }
    target.restore();
    st.overlayAlpha = 1;
    st.overlay = null;
    st.stroke = null;
    redraw();
    queueSave();
  }

  /** Füllen: Flutfüllung mit kleiner Toleranz. */
  function flood(x0, y0) {
    if (x0 < 0 || y0 < 0 || x0 >= W || y0 >= H) return;
    const ctx = layer().ctx;
    const img = ctx.getImageData(0, 0, W, H);
    const d = img.data;
    const i0 = (y0 * W + x0) * 4;
    const target = [d[i0], d[i0 + 1], d[i0 + 2], d[i0 + 3]];
    const [r, g, b] = hexToRgb(st.color);
    const a = Math.round(255 * st.opacity);
    if (target[0] === r && target[1] === g && target[2] === b && target[3] === a) return;
    const tol = 32;
    const same = (i) => Math.abs(d[i] - target[0]) <= tol && Math.abs(d[i + 1] - target[1]) <= tol && Math.abs(d[i + 2] - target[2]) <= tol && Math.abs(d[i + 3] - target[3]) <= tol;
    const seen = new Uint8Array(W * H);
    const stack = [x0, y0];
    while (stack.length) {
      const y = stack.pop();
      let x = stack.pop();
      while (x >= 0 && same((y * W + x) * 4) && !seen[y * W + x]) x -= 1;
      x += 1;
      let up = false;
      let down = false;
      while (x < W && same((y * W + x) * 4) && !seen[y * W + x]) {
        const i = (y * W + x) * 4;
        seen[y * W + x] = 1;
        d[i] = r;
        d[i + 1] = g;
        d[i + 2] = b;
        d[i + 3] = a;
        if (y > 0) {
          const u = ((y - 1) * W + x) * 4;
          if (same(u) && !seen[(y - 1) * W + x]) {
            if (!up) {
              stack.push(x, y - 1);
              up = true;
            }
          } else up = false;
        }
        if (y < H - 1) {
          const dn = ((y + 1) * W + x) * 4;
          if (same(dn) && !seen[(y + 1) * W + x]) {
            if (!down) {
              stack.push(x, y + 1);
              down = true;
            }
          } else down = false;
        }
        x += 1;
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  /* ---------------------------------------------------------------- Zeiger (Maus, Stift, Touch) */
  function onDown(e) {
    if (!st.view || e.target !== st.view) return;
    st.view.setPointerCapture(e.pointerId);
    st.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    // Zwei Finger: verschieben und zoomen statt malen
    if (st.ptrs.size === 2) {
      if (st.stroke) {
        clearInterval(st.stroke.dwellTimer);
        (st.stroke.layerCtx || st.stroke.ctx).restore();
        st.overlayAlpha = 1;
        st.stroke = null;
        st.overlay = null;
        undo(true);
        st.redo = [];
      }
      const [a, b] = [...st.ptrs.values()];
      st.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, zoom: st.zoom, panX: st.panX, panY: st.panY };
      return;
    }
    if (st.tool === 'hand' || e.button === 1 || st.spaceDown) {
      st.panning = { x: e.clientX, y: e.clientY, px: st.panX, py: st.panY };
      return;
    }
    if (e.button === 2) return;
    if (!layer().visible) return A.toast('Diese Ebene ist ausgeblendet.', 'error');
    st.stroke = strokeStart(e);
  }
  function onMove(e) {
    if (!st.view) return;
    if (st.ptrs.has(e.pointerId)) st.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const dpr = st.view.width / st.view.clientWidth;
    if (st.pinch && st.ptrs.size === 2) {
      const [a, b] = [...st.ptrs.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const z = Math.max(0.05, Math.min(8, st.pinch.zoom * (d / st.pinch.d)));
      const cx = (a.x + b.x) / 2;
      const cy = (a.y + b.y) / 2;
      const r = st.view.getBoundingClientRect();
      const ox = (st.pinch.cx - r.left) * dpr;
      const oy = (st.pinch.cy - r.top) * dpr;
      st.zoom = z;
      st.panX = ox - ((ox - st.pinch.panX) / st.pinch.zoom) * z + (cx - st.pinch.cx) * dpr;
      st.panY = oy - ((oy - st.pinch.panY) / st.pinch.zoom) * z + (cy - st.pinch.cy) * dpr;
      return redraw();
    }
    if (st.panning) {
      st.panX = st.panning.px + (e.clientX - st.panning.x) * dpr;
      st.panY = st.panning.py + (e.clientY - st.panning.y) * dpr;
      return redraw();
    }
    if (st.stroke && e.pointerId === [...st.ptrs.keys()][0]) strokeMove(e);
  }
  function onUp(e) {
    st.ptrs.delete(e.pointerId);
    if (st.ptrs.size < 2) st.pinch = null;
    st.panning = null;
    if (st.stroke && !st.ptrs.size) strokeEnd();
  }
  function onWheel(e) {
    if (!st.view || e.target !== st.view) return;
    e.preventDefault();
    const dpr = st.view.width / st.view.clientWidth;
    if (e.ctrlKey || e.metaKey || !e.shiftKey) {
      const r = st.view.getBoundingClientRect();
      const ox = (e.clientX - r.left) * dpr;
      const oy = (e.clientY - r.top) * dpr;
      const z = Math.max(0.05, Math.min(8, st.zoom * Math.exp(-e.deltaY * 0.0015)));
      st.panX = ox - ((ox - st.panX) / st.zoom) * z;
      st.panY = oy - ((oy - st.panY) / st.zoom) * z;
      st.zoom = z;
    } else st.panX -= e.deltaY * dpr;
    paintZoom();
    redraw();
  }

  /* ---------------------------------------------------------------- Speichern */
  function queueSave() {
    st.dirty = true;
    clearTimeout(st.saveTimer);
    st.saveTimer = setTimeout(saveNow, 1500);
  }
  async function saveNow() {
    if (!st.dirty) return;
    st.dirty = false;
    const doc = { bg: st.bg, active: st.active, layers: st.layers.map((l) => ({ name: l.name, visible: l.visible, opacity: l.opacity, png: l.canvas.toDataURL('image/png') })) };
    await A.store.set('draw-last', doc);
  }
  async function load() {
    if (st.loaded) return;
    st.loaded = true;
    const doc = await A.store.get('draw-last', null);
    if (!doc?.layers?.length) return ensureLayers();
    st.bg = doc.bg || '#ffffff';
    st.layers = [];
    for (const l of doc.layers.slice(0, 12)) {
      const nl = newLayer(l.name || 'Ebene');
      nl.visible = l.visible !== false;
      nl.opacity = Number(l.opacity) || 1;
      await new Promise((res) => {
        const img = new Image();
        img.onload = () => {
          nl.ctx.drawImage(img, 0, 0);
          res();
        };
        img.onerror = res;
        img.src = l.png;
      });
      st.layers.push(nl);
    }
    st.active = Math.min(st.layers.length - 1, Number(doc.active) || 0);
  }
  function exportPng() {
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const x = c.getContext('2d');
    x.fillStyle = st.bg;
    x.fillRect(0, 0, W, H);
    for (const l of st.layers) if (l.visible) {
      x.globalAlpha = l.opacity;
      x.drawImage(l.canvas, 0, 0);
    }
    const a = document.createElement('a');
    a.href = c.toDataURL('image/png');
    a.download = `Zeichnung ${new Date().toLocaleString('de-CH').replace(/[/:]/g, '-')}.png`;
    a.click();
  }
  function openImage() {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = 'image/*';
    inp.onchange = () => {
      const f = inp.files?.[0];
      if (!f) return;
      const url = URL.createObjectURL(f);
      const img = new Image();
      img.onload = () => {
        const l = newLayer(f.name.slice(0, 24));
        const sc = Math.min(W / img.width, H / img.height, 1);
        l.ctx.drawImage(img, (W - img.width * sc) / 2, (H - img.height * sc) / 2, img.width * sc, img.height * sc);
        st.layers.push(l);
        st.active = st.layers.length - 1;
        URL.revokeObjectURL(url);
        paintLayers();
        redraw();
        queueSave();
      };
      img.src = url;
    };
    inp.click();
  }

  /* ---------------------------------------------------------------- Oberfläche */
  function paintTools() {
    const t = st.root?.querySelector('.dr-tools');
    if (!t) return;
    t.innerHTML = `${BRUSHES.map(([k, n, ic]) => `<button class="dr-tool ${st.tool === k ? 'on' : ''}" data-dr-tool="${k}" title="${esc(n)}"><span>${ic}</span><small>${esc(n)}</small></button>`).join('')}`;
    const c = st.root.querySelector('.dr-colors');
    if (c) c.innerHTML = `${SWATCHES.map((s) => `<button class="dr-sw ${st.color === s ? 'on' : ''}" style="--c:${s}" data-dr-color="${s}" title="${s}"></button>`).join('')}<label class="dr-sw dr-custom" title="Eigene Farbe" style="--c:${st.color}"><input type="color" value="${st.color}" data-dr-colorinput/></label>`;
  }
  function paintLayers() {
    const box = st.root?.querySelector('.dr-layers');
    if (!box) return;
    box.innerHTML = `<div class="rv-row between"><b>Ebenen</b><span class="rv-row"><button class="rv-btn sm" data-dr="layer-add" title="Neue Ebene">＋</button><button class="rv-btn sm" data-dr="layer-del" title="Ebene löschen" ${st.layers.length < 2 ? 'disabled' : ''}>−</button></span></div>
      ${[...st.layers].map((l, i) => ({ l, i })).reverse().map(({ l, i }) => `<div class="dr-layer ${i === st.active ? 'on' : ''}" data-dr-layer="${i}"><button class="dr-eye" data-dr-eye="${i}" title="Ein-/ausblenden">${l.visible ? '👁' : '◌'}</button><span>${esc(l.name)}</span><input type="range" min="0" max="1" step="0.05" value="${l.opacity}" data-dr-lop="${i}" title="Deckkraft"/></div>`).join('')}`;
  }
  function paintZoom() {
    const z = st.root?.querySelector('[data-dr-zoomlabel]');
    if (z && st.view) z.textContent = `${Math.round((st.zoom / (st.view.width / st.view.clientWidth)) * 100)} %`;
  }
  function paint() {
    if (!st.root) return;
    st.root.innerHTML = `<div class="dr">
      <aside class="dr-side rv-card">
        <div class="dr-tools"></div>
        <div class="dr-sec"><b>Farbe</b><div class="dr-colors"></div></div>
        <div class="dr-sec"><label>Größe <output data-dr-out="size">${st.size}</output><input type="range" min="1" max="120" value="${st.size}" data-dr-range="size"/></label>
          <label>Deckkraft <output data-dr-out="opacity">${Math.round(st.opacity * 100)} %</output><input type="range" min="0.05" max="1" step="0.05" value="${st.opacity}" data-dr-range="opacity"/></label>
          <label>Glätten <output data-dr-out="smooth">${Math.round(st.smooth * 100)} %</output><input type="range" min="0" max="0.95" step="0.05" value="${st.smooth}" data-dr-range="smooth"/></label>
          <label class="rv-row between">Papier <input type="color" value="${st.bg}" data-dr-bg/></label></div>
        <div class="dr-sec dr-layers"></div>
      </aside>
      <section class="dr-main rv-card">
        <div class="dr-top rv-row between">
          <div class="rv-row"><button class="rv-btn sm" data-dr="undo" title="Rückgängig (Strg+Z)">↶</button><button class="rv-btn sm" data-dr="redo" title="Wiederholen (Strg+Y)">↷</button>
            <button class="rv-btn sm" data-dr="fit">Einpassen</button><span class="rv-pill" data-dr-zoomlabel>100 %</span></div>
          <div class="rv-row"><button class="rv-btn sm" data-dr="open">Bild öffnen</button><button class="rv-btn sm" data-dr="clear">Ebene leeren</button><button class="rv-btn sm primary" data-dr="export">Als PNG speichern</button></div>
        </div>
        <div class="dr-stage"><canvas class="dr-canvas"></canvas></div>
        <p class="dr-hint">Tipp: Mit Stift fester drücken oder kurz verweilen = breiter, schnell ziehen = schmaler. Zwei Finger oder Leertaste zum Verschieben, Strg + Mausrad zum Zoomen. Umschalt bei Formen = gleichmäßig.</p>
      </section>
    </div>`;
    st.view = st.root.querySelector('.dr-canvas');
    st.ctxView = st.view.getContext('2d');
    st.view.addEventListener('pointerdown', onDown);
    st.view.addEventListener('pointermove', onMove);
    st.view.addEventListener('pointerup', onUp);
    st.view.addEventListener('pointercancel', onUp);
    st.view.addEventListener('wheel', onWheel, { passive: false });
    st.view.addEventListener('contextmenu', (e) => e.preventDefault());
    paintTools();
    paintLayers();
    requestAnimationFrame(() => {
      fit();
      paintZoom();
    });
  }

  document.addEventListener('click', (e) => {
    if (!st.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const tool = q('[data-dr-tool]')?.dataset.drTool;
    if (tool) {
      st.tool = tool;
      st.view.style.cursor = tool === 'hand' ? 'grab' : tool === 'pick' || tool === 'fill' ? 'copy' : 'crosshair';
      return paintTools();
    }
    const col = q('[data-dr-color]')?.dataset.drColor;
    if (col) {
      st.color = col;
      if (st.tool === 'eraser' || st.tool === 'pick') st.tool = 'pen';
      return paintTools();
    }
    const eye = q('[data-dr-eye]')?.dataset.drEye;
    if (eye != null) {
      st.layers[Number(eye)].visible = !st.layers[Number(eye)].visible;
      paintLayers();
      redraw();
      return queueSave();
    }
    const li = q('[data-dr-layer]')?.dataset.drLayer;
    if (li != null && !e.target.matches('input')) {
      st.active = Number(li);
      return paintLayers();
    }
    const a = q('[data-dr]')?.dataset.dr;
    if (a === 'undo') undo(true);
    else if (a === 'redo') undo(false);
    else if (a === 'fit') {
      fit();
      paintZoom();
    } else if (a === 'export') exportPng();
    else if (a === 'open') openImage();
    else if (a === 'clear') {
      snapshot();
      layer().ctx.clearRect(0, 0, W, H);
      redraw();
      queueSave();
    } else if (a === 'layer-add') {
      st.layers.splice(st.active + 1, 0, newLayer(`Ebene ${st.layers.length + 1}`));
      st.active += 1;
      paintLayers();
      queueSave();
    } else if (a === 'layer-del' && st.layers.length > 1) {
      st.layers.splice(st.active, 1);
      st.active = Math.max(0, st.active - 1);
      paintLayers();
      redraw();
      queueSave();
    }
  });
  document.addEventListener('input', (e) => {
    if (!st.root?.contains(e.target)) return;
    const r = e.target.dataset.drRange;
    if (r) {
      st[r] = Number(e.target.value);
      const out = st.root.querySelector(`[data-dr-out="${r}"]`);
      if (out) out.textContent = r === 'size' ? st.size : `${Math.round(st[r] * 100)} %`;
      return;
    }
    if (e.target.matches('[data-dr-colorinput]')) {
      st.color = e.target.value;
      return;
    }
    if (e.target.matches('[data-dr-bg]')) {
      st.bg = e.target.value;
      redraw();
      return queueSave();
    }
    const lop = e.target.dataset.drLop;
    if (lop != null) {
      st.layers[Number(lop)].opacity = Number(e.target.value);
      redraw();
      queueSave();
    }
  });
  document.addEventListener('change', (e) => {
    if (st.root?.contains(e.target) && e.target.matches('[data-dr-colorinput]')) paintTools();
  });
  document.addEventListener('keydown', (e) => {
    if (!st.root || !document.contains(st.root) || /^(INPUT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z') {
      e.preventDefault();
      undo(!e.shiftKey);
    } else if ((e.ctrlKey || e.metaKey) && k === 'y') {
      e.preventDefault();
      undo(false);
    } else if (k === ' ') {
      st.spaceDown = true;
      e.preventDefault();
    } else if (!e.ctrlKey && !e.metaKey && !e.altKey) {
      const map = { b: 'pen', p: 'pencil', k: 'chalk', m: 'marker', a: 'air', e: 'eraser', l: 'line', r: 'rect', o: 'ellipse', g: 'fill', i: 'pick', h: 'hand' };
      if (map[k]) {
        st.tool = map[k];
        paintTools();
      } else if (k === '[' || k === ']') {
        st.size = Math.max(1, Math.min(120, st.size + (k === ']' ? 2 : -2)));
        const inp = st.root.querySelector('[data-dr-range="size"]');
        if (inp) inp.value = st.size;
        const out = st.root.querySelector('[data-dr-out="size"]');
        if (out) out.textContent = st.size;
      }
    }
  });
  document.addEventListener('keyup', (e) => {
    if (e.key === ' ') st.spaceDown = false;
  });
  window.addEventListener('resize', () => st.root && document.contains(st.root) && (fit(), paintZoom()));

  A.define(
    ID,
    { nav: 'Zeichnen', title: 'Zeichnen', sub: 'Mit Stift, Touch oder Maus', icon: 'palette', tint: 'linear-gradient(135deg,#f472b6,#9333ea)', desc: 'Zeichnen mit Druckstufen: Verweilen macht den Strich breiter, schnelles Ziehen schmaler. Füller, Bleistift, bröckelige Kreide, Marker, Airbrush, Ebenen, Formen und Export als PNG.' },
    {
      async mount(root) {
        st.root = root;
        root.innerHTML = '<div class="rv-empty">Lädt …</div>';
        await load();
        ensureLayers();
        if (st.root === root) paint();
      },
      unmount() {
        saveNow();
        st.root = null;
        st.view = null;
        st.ctxView = null;
      },
      wide: true,
    },
  );
})();
