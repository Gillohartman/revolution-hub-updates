'use strict';

/**
 * Revolution Hub – one app for Dropzone, the Gaming Hub, Orbit Island and the hub's own
 * tools (System-Monitor, Screenshot, Video-Schnitt, Dokumente, Schach-Coach).
 */

const electron = require('electron');
const { app, BrowserWindow, Menu, Tray, ipcMain, nativeImage, protocol, shell, Notification, powerSaveBlocker, dialog, screen, powerMonitor } = electron;
const { pathToFileURL } = require('url');
const fs = require('fs');
const path = require('path');
const { createShim, privilegedSchemes } = require('./shim');
const { ModuleView } = require('./module-view');
const { OrbitIsland } = require('./orbit');
const { Community } = require('./community');
const { setHidden: setTaskbarHidden, startMenu: openStartMenu, restoreSync: restoreTaskbarSync, watchFullscreen, watchWindowsKey, watchEscapeHold, keepTaskbarHidden } = require('./taskbar');
const windowsTaskbar = require('./windows-taskbar');

const APP_ROOT = path.join(__dirname, '..', '..');
const UI_DIR = path.join(APP_ROOT, 'src', 'ui');
const APPS_DIR = path.join(APP_ROOT, 'src', 'apps');
const ICON = path.join(UI_DIR, 'assets', 'logo.png');
const WALLPAPER_DIR = path.join(APP_ROOT, 'modules', 'gaming-hub', 'assets', 'wallpapers');
const START_HIDDEN = process.argv.includes('--hidden');

// Das Admin-Center ist eine eigene App-Oberfläche: gleicher Installer, eigener
// Prozess, eigenes Fenster und ohne jeden Admin-Einstieg im normalen Hub.
if (process.argv.includes('--admin')) {
  require('../admin/app').start();
  return;
}

const RAIL_WIDTH = 0; // Seitenleiste ersetzt durch das Dock
const DOCK_SPACE = { s: 80, m: 96, l: 112 };
const TOOL_PAGES = ['translate', 'calc', 'convert', 'currency', 'weather', 'notes', 'timer', 'password', 'clipboard', 'worldclock', 'autoclick', 'shield', 'schematics', 'account', 'football', 'screentime', 'speed', 'phone', 'keyboard', 'airplay', 'backgrounds', 'desktop'].map((x) => `tool-${x}`);
const TOPBAR_HEIGHT = 48;

app.setName('Revulution Hub');
// CPU/RAM: Chromium darf versteckte Apps wieder drosseln. Nur der Gaming Hub (Clips, Facecam)
// und die Chats (Anrufe) laufen ungedrosselt weiter – das steht direkt an ihren Ansichten.
app.commandLine.appendSwitch('disable-features', 'IntensiveWakeUpThrottling');
// Ein Vollbild-Spiel verdeckt das Hub-Fenster. Ohne diesen Schalter hält Chromium dann die
// Bilder des Gaming Hubs an – Kill- und Sieg-Erkennung (Auto-Clips) bekamen keine Bilder mehr.
// Muss vor „ready“ stehen; im Gaming-Hub-Modul selbst wirkt er zu spät.
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.setPath('userData', process.env.REVOLUTION_HUB_PROFILE || path.join(app.getPath('appData'), 'Revolution Hub'));
if (process.platform === 'win32') app.setAppUserModelId('com.revolution.hub');

// One hub at a time: the overlays, hotkeys and tray must not exist twice.
if (!app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}

// revulution://open/<seite> – damit die Island (Anruf, Nachrichten) den Hub öffnen kann.
try {
  if (process.defaultApp) app.setAsDefaultProtocolClient('revulution', process.execPath, [path.resolve(process.argv[1] || '.')]);
  else app.setAsDefaultProtocolClient('revulution');
} catch {
  /* ohne Link funktioniert der Rest trotzdem */
}

/* ------------------------------------------------------------------ settings */

const WALLPAPERS = ['nebula', 'aurora', 'galaxy', 'synthwave', 'liquid', 'silk', 'waves', 'ocean', 'clouds', 'mountains', 'fireflies', 'bokeh', 'lava', 'warp'];

const DEFAULT_SETTINGS = {
  autoStart: false,
  closeToTray: true,
  orbitWithHub: true,
  startPage: 'home',
  lastPage: 'home',
  trayHintShown: false,
  wallpaper: 'nebula',
  wallpaperDim: 0.45,
  wallpaperIsland: false,
  backdropBlur: true,
  backdropBlurAmount: 18,
  backdropDim: 0.14,
  widgets: { sysLive: true, upcoming: true, screentime: true, speed: true },
  desktopWidgets: { enabled: true, clock: true, system: true, screentime: false, upcoming: false, music: true, calendar: true, face: true, cards: true, vinyl: true },
  sounds: true,
  soundVolume: 0.5,
  lang: '',
  dock: { pos: 'bottom', size: 'm', items: null, magnify: true },
  replaceTaskbar: false,
  taskbarStyle: 'top',
  updateAuto: true,
  muteWinNotify: true,
  updateUrl: '',
  dnd: false,
  notes: '',
  favoriteApps: [],
  topbarItems: ['crosshair', 'screentime', 'speed'],
  crosshairOn: false,
};

const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');

function readSettings() {
  try {
    const raw = JSON.parse(fs.readFileSync(settingsFile(), 'utf8'));
    return { ...DEFAULT_SETTINGS, ...raw, widgets: { ...DEFAULT_SETTINGS.widgets, ...(raw.widgets || {}) }, desktopWidgets: { ...DEFAULT_SETTINGS.desktopWidgets, ...(raw.desktopWidgets || {}) } };
  } catch {
    return { ...DEFAULT_SETTINGS, widgets: { ...DEFAULT_SETTINGS.widgets }, desktopWidgets: { ...DEFAULT_SETTINGS.desktopWidgets } };
  }
}

let settings = readSettings();
// Alte Installationen hatten nur das Crosshair in der oberen Leiste. Einmalig
// auf die vollständige Standardbelegung heben, damit WLAN-Test & Co. da sind.
if (Array.isArray(settings.topbarItems) && settings.topbarItems.length === 1 && settings.topbarItems[0] === 'crosshair') {
  settings.topbarItems = ['crosshair', 'screentime', 'speed'];
}

/* ------------------------------------------------------------------ Sprache */
// Ganze App dreisprachig: der Hub und alle Apps übersetzen ihre Oberfläche zur Laufzeit.
let translatorCode = '';
function translatorScript() {
  if (!translatorCode) {
    try {
      translatorCode = fs.readFileSync(path.join(APP_ROOT, 'src', 'shared', 'i18n-dict.js'), 'utf8') + '\n' + fs.readFileSync(path.join(APP_ROOT, 'src', 'shared', 'translate.js'), 'utf8');
    } catch {
      translatorCode = '';
    }
  }
  return `${translatorCode}\n;window.RevTranslate && window.RevTranslate.set(${JSON.stringify(currentLang())});`;
}
function currentLang() {
  if (['de', 'en', 'es'].includes(settings.lang)) return settings.lang;
  const loc = String(app.getLocale?.() || 'de').slice(0, 2);
  return ['de', 'en', 'es'].includes(loc) ? loc : 'en';
}

/* OpenRGB-Effekt-Einstellungen prüfen. */
function cleanRgb(raw = {}) {
  const ids = RGB_EFFECTS.map(([id]) => id);
  const hex = (v, fallback) => (/^#[0-9a-f]{6}$/i.test(String(v || '')) ? String(v) : fallback);
  return {
    effect: ids.includes(raw.effect) ? raw.effect : 'wave',
    color: hex(raw.color, '#ff3b30'),
    color2: hex(raw.color2, '#00d5ff'),
    speed: Math.max(1, Math.min(100, Math.round(Number(raw.speed) || 55))),
    brightness: Math.max(0, Math.min(100, Math.round(Number(raw.brightness) || 100))),
    autoConnect: raw.autoConnect !== false,
  };
}

/* Display-Vorlagen der AJAZZ-Tastatur prüfen. */
function cleanScreen(raw = {}) {
  const presets = ['clock', 'text', 'messages', 'rainbow', 'pulse', 'pc'];
  return {
    preset: presets.includes(raw.preset) ? raw.preset : 'clock',
    text: String(raw.text ?? 'Revolution Hub').slice(0, 200),
    slot: [1, 2, 3].includes(Number(raw.slot)) ? Number(raw.slot) : 1,
    color: /^#[0-9a-f]{6}$/i.test(String(raw.color || '')) ? String(raw.color) : '#ff3b30',
    autoMessages: raw.autoMessages === true,
    autoClock: raw.autoClock === true,
  };
}

function saveSettings(patch) {
  settings = { ...settings, ...patch };
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch (error) {
    console.error('[hub] could not save settings', error);
  }
  return settings;
}

function applyAutoStart() {
  if (!app.isPackaged || process.platform !== 'win32') return;
  app.setLoginItemSettings({ openAtLogin: Boolean(settings.autoStart), path: process.execPath, args: ['--hidden'] });
}

let clickClipCache = null;
function clickClip() {
  if (settings.clickSound !== 'kq') return '';
  if (clickClipCache === null) {
    try {
      clickClipCache = fs.readFileSync(path.join(__dirname, '..', 'shared', 'assets', 'click-kq.mp3')).toString('base64');
    } catch {
      clickClipCache = '';
    }
  }
  return clickClipCache;
}

let clickPackCache = null;
function clickPack() {
  if ((settings.clickSound || 'nothing') !== 'nothing') return null;
  if (!clickPackCache) {
    clickPackCache = {};
    for (const k of ['tap', 'close', 'toggle', 'error', 'success', 'notify']) {
      try {
        clickPackCache[k] = fs.readFileSync(path.join(__dirname, '..', 'shared', 'assets', 'ui', `${k}.ogg`)).toString('base64');
      } catch {
        /* fehlt – dann der synthetische Klick */
      }
    }
  }
  return clickPackCache;
}

function appearance() {
  return { sounds: settings.sounds, volume: settings.soundVolume, clickSound: settings.clickSound || 'nothing', clickClip: clickClip(), clickPack: clickPack(), wallpaper: settings.wallpaper, dim: settings.wallpaperDim, lang: currentLang() };
}

/* ------------------------------------------------------------------- modules */

function readVersion(dir) {
  try {
    return JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).version || '1.0.0';
  } catch {
    return '1.0.0';
  }
}

const appData = app.getPath('appData');
const hubData = (name) => path.join(app.getPath('userData'), name);

// The hub paints one live wallpaper behind everything; the apps are made see-through.
const DROPZONE_CSS = `
html, body, #root { background: transparent !important; }
.app-shell { background: transparent !important; border: 0 !important; border-radius: 0 !important; box-shadow: none !important; }
.wallpaper-layer { display: none !important; }
section.panel:has(.wp-name) { display: none !important; }
.titlebar .win-btn, .titlebar .mx-1\\.5.h-4.w-px { display: none !important; }
.hub-copy-path { display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 11px; margin-right: 8px;
  border-radius: 8px; border: 1px solid var(--line-2); background: color-mix(in srgb, var(--surface-2) 70%, transparent);
  color: var(--text); font-size: 12px; font-weight: 600; cursor: pointer; transition: background .15s, border-color .15s; }
.hub-copy-path:hover { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 45%, transparent); }
.hub-copy-path svg { width: 14px; height: 14px; }
.hub-copy-crumb { flex: none; display: inline-grid; place-items: center; width: 28px; height: 28px; margin-left: 6px; border-radius: 8px;
  border: 1px solid var(--line-2); background: color-mix(in srgb, var(--surface-2) 70%, transparent); color: var(--text); cursor: pointer;
  transition: background .15s, border-color .15s, transform .1s; -webkit-app-region: no-drag; }
.hub-copy-crumb:hover { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 45%, transparent); }
.hub-copy-crumb:active { transform: scale(.92); }
.hub-copy-crumb.done { border-color: #3ddc97; color: #3ddc97; }
.hub-copy-crumb svg { width: 14px; height: 14px; }
`;

// "Pfad kopieren": copies the selected items, or the open folder when nothing is selected.
const DROPZONE_SCRIPT = `(() => {
  if (window.__hubCopyPath) return;
  window.__hubCopyPath = true;
  const ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
  function paths() {
    const store = window.__dropzoneStore;
    if (!store) return [];
    const state = store.getState();
    const pane = state.panes[state.activePane];
    const tab = pane.tabs.find((t) => t.id === pane.activeId) || pane.tabs[0];
    const selection = Array.from(tab.selection || []);
    return selection.length ? selection : tab.path ? [tab.path] : [];
  }
  function copy() {
    const list = paths();
    if (!list.length) return;
    const text = list.join('\\r\\n');
    if (window.dropzone && window.dropzone.copyText) window.dropzone.copyText(text);
    else navigator.clipboard.writeText(text).catch(() => {});
    const state = window.__dropzoneStore.getState();
    if (state.toast) state.toast(list.length > 1 ? list.length + ' Pfade kopiert' : 'Pfad kopiert: ' + list[0], 'ok');
  }
  function mount() {
    const bar = document.querySelector('.titlebar .no-drag.flex');
    if (!bar || bar.querySelector('.hub-copy-path')) return;
    const button = document.createElement('button');
    button.className = 'hub-copy-path';
    button.title = 'Pfad der Auswahl kopieren – ohne Auswahl den Pfad des Ordners (Strg+Umschalt+C)';
    button.innerHTML = ICON + '<span>Pfad kopieren</span>';
    button.addEventListener('click', copy);
    bar.insertBefore(button, bar.firstChild);
  }
  // Zusätzlich: ein Kopier-Knopf direkt neben der Pfadleiste jedes Fensterteils
  function copyPane(index, button) {
    const store = window.__dropzoneStore;
    if (!store) return copy();
    const state = store.getState();
    const panes = Array.isArray(state.panes) ? state.panes : Object.values(state.panes || {});
    const pane = panes[index] || state.panes[state.activePane];
    const tab = pane && (pane.tabs.find((t) => t.id === pane.activeId) || pane.tabs[0]);
    if (!tab || !tab.path) return copy();
    if (window.dropzone && window.dropzone.copyText) window.dropzone.copyText(tab.path);
    else navigator.clipboard.writeText(tab.path).catch(() => {});
    if (state.toast) state.toast('Pfad kopiert: ' + tab.path, 'ok');
    button.classList.add('done');
    setTimeout(() => button.classList.remove('done'), 900);
  }
  function mountCrumbs() {
    document.querySelectorAll('.crumbs').forEach((crumbs, index) => {
      const next = crumbs.nextElementSibling;
      if (next && next.classList.contains('hub-copy-crumb')) return;
      const button = document.createElement('button');
      button.className = 'hub-copy-crumb';
      button.title = 'Pfad dieses Ordners kopieren';
      button.innerHTML = ICON;
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        copyPane([...document.querySelectorAll('.crumbs')].indexOf(crumbs), button);
      });
      crumbs.insertAdjacentElement('afterend', button);
    });
  }
  let pending = 0;
  const mountAll = () => {
    if (pending) return;
    pending = requestAnimationFrame(() => {
      pending = 0;
      mount();
      mountCrumbs();
    });
  };
  new MutationObserver(mountAll).observe(document.documentElement, { childList: true, subtree: true });
  mountAll();
  window.addEventListener('keydown', (event) => {
    if (event.ctrlKey && event.shiftKey && !event.altKey && event.key.toLowerCase() === 'c') {
      const target = event.target;
      if (target && (target.isContentEditable || /^(input|textarea)$/i.test(target.tagName))) return;
      event.preventDefault();
      copy();
    }
  }, true);
})();`;

const GAMING_CSS = `
body { background: transparent !important; }
.wall, .wall-shade { display: none !important; }
.card:has(#wall-grid) { display: none !important; }
.win-controls { display: none !important; }
[data-view="music"] { display: none !important; }
.app { background: rgba(8, 9, 13, 0.34); }
`;

// The hub plays the click sounds and the wallpaper for every app.
const GAMING_SCRIPT = `(() => {
  try { playClick = function () {}; } catch (e) {}
  try { applyWallpaper = function () {}; } catch (e) {}
  const video = document.getElementById('wall');
  if (video) { video.pause(); video.removeAttribute('src'); video.load(); }
})();`;

const MODULES = [
  {
    id: 'dropzone',
    name: 'Dropzone by Revulution',
    dir: path.join(APP_ROOT, 'modules', 'dropzone'),
    entry: path.join('dist', 'main', 'main.cjs'),
    dataDir: path.join(appData, 'Dropzone by Revolution'),
    lazy: true,
    css: DROPZONE_CSS,
    script: DROPZONE_SCRIPT,
  },
  {
    id: 'gaming',
    name: 'Revulution Gaming Hub',
    dir: path.join(APP_ROOT, 'modules', 'gaming-hub'),
    entry: path.join('app', 'main.js'),
    dataDir: path.join(appData, 'Revolution Gaming Hub'),
    // Crosshair, clips and overlays run all the time, so this one loads at start.
    lazy: false,
    css: GAMING_CSS,
    script: GAMING_SCRIPT,
  },
  { id: 'screenshot', name: 'Screenshot', dir: path.join(APPS_DIR, 'screenshot'), entry: 'main.js', dataDir: hubData('screenshot'), lazy: true },
  { id: 'video', name: 'Video-Schnitt', dir: path.join(APPS_DIR, 'video'), entry: 'main.js', dataDir: hubData('video'), lazy: true },
  { id: 'beat', name: 'Beat Lab', dir: path.join(APPS_DIR, 'beat'), entry: 'main.js', dataDir: hubData('beat'), lazy: true },
  { id: 'docs', name: 'Dokumente', dir: path.join(APPS_DIR, 'docs'), entry: 'main.js', dataDir: hubData('docs'), lazy: true },
  { id: 'chess', name: 'Schach-Coach', dir: path.join(APPS_DIR, 'chess'), entry: 'main.js', dataDir: hubData('chess'), lazy: true, ownI18n: true },
  // Agenda läuft immer (Erinnerungen), die Ansicht ist klein.
  { id: 'agenda', name: 'Agenda', dir: path.join(APPS_DIR, 'agenda'), entry: 'main.js', dataDir: hubData('agenda'), lazy: false },
  // Chats laufen immer mit, damit Nachrichten (Island, roter Punkt) auch ohne Öffnen ankommen.
  { id: 'chats', name: 'Chats', dir: path.join(APPS_DIR, 'chats'), entry: 'main.js', dataDir: hubData('chats'), lazy: false },
  { id: 'geo', name: 'GeoRevulution', dir: path.join(APPS_DIR, 'geo'), entry: 'main.js', dataDir: hubData('geo'), lazy: true, ownI18n: true },
];
for (const mod of MODULES) {
  mod.partition = `persist:${mod.id}`;
  mod.version = mod.dir.startsWith(APPS_DIR) ? app.getVersion() : readVersion(mod.dir);
  mod.error = null;
}
const moduleById = (id) => MODULES.find((mod) => mod.id === id);

/* ----------------------------------------------------------------------- hub */

const PAGES = new Set(['home', 'orbit', 'settings', 'shop', ...TOOL_PAGES, ...MODULES.map((mod) => mod.id)]);

/** Aktueller Screenshot-Hotkey (aus den Einstellungen der Screenshot-App), lesbar formatiert. */
function screenshotHotkey() {
  let key = 'CommandOrControl+Shift+X';
  try {
    const saved = JSON.parse(fs.readFileSync(path.join(hubData('screenshot'), 'settings.json'), 'utf8'));
    if (typeof saved.hotkey === 'string') key = saved.hotkey;
  } catch {
    /* Standard */
  }
  if (!key) return '';
  return key
    .split('+')
    .map((part) => ({ CommandOrControl: 'Strg', CmdOrCtrl: 'Strg', Control: 'Strg', Ctrl: 'Strg', Shift: 'Umschalt', Alt: 'Alt', Super: 'Win', Meta: 'Win', PrintScreen: 'Druck' })[part] || part)
    .join('+');
}

const hub = {
  window: null,
  tray: null,
  active: 'home',
  views: new Map(),
  opened: new Set(),
  moduleTrays: new Map(),
  quitting: false,
  visible: new Map(),

  wasOpened(id) {
    return this.opened.has(id);
  },

  attachView(view) {
    this.views.set(view.mod.id, view);
    if (this.window) this.window.contentView.addChildView(view.view);
    dockToTop();
    if (this.opened.has(view.mod.id)) view.ensureLoaded();
    // Chats laufen im Hintergrund mit, sobald man sie einmal benutzt hat – sonst
    // kämen neue Nachrichten erst an, wenn man den Bereich öffnet.
    else if (view.mod.id === 'chats' && settings.chatsUsed) setTimeout(() => view.ensureLoaded(), 4000);
    this.layout();
  },

  viewForContents(contents) {
    for (const view of this.views.values()) if (view.webContents === contents) return view;
    return null;
  },

  open(id) {
    if (!PAGES.has(id)) return;
    const changed = this.active !== id;
    this.active = id;
    const view = this.views.get(id);
    if (view) {
      this.opened.add(id);
      view.ensureLoaded();
    }
    // Zuletzt benutzt (bleibt nach dem Neustart erhalten)
    const recent = id === 'home' || id === 'settings' ? settings.recentApps || [] : [id, ...(settings.recentApps || []).filter((x) => x !== id)].slice(0, 8);
    saveSettings({ lastPage: id, recentApps: recent, openedPages: [...this.opened].slice(0, 20), ...(id === 'chats' && !settings.chatsUsed ? { chatsUsed: true } : {}) });
    this.layout();
    this.showWindow();
    if (view) {
      view.webContents.focus();
      if (changed) this.revealView(view);
    }
    this.pushState();
  },

  revealView(view) {
    if (!view || view.webContents.isDestroyed()) return;
    view.webContents
      .executeJavaScript(
        "document.documentElement.classList.remove('nt-app-enter');void document.documentElement.offsetWidth;document.documentElement.classList.add('nt-app-enter')",
        true,
      )
      .catch(() => {});
  },

  layout() {
    if (!this.window || this.window.isDestroyed()) return;
    const [width, height] = this.window.getContentSize();
    // Platz für das schwebende Dock frei lassen (unten, oben, links oder rechts)
    const dock = settings.dock || {};
    const space = DOCK_SPACE[dock.size] || DOCK_SPACE.m;
    const pos = ['bottom', 'top', 'left', 'right'].includes(dock.pos) ? dock.pos : 'bottom';
    const bounds = { x: RAIL_WIDTH, y: TOPBAR_HEIGHT, width: Math.max(0, width - RAIL_WIDTH), height: Math.max(0, height - TOPBAR_HEIGHT) };
    // Das Dock liegt als eigene Ebene darüber: die Apps bekommen die volle Fläche.
    layoutDock(bounds, pos);
    if (dockView && dockAlive) {
      /* volle Fläche */
    } else if (pos === 'bottom') bounds.height = Math.max(0, bounds.height - space);
    if (dockView && dockAlive) {
      /* nichts abziehen */
    } else if (pos === 'top') {
      bounds.y += space;
      bounds.height = Math.max(0, bounds.height - space);
    }
    if (!(dockView && dockAlive) && pos === 'left') {
      bounds.x += space;
      bounds.width = Math.max(0, bounds.width - space);
    }
    if (!(dockView && dockAlive) && pos === 'right') bounds.width = Math.max(0, bounds.width - space);
    const windowShown = this.window.isVisible() && !this.window.isMinimized();
    for (const [id, view] of this.views) {
      view.view.setBounds(bounds);
      // Starter, Kontrollzentrum usw. liegen im Hub-Fenster – solange sie offen sind, App ausblenden
      view.view.setVisible(id === this.active && !this.overlay);
      // Apps pause live work (e.g. the system sampler) while they are not on screen.
      const shown = windowShown && id === this.active;
      if (this.visible.get(id) !== shown) {
        this.visible.set(id, shown);
        if (!view.isDestroyed()) view.webContents.send('hub:visibility', shown);
        view.emit('hub-visibility', shown);
      }
    }
  },

  showWindow() {
    if (!this.window || this.window.isDestroyed()) return;
    if (this.window.isMinimized()) this.window.restore();
    if (!this.window.isVisible()) this.window.show();
    this.window.focus();
  },

  quit() {
    this.quitting = true;
    app.quit();
  },

  /**
   * One place for every message of the ecosystem: while Orbit Island runs it shows the
   * message (with the app's icon), otherwise Windows does.
   */
  islandRunning() {
    return Boolean(orbit.running);
  },

  notify(title, body, { open = '', app = 'Revulution Hub', icon = ICON, accent = '', glyph = '' } = {}) {
    if (settings.dnd) return; // Nicht stören
    if (orbit.running && orbit.post({ title, message: body || '', app, icon, open, ...(accent ? { accent } : {}), ...(glyph ? { glyph } : {}) })) return;
    if (!Notification.isSupported()) return;
    const note = new Notification({ title, body, icon: ICON });
    if (open) note.on('click', () => shell.openPath(open));
    note.show();
  },

  registerModuleTray(id, tray) {
    this.moduleTrays.set(id, tray);
  },

  refreshTray() {
    if (this.tray && !this.tray.isDestroyed()) this.tray.setContextMenu(buildTrayMenu());
  },

  state() {
    return {
      lang: currentLang(),
      active: this.active,
      maximized: Boolean(this.window?.isMaximized()),
      modules: MODULES.map((mod) => ({
        id: mod.id,
        name: mod.name,
        version: mod.version,
        error: mod.error,
        ready: Boolean(this.views.get(mod.id)?.ready),
      })),
      orbit: { available: orbit.available(), running: orbit.running },
      opened: [...this.opened],
      gameMode: Boolean(settings.gameMode),
      keepAwake: Boolean(settings.keepAwake),
      keepAwakeUntil: Number(settings.keepAwakeUntil) || 0,
      screenshotHotkey: screenshotHotkey(),
      upcoming: global.__revolutionHub?.agenda?.upcoming?.() || [],
      badges: { ...badges },
      dockExternal: Boolean(dockView && dockAlive),
      win: this.window && !this.window.isDestroyed() ? (([w, h]) => ({ w, h: h - TOPBAR_HEIGHT }))(this.window.getContentSize()) : null,
      settings,
      wallpapers: WALLPAPERS,
      wallpaperDir: WALLPAPER_DIR,
      desktopBackdrop: backdropCache.path || '',
      camera: cameraState,
      version: app.getVersion(),
    };
  },

  /** Profil (Name, Punkte, Cosmetics) an Hub-Oberfläche und alle Apps schicken. */
  pushProfile() {
    const p = hubProfile();
    if (this.window && !this.window.isDestroyed()) this.window.webContents.send('hub:profile', p);
    const js = `window.dispatchEvent(new CustomEvent('hub-profile', { detail: ${JSON.stringify(p)} }))`;
    for (const view of this.views.values()) if (!view.webContents.isDestroyed()) view.webContents.executeJavaScript(js, true).catch(() => {});
  },

  pushState() {
    if (!this.window || this.window.isDestroyed()) return;
    const st = this.state();
    this.window.webContents.send('hub:state', st);
    if (dockView && !dockView.webContents.isDestroyed()) dockView.webContents.send('hub:state', st);
    sendWidgets('hub:state', st);
    broadcastTaskbar();
  },

  pushAppearance() {
    const payload = appearance();
    for (const view of this.views.values()) if (!view.isDestroyed()) view.webContents.send('hub:appearance', payload);
  },

  /** Neue Sprache an den Hub und alle Apps weitergeben. */
  applyLang() {
    const lang = currentLang();
    this.window?.webContents.executeJavaScript(`window.RevTranslate && window.RevTranslate.set(${JSON.stringify(lang)})`, true).catch(() => {});
    for (const [id, view] of this.views) {
      if (view.isDestroyed()) continue;
      const mod = moduleById(id);
      const code = mod?.ownI18n
        ? `window.dispatchEvent(new CustomEvent('hub-lang', { detail: ${JSON.stringify(lang)} }))`
        : `window.RevTranslate ? window.RevTranslate.set(${JSON.stringify(lang)}) : 0`;
      view.webContents.executeJavaScript(code, true).catch(() => {});
    }
    this.pushAppearance();
  },
  translatorScript: () => translatorScript(),
  currentLang: () => currentLang(),

  /** Lets an app inside the hub run a hub action (e.g. hide the window for a screenshot). */
  api: {},

  /** Data folder of another area, so the apps can share files (e.g. Gaming Hub clips → Video). */
  moduleDataDir(id) {
    return moduleById(id)?.dataDir || '';
  },
};

/* ------------------------------------------------------------- Hub-Profil */
// Ein Profil für alle Apps: Anzeigename, Punkte (◆) und Cosmetics.
const RevCos = require('../shared/cosmetics.js');
const defaultProfile = () => ({ name: '', points: 0, cos: { owned: {}, eq: {} }, migrated: false });
function hubProfile() {
  const p = { ...defaultProfile(), ...(settings.profile || {}) };
  p.cos = { owned: { ...(p.cos?.owned || {}) }, eq: { ...(p.cos?.eq || {}) } };
  return p;
}
const cleanName = (v) => String(v || '').trim().replace(/\s+/g, ' ').slice(0, 16);
const profileApi = {
  get: () => hubProfile(),
  save(p) {
    saveSettings({ profile: p, profileAt: Date.now() });
    hub.pushProfile();
    accountChanged();
    return p;
  },
  setName(name) {
    const p = hubProfile();
    const v = cleanName(name);
    if (v.length < 2) return p;
    p.name = v;
    return this.save(p);
  },
  earn(amount) {
    const n = Math.max(0, Math.min(1000, Math.round(Number(amount) || 0)));
    const p = hubProfile();
    p.points += n;
    return this.save(p);
  },
  buy(slot, id) {
    const p = hubProfile();
    const it = RevCos.COSMETICS[slot]?.find((x) => x.id === id);
    if (!it) throw new Error('Unbekannter Artikel');
    const owned = it.price === 0 || (p.cos.owned[slot] || []).includes(id);
    if (!owned) {
      if (p.points < it.price) throw new Error('Nicht genug Punkte');
      p.points -= it.price;
      p.cos.owned[slot] = [...(p.cos.owned[slot] || []), id];
    }
    if (!(it.custom && !p.cos.eq.img)) p.cos.eq[slot] = id;
    return this.save(p);
  },
  equip(slot, id) {
    const p = hubProfile();
    const it = RevCos.COSMETICS[slot]?.find((x) => x.id === id);
    if (!it || !(it.price === 0 || (p.cos.owned[slot] || []).includes(id))) return p;
    p.cos.eq[slot] = id;
    return this.save(p);
  },
  setImage(dataUrl) {
    const p = hubProfile();
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/') || dataUrl.length > 60000) throw new Error('Bild zu groß');
    if (!(p.cos.owned.avatar || []).includes('custom')) throw new Error('Erst im Shop freischalten');
    p.cos.eq.img = dataUrl;
    p.cos.eq.avatar = 'custom';
    return this.save(p);
  },
  /** Einmalig: Punkte, Name und Cosmetics aus dem alten Schach-Profil übernehmen. */
  migrate(old) {
    const p = hubProfile();
    if (p.migrated) return p;
    p.migrated = true;
    if (old && typeof old === 'object') {
      if (!p.name && old.name) p.name = cleanName(old.name);
      p.points += Math.max(0, Math.min(100000, Number(old.points) || 0));
      for (const [slot, list] of Object.entries(old.cos?.owned || {})) if (RevCos.COSMETICS[slot] && Array.isArray(list)) p.cos.owned[slot] = [...new Set([...(p.cos.owned[slot] || []), ...list.filter((x) => typeof x === 'string')])];
      for (const [slot, id] of Object.entries(old.cos?.eq || {})) if (typeof id === 'string' && (RevCos.COSMETICS[slot] || slot === 'img')) p.cos.eq[slot] = id;
    }
    return this.save(p);
  },
};

/* ------------------------------------------------- Dock als eigene Ebene
 * Die Apps sind eigene Ebenen über der Hub-Oberfläche. Damit sie auch hinter dem Dock
 * weiterlaufen, liegt das Dock in einer kleinen, durchsichtigen Ebene ganz oben. Sie ist nur
 * so groß wie das Dock (beim Darüberfahren etwas größer – für Vergrößerung und Namen). */
let dockView = null;
let dockAlive = false; // erst wenn die Dock-Ebene sich gemeldet hat, verschwindet das alte Dock
let dockSize = { w: 96, h: 700, expanded: false };
function createDockView() {
  if (dockView || !hub.window) return;
  // einmalig: Dock standardmässig rechts
  // einmalig: Dock unten (über den Apps)
  // einmalig: Fußball-App ins Dock
  if (!settings.dockFootballV1) {
    const items = Array.isArray(settings.dock?.items) ? settings.dock.items : null;
    saveSettings({ dock: { ...(settings.dock || {}), ...(items && !items.includes('tool-football') ? { items: [...items.slice(0, 10), 'tool-football', ...items.slice(10)] } : {}) }, dockFootballV1: true });
  }
  if (!settings.dockBottomV2) saveSettings({ dock: { ...(settings.dock || {}), pos: 'bottom' }, dockBottomV2: true });
  const { WebContentsView } = require('electron');
  dockView = new WebContentsView({ webPreferences: { preload: path.join(APP_ROOT, 'src', 'preload', 'hub-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false, spellcheck: false } });
  dockView.setBackgroundColor('#00000000');
  hub.window.contentView.addChildView(dockView);
  dockView.webContents.loadFile(path.join(UI_DIR, 'dock.html'));
  dockView.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  hub.layout();
}
function dockToTop() {
  if (dockView && hub.window && !hub.window.isDestroyed()) hub.window.contentView.addChildView(dockView);
}
function layoutDock(area, pos) {
  if (!dockView) return;
  // Im Taskleisten-Modus übernimmt die neue Desktop-Leiste; das interne Dock
  // bleibt nur als Modellquelle im Hintergrund und wird nicht doppelt gezeigt.
  if (settings.replaceTaskbar) return dockView.setBounds({ x: 0, y: 0, width: 1, height: 1 });
  if (!dockAlive) return dockView.setBounds({ x: 0, y: 0, width: 1, height: 1 });
  const w = Math.min(area.width, Math.max(40, Math.round(dockSize.w)));
  const h = Math.min(area.height, Math.max(40, Math.round(dockSize.h)));
  let x = area.x + Math.round((area.width - w) / 2), y = area.y + area.height - h;
  if (pos === 'top') y = area.y;
  if (pos === 'left' || pos === 'right') {
    y = area.y + Math.round((area.height - h) / 2);
    x = pos === 'left' ? area.x : area.x + area.width - w;
  }
  dockView.setBounds({ x, y, width: w, height: h });
}
let taskbarWindows = [];
let taskbarWatch = null;
let winKeyWatch = null;
let taskbarFullscreen = false;
let hubImmersive = false; // Video/Seite im Hub im Vollbild
let taskbarDrawerOpen = false;
let taskbarPanelKind = 'drawer';
let taskbarDrawerDisplayId = null;
const TASKBAR_PAGE = path.join(UI_DIR, 'taskbar.html');
const taskbarStyle = () => 'top';
const TASKBAR_TITLES = { home: 'Revulution Hub', settings: 'Einstellungen', shop: 'Shop', orbit: 'Island', gaming: 'Gaming Hub', dropzone: 'Dateien' };

function taskbarTitle(id) {
  if (TASKBAR_TITLES[id]) return TASKBAR_TITLES[id];
  return moduleById(id)?.name || dockModel?.items?.find((item) => item.id === id)?.tip || 'Revulution Hub';
}

function taskbarPayload(side, drawer = false) {
  const fallback = (settings.dock?.items || []).map((id) => ({ id, tip: taskbarTitle(id), active: hub.active === id, badge: badges[id] || 0 }));
  const items = (dockModel?.items?.length ? dockModel.items : fallback).slice(0, 16).map((item) => ({
    id: item.id,
    tip: item.tip || taskbarTitle(item.id),
    active: Boolean(item.active),
    badge: Number(item.badge) || 0,
  }));
  return {
    style: 'top',
    side,
    drawer: Boolean(drawer),
    active: hub.active,
    activeTitle: taskbarTitle(hub.active),
    items,
    windowsApps: [
      // Der Hub selbst steht wie jede andere offene App in der Leiste.
      ...(hub.window && !hub.window.isDestroyed() && hub.window.isVisible() ? [{ id: 'hub:self', name: 'Revulution Hub', icon: 'assets/mark.png', kind: 'running', title: 'Revulution Hub', self: true, focused: hub.window.isFocused() }] : []),
      ...windowsTaskbar.list().map((item) => ({ id: item.id, name: item.name, icon: item.icon, kind: item.kind, title: item.title || item.name })),
    ],
    badges: Object.keys(badges).length > 0,
    dnd: Boolean(settings.dnd),
    topbarItems: settings.topbarItems || ['crosshair', 'screentime', 'speed'],
    // Nur der Monitor, auf dem das Menü geöffnet wurde, zeigt es an.
    panel: drawer ? taskbarPanelKind : '',
    crosshairOn: crosshairIsOn(),
    lang: currentLang(),
    version: app.getVersion(),
  };
}

function refreshWindowsTaskbar() {
  windowsTaskbar.refresh().then(() => broadcastTaskbar()).catch(() => {});
}

function sendTaskbar(win) {
  if (!win || win.isDestroyed() || win.webContents.isDestroyed()) return;
  const drawer = taskbarDrawerOpen && win.__taskbar?.displayId === taskbarDrawerDisplayId;
  win.webContents.send('hub:taskbar', taskbarPayload(win.__taskbar?.side || 'full', drawer));
}

function broadcastTaskbar() {
  for (const win of taskbarWindows) sendTaskbar(win);
}

function taskbarShouldShow(win) {
  if (!settings.replaceTaskbar || taskbarFullscreen || hubImmersive) return false;
  return true;
}

function updateTaskbarVisibility() {
  for (const win of taskbarWindows) {
    if (!win || win.isDestroyed()) continue;
    const show = taskbarShouldShow(win);
    if (show && !win.isVisible()) win.showInactive();
    if (!show && win.isVisible()) win.hide();
  }
}

const TASKBAR_WIN_HEIGHT = 350;
function createTaskbarWindow(display, side) {
  const width = display.bounds.width;
  // Feste Höhe: das Fenster wird beim Öffnen des Menüs nicht mehr vergrößert (das flackerte).
  // Der leere, transparente Teil lässt Klicks durch (setIgnoreMouseEvents unten).
  const height = TASKBAR_WIN_HEIGHT;
  const x = display.bounds.x;
  // 2.26: die Leiste sitzt unten in der Mitte (wie das Mac-Dock); das Fenster hängt am unteren Rand.
  const y = display.bounds.y + display.bounds.height - height;
  const win = new BrowserWindow({
    x,
    y,
    width,
    height,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    focusable: true,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    title: 'Revulution Taskbar',
    webPreferences: {
      preload: path.join(APP_ROOT, 'src', 'preload', 'hub-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });
  win.__taskbar = { side: 'full', displayId: display.id, displayBounds: { ...display.bounds } };
  // Klick-Durchlass erst NACH dem Anzeigen setzen – vorher zeichnet Electron das
  // transparente Fenster grau (Electron-Fehler, getestet).
  win.once('show', () => setTimeout(() => !win.isDestroyed() && win.setIgnoreMouseEvents(true, { forward: true }), 150));
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setSkipTaskbar(true);
  win.loadFile(TASKBAR_PAGE);
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('did-finish-load', () => {
    sendTaskbar(win);
    if (taskbarShouldShow(win)) win.showInactive();
  });
  win.once('ready-to-show', () => {
    sendTaskbar(win);
    if (taskbarShouldShow(win)) win.showInactive();
  });
  win.on('closed', () => {
    taskbarWindows = taskbarWindows.filter((entry) => entry !== win);
  });
  taskbarWindows.push(win);
  return win;
}

/* --------------------------------------------------------------- Client-Fenster */
let clientWindow = null;

function closeClientWindow() {
  const win = clientWindow;
  clientWindow = null;
  try {
    if (win && !win.isDestroyed()) win.destroy();
  } catch {
    /* bereits geschlossen */
  }
}

function openClient(view = 'control') {
  const target = view === 'settings' ? 'settings' : 'control';
  if (clientWindow && !clientWindow.isDestroyed()) {
    clientWindow.loadFile(path.join(UI_DIR, 'client.html'), { query: { view: target } });
    clientWindow.show();
    clientWindow.focus();
    return true;
  }
  const display = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const width = 392;
  const height = Math.min(target === 'settings' ? 560 : 610, display.workArea.height - 42);
  const x = display.workArea.x + display.workArea.width - width - 14;
  const y = display.workArea.y + 28;
  const win = new BrowserWindow({
    x,
    y,
    width,
    height,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    focusable: true,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    title: 'Revulution',
    webPreferences: {
      preload: path.join(APP_ROOT, 'src', 'preload', 'hub-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });
  clientWindow = win;
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setSkipTaskbar(true);
  win.loadFile(path.join(UI_DIR, 'client.html'), { query: { view: target } });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  const show = () => {
    if (!win.isDestroyed() && !win.isVisible()) {
      win.show();
      win.focus();
    }
  };
  win.once('ready-to-show', show);
  win.webContents.on('did-finish-load', show);
  win.on('blur', () => {
    setTimeout(() => {
      if (clientWindow === win && !win.isDestroyed() && !win.isFocused()) closeClientWindow();
    }, 180);
  });
  win.on('closed', () => {
    if (clientWindow === win) clientWindow = null;
  });
  return true;
}

/* ------------------------------------------------------- Widgets auf dem Desktop */
/* Ein durchsichtiges Fenster pro Monitor (volle Fläche, auch ganz oben/unten).
   Jedes Widget gehört zu einem Monitor; beim Ziehen über den Rand wandert es mit. */
const widgetWins = new Map(); // display.id → BrowserWindow
const widgetWinList = () => [...widgetWins.values()].filter((w) => w && !w.isDestroyed());
function sendWidgets(channel, payload) {
  for (const w of widgetWinList()) if (!w.webContents.isDestroyed()) w.webContents.send(channel, payload);
}
function widgetWinFor(sender) {
  return widgetWinList().find((w) => w.webContents === sender) || null;
}

function syncDesktopWidgets() {
  const on = settings.desktopWidgets?.enabled !== false;
  const displays = on ? screen.getAllDisplays() : [];
  const want = new Set(displays.map((d) => d.id));
  for (const [id, w] of [...widgetWins]) {
    if (!want.has(id) || w.isDestroyed()) {
      widgetWins.delete(id);
      try { if (!w.isDestroyed()) w.destroy(); } catch { /* schon weg */ }
    }
  }
  const primary = screen.getPrimaryDisplay().id;
  // Widgets auf einem abgesteckten Monitor kommen zurück auf den Hauptmonitor.
  if (on) {
    const pos = { ...(settings.widgetPos || {}) };
    let fixed = false;
    for (const [id, p] of Object.entries(pos)) {
      if (p && p.d != null && !want.has(p.d)) {
        pos[id] = { x: 40, y: 80, d: primary };
        fixed = true;
      }
    }
    if (fixed) saveSettings({ widgetPos: pos });
  }
  for (const d of displays) {
    const old = widgetWins.get(d.id);
    if (old && !old.isDestroyed()) {
      const b = old.getBounds();
      if (b.x !== d.bounds.x || b.y !== d.bounds.y || b.width !== d.bounds.width || b.height !== d.bounds.height) old.setBounds(d.bounds);
      old.webContents.send('hub:state', hub.state());
      continue;
    }
    const win = new BrowserWindow({
      ...d.bounds,
      frame: false,
      transparent: true,
      backgroundColor: '#00000000',
      alwaysOnTop: false,
      skipTaskbar: true,
      focusable: false,
      resizable: false,
      movable: false,
      minimizable: false,
      maximizable: false,
      fullscreenable: false,
      hasShadow: false,
      show: false,
      webPreferences: {
        preload: path.join(APP_ROOT, 'src', 'preload', 'hub-preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
      },
    });
    win.__display = d.id;
    win.setSkipTaskbar(true);
    win.loadFile(path.join(UI_DIR, 'desktop-widgets.html'), { query: { display: String(d.id), primary: d.id === primary ? '1' : '0' } });
    win.once('ready-to-show', () => {
      if (win.isDestroyed()) return;
      win.setBounds(d.bounds);
      win.showInactive();
      // Erst nach dem Anzeigen – sonst wird das ganze Fenster grau statt durchsichtig.
      setTimeout(() => !win.isDestroyed() && win.setIgnoreMouseEvents(true, { forward: true }), 150);
      win.webContents.send('hub:state', hub.state());
      if (lastWidgetMedia) win.webContents.send('hub:media', lastWidgetMedia);
    });
    win.on('closed', () => {
      if (widgetWins.get(d.id) === win) widgetWins.delete(d.id);
      syncWidgetMedia();
    });
    widgetWins.set(d.id, win);
  }
  syncWidgetMedia();
}

/* Bilder für „Läuft gerade“: Albumcover aus dem Player; fehlt eins, das Cover über die iTunes-Suche.
   Bei YouTube (Browser ohne Album) das Kanalbild. Pro Song einmal geladen und gemerkt. */
const mediaArt = new Map(); // key → base64 ('' = nichts gefunden)
const mediaArtBusy = new Set();
const BROWSER_APP = /chrome|msedge|firefox|opera|brave|vivaldi|arc/i;
async function fetchImageB64(url) {
  const r = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36' } });
  if (!r.ok) return '';
  const buf = Buffer.from(await r.arrayBuffer());
  return buf.length > 500 && buf.length < 3 * 1024 * 1024 ? buf.toString('base64') : '';
}
async function youtubeChannelImage(channel) {
  const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(channel)}&sp=EgIQAg%253D%253D&hl=de`;
  const r = await fetch(url, { headers: { 'accept-language': 'de-DE,de;q=0.9', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36' } });
  if (!r.ok) return '';
  const html = await r.text();
  const m = html.match(/"channelRenderer":\{"channelId":"[^"]+"[\s\S]{0,600}?"thumbnails":\[\{"url":"([^"]+)"/);
  if (!m) return '';
  let img = m[1].replace(/\\u0026/g, '&');
  if (img.startsWith('//')) img = `https:${img}`;
  img = img.replace(/=s\d+-/, '=s400-');
  return fetchImageB64(img);
}
async function itunesCover(title, artist) {
  const term = `${artist || ''} ${title || ''}`.replace(/\(.*?\)|\[.*?\]|official|video|lyrics|audio/gi, ' ').replace(/\s+/g, ' ').trim();
  if (!term) return '';
  const r = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(term)}&entity=song&limit=1`);
  if (!r.ok) return '';
  const j = await r.json();
  const art = j?.results?.[0]?.artworkUrl100;
  return art ? fetchImageB64(art.replace('100x100bb', '600x600bb')) : '';
}
function mediaKey(m) {
  return `${m.app}|${m.title}|${m.artist}|${m.album}`;
}
/** Ergänzt das Bild (falls bekannt) und lädt fehlende Bilder im Hintergrund nach. */
function enrichMedia(m, resend) {
  if (!m?.title) return m;
  const key = mediaKey(m);
  const youtube = BROWSER_APP.test(String(m.app || '')) && !m.album && Boolean(m.artist);
  if (m.art && !youtube) {
    mediaArt.set(key, m.art);
    return m;
  }
  if (mediaArt.has(key)) return { ...m, art: mediaArt.get(key) || m.art };
  if (!mediaArtBusy.has(key)) {
    mediaArtBusy.add(key);
    (async () => {
      let art = '';
      try {
        art = youtube ? await youtubeChannelImage(m.artist) : await itunesCover(m.title, m.artist);
      } catch {
        art = '';
      }
      mediaArt.set(key, art || m.art || '');
      mediaArtBusy.delete(key);
      if (mediaArt.size > 200) mediaArt.delete(mediaArt.keys().next().value);
      if (art) resend({ ...m, art });
    })();
  }
  return m;
}

/* Musik-Widget: „Läuft gerade“ über die Windows-Mediensitzung – nur solange das Widget an ist. */
let widgetMedia = null;
let lastWidgetMedia = null;
function syncWidgetMedia() {
  const hubVisible = Boolean(hub.window && !hub.window.isDestroyed() && hub.window.isVisible() && !hub.window.isMinimized());
  const want = hubVisible || Boolean(widgetWinList().length && settings.desktopWidgets?.enabled !== false && settings.desktopWidgets?.music !== false);
  if (want && !widgetMedia) {
    const script = path.join(APP_ROOT, 'modules', 'gaming-hub', 'scripts', 'media-session.ps1');
    if (!fs.existsSync(script)) return;
    const proc = require('child_process').spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    widgetMedia = proc;
    let buf = '';
    proc.stdout.setEncoding('utf8');
    proc.stdout.on('data', (chunk) => {
      buf += chunk;
      const lines = buf.split(/\r?\n/);
      buf = lines.pop() || '';
      for (const line of lines) {
        if (!line.startsWith('{')) continue;
        try {
          const send = (x) => {
            lastWidgetMedia = x;
            sendWidgets('hub:media', x);
            if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:media', x);
          };
          const m = enrichMedia(JSON.parse(line), send);
          send(m);
        } catch {
          /* unvollständige Zeile */
        }
      }
    });
    proc.on('exit', () => {
      if (widgetMedia === proc) widgetMedia = null;
    });
  } else if (!want && widgetMedia) {
    const p = widgetMedia;
    widgetMedia = null;
    try {
      p.kill();
    } catch {
      /* schon weg */
    }
  }
}
app.on('before-quit', () => {
  windowsTaskbar.stop();
  try {
    widgetMedia?.kill();
  } catch {
    /* egal */
  }
});
electron.ipcMain.on('desktopWidgets:interactive', (event, on) => {
  const win = widgetWinFor(event.sender);
  if (win) win.setIgnoreMouseEvents(!on, { forward: true });
});
const WIDGET_IDS = ['clock', 'face', 'music', 'system', 'calendar', 'screen', 'upcoming'];
/* Ziehen über Monitorgrenzen: der Hauptprozess kennt die Maus überall. Auf dem Ziel-
   monitor zeigt dessen Fenster das Widget schon während des Ziehens an. */
function widgetDropPoint(dx, dy) {
  const cur = screen.getCursorScreenPoint();
  const d = screen.getDisplayNearestPoint(cur);
  const x = Math.round(cur.x - d.bounds.x - (Number(dx) || 0));
  const y = Math.round(cur.y - d.bounds.y - (Number(dy) || 0));
  return { d, x: Math.max(0, Math.min(d.bounds.width - 60, x)), y: Math.max(0, Math.min(d.bounds.height - 40, y)) };
}
electron.ipcMain.on('desktopWidgets:drag', (event, id, dx, dy, phase) => {
  const src = widgetWinFor(event.sender);
  if (!src || !WIDGET_IDS.includes(id)) return;
  const { d, x, y } = widgetDropPoint(dx, dy);
  for (const w of widgetWinList()) {
    const ghost = phase === 'move' && w.__display === d.id && w !== src ? { id, x, y } : { id, off: true };
    w.webContents.send('hub:widgetGhost', ghost);
  }
  if (phase === 'end') {
    saveSettings({ widgetPos: { ...(settings.widgetPos || {}), [id]: { x, y, d: d.id } } });
    sendWidgets('hub:state', hub.state());
  }
});

handle('desktopWidgets:set', (on) => {
  saveSettings({ desktopWidgets: { ...(settings.desktopWidgets || DEFAULT_SETTINGS.desktopWidgets), enabled: Boolean(on) } });
  syncDesktopWidgets();
  hub.pushState();
  return settings.desktopWidgets;
});
handle('desktopWidgets:state', () => settings.desktopWidgets || DEFAULT_SETTINGS.desktopWidgets);
/* ------------------------------------------------------- Kamera: wer benutzt sie? */
let cameraState = { on: false, users: [], parts: [] };
const CAM_PART_NAMES = { gaming: 'Gaming Hub (Facecam/Clips)', video: 'Video-Studio', chats: 'Chats' };
async function ownCameraParts() {
  const parts = [];
  for (const [id, view] of hub.views) {
    const wc = view?.webContents;
    if (!wc || wc.isDestroyed()) continue;
    const n = await wc.executeJavaScript('window.__revCam ? window.__revCam.count() : 0', true).catch(() => 0);
    if (Number(n) > 0) parts.push(CAM_PART_NAMES[id] || moduleById(id)?.name || id);
  }
  for (const win of BrowserWindow.getAllWindows()) {
    if (win.isDestroyed() || win === hub.window) continue;
    const n = await win.webContents.executeJavaScript('window.__revCam ? window.__revCam.count() : 0', true).catch(() => 0);
    if (Number(n) > 0 && !parts.includes('Gaming Hub (Facecam/Clips)')) parts.push(win.getTitle() || 'Overlay');
  }
  return parts;
}
async function pollCamera() {
  const users = await windowsTaskbar.cameraUsers().catch(() => null);
  if (!users) return;
  const parts = users.some((u) => u.own) ? await ownCameraParts() : [];
  const next = { on: users.length > 0, users, parts };
  if (JSON.stringify(next) !== JSON.stringify(cameraState)) {
    cameraState = next;
    hub.pushState();
  }
}
setInterval(pollCamera, 4000);
handle('camera:state', () => cameraState);
handle('camera:stopOwn', async () => {
  let n = 0;
  const all = [...[...hub.views.values()].map((v) => v?.webContents), ...BrowserWindow.getAllWindows().map((w) => w.webContents)];
  for (const wc of all) {
    if (!wc || wc.isDestroyed()) continue;
    n += Number(await wc.executeJavaScript('window.__revCam ? window.__revCam.stop() : 0', true).catch(() => 0)) || 0;
  }
  setTimeout(pollCamera, 800);
  return n;
});
handle('camera:openSettings', () => shell.openExternal('ms-settings:privacy-webcam'));

/* --------------------------------------------------------------- Crosshair-Overlay */
let crosshairWindow = null;

function closeCrosshairWindow() {
  if (!crosshairWindow) return;
  try { if (!crosshairWindow.isDestroyed()) crosshairWindow.destroy(); } catch { /* geschlossen */ }
  crosshairWindow = null;
}

function openCrosshairWindow() {
  if (crosshairWindow && !crosshairWindow.isDestroyed()) return crosshairWindow;
  const display = screen.getPrimaryDisplay();
  const size = 64;
  const win = new BrowserWindow({
    x: Math.round(display.bounds.x + display.bounds.width / 2 - size / 2),
    y: Math.round(display.bounds.y + display.bounds.height / 2 - size / 2),
    width: size,
    height: size,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    focusable: false,
    hasShadow: false,
    show: false,
    backgroundColor: '#00000000',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setSkipTaskbar(true);
  win.loadFile(path.join(UI_DIR, 'crosshair.html'));
  win.once('ready-to-show', () => {
    if (win.isDestroyed()) return;
    win.showInactive();
    setTimeout(() => !win.isDestroyed() && win.setIgnoreMouseEvents(true), 150); // erst nach dem Anzeigen, sonst grau
  });
  win.on('closed', () => { if (crosshairWindow === win) crosshairWindow = null; });
  crosshairWindow = win;
  return win;
}

/** Fadenkreuz des Gaming Hubs, falls geladen – sonst das kleine Hub-eigene als Notlösung. */
const gamingCrosshair = () => global.__revolutionHub?.crosshair || null;
function crosshairIsOn() {
  try {
    const g = gamingCrosshair();
    if (g) return g.on();
  } catch {
    /* Gaming Hub lädt noch */
  }
  return Boolean(settings.crosshairOn);
}
function setCrosshair(on) {
  const value = Boolean(on);
  const g = gamingCrosshair();
  if (g) {
    closeCrosshairWindow();
    if (settings.crosshairOn) saveSettings({ crosshairOn: false });
    g.toggle(value);
  } else {
    saveSettings({ crosshairOn: value });
    if (value) openCrosshairWindow();
    else closeCrosshairWindow();
  }
  if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:crosshair', { on: value });
  broadcastTaskbar();
  return { on: value };
}

handle('crosshair:set', (on) => setCrosshair(on));
handle('crosshair:toggle', () => setCrosshair(!crosshairIsOn()));
handle('crosshair:state', () => ({ on: crosshairIsOn() }));

/* --------------------------------------------------------------- Sperrbildschirm */
let lockWindows = [];
let lockAutoClose = null;
let lockReasons = new Map();

function lockWallpaper() {
  const id = settings.wallpaper;
  if (!id || id === 'none' || !WALLPAPERS.includes(id)) return '';
  const file = path.join(WALLPAPER_DIR, 'thumbs', `${id}.jpg`);
  try {
    return require('fs').existsSync(file) ? pathToFileURL(file).href : '';
  } catch {
    return '';
  }
}

function lockPayload(reason = 'windows') {
  return {
    locked: true,
    reason,
    wallpaper: lockWallpaper(),
    host: process.env.COMPUTERNAME || 'Windows',
  };
}

function sendLockState(win) {
  try {
    if (win && !win.isDestroyed()) win.webContents.send('hub:lock-state', { locked: false });
  } catch {
    /* geschlossen */
  }
}

function createLockWindow(display) {
  const win = new BrowserWindow({
    x: display.bounds.x,
    y: display.bounds.y,
    width: display.bounds.width,
    height: display.bounds.height,
    frame: false,
    transparent: false,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    focusable: true,
    hasShadow: false,
    show: false,
    backgroundColor: '#050506',
    title: 'Gesperrt',
    webPreferences: {
      preload: path.join(APP_ROOT, 'src', 'preload', 'hub-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });
  win.__lockReason = 'windows';
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setSkipTaskbar(true);
  try { win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true }); } catch { /* optional */ }
  win.loadFile(path.join(UI_DIR, 'lock.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('did-finish-load', () => {
    try { win.webContents.send('hub:lock', lockPayload(win.__lockReason)); } catch { /* geschlossen */ }
  });
  win.once('ready-to-show', () => {
    if (!win.isDestroyed()) {
      win.show();
      win.focus();
    }
  });
  win.on('closed', () => {
    lockWindows = lockWindows.filter((entry) => entry !== win);
  });
  lockWindows.push(win);
  return win;
}

function dismissLockScreen() {
  clearTimeout(lockAutoClose);
  lockAutoClose = null;
  for (const win of lockWindows) {
    try { if (!win.isDestroyed()) win.destroy(); } catch { /* geschlossen */ }
  }
  lockWindows = [];
  return true;
}

function showLockScreen(reason = 'windows') {
  clearTimeout(lockAutoClose);
  lockAutoClose = null;
  if (!lockWindows.length) {
    for (const display of screen.getAllDisplays()) createLockWindow(display);
    for (const win of lockWindows) win.__lockReason = reason;
  } else {
    for (const win of lockWindows) {
      win.__lockReason = reason;
      try { win.webContents.send('hub:lock', lockPayload(reason)); } catch { /* geschlossen */ }
    }
  }
  return true;
}

function closeTaskbarWindows() {
  for (const win of taskbarWindows) {
    try {
      if (!win.isDestroyed()) win.destroy();
    } catch {
      /* schon geschlossen */
    }
  }
  taskbarWindows = [];
}

function buildTaskbarWindows() {
  closeTaskbarWindows();
  if (!settings.replaceTaskbar) return;
  for (const display of screen.getAllDisplays()) createTaskbarWindow(display, 'full');
  updateTaskbarVisibility();
}

function startTaskbarWatch() {
  if (taskbarWatch) return;
  try {
    taskbarWatch = watchFullscreen((fullscreen) => {
      // Ein maximierter Hub ist selbst bildschirmfüllend – auf den anderen
      // Monitoren soll die Leiste deswegen nicht verschwinden.
      // Vollbild im Vordergrund (Video, Spiel, Browser-Vollbild): Leiste weg. Ein nur maximiertes
      // Fenster zählt nicht – das erkennt der Wächter selbst.
      taskbarFullscreen = Boolean(fullscreen);
      updateTaskbarVisibility();
    });
  } catch {
    taskbarWatch = null;
  }
}

function stopTaskbarWatch() {
  if (!taskbarWatch) return;
  try {
    taskbarWatch();
  } catch {
    /* schon beendet */
  }
  taskbarWatch = null;
  taskbarFullscreen = false;
}

let escapeWatch = null;
function startEscapeWatch() {
  if (escapeWatch) return;
  escapeWatch = watchEscapeHold(async () => {
    // Notausgang: Windows-Leiste sofort und mehrfach zurückholen, obere Leiste
    // ausschalten, damit unten garantiert wieder bedient werden kann.
    saveSettings({ replaceTaskbar: false });
    closeTaskbarWindows();
    stopTaskbarWatch();
    stopWinKeyWatch();
    for (let i = 0; i < 4; i += 1) {
      await setTaskbarHidden(false, true).catch(() => {});
      await new Promise((r) => setTimeout(r, 700));
    }
    hub.pushState();
    hub.layout();
    hub.notify('Windows-Taskleiste ist zurück', 'Esc wurde 20 Sekunden gehalten. Die obere Leiste ist aus – unten lässt sich wieder alles bedienen.');
  });
}

function startWinKeyWatch() {
  if (winKeyWatch || process.platform !== 'win32') return;
  winKeyWatch = watchWindowsKey((kind) => {
    if (settings.replaceTaskbar) {
      // Der System-Wächter schluckt die Taste selbst (kein Startmenü, keine Windows-Leiste) –
      // hier nur noch das Hub-Menü öffnen. Kein PowerShell-Aufruf mehr pro Tastendruck.
      if (kind === 'down') return;
      toggleTaskbarDrawer();
    }
    // Im Vollbild holt die Windows-Taste die obere Leiste kurz zurück.
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:peek');
  });
}

function stopWinKeyWatch() {
  if (!winKeyWatch) return;
  try { winKeyWatch(); } catch { /* schon beendet */ }
  winKeyWatch = null;
}

function restartTaskbarWindows() {
  if (!settings.replaceTaskbar) return;
  buildTaskbarWindows();
  startTaskbarWatch();
  startWinKeyWatch();
  hub.layout();
  hub.pushState();
}

function setTaskbarDrawer(open, kind = 'drawer') {
  taskbarDrawerOpen = Boolean(open);
  taskbarPanelKind = taskbarDrawerOpen ? (['screentime', 'speed'].includes(kind) ? kind : 'drawer') : 'drawer';
  if (!settings.replaceTaskbar) return false;
  taskbarDrawerDisplayId = taskbarDrawerOpen ? screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).id : null;
  for (const win of taskbarWindows) {
    if (!win || win.isDestroyed()) continue;
    // Kein setBounds mehr – das Menü öffnet sich innerhalb des festen Fensters.
  }
  broadcastTaskbar();
  updateTaskbarVisibility();
  return true;
}

function toggleTaskbarDrawer(kind = 'drawer') {
  if (!settings.replaceTaskbar || !taskbarWindows.length) return false;
  return setTaskbarDrawer(!taskbarDrawerOpen, kind);
}
function toggleTaskbarPanel(kind) {
  if (!settings.replaceTaskbar || !taskbarWindows.length) return false;
  if (taskbarDrawerOpen && taskbarPanelKind === kind) return setTaskbarDrawer(false);
  return setTaskbarDrawer(true, kind);
}

async function setTaskbarReplacement(enabled) {
  const on = Boolean(enabled);
  const ok = await setTaskbarHidden(on).catch(() => false);
  if (!ok && !on) throw new Error('Die Windows-Taskleiste konnte nicht geändert werden.');
  // Der Wächter blendet die Windows-Leiste laufend aus und hält die Windows-Taste fest –
  // auch wenn der erste Versuch (Autohide) nicht geklappt hat.
  if (on) keepTaskbarHidden(true);
  saveSettings({ replaceTaskbar: on });
  if (on) {
    taskbarDrawerOpen = false;
    try {
      buildTaskbarWindows();
      startTaskbarWatch();
      startWinKeyWatch();
    } catch (error) {
      console.error('[taskbar] Leiste konnte nicht gestartet werden:', error);
      closeTaskbarWindows();
      stopTaskbarWatch();
      await setTaskbarHidden(false).catch(() => {});
      saveSettings({ replaceTaskbar: false });
      hub.pushState();
      throw error;
    }
  } else {
    closeTaskbarWindows();
    stopTaskbarWatch();
    stopWinKeyWatch();
    taskbarDrawerOpen = false;
    // Nach dem Entfernen der eigenen Leiste die Windows-Leiste ausdrücklich
    // wieder zeigen – mehrfach, weil Explorer sie gern wieder versteckt.
    for (let i = 0; i < 3; i += 1) {
      await setTaskbarHidden(false, true).catch(() => {});
      await new Promise((r) => setTimeout(r, 650));
    }
  }
  hub.layout();
  hub.pushState();
  hub.refreshTray();
  return true;
}

handle('taskbar:replace', (on) => setTaskbarReplacement(on));
handle('quit', () => {
  hub.quitting = true;
  setTimeout(() => app.quit(), 60);
  return true;
});
handle('taskbar:ready', () => {
  refreshWindowsTaskbar();
  broadcastTaskbar();
  return true;
});
handle('taskbar:drawer', (open) => setTaskbarDrawer(open));
handle('taskbar:panel', (kind) => toggleTaskbarPanel(['screentime', 'speed'].includes(kind) ? kind : 'drawer'));
handle('taskbar:launch', (id) => {
  if (id === 'hub:self') {
    hub.showWindow();
    return true;
  }
  return windowsTaskbar.launch(String(id || ''));
});
handle('taskbar:search', (q) => windowsTaskbar.search(String(q || '').slice(0, 80)));
handle('taskbar:searchApps', (q) => windowsTaskbar.searchApps(String(q || '').slice(0, 80)));
handle('taskbar:searchFiles', (q) => windowsTaskbar.searchFiles(String(q || '').slice(0, 80)));
handle('taskbar:open', (id) => {
  setTaskbarDrawer(false);
  return windowsTaskbar.openResult(String(id || ''));
});
handle('taskbar:list', async () => {
  await windowsTaskbar.refresh(true).catch(() => {});
  return windowsTaskbar.list();
});
ipcMain.handle('hub:taskbar:interactive', (event, on) => {
  if (!isTrustedHubSender(event.sender)) throw new Error('Unzulässiger Aufrufer');
  const win = taskbarWindows.find((entry) => !entry.isDestroyed() && entry.webContents === event.sender);
  if (win) win.setIgnoreMouseEvents(!Boolean(on), { forward: true });
  return true;
});
ipcMain.handle('hub:taskbar:context', (event, id) => {
  if (!isTrustedHubSender(event.sender)) throw new Error('Unzulässiger Aufrufer');
  const entry = windowsTaskbar.list().find((item) => item.id === String(id));
  if (!entry) return false;
  const win = BrowserWindow.fromWebContents(event.sender);
  const after = (promise) => Promise.resolve(promise).finally(() => {
    windowsTaskbar.refresh(true).then(() => broadcastTaskbar()).catch(() => {});
  });
  const items = [{ label: entry.title || entry.name, enabled: false }];
  items.push(
    { label: entry.kind === 'running' ? 'Fokussieren' : 'Öffnen', click: () => windowsTaskbar.launch(entry.id) },
  );
  if (entry.kind === 'running') {
    items.push(
      { type: 'separator' },
      { label: 'Fenster schließen', click: () => after(windowsTaskbar.closeWindow(entry.id)) },
      { label: 'Task beenden', click: () => after(windowsTaskbar.endTask(entry.id)) },
      { label: 'An Taskleiste anheften', click: () => after(windowsTaskbar.pin(entry.id)) },
    );
  } else {
    items.push(
      { type: 'separator' },
      { label: 'Von Taskleiste lösen', click: () => after(windowsTaskbar.unpin(entry.id)) },
    );
  }
  items.push(
    { type: 'separator' },
    { label: 'Dateispeicherort öffnen', click: () => windowsTaskbar.reveal(entry.id) },
  );
  Menu.buildFromTemplate(items).popup({ window: win || undefined });
  return true;
});
handle('ui:control', () => {
  closeClientWindow();
  return openClient('control');
});
handle('ui:settings', () => {
  closeClientWindow();
  return openClient('settings');
});
handle('ui:view', (view) => {
  closeClientWindow();
  return openClient(view);
});
handle('ui:close', () => {
  closeClientWindow();
  return true;
});
handle('lock:dismiss', () => dismissLockScreen());
handle('lock:state', () => ({ ...lockPayload('windows'), locked: true }));
handle('lock:hello', () => new Promise((resolve) => {
  if (process.platform !== 'win32') return resolve({ ok: false, reason: 'Windows Hello ist nur unter Windows verfügbar.' });
  const script = `
$ErrorActionPreference = 'Stop'
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $null = [Windows.Security.Credentials.UI.UserConsentVerifier, Windows.Security.Credentials.UI, ContentType=WindowsRuntime]
  $op = [Windows.Security.Credentials.UI.UserConsentVerifier]::RequestVerificationAsync('Revulution Hub entsperren')
  $m = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' })[0]
  $task = $m.MakeGenericMethod([Windows.Security.Credentials.UI.UserConsentVerificationResult]).Invoke($null, @($op))
  $null = $task.Wait(30000)
  Write-Output $task.Result.ToString()
} catch { Write-Output 'Unavailable' }`;
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  require('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, timeout: 40000 }, (error, stdout) => {
    const result = String(stdout || '').trim();
    if (!error && result === 'Verified') return resolve({ ok: true });
    resolve({ ok: false, reason: result === 'Unavailable' || !result ? 'Windows Hello ist auf diesem PC nicht eingerichtet.' : 'Face ID wurde nicht erkannt.' });
  });
}));
handle('ui:launcher', () => {
  hub.showWindow();
  if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:open-launcher');
  return true;
});
handle('taskbar:start', () => openStartMenu());
handle('dock:size', (size) => {
  if (!size || !Number.isFinite(size.w) || !Number.isFinite(size.h)) return false;
  dockSize = { w: size.w, h: size.h, expanded: Boolean(size.expanded) };
  hub.layout();
  return true;
});
let dockModel = null;
handle('dock:model', (m) => {
  dockModel = m;
  if (dockView && !dockView.webContents.isDestroyed()) dockView.webContents.send('hub:dock-model', m);
  broadcastTaskbar();
  return true;
});
handle('dock:capture', async () => {
  if (!dockView || !hub.window || hub.window.isDestroyed()) return '';
  const b = dockView.getBounds();
  if (b.width < 20 || b.height < 20) return '';
  // Liegt eine App darunter, deren Bild nehmen – sonst die Hub-Oberfläche
  const view = hub.views.get(hub.active);
  let img = null;
  try {
    if (view && !hub.overlay && view.view.getVisible?.() !== false) {
      const vb = view.view.getBounds();
      img = await view.webContents.capturePage({ x: b.x - vb.x, y: b.y - vb.y, width: b.width, height: b.height });
    } else img = await hub.window.webContents.capturePage(b);
  } catch {
    return '';
  }
  if (!img || img.isEmpty()) return '';
  return `data:image/jpeg;base64,${img.toJPEG(78).toString('base64')}`;
});
handle('dock:ready', () => {
  if (!dockAlive) {
    dockAlive = true;
    setTimeout(() => {
      hub.layout();
      hub.pushState();
    }, 50);
  }
  return dockModel;
});
handle('dock:special', (kind) => {
  if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:dock-special', String(kind || ''));
  return true;
});

/* ------------------------------------------------- Badges (roter Punkt) */
const badges = {};
let overlayIcon = null;
function badgeIcon() {
  if (overlayIcon) return overlayIcon;
  const { nativeImage } = require('electron');
  const S = 32, buf = Buffer.alloc(S * S * 4);
  for (let y = 0; y < S; y += 1)
    for (let x = 0; x < S; x += 1) {
      const d = Math.hypot(x - S / 2 + 0.5, y - S / 2 + 0.5), a = Math.max(0, Math.min(1, S / 2 - 1 - d));
      const i = (y * S + x) * 4;
      // BGRA
      buf[i] = 48; buf[i + 1] = 59; buf[i + 2] = 255; buf[i + 3] = Math.round(a * 255);
    }
  overlayIcon = nativeImage.createFromBitmap(buf, { width: S, height: S });
  return overlayIcon;
}
function setBadge(id, n) {
  const v = Math.max(0, Math.min(999, Number(n) || 0));
  if ((badges[id] || 0) === v) return;
  if (v) badges[id] = v;
  else delete badges[id];
  const total = Object.values(badges).reduce((a, b) => a + b, 0);
  try {
    if (hub.window && !hub.window.isDestroyed()) hub.window.setOverlayIcon(total ? badgeIcon() : null, total ? `${total} ungelesen` : '');
  } catch {
    /* egal */
  }
  hub.pushState();
}

/* ------------------------------------------- Chats ↔ Spiele (Brücke) */
const chatBridge = {
  pending: [],
  onDm: null,
  identity() {
    const c = settings.chat || {};
    return c.code ? { code: c.code, name: hubProfile().name || c.name || '', allowGameDMs: c.allowGameDMs !== false, allowFriendReq: c.allowFriendReq !== false } : null;
  },
  setIdentity(id) {
    if (!id || !/^[A-Z0-9]{8}$/.test(String(id.code || ''))) return;
    saveSettings({ chat: { code: id.code, name: String(id.name || '').slice(0, 24), allowGameDMs: id.allowGameDMs !== false, allowFriendReq: id.allowFriendReq !== false } });
  },
  /** Aus einem Spiel: Chat mit dem Gegner öffnen oder ihn als Freund hinzufügen. */
  request(peer, kind) {
    if (!peer || !/^[A-Z0-9]{8}$/.test(String(peer.code || ''))) throw new Error('Der Gegner hat keinen Chat-Code');
    const item = { kind: kind === 'friend' ? 'friend' : 'dm', code: peer.code, name: String(peer.name || 'Spieler').slice(0, 24), cos: peer.cos || null, game: String(peer.game || '') };
    if (this.onDm) this.onDm(item);
    else this.pending.push(item);
    if (item.kind === 'dm') hub.open('chats');
    return true;
  },
  take() {
    const p = this.pending;
    this.pending = [];
    return p;
  },
};

global.__revolutionHub = {
  hub,
  profile: profileApi,
  chat: chatBridge,
  setBadge,
  shim: (id) => createShim(moduleById(id), hub),
  view: (id, options) => new ModuleView(hub, moduleById(id), options),
};

const orbit = new OrbitIsland(() => {
  hub.pushState();
  hub.refreshTray();
});

/* -------------------------------------------------------------------- window */

function createWindow() {
  hub.window = new BrowserWindow({
    width: 1460,
    height: 920,
    minWidth: 1140,
    minHeight: 720,
    show: false,
    frame: false,
    // Nicht „transparent“: nur so rundet Windows 11 die Ecken (klein, wie bei Systemfenstern).
    // Das Acrylic lässt den Desktop trotzdem live und verschwommen durchscheinen.
    transparent: false,
    backgroundColor: '#00000000',
    backgroundMaterial: 'acrylic',
    hasShadow: true,
    roundedCorners: true,
    title: 'Revulution Hub',
    icon: ICON,
    webPreferences: {
      preload: path.join(APP_ROOT, 'src', 'preload', 'hub-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });

  for (const view of hub.views.values()) hub.window.contentView.addChildView(view.view);

  hub.window.loadFile(path.join(UI_DIR, 'index.html'));
  hub.window.once('ready-to-show', () => {
    createDockView();
    hub.layout();
    if (!START_HIDDEN) hub.window.show();
  });
  for (const event of ['resize', 'show', 'hide', 'minimize', 'restore']) hub.window.on(event, () => hub.layout());
  // Glas: der Hub zeigt den (unscharfen) Desktop genau an der Stelle, an der das Fenster steht.
  const sendGlass = () => {
    const w = hub.window;
    if (!w || w.isDestroyed()) return;
    const b = w.getContentBounds();
    const d = screen.getDisplayMatching(b);
    w.webContents.send('hub:glass', { x: b.x - d.bounds.x, y: b.y - d.bounds.y, w: d.bounds.width, h: d.bounds.height });
  };
  let glassT = 0;
  for (const ev of ['move', 'resize', 'show', 'maximize', 'unmaximize', 'restore']) hub.window.on(ev, () => { clearTimeout(glassT); glassT = setTimeout(sendGlass, 16); });
  hub.window.webContents.on('did-finish-load', () => setTimeout(sendGlass, 50));
  hub.window.on('maximize', () => hub.pushState());
  hub.window.on('unmaximize', () => hub.pushState());
  // Echtes Vollbild (F11/HTML-Vollbild): obere Leiste ausblenden, bis die Windows-Taste kommt.
  const immersive = (on) => {
    hubImmersive = Boolean(on);
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:immersive', Boolean(on));
    updateTaskbarVisibility();
  };
  hub.window.on('enter-full-screen', () => immersive(true));
  hub.window.on('leave-full-screen', () => immersive(false));
  hub.onModuleFullscreen = (on) => {
    hubImmersive = Boolean(on);
    updateTaskbarVisibility();
  };
  hub.window.webContents.on('enter-html-full-screen', () => immersive(true));
  hub.window.webContents.on('leave-html-full-screen', () => immersive(false));
  // Im Ersatz-Modus bleibt die Windows-Taskleiste aus; die Revulution-Leiste
  // läuft unabhängig vom Hub-Fenster weiter (auch im Tray).
  for (const event of ['show', 'restore', 'focus', 'blur', 'hide', 'minimize']) hub.window.on(event, updateTaskbarVisibility);
  for (const event of ['show', 'hide', 'focus', 'blur', 'minimize', 'restore']) hub.window.on(event, () => broadcastTaskbar());
  for (const event of ['show', 'hide', 'minimize', 'restore']) hub.window.on(event, () => syncWidgetMedia());
  hub.window.webContents.on('did-finish-load', () => { if (lastWidgetMedia) hub.window.webContents.send('hub:media', lastWidgetMedia); });
  hub.window.on('show', () => { if (settings.replaceTaskbar) setTaskbarHidden(true).catch(() => {}); });
  hub.window.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  hub.window.on('close', (event) => {
    if (hub.quitting) return;
    // Laufen Crosshair, Clipper oder der Autoclicker, bleibt der Hub immer im Hintergrund offen.
    let working = false;
    try {
      working = Boolean(global.__revolutionHub?.gamingActive?.()) || autoclick.status().running;
    } catch {
      working = false;
    }
    if (!settings.closeToTray && !working) {
      // Overlay windows would keep the process alive, so quit explicitly.
      hub.quitting = true;
      setImmediate(() => app.quit());
      return;
    }
    event.preventDefault();
    hub.window.hide();
    if (!settings.trayHintShown) {
      hub.notify('Revulution Hub läuft weiter', 'Crosshair, Overlays, Screenshot-Hotkey und Revulution Island bleiben aktiv. Beenden über das Symbol im Infobereich.');
      saveSettings({ trayHintShown: true });
    }
  });
}

/* ---------------------------------------------------------------------- tray */

const TRAY_SECTIONS = { gaming: 'Gaming Hub', dropzone: 'Dateien' };

function moduleTraySubmenu(id, tray) {
  if (!tray?.menu || tray.isDestroyed()) return null;
  const items = tray.menu.items
    .filter((item) => !/^(beenden|quit|exit|fenster öffnen)$/i.test(item.label) && item.label !== moduleById(id).name)
    .map((item) => ({
      label: item.label,
      type: item.type,
      checked: item.checked,
      enabled: item.enabled,
      click: item.click
        ? (...args) => {
            if (/statistik/i.test(item.label)) hub.open(id);
            item.click(...args);
          }
        : undefined,
    }));
  while (items.length && items[0].type === 'separator') items.shift();
  while (items.length && items[items.length - 1].type === 'separator') items.pop();
  return items.length ? Menu.buildFromTemplate(items) : null;
}

function buildTrayMenu() {
  const template = [
    { label: 'Revulution Hub öffnen', click: () => hub.open(hub.active) },
    ...(settings.replaceTaskbar ? [{ label: 'Windows-Taskleiste zurückholen', click: () => setTaskbarReplacement(false).catch(() => {}) }] : []),
    { label: 'Screenshot aufnehmen', click: () => hub.api?.screenshot?.() },
    { type: 'separator' },
    { label: 'Dateien', click: () => hub.open('dropzone') },
    { label: 'Gaming Hub', click: () => hub.open('gaming') },
    { label: 'Video-Schnitt', click: () => hub.open('video') },
    { label: 'Dokumente', click: () => hub.open('docs') },
    { label: 'Schach-Coach', click: () => hub.open('chess') },
    { label: 'GeoRevulution', click: () => hub.open('geo') },
    { label: 'Agenda', click: () => hub.open('agenda') },
    { label: 'Chats', click: () => hub.open('chats') },
  ];
  const sections = [];
  for (const [id, tray] of hub.moduleTrays) {
    const submenu = moduleTraySubmenu(id, tray);
    if (submenu) sections.push({ label: TRAY_SECTIONS[id] || moduleById(id).name, submenu });
  }
  if (sections.length) template.push({ type: 'separator' }, ...sections);
  if (orbit.available()) {
    template.push(
      { type: 'separator' },
      {
        label: 'Revulution Island',
        type: 'checkbox',
        checked: orbit.running,
        click: () => (orbit.running ? orbit.stop() : orbit.start()).catch(() => {}),
      },
    );
  }
  template.push({ type: 'separator' }, { label: 'Beenden', click: () => hub.quit() });
  return Menu.buildFromTemplate(template);
}

function createTray() {
  const image = nativeImage.createFromPath(ICON).resize({ width: 16, height: 16 });
  hub.tray = new Tray(image);
  hub.tray.setToolTip('Revulution Hub');
  hub.tray.on('click', () => hub.open(hub.active));
  hub.refreshTray();
}

/* ----------------------------------------------------------------------- IPC */

function isTrustedHubSender(sender) {
  return sender === hub.window?.webContents
    || sender === dockView?.webContents
    || sender === clientWindow?.webContents
    || Boolean(widgetWinFor(sender))
    || taskbarWindows.some((win) => !win.isDestroyed() && win.webContents === sender)
    || lockWindows.some((win) => !win.isDestroyed() && win.webContents === sender);
}

function handle(channel, fn) {
  ipcMain.handle(`hub:${channel}`, async (event, ...args) => {
    if (!isTrustedHubSender(event.sender)) throw new Error('Unzulässiger Aufrufer');
    return fn(...args);
  });
}

// Read-only appearance for the apps inside the hub (click sounds).
ipcMain.handle('hub-view:appearance', () => appearance());

handle('state', () => hub.state());
handle('open', (id) => hub.open(id));
handle('window', (action) => {
  const win = hub.window;
  if (!win) return false;
  if (action === 'minimize') win.minimize();
  else if (action === 'maximize') (win.isMaximized() ? win.unmaximize() : win.maximize());
  else if (action === 'close') win.close();
  return true;
});
handle('settings:set', async (patch) => {
  const allowed = {};
  for (const key of ['autoStart', 'closeToTray', 'orbitWithHub', 'sounds', 'wallpaperIsland', 'updateAuto']) if (typeof patch?.[key] === 'boolean') allowed[key] = patch[key];
  if (patch?.startPage === 'home' || patch?.startPage === 'last') allowed.startPage = patch.startPage;
  if (typeof patch?.soundVolume === 'number') allowed.soundVolume = Math.min(1, Math.max(0, patch.soundVolume));
  if (typeof patch?.wallpaperDim === 'number') allowed.wallpaperDim = Math.min(0.9, Math.max(0, patch.wallpaperDim));
  if (typeof patch?.backdropBlur === 'boolean') allowed.backdropBlur = patch.backdropBlur;
  if (typeof patch?.backdropBlurAmount === 'number') allowed.backdropBlurAmount = Math.min(40, Math.max(0, Math.round(patch.backdropBlurAmount)));
  if (typeof patch?.backdropDim === 'number') allowed.backdropDim = Math.min(0.75, Math.max(0, patch.backdropDim));
  if (patch?.widgets && typeof patch.widgets === 'object') {
    const w = { ...(settings.widgets || DEFAULT_SETTINGS.widgets) };
    for (const key of ['sysLive', 'upcoming', 'screentime', 'speed']) if (typeof patch.widgets[key] === 'boolean') w[key] = patch.widgets[key];
    allowed.widgets = w;
  }
  if (patch?.desktopWidgets && typeof patch.desktopWidgets === 'object') {
    const w = { ...(settings.desktopWidgets || DEFAULT_SETTINGS.desktopWidgets) };
    for (const key of ['enabled', 'clock', 'system', 'screentime', 'upcoming', 'music', 'calendar', 'face', 'cards', 'vinyl']) if (typeof patch.desktopWidgets[key] === 'boolean') w[key] = patch.desktopWidgets[key];
    allowed.desktopWidgets = w;
  }
  if (patch?.wallpaper === 'none' || WALLPAPERS.includes(patch?.wallpaper)) allowed.wallpaper = patch.wallpaper;
  if (['de', 'en', 'es'].includes(patch?.lang)) allowed.lang = patch.lang;
  // Seitenleiste: angeheftete Apps (max. 3) + Gruppen
  if (patch?.nav && Array.isArray(patch.nav.pinned) && Array.isArray(patch.nav.groups)) {
    const ids = (list) => (Array.isArray(list) ? list.filter((x) => typeof x === 'string' && x.length < 30).slice(0, 40) : []);
    allowed.nav = {
      pinned: ids(patch.nav.pinned).slice(0, 3),
      groups: patch.nav.groups.slice(0, 12).map((g) => ({ id: String(g.id || '').slice(0, 30), name: String(g.name || 'Gruppe').slice(0, 18), apps: ids(g.apps) })),
    };
  }
  if (Array.isArray(patch?.navCollapsed)) allowed.navCollapsed = patch.navCollapsed.filter((x) => typeof x === 'string').slice(0, 12);
  if (patch?.dock && typeof patch.dock === 'object') {
    const d = { ...(settings.dock || {}) };
    if (['bottom', 'top', 'left', 'right'].includes(patch.dock.pos)) d.pos = patch.dock.pos;
    if (['s', 'm', 'l'].includes(patch.dock.size)) d.size = patch.dock.size;
    if (typeof patch.dock.magnify === 'boolean') d.magnify = patch.dock.magnify;
    if (Array.isArray(patch.dock.items)) d.items = [...new Set(patch.dock.items.filter((x) => typeof x === 'string' && x.length < 30))].slice(0, 30);
    allowed.dock = d;
  }
  if (typeof patch?.dnd === 'boolean') allowed.dnd = patch.dnd;
  if (typeof patch?.muteWinNotify === 'boolean') allowed.muteWinNotify = patch.muteWinNotify;
  if (['classic', 'kq', 'nothing'].includes(patch?.clickSound)) allowed.clickSound = patch.clickSound;
  if (['top', 'dock'].includes(patch?.taskbarStyle)) allowed.taskbarStyle = patch.taskbarStyle;
  if (typeof patch?.updateAuto === 'boolean') allowed.updateAuto = patch.updateAuto;
  if (typeof patch?.seenVersion === 'string') allowed.seenVersion = patch.seenVersion.slice(0, 20);
  if (typeof patch?.onboarded === 'boolean') allowed.onboarded = patch.onboarded;
  if (Array.isArray(patch?.recentApps)) allowed.recentApps = patch.recentApps.filter((x) => typeof x === 'string').slice(0, 8);
  if (Array.isArray(patch?.favoriteApps)) allowed.favoriteApps = [...new Set(patch.favoriteApps.filter((x) => typeof x === 'string' && x.length < 40))].slice(0, 40);
  if (Array.isArray(patch?.topbarItems)) allowed.topbarItems = [...new Set(patch.topbarItems.filter((x) => ['crosshair', 'screentime', 'speed', 'settings'].includes(x)))].slice(0, 4);
  if (typeof patch?.crosshairOn === 'boolean') allowed.crosshairOn = patch.crosshairOn;
  if (patch?.autoclick && typeof patch.autoclick === 'object') allowed.autoclick = cleanAutoclick(patch.autoclick);
  if (patch?.keyboard && typeof patch.keyboard === 'object') allowed.keyboard = cleanKeyboard(patch.keyboard);
  if (patch?.ajazz && typeof patch.ajazz === 'object') allowed.ajazz = { mode: Number(patch.ajazz.mode) || 0, color: /^#[0-9a-f]{6}$/i.test(patch.ajazz.color) ? patch.ajazz.color : '#ff3b30', brightness: Math.max(0, Math.min(5, Number(patch.ajazz.brightness) || 0)), speed: Math.max(0, Math.min(5, Number(patch.ajazz.speed) || 0)), direction: Math.max(0, Math.min(3, Number(patch.ajazz.direction) || 0)), colorful: patch.ajazz.colorful === true, sleep: [0, 1, 5, 30].includes(Number(patch.ajazz.sleep)) ? Number(patch.ajazz.sleep) : 5 };
  if (patch?.rgb && typeof patch.rgb === 'object') allowed.rgb = cleanRgb(patch.rgb);
  if (patch?.screen && typeof patch.screen === 'object') allowed.screen = cleanScreen(patch.screen);
  if (patch?.shield && typeof patch.shield === 'object') allowed.shield = { watch: patch.shield.watch !== false, locate: patch.shield.locate !== false };
  if (Array.isArray(patch?.weatherCities)) allowed.weatherCities = patch.weatherCities.filter((c) => c && typeof c === 'object').slice(0, 8).map((c) => ({ name: String(c.name || '').slice(0, 60), lat: Number(c.lat) || 0, lon: Number(c.lon) || 0 }));
  if (typeof patch?.weatherWarned === 'string') allowed.weatherWarned = patch.weatherWarned.slice(0, 40);
  if (typeof patch?.notes === 'string') allowed.notes = patch.notes.slice(0, 20000);
  if (patch?.worldclocks && Array.isArray(patch.worldclocks)) allowed.worldclocks = patch.worldclocks.filter((x) => typeof x === 'string' && x.length < 40).slice(0, 8);
  if (patch?.weatherCity && typeof patch.weatherCity === 'object') allowed.weatherCity = { name: String(patch.weatherCity.name || '').slice(0, 60), lat: Number(patch.weatherCity.lat) || 0, lon: Number(patch.weatherCity.lon) || 0 };
  saveSettings(allowed);
  if ('dock' in allowed) hub.layout();
  if ('muteWinNotify' in allowed) applyWinSound();
  if ('autoclick' in allowed) autoclick.bindHotkey();
  if ('keyboard' in allowed) keyboard.apply();
  if ('lang' in allowed) hub.applyLang();
  if ('autoStart' in allowed) applyAutoStart();
  if ('taskbarStyle' in allowed && settings.replaceTaskbar) restartTaskbarWindows();
  if ('desktopWidgets' in allowed) syncDesktopWidgets();
  if ('sounds' in allowed || 'soundVolume' in allowed || 'clickSound' in allowed) hub.pushAppearance();
  if (('wallpaper' in allowed || 'wallpaperIsland' in allowed) && settings.wallpaperIsland) await syncIslandWallpaper().catch(() => {});
  hub.pushState();
  return settings;
});
handle('profile:get', () => profileApi.get());
handle('profile:buy', ({ slot, id }) => profileApi.buy(slot, id));
handle('profile:equip', ({ slot, id }) => profileApi.equip(slot, id));
handle('profile:name', (name) => profileApi.setName(name));
handle('profile:image', (data) => profileApi.setImage(data));
handle('pc:info', (force) => require('./pcinfo').info(Boolean(force)));
handle('pc:live', () => require('./pcinfo').live());
handle('pc:kill', (pid) => new Promise((resolve) => {
  const id = Number(pid);
  if (!Number.isInteger(id) || id <= 0) return resolve(false);
  require('child_process').execFile('taskkill.exe', ['/PID', String(id), '/T', '/F'], { windowsHide: true, timeout: 8000 }, (error) => resolve(!error));
}));
handle('speed:wlan', () => require('./speedtest').wlanInfo());
// Starter / Kontrollzentrum offen → App-Ansicht kurz ausblenden
handle('overlay', (on) => {
  hub.overlay = Boolean(on);
  hub.layout();
  return hub.overlay;
});
const control = require('./control');
handle('cc:volume', (level) => (level == null ? control.getVolume() : control.setVolume(level)));
handle('cc:media', (key) => control.media(key));
handle('cc:brightness', (level) => (level == null ? control.getBrightness() : control.setBrightness(level)));
handle('cc:power', (mode) => (mode ? control.setPower(mode) : control.getPower()));
handle('cc:lock', () => {
  showLockScreen('manual');
  setTimeout(() => Promise.resolve(control.lockPc()).catch(() => {}), 700);
  return true;
});

/* Timer und Wecker: laufen sichtbar in der Island (sonst als normale Meldung) */
const hubTimers = new Map();
function islandTimer(seconds, name) {
  const secs = Math.max(1, Math.min(7 * 86400, Math.round(Number(seconds) || 0)));
  const label = String(name || 'Timer').replace(/[:\r\n]/g, ' ').slice(0, 40);
  if (orbit.running) orbit.post({ command: `timer:${secs}:${label}` });
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  // Fallback, falls die Island nicht läuft: der Hub meldet sich selbst
  const t = setTimeout(() => {
    hubTimers.delete(id);
    if (!orbit.running) hub.notify(`⏰ ${label}`, 'Die Zeit ist um.', { app: 'Revulution Hub', glyph: '⏰' });
  }, secs * 1000);
  hubTimers.set(id, { t, at: Date.now() + secs * 1000, label });
  return { id, at: Date.now() + secs * 1000, label };
}
handle('cc:timer', (seconds, name) => islandTimer(seconds, name));
handle('cc:alarm', (hhmm) => {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || ''));
  if (!m) throw new Error('Uhrzeit bitte als HH:MM eingeben.');
  const at = new Date();
  at.setHours(Number(m[1]), Number(m[2]), 0, 0);
  if (at <= new Date()) at.setDate(at.getDate() + 1);
  return islandTimer((at - Date.now()) / 1000, `Wecker ${m[1].padStart(2, '0')}:${m[2]}`);
});
handle('mix:list', async () => {
  const m = global.__revolutionHub?.mixer;
  if (!m) return { apps: [], error: 'Mixer nicht verfügbar' };
  try {
    return await m.list();
  } catch (error) {
    return { apps: [], error: String(error?.message || error) };
  }
});
handle('mix:app', (pid, volume, mute) => global.__revolutionHub?.mixer?.setApp(pid, volume == null ? -1 : Number(volume), mute == null ? -1 : mute ? 1 : 0));
handle('mix:master', (volume, mute) => global.__revolutionHub?.mixer?.setMaster(volume == null ? -1 : Number(volume), mute == null ? -1 : mute ? 1 : 0));
/* ---------------- Konto (Login + Sync von Profil, Punkten, Cosmetics und Schach) */
const { Account } = require('./account');
const chessProfileFile = () => path.join(hubData('chess'), 'profile.json');
const readChessProfile = () => {
  try {
    return JSON.parse(fs.readFileSync(chessProfileFile(), 'utf8'));
  } catch {
    return null;
  }
};
const account = new Account({
  getLocal: () => {
    let chessAt = 0;
    try {
      chessAt = fs.statSync(chessProfileFile()).mtimeMs;
    } catch {
      chessAt = 0;
    }
    return { profile: hubProfile(), chess: readChessProfile(), updatedAt: Math.max(Number(settings.profileAt) || 0, chessAt) };
  },
  applyRemote: (data, at) => {
    if (data?.profile && typeof data.profile === 'object') saveSettings({ profile: { ...hubProfile(), ...data.profile }, profileAt: at });
    if (data?.chess && typeof data.chess === 'object') {
      try {
        fs.mkdirSync(path.dirname(chessProfileFile()), { recursive: true });
        fs.writeFileSync(chessProfileFile(), JSON.stringify(data.chess));
        hub.views.get('chess')?.unload?.(); // lädt beim nächsten Öffnen mit dem neuen Stand
        hub.opened.delete('chess');
      } catch {
        /* egal */
      }
    }
    hub.pushProfile();
    hub.pushState();
  },
  onChange: (st) => {
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:account', st);
  },
});
account.markLocal = (at) => saveSettings({ profileAt: at });
function accountChanged() {
  account.changed();
}
// Schach speichert sein Profil selbst – Änderungen an der Datei ebenfalls hochladen
setInterval(() => {
  try {
    const m = fs.statSync(chessProfileFile()).mtimeMs;
    if (account.lastChess && m > account.lastChess) accountChanged();
    account.lastChess = m;
  } catch {
    /* noch kein Schach-Profil */
  }
}, 30000);
handle('acct:state', () => account.state());
handle('acct:login', (email, password, create) => account.login(email, password, Boolean(create)));
handle('acct:logout', () => account.logout());
handle('acct:sync', (mode) => account.sync(['push', 'pull'].includes(mode) ? mode : 'auto'));
handle('acct:reset', (email) => account.reset(email));
handle('acct:code', (code) => account.verifyCode(code));
handle('acct:cancel', () => account.cancelCode());
handle('acct:mfaStart', () => account.mfaStart());
handle('acct:mfaFinish', (code) => account.mfaFinish(code));
handle('acct:mfaRemove', () => account.mfaRemove());
handle('acct:verify', () => account.resendVerify());

/* ---------------- Schematics-Cloud (KELPI) */
const schematics = require('./schematics');
handle('schem:list', (force) => schematics.list(Boolean(force)));
handle('schem:detail', (id) => schematics.detail(String(id)));
handle('schem:icons', (ids) => schematics.icons(ids));
handle('schem:install', async (id, version) => {
  const r = await schematics.install(String(id), Number.isInteger(version) ? version : -1);
  hub.notify('Schematic installiert', `${r.file} liegt jetzt in ${r.count} Ordner(n).`, { app: 'Schematics', glyph: '🧱' });
  return r;
});
handle('schem:targets', () => schematics.targets('x.litematic').map((t) => t.label));
handle('schem:file', (id) => schematics.file(String(id)));
handle('schem:social', (id) => schematics.social(String(id), account));
handle('schem:rate', (id, stars) => schematics.rate(String(id), stars, account, hubProfile().name));
handle('schem:comment', (id, text) => schematics.comment(String(id), text, account, hubProfile().name));
handle('schem:uncomment', (docId) => schematics.uncomment(String(docId), account));

/* ---------------- Hintergründe, Meldungen & Admin */
const community = new Community({
  dir: app.getPath('userData'),
  getSettings: () => settings,
  saveSettings,
  onChange: () => {},
});
handle('community:status', () => community.status());
handle('community:download', (id) => community.download(String(id || '')));
handle('community:desktop', (id, opts) => community.desktop(String(id || ''), opts || {}));
handle('wallpaper:monitors', () => require('./desktop-wallpaper').monitors());
/* Live-Leuchten auf den echten Monitoren, solange sie in der Hintergrund-Auswahl gewählt sind */
const glowWins = new Map(); // display.id → BrowserWindow
function glowOff(id) {
  const win = glowWins.get(id);
  glowWins.delete(id);
  if (!win || win.isDestroyed()) return;
  win.webContents.executeJavaScript("document.body.classList.remove('on')").catch(() => {});
  setTimeout(() => !win.isDestroyed() && win.destroy(), 480);
}
handle('wallpaper:highlight', (rects) => {
  const want = new Set();
  for (const r of Array.isArray(rects) ? rects.slice(0, 8) : []) {
    const phys = { x: Math.round(Number(r?.x) || 0), y: Math.round(Number(r?.y) || 0), width: Math.max(1, Math.round(Number(r?.w) || 1)), height: Math.max(1, Math.round(Number(r?.h) || 1)) };
    let dip = phys;
    try {
      dip = screen.screenToDipRect(null, phys);
    } catch {
      /* gleiche Skalierung */
    }
    const d = screen.getDisplayMatching(dip);
    if (d) want.add(d.id);
  }
  for (const id of [...glowWins.keys()]) if (!want.has(id)) glowOff(id);
  for (const d of screen.getAllDisplays()) {
    if (!want.has(d.id) || glowWins.has(d.id)) continue;
    const win = new BrowserWindow({ ...d.bounds, frame: false, transparent: true, backgroundColor: '#00000000', resizable: false, movable: false, focusable: false, skipTaskbar: true, hasShadow: false, show: false, webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
    win.setAlwaysOnTop(true, 'screen-saver');
    win.loadFile(path.join(UI_DIR, 'monitor-glow.html'));
    win.once('ready-to-show', () => {
      if (win.isDestroyed()) return;
      win.setBounds(d.bounds);
      win.showInactive();
      setTimeout(() => !win.isDestroyed() && win.setIgnoreMouseEvents(true), 150); // erst nach dem Anzeigen, sonst grau
    });
    glowWins.set(d.id, win);
  }
  return true;
});
/* Hintergründe aus der Cloud: einreichen (angemeldet) und freigegebene laden */
const { CloudBackgrounds } = require('./cloud-backgrounds');
const cloudBg = new CloudBackgrounds({
  fb: account.client(),
  token: () => account.token().catch(() => ''),
  uid: () => account.status.uid || '',
  name: () => hubProfile()?.name || account.status.email?.split('@')[0] || 'Nutzer',
  dir: app.getPath('userData'),
});
handle('community:cloud', (force) => cloudBg.list(Boolean(force)));
handle('community:submit', (r) => cloudBg.submit(r || {}));
handle('community:cloudDesktop', (id, opts) => cloudBg.desktop(String(id || ''), opts || {}));
handle('wallpaper:desktop', async (id, opts) => {
  const key = String(id || '');
  if (!WALLPAPERS.includes(key)) throw new Error('Hintergrund nicht gefunden.');
  const thumb = path.join(WALLPAPER_DIR, 'thumbs', `${key}.jpg`);
  const video = path.join(WALLPAPER_DIR, `live-${key}.mp4`);
  if (!fs.existsSync(video) && !fs.existsSync(thumb)) throw new Error('Bilddatei fehlt.');
  const dst = path.join(app.getPath('userData'), `desktop-${key}.jpg`);
  // Die Vorschaubilder sind nur 480 × 270 – als Desktop wären sie stark unscharf.
  // Deshalb einen echten Full-HD-Frame aus dem Live-Hintergrund ziehen.
  let sharp = false;
  if (fs.existsSync(video)) {
    const ffmpeg = path.join(APP_ROOT, 'vendor', 'ffmpeg', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
    if (fs.existsSync(ffmpeg)) {
      sharp = await new Promise((resolve) => {
        require('child_process').execFile(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-skip_frame', 'nokey', '-i', video, '-frames:v', '1', '-q:v', '1', '-y', dst], { windowsHide: true, timeout: 30000 }, (error) => resolve(!error && fs.existsSync(dst)));
      });
    }
  }
  if (!sharp) fs.copyFileSync(thumb, dst);
  await require('./desktop-wallpaper').applyDesktopWallpaper(dst, opts || {});
  return true;
});
let desktopToneCache = { key: '', tone: 'dark' };
const TRANSCODED_WALLPAPER = path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Themes', 'TranscodedWallpaper');
let wallpaperPathCache = { at: 0, file: '' };
function currentDesktopWallpaper() {
  return new Promise((resolve) => {
    const script = "$p=(Get-ItemProperty -Path 'HKCU:\\Control Panel\\Desktop' -Name Wallpaper -ErrorAction SilentlyContinue).Wallpaper; if($p){[Console]::Out.Write($p)}";
    require('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout: 8000 }, (error, stdout) => resolve(error ? '' : String(stdout || '').trim()));
  });
}
async function liveWallpaperFile() {
  // TranscodedWallpaper ist immer das Bild, das Windows gerade anzeigt – auch
  // bei Diashow, Spotlight oder einem frisch gesetzten Hintergrund.
  if (fs.existsSync(TRANSCODED_WALLPAPER)) return TRANSCODED_WALLPAPER;
  if (wallpaperPathCache.file && Date.now() - wallpaperPathCache.at < 30000 && fs.existsSync(wallpaperPathCache.file)) return wallpaperPathCache.file;
  const file = await currentDesktopWallpaper();
  if (file && fs.existsSync(file)) wallpaperPathCache = { at: Date.now(), file };
  return file && fs.existsSync(file) ? file : '';
}

/* Weichgezeichneter Desktop-Hintergrund fürs Hub-Fenster und die Vorschauen. */
let backdropCache = { key: '', path: '' };
async function desktopBackdrop() {
  const file = await liveWallpaperFile();
  if (!file) return backdropCache.path || '';
  let key = '';
  try {
    const stat = fs.statSync(file);
    key = `${Math.round(stat.mtimeMs)}-${stat.size}`;
  } catch {
    return backdropCache.path || '';
  }
  if (backdropCache.key === key && fs.existsSync(backdropCache.path)) return backdropCache.path;
  const dst = path.join(app.getPath('userData'), `desktop-backdrop-${key}.jpg`);
  try {
    if (!fs.existsSync(dst)) fs.copyFileSync(file, dst);
  } catch {
    return backdropCache.path || '';
  }
  backdropCache = { key, path: dst };
  try {
    for (const name of fs.readdirSync(path.dirname(dst))) {
      if (name.startsWith('desktop-backdrop-') && path.join(path.dirname(dst), name) !== dst) fs.rmSync(path.join(path.dirname(dst), name), { force: true });
    }
  } catch {}
  return dst;
}
handle('desktop:backdrop', () => desktopBackdrop());
handle('desktop:tone', async () => {
  // Helligkeit des Bereichs hinter der oberen Leiste: dunkler Desktop → weiße
  // Symbole, heller Desktop → schwarze Symbole.
  const file = await liveWallpaperFile();
  if (!file) return 'dark';
  try {
    const stat = fs.statSync(file);
    const key = `${file}:${stat.mtimeMs}:${stat.size}`;
    if (desktopToneCache.key === key) return desktopToneCache.tone;
    const image = nativeImage.createFromBuffer(fs.readFileSync(file));
    if (image.isEmpty()) return 'dark';
    const small = image.resize({ width: 64, quality: 'good' });
    const { width, height } = small.getSize();
    const bmp = small.toBitmap();
    const rows = Math.max(1, Math.round(height * 0.14));
    let sum = 0;
    let count = 0;
    for (let y = 0; y < rows; y += 1) {
      for (let x = 0; x < width; x += 1) {
        const i = (y * width + x) * 4;
        sum += 0.299 * bmp[i + 2] + 0.587 * bmp[i + 1] + 0.114 * bmp[i];
        count += 1;
      }
    }
    const tone = count && sum / count > 150 ? 'light' : 'dark';
    desktopToneCache = { key, tone };
    return tone;
  } catch {
    return 'dark';
  }
});
handle('community:report', (r) => community.report(r || {}));

/* ---------------- Island-Status: zeigt dauerhaft, was im Hub gerade läuft */
let islandStatusLast = null;
let chatCall = null;
let chatCallNotified = '';
function setChatCall(st) {
  const prev = chatCall;
  chatCall = st && st.name ? { phase: String(st.phase || ''), name: String(st.name).slice(0, 32), callId: String(st.callId || '').slice(0, 40) } : null;
  // Eingehender Anruf: groß in der Island, solange es klingelt – Klick öffnet die Chats.
  if (chatCall?.phase === 'ringing' && chatCall.callId && chatCallNotified !== chatCall.callId) {
    chatCallNotified = chatCall.callId;
    if (orbit.running && !settings.dnd)
      orbit.post({ title: `${chatCall.name} ruft an`, message: 'Sprachanruf · klicken zum Annehmen', app: 'Chats', glyph: '📞', accent: '#22c55e', open: 'revulution://open/chats', priority: 'high', seconds: '45', key: `call-${chatCall.callId}` });
    else hub.notify(`${chatCall.name} ruft an`, 'Sprachanruf in den Chats', { app: 'Chats', glyph: '📞', accent: '#22c55e' });
  }
  // Angenommen, abgelehnt oder aufgelegt: die Klingel-Karte in der Island schließen.
  if (prev?.phase === 'ringing' && prev.callId && chatCall?.phase !== 'ringing') orbit.post({ command: `dismiss:call-${prev.callId}` });
  islandStatus();
}
/* ---------------- Handy spiegeln (Android über scrcpy) */
const { Phone } = require('./phone');
const phone = new Phone({ dir: app.getPath('userData'), onChange: (st) => hub.window && !hub.window.isDestroyed() && hub.window.webContents.send('hub:phone', st) });
handle('phone:status', () => phone.status());
handle('phone:install', () => phone.install());
handle('phone:start', (opts) => phone.start(opts || {}));
handle('phone:stop', () => phone.stop());
app.on('before-quit', () => phone.stop());

/* ---------------- Bildschirmzeit */
const { ScreenTime } = require('./screentime');
const screenTime = new ScreenTime({ dir: app.getPath('userData'), getSettings: () => settings, notify: (t, b) => hub.notify(t, b, { app: 'Bildschirmzeit', glyph: '⏳', accent: '#ff3b30' }) });
app.whenReady().then(() => setTimeout(() => screenTime.start(), 6000));
app.on('before-quit', () => screenTime.stop());
handle('screentime:summary', (day) => screenTime.summary(typeof day === 'string' ? day : undefined));
handle('screentime:icon', async (exe) => {
  const file = screenTime.pathOf(String(exe || ''));
  if (!file) return '';
  try {
    const icon = await app.getFileIcon(file, { size: 'normal' });
    return icon.isEmpty() ? '' : icon.toDataURL();
  } catch {
    return '';
  }
});
handle('screentime:limit', (min) => {
  saveSettings({ screentimeLimit: Math.max(0, Math.min(24 * 60, Math.round(Number(min) || 0))) });
  return screenTime.summary();
});

/* ---------------- Fußball in der Island */
const { Football } = require('./football');
const football = new Football({
  getSettings: () => settings,
  saveSettings,
  notify: (title, body) => hub.notify(title, body, { app: 'Fußball', glyph: '⚽', accent: '#22c55e' }),
});
football.start();
handle('football:overview', () => football.overview());
handle('football:search', (q) => football.search(String(q || '')));
handle('football:teams', (teams) => football.setTeams(teams));
handle('football:options', (patch) => football.setOptions(patch));
handle('football:today', () => football.today());
handle('football:follow', (team) => football.follow(team));

function islandStatus() {
  const parts = [];
  if (chatCall) parts.push(`📞 ${chatCall.phase === 'ringing' ? 'Anruf von' : chatCall.phase === 'active' ? 'Anruf mit' : 'Anruf'} ${chatCall.name}${chatCall.phase === 'active' ? ' · aktiv' : chatCall.phase === 'ringing' ? ' · klingelt' : ''}`);
  if (football.status) parts.push(football.status);
  try {
    const ac = autoclick.status();
    if (ac.running) parts.push(`🖱️ Autoclicker läuft${ac.clicks ? ` · ${ac.clicks.toLocaleString('de-DE')} Klicks` : ''}`);
  } catch {
    /* noch nicht bereit */
  }
  if (settings.gameMode) parts.push('🎮 Game-Modus');
  if (settings.keepAwake) parts.push('☕ PC bleibt wach');
  const next = [...hubTimers.values()].sort((a, b) => a.at - b.at)[0];
  if (next && !orbit.running) parts.push(`⏰ ${next.label}`);
  if (account.status.syncing) parts.push('☁️ Konto wird abgeglichen');
  const text = parts.join('  ·  ');
  if (text === islandStatusLast || !orbit.running) return;
  islandStatusLast = text;
  orbit.post({ command: `status:${text}` });
}
setInterval(islandStatus, 3000);

/* ---------------- PC wach halten */
let awakeId = null;
function applyAwake(on) {
  if (on && awakeId === null) awakeId = powerSaveBlocker.start('prevent-display-sleep');
  if (!on && awakeId !== null) {
    powerSaveBlocker.stop(awakeId);
    awakeId = null;
  }
  return Boolean(on);
}
handle('awake', (on, minutes) => {
  const v = Boolean(on);
  saveSettings({ keepAwake: v, keepAwakeUntil: v && minutes ? Date.now() + Number(minutes) * 60000 : 0 });
  applyAwake(v);
  hub.pushState();
  islandStatus();
  hub.notify(v ? 'PC bleibt wach' : 'PC darf wieder schlafen', v ? 'Bildschirm und PC gehen nicht in den Ruhezustand.' : 'Energiesparen ist wieder normal.', { app: 'Revulution Hub', glyph: '☕' });
  return v;
});
setInterval(() => {
  if (settings.keepAwake && settings.keepAwakeUntil && Date.now() > settings.keepAwakeUntil) {
    saveSettings({ keepAwake: false, keepAwakeUntil: 0 });
    applyAwake(false);
    hub.notify('PC darf wieder schlafen', 'Die Wach-Zeit ist abgelaufen.', { app: 'Revulution Hub', glyph: '☕' });
    hub.pushState();
  }
}, 30000);

/* ---------------- Windows-Ton bei Meldungen aus (die Island spielt ihren eigenen) */
const SOUND_KEY = 'HKCU\\AppEvents\\Schemes\\Apps\\.Default\\Notification.Default\\.Current';
function regRead() {
  try {
    const out = require('child_process').execFileSync('reg', ['query', SOUND_KEY, '/ve'], { windowsHide: true, encoding: 'utf8' });
    const m = /REG_(?:EXPAND_)?SZ\s+(.*)$/m.exec(out);
    return m ? m[1].trim() : '';
  } catch {
    return null;
  }
}
function regWrite(value) {
  try {
    require('child_process').execFileSync('reg', ['add', SOUND_KEY, '/ve', '/t', 'REG_SZ', '/d', value, '/f'], { windowsHide: true, stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}
function applyWinSound() {
  if (process.platform !== 'win32') return;
  const off = settings.muteWinNotify !== false;
  const cur = regRead();
  if (cur === null) return;
  if (off && cur) {
    saveSettings({ winSoundBackup: cur });
    regWrite('');
  } else if (!off && !cur && settings.winSoundBackup) regWrite(settings.winSoundBackup);
}

handle('cc:timers', () => [...hubTimers.entries()].map(([id, x]) => ({ id, at: x.at, label: x.label })).sort((a, b) => a.at - b.at));

/* Game-Modus: nur Crosshair, Clipper, Aufnahmen und Island laufen – alles andere wird entladen */
function applyGameMode(on) {
  if (on) {
    for (const [id, view] of hub.views) {
      if (id === 'gaming') continue;
      if (view.unload?.()) hub.opened.delete(id);
    }
    if (hub.active !== 'gaming' && hub.active !== 'home') hub.active = 'home';
  }
  hub.layout();
  hub.pushState();
}
handle('gamemode', (on) => {
  saveSettings({ gameMode: Boolean(on) });
  applyGameMode(Boolean(on));
  islandStatus();
  if (!on) hub.notify('Game-Modus aus', 'Alle Apps sind wieder verfügbar.', { app: 'Revulution Hub', glyph: '🎮' });
  if (on) hub.notify('Game-Modus an', 'Nur Crosshair, Clipper, Aufnahmen und die Island laufen – der Rest ist entladen.', { app: 'Revulution Hub', glyph: '🎮' });
  return Boolean(on);
});
/* Rechtsklick im Dock → App beenden */
handle('module:close', (id) => {
  const view = hub.views.get(id);
  if (!view || id === 'gaming') return false;
  const ok = view.unload();
  hub.opened.delete(id);
  if (hub.active === id) hub.active = 'home';
  hub.layout();
  hub.pushState();
  return ok;
});
/* ---------------- RAM sparen: lange unbenutzte Apps im Hintergrund beenden
 * Video-Schnitt und Dokumente bleiben (ungespeicherte Arbeit), Gaming Hub, Chats und
 * Agenda arbeiten im Hintergrund. Beim nächsten Öffnen lädt die App einfach neu. */
const lastUsed = new Map();
const IDLE_UNLOAD = { geo: 10, screenshot: 5, dropzone: 15, chess: 15, beat: 15 }; // Minuten
setInterval(() => {
  if (hub.active) lastUsed.set(hub.active, Date.now());
  for (const [id, minutes] of Object.entries(IDLE_UNLOAD)) {
    if (id === hub.active || !hub.opened.has(id)) continue;
    const used = lastUsed.get(id) || 0;
    if (!used) {
      lastUsed.set(id, Date.now());
      continue;
    }
    if (Date.now() - used < minutes * 60000) continue;
    const view = hub.views.get(id);
    if (view?.unload()) {
      hub.opened.delete(id);
      lastUsed.delete(id);
      hub.pushState();
    }
  }
}, 60000);
handle('cc:screenshot', () => control.screenshot());
handle('tool:fetch', (url) => control.toolFetch(url));
handle('clickClip', () => clickClip());
handle('clickPack', () => clickPack());

/* Autoclicker und Schutz (Tracker-Karte, Virenscan) */
const { AutoClicker, clean: cleanAutoclick } = require('./autoclick');
const { Shield } = require('./shield');
let autoclickWasRunning = false;
const autoclick = new AutoClicker({
  getConfig: () => settings.autoclick || {},
  onChange: (status) => {
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:autoclick', status);
    if (status.running !== autoclickWasRunning) {
      autoclickWasRunning = status.running;
      hub.notify(status.running ? 'Autoclicker gestartet' : 'Autoclicker gestoppt', status.running ? `Stopp mit ${status.hotkey || 'dem Hotkey'}.` : `${status.clicks.toLocaleString('de-DE')} Klicks · ${status.presses.toLocaleString('de-DE')} Tastendrücke`, { app: 'Autoclicker', glyph: '🖱️' });
    }
    islandStatus();
  },
});
/* Tastatur: Umbelegung, Makros, Profile pro App */
const { Keyboard, clean: cleanKeyboard } = require('./keyboard');
const keyboard = new Keyboard({
  dir: app.getPath('userData'),
  getConfig: () => settings.keyboard || {},
  onChange: (st) => hub.window && !hub.window.isDestroyed() && hub.window.webContents.send('hub:keyboard', st),
});
handle('kb:status', () => keyboard.status());
handle('kb:apply', () => keyboard.apply());
handle('kb:devices', () => keyboard.devices());
handle('kb:open', (id) => keyboard.openTool(String(id || '')));
handle('kb:lighting', () => shell.openExternal('ms-settings:personalization-lighting'));
/* AJAZZ AK820 Pro direkt steuern (Kabelmodus) */
const { AjazzKeyboard, MODES: AJAZZ_MODES } = require('./ajazz');
const ajazz = new AjazzKeyboard({
  dir: app.getPath('userData'),
  onProgress: (p) => hub.window && !hub.window.isDestroyed() && hub.window.webContents.send('hub:ajazz-progress', p),
});
handle('aj:probe', () => ajazz.probe());
handle('aj:modes', () => AJAZZ_MODES);
handle('aj:light', (cfg) => ajazz.light(cfg || {}));
handle('aj:clock', () => ajazz.clock());
handle('aj:sleep', (m) => ajazz.sleep(m));
handle('aj:battery', () => ajazz.battery());
handle('aj:tft', (frames, slot) => ajazz.tft(frames, slot));
/* Mitgelieferte Standard-GIFs fürs Display (liegen neben der Oberfläche). */
const AJAZZ_GIFS = { wireframe: 'wireframe.gif', pixel: 'pixel.gif', mini: 'mini.gif' };
handle('aj:gif', (id) => {
  const name = AJAZZ_GIFS[String(id || '')];
  if (!name) return null;
  const file = path.join(UI_DIR, 'assets', 'gifs', name);
  const data = fs.readFileSync(file);
  return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
});
/* Nachrichten aus dem Hub-Chat („Revolutionland“) fürs Tastatur-Display */
const screenFeed = { list: [] };
function screenAdd(item) {
  const text = String(item?.text || '').trim().slice(0, 160);
  if (!text) return false;
  const entry = { from: String(item?.from || 'Revolutionland').slice(0, 24), chat: String(item?.chat || '').slice(0, 32), text, at: Date.now() };
  screenFeed.list = [entry, ...screenFeed.list].slice(0, 40);
  if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:ajazz-feed', entry);
  return true;
}
global.__revolutionHub.ajazzFeed = screenAdd;
global.__revolutionHub.chatCall = setChatCall;
handle('aj:feed', () => screenFeed.list);
/* Ganzes PC-RGB direkt über den ASRock-HID-Controller – ohne OpenRGB-Download. */
const { AsrockRgb, EFFECTS: RGB_EFFECTS } = require('./asrock');
const openrgb = new AsrockRgb({
  dir: app.getPath('userData'),
  getSwap: () => settings.rgbSwap || {},
  onChange: (st) => hub.window && !hub.window.isDestroyed() && hub.window.webContents.send('hub:openrgb', st),
});
handle('rgb:status', () => openrgb.status());
handle('rgb:install', () => openrgb.install());
handle('rgb:connect', () => openrgb.connect());
handle('rgb:rescan', () => openrgb.rescan());
handle('rgb:effect', (cfg) => openrgb.startEffect(cfg || {}));
handle('rgb:stop', () => {
  openrgb.stopEffect();
  return openrgb.status();
});
handle('rgb:mode', (i, opts) => openrgb.setMode(Number(i) || 0, opts || {}));
handle('rgb:save', (cfg) => {
  saveSettings({ rgb: cleanRgb(cfg) });
  return settings.rgb;
});
/* Handy-Spiegelung über AirPlay (Empfänger + Fensteraufnahme im Hub) */
const { AirPlay, PAGE: AIRPLAY_PAGE } = require('./airplay');
const airplay = new AirPlay({
  dir: app.getPath('userData'),
  onChange: (st) => hub.window && !hub.window.isDestroyed() && hub.window.webContents.send('hub:airplay', st),
});
let airplayArmed = false;
async function airplaySource() {
  if (!electron.desktopCapturer) return null;
  const list = await electron.desktopCapturer.getSources({ types: ['window'], thumbnailSize: { width: 2, height: 2 } });
  return list.find((s) => /airplay/i.test(s.name)) || null;
}
handle('ap:status', () => airplay.status());
handle('ap:install', () => airplay.install());
handle('ap:start', () => airplay.start());
handle('ap:stop', () => airplay.stop());
handle('ap:focus', () => airplay.focus());
handle('ap:arm', () => {
  // Erlaubt der Seite einmal, das AirPlay-Fenster aufzunehmen (ohne Auswahl-Dialog).
  airplayArmed = true;
  return true;
});
handle('ap:source', async () => Boolean(await airplaySource()));
handle('ap:page', () => AIRPLAY_PAGE);
/* Ganzes PC-RGB über SignalRGB */
const { SignalRgb } = require('./signalrgb');
const signalrgb = new SignalRgb();
handle('srgb:status', () => signalrgb.status());
handle('srgb:effects', (force) => signalrgb.list(Boolean(force)));
handle('srgb:apply', (id) => signalrgb.apply(String(id || '')));
handle('srgb:brightness', (n) => signalrgb.brightness(n));
handle('srgb:enabled', (on) => signalrgb.enabled(on));
handle('srgb:step', (dir) => signalrgb.step(String(dir || 'next')));
handle('srgb:layout', (name) => signalrgb.layout(name));
handle('srgb:start', () => signalrgb.start());
const shield = new Shield({ notify: (title, body) => hub.notify(title, body, { app: 'Schutz', accent: '#f87171', glyph: '🛡️' }), getSettings: () => settings.shield || {} });
/* Updates über das Internet (Adresse in den Optionen) */
const { Updater, httpsUrl } = require('./updater');
// Offizielle Update-Adresse (GitHub). In den Optionen lässt sie sich überschreiben.
const DEFAULT_UPDATE_URL = (() => {
  try {
    return require('./update-source.json').url || '';
  } catch {
    return '';
  }
})();
const updater = new Updater({
  getUrl: () => DEFAULT_UPDATE_URL, // fest: unser GitHub-Update-Server
  beforeIsland: () => (orbit.running ? orbit.stop() : null),
  onProgress: (p) => {
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:update', p);
    if (dockView && !dockView.webContents.isDestroyed()) dockView.webContents.send('hub:update', p);
  },
});
let updateFound = null;
async function checkForUpdate(manual = false) {
  const r = await updater.check();
  if (r.ok && r.available) {
    updateFound = { version: r.version, notes: r.notes || '', dismissed: settings.updateDismissed === r.version };
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:update-available', updateFound);
    if (dockView && !dockView.webContents.isDestroyed()) dockView.webContents.send('hub:update-available', updateFound);
  } else if (manual) updateFound = null;
  return r;
}
handle('update:check', () => checkForUpdate(true));
handle('update:pending', () => updateFound);
handle('update:dismiss', (version) => {
  saveSettings({ updateDismissed: String(version || '') });
  if (updateFound) updateFound.dismissed = true;
  return true;
});
handle('update:install', () => updater.install());
handle('ac:status', () => autoclick.status());
handle('ac:start', () => autoclick.start());
handle('ac:stop', () => autoclick.stop());
handle('ac:pick', (ms) => autoclick.pickPosition(ms));
handle('shield:trackers', () => shield.trackers({ quiet: true }));
handle('shield:last', () => shield.last);
handle('shield:defender', () => shield.defender());
handle('shield:update', () => shield.updateSignatures());
handle('shield:scan', async (kind) => {
  if (kind === 'quick') return shield.scan('quick');
  const picked = await electron.dialog.showOpenDialog(hub.window, { title: kind === 'folder' ? 'Ordner prüfen' : 'Datei prüfen', properties: [kind === 'folder' ? 'openDirectory' : 'openFile'] });
  if (picked.canceled || !picked.filePaths[0]) return null;
  return shield.scan('path', picked.filePaths[0]);
});
handle('tool:clipboard', (action, value) => control.clipboardApi(action, value));
handle('tool:notify', (title, body) => {
  hub.notify(String(title).slice(0, 60), String(body || '').slice(0, 140), { app: 'Revulution Hub' });
  return true;
});
handle('speed:history', () => settings.speedHistory || []);
handle('speed:run', async () => {
  const send = (p) => {
    if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('hub:speed', p);
    for (const w of taskbarWindows) if (w && !w.isDestroyed()) w.webContents.send('hub:speed', p);
  };
  const r = await require('./speedtest').run(send);
  saveSettings({ speedHistory: [{ at: r.at, down: r.down, up: r.up, ping: r.ping }, ...(settings.speedHistory || [])].slice(0, 10) });
  hub.notify(`WLAN-Test: ${String(r.down).replace('.', ',')} MBit/s`, `↑ ${String(r.up).replace('.', ',')} MBit/s · Ping ${r.ping} ms · ${r.grade || ''}`, { app: 'WLAN-Test', glyph: '📶' });
  return r;
});
handle('music:get', () => global.__revolutionHub.music?.get() || null);
handle('music:set', (patch) => global.__revolutionHub.music?.set(patch) || null);
handle('music:demo', () => global.__revolutionHub.music?.demo() || null);
handle('orbit:start', () => applyIslandMonitor().catch(() => {}).then(() => orbit.start()).then(() => hub.pushState()));
handle('orbit:stop', () => orbit.stop().then(() => hub.pushState()));
/** Angeschlossene Monitore mit ihrem Windows-Gerätenamen (so erwartet ihn die Island). */
let monitorNames = null;
function monitorDevices() {
  if (monitorNames) return Promise.resolve(monitorNames);
  return new Promise((resolve) => {
    require('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::AllScreens | ForEach-Object { '{0}|{1}|{2}|{3}x{4}' -f $_.DeviceName, $_.Primary, $_.Bounds.X, $_.Bounds.Width, $_.Bounds.Height }"], { windowsHide: true, timeout: 8000 }, (error, stdout) => {
      const rows = error ? [] : String(stdout).trim().split(/\r?\n/).map((l) => l.trim().split('|')).filter((p) => p.length >= 4);
      monitorNames = rows.sort((a, b) => Number(a[2]) - Number(b[2])).map((p, i) => ({ name: p[0], primary: p[1] === 'True', text: `Monitor ${i + 1} · ${p[3].replace('x', '×')}${p[1] === 'True' ? ' · Hauptmonitor' : ''}` }));
      setTimeout(() => (monitorNames = null), 15000);
      resolve(monitorNames);
    });
  });
}
handle('orbit:settings', async () => {
  const current = orbit.readSettings();
  return { ...current, defaults: orbit.defaults(), wallpapers: orbit.wallpapers(), running: orbit.running, monitors: await monitorDevices().catch(() => []) };
});
/**
 * Island sitzt von selbst auf dem zweiten Bildschirm (das Crosshair bleibt auf dem Hauptbildschirm).
 * Sobald du in den Island-Einstellungen selbst einen Monitor wählst, gilt deine Wahl.
 */
async function applyIslandMonitor() {
  if (settings.islandMonitorAuto === false) return;
  const mons = await monitorDevices().catch(() => []);
  if (!mons.length) return;
  const second = mons.find((m) => !m.primary);
  const want = second ? second.name : '';
  const cur = orbit.readSettings().settings?.Position?.MonitorId || '';
  if (cur !== want) await orbit.writeSettings({ Position: { MonitorId: want } });
}
handle('orbit:save', async (patch) => {
  const chosen = patch?.Position?.MonitorId;
  if (chosen === '__auto__') {
    saveSettings({ islandMonitorAuto: true });
    delete patch.Position.MonitorId;
    await orbit.writeSettings(patch);
    return applyIslandMonitor();
  }
  if (typeof chosen === 'string') saveSettings({ islandMonitorAuto: false });
  return orbit.writeSettings(patch);
});
handle('orbit:native', () => orbit.openNativeSettings());
handle('orbit:command', (name) => (['face', 'newevent'].includes(name) ? orbit.command(name) : false));
handle('openData', (id) => {
  const dir = id === 'hub' ? app.getPath('userData') : id === 'orbit' ? path.dirname(orbit.settingsFile()) : moduleById(id)?.dataDir;
  if (dir) {
    fs.mkdirSync(dir, { recursive: true });
    shell.openPath(dir);
  }
});
handle('external', (url) => {
  if (/^https:\/\//.test(url)) shell.openExternal(url);
});

/** "Auch für Orbit Island": the island plays the same live wallpaper as the hub. */
async function syncIslandWallpaper() {
  const current = orbit.readSettings();
  const base = current.settings || { ...orbit.defaults().settings, FirstRun: false };
  const file = settings.wallpaper === 'none' ? '' : orbit.wallpaperPath(settings.wallpaper);
  if ((base.Appearance?.WallpaperFile || '') === file) return;
  await orbit.writeSettings({ Appearance: { WallpaperFile: file, Wallpaper: file ? base.Appearance?.Wallpaper || 'Nebula' : 'Off' } });
}

/* ----------------------------------------------------------------- lifecycle */

app.on('second-instance', (_event, argv) => {
  if (argv.includes('--hidden')) return;
  // Links aus der Island: revulution://open/<seite>
  const link = argv.find((a) => /^revulution:\/\//i.test(a));
  if (link) {
    const target = /^revulution:\/\/open\/([a-z0-9-]+)/i.exec(link)?.[1];
    hub.open(target && PAGES.has(target) ? target : hub.active);
    return;
  }
  // z. B. aus der Island: "Revolution Hub.exe --open=settings"
  const page = (argv.find((a) => a.startsWith('--open='))?.slice(7)) || (argv.find((a) => a.startsWith('--page='))?.slice(7));
  hub.open(page && PAGES.has(page) ? page : hub.active);
});

// The hub's ready handler is registered before the modules load, so the hub window
// exists by the time each module creates its main view.
app.whenReady().then(() => {
  // Fensteraufnahme für die AirPlay-Spiegelung: nur wenn die Seite es anfordert,
  // wird das Empfänger-Fenster gewählt (kein Auswahl-Dialog für den Nutzer).
  try {
    electron.session.defaultSession.setDisplayMediaRequestHandler(async (_request, callback) => {
      if (!airplayArmed) return callback({});
      airplayArmed = false;
      try {
        const source = await airplaySource();
        callback(source ? { video: source } : {});
      } catch {
        callback({});
      }
    });
  } catch {
    /* ältere Electron-Version */
  }
  control.startClipboard();
  // Benachrichtigungstöne für die Island (Auswahl in den Island-Einstellungen)
  try {
    const dir = path.join(process.env.APPDATA || app.getPath('appData'), 'PulseIsland', 'sounds');
    fs.mkdirSync(dir, { recursive: true });
    for (const f of ['chime-a.wav', 'chime-b.wav']) {
      const from = path.join(__dirname, '..', 'shared', 'assets', f);
      const to = path.join(dir, f);
      if (fs.existsSync(from) && (!fs.existsSync(to) || fs.statSync(to).size !== fs.statSync(from).size)) fs.copyFileSync(from, to);
    }
  } catch {
    /* ohne eigene Töne spielt die Island ihren Standardton */
  }
  if (settings.gameMode) setTimeout(() => applyGameMode(true), 1500);
  if (settings.keepAwake) applyAwake(true);
  applyWinSound();
  setTimeout(() => account.restore(), 3000);
  autoclick.bindHotkey();
  try {
    keyboard.apply();
  } catch {
    /* egal */
  }
  if (settings.rgb?.autoConnect === true) setTimeout(async () => {
    const st = await openrgb.connect().catch(() => null);
    if (st?.running && settings.rgb?.effect && settings.rgb.effect !== 'off') openrgb.startEffect(settings.rgb).catch(() => {});
  }, 6000);
  shield.watch();
  startEscapeWatch();
  if (!settings.replaceTaskbar) {
    // Ohne obere Leiste muss die Windows-Leiste immer sichtbar sein.
    const showWindowsBar = () => setTaskbarHidden(false, true).catch(() => {});
    showWindowsBar();
    setTimeout(showWindowsBar, 1200);
    setTimeout(showWindowsBar, 4000);
  }
  if (settings.crosshairOn && !gamingCrosshair()) setTimeout(() => !gamingCrosshair() && openCrosshairWindow(), 4000);
  syncDesktopWidgets();
  try {
    electron.globalShortcut.register('CommandOrControl+Shift+M', () => {
      hub.showWindow();
      hub.window?.webContents.send('hub:open-control', 'mixer');
    });
  } catch {
    /* Tastenkürzel belegt */
  }
  try {
    const winSpace = electron.globalShortcut.isRegistered('Super+Space') || electron.globalShortcut.register('Super+Space', toggleTaskbarDrawer);
    console.log(`[taskbar] Windows-Taste ${process.platform === 'win32' ? 'Beobachter' : 'Tastenkürzel'}, Super+Space ${winSpace ? 'aktiv' : 'belegt'}`);
  } catch {
    /* Windows-Taste ist vom System belegt – die Leiste bleibt klickbar. */
  }
  try {
    powerMonitor.on('lock-screen', () => {
      if (hub.quitting) return;
      showLockScreen('windows');
    });
    powerMonitor.on('unlock-screen', () => {
      if (!lockWindows.length) return;
      for (const win of lockWindows) sendLockState(win);
      clearTimeout(lockAutoClose);
      lockAutoClose = setTimeout(dismissLockScreen, 2600);
    });
  } catch {
    /* powerMonitor ist auf älteren Systemen eingeschränkt */
  }
  // Einmal kurz nach dem Start nach Updates sehen (wenn eine Adresse eingetragen ist)
  // Automatisch nach Updates suchen: kurz nach dem Start und dann alle 4 Stunden
  const autoCheck = () => {
    if (settings.updateAuto === false || !DEFAULT_UPDATE_URL) return;
    checkForUpdate().then((r) => {
      if (r.ok && r.available && settings.updateNotified !== r.version) {
        saveSettings({ updateNotified: r.version });
        hub.notify(`Update ${r.version} ist da`, 'Unten im Hub: „Aktualisieren“ spielt es mit einem Klick ein.', { app: 'Revulution Hub', glyph: '⬆️' });
      }
    }).catch(() => {});
  };
  // Bestehende Installationen kennen den Hub schon – Willkommen nur beim allerersten Start
  if (settings.onboarded === undefined && (settings.lastPage || settings.profileAt || settings.seenVersion)) saveSettings({ onboarded: true });
  setTimeout(autoCheck, 8000);
  setInterval(autoCheck, 30 * 60 * 1000); // alle 30 Minuten
  Menu.setApplicationMenu(null);
  const launchPage = (process.argv.find((a) => a.startsWith('--page=')) || '').slice(7);
  hub.active = PAGES.has(launchPage) ? launchPage : settings.startPage === 'last' && PAGES.has(settings.lastPage) ? settings.lastPage : 'home';
  if (hub.active === 'settings' || hub.active === 'orbit') hub.active = 'home';
  hub.opened.add(hub.active);
  // Was beim letzten Mal offen war, ist wieder da (z. B. die laufende Schachpartie)
  for (const id of Array.isArray(settings.openedPages) ? settings.openedPages : []) if (PAGES.has(id) && moduleById(id)) hub.opened.add(id);
  // 2.26: die eigene Leiste unten in der Mitte ersetzt die Windows-Taskleiste (einmalig einschalten)
  // 2.28.2: die eigene untere Leiste ist standardmäßig aus (Windows-Taskleiste bleibt) – einschalten unter Desktop.
  if (!settings.bottomBarOff2282) saveSettings({ replaceTaskbar: false, bottomBar226: true, bottomBar228: true, bottomBarOff2282: true });
  // 2.25: die neuen Revulution-Klicks einmalig als Standard setzen
  if (!settings.soundPack225) saveSettings({ clickSound: 'nothing', soundPack225: true });
  createWindow();
  createTray();
  applyAutoStart();
  for (const event of ['display-added', 'display-removed', 'display-metrics-changed']) {
    screen.on(event, () => {
      clearTimeout(syncDesktopWidgets.timer);
      syncDesktopWidgets.timer = setTimeout(syncDesktopWidgets, 400);
      if (!settings.replaceTaskbar || !hub.window) return;
      clearTimeout(restartTaskbarWindows.timer);
      restartTaskbarWindows.timer = setTimeout(() => {
        if (settings.replaceTaskbar) restartTaskbarWindows();
      }, 180);
    });
  }
  if (settings.replaceTaskbar) {
    setTimeout(async () => {
      try {
        await setTaskbarHidden(true).catch(() => false);
        keepTaskbarHidden(true);
        buildTaskbarWindows();
        startTaskbarWatch();
        startWinKeyWatch();
        refreshWindowsTaskbar();
        setInterval(refreshWindowsTaskbar, 4000);
        windowsTaskbar.preloadSearch();
      } catch (error) {
        console.error('[taskbar] Leiste konnte nicht gestartet werden:', error);
        closeTaskbarWindows();
        stopTaskbarWatch();
        stopWinKeyWatch();
        await setTaskbarHidden(false).catch(() => {});
        saveSettings({ replaceTaskbar: false });
        hub.pushState();
      }
    }, 600);
  }
  // Alte Einzel-Apps (Island, Gaming Hub, Dropzone) dürfen nicht parallel laufen –
  // alles kommt aus dem Hub.
  orbit
    .takeOver()
    .catch(() => {})
    .then(() => {
      orbit.autoReplace = true;
      orbit.watch();
      orbit.watchCamera((active) => {
        const view = hub.views.get('gaming');
        if (view && !view.webContents.isDestroyed()) view.webContents.executeJavaScript(`window.__revCamPause && window.__revCamPause(${active})`, true).catch(() => {});
      });
      if (settings.orbitWithHub && orbit.available()) applyIslandMonitor().catch(() => {}).then(() => orbit.start()).catch(() => {});
    });
});

for (const mod of MODULES) {
  try {
    require(path.join(mod.dir, mod.entry));
  } catch (error) {
    mod.error = error?.message || String(error);
    console.error(`[hub] module ${mod.id} failed to load`, error);
  }
}

protocol.registerSchemesAsPrivileged(privilegedSchemes);

process.on('exit', () => {
  closeTaskbarWindows();
  stopTaskbarWatch();
  stopWinKeyWatch();
  dismissLockScreen();
  restoreTaskbarSync();
});

app.on('before-quit', () => {
  hub.quitting = true;
  dismissLockScreen();
  closeTaskbarWindows();
  stopTaskbarWatch();
  stopWinKeyWatch();
  try { electron.globalShortcut.unregister('Super+Space'); } catch { /* egal */ }
  restoreTaskbarSync();
  autoclick.shutdown();
  keyboard.stop();
  ajazz.stop();
  openrgb.stop();
  airplay.stop();
  shield.shutdown();
  orbit.shutdown();
});

app.on('window-all-closed', () => {
  if (hub.quitting) app.quit();
});
