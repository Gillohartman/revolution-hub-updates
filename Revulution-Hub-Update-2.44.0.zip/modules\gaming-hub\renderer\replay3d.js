'use strict';

/* 2.44 Replay in 3D
   Liest Laufwege aller Spieler, den Sturm und die Todesorte aus einem Fortnite-Replay und zeigt sie
   als drehbare 3D-Szene: abspielen, vor- und zurückspulen, nur das eigene Team zeigen und mit der
   Maus auf den Boden zeichnen (Taktik-Skizzen bleiben pro Match gespeichert). */
(() => {
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const COLORS = ['#ffffff', '#ff453a', '#ffd60a', '#30d158', '#0a84ff', '#bf5af2'];
  let root = null;
  let cv = null;
  let ctx = null;
  let data = null;
  let file = '';
  let raf = 0;
  const st = { t: 0, t0: 0, t1: 1, playing: false, speed: 8, last: 0, team: false, mode: 'orbit', color: '#ffd60a', yaw: -Math.PI / 4, pitch: 0.75, dist: 160000, tx: 0, ty: 0, tz: 0, sketches: [], drawing: null, me: null, view: 'drone', fx: 0, fy: 0, fz: 3000, lyaw: 0, lpitch: -0.2, pyaw: 0, keys: new Set(), hf: null };

  const fmt = (s) => `${Math.floor(Math.max(0, s) / 60)}:${String(Math.floor(Math.max(0, s) % 60)).padStart(2, '0')}`;

  function open() {
    if (root) return;
    root = document.createElement('div');
    root.className = 'r3d';
    root.innerHTML = `
      <div class="r3d-top">
        <b class="r3d-title">Replay in 3D</b>
        <select class="r3d-sel" id="r3d-sel"><option>Replays werden geladen …</option></select>
        <div class="r3d-tools">
          <button data-view="drone" class="on" title="Drohne: ziehen dreht, rechte Maustaste verschiebt, Mausrad zoomt">Drohne</button>
          <button data-view="player" title="Spieler-Sicht: die Kamera fliegt hinter dir her">Spieler</button>
          <button data-view="free" title="Frei fliegen: W A S D, Leertaste hoch, Strg runter, Umschalt schneller, Maus ziehen schaut">Frei</button>
          <i class="r3d-sep"></i>
          <button data-mode="draw" title="Auf das Gelände zeichnen">Zeichnen</button>
          <span class="r3d-cols">${COLORS.map((c) => `<i data-col="${c}" style="--c:${c}" class="${c === st.color ? 'on' : ''}"></i>`).join('')}</span>
          <button data-act="undo" title="Letzten Strich weg">↶</button>
          <button data-act="clear" title="Alle Striche löschen">Löschen</button>
          <button data-act="team" title="Nur dich und dein Team zeigen">Nur Team</button>
          <button data-act="me" title="Kamera auf dich">Zu mir</button>
        </div>
        <button class="r3d-x" data-act="close" title="Schließen">✕</button>
      </div>
      <canvas class="r3d-cv"></canvas>
      <div class="r3d-msg" id="r3d-msg">Replay wird gelesen …</div>
      <div class="r3d-legend"><span><i style="background:#fff"></i>Du</span><span><i style="background:#0a84ff"></i>Team</span><span><i style="background:#ff6b6b"></i>Gegner</span><span><i class="x">✕</i>Eliminiert</span><span><i class="ring"></i>Sturm</span></div>
      <div class="r3d-bar">
        <button class="r3d-play" data-act="play"><svg viewBox="0 0 24 24"><path d="M8 5.5v13l11-6.5z"/></svg></button>
        <span class="r3d-time" id="r3d-time">0:00</span>
        <input type="range" class="r3d-range" id="r3d-range" min="0" max="1000" value="0" />
        <span class="r3d-time" id="r3d-end">0:00</span>
        <button class="r3d-speed" data-act="speed">8×</button>
      </div>`;
    document.body.appendChild(root);
    cv = root.querySelector('.r3d-cv');
    ctx = cv.getContext('2d');
    root.addEventListener('click', onClick);
    root.querySelector('#r3d-sel').addEventListener('change', (e) => load(e.target.value));
    root.querySelector('#r3d-range').addEventListener('input', (e) => {
      st.t = st.t0 + (Number(e.target.value) / 1000) * (st.t1 - st.t0);
      draw();
    });
    bindMouse();
    window.addEventListener('resize', size);
    document.addEventListener('keydown', onKey);
    document.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', () => st.keys.clear());
    size();
    list();
  }

  function close() {
    cancelAnimationFrame(raf);
    raf = 0;
    window.removeEventListener('resize', size);
    document.removeEventListener('keydown', onKey);
    document.removeEventListener('keyup', onKeyUp);
    st.keys.clear();
    root?.remove();
    root = null;
    data = null;
  }
  function onKey(e) {
    if (e.key === 'Escape') close();
    else if (st.view === 'free' && ['w', 'a', 's', 'd', ' ', 'Control', 'Shift'].includes(e.key.length === 1 ? e.key.toLowerCase() : e.key)) {
      e.preventDefault();
      st.keys.add(e.key.length === 1 ? e.key.toLowerCase() : e.key);
      flyLoop();
    } else if (e.key === ' ' && e.target.tagName !== 'SELECT') {
      e.preventDefault();
      togglePlay();
    }
  }

  function onKeyUp(e) {
    st.keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key);
  }

  async function list() {
    const sel = root.querySelector('#r3d-sel');
    let items = [];
    try {
      items = await window.xh.replayList();
    } catch {
      items = [];
    }
    if (!items.length) {
      sel.innerHTML = '<option>Keine Replays gefunden</option>';
      msg('Keine Replays gefunden. In Fortnite unter Einstellungen „Replays aufnehmen“ einschalten und danach „Replays scannen“.');
      return;
    }
    sel.innerHTML = items
      .map((m) => {
        const d = m.date ? new Date(m.date) : null;
        const when = d && !Number.isNaN(d.getTime()) ? d.toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : m.file;
        return `<option value="${esc(m.file)}">${esc(when)} · #${m.placement || '–'} · ${m.kills} Kills</option>`;
      })
      .join('');
    load(items[0].file);
  }

  function msg(t) {
    const m = root?.querySelector('#r3d-msg');
    if (!m) return;
    m.textContent = t || '';
    m.hidden = !t;
  }

  async function load(f) {
    file = f;
    data = null;
    st.playing = false;
    playIcon();
    msg('Replay wird gelesen … (beim ersten Mal ein paar Sekunden)');
    draw();
    try {
      const d = await window.xh.replayTrack(f);
      if (file !== f || !root) return;
      const tracks = (d.tracks || []).filter((t) => t.pts?.length);
      if (!tracks.length) throw new Error('In diesem Replay sind keine Laufwege gespeichert.');
      data = { ...d, tracks };
      st.me = tracks.find((t) => t.me) || tracks.find((t) => d.meId && t.id === d.meId) || tracks.find((t) => d.meName && t.name === d.meName) || null;
      if (st.me) st.me.me = true;
      const myTeam = st.me?.team;
      for (const t of tracks) t.kind = t.me ? 'me' : myTeam != null && t.team === myTeam ? 'team' : 'enemy';
      let t0 = Infinity;
      let t1 = 0;
      for (const t of tracks) {
        t0 = Math.min(t0, t.pts[0][0]);
        t1 = Math.max(t1, t.pts[t.pts.length - 1][0]);
      }
      st.t0 = t0;
      st.t1 = Math.max(t0 + 1, t1);
      st.t = st.t0;
      root.querySelector('#r3d-end').textContent = fmt(st.t1 - st.t0);
      try {
        st.sketches = JSON.parse(localStorage.getItem(`r3d:${f}`) || '[]');
      } catch {
        st.sketches = [];
      }
      buildTerrain();
      fitAll();
      msg('');
      draw();
    } catch (e) {
      if (file === f) msg(String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''));
    }
  }

  /* ------------------------------------------------------------ Gelände
     Aus allen Positionen (Laufen, Bauen, Springen) ergibt sich pro Feld die tiefste Stelle, auf der
     jemand stand – das ist ziemlich genau der Boden. Daraus wird eine Höhenkarte, auf die man zeichnet. */
  const CELL = 700;
  function buildTerrain() {
    const m = new Map();
    for (const tr of data.tracks) {
      for (const p of tr.pts) {
        const k = `${Math.floor(p[1] / CELL)},${Math.floor(p[2] / CELL)}`;
        const cur = m.get(k);
        if (cur === undefined || p[3] < cur) m.set(k, p[3]);
      }
    }
    const zs = [...m.values()].sort((a, b) => a - b);
    const base = zs.length ? zs[Math.floor(zs.length * 0.2)] : 0;
    // Felder, in denen nur geflogen wurde (Bus, Gleiter), sind kein Boden
    for (const [k, z] of m) if (z > base + 12000) m.delete(k);
    // Lücken zwischen den Wegen füllen: leere Nachbarfelder mit mind. 2 bekannten Nachbarn bekommen den Mittelwert
    for (let pass = 0; pass < 4 && m.size < 60000; pass++) {
      const add = [];
      const seen = new Set();
      for (const k of m.keys()) {
        const [a0, b0] = k.split(',').map(Number);
        for (let dx = -1; dx <= 1; dx++) {
          for (let dy = -1; dy <= 1; dy++) {
            const nk = `${a0 + dx},${b0 + dy}`;
            if (m.has(nk) || seen.has(nk)) continue;
            seen.add(nk);
            let sum = 0;
            let n = 0;
            for (let ex = -1; ex <= 1; ex++) {
              for (let ey = -1; ey <= 1; ey++) {
                const z = m.get(`${a0 + dx + ex},${b0 + dy + ey}`);
                if (z !== undefined) {
                  sum += z;
                  n++;
                }
              }
            }
            if (n >= 2) add.push([nk, sum / n]);
          }
        }
      }
      for (const [k, z] of add) m.set(k, z);
    }
    const cells = [...m].map(([k, z]) => {
      const [a, b] = k.split(',').map(Number);
      return [(a + 0.5) * CELL, (b + 0.5) * CELL, z];
    });
    let lo = Infinity;
    let hi = -Infinity;
    for (const c of cells) {
      lo = Math.min(lo, c[2]);
      hi = Math.max(hi, c[2]);
    }
    st.hf = { m, cells, base, lo, hi };
  }
  function heightAt(x, y) {
    const hf = st.hf;
    if (!hf) return 0;
    const z = hf.m.get(`${Math.floor(x / CELL)},${Math.floor(y / CELL)}`);
    return z === undefined ? hf.base : z;
  }
  function terrainColor(z) {
    const hf = st.hf;
    const k = Math.max(0, Math.min(1, (z - hf.lo) / Math.max(1, hf.hi - hf.lo)));
    // Wiese → Fels → Schnee
    const stops = [[46, 125, 78], [96, 150, 80], [150, 130, 95], [235, 235, 240]];
    const f = k * (stops.length - 1);
    const i = Math.min(stops.length - 2, Math.floor(f));
    const t = f - i;
    const c = stops[i].map((v, j) => Math.round(v + (stops[i + 1][j] - v) * t));
    return `rgb(${c[0]},${c[1]},${c[2]})`;
  }
  /** Position eines Spielers zur Zeit t (zwischen zwei Punkten weich) */
  function posAt(tr, t) {
    const pts = tr.pts;
    if (t <= pts[0][0]) return [pts[0][1], pts[0][2], pts[0][3], 0];
    for (let i = 1; i < pts.length; i++) {
      if (pts[i][0] >= t) {
        const a = pts[i - 1];
        const b = pts[i];
        const k = (t - a[0]) / Math.max(0.01, b[0] - a[0]);
        return [a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k, a[3] + (b[3] - a[3]) * k, Math.atan2(b[2] - a[2], b[1] - a[1])];
      }
    }
    const l = pts[pts.length - 1];
    return [l[1], l[2], l[3], 0];
  }

  /* ------------------------------------------------------------ Kamera */
  function fitAll() {
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    const pts = st.me ? st.me.pts.filter((p) => p[3] < 20000) : [];
    const src = pts.length > 5 ? pts : data.tracks.flatMap((t) => t.pts);
    for (const p of src) {
      minX = Math.min(minX, p[1]);
      maxX = Math.max(maxX, p[1]);
      minY = Math.min(minY, p[2]);
      maxY = Math.max(maxY, p[2]);
    }
    st.tx = (minX + maxX) / 2;
    st.ty = (minY + maxY) / 2;
    st.tz = st.hf ? st.hf.base : 0;
    st.dist = Math.max(12000, Math.max(maxX - minX, maxY - minY) * 1.3);
  }
  let lastHeading = 0;
  function cam() {
    let c;
    let look;
    if (st.view === 'free') {
      c = { x: st.fx, y: st.fy, z: st.fz };
      look = { x: c.x + Math.cos(st.lpitch) * Math.cos(st.lyaw), y: c.y + Math.cos(st.lpitch) * Math.sin(st.lyaw), z: c.z + Math.sin(st.lpitch) };
    } else if (st.view === 'player' && st.me) {
      const p = posAt(st.me, st.t);
      if (p[3]) lastHeading = lastHeading + Math.atan2(Math.sin(p[3] - lastHeading), Math.cos(p[3] - lastHeading)) * 0.15;
      const h = lastHeading + st.pyaw;
      c = { x: p[0] - Math.cos(h) * 900, y: p[1] - Math.sin(h) * 900, z: p[2] + 420 };
      look = { x: p[0] + Math.cos(h) * 600, y: p[1] + Math.sin(h) * 600, z: p[2] + 120 };
    } else {
      const cp = Math.cos(st.pitch);
      c = { x: st.tx + st.dist * cp * Math.cos(st.yaw), y: st.ty + st.dist * cp * Math.sin(st.yaw), z: st.tz + st.dist * Math.sin(st.pitch) };
      look = { x: st.tx, y: st.ty, z: st.tz };
    }
    let f = { x: look.x - c.x, y: look.y - c.y, z: look.z - c.z };
    const fl = Math.hypot(f.x, f.y, f.z) || 1;
    f = { x: f.x / fl, y: f.y / fl, z: f.z / fl };
    let r = { x: f.y, y: -f.x, z: 0 };
    const rl = Math.hypot(r.x, r.y) || 1;
    r = { x: r.x / rl, y: r.y / rl, z: 0 };
    const u = { x: r.y * f.z - r.z * f.y, y: r.z * f.x - r.x * f.z, z: r.x * f.y - r.y * f.x };
    const F = cv.height / (2 * Math.tan((50 * Math.PI) / 360));
    return { c, f, r, u, F, cx: cv.width / 2, cy: cv.height / 2 };
  }
  function proj(K, x, y, z) {
    const dx = x - K.c.x;
    const dy = y - K.c.y;
    const dz = z - K.c.z;
    const zc = dx * K.f.x + dy * K.f.y + dz * K.f.z;
    if (zc < 20) return null;
    const xc = dx * K.r.x + dy * K.r.y + dz * K.r.z;
    const yc = dx * K.u.x + dy * K.u.y + dz * K.u.z;
    return [K.cx + (xc / zc) * K.F, K.cy - (yc / zc) * K.F, zc];
  }
  /** Mausposition → Punkt auf dem Gelände (Strahl läuft, bis er unter die Höhenkarte taucht) */
  function ground(K, sx, sy) {
    const a = (sx - K.cx) / K.F;
    const b = -(sy - K.cy) / K.F;
    let d = { x: K.f.x + K.r.x * a + K.u.x * b, y: K.f.y + K.r.y * a + K.u.y * b, z: K.f.z + K.r.z * a + K.u.z * b };
    const dl = Math.hypot(d.x, d.y, d.z);
    d = { x: d.x / dl, y: d.y / dl, z: d.z / dl };
    let tPrev = 0;
    let t = 50;
    for (let i = 0; i < 700 && t < 900000; i++) {
      const x = K.c.x + d.x * t;
      const y = K.c.y + d.y * t;
      const z = K.c.z + d.z * t;
      if (z <= heightAt(x, y)) {
        // genauer zwischen dem letzten und diesem Schritt
        let lo = tPrev;
        let hi = t;
        for (let k = 0; k < 12; k++) {
          const m = (lo + hi) / 2;
          if (K.c.z + d.z * m <= heightAt(K.c.x + d.x * m, K.c.y + d.y * m)) hi = m;
          else lo = m;
        }
        const gx = K.c.x + d.x * hi;
        const gy = K.c.y + d.y * hi;
        return [gx, gy, heightAt(gx, gy)];
      }
      tPrev = t;
      t += Math.max(60, t * 0.015);
    }
    return null;
  }

  function size() {
    if (!cv) return;
    const dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(cv.clientWidth * dpr);
    cv.height = Math.round(cv.clientHeight * dpr);
    draw();
  }

  /* ------------------------------------------------------------ Zeichnen */
  function line(K, pts, color, width, alpha = 1) {
    ctx.strokeStyle = color;
    ctx.globalAlpha = alpha;
    ctx.lineWidth = width;
    ctx.beginPath();
    let on = false;
    for (const p of pts) {
      const s = proj(K, p[0], p[1], p[2]);
      if (!s) {
        on = false;
        continue;
      }
      if (on) ctx.lineTo(s[0], s[1]);
      else ctx.moveTo(s[0], s[1]);
      on = true;
    }
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
  function draw() {
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, cv.width, cv.height);
    if (!data) return;
    const K = cam();
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    // Bodenraster um den Blickpunkt
    const step = Math.pow(10, Math.floor(Math.log10(st.dist / 3)));
    const span = step * 12;
    const gx = Math.round(st.tx / step) * step;
    const gy = Math.round(st.ty / step) * step;
    for (let i = -12; i <= 12; i++) {
      const gz = st.hf ? st.hf.base : 0;
      line(K, [[gx + i * step, gy - span, gz], [gx + i * step, gy + span, gz]], '#ffffff', dpr, i % 5 === 0 ? 0.12 : 0.05);
      line(K, [[gx - span, gy + i * step, gz], [gx + span, gy + i * step, gz]], '#ffffff', dpr, i % 5 === 0 ? 0.12 : 0.05);
    }
    // Gelände als Punktwolke (Höhe = Farbe)
    if (st.hf) {
      for (const cl of st.hf.cells) {
        const s2 = proj(K, cl[0], cl[1], cl[2]);
        if (!s2 || s2[0] < -20 || s2[1] < -20 || s2[0] > cv.width + 20 || s2[1] > cv.height + 20) continue;
        const r = Math.max(0.7, Math.min(16 * dpr, ((CELL * 0.5) / s2[2]) * K.F));
        ctx.globalAlpha = Math.max(0.35, Math.min(0.85, 2600 / Math.sqrt(s2[2])));
        ctx.fillStyle = terrainColor(cl[2]);
        ctx.fillRect(s2[0] - r, s2[1] - r * 0.55, r * 2, r * 1.1);
      }
      ctx.globalAlpha = 1;
    }
    // Sturmkreise
    for (const z of data.zones || []) {
      if (!z.r) continue;
      const ring = [];
      for (let a = 0; a <= 64; a++) ring.push([z.x + Math.cos((a / 64) * Math.PI * 2) * z.r, z.y + Math.sin((a / 64) * Math.PI * 2) * z.r, 0]);
      line(K, ring, '#bf5af2', 2 * dpr, 0.7);
    }
    const t = st.t;
    const order = [...data.tracks].sort((a, b) => (a.kind === 'me') - (b.kind === 'me') || (a.kind === 'team') - (b.kind === 'team'));
    for (const tr of order) {
      if (st.team && tr.kind === 'enemy') continue;
      const until = tr.pts.filter((p) => p[0] <= t).map((p) => [p[1], p[2], p[3]]);
      if (!until.length) continue;
      // aktuelle Position weich zwischen den Punkten, damit Spieler-Sicht und Abspielen nicht ruckeln
      if (!(tr.deathT > 0 && tr.deathT <= t)) {
        const now = posAt(tr, t);
        until.push([now[0], now[1], now[2]]);
      }
      const col = tr.kind === 'me' ? '#ffffff' : tr.kind === 'team' ? '#0a84ff' : '#ff6b6b';
      const w = (tr.kind === 'me' ? 3 : tr.kind === 'team' ? 2.2 : 1.2) * dpr;
      // Schatten auf dem Boden: zeigt, wo jemand in der Luft war
      if (tr.kind !== 'enemy') line(K, until.map((p) => [p[0], p[1], 0]), col, w * 0.6, 0.15);
      line(K, until, col, w, tr.kind === 'enemy' ? (tr.bot ? 0.25 : 0.45) : 0.95);
      const dead = tr.deathT > 0 && tr.deathT <= t;
      const last = until[until.length - 1];
      const s = proj(K, last[0], last[1], last[2]);
      if (!s) continue;
      if (dead) {
        ctx.strokeStyle = col;
        ctx.lineWidth = 2 * dpr;
        const r = 5 * dpr;
        ctx.beginPath();
        ctx.moveTo(s[0] - r, s[1] - r);
        ctx.lineTo(s[0] + r, s[1] + r);
        ctx.moveTo(s[0] + r, s[1] - r);
        ctx.lineTo(s[0] - r, s[1] + r);
        ctx.stroke();
      } else {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(s[0], s[1], (tr.kind === 'me' ? 6 : tr.kind === 'team' ? 4.5 : 3) * dpr, 0, Math.PI * 2);
        ctx.fill();
        if (tr.kind !== 'enemy') {
          ctx.font = `600 ${11 * dpr}px "Segoe UI", sans-serif`;
          ctx.fillStyle = 'rgba(255,255,255,.9)';
          ctx.fillText(tr.kind === 'me' ? 'Du' : tr.name || 'Team', s[0] + 9 * dpr, s[1] - 7 * dpr);
        }
      }
    }
    // Skizzen
    for (const sk of [...st.sketches, ...(st.drawing ? [st.drawing] : [])]) line(K, sk.pts.map((p) => [p[0], p[1], (p[2] ?? heightAt(p[0], p[1])) + 40]), sk.c, 4 * dpr, 0.95);
    const tl = root.querySelector('#r3d-time');
    if (tl) tl.textContent = fmt(t - st.t0);
    const rg = root.querySelector('#r3d-range');
    if (rg && document.activeElement !== rg) rg.value = String(Math.round(((t - st.t0) / (st.t1 - st.t0)) * 1000));
  }

  /* ------------------------------------------------------------ Abspielen */
  function playIcon() {
    const b = root?.querySelector('.r3d-play');
    if (b) b.innerHTML = st.playing ? '<svg viewBox="0 0 24 24"><rect x="6.5" y="5" width="4" height="14" rx="1.4"/><rect x="13.5" y="5" width="4" height="14" rx="1.4"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l11-6.5z"/></svg>';
  }
  function togglePlay() {
    if (!data) return;
    if (!st.playing && st.t >= st.t1) st.t = st.t0;
    st.playing = !st.playing;
    playIcon();
    st.last = performance.now();
    if (st.playing) loop();
  }
  function loop() {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame((now) => {
      if (!st.playing || !root) return;
      st.t = Math.min(st.t1, st.t + ((now - st.last) / 1000) * st.speed);
      st.last = now;
      draw();
      if (st.t >= st.t1) {
        st.playing = false;
        playIcon();
        return;
      }
      loop();
    });
  }

  function onClick(e) {
    const b = e.target.closest('button, [data-col]');
    if (!b) return;
    if (b.dataset.col) {
      st.color = b.dataset.col;
      root.querySelectorAll('[data-col]').forEach((x) => x.classList.toggle('on', x === b));
      setMode('draw');
      return;
    }
    if (b.dataset.view) return setView(b.dataset.view);
    if (b.dataset.mode) return setMode(st.mode === 'draw' ? 'orbit' : 'draw');
    const a = b.dataset.act;
    if (a === 'close') close();
    else if (a === 'play') togglePlay();
    else if (a === 'speed') {
      st.speed = st.speed === 8 ? 24 : st.speed === 24 ? 2 : 8;
      b.textContent = `${st.speed}×`;
    } else if (a === 'team') {
      st.team = !st.team;
      b.classList.toggle('on', st.team);
      draw();
    } else if (a === 'me' && st.me) {
      const p = st.me.pts.filter((q) => q[0] <= st.t).pop() || st.me.pts[0];
      st.tx = p[1];
      st.ty = p[2];
      st.tz = p[3];
      st.dist = 9000;
      if (st.view !== 'drone') setView('drone');
      draw();
    } else if (a === 'undo') {
      st.sketches.pop();
      saveSketch();
      draw();
    } else if (a === 'clear') {
      st.sketches = [];
      saveSketch();
      draw();
    }
  }
  function setView(v) {
    if (v === 'player' && !st.me) return;
    if (v === 'free' && st.view !== 'free') {
      // frei fliegen startet dort, wo die Kamera gerade ist
      const K = cam();
      st.fx = K.c.x;
      st.fy = K.c.y;
      st.fz = K.c.z;
      st.lyaw = Math.atan2(K.f.y, K.f.x);
      st.lpitch = Math.asin(Math.max(-1, Math.min(1, K.f.z)));
    }
    st.view = v;
    st.pyaw = 0;
    root.querySelectorAll('[data-view]').forEach((x) => x.classList.toggle('on', x.dataset.view === v));
    flyLoop();
    draw();
  }
  /** Frei fliegen: solange eine Taste gedrückt ist, bewegt sich die Kamera */
  let flyRaf = 0;
  let flyLast = 0;
  function flyLoop() {
    if (flyRaf || st.view !== 'free' || !st.keys.size) return;
    flyLast = performance.now();
    const step = (now) => {
      flyRaf = 0;
      if (!root || st.view !== 'free' || !st.keys.size) return;
      const dt = Math.min(0.05, (now - flyLast) / 1000);
      flyLast = now;
      const speed = (st.keys.has('Shift') ? 9000 : 2500) * dt;
      const fx = Math.cos(st.lyaw);
      const fy = Math.sin(st.lyaw);
      if (st.keys.has('w')) { st.fx += fx * speed; st.fy += fy * speed; st.fz += Math.sin(st.lpitch) * speed; }
      if (st.keys.has('s')) { st.fx -= fx * speed; st.fy -= fy * speed; st.fz -= Math.sin(st.lpitch) * speed; }
      if (st.keys.has('a')) { st.fx -= fy * speed; st.fy += fx * speed; }
      if (st.keys.has('d')) { st.fx += fy * speed; st.fy -= fx * speed; }
      if (st.keys.has(' ')) st.fz += speed;
      if (st.keys.has('Control')) st.fz -= speed;
      st.fz = Math.max(heightAt(st.fx, st.fy) + 60, st.fz);
      draw();
      flyRaf = requestAnimationFrame(step);
    };
    flyRaf = requestAnimationFrame(step);
  }
  function setMode(m) {
    st.mode = m;
    root.querySelectorAll('[data-mode]').forEach((x) => x.classList.toggle('on', x.dataset.mode === m));
    cv.classList.toggle('draw', m === 'draw');
  }
  function saveSketch() {
    try {
      localStorage.setItem(`r3d:${file}`, JSON.stringify(st.sketches.slice(-200)));
    } catch {
      /* voll */
    }
  }

  function bindMouse() {
    let drag = null;
    const pos = (e) => {
      const r = cv.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      return [(e.clientX - r.left) * dpr, (e.clientY - r.top) * dpr];
    };
    cv.addEventListener('contextmenu', (e) => e.preventDefault());
    cv.addEventListener('pointerdown', (e) => {
      if (!data) return;
      cv.setPointerCapture(e.pointerId);
      if (st.mode === 'draw' && e.button === 0) {
        const g = ground(cam(), ...pos(e));
        if (g) st.drawing = { c: st.color, pts: [g] };
        return;
      }
      drag = { x: e.clientX, y: e.clientY, pan: e.button === 2 || e.shiftKey };
    });
    cv.addEventListener('pointermove', (e) => {
      if (st.drawing) {
        const g = ground(cam(), ...pos(e));
        const l = st.drawing.pts[st.drawing.pts.length - 1];
        const minStep = st.view === 'drone' ? st.dist / 400 : 40;
        if (g && Math.hypot(g[0] - l[0], g[1] - l[1]) > minStep) {
          st.drawing.pts.push(g);
          draw();
        }
        return;
      }
      if (!drag) return;
      const dx = e.clientX - drag.x;
      const dy = e.clientY - drag.y;
      drag.x = e.clientX;
      drag.y = e.clientY;
      if (st.view === 'free') {
        st.lyaw -= dx * 0.004;
        st.lpitch = Math.max(-1.5, Math.min(1.5, st.lpitch - dy * 0.004));
      } else if (st.view === 'player') {
        st.pyaw -= dx * 0.006;
      } else if (drag.pan) {
        const k = st.dist / 900;
        const sy = Math.sin(st.yaw);
        const cy = Math.cos(st.yaw);
        st.tx += (dx * sy + dy * cy) * k;
        st.ty += (-dx * cy + dy * sy) * k;
      } else {
        st.yaw -= dx * 0.006;
        st.pitch = Math.max(0.08, Math.min(1.55, st.pitch + dy * 0.005));
      }
      draw();
    });
    const up = () => {
      if (st.drawing) {
        if (st.drawing.pts.length > 1) st.sketches.push(st.drawing);
        st.drawing = null;
        saveSketch();
        draw();
      }
      drag = null;
    };
    cv.addEventListener('pointerup', up);
    cv.addEventListener('pointercancel', up);
    cv.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (st.view === 'free') {
        const k = -e.deltaY * 4;
        st.fx += Math.cos(st.lpitch) * Math.cos(st.lyaw) * k;
        st.fy += Math.cos(st.lpitch) * Math.sin(st.lyaw) * k;
        st.fz = Math.max(heightAt(st.fx, st.fy) + 60, st.fz + Math.sin(st.lpitch) * k);
      } else if (st.view === 'drone') st.dist = Math.max(1500, Math.min(600000, st.dist * Math.exp(e.deltaY * 0.0012)));
      draw();
    }, { passive: false });
  }

  window.Replay3D = { open };
})();
