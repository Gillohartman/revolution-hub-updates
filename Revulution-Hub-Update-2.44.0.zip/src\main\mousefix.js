'use strict';

/* 2.44 Geräte & Maus-Fix
   Listet angeschlossene Mäuse, Tastaturen und Empfänger. Für Logitech-Mäuse (z. B. G502 X / Lightspeed)
   gibt es einen Fix gegen Stocken: USB-Energiesparen für die Logitech-Geräte aus (einmal mit
   Windows-Bestätigung). Der globale Maus-Hook des Gaming Hubs ist seit 2.44 ohnehin aus. */
const { execFile } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const run = (cmd, timeout = 20000) =>
  new Promise((resolve) =>
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', cmd], { windowsHide: true, timeout, maxBuffer: 4 * 1024 * 1024 }, (e, so) => resolve(e ? '' : String(so || '').trim())),
  );

async function list() {
  const out = await run(
    "[Console]::OutputEncoding = [Text.Encoding]::UTF8; Get-PnpDevice -PresentOnly -Class Mouse,Keyboard,HIDClass,USB -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'OK' } | Select-Object FriendlyName,InstanceId,Class | ConvertTo-Json -Compress",
  );
  let rows = [];
  try {
    rows = JSON.parse(out || '[]');
  } catch {
    rows = [];
  }
  if (!Array.isArray(rows)) rows = [rows];
  const seen = new Set();
  const devices = [];
  for (const r of rows) {
    const name = String(r.FriendlyName || '').trim();
    const id = String(r.InstanceId || '');
    if (!name || /root hub|host controller|hostcontroller|usb-hub|composite|generic usb hub|usb-root|synthetic|hid-compliant (vendor|consumer|system|device)|input configuration|pen|virtual/i.test(name) || (/verbundger|usb-eingabeger|hid-konformes ger/i.test(name) && !/VID_046D/i.test(id))) continue;
    const vid = (id.match(/VID_([0-9A-F]{4})/i) || [])[1]?.toUpperCase() || '';
    const pid = (id.match(/PID_([0-9A-F]{4})/i) || [])[1]?.toUpperCase() || '';
    const key = `${name}|${vid}|${pid}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const logitech = vid === '046D' || /logitech|lightspeed|g502/i.test(name);
    devices.push({
      name,
      kind: r.Class === 'Mouse' ? 'Maus' : r.Class === 'Keyboard' ? 'Tastatur' : r.Class === 'USB' ? 'USB' : 'Eingabegerät',
      vid,
      pid,
      logitech,
      g502: logitech && (/g502/i.test(name) || ['C098', 'C099', 'C547', 'C08D', 'C332', 'C539'].includes(pid)),
    });
  }
  // Ein Gerät meldet sich unter vielen Namen (HID-Maus, HID-Tastatur, Empfänger …) → eins pro VID:PID
  const generic = (n) => /^(hid|usb)[- ]|hid-konform|eingabeger|verbundger|bluetooth-hid/i.test(n);
  const rank = { Maus: 0, Tastatur: 1, USB: 2, Eingabegerät: 3 };
  const groups = new Map();
  for (const d of devices) {
    const k = d.vid && d.pid ? `${d.vid}:${d.pid}` : `n:${d.name}`;
    const g = groups.get(k);
    if (!g) {
      groups.set(k, { ...d, kinds: new Set([d.kind]) });
      continue;
    }
    g.kinds.add(d.kind);
    if (generic(g.name) && !generic(d.name)) g.name = d.name;
    if (rank[d.kind] < rank[g.kind]) g.kind = d.kind;
  }
  const result = [...groups.values()].map((g) => {
    let name = g.name;
    if (g.g502) name = `Logitech G502 X${/lightspeed|receiver/i.test(name) || g.pid === 'C547' ? ' LIGHTSPEED' : ''}`;
    else if (g.logitech && generic(name)) name = `Logitech ${g.kind}`;
    else if (generic(name)) name = g.kind === 'Maus' ? 'Maus' : g.kind === 'Tastatur' ? 'Tastatur' : name;
    return { name, kind: g.kinds.has('Maus') ? 'Maus' : g.kinds.has('Tastatur') ? 'Tastatur' : g.kind, vid: g.vid, pid: g.pid, logitech: g.logitech, g502: g.g502 };
  });
  result.sort((a, b) => b.g502 - a.g502 || b.logitech - a.logitech || a.kind.localeCompare(b.kind) || a.name.localeCompare(b.name));
  return result.slice(0, 30);
}

/** USB-Energiesparen für alle Logitech-Geräte aus (Windows fragt einmal nach Erlaubnis). */
async function fix() {
  const script = path.join(os.tmpdir(), `rev-mousefix-${Date.now()}.ps1`);
  fs.writeFileSync(
    script,
    `$ErrorActionPreference = 'SilentlyContinue'
$n = 0
Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -match 'VID_046D' } | ForEach-Object {
  $k = "HKLM:\\SYSTEM\\CurrentControlSet\\Enum\\$($_.InstanceId)\\Device Parameters"
  if (Test-Path $k) {
    New-ItemProperty -Path $k -Name EnhancedPowerManagementEnabled -Value 0 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $k -Name SelectiveSuspendEnabled -Value 0 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $k -Name AllowIdleIrpInD3 -Value 0 -PropertyType DWord -Force | Out-Null
    $n++
  }
}
Set-Content -Path "${script}.done" -Value $n
`,
    'utf8',
  );
  const quoted = script.replace(/'/g, "''");
  await run(`Start-Process -FilePath powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','${quoted}'`, 90000);
  let changed = -1;
  try {
    changed = Number(fs.readFileSync(`${script}.done`, 'utf8').trim()) || 0;
  } catch {
    changed = -1;
  }
  for (const f of [script, `${script}.done`]) fs.rm(f, { force: true }, () => {});
  if (changed < 0) return { ok: false, error: 'Windows-Bestätigung wurde abgelehnt.' };
  return { ok: true, changed };
}

module.exports = { list, fix };
