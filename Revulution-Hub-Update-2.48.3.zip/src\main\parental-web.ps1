# Revolution Hub – Kindersicherung: Wort-Sperre für Browser (2.47.2)
# Schaut alle 700 ms auf das Fenster im Vordergrund. Ist es ein Browser, werden Fenstertitel und
# Adresszeile (über die Windows-Bedienungshilfen) gelesen. Enthält eines davon ein gesperrtes Wort,
# wird das Browserfenster sofort geschlossen. Treffer werden als Zeile ausgegeben (für die Meldung im Hub).
param([string]$Words, [string]$Config)
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
Add-Type @"
using System; using System.Text; using System.Runtime.InteropServices;
public static class RevPW {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
}
"@
$list = $Words.ToLower().Split('|') | Where-Object { $_ }
$browsers = @('chrome','msedge','firefox','brave','opera','opera_gx','vivaldi','iexplore','waterfox','librewolf','arc','thorium','yandex','chromium')
$lastHwnd = [IntPtr]::Zero; $edit = $null
function Test-Bad([string]$s) {
  if (-not $s) { return $null }
  $t = $s.ToLower()
  foreach ($w in $list) { if ($t.Contains($w)) { return $w } }
  return $null
}
while ($true) {
  Start-Sleep -Milliseconds 700
  if ($Config -and -not (Test-Path -LiteralPath $Config)) { break }   # Hub hat die Sperre beendet
  $h = [RevPW]::GetForegroundWindow()
  if ($h -eq [IntPtr]::Zero) { continue }
  $procId = 0; [void][RevPW]::GetWindowThreadProcessId($h, [ref]$procId)
  $p = Get-Process -Id $procId
  if (-not $p -or ($browsers -notcontains $p.ProcessName.ToLower())) { continue }
  $sb = New-Object System.Text.StringBuilder 512; [void][RevPW]::GetWindowText($h, $sb, 512); $title = $sb.ToString()
  $url = ''
  try {
    if ($h -ne $lastHwnd -or -not $edit) {
      $lastHwnd = $h
      $root = [System.Windows.Automation.AutomationElement]::FromHandle($h)
      $cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::Edit)
      $edit = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $cond)
    }
    if ($edit) {
      $vp = $edit.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
      if ($vp) { $url = $vp.Current.Value }
    }
  } catch { $edit = $null }
  $hit = Test-Bad $url
  if (-not $hit) { $hit = Test-Bad $title }
  if ($hit) {
    [void][RevPW]::PostMessage($h, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero)   # WM_CLOSE: Browserfenster zu
    Write-Output ("HIT|" + $p.ProcessName + "|" + $hit)
    $edit = $null; $lastHwnd = [IntPtr]::Zero
    Start-Sleep -Milliseconds 800
  }
}
