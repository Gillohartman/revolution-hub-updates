'use strict';

/* 2.43 Player: links groß das Albumbild, rechts der Songtext ohne Hintergrund – die gesungene Zeile leuchtet auf
   und der Text gleitet weich mit. Songtexte (mit Zeitstempeln) kommen von lrclib.net. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-player';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const pl = { m: null, at: 0, key: '', lines: null, plain: '', loading: false, idx: -1, raf: 0 };
  // Runde 11b: Bildtyp am Inhalt erkennen (die Mediensitzung liefert meist PNG, iTunes JPG)
  const artUrl = (b64) => `data:${b64.startsWith('iVBOR') ? 'image/png' : b64.startsWith('UklGR') ? 'image/webp' : 'image/jpeg'};base64,${b64}`;
  // Runde 11b: Ansicht „Cover“ oder „Plattenspieler“ (bleibt gespeichert)
  let view = 'cover';
  try { view = localStorage.getItem('rv-player-view') === 'tt' ? 'tt' : 'cover'; } catch { /* egal */ }

  const keyOf = (m) => `${m?.title || ''}|${m?.artist || ''}`;
  const clean = (s) => String(s || '').replace(/\(.*?\)|\[.*?\]|official|video|lyrics|audio|- topic/gi, ' ').replace(/\s+/g, ' ').trim();
  function parseLrc(text) {
    const out = [];
    for (const row of String(text || '').split(/\r?\n/)) {
      const tags = [...row.matchAll(/\[(\d+):(\d+(?:\.\d+)?)\]/g)];
      const words = row.replace(/\[[^\]]*\]/g, '').trim();
      for (const t of tags) out.push({ t: Number(t[1]) * 60 + Number(t[2]), text: words });
    }
    return out.sort((a, b) => a.t - b.t);
  }
  async function loadLyrics(m) {
    const k = keyOf(m);
    if (!m?.title || pl.key === k) return;
    pl.key = k;
    pl.lines = null;
    pl.plain = '';
    pl.idx = -1;
    pl.loading = true;
    if (active()) ctx().render();
    try {
      const q = new URLSearchParams({ track_name: clean(m.title), artist_name: clean(m.artist) });
      if (m.duration > 0) q.set('duration', String(Math.round(m.duration)));
      let r = await window.hub.tool.fetch(`https://lrclib.net/api/get?${q}`).catch(() => null);
      if (!r?.syncedLyrics && !r?.plainLyrics) {
        const list = await window.hub.tool.fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(`${clean(m.artist)} ${clean(m.title)}`)}`).catch(() => null);
        r = Array.isArray(list) ? list.find((x) => x.syncedLyrics) || list[0] : null;
      }
      if (pl.key !== k) return;
      pl.lines = r?.syncedLyrics ? parseLrc(r.syncedLyrics) : null;
      pl.plain = !pl.lines && r?.plainLyrics ? r.plainLyrics : '';
    } catch {
      pl.lines = null;
    }
    pl.loading = false;
    if (active()) ctx().render();
  }
  // Position zwischen den Updates weiterzählen
  const pos = () => {
    const m = pl.m;
    if (!m) return 0;
    return (Number(m.position) || 0) + (m.playing ? (Date.now() - pl.at) / 1000 : 0);
  };
  window.hub.onMedia?.((m) => {
    if (!m) return;
    const same = pl.m && keyOf(pl.m) === keyOf(m);
    pl.m = { ...m, art: m.art || (same ? pl.m.art : '') };
    pl.at = Date.now();
    if (!same) {
      loadLyrics(pl.m);
      if (active()) ctx().render();
    } else if (active()) {
      const btn = document.querySelector('.pl-ctl .main');
      if (btn) btn.innerHTML = window.icon(pl.m.playing ? 'pause' : 'play', 26);
      // Runde 11b: Cover jedes Mal nachziehen, wenn ein (besseres) Bild kommt – nicht nur, wenn noch keins da ist
      const art = document.querySelector('.pl-art');
      if (art && pl.m.art && art.dataset.art !== String(pl.m.art.length)) {
        art.dataset.art = String(pl.m.art.length);
        art.style.setProperty('--pl-art', `url('${artUrl(pl.m.art)}')`);
        document.querySelector('.pl-fs-host')?.style.setProperty('--pl-art', `url('${artUrl(pl.m.art)}')`);
        art.innerHTML = ''; // 2.44: kein Notenzeichen mehr hinter dem Cover
      }
      const label = document.querySelector('.tt-label');
      if (label && pl.m.art && label.dataset.art !== String(pl.m.art.length)) {
        label.dataset.art = String(pl.m.art.length);
        label.setAttribute('href', artUrl(pl.m.art));
      }
    }
    tick();
    ttStart();
  });

  function tick() {
    if (pl.raf || !active()) return;
    pl.raf = requestAnimationFrame(() => {
      pl.raf = 0;
      if (!active()) return;
      const p = pos();
      const bar = document.querySelector('.pl-prog i');
      if (bar && pl.m?.duration > 0) bar.style.width = `${Math.min(100, (p / pl.m.duration) * 100)}%`;
      if (pl.lines?.length) {
        let i = -1;
        for (let k = 0; k < pl.lines.length; k++) if (pl.lines[k].t <= p + 0.25) i = k;
        karaoke(i, p);
        if (i !== pl.idx) {
          pl.idx = i;
          const box = document.querySelector('.pl-lyrics');
          const rows = box?.querySelectorAll('.pl-line');
          rows?.forEach((el, n) => {
            el.classList.toggle('on', n === i);
            el.classList.toggle('past', n < i);
          });
          const cur = rows?.[Math.max(0, i)];
          if (box && cur) {
            const target = cur.offsetTop - box.clientHeight * 0.36;
            box.querySelector('.pl-roll').style.transform = `translateY(${-Math.max(0, target)}px)`;
          }
        }
      }
      if (pl.m?.playing) tick();
      else setTimeout(tick, 500);
    });
  }

  /* 2.44 Karaoke wie in der Island: die Zeile bleibt stehen, bis die nächste kommt, und füllt sich
     Wort für Wort weiß – das gerade gesungene Wort wischt sich weich von links nach rechts. */
  const words = (t) => esc(t || '♪').split(/(\s+)/).map((w) => (/^\s+$/.test(w) ? w : `<span class="w">${w}</span>`)).join('');
  function karaoke(i, p) {
    const el = i >= 0 ? document.querySelectorAll('.pl-line')[i] : null;
    if (el) paint(el, i, p);
  }
  function paint(el, i, p) {
    const line = pl.lines?.[i];
    if (!line) return;
    const next = pl.lines[i + 1]?.t ?? line.t + 6;
    const ws = el.querySelectorAll('.w');
    if (!ws.length) return;
    const chars = [...ws].reduce((n, w) => n + w.textContent.length, 0) || 1;
    // gesungen wird meist schneller, als die Pause bis zur nächsten Zeile dauert
    const dur = Math.max(0.6, Math.min(next - line.t - 0.15, 0.35 + chars * 0.075));
    const done = Math.max(0, Math.min(1, (p - line.t + 0.1) / dur)) * chars;
    let acc = 0;
    for (const w of ws) {
      const len = w.textContent.length;
      const f = Math.max(0, Math.min(1, (done - acc) / len));
      acc += len;
      const v = f >= 1 ? '100%' : f <= 0 ? '0%' : `${(f * 100).toFixed(1)}%`;
      if (w.style.getPropertyValue('--p') !== v) w.style.setProperty('--p', v);
    }
  }

  // 2.44: die Player-Karte auf der Startseite nutzt denselben Songtext und dieselbe Karaoke-Füllung
  window.PlayerLyrics = {
    key: () => pl.key,
    lines: () => pl.lines,
    pos,
    words,
    paint,
    index(p) {
      let i = -1;
      if (pl.lines) for (let k = 0; k < pl.lines.length; k++) if (pl.lines[k].t <= p + 0.25) i = k;
      return i;
    },
  };

  /* ---------------- Runde 11b: Plattenspieler ----------------
     Grosse Platte mit dem Albumcover als Etikett; dreht sich beim Abspielen (33⅓ U/min, mit Anlauf
     und Auslauf), der Tonarm schwenkt beim Abspielen auf die Platte und wandert mit dem Song nach
     innen, bei Pause hebt er ab und geht zurück. Platte ziehen = scratchen; beim Loslassen springt
     der Song um die gedrehte Strecke (1 Umdrehung = 1,8 s). Klick auf den Tonarm = Play/Pause. */
  const CX = 250, CY = 250, RPS = 100 / 3 / 60; // Umdrehungen pro Sekunde
  const ARM = { rest: -12, start: 3, end: 21 }; // Tonarm-Winkel (Grad) um den Drehpunkt 490/70
  const tt = { ang: 0, speed: 0, last: 0, drag: null, raf: 0, seekTo: null };
  function turntable(m) {
    const grooves = Array.from({ length: 30 }, (_, i) => `<circle cx="${CX}" cy="${CY}" r="${98 + i * 3.9}" />`).join('');
    const label = m.art ? `<image class="tt-label" href="${artUrl(m.art)}" data-art="${m.art.length}" x="${CX - 88}" y="${CY - 88}" width="176" height="176" preserveAspectRatio="xMidYMid slice" clip-path="url(#tt-clip)"/>` : `<circle cx="${CX}" cy="${CY}" r="88" fill="url(#tt-lab)"/><text x="${CX}" y="${CY + 40}" text-anchor="middle" class="tt-labtxt">${esc((m.title || '').slice(0, 22))}</text>`;
    return `<div class="tt${m.playing ? ' playing' : ''}">
      <svg class="tt-svg" viewBox="0 0 560 500" aria-label="Plattenspieler">
        <defs>
          <linearGradient id="tt-plinth" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2d2d32"/><stop offset="1" stop-color="#151518"/></linearGradient>
          <radialGradient id="tt-vinyl"><stop offset=".38" stop-color="#1b1b1e"/><stop offset=".42" stop-color="#0b0b0d"/><stop offset=".97" stop-color="#111114"/><stop offset="1" stop-color="#202024"/></radialGradient>
          <radialGradient id="tt-lab"><stop offset="0" stop-color="#e8505b"/><stop offset="1" stop-color="#8e1f3a"/></radialGradient>
          <linearGradient id="tt-metal" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f2f2f4"/><stop offset=".5" stop-color="#9a9aa2"/><stop offset="1" stop-color="#d8d8de"/></linearGradient>
          <clipPath id="tt-clip"><circle cx="${CX}" cy="${CY}" r="88"/></clipPath>
        </defs>
        <rect class="tt-plinth" x="2" y="2" width="556" height="496" rx="26" fill="url(#tt-plinth)"/>
        <circle cx="${CX}" cy="${CY}" r="229" fill="#0a0a0b" stroke="url(#tt-metal)" stroke-width="3" opacity=".95"/>
        <g class="tt-record" data-tt="record">
          <circle cx="${CX}" cy="${CY}" r="218" fill="url(#tt-vinyl)"/>
          <g class="tt-grooves" fill="none">${grooves}</g>
          ${label}
          <circle cx="${CX + 62}" cy="${CY - 62}" r="3" fill="rgba(255,255,255,.55)"/>
          <circle cx="${CX}" cy="${CY}" r="7" fill="url(#tt-metal)"/>
        </g>
        <path class="tt-shine" d="M${CX} ${CY} L${CX + 210} ${CY - 60} A218 218 0 0 1 ${CX + 175} ${CY - 130} Z M${CX} ${CY} L${CX - 210} ${CY + 60} A218 218 0 0 1 ${CX - 175} ${CY + 130} Z"/>
        <g class="tt-arm${m.playing ? ' on' : ''}" data-pl="playpause" style="--arm:${m.playing ? ARM.start : ARM.rest}deg">
          <title>Tonarm – Klick: Play/Pause</title>
          <circle cx="490" cy="70" r="40" fill="#1d1d21" stroke="url(#tt-metal)" stroke-width="2"/>
          <rect x="478" y="10" width="24" height="26" rx="5" fill="url(#tt-metal)"/>
          <path d="M490 70 L486 320 L452 368" fill="none" stroke="url(#tt-metal)" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M440 352 L468 372 L456 390 L428 372 Z" fill="#2a2a2f" stroke="#bdbdc4" stroke-width="2"/>
          <circle cx="490" cy="70" r="13" fill="url(#tt-metal)"/>
        </g>
        <g class="tt-deco"><circle cx="512" cy="452" r="15" fill="#1d1d21" stroke="#555" stroke-width="2"/><text x="512" y="457" text-anchor="middle">33</text><circle class="tt-led" cx="476" cy="452" r="5"/></g>
      </svg>
      <div class="tt-hint">Platte ziehen zum Spulen · Tonarm klicken = Play/Pause</div>
    </div>`;
  }
  function ttStart() {
    if (!tt.raf && document.querySelector('.tt-record')) tt.raf = requestAnimationFrame(ttLoop);
  }
  function ttLoop(now) {
    tt.raf = 0;
    const rec = document.querySelector('.tt-record');
    if (!rec || !active()) { tt.last = 0; return; }
    const dt = tt.last ? Math.min(0.1, (now - tt.last) / 1000) : 0;
    tt.last = now;
    const playing = Boolean(pl.m?.playing);
    const want = playing && !tt.drag ? 1 : 0;
    tt.speed += (want - tt.speed) * Math.min(1, dt * (want ? 2.4 : 1.5)); // Anlauf ~1 s, Auslauf ~1,5 s
    if (!tt.drag) tt.ang = (tt.ang + tt.speed * RPS * 360 * dt) % 360;
    rec.setAttribute('transform', `rotate(${tt.ang.toFixed(2)} ${CX} ${CY})`);
    const arm = document.querySelector('.tt-arm');
    if (arm) {
      const prog = pl.m?.duration > 0 ? Math.max(0, Math.min(1, pos() / pl.m.duration)) : 0;
      const a = playing || tt.drag ? ARM.start + prog * (ARM.end - ARM.start) : ARM.rest;
      const v = `${a.toFixed(2)}deg`;
      if (arm.style.getPropertyValue('--arm') !== v) arm.style.setProperty('--arm', v);
      arm.classList.toggle('on', playing || Boolean(tt.drag));
    }
    document.querySelector('.tt')?.classList.toggle('playing', playing);
    if (playing || tt.drag || tt.speed > 0.002) tt.raf = requestAnimationFrame(ttLoop);
    else tt.last = 0;
  }
  const ptrAngle = (e, svgEl) => {
    const r = svgEl.getBoundingClientRect(), k = r.width / 560;
    return (Math.atan2(e.clientY - (r.top + CY * k), e.clientX - (r.left + CX * k)) * 180) / Math.PI;
  };
  document.addEventListener('pointerdown', (e) => {
    const rec = e.target.closest?.('[data-tt="record"]');
    if (!rec || !active()) return;
    const svgEl = rec.ownerSVGElement;
    e.preventDefault();
    try { svgEl.setPointerCapture(e.pointerId); } catch { /* egal */ }
    tt.drag = { last: ptrAngle(e, svgEl), total: 0, svgEl, id: e.pointerId };
    svgEl.closest('.tt')?.classList.add('scratch');
    ttStart();
  });
  document.addEventListener('pointermove', (e) => {
    const d = tt.drag;
    if (!d || e.pointerId !== d.id) return;
    const a = ptrAngle(e, d.svgEl);
    let delta = a - d.last;
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;
    d.last = a;
    d.total += delta;
    tt.ang = (tt.ang + delta + 360) % 360;
  });
  const endScratch = (e) => {
    const d = tt.drag;
    if (!d || e.pointerId !== d.id) return;
    tt.drag = null;
    d.svgEl.closest('.tt')?.classList.remove('scratch');
    const secs = d.total / 360 / RPS;
    if (pl.m && Math.abs(secs) >= 0.5) {
      const to = Math.max(0, Math.min((pl.m.duration || Infinity) - 1, pos() + secs));
      pl.m.position = to;
      pl.at = Date.now();
      window.hub.mediaSeek?.(to)?.catch?.(() => {});
      tick();
    }
    ttStart();
  };
  document.addEventListener('pointerup', endScratch);
  document.addEventListener('pointercancel', endScratch);

  function html() {
    const m = pl.m;
    setTimeout(tick, 30);
    if (!m?.title) {
      return `<div class="pl-empty"><div class="pl-art none">${window.icon('music', 64)}</div><h2>Gerade läuft nichts</h2><p class="muted">Spiel Musik in Spotify, im Browser oder einer anderen App – hier erscheint dann das Cover mit dem Songtext.</p></div>`;
    }
    if (pl.key !== keyOf(m)) loadLyrics(m);
    // 2.46: Cover als CSS-Variable – das Pro-Design überschrieb background-image mit none !important
    const art = m.art ? `style="--pl-art:url('${artUrl(m.art)}')" data-art="${m.art.length}"` : '';
    setTimeout(() => { const h = document.querySelector('.pl-fs-host'); if (h && m.art) h.style.setProperty('--pl-art', `url('${artUrl(m.art)}')`); }, 0);
    const lyrics = pl.loading
      ? '<div class="pl-note">Songtext wird gesucht …</div>'
      : pl.lines?.length
        ? `<div class="pl-roll">${pl.lines.map((l, i) => `<p class="pl-line ${i === pl.idx ? 'on' : i < pl.idx ? 'past' : ''}" style="--d:${Math.min(i, 12) * 30}ms">${words(l.text)}</p>`).join('')}</div>`
        : pl.plain
          ? `<div class="pl-roll plain">${pl.plain.split(/\r?\n/).map((l) => `<p class="pl-line past">${esc(l) || '&nbsp;'}</p>`).join('')}</div>`
          : '<div class="pl-note">Für diesen Song gibt es keinen Songtext.</div>';
    setTimeout(ttStart, 30);
    const switcher = `<div class="pl-view" role="tablist"><button data-plview="cover" class="${view === 'cover' ? 'on' : ''}" title="Albumcover">Cover</button><button data-plview="tt" class="${view === 'tt' ? 'on' : ''}" title="Plattenspieler">Plattenspieler</button></div>`;
    return `<div class="pl${view === 'tt' ? ' pl-tt' : ''}">
      <div class="pl-left">
        <div class="pl-tools">${switcher}
          <button class="pl-tbtn ${crackle.on ? 'on' : ''}" data-plx="crackle" title="Plattenknistern an/aus"><span class="crk"><i></i><i></i><i></i></span>Knistern</button>
          <button class="pl-tbtn" data-plx="full" title="Vollbild (Esc beendet)"><svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>Vollbild</button>
        </div>
        <button class="pl-tbtn pl-exit" data-plx="exit" title="Vollbild beenden (Esc)"><svg viewBox="0 0 24 24"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>Beenden</button>
        ${view === 'tt' ? turntable(m) : `<div class="pl-art" ${art}>${m.art ? '' : window.icon('music', 64)}</div>`}
        <div class="pl-meta"><b>${esc(m.title)}</b><span>${esc(m.artist || '')}</span></div>
        <div class="pl-prog"><i></i></div>
        <div class="pl-ctl"><button data-pl="prev">${window.icon('arrow', 20).replace('class="icon"', 'class="icon flip"')}</button><button class="main" data-pl="playpause">${window.icon(m.playing ? 'pause' : 'play', 26)}</button><button data-pl="next">${window.icon('arrow', 20)}</button></div>
      </div>
      <div class="pl-lyrics ${pl.plain ? 'scroll' : ''}">${lyrics}</div>
    </div>`;
  }

  /* ---------------- 2.46 Plattenknistern: Rauschen + zufällige Knackser, erzeugt mit Web Audio (keine Datei) */
  const crackle = { on: false, ctx: null, src: null, gain: null };
  try { crackle.on = localStorage.getItem('rv-player-crackle') === '1'; } catch { /* egal */ }
  function crackleBuffer(c) {
    const secs = 6, sr = c.sampleRate, n = secs * sr;
    const b = c.createBuffer(2, n, sr);
    for (let ch = 0; ch < 2; ch++) {
      const d = b.getChannelData(ch);
      let brown = 0;
      for (let i = 0; i < n; i++) { brown = (brown + (Math.random() * 2 - 1) * 0.02) * 0.985; d[i] = brown * 0.35 + (Math.random() * 2 - 1) * 0.0035; }
      // feine Knackser (viele) und ein paar größere Pops; leicht unterschiedlich je Kanal
      const clicks = secs * (26 + Math.random() * 8);
      for (let k = 0; k < clicks; k++) {
        const at = Math.floor(Math.random() * (n - 400));
        const big = Math.random() < 0.06;
        const amp = (big ? 0.35 + Math.random() * 0.3 : 0.04 + Math.random() * 0.12) * (Math.random() < 0.5 ? -1 : 1);
        const len = big ? 120 + Math.random() * 220 : 8 + Math.random() * 40;
        for (let j = 0; j < len; j++) d[at + j] += amp * Math.exp(-j / (len / 4)) * (j % 2 ? -0.6 : 1);
      }
      // Rillen-Rumpeln: ein ganz leises Wummern pro Umdrehung (33⅓ U/min ≈ 1,8 s)
      for (let i = 0; i < n; i++) d[i] += Math.sin((2 * Math.PI * i) / (sr * 1.8)) * 0.004;
    }
    return b;
  }
  function crackleSync() {
    const want = crackle.on && Boolean(pl.m?.playing);
    if (want && !crackle.src) {
      crackle.ctx = crackle.ctx || new AudioContext();
      const c = crackle.ctx;
      c.resume().catch(() => {});
      const src = c.createBufferSource();
      src.buffer = crackleBuffer(c);
      src.loop = true;
      const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 280;
      const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 7500;
      const g = c.createGain(); g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.exponentialRampToValueAtTime(0.55, c.currentTime + 0.6);
      src.connect(hp).connect(lp).connect(g).connect(c.destination);
      src.start();
      crackle.src = src; crackle.gain = g;
    } else if (!want && crackle.src) {
      const { src, gain, ctx: c } = crackle;
      crackle.src = null;
      try { gain.gain.setTargetAtTime(0.0001, c.currentTime, 0.15); setTimeout(() => { try { src.stop(); } catch { /* egal */ } }, 700); } catch { /* egal */ }
    }
  }
  window.hub.onMedia?.(() => setTimeout(crackleSync, 0));

  /* ---------------- 2.46 echtes Vollbild: ganzer Monitor, App-Leiste und Dock weg */
  let full = false, idleT = 0;
  function setFull(on) {
    full = on;
    const host = document.querySelector(`[data-tool-page="${PAGE}"]`);
    document.body.classList.toggle('pl-full', on);
    host?.classList.toggle('pl-fs-host', on);
    if (on && host && pl.m?.art) host.style.setProperty('--pl-art', `url('${artUrl(pl.m.art)}')`);
    window.hub.window?.(on ? 'fullscreen-on' : 'fullscreen-off');
    if (!on) document.body.classList.remove('pl-idle');
    setTimeout(tick, 300);
  }
  document.addEventListener('keydown', (e) => { if (full && e.key === 'Escape') { e.preventDefault(); setFull(false); } });
  document.addEventListener('mousemove', () => {
    if (!full) return;
    document.body.classList.remove('pl-idle');
    clearTimeout(idleT);
    idleT = setTimeout(() => full && document.body.classList.add('pl-idle'), 2500);
  });
  // Seite verlassen → Vollbild aus; neu gezeichnet → Klasse am neuen Element wieder setzen
  setInterval(() => {
    if (!full) return;
    if (!active()) return setFull(false);
    const host = document.querySelector(`[data-tool-page="${PAGE}"]`);
    if (host && !host.classList.contains('pl-fs-host')) { host.classList.add('pl-fs-host'); if (pl.m?.art) host.style.setProperty('--pl-art', `url('${artUrl(pl.m.art)}')`); }
  }, 400);

  document.addEventListener('click', (e) => {
    if (!active()) return;
    const x = e.target.closest('[data-plx]')?.dataset.plx;
    if (x === 'full') return setFull(true);
    if (x === 'exit') return setFull(false);
    if (x === 'crackle') {
      crackle.on = !crackle.on;
      try { localStorage.setItem('rv-player-crackle', crackle.on ? '1' : '0'); } catch { /* egal */ }
      e.target.closest('[data-plx]').classList.toggle('on', crackle.on);
      crackleSync();
      if (crackle.on && !pl.m?.playing) ctx().toast?.('Knistern läuft, sobald Musik spielt.');
      return;
    }
    const v = e.target.closest('[data-plview]')?.dataset.plview;
    if (v) {
      view = v;
      try { localStorage.setItem('rv-player-view', v); } catch { /* egal */ }
      ctx().render();
      return;
    }
    const b = e.target.closest('[data-pl]');
    if (!b) return;
    window.hub.cc?.media?.(b.dataset.pl)?.catch?.(() => {});
    if (b.dataset.pl === 'playpause' && pl.m) {
      pl.m.playing = !pl.m.playing;
      pl.m.position = pos();
      pl.at = Date.now();
      const main = b.tagName === 'BUTTON' ? b : document.querySelector('.pl-ctl .main');
      if (main) main.innerHTML = window.icon(pl.m.playing ? 'pause' : 'play', 26);
      tick();
      ttStart();
      crackleSync();
    }
  });

  T.register(PAGE, { nav: 'Player', title: 'Player', sub: 'Cover und Songtext im Vollbild', icon: 'music', tint: 'linear-gradient(135deg,#f472b6,#7c3aed)', desc: 'Großes Albumbild und der Songtext, der beim Singen mitleuchtet – ganz ohne Ablenkung.' }, html);
})();
