'use strict';

/*
 * 2.47.5 Sperrbildschirm: Windows zeigt dort nur Bilder (kein Video). Deshalb bekommt der Sperrbildschirm
 * das scharfe Standbild des aktuellen (Live-)Hintergrunds – über die offizielle Windows-Schnittstelle
 * LockScreen.SetImageFileAsync (gilt nur für das eigene Konto, keine Admin-Rechte nötig).
 */
const fs = require('fs');
const { execFile } = require('child_process');

const SCRIPT = [
  "$ErrorActionPreference = 'Stop'",
  "$ProgressPreference = 'SilentlyContinue'",
  'Add-Type -AssemblyName System.Runtime.WindowsRuntime',
  '[void][Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]',
  '[void][Windows.System.UserProfile.LockScreen, Windows.System.UserProfile, ContentType = WindowsRuntime]',
  '$ext = [System.WindowsRuntimeSystemExtensions].GetMethods()',
  "$op = ($ext | Where-Object { $_.ToString() -eq 'System.Threading.Tasks.Task`1[TResult] AsTask[TResult](Windows.Foundation.IAsyncOperation`1[TResult])' })[0]",
  "$act = ($ext | Where-Object { $_.ToString() -eq 'System.Threading.Tasks.Task AsTask(Windows.Foundation.IAsyncAction)' })[0]",
  '$file = $op.MakeGenericMethod([Windows.Storage.StorageFile]).Invoke($null, @([Windows.Storage.StorageFile]::GetFileFromPathAsync($env:REV_LOCK_IMG))).Result',
  '$act.Invoke($null, @([Windows.System.UserProfile.LockScreen]::SetImageFileAsync($file))).Wait()',
  "'ok'",
].join('\n');

/** @param {string} image lokale JPG/PNG-Datei */
function setLockScreenImage(image) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32' || !image || !fs.existsSync(image)) return resolve(false);
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(SCRIPT, 'utf16le').toString('base64')],
      { windowsHide: true, timeout: 30000, env: { ...process.env, REV_LOCK_IMG: image } },
      (error, stdout) => resolve(!error && String(stdout).includes('ok')),
    );
  });
}

module.exports = { setLockScreenImage };
