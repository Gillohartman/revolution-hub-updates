'use strict';

/*
 * Windows-Taskleisten-Apps für die Revulution-Leiste:
 * angeheftete Verknüpfungen und laufende Fenster, inklusive echter Symbole.
 * Die Symbole werden als PNG zwischengespeichert, damit die Leiste sie ohne
 * Zugriff auf fremde Programme laden kann.
 */
const { execFile, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { app, shell } = require('electron');

const CACHE = path.join(app.getPath('userData'), 'windows-taskbar');
let entries = [];
let busy = null;
let last = 0;

function iconUrl(file) {
  if (!file) return '';
  try {
    return require('url').pathToFileURL(file).href;
  } catch {
    return '';
  }
}

const SCRIPT = String.raw`
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Drawing
$dir = $env:REV_TASKBAR_ICONS
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$shell = New-Object -ComObject WScript.Shell
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$md5 = [Security.Cryptography.MD5]::Create()
Add-Type -AssemblyName System.Data
# Echte App-Symbole über die Windows-Shell – klappt für Verknüpfungen, Programme und Store-Apps
# (shell:AppsFolder\<AppID>), in hoher Auflösung und mit Transparenz.
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class RevIcon {
  [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IShellItemImageFactory { [PreserveSig] int GetImage(SIZE size, int flags, out IntPtr phbm); }
  [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; public SIZE(int x, int y) { cx = x; cy = y; } }
  [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
  static extern void SHCreateItemFromParsingName(string path, IntPtr pbc, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.Interface)] out IShellItemImageFactory item);
  [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr h);
  public static bool Save(string parsing, string file, int px) {
    try {
      IShellItemImageFactory f;
      SHCreateItemFromParsingName(parsing, IntPtr.Zero, new Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), out f);
      IntPtr hbm;
      // 0x1 = BIGGERSIZEOK, 0x4 = ICONONLY
      if (f.GetImage(new SIZE(px, px), 0x1 | 0x4, out hbm) != 0 || hbm == IntPtr.Zero) return false;
      try {
        var src = Image.FromHbitmap(hbm);
        var bd = src.LockBits(new Rectangle(0, 0, src.Width, src.Height), ImageLockMode.ReadOnly, src.PixelFormat);
        var argb = new Bitmap(src.Width, src.Height, bd.Stride, PixelFormat.Format32bppArgb, bd.Scan0);
        var copy = new Bitmap(argb);
        src.UnlockBits(bd);
        copy.Save(file, ImageFormat.Png);
        copy.Dispose(); argb.Dispose(); src.Dispose();
        return true;
      } finally { DeleteObject(hbm); }
    } catch { return false; }
  }
}
'@

function Save-Icon([string]$source, [string]$prefix) {
  try {
    if (-not $source) { return $null }
    $hash = [BitConverter]::ToString($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes($source.ToLowerInvariant()))).Replace('-', '')
    $file = Join-Path $dir ($prefix + '_' + $hash + '.png')
    if (Test-Path -LiteralPath $file) { return $file }
    $ico = [System.Drawing.Icon]::ExtractAssociatedIcon($source)
    if ($null -eq $ico) { return $null }
    $bmp = $ico.ToBitmap()
    $bmp.Save($file, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    $ico.Dispose()
    return $file
  } catch { return $null }
}

# 2.46: Fenster, die Windows nur versteckt hält (Einstellungen, Rechner … im Ruhezustand), zählen nicht als offen
if (-not ('RevWinVis' -as [type])) {
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class RevWinVis {
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int s);
  public static bool Shown(IntPtr h) { if (h == IntPtr.Zero || !IsWindowVisible(h)) return false; int c; return DwmGetWindowAttribute(h, 14, out c, 4) != 0 || c == 0; }
}
'@
}

function Scan {
$items = New-Object System.Collections.ArrayList
$seen = @{}
$pinnedDir = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
Get-ChildItem -LiteralPath $pinnedDir -Filter '*.lnk' -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object {
  $lnk = $_.FullName
  $target = ''
  try { $target = $shell.CreateShortcut($lnk).TargetPath } catch {}
  $key = if ($target) { $target.ToLowerInvariant() } else { $lnk.ToLowerInvariant() }
  if ($seen.ContainsKey($key)) { return }
  $seen[$key] = $true
  $icon = Save-Icon $(if ($target) { $target } else { $lnk }) 'pin'
  $name = [System.IO.Path]::GetFileNameWithoutExtension($_.Name)
  if ($name -match '(?i)revulution|revolution hub') { return }
  [void]$items.Add([pscustomobject]@{
    id = 'pin:' + $_.BaseName
    name = $name
    icon = $icon
    kind = 'pinned'
    path = $lnk
    target = $target
    handle = 0
  })
}

$self = $PID
Get-Process -ErrorAction SilentlyContinue | Where-Object {
  $_.MainWindowHandle -ne 0 -and ($_.ProcessName -eq 'explorer' -or [RevWinVis]::Shown($_.MainWindowHandle)) -and $_.Path -and $_.Id -ne $self -and $_.Path -ne $env:REV_SELF -and
  $_.ProcessName -notmatch '^(Revulution|RevulutionHub|OrbitIsland|SystemSettings|TextInputHost|ApplicationFrameHost|ShellExperienceHost|StartMenuExperienceHost|SearchHost|Widgets|LockApp|NVIDIA|NVIDIA Overlay|NVDisplay\.Container)$'
} | Sort-Object StartTime | ForEach-Object {
  $exe = $_.Path
  $key = $exe.ToLowerInvariant()
  if ($exe -match '(?i)\\Revulution Hub\\|\\Revolution Hub\\') { return }
  if ($seen.ContainsKey($key)) { return }
  $seen[$key] = $true
  $icon = Save-Icon $exe 'run'
  $name = [System.IO.Path]::GetFileNameWithoutExtension($exe)
  if ($_.ProcessName -eq 'explorer') { $name = 'Explorer' }
  [void]$items.Add([pscustomobject]@{
    id = 'run:' + $_.Id
    pid = [int]$_.Id
    name = $name
    icon = $icon
    kind = 'running'
    path = $exe
    target = $exe
    handle = [int64]$_.MainWindowHandle
    title = $_.MainWindowTitle
  })
}

return ,@($items | Select-Object -First 18)
}

# Dateien über den Windows-Suchindex (schnell, auch in großen Ordnern)
function Find-Files([string]$q) {
  $out = New-Object System.Collections.ArrayList
  $q = ($q -replace '[''"%*\[\]]', ' ').Trim()
  if ($q.Length -lt 2) { return ,@() }
  $scope = 'file:' + ($env:USERPROFILE -replace '\\', '/')
  $sqls = @(
    "SELECT TOP 14 System.ItemUrl, System.ItemNameDisplay, System.ItemType FROM SystemIndex WHERE SCOPE='$scope' AND CONTAINS(System.FileName, '""$q*""') AND NOT System.ItemUrl LIKE '%/AppData/%' AND NOT System.ItemUrl LIKE '%/node_modules/%' ORDER BY System.DateModified DESC",
    "SELECT TOP 14 System.ItemUrl, System.ItemNameDisplay, System.ItemType FROM SystemIndex WHERE SCOPE='$scope' AND System.FileName LIKE '%$q%' AND NOT System.ItemUrl LIKE '%/AppData/%' AND NOT System.ItemUrl LIKE '%/node_modules/%' ORDER BY System.DateModified DESC"
  )
  try {
    $conn = New-Object System.Data.OleDb.OleDbConnection "Provider=Search.CollatorDSO;Extended Properties='Application=Windows';"
    $conn.Open()
    foreach ($sql in $sqls) {
      $cmd = $conn.CreateCommand(); $cmd.CommandText = $sql
      $r = $cmd.ExecuteReader()
      while ($r.Read()) {
        $p = [string]$r.GetValue(0)
        if ($p.StartsWith('file:')) { $p = [Uri]::UnescapeDataString($p.Substring(5)).Replace('/', [string][char]92) } else { continue }
        if ($p -and -not ($out | Where-Object { $_.path -eq $p })) {
          [void]$out.Add([pscustomobject]@{ path = $p; name = [string]$r.GetValue(1); type = [string]$r.GetValue(2) })
        }
      }
      $r.Close()
      if ($out.Count -ge 6) { break }
    }
    $conn.Close()
  } catch {}
  return ,@($out | Select-Object -First 14)
}

# Wer benutzt gerade die Kamera? Windows trägt das selbst ein (LastUsedTimeStop = 0 heißt: läuft).
function Cam {
  $out = New-Object System.Collections.ArrayList
  $root = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam'
  $keys = @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue) + @(Get-ChildItem -LiteralPath ($root + '\NonPackaged') -ErrorAction SilentlyContinue)
  foreach ($k in $keys) {
    $p = Get-ItemProperty -LiteralPath $k.PSPath -ErrorAction SilentlyContinue
    if ($p -and $p.LastUsedTimeStart -and ($p.LastUsedTimeStop -eq 0)) { [void]$out.Add([string]$k.PSChildName) }
  }
  return ,@($out)
}

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  try {
    if ($line -eq 'scan') {
      [Console]::Out.WriteLine('S' + (ConvertTo-Json -InputObject (Scan) -Compress -Depth 3))
    } elseif ($line.StartsWith('find ')) {
      $q = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($line.Substring(5)))
      [Console]::Out.WriteLine('F' + (ConvertTo-Json -InputObject (Find-Files $q) -Compress -Depth 3))
    } elseif ($line.StartsWith('icon ')) {
      $parts = $line.Substring(5).Split(' ')
      $src = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($parts[0]))
      $hash = [BitConverter]::ToString($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes($src.ToLowerInvariant()))).Replace('-', '')
      $file = Join-Path $dir ('app_' + $hash + '.png')
      if ((Test-Path -LiteralPath $file) -or [RevIcon]::Save($src, $file, 64)) { [Console]::Out.WriteLine('I' + $file) } else { [Console]::Out.WriteLine('I') }
    } elseif ($line -eq 'cam') {
      [Console]::Out.WriteLine('C' + (ConvertTo-Json -InputObject (Cam) -Compress))
    } elseif ($line -eq 'apps') {
      $apps = @(Get-StartApps | Select-Object Name, AppID)
      [Console]::Out.WriteLine('A' + (ConvertTo-Json -InputObject $apps -Compress -Depth 3))
    }
  } catch { [Console]::Out.WriteLine('E') }
}
`;

function parse(raw) {
  const text = String(raw || '').trim();
  if (!text) return [];
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return [];
  }
  const list = Array.isArray(parsed) ? parsed : [parsed];
  return list
    .filter((item) => item && item.id && item.name)
    .map((item) => ({
      id: String(item.id),
      name: String(item.name).slice(0, 54),
      icon: iconUrl(item.icon ? String(item.icon) : ''),
      kind: item.kind === 'running' ? 'running' : 'pinned',
      path: String(item.path || ''),
      target: String(item.target || ''),
      handle: Number(item.handle) || 0,
      pid: Number(item.pid) || 0,
    }));
}

/* Ein dauerhaft laufender Helfer: kein PowerShell-Start pro Abfrage mehr. */
let helper = null;
let helperBuf = '';
const waiting = { S: [], F: [], A: [], C: [], I: [] };
function startHelper() {
  if (helper) return helper;
  try {
    fs.mkdirSync(CACHE, { recursive: true });
  } catch {
    /* Cache ist optional */
  }
  const file = path.join(CACHE, 'rev-taskbar-helper.ps1');
  try {
    fs.writeFileSync(file, '﻿' + SCRIPT, 'utf8');
  } catch {
    return null;
  }
  const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], {
    windowsHide: true,
    stdio: ['pipe', 'pipe', 'ignore'],
    env: { ...process.env, REV_TASKBAR_ICONS: CACHE, REV_SELF: process.execPath },
  });
  helper = child;
  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    helperBuf += chunk;
    const lines = helperBuf.split(/\r?\n/);
    helperBuf = lines.pop() || '';
    for (const line of lines) {
      const kind = line[0];
      if (kind === 'E') {
        for (const k of Object.keys(waiting)) if (waiting[k].length) { waiting[k].shift()(''); break; }
        continue;
      }
      const q = waiting[kind];
      if (q?.length) q.shift()(line.slice(1));
    }
  });
  const fail = () => {
    if (helper === child) helper = null;
    for (const k of Object.keys(waiting)) while (waiting[k].length) waiting[k].shift()('');
  };
  child.on('exit', fail);
  child.on('error', fail);
  child.stdin.on('error', () => {});
  return child;
}
function ask(kind, line, timeout = 12000) {
  return new Promise((resolve) => {
    const h = startHelper();
    if (!h) return resolve('');
    let done = false;
    const finish = (v) => {
      if (done) return;
      done = true;
      resolve(v);
    };
    waiting[kind].push(finish);
    setTimeout(() => {
      const i = waiting[kind].indexOf(finish);
      if (i >= 0) waiting[kind].splice(i, 1);
      finish('');
    }, timeout);
    try {
      h.stdin.write(`${line}\n`);
    } catch {
      finish('');
    }
  });
}

async function refresh(force = false) {
  if (process.platform !== 'win32') return entries;
  if (busy) return busy;
  if (!force && Date.now() - last < 2500) return entries;
  busy = (async () => {
    const next = parse(await ask('S', 'scan', 20000));
    if (next.length) entries = next;
    last = Date.now();
    return entries;
  })();
  try {
    return await busy;
  } finally {
    busy = null;
  }
}

/* ------------------------------------------------------------ Suche im Win-Menü */
const START_DIRS = [
  path.join(process.env.ProgramData || 'C:\\ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
  path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
  path.join(process.env.USERPROFILE || '', 'Desktop'),
  path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Desktop'),
  path.join(process.env.USERPROFILE || '', 'OneDrive', 'Desktop'),
];
let uwpApps = [];
let uwpLoading = null;
function loadUwp() {
  if (uwpLoading) return uwpLoading;
  uwpLoading = ask('A', 'apps', 30000).then((raw) => {
    try {
      const list = JSON.parse(raw || '[]');
      uwpApps = (Array.isArray(list) ? list : [list]).filter((a) => a && a.Name && a.AppID && !/uninstall|deinstall/i.test(a.Name)).map((a) => ({ name: String(a.Name).trim(), appId: String(a.AppID).trim() }));
    } catch {
      uwpApps = [];
    }
    startAppsAt = 0; // Liste neu zusammensetzen
    if (!uwpApps.length) uwpLoading = null; // später nochmal versuchen
    return uwpApps;
  });
  return uwpLoading;
}
let startApps = null;
let startAppsAt = 0;
function walkLinks(dir, out, depth = 0) {
  if (depth > 4) return;
  let list = [];
  try {
    list = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of list) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walkLinks(full, out, depth + 1);
    else if (/\.(lnk|url)$/i.test(e.name) && !/uninstall|deinstall|readme|help|hilfe|website|license|lizenz/i.test(e.name)) out.push(full);
  }
}
async function loadStartApps() {
  if (startApps && startAppsAt && Date.now() - startAppsAt < 10 * 60 * 1000) return startApps;
  const links = [];
  for (const d of START_DIRS) walkLinks(d, links, /Desktop$/i.test(d) ? 4 : 0); // Desktop: nur die oberste Ebene
  const byName = new Map();
  for (const l of links) {
    const name = path.basename(l).replace(/\.(lnk|url)$/i, '');
    if (!byName.has(name.toLowerCase())) byName.set(name.toLowerCase(), { id: `lnk:${l}`, name, path: l, kind: 'app' });
  }
  // Store-Apps (Rechner, Fotos, Einstellungen …) kennt nur Get-StartApps – kommt im Hintergrund dazu,
  // die Suche wartet nie darauf.
  loadUwp();
  for (const a of uwpApps) {
    if (byName.has(a.name.toLowerCase())) continue;
    byName.set(a.name.toLowerCase(), { id: `uwp:${a.appId}`, name: a.name, path: '', appId: a.appId, kind: 'app' });
  }
  startApps = [...byName.values()].sort((a, b) => a.name.localeCompare(b.name, 'de'));
  startAppsAt = Date.now();
  return startApps;
}
const shellIconCache = new Map();
/** Symbol über die Windows-Shell (auch Store-Apps). Liefert eine file://-URL oder ''. */
async function shellIcon(parsing) {
  if (!parsing) return '';
  if (shellIconCache.has(parsing)) return shellIconCache.get(parsing);
  const out = await ask('I', `icon ${Buffer.from(parsing, 'utf8').toString('base64')}`, 4000);
  const url = out ? iconUrl(out) : '';
  shellIconCache.set(parsing, url);
  return url;
}
const iconCache = new Map();
async function fileIcon(file) {
  if (!file) return '';
  if (iconCache.has(file)) return iconCache.get(file);
  let url = '';
  try {
    const img = await app.getFileIcon(file, { size: 'normal' });
    url = img && !img.isEmpty() ? img.toDataURL() : '';
  } catch {
    url = '';
  }
  iconCache.set(file, url);
  return url;
}
const lastResults = new Map();
/** Nur Apps – schnell, ohne Dateisuche. */
async function searchApps(query) {
  const q = String(query || '').trim().toLocaleLowerCase('de');
  if (!q) return [];
  const all = await loadStartApps().catch(() => []);
  const score = (n) => {
    const s = n.toLocaleLowerCase('de');
    if (s.startsWith(q)) return 0;
    if (s.split(/[\s\-_.]+/).some((w) => w.startsWith(q))) return 1;
    return s.includes(q) ? 2 : 9;
  };
  const apps = all
    .map((a) => ({ a, s: score(a.name) }))
    .filter((x) => x.s < 9)
    .sort((x, y) => x.s - y.s || x.a.name.length - y.a.name.length)
    .slice(0, 12)
    .map((x) => x.a);
  await Promise.all(apps.map(async (a) => {
    const parsing = a.appId ? `shell:AppsFolder\\${a.appId}` : a.path;
    a.icon = await Promise.race([shellIcon(parsing), new Promise((r) => setTimeout(() => r(''), 2500))]);
    if (!a.icon && a.path) a.icon = await fileIcon(a.path);
  }));
  for (const r of apps) lastResults.set(r.id, r);
  return apps.map((a) => ({ id: a.id, name: a.name, icon: a.icon }));
}
/** Nur Dateien – über den Windows-Suchindex. */
async function searchFiles(query) {
  const q = String(query || '').trim().toLocaleLowerCase('de');
  if (q.length < 2) return [];
  let files = [];
  try {
    const raw = await ask('F', `find ${Buffer.from(q, 'utf8').toString('base64')}`, 8000);
    const list = JSON.parse(raw || '[]');
    files = (Array.isArray(list) ? list : [list]).filter((f) => f && f.path).map((f) => ({ id: `file:${f.path}`, name: String(f.name || path.basename(f.path)), path: String(f.path), kind: 'file' }));
  } catch {
    files = [];
  }
  await Promise.all(files.map(async (f) => { f.icon = await Promise.race([fileIcon(f.path), new Promise((r) => setTimeout(() => r(''), 1500))]); }));
  for (const r of files) lastResults.set(r.id, r);
  return files.map((f) => ({ id: f.id, name: f.name, icon: f.icon, dir: path.dirname(f.path).replace(process.env.USERPROFILE || '', '~') }));
}

async function search(query) {
  const q = String(query || '').trim().toLocaleLowerCase('de');
  if (!q) return { apps: [], files: [] };
  const all = await loadStartApps().catch(() => []);
  const score = (n) => {
    const s = n.toLocaleLowerCase('de');
    if (s.startsWith(q)) return 0;
    if (s.split(/[\s\-_.]+/).some((w) => w.startsWith(q))) return 1;
    return s.includes(q) ? 2 : 9;
  };
  const apps = all
    .map((a) => ({ a, s: score(a.name) }))
    .filter((x) => x.s < 9)
    .sort((x, y) => x.s - y.s || x.a.name.length - y.a.name.length)
    .slice(0, 12)
    .map((x) => x.a);
  let files = [];
  if (q.length >= 2) {
    try {
      const raw = await ask('F', `find ${Buffer.from(q, 'utf8').toString('base64')}`, 8000);
      const list = JSON.parse(raw || '[]');
      files = (Array.isArray(list) ? list : [list]).filter((f) => f && f.path).map((f) => ({ id: `file:${f.path}`, name: String(f.name || path.basename(f.path)), path: String(f.path), type: String(f.type || ''), kind: 'file' }));
    } catch {
      files = [];
    }
  }
  for (const a of apps) a.icon = a.path ? await fileIcon(a.path) : '';
  for (const f of files) f.icon = await fileIcon(f.path);
  for (const r of [...apps, ...files]) lastResults.set(r.id, r);
  if (lastResults.size > 400) for (const k of [...lastResults.keys()].slice(0, 200)) lastResults.delete(k);
  return {
    apps: apps.map((a) => ({ id: a.id, name: a.name, icon: a.icon })),
    files: files.map((f) => ({ id: f.id, name: f.name, icon: f.icon, dir: path.dirname(f.path).replace(process.env.USERPROFILE || '', '~') })),
  };
}
async function openResult(id) {
  const r = lastResults.get(String(id || ''));
  if (!r) return false;
  if (r.appId) {
    spawn('explorer.exe', [`shell:AppsFolder\\${r.appId}`], { windowsHide: true, detached: true, stdio: 'ignore' }).unref();
    return true;
  }
  const err = await shell.openPath(r.path).catch(() => 'fail');
  return !err;
}
const CAM_NAMES = { 'nvidia broadcast': 'NVIDIA Broadcast', obs64: 'OBS', discord: 'Discord', teams: 'Microsoft Teams', 'ms-teams': 'Microsoft Teams', zoom: 'Zoom', chrome: 'Google Chrome', msedge: 'Microsoft Edge', firefox: 'Firefox', opera: 'Opera', brave: 'Brave', mediasdk_server: 'TikTok LIVE Studio' };
/** Apps, die gerade die Kamera benutzen: [{ name, path, own }] */
async function cameraUsers() {
  if (process.platform !== 'win32') return [];
  let list = [];
  try {
    const raw = await ask('C', 'cam', 8000);
    list = JSON.parse(raw || '[]');
  } catch {
    return null;
  }
  if (!Array.isArray(list)) list = list ? [list] : [];
  const self = process.execPath.toLowerCase();
  return list.map((key) => {
    const k = String(key);
    if (k.includes('#')) {
      const file = k.replace(/#/g, '\\');
      const base = path.basename(file).replace(/\.exe$/i, '');
      const own = file.toLowerCase() === self || /revulution|revolution hub/i.test(file);
      return { name: own ? 'Revulution Hub' : CAM_NAMES[base.toLowerCase()] || base, path: file, own };
    }
    // Store-App: „Microsoft.WindowsCamera_8wekyb3d8bbwe“ → „Kamera“
    const pkg = k.split('_')[0].replace(/^Microsoft\./, '');
    const nice = { WindowsCamera: 'Kamera', MicrosoftTeams: 'Microsoft Teams', SkypeApp: 'Skype', WindowsStore: 'Microsoft Store' }[pkg] || pkg.replace(/([a-z])([A-Z])/g, '$1 $2');
    return { name: nice, path: '', own: false };
  });
}

function stop() {
  try {
    helper?.kill();
  } catch {
    /* schon weg */
  }
  helper = null;
}

function find(id) {
  return entries.find((entry) => entry.id === id) || null;
}

async function focusRunning(entry) {
  const script = `$ErrorActionPreference='SilentlyContinue'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class RevFocus {
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr SetFocus(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
}
'@
$h = [IntPtr]${Number(entry.handle) || 0}
$pidTarget = ${Number(entry.pid) || 0}
if ($h -eq [IntPtr]::Zero -and $pidTarget -gt 0) {
  $p = Get-Process -Id $pidTarget -ErrorAction SilentlyContinue
  if ($p) { $h = $p.MainWindowHandle }
}
if ($h -eq [IntPtr]::Zero) { Write-Output 'no'; exit 0 }
if ([RevFocus]::IsIconic($h)) { [void][RevFocus]::ShowWindow($h, 9) } else { [void][RevFocus]::ShowWindow($h, 5) }
[void][RevFocus]::BringWindowToTop($h)
$fg = [RevFocus]::GetForegroundWindow()
if ($fg -ne $h) {
  $p = 0
  $target = [RevFocus]::GetWindowThreadProcessId($h, [ref]$p)
  $current = [RevFocus]::GetCurrentThreadId()
  [void][RevFocus]::AttachThreadInput($current, $target, $true)
  [void][RevFocus]::SetForegroundWindow($h)
  [void][RevFocus]::SetFocus($h)
  [void][RevFocus]::AttachThreadInput($current, $target, $false)
}
Start-Sleep -Milliseconds 120
if ([RevFocus]::GetForegroundWindow() -eq $h -or [RevFocus]::SetForegroundWindow($h)) { Write-Output 'ok' } else { Write-Output 'no' }`;
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout: 8000 }, (error, stdout) => resolve(!error && String(stdout || '').includes('ok')));
  });
}

async function launch(id) {
  let entry = find(id);
  if (!entry) {
    await refresh(true);
    entry = find(id);
  }
  if (!entry) return false;
  // Laufende Apps: immer nur in den Vordergrund holen – niemals eine zweite
  // Instanz starten oder versehentlich den Einstellungs-Eintrag öffnen.
  if (entry.kind === 'running') {
    if (!entry.handle) {
      await refresh(true);
      entry = find(id) || entry;
    }
    return focusRunning(entry);
  }
  if (entry.path) {
    const error = await shell.openPath(entry.path).catch(() => 'open failed');
    if (!error) return true;
    const child = spawn('cmd.exe', ['/c', 'start', '', entry.path], { windowsHide: true, detached: true, stdio: 'ignore' });
    child.unref();
    return true;
  }
  if (entry.target) {
    const error = await shell.openPath(entry.target).catch(() => 'open failed');
    if (!error) return true;
    spawn(entry.target, [], { windowsHide: true, detached: true, stdio: 'ignore' }).unref();
    return true;
  }
  return false;
}

async function closeWindow(id) {
  const entry = find(id);
  if (!entry || !entry.handle) return false;
  const script = `$ErrorActionPreference='SilentlyContinue'; Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class RevClose { [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l); }'; [RevClose]::PostMessage([IntPtr]${Number(entry.handle)},0x0010,[IntPtr]::Zero,[IntPtr]::Zero)`;
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 5000 }, (error) => resolve(!error));
  });
}

async function endTask(id) {
  const entry = find(id);
  if (!entry) return false;
  if (entry.pid) {
    return new Promise((resolve) => {
      execFile('taskkill.exe', ['/PID', String(entry.pid), '/T', '/F'], { windowsHide: true, timeout: 8000 }, (error) => resolve(!error));
    });
  }
  if (!entry.target) return false;
  const script = "$ErrorActionPreference='SilentlyContinue'; Get-Process | Where-Object { $_.Path -eq $env:REV_TARGET } | Stop-Process -Force";
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], {
      windowsHide: true,
      timeout: 8000,
      env: { ...process.env, REV_TARGET: entry.target },
    }, (error) => resolve(!error));
  });
}

async function pin(id) {
  const entry = find(id);
  if (!entry || entry.kind === 'pinned' || !entry.target) return false;
  const script = `$ErrorActionPreference='Stop'; $dir=Join-Path $env:APPDATA 'Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\TaskBar'; New-Item -ItemType Directory -Force -Path $dir | Out-Null; $file=Join-Path $dir ($env:REV_NAME + '.lnk'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($file); $s.TargetPath=$env:REV_TARGET; $s.WorkingDirectory=Split-Path $env:REV_TARGET; $s.IconLocation=($env:REV_TARGET + ',0'); $s.Save()`;
  const name = String(entry.name || 'App').replace(/[\\/:*?"<>|]/g, '').slice(0, 54) || 'App';
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], {
      windowsHide: true,
      timeout: 8000,
      env: { ...process.env, REV_NAME: name, REV_TARGET: entry.target },
    }, (error) => resolve(!error));
  });
}

async function unpin(id) {
  const entry = find(id);
  if (!entry || entry.kind !== 'pinned' || !entry.path) return false;
  try {
    const pinnedDir = path.join(process.env.APPDATA || '', 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned', 'TaskBar');
    const resolved = path.resolve(entry.path);
    if (!resolved.startsWith(path.resolve(pinnedDir) + path.sep) || path.extname(resolved).toLowerCase() !== '.lnk') return false;
    fs.unlinkSync(resolved);
    return true;
  } catch {
    return false;
  }
}

function reveal(id) {
  const entry = find(id);
  if (!entry) return false;
  const target = entry.target || entry.path;
  if (!target) return false;
  shell.showItemInFolder(target);
  return true;
}

module.exports = { searchApps, searchFiles, cameraUsers, refresh, launch, closeWindow, endTask, pin, unpin, reveal, search, openResult, preloadSearch: () => { loadUwp(); return loadStartApps().catch(() => []); }, stop, list: () => entries };
