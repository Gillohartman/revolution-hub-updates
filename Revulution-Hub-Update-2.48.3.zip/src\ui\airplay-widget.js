'use strict';

/* iPhone-Spiegelung als freies Fenster: holt das (versteckte) Empfänger-Fenster per Aufnahme
   und zeigt es mit iPhone-Ecken oder eckig. Ziehen am Bild verschiebt das Fenster. */
(() => {
  const q = new URLSearchParams(location.search);
  const setCorners = (c) => {
    document.body.classList.toggle('square', c === 'square');
    document.getElementById('corners').textContent = c === 'square' ? 'Rund' : 'Eckig';
  };
  setCorners(q.get('corners') || 'round');
  window.hub.onApCorners?.(setCorners);
  document.getElementById('corners').addEventListener('click', () => setCorners(document.body.classList.contains('square') ? 'round' : 'square'));
  document.getElementById('close').addEventListener('click', () => window.hub.apWidgetClose());
  let onTop = true;
  document.getElementById('pin').addEventListener('click', (e) => {
    onTop = !onTop;
    e.currentTarget.textContent = onTop ? 'Nicht oben' : 'Immer oben';
    window.hub.winAlwaysOnTop?.(onTop);
  });

  /* 2.47.2: Querformat, drei Größen und Vollbild – das Fenster passt sich an */
  const st = { orient: 'port', size: 1, full: false };
  const SIZES = ['Klein', 'Mittel', 'Groß'];
  const apply = () => {
    document.body.classList.toggle('land', st.orient === 'land');
    document.body.classList.toggle('full', st.full);
    document.getElementById('orient').textContent = st.orient === 'land' ? 'Hoch' : 'Quer';
    document.getElementById('size').textContent = SIZES[(st.size + 1) % 3];
    document.getElementById('full').textContent = st.full ? 'Fenster' : 'Vollbild';
    window.hub.apWidgetShape?.({ orient: st.orient, size: st.size, full: st.full });
  };
  document.getElementById('orient').addEventListener('click', () => { st.orient = st.orient === 'land' ? 'port' : 'land'; st.auto = false; apply(); });
  document.getElementById('size').addEventListener('click', () => { st.size = (st.size + 1) % 3; apply(); });
  document.getElementById('full').addEventListener('click', () => { st.full = !st.full; apply(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && st.full) { st.full = false; apply(); } if (e.key === 'f' || e.key === 'F11') { e.preventDefault(); st.full = !st.full; apply(); } });
  document.addEventListener('dblclick', () => { st.full = !st.full; apply(); });
  // dreht man das iPhone, kommt ein breites Bild → automatisch Querformat (solange nicht von Hand gewählt)
  st.auto = true;
  document.getElementById('v').addEventListener('resize', (e) => {
    const v = e.target;
    if (!st.auto || !v.videoWidth) return;
    const want = v.videoWidth > v.videoHeight ? 'land' : 'port';
    if (want !== st.orient) { st.orient = want; apply(); }
  });

  async function connect() {
    try {
      await window.hub.airplay.arm();
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 60 }, audio: false });
      const v = document.getElementById('v');
      v.srcObject = stream;
      // Text erst weg, wenn wirklich Bild kommt
      v.onplaying = () => (document.getElementById('empty').hidden = true);
      document.getElementById('empty').hidden = true;
      stream.getVideoTracks()[0]?.addEventListener('ended', () => {
        document.getElementById('empty').hidden = false;
        setTimeout(connect, 2000);
      });
    } catch {
      document.getElementById('empty').hidden = false;
      setTimeout(connect, 3000);
    }
  }
  connect();
})();
