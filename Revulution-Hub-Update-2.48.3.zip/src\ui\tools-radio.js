'use strict';
/*
 * 2.46 Radio – alle Radiosender der Welt als leuchtende Punkte auf einer Weltkarte.
 * Daten: radio-browser.info (freie, offene Senderdatenbank). Karte: Natural Earth 1:110m (world-110m.js).
 * Ziehen = verschieben, Mausrad = zoomen, Punkt anklicken = Sender an diesem Ort, Sender anklicken = hören.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-radio';
  const API = ['de1.api.radio-browser.info', 'de2.api.radio-browser.info', 'nl1.api.radio-browser.info', 'at1.api.radio-browser.info'];

  const st = {
    root: null, stations: [], loading: false, error: '', places: [], sel: null, q: '', fav: [], tab: 'here',
    view: { x: 0, y: 0, k: 1 }, drag: null, hover: null, raf: 0, playing: null, audio: null, vol: 0.8, state: 'idle',
  };

  /* ---------------------------------------------------------------- Weltkarte (TopoJSON → Pfade) */
  let land = null;
  function decodeTopo() {
    const T = window.WORLD_TOPO;
    if (!T) return [];
    const [sx, sy] = T.transform?.scale || [1, 1];
    const [tx, ty] = T.transform?.translate || [0, 0];
    const arcs = T.arcs.map((arc) => { let x = 0, y = 0; return arc.map(([dx, dy]) => { x += dx; y += dy; return [x * sx + tx, y * sy + ty]; }); });
    const ring = (ids) => { const out = []; for (const i of ids) { const a = i < 0 ? arcs[~i].slice().reverse() : arcs[i]; out.push(...(out.length ? a.slice(1) : a)); } return out; };
    const polys = [];
    for (const g of T.objects.countries.geometries) {
      if (g.type === 'Polygon') polys.push(g.arcs.map(ring));
      else if (g.type === 'MultiPolygon') for (const p of g.arcs) polys.push(p.map(ring));
    }
    return polys;
  }

  /* ---------------------------------------------------------------- Projektion */
  const W = () => st.cv?.clientWidth || 800;
  const H = () => st.cv?.clientHeight || 500;
  const base = () => Math.min(W() / 360, H() / 170);
  function proj(lon, lat) {
    const s = base() * st.view.k;
    return [W() / 2 + (lon * s) + st.view.x, H() / 2 - (lat * s) + st.view.y];
  }
  function unproj(px, py) {
    const s = base() * st.view.k;
    return [(px - W() / 2 - st.view.x) / s, -(py - H() / 2 - st.view.y) / s];
  }

  /* ---------------------------------------------------------------- Daten */
  async function api(path) {
    let err;
    for (const host of API) {
      try { return await window.hub.tool.fetch(`https://${host}${path}`); } catch (e) { err = e; }
    }
    throw err || new Error('Radio-Dienst nicht erreichbar');
  }
  async function load() {
    if (st.loading || st.stations.length) return;
    st.loading = true;
    st.error = '';
    paintSide();
    try {
      const list = await api('/json/stations/search?has_geo_info=true&hidebroken=true&order=clickcount&reverse=true&limit=12000');
      st.stations = (list || []).filter((s) => Number.isFinite(s.geo_lat) && Number.isFinite(s.geo_long) && s.url_resolved).map((s) => ({
        id: s.stationuuid, name: String(s.name || '').trim() || 'Unbenannt', url: s.url_resolved, lat: s.geo_lat, lon: s.geo_long,
        country: s.country || '', cc: s.countrycode || '', state: s.state || '', tags: String(s.tags || '').split(',').filter(Boolean).slice(0, 4),
        icon: /^https:/.test(s.favicon || '') ? s.favicon : '', clicks: s.clickcount || 0, codec: s.codec || '', br: s.bitrate || 0,
      }));
      // Orte bündeln (gleiche Koordinaten ≈ gleiche Stadt)
      const map = new Map();
      for (const s of st.stations) {
        const key = `${s.lat.toFixed(1)}|${s.lon.toFixed(1)}`;
        let p = map.get(key);
        if (!p) { p = { lat: s.lat, lon: s.lon, list: [], name: s.state || s.country }; map.set(key, p); }
        p.list.push(s);
      }
      st.places = [...map.values()].sort((a, b) => a.list.length - b.list.length);
    } catch (e) {
      st.error = A.errText(e);
    }
    st.loading = false;
    paintSide();
    draw();
  }

  /* ---------------------------------------------------------------- Zeichnen */
  /** 2.46 Karte bleibt im Bild: nicht über die Ränder hinaus ziehen oder herauszoomen. */
  function clampView() {
    const s = base() * st.view.k;
    const w = W(), h = H();
    const halfW = 180 * s, top = 84 * s, bottom = 60 * s;
    st.view.k = Math.max(1, Math.min(60, st.view.k));
    // waagrecht: Karte breiter als Fenster → Ränder dürfen nicht hereinrutschen, sonst mittig
    st.view.x = halfW * 2 <= w ? 0 : Math.max(w / 2 - halfW, Math.min(halfW - w / 2, st.view.x));
    // senkrecht: genauso, Karte reicht von 84° N bis 60° S
    const mapH = top + bottom;
    if (mapH <= h) st.view.y = (top - bottom) / 2;
    else st.view.y = Math.max(h / 2 - bottom, Math.min(top - h / 2, st.view.y));
  }

  function draw() {
    clampView();
    if (st.raf) return;
    st.raf = requestAnimationFrame(() => {
      st.raf = 0;
      const cv = st.cv;
      if (!cv || !cv.isConnected) return;
      const dpr = window.devicePixelRatio || 1;
      const w = W(), h = H();
      if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
      const g = cv.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, w, h);
      // Land
      if (!land) land = decodeTopo();
      g.beginPath();
      for (const poly of land) for (const r of poly) {
        // über die Datumsgrenze (±180°) nicht quer über die Karte zeichnen
        let prev = null;
        r.forEach(([lon, lat], i) => { const [x, y] = proj(lon, lat); if (i && Math.abs(lon - prev) < 180) g.lineTo(x, y); else g.moveTo(x, y); prev = lon; });
        g.closePath();
      }
      g.fillStyle = 'rgba(255,255,255,0.055)';
      g.fill('evenodd');
      g.strokeStyle = 'rgba(255,255,255,0.09)';
      g.lineWidth = 0.7;
      g.stroke();
      // Punkte
      const k = st.view.k;
      const r0 = Math.max(1.1, Math.min(3.2, 0.9 + k * 0.35));
      for (const p of st.places) {
        const [x, y] = proj(p.lon, p.lat);
        if (x < -10 || y < -10 || x > w + 10 || y > h + 10) continue;
        const n = p.list.length;
        const r = r0 + Math.min(3.5, Math.log2(n) * 0.55);
        const on = st.sel === p, hov = st.hover === p, play = st.playing && p.list.includes(st.playing);
        g.beginPath();
        g.arc(x, y, on || hov ? r + 2 : r, 0, Math.PI * 2);
        g.fillStyle = play ? '#ff453a' : on ? '#ffffff' : `rgba(48, 209, 88, ${hov ? 1 : 0.85})`;
        g.shadowColor = play ? 'rgba(255,69,58,.9)' : 'rgba(48,209,88,.7)';
        g.shadowBlur = on || hov || play ? 14 : 5;
        g.fill();
      }
      g.shadowBlur = 0;
      // Puls um den laufenden Sender
      if (st.playing) {
        const [x, y] = proj(st.playing.lon, st.playing.lat);
        const t = (performance.now() % 1600) / 1600;
        g.beginPath();
        g.arc(x, y, 6 + t * 22, 0, Math.PI * 2);
        g.strokeStyle = `rgba(255,69,58,${0.7 * (1 - t)})`;
        g.lineWidth = 2;
        g.stroke();
        if (st.state === 'playing') draw();
      }
      // Fadenkreuz in der Mitte (wie beim Durchsuchen)
      g.strokeStyle = 'rgba(255,255,255,.35)';
      g.lineWidth = 1;
      g.beginPath(); g.arc(w / 2, h / 2, 16, 0, Math.PI * 2); g.stroke();
    });
  }
  function nearest(px, py, maxD = 14) {
    let best = null, bd = maxD;
    for (const p of st.places) {
      const [x, y] = proj(p.lon, p.lat);
      const d = Math.hypot(x - px, y - py);
      if (d < bd) { bd = d; best = p; }
    }
    return best;
  }
  function flyTo(lat, lon, k = Math.max(st.view.k, 4)) {
    const from = { ...st.view };
    const s = base() * k;
    const to = { k, x: -lon * s, y: lat * s };
    const t0 = performance.now();
    const step = (now) => {
      const t = Math.min(1, (now - t0) / 650);
      const e = 1 - (1 - t) ** 3;
      st.view = { k: from.k + (to.k - from.k) * e, x: from.x + (to.x - from.x) * e, y: from.y + (to.y - from.y) * e };
      draw();
      if (t < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  /* ---------------------------------------------------------------- Abspielen */
  function audio() {
    if (!st.audio) {
      st.audio = new Audio();
      st.audio.preload = 'none';
      st.audio.volume = st.vol;
      st.audio.addEventListener('playing', () => { st.state = 'playing'; paintNow(); draw(); });
      st.audio.addEventListener('waiting', () => { st.state = 'loading'; paintNow(); });
      st.audio.addEventListener('pause', () => { if (st.state !== 'error') st.state = 'paused'; paintNow(); });
      st.audio.addEventListener('error', () => { st.state = 'error'; paintNow(); A.toast('Dieser Sender sendet gerade nicht – nimm einen anderen.', 'error'); });
    }
    return st.audio;
  }
  function play(s) {
    const a = audio();
    st.playing = s;
    st.state = 'loading';
    a.src = s.url;
    a.play().catch(() => {});
    // Zählt den Klick bei radio-browser (so findet die Community gute Sender)
    api(`/json/url/${encodeURIComponent(s.id)}`).catch(() => {});
    try { localStorage.setItem('rv-radio-last', JSON.stringify(s)); } catch { /* egal */ }
    paintNow();
    paintSide();
    draw();
  }
  function toggle() {
    const a = audio();
    if (!st.playing) return;
    if (a.paused) { st.state = 'loading'; a.src = st.playing.url; a.play().catch(() => {}); } else { a.pause(); a.removeAttribute('src'); a.load(); st.state = 'paused'; }
    paintNow();
  }
  const isFav = (s) => st.fav.some((f) => f.id === s?.id);
  function toggleFav(s) {
    st.fav = isFav(s) ? st.fav.filter((f) => f.id !== s.id) : [s, ...st.fav].slice(0, 60);
    A.store.set('radio-fav', st.fav);
    paintNow();
    paintSide();
  }

  /* ---------------------------------------------------------------- Oberfläche */
  const icon = (n, s = 16) => window.icon?.(n, s) || '';
  function stationRow(s) {
    const on = st.playing?.id === s.id;
    return `<button class="rd-st ${on ? 'on' : ''}" data-rd-play="${esc(s.id)}">
      <span class="rd-ic">${s.icon ? `<img src="${esc(s.icon)}" alt="" loading="lazy" referrerpolicy="no-referrer"/>` : ''}<b>${esc(s.name.slice(0, 1).toUpperCase())}</b></span>
      <span class="rd-tx"><b>${esc(s.name)}</b><small>${esc([s.state || s.country, s.tags.slice(0, 2).join(' · ')].filter(Boolean).join(' · '))}</small></span>
      ${on ? `<span class="rd-eq ${st.state === 'playing' ? 'run' : ''}"><i></i><i></i><i></i></span>` : ''}
    </button>`;
  }
  function sideList() {
    if (st.loading) return '<div class="rd-note"><span class="rd-spin"></span>Sender der Welt werden geladen …</div>';
    if (st.error) return `<div class="rd-note err">${esc(st.error)}<button class="rv-btn sm" data-rd-retry>Nochmal</button></div>`;
    const q = st.q.trim().toLowerCase();
    if (q) {
      const hits = st.stations.filter((s) => `${s.name} ${s.country} ${s.state} ${s.tags.join(' ')}`.toLowerCase().includes(q)).slice(0, 80);
      return hits.length ? `<div class="rd-h">${hits.length >= 80 ? '80+' : hits.length} Treffer</div>${hits.map(stationRow).join('')}` : '<div class="rd-note">Kein Sender gefunden.</div>';
    }
    if (st.tab === 'fav') return st.fav.length ? st.fav.map(stationRow).join('') : '<div class="rd-note">Noch keine Favoriten – beim laufenden Sender auf ♥ tippen.</div>';
    if (st.sel) return `<div class="rd-h">${esc(st.sel.name || 'Hier')} · ${st.sel.list.length} ${st.sel.list.length === 1 ? 'Sender' : 'Sender'}</div>${st.sel.list.slice().sort((a, b) => b.clicks - a.clicks).map(stationRow).join('')}`;
    const top = st.stations.slice(0, 40);
    return `<div class="rd-h">Beliebt weltweit</div>${top.map(stationRow).join('')}`;
  }
  function paintSide() {
    const el = st.root?.querySelector('.rd-list');
    if (el) el.innerHTML = sideList();
    const c = st.root?.querySelector('.rd-count');
    if (c) c.textContent = st.stations.length ? `${st.stations.length.toLocaleString('de-DE')} Sender · ${st.places.length.toLocaleString('de-DE')} Orte` : '';
    st.root?.querySelectorAll('[data-rd-tab]').forEach((b) => b.classList.toggle('on', b.dataset.rdTab === st.tab && !st.q));
  }
  function paintNow() {
    const el = st.root?.querySelector('.rd-now');
    if (!el) return;
    const s = st.playing;
    el.classList.toggle('show', Boolean(s));
    if (!s) return;
    el.innerHTML = `<span class="rd-ic big">${s.icon ? `<img src="${esc(s.icon)}" alt="" referrerpolicy="no-referrer"/>` : ''}<b>${esc(s.name.slice(0, 1).toUpperCase())}</b></span>
      <div class="rd-now-tx"><b>${esc(s.name)}</b><small>${esc([s.state, s.country].filter(Boolean).join(', '))}${s.br ? ` · ${s.br} kbit/s` : ''}</small>
        <span class="rd-live ${st.state}">${st.state === 'playing' ? '● LIVE' : st.state === 'loading' ? 'Verbinde …' : st.state === 'error' ? 'Offline' : 'Pausiert'}</span></div>
      <button class="rd-btn" data-rd-fav title="Favorit">${isFav(s) ? '♥' : '♡'}</button>
      <button class="rd-btn main" data-rd-toggle title="Play/Pause">${icon(st.state === 'playing' || st.state === 'loading' ? 'pause' : 'play', 18)}</button>
      <input class="rd-vol" type="range" min="0" max="1" step="0.02" value="${st.vol}" data-rd-vol title="Lautstärke" />`;
  }
  function tip(p, x, y) {
    const t = st.root?.querySelector('.rd-tip');
    if (!t) return;
    if (!p) { t.hidden = true; return; }
    t.hidden = false;
    t.innerHTML = `<b>${esc(p.list[0].state || p.list[0].country || 'Sender')}</b><small>${p.list.length} ${p.list.length === 1 ? 'Sender' : 'Sender'} · ${esc(p.list[0].name)}${p.list.length > 1 ? ' …' : ''}</small>`;
    t.style.left = `${x + 14}px`;
    t.style.top = `${y + 14}px`;
  }

  function mount(root) {
    st.root = root;
    root.innerHTML = `<div class="rd">
      <div class="rd-map"><canvas class="rd-cv"></canvas><div class="rd-tip" hidden></div>
        <div class="rd-zoom"><button data-rd-zoom="1" title="Hineinzoomen">+</button><button data-rd-zoom="-1" title="Herauszoomen">−</button><button data-rd-zoom="0" title="Ganze Welt">⌂</button></div>
        <div class="rd-now"></div></div>
      <aside class="rd-side">
        <div class="rd-head"><div><b>Radio</b><span class="rd-count"></span></div><button class="rv-btn sm ghost" data-rd-random title="Zufälliger Sender">🎲 Zufall</button></div>
        <label class="rd-search">${icon('search', 14)}<input type="search" placeholder="Sender, Land, Stadt oder Genre …" data-rd-q value="${esc(st.q)}" autocomplete="off" spellcheck="false" /></label>
        <div class="rd-tabs"><button data-rd-tab="here">Entdecken</button><button data-rd-tab="fav">♥ Favoriten</button></div>
        <div class="rd-list"></div>
      </aside>
    </div>`;
    st.cv = root.querySelector('.rd-cv');
    const cv = st.cv;
    cv.addEventListener('pointerdown', (e) => { cv.setPointerCapture(e.pointerId); st.drag = { x: e.clientX, y: e.clientY, vx: st.view.x, vy: st.view.y, moved: false }; });
    cv.addEventListener('pointermove', (e) => {
      const r = cv.getBoundingClientRect();
      if (st.drag) {
        const dx = e.clientX - st.drag.x, dy = e.clientY - st.drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 3) st.drag.moved = true;
        st.view.x = st.drag.vx + dx;
        st.view.y = st.drag.vy + dy;
        cv.style.cursor = 'grabbing';
        tip(null);
        return draw();
      }
      const p = nearest(e.clientX - r.left, e.clientY - r.top);
      if (p !== st.hover) { st.hover = p; draw(); }
      cv.style.cursor = p ? 'pointer' : 'grab';
      tip(p, e.clientX - r.left, e.clientY - r.top);
    });
    cv.addEventListener('pointerup', (e) => {
      const d = st.drag;
      st.drag = null;
      cv.style.cursor = 'grab';
      if (d?.moved) return;
      const r = cv.getBoundingClientRect();
      const p = nearest(e.clientX - r.left, e.clientY - r.top, 18);
      st.sel = p;
      st.tab = 'here';
      if (p) { if (p.list.length === 1 || !st.playing) play(p.list.slice().sort((a, b) => b.clicks - a.clicks)[0]); flyTo(p.lat, p.lon, Math.max(st.view.k, 3)); }
      paintSide();
      draw();
    });
    cv.addEventListener('pointerleave', () => { st.hover = null; tip(null); draw(); });
    cv.addEventListener('wheel', (e) => {
      e.preventDefault();
      const r = cv.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      const [lon, lat] = unproj(mx, my);
      st.view.k = Math.max(1, Math.min(60, st.view.k * Math.exp(-e.deltaY * 0.0015)));
      const [x, y] = proj(lon, lat);
      st.view.x += mx - x;
      st.view.y += my - y;
      draw();
    }, { passive: false });
    if (!st.ro) { st.ro = new ResizeObserver(() => draw()); }
    st.ro.observe(cv);
    A.store.get('radio-fav', []).then((f) => { st.fav = Array.isArray(f) ? f : []; paintSide(); });
    if (!st.playing) { try { const last = JSON.parse(localStorage.getItem('rv-radio-last') || 'null'); if (last?.url) st.playing = last; st.state = 'paused'; } catch { /* egal */ } }
    paintSide();
    paintNow();
    draw();
    load();
  }

  document.addEventListener('click', (e) => {
    if (!st.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const pid = q('[data-rd-play]')?.dataset.rdPlay;
    if (pid) {
      const s = st.stations.find((x) => x.id === pid) || st.fav.find((x) => x.id === pid);
      if (s) { play(s); flyTo(s.lat, s.lon, Math.max(st.view.k, 4)); }
      return;
    }
    if (q('[data-rd-toggle]')) return toggle();
    if (q('[data-rd-fav]')) return toggleFav(st.playing);
    if (q('[data-rd-retry]')) return load();
    const tab = q('[data-rd-tab]')?.dataset.rdTab;
    if (tab) { st.tab = tab; st.q = ''; const i = st.root.querySelector('[data-rd-q]'); if (i) i.value = ''; return paintSide(); }
    if (q('[data-rd-random]') && st.stations.length) {
      const s = st.stations[Math.floor(Math.random() * Math.min(st.stations.length, 3000))];
      st.sel = st.places.find((p) => p.list.includes(s)) || null;
      play(s);
      flyTo(s.lat, s.lon, 5);
      return;
    }
    const z = q('[data-rd-zoom]')?.dataset.rdZoom;
    if (z != null) {
      if (z === '0') { st.view = { x: 0, y: 0, k: 1 }; st.sel = null; paintSide(); return draw(); }
      st.view.k = Math.max(1, Math.min(60, st.view.k * (z === '1' ? 1.6 : 1 / 1.6)));
      draw();
    }
  });
  document.addEventListener('input', (e) => {
    if (!st.root?.contains(e.target)) return;
    if (e.target.matches('[data-rd-q]')) { st.q = e.target.value; return paintSide(); }
    if (e.target.matches('[data-rd-vol]')) { st.vol = Number(e.target.value); if (st.audio) st.audio.volume = st.vol; }
  });

  A.define(ID, { nav: 'Radio', title: 'Radio', sub: 'Alle Sender der Welt', icon: 'globe', tint: 'linear-gradient(135deg,#30d158,#0e7490)', desc: 'Tausende Radiosender aus aller Welt als Punkte auf der Weltkarte – Punkt antippen und reinhören. Mit Suche, Favoriten und Zufall.' }, {
    mount,
    unmount() { st.ro?.disconnect(); },
    wide: true,
    game: true,
  });
})();
// Senderlogos, die nicht laden, ausblenden (inline onerror verbietet die CSP)
document.addEventListener('error', (e) => { if (e.target?.closest?.('.rd-ic')) e.target.remove(); }, true);
