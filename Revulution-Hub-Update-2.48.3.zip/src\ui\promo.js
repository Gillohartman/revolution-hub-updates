'use strict';
/*
 * 2.48.3 Rabattaktionen: Das Admin-Programm legt promo.json in den öffentlichen Bibliotheks-Speicher (R2).
 * Jeder Hub liest sie (alle 10 min) und zeigt die Aktion an: Werbebanner auf der Startseite und im Store,
 * durchgestrichene Preise bei Pro/Max/Coins.
 *   { active, title, text, percent, targets: ['pro','max','coins'], until, color, home }
 */
(() => {
  const URL_ = 'https://pub-7ec1cfdd23eb4d88ac17e63a5bfd016a.r2.dev/promo.json';
  const COLORS = { red: ['#ff375f', '#ff9f0a'], purple: ['#a855f7', '#6366f1'], gold: ['#ffd60a', '#ff9f0a'], blue: ['#0a84ff', '#22d3ee'], green: ['#30d158', '#22d3ee'] };
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  let data = null;
  let key = '';
  let hidden = '';
  try { hidden = localStorage.getItem('rev-promo-hidden') || ''; } catch { /* egal */ }

  async function load() {
    try {
      const j = await window.hub.promo();
      if (j === undefined) return; // offline
      const next = j && typeof j === 'object' ? j : null;
      const k = JSON.stringify(next);
      if (k !== key) {
        key = k;
        data = next;
        window.HubTools?.ctx?.()?.render?.();
      }
    } catch {
      /* offline: letzte Aktion behalten */
    }
  }
  const active = () => Boolean(data?.active && Number(data.percent) > 0 && (!data.until || Date.now() < Number(data.until)));
  const applies = (kind) => active() && (data.targets || []).includes(kind);
  const pct = () => Math.max(0, Math.min(90, Math.round(Number(data?.percent) || 0)));
  const fmt = (n) => (Math.round(n * 100) % 100 === 0 ? `${Math.round(n)}.–` : n.toFixed(2));
  function left() {
    if (!data?.until) return '';
    const ms = Number(data.until) - Date.now();
    if (ms <= 0) return '';
    const d = Math.floor(ms / 864e5), h = Math.floor((ms % 864e5) / 36e5), m = Math.floor((ms % 36e5) / 6e4);
    return d ? `noch ${d} T ${h} Std` : h ? `noch ${h} Std ${m} Min` : `noch ${m} Min`;
  }
  const grad = () => { const [a, b] = COLORS[data?.color] || COLORS.red; return `linear-gradient(120deg, ${a}, ${b})`; };

  /** Preis mit Rabatt: „CHF 2.90“ → „<s>CHF 2.90</s> CHF 2.32“ */
  function price(chf, kind) {
    if (!applies(kind)) return `CHF ${fmt(chf)}`;
    const now = Math.round(chf * (100 - pct())) / 100;
    return `<s class="pr-old">CHF ${fmt(chf)}</s> CHF ${fmt(now)}`;
  }
  const badge = (kind) => (applies(kind) ? `<span class="pr-badge" style="background:${grad()}">−${pct()} %</span>` : '');

  function banner(where = 'home') {
    if (!active()) return '';
    if (where === 'home' && (data.home === false || hidden === key)) return '';
    const t = left();
    return `<div class="pr-banner ${where}" style="--pr:${grad()}">
      <div class="pr-glow"></div>
      <div class="pr-pct">−${pct()}<small>%</small></div>
      <div class="pr-txt"><b>${esc(data.title || 'Rabattaktion')}</b><span>${esc(data.text || '')}</span>${t ? `<em data-pr-left>${esc(t)}</em>` : ''}</div>
      ${where === 'home' ? `<button class="pr-go" data-open="tool-store">Zum Shop</button><button class="pr-x" data-pr-hide title="Ausblenden">✕</button>` : ''}
    </div>`;
  }

  document.addEventListener('click', (e) => {
    if (!e.target.closest?.('[data-pr-hide]')) return;
    hidden = key;
    try { localStorage.setItem('rev-promo-hidden', key); } catch { /* egal */ }
    window.HubTools?.ctx?.()?.render?.();
  });
  // Countdown frisch halten, ohne alles neu zu zeichnen
  setInterval(() => { const t = left(); document.querySelectorAll('[data-pr-left]').forEach((el) => { el.textContent = t; }); }, 30000);

  // _show: nur für Tests (Aktion lokal anzeigen, ohne sie zu veröffentlichen)
  window.RevPromo = { load, active, applies, price, badge, banner, percent: pct, get data() { return data; }, _show: (j) => { data = j; key = JSON.stringify(j); window.HubTools?.ctx?.()?.render?.(); } };
  load();
  setInterval(load, 10 * 60000);
})();
