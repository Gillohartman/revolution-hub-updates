'use strict';

/*
 * 2.47 Live-Desktop: ein Video-Fenster pro Monitor, das HINTER den Desktop-Symbolen liegt.
 *
 * Windows 11 24H2 hat die Desktop-Ebenen umgebaut: „Progman“ enthält jetzt selbst die Symbole
 * (SHELLDLL_DefView) und darunter eine WorkerW-Ebene mit dem Standbild. Unser Fenster wird
 * als Kind von Progman genau zwischen diese beiden gesetzt. Ältere Windows-Versionen: klassisch
 * über die abgespaltene WorkerW-Ebene (Nachricht 0x052C an Progman).
 */
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { pathToFileURL } = require('url');

const HELPER = String.raw`
Add-Type @"
using System; using System.Text; using System.Runtime.InteropServices;
public static class RevLiveDesk {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern IntPtr FindWindowW(string c, string n);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern IntPtr FindWindowExW(IntPtr p, IntPtr a, string c, string n);
  [DllImport("user32.dll")] static extern IntPtr SetParent(IntPtr c, IntPtr p);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int w, int hh, uint f);
  [DllImport("user32.dll")] static extern IntPtr GetWindowLongPtrW(IntPtr h, int i);
  [DllImport("user32.dll")] static extern IntPtr SetWindowLongPtrW(IntPtr h, int i, IntPtr v);
  [DllImport("user32.dll")] static extern bool SetLayeredWindowAttributes(IntPtr h, uint k, byte a, uint f);
  [DllImport("user32.dll")] static extern IntPtr SendMessageTimeoutW(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);
  [DllImport("user32.dll")] static extern bool MapWindowPoints(IntPtr from, IntPtr to, ref PT p, uint n);
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
  [StructLayout(LayoutKind.Sequential)] struct PT { public int X, Y; }
  public static string Attach(IntPtr win, int x, int y, int w, int h) {
    IntPtr old = SetThreadDpiAwarenessContext(new IntPtr(-4)); // Pixel, nicht skaliert
    try {
      IntPtr pm = FindWindowW("Progman", null); IntPtr r;
      SendMessageTimeoutW(pm, 0x052C, IntPtr.Zero, IntPtr.Zero, 0, 1000, out r);
      IntPtr defInProgman = FindWindowExW(pm, IntPtr.Zero, "SHELLDLL_DefView", null);
      IntPtr parent; IntPtr after;
      if (defInProgman != IntPtr.Zero) {
        // 24H2: Kind von Progman, direkt unter den Symbolen
        parent = pm; after = defInProgman;
        long ex = (long)GetWindowLongPtrW(win, -20);
        SetWindowLongPtrW(win, -20, new IntPtr(ex | 0x80000));
        SetLayeredWindowAttributes(win, 0, 255, 2);
      } else {
        // klassisch: die WorkerW-Ebene hinter dem Fenster mit den Symbolen
        IntPtr worker = IntPtr.Zero, cur = IntPtr.Zero;
        while ((cur = FindWindowExW(IntPtr.Zero, cur, "WorkerW", null)) != IntPtr.Zero) {
          if (FindWindowExW(cur, IntPtr.Zero, "SHELLDLL_DefView", null) != IntPtr.Zero) { worker = FindWindowExW(IntPtr.Zero, cur, "WorkerW", null); break; }
        }
        parent = worker != IntPtr.Zero ? worker : pm; after = new IntPtr(1);
      }
      long st = (long)GetWindowLongPtrW(win, -16);
      SetWindowLongPtrW(win, -16, new IntPtr((st | 0x40000000L) & ~0x80000000L & ~0x00C00000L & ~0x00040000L));
      SetParent(win, parent);
      // Bildschirm-Koordinaten in Koordinaten des Elternfensters umrechnen
      PT p = new PT { X = x, Y = y }; MapWindowPoints(IntPtr.Zero, parent, ref p, 1);
      SetWindowPos(win, after, p.X, p.Y, w, h, 0x0010 | 0x0040);
      return "ok parent=" + parent + " mode=" + (defInProgman != IntPtr.Zero ? "24h2" : "classic") + " at=" + p.X + "," + p.Y;
    } finally { SetThreadDpiAwarenessContext(old); }
  }
}
"@
`;

class LiveDesktop {
  constructor(electron) {
    this.electron = electron;
    this.windows = [];
    this.file = '';
    this.paused = false;
    this.layout = {};
    // 2.47.6 Wächter: fehlt ein Fenster (z. B. Explorer neu gestartet), wird der Live-Desktop neu aufgebaut
    this.guard = setInterval(() => {
      if (!this.file || this.busy) return;
      if (this.windows.some((w) => w.isDestroyed() || w.webContents.isCrashed())) {
        this.busy = true;
        const file = this.file;
        this.stop();
        this.set(file, this.layout).catch(() => {}).finally(() => { this.busy = false; });
      }
    }, 15000);
  }

  /**
   * Video abspielen (leerer Pfad = aus).
   * layout: { mode: 'all' | 'span' | 'select', rects?: [{x,y,w,h}] } – rects = gewählte Monitore in physischen Pixeln.
   * 'span' = ein Video über alle Monitore gestreckt (jeder Monitor zeigt seinen Ausschnitt).
   */
  async set(file, layout = {}) {
    this.layout = layout || {};
    const next = file && fs.existsSync(file) ? file : '';
    const { screen } = this.electron;
    const mode = ['span', 'select'].includes(layout.mode) ? layout.mode : 'all';
    const phys = (d) => (screen.dipToScreenRect ? screen.dipToScreenRect(null, d.bounds) : { x: Math.round(d.bounds.x * d.scaleFactor), y: Math.round(d.bounds.y * d.scaleFactor), width: Math.round(d.bounds.width * d.scaleFactor), height: Math.round(d.bounds.height * d.scaleFactor) });
    const near = (r, m) => Math.abs(r.x - m.x) < 8 && Math.abs(r.y - m.y) < 8;
    let displays = screen.getAllDisplays();
    if (mode === 'select' && Array.isArray(layout.rects) && layout.rects.length) {
      const pick = displays.filter((d) => layout.rects.some((m) => near(phys(d), m)));
      if (pick.length) displays = pick;
    }
    const all = displays.map(phys);
    const ux = Math.min(...all.map((r) => r.x));
    const uy = Math.min(...all.map((r) => r.y));
    const union = { x: ux, y: uy, w: Math.max(...all.map((r) => r.x + r.width)) - ux, h: Math.max(...all.map((r) => r.y + r.height)) - uy };
    const key = `${mode}|${all.map((r) => `${r.x},${r.y},${r.width},${r.height}`).join(';')}`;
    // 2.47.2: läuft schon ein Live-Desktop mit derselben Aufteilung → nur weich überblenden statt neu aufbauen
    const live = this.windows.filter((w) => !w.isDestroyed());
    if (next && live.length && this.layoutKey === key && live.length === displays.length) {
      const src = pathToFileURL(next).href;
      const ok = await Promise.all(live.map((w) => w.webContents.executeJavaScript(`window.__swap(${JSON.stringify(src)})`).catch(() => false)));
      if (ok.every(Boolean)) {
        this.file = next;
        this.paused = false;
        return ok.map(() => 'ok swap');
      }
    }
    this.stop();
    this.file = next;
    this.layoutKey = key;
    if (!this.file) return false;
    const { BrowserWindow } = this.electron;
    const src = pathToFileURL(this.file).href;
    const results = [];
    for (const d of displays) {
      const b = d.bounds;
      const me = phys(d);
      const query = { src };
      if (mode === 'span' && displays.length > 1) query.span = [union.x - me.x, union.y - me.y, union.w, union.h, me.width, me.height].join(',');
      const win = new BrowserWindow({
        x: b.x, y: b.y, width: b.width, height: b.height, show: false, frame: false, skipTaskbar: true, focusable: false,
        resizable: false, movable: false, minimizable: false, maximizable: false, fullscreenable: false, hasShadow: false,
        backgroundColor: '#000000', title: 'Revulution Live Desktop',
        webPreferences: { backgroundThrottling: false, contextIsolation: true, sandbox: true },
      });
      win.setIgnoreMouseEvents(true);
      // als echte Datei laden – eine data:-Seite darf keine lokalen Videos abspielen
      await win.loadFile(path.join(__dirname, '..', 'ui', 'live-desktop.html'), { query });
      win.showInactive();
      const hwnd = win.getNativeWindowHandle();
      const id = hwnd.length >= 8 ? hwnd.readBigUInt64LE(0) : BigInt(hwnd.readUInt32LE(0));
      // physische Pixel (die Win32-Funktionen arbeiten ohne Skalierung)
      results.push(await this.attach(id, me));
      this.windows.push(win);
    }
    this.paused = false;
    return results;
  }

  attach(hwnd, r) {
    const script = `${HELPER}\n[RevLiveDesk]::Attach([IntPtr]${hwnd.toString()}, ${r.x}, ${r.y}, ${r.width}, ${r.height})`;
    return new Promise((resolve) => {
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout: 20000 }, (error, stdout, stderr) => resolve(error ? `fehler: ${String(stderr || error.message).slice(0, 300)}` : String(stdout).trim()));
    });
  }

  pause(on) {
    this.paused = Boolean(on);
    for (const w of this.windows) if (!w.isDestroyed()) w.webContents.executeJavaScript(`window.__pause(${on ? 'true' : 'false'})`).catch(() => {});
  }

  stop() {
    for (const w of this.windows) if (!w.isDestroyed()) w.destroy();
    this.windows = [];
    this.file = '';
    this.layoutKey = '';
  }
}

module.exports = { LiveDesktop };
