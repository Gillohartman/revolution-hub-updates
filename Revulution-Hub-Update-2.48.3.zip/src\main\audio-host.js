'use strict';
/**
 * Startet die Audio-Engine (unsichtbares Fenster src/ui/audio-engine.html) und reicht Befehle durch (2.45.8):
 * Soundboard-Sound abspielen (Widget + Stream Deck), alles stoppen, stummschalten, Mikrofon-Mix einstellen.
 * Die Seite hat keinen Node-Zugriff; sie bekommt die Sounds als Data-URL. Mikrofon-Zugriff nur für diese Seite.
 */
const path = require('path');
const { BrowserWindow, session } = require('electron');

class AudioHost {
  constructor({ soundData, onState }) {
    this.soundData = soundData; // (pad) => { data, ver }
    this.onState = onState;
    this.win = null;
    this.ready = null;
    this.muted = false;
    this.mix = null;
  }

  ensure() {
    if (this.win && !this.win.isDestroyed()) return this.ready;
    const ses = session.fromPartition('rev-audio-engine');
    // Nur Audio/Mikrofon erlauben – sonst nichts
    ses.setPermissionRequestHandler((_wc, perm, cb, details) => cb(perm === 'media' && !(details?.mediaTypes || []).includes('video')));
    ses.setPermissionCheckHandler((_wc, perm) => perm === 'media' || perm === 'speaker-selection');
    ses.setDevicePermissionHandler?.(() => false);
    this.win = new BrowserWindow({
      show: false, width: 200, height: 100, skipTaskbar: true,
      webPreferences: { partition: 'rev-audio-engine', contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' },
    });
    this.win.webContents.on('will-navigate', (e) => e.preventDefault());
    this.win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    this.win.on('closed', () => { this.win = null; this.ready = null; });
    // 2.45.8: Sounds warten nicht mehr auf den Mikrofon-Mix – hing der (Mikrofon/Ausgabe nicht bereit),
    // blieb früher jeder Sound stumm, bis der Hub neu gestartet wurde.
    this.ready = this.win.loadFile(path.join(__dirname, '..', 'ui', 'audio-engine.html')).then(() => {
      if (this.muted) this.exec('mute', true).catch(() => {});
      if (this.mix?.on) this.exec('config', this.mix).catch(() => {});
      return true;
    });
    return this.ready;
  }

  exec(fn, arg, timeout = 8000) {
    const job = this.win.webContents.executeJavaScript(`window.__engine.${fn}(${arg === undefined ? '' : JSON.stringify(arg)})`, true);
    return Promise.race([job, new Promise((_, reject) => setTimeout(() => reject(new Error('Audio-Engine antwortet nicht.')), timeout))]);
  }

  async run(fn, arg) {
    await this.ensure();
    return this.exec(fn, arg);
  }

  async play(pad, volume = 1) {
    const i = Math.max(0, Math.min(23, Number(pad) || 0));
    const { data, ver } = this.soundData(i);
    const vol = Math.max(0, Math.min(1.5, Number(volume ?? 1)));
    // 2.48.3: Datei nur schicken, wenn die Engine sie noch nicht hat – sonst wurden bei JEDEM Druck
    // mehrere MB übertragen (spürbare Verzögerung bis zum Sound)
    if (data) {
      const r = await this.run('play', { pad: i, volume: vol, ver, custom: true });
      if (!r?.need) return r;
    }
    return this.run('play', { pad: i, volume: vol, data, ver });
  }

  stop() { return this.win ? this.run('stop') : true; }

  async setMuted(on) {
    this.muted = Boolean(on);
    const s = this.win || this.mix?.on ? await this.run('mute', this.muted) : { muted: this.muted };
    this.onState?.(await this.status());
    return s;
  }

  async configure(mix) {
    this.mix = mix;
    if (!mix?.on && !this.win) return this.status();
    await this.run('config', mix);
    const s = await this.status();
    this.onState?.(s);
    return s;
  }

  devices() { return this.run('devices'); }

  async status() {
    if (!this.win) return { muted: this.muted, mix: this.mix || { on: false }, active: false, level: 0 };
    return this.run('status');
  }

  destroy() { if (this.win && !this.win.isDestroyed()) this.win.destroy(); this.win = null; }
}

module.exports = { AudioHost };
