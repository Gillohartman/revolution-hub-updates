'use strict';

/*
 * Augenmaß (2.47): Schätz-Spiel mit 40 Modi. Die Aufgabe blitzt nur kurz auf (keine Zeit zum Zählen
 * oder Messen), danach schätzt man aus dem Gedächtnis: Punkte zählen, Winkel, Füllstände, Längen,
 * Positionen, Farben, Zeitgefühl … 10 Runden pro Spiel, bis zu 100 Punkte pro Runde.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-eyeball';
  const ROUNDS = 10;
  const TAU = Math.PI * 2;

  /* ------------------------------------------------------------------ Zeichen-Helfer */
  const COLORS = ['#ff453a', '#0a84ff', '#30d158', '#ffd60a', '#bf5af2', '#ff9f0a', '#64d2ff'];
  const R = (rnd, a, b) => a + rnd() * (b - a);
  const RI = (rnd, a, b) => Math.floor(R(rnd, a, b + 1));
  const pick = (rnd, arr) => arr[Math.floor(rnd() * arr.length)];
  /** n Punkte ohne Überlappung im Feld verteilen */
  function scatter(rnd, n, w, h, r, pad = 24) {
    const pts = [];
    let guard = 0;
    while (pts.length < n && guard++ < n * 400) {
      const p = { x: R(rnd, pad + r, w - pad - r), y: R(rnd, pad + r, h - pad - r) };
      if (pts.every((q) => (q.x - p.x) ** 2 + (q.y - p.y) ** 2 > (r * 2.3) ** 2)) pts.push(p);
    }
    return pts;
  }
  const dot = (c, x, y, r, col = '#fff') => { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); };
  const line = (c, x1, y1, x2, y2, col = '#fff', w = 5) => { c.strokeStyle = col; c.lineWidth = w; c.lineCap = 'round'; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke(); };
  function polygon(c, x, y, r, sides, rot, col) {
    c.fillStyle = col;
    c.beginPath();
    for (let i = 0; i < sides; i++) {
      const a = rot + (i / sides) * TAU;
      c[i ? 'lineTo' : 'moveTo'](x + Math.cos(a) * r, y + Math.sin(a) * r);
    }
    c.closePath();
    c.fill();
  }
  function star(c, x, y, r, col) {
    c.fillStyle = col;
    c.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i / 10) * TAU;
      const rr = i % 2 ? r * 0.45 : r;
      c[i ? 'lineTo' : 'moveTo'](x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    c.closePath();
    c.fill();
  }
  const hsl = (h, s, l) => `hsl(${h} ${s}% ${l}%)`;

  /* ------------------------------------------------------------------ Bewertung */
  const relScore = (g, a, k = 1.6) => Math.max(0, Math.round(100 - (Math.abs(g - a) / Math.max(1e-9, Math.abs(a))) * 100 * k));
  const absScore = (g, a, per) => Math.max(0, Math.round(100 - Math.abs(g - a) * per));
  const angDiff = (a, b, period = 360) => { const d = Math.abs(((a - b) % period) + period) % period; return Math.min(d, period - d); };

  /*
   * Ein Modus: { id, name, cat, icon, hint, input, flash, gen(rnd, w, h) → round }
   * round: { draw(c, w, h), answer, unit?, min?, max?, score(guess) }
   * input: 'number' | 'angle' | 'percent' | 'click' | 'hue' | 'gray' | 'timing'
   */
  const M = [];
  const mode = (o) => M.push(o);

  // ---- Zählen
  const countMode = (id, name, icon, lo, hi, draw, hint) => mode({
    id, name, cat: 'Zählen', icon, hint, input: 'number', flash: 900,
    gen(rnd, w, h) {
      const n = RI(rnd, lo, hi);
      const data = draw.prep ? draw.prep(rnd, n, w, h) : scatter(rnd, n, w, h, 9);
      return { answer: n, draw: (c) => draw(c, data, rnd), score: (g) => relScore(g, n, 2.2) };
    },
  });
  countMode('dots', 'Punkte zählen', '⚪', 8, 45, (c, pts) => pts.forEach((p) => dot(c, p.x, p.y, 9)), 'Wie viele Punkte waren zu sehen?');
  countMode('dots-many', 'Sternenhimmel', '✨', 40, 140, Object.assign((c, pts) => pts.forEach((p) => dot(c, p.x, p.y, 3.2, '#fdfdfd')), { prep: (rnd, n, w, h) => scatter(rnd, n, w, h, 3.2, 10) }), 'Wie viele Sterne?');
  countMode('squares', 'Quadrate zählen', '⬛', 6, 35, Object.assign((c, pts) => pts.forEach((p) => { c.fillStyle = '#64d2ff'; c.fillRect(p.x - 10, p.y - 10, 20, 20); }), { prep: (rnd, n, w, h) => scatter(rnd, n, w, h, 13) }), 'Wie viele Quadrate?');
  countMode('stars', 'Sterne zählen', '⭐', 5, 30, Object.assign((c, pts) => pts.forEach((p) => star(c, p.x, p.y, 15, '#ffd60a')), { prep: (rnd, n, w, h) => scatter(rnd, n, w, h, 16) }), 'Wie viele Sterne?');
  countMode('triangles', 'Dreiecke zählen', '🔺', 5, 30, Object.assign((c, pts) => pts.forEach((p) => polygon(c, p.x, p.y, 14, 3, -Math.PI / 2 + p.x, '#ff9f0a')), { prep: (rnd, n, w, h) => scatter(rnd, n, w, h, 15) }), 'Wie viele Dreiecke?');
  countMode('lines', 'Striche zählen', '📏', 6, 30, Object.assign((c, pts) => pts.forEach((p) => line(c, p.x - Math.cos(p.a) * 16, p.y - Math.sin(p.a) * 16, p.x + Math.cos(p.a) * 16, p.y + Math.sin(p.a) * 16, '#bf5af2', 4)), { prep: (rnd, n, w, h) => scatter(rnd, n, w, h, 17).map((p) => ({ ...p, a: R(rnd, 0, Math.PI) })) }), 'Wie viele Striche?');
  mode({
    id: 'red-dots', name: 'Nur die roten', cat: 'Zählen', icon: '🔴', hint: 'Wie viele ROTE Punkte?', input: 'number', flash: 1100,
    gen(rnd, w, h) {
      const red = RI(rnd, 5, 25);
      const other = RI(rnd, 10, 35);
      const pts = scatter(rnd, red + other, w, h, 9).map((p, i) => ({ ...p, col: i < red ? '#ff453a' : pick(rnd, COLORS.slice(1)) }));
      return { answer: red, draw: (c) => pts.forEach((p) => dot(c, p.x, p.y, 9, p.col)), score: (g) => relScore(g, red, 2.2) };
    },
  });
  mode({
    id: 'letters', name: 'Buchstaben-Suche', cat: 'Zählen', icon: '🔤', hint: 'Wie oft kam das große „A“ vor?', input: 'number', flash: 1500,
    gen(rnd, w, h) {
      const n = RI(rnd, 3, 16);
      const total = 70;
      const cells = Array.from({ length: total }, (_, i) => (i < n ? 'A' : pick(rnd, 'BCDEFGHKMNRSTVXZ'.split(''))));
      cells.sort(() => rnd() - 0.5);
      return {
        answer: n,
        draw(c) {
          c.font = '600 26px Segoe UI, sans-serif'; c.fillStyle = '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle';
          const cols = 14; const cw = (w - 60) / cols; const ch = (h - 60) / 5;
          cells.forEach((t, i) => c.fillText(t, 30 + cw * (i % cols) + cw / 2, 30 + ch * Math.floor(i / cols) + ch / 2));
        },
        score: (g) => relScore(g, n, 3),
      };
    },
  });
  mode({
    id: 'sum', name: 'Blitz-Summe', cat: 'Zählen', icon: '➕', hint: 'Wie groß war die Summe aller Zahlen?', input: 'number', flash: 1600,
    gen(rnd, w, h) {
      const nums = Array.from({ length: RI(rnd, 4, 7) }, () => RI(rnd, 2, 19));
      const sum = nums.reduce((s, x) => s + x, 0);
      const pts = scatter(rnd, nums.length, w, h, 40);
      return {
        answer: sum,
        draw(c) { c.font = '700 44px Segoe UI, sans-serif'; c.fillStyle = '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle'; pts.forEach((p, i) => c.fillText(String(nums[i]), p.x, p.y)); },
        score: (g) => relScore(g, sum, 3),
      };
    },
  });
  mode({
    id: 'more-side', name: 'Links gegen rechts', cat: 'Zählen', icon: '⚖️', hint: 'Wie viele Punkte MEHR waren auf der volleren Seite?', input: 'number', flash: 1000,
    gen(rnd, w, h) {
      const a = RI(rnd, 10, 35); const b = a + RI(rnd, 2, 14) * (rnd() < 0.5 ? 1 : -1);
      const L = scatter(rnd, a, w / 2 - 20, h, 8); const Rr = scatter(rnd, Math.max(1, b), w / 2 - 20, h, 8);
      const diff = Math.abs(a - Math.max(1, b));
      return { answer: diff, draw(c) { line(c, w / 2, 20, w / 2, h - 20, 'rgba(255,255,255,.25)', 2); L.forEach((p) => dot(c, p.x, p.y, 8, '#0a84ff')); Rr.forEach((p) => dot(c, p.x + w / 2 + 20, p.y, 8, '#ff9f0a')); }, score: (g) => absScore(g, diff, 9) };
    },
  });

  // ---- Winkel & Richtung
  mode({
    id: 'angle', name: 'Winkel schätzen', cat: 'Winkel', icon: '📐', hint: 'Wie groß war der Winkel (0–180°)?', input: 'number', unit: '°', flash: 900,
    gen(rnd, w, h) {
      const ang = RI(rnd, 10, 175); const rot = R(rnd, 0, TAU);
      return {
        answer: ang,
        draw(c) {
          const cx = w / 2; const cy = h / 2; const L = Math.min(w, h) * 0.38;
          line(c, cx, cy, cx + Math.cos(rot) * L, cy + Math.sin(rot) * L, '#fff', 6);
          line(c, cx, cy, cx + Math.cos(rot + (ang * Math.PI) / 180) * L, cy + Math.sin(rot + (ang * Math.PI) / 180) * L, '#fff', 6);
          dot(c, cx, cy, 6, '#ff453a');
        },
        score: (g) => absScore(g, ang, 2.5),
      };
    },
  });
  mode({
    id: 'angle-acute', name: 'Spitze Winkel', cat: 'Winkel', icon: '🔻', hint: 'Wie groß war der Winkel (0–90°)?', input: 'number', unit: '°', flash: 800,
    gen(rnd, w, h) {
      const ang = RI(rnd, 4, 88); const rot = R(rnd, 0, TAU);
      return { answer: ang, draw(c) { const cx = w / 2, cy = h / 2, L = Math.min(w, h) * 0.4; line(c, cx, cy, cx + Math.cos(rot) * L, cy + Math.sin(rot) * L, '#64d2ff', 5); line(c, cx, cy, cx + Math.cos(rot + (ang * Math.PI) / 180) * L, cy + Math.sin(rot + (ang * Math.PI) / 180) * L, '#64d2ff', 5); }, score: (g) => absScore(g, ang, 4) };
    },
  });
  mode({
    id: 'direction', name: 'Himmelsrichtung', cat: 'Winkel', icon: '🧭', hint: 'In welche Richtung zeigte der Pfeil? Zieh den Zeiger.', input: 'angle', flash: 700,
    gen(rnd, w, h) {
      const deg = RI(rnd, 0, 359);
      return { answer: deg, draw(c) { const cx = w / 2, cy = h / 2, L = Math.min(w, h) * 0.36, a = ((deg - 90) * Math.PI) / 180; line(c, cx, cy, cx + Math.cos(a) * L, cy + Math.sin(a) * L, '#ff453a', 8); dot(c, cx + Math.cos(a) * L, cy + Math.sin(a) * L, 12, '#ff453a'); dot(c, cx, cy, 7); }, score: (g) => absScore(angDiff(g, deg), 0, 2.2) };
    },
  });
  mode({
    id: 'slope', name: 'Neigung', cat: 'Winkel', icon: '⛰️', hint: 'Wie steil war die Linie (0–90° zur Waagrechten)?', input: 'number', unit: '°', flash: 800,
    gen(rnd, w, h) {
      const ang = RI(rnd, 2, 88);
      return { answer: ang, draw(c) { const L = Math.min(w, h) * 0.45, a = (-ang * Math.PI) / 180; line(c, w / 2 - Math.cos(a) * L, h / 2 - Math.sin(a) * L, w / 2 + Math.cos(a) * L, h / 2 + Math.sin(a) * L, '#30d158', 7); line(c, 40, h - 30, w - 40, h - 30, 'rgba(255,255,255,.2)', 2); }, score: (g) => absScore(g, ang, 4) };
    },
  });
  mode({
    id: 'clock', name: 'Uhrzeit ablesen', cat: 'Winkel', icon: '🕓', hint: 'Wie viele Minuten nach der vollen Stunde?', input: 'number', unit: 'min', flash: 700,
    gen(rnd, w, h) {
      const min = RI(rnd, 0, 59); const hr = RI(rnd, 1, 12);
      return {
        answer: min,
        draw(c) {
          const cx = w / 2, cy = h / 2, r = Math.min(w, h) * 0.38;
          c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 3; c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.stroke();
          const ma = (min / 60) * TAU - Math.PI / 2; const ha = ((hr % 12) / 12 + min / 720) * TAU - Math.PI / 2;
          line(c, cx, cy, cx + Math.cos(ha) * r * 0.55, cy + Math.sin(ha) * r * 0.55, '#fff', 8);
          line(c, cx, cy, cx + Math.cos(ma) * r * 0.9, cy + Math.sin(ma) * r * 0.9, '#ffd60a', 5);
        },
        score: (g) => absScore(angDiff(g * 6, min * 6), 0, 2),
      };
    },
  });
  mode({
    id: 'rotation', name: 'Drehung', cat: 'Winkel', icon: '🔄', hint: 'Um wie viel Grad war das rechte Quadrat gedreht (0–90°)?', input: 'number', unit: '°', flash: 900,
    gen(rnd, w, h) {
      const ang = RI(rnd, 3, 87);
      return { answer: ang, draw(c) { const s = Math.min(w, h) * 0.32; c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(w * 0.28 - s / 2, h / 2 - s / 2, s, s); c.save(); c.translate(w * 0.72, h / 2); c.rotate((ang * Math.PI) / 180); c.fillStyle = '#bf5af2'; c.fillRect(-s / 2, -s / 2, s, s); c.restore(); }, score: (g) => absScore(g, ang, 4) };
    },
  });
  mode({
    id: 'parallel', name: 'Fast parallel', cat: 'Winkel', icon: '🛤️', hint: 'Wie viel Grad Unterschied hatten die beiden Linien?', input: 'number', unit: '°', flash: 900,
    gen(rnd, w, h) {
      const d = RI(rnd, 1, 30); const base = R(rnd, -0.6, 0.6);
      return { answer: d, draw(c) { const L = w * 0.36; for (const [k, off] of [[0, -h * 0.18], [1, h * 0.18]]) { const a = base + (k ? (d * Math.PI) / 180 : 0); line(c, w / 2 - Math.cos(a) * L, h / 2 + off - Math.sin(a) * L, w / 2 + Math.cos(a) * L, h / 2 + off + Math.sin(a) * L, '#fff', 5); } }, score: (g) => absScore(g, d, 6) };
    },
  });
  mode({
    id: 'bisect', name: 'Winkelhalbierende', cat: 'Winkel', icon: '✂️', hint: 'Klick dorthin, wo die Mitte zwischen den beiden Strahlen lag.', input: 'click', flash: 900,
    gen(rnd, w, h) {
      const a1 = R(rnd, 0, TAU); const a2 = a1 + R(rnd, 0.6, 2.4); const cx = w / 2, cy = h / 2, L = Math.min(w, h) * 0.42;
      const mid = (a1 + a2) / 2;
      const ans = { x: cx + Math.cos(mid) * L * 0.7, y: cy + Math.sin(mid) * L * 0.7 };
      return { answer: ans, draw(c) { line(c, cx, cy, cx + Math.cos(a1) * L, cy + Math.sin(a1) * L, '#fff', 5); line(c, cx, cy, cx + Math.cos(a2) * L, cy + Math.sin(a2) * L, '#fff', 5); dot(c, cx, cy, 6, '#ff453a'); }, score: (g) => { const ga = Math.atan2(g.y - cy, g.x - cx); return absScore(angDiff((ga * 180) / Math.PI, (mid * 180) / Math.PI), 0, 3); } };
    },
  });

  // ---- Anteile & Füllstände
  const pctMode = (id, name, icon, hint, drawFn, per = 3, flash = 800) => mode({
    id, name, cat: 'Anteile', icon, hint, input: 'percent', flash,
    gen(rnd, w, h) { const p = RI(rnd, 3, 97); const extra = rnd(); return { answer: p, draw: (c) => drawFn(c, p, w, h, extra), score: (g) => absScore(g, p, per) }; },
  });
  pctMode('glass', 'Füllstand', '🥛', 'Wie voll war das Glas (in %)?', (c, p, w, h) => { const gw = Math.min(w, h) * 0.32, gh = Math.min(w, h) * 0.7, x = w / 2 - gw / 2, y = h / 2 - gh / 2; c.fillStyle = '#0a84ff'; c.fillRect(x, y + gh * (1 - p / 100), gw, (gh * p) / 100); c.strokeStyle = '#fff'; c.lineWidth = 4; c.strokeRect(x, y, gw, gh); });
  pctMode('pie', 'Tortenstück', '🥧', 'Wie viel Prozent des Kreises war gefärbt?', (c, p, w, h, e) => { const cx = w / 2, cy = h / 2, r = Math.min(w, h) * 0.38, s = e * TAU; c.fillStyle = 'rgba(255,255,255,.15)'; c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.fill(); c.fillStyle = '#ff9f0a'; c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, r, s, s + (p / 100) * TAU); c.closePath(); c.fill(); });
  pctMode('bar', 'Ladebalken', '⏳', 'Wie weit war der Balken geladen (in %)?', (c, p, w, h) => { const bw = w * 0.8, x = w * 0.1, y = h / 2 - 16; c.fillStyle = 'rgba(255,255,255,.15)'; c.fillRect(x, y, bw, 32); c.fillStyle = '#30d158'; c.fillRect(x, y, (bw * p) / 100, 32); }, 4, 600);
  pctMode('cover', 'Bedeckte Fläche', '🟩', 'Wie viel Prozent der Fläche waren grün?', (c, p, w, h, e) => { const cols = 20, rows = 12, cw = w / cols, ch = h / rows, total = cols * rows, on = Math.round((total * p) / 100); const idx = [...Array(total).keys()].sort((a, b) => Math.sin(a * 999 + e * 50) - Math.sin(b * 999 + e * 50)); const set = new Set(idx.slice(0, on)); for (let i = 0; i < total; i++) { c.fillStyle = set.has(i) ? '#30d158' : 'rgba(255,255,255,.08)'; c.fillRect((i % cols) * cw + 1, Math.floor(i / cols) * ch + 1, cw - 2, ch - 2); } }, 2.5, 900);
  pctMode('mix', 'Farbmischung', '🎨', 'Wie viel Prozent der Punkte waren rot?', (c, p, w, h, e) => { let s = e * 1e6; const rr = () => ((s = (s * 9301 + 49297) % 233280) / 233280); const pts = scatter(rr, 120, w, h, 5, 10); pts.forEach((pt, i) => dot(c, pt.x, pt.y, 5, i < (pts.length * p) / 100 ? '#ff453a' : '#0a84ff')); }, 2.5, 1000);
  pctMode('arc', 'Kreisbogen', '◔', 'Wie viel Prozent eines vollen Kreises war der Bogen?', (c, p, w, h, e) => { const cx = w / 2, cy = h / 2, r = Math.min(w, h) * 0.36, s = e * TAU; c.strokeStyle = '#bf5af2'; c.lineWidth = 12; c.lineCap = 'round'; c.beginPath(); c.arc(cx, cy, r, s, s + (p / 100) * TAU); c.stroke(); });
  pctMode('battery', 'Akkustand', '🔋', 'Wie voll war der Akku (in %)?', (c, p, w, h) => { const bw = w * 0.5, bh = h * 0.32, x = w / 2 - bw / 2, y = h / 2 - bh / 2; c.strokeStyle = '#fff'; c.lineWidth = 5; c.strokeRect(x, y, bw, bh); c.fillStyle = '#fff'; c.fillRect(x + bw, y + bh * 0.3, 12, bh * 0.4); c.fillStyle = p < 20 ? '#ff453a' : '#30d158'; c.fillRect(x + 6, y + 6, ((bw - 12) * p) / 100, bh - 12); }, 4, 600);

  // ---- Längen & Verhältnisse
  mode({
    id: 'length-ratio', name: 'Längenvergleich', cat: 'Längen', icon: '📏', hint: 'Wie viel Prozent der oberen Linie war die untere lang?', input: 'percent', flash: 800,
    gen(rnd, w, h) { const p = RI(rnd, 10, 100); const L = w * 0.7; return { answer: p, draw(c) { line(c, w / 2 - L / 2, h * 0.35, w / 2 + L / 2, h * 0.35, '#fff', 6); const l2 = (L * p) / 100, x0 = R(rnd, w * 0.12, w * 0.88 - l2); line(c, x0, h * 0.65, x0 + l2, h * 0.65, '#ffd60a', 6); }, score: (g) => absScore(g, p, 3) }; },
  });
  mode({
    id: 'circle-ratio', name: 'Kreisgrößen', cat: 'Längen', icon: '⭕', hint: 'Wie oft passte der Durchmesser des kleinen Kreises in den großen?', input: 'number', flash: 900,
    gen(rnd, w, h) { const f = Math.round(R(rnd, 1.3, 6) * 10) / 10; const big = Math.min(w, h) * 0.38; return { answer: f, draw(c) { dot(c, w * 0.34, h / 2, big, 'rgba(10,132,255,.85)'); dot(c, w * 0.78, h / 2, big / f, '#ff9f0a'); }, score: (g) => relScore(g, f, 1.6) }; },
  });
  mode({
    id: 'aspect', name: 'Seitenverhältnis', cat: 'Längen', icon: '▭', hint: 'Wie oft passte die Höhe in die Breite (z. B. 1,8)?', input: 'number', flash: 800,
    gen(rnd, w, h) { const f = Math.round(R(rnd, 1.1, 4) * 10) / 10; const hh = Math.min(h * 0.5, (w * 0.8) / f); return { answer: f, draw(c) { c.fillStyle = '#64d2ff'; c.fillRect(w / 2 - (hh * f) / 2, h / 2 - hh / 2, hh * f, hh); }, score: (g) => relScore(g, f, 2) }; },
  });
  mode({
    id: 'midpoint', name: 'Mitte treffen', cat: 'Längen', icon: '🎯', hint: 'Klick auf die Mitte der Linie.', input: 'click', flash: 700,
    gen(rnd, w, h) { const x1 = R(rnd, 40, w - 40), y1 = R(rnd, 40, h - 40), x2 = R(rnd, 40, w - 40), y2 = R(rnd, 40, h - 40); const ans = { x: (x1 + x2) / 2, y: (y1 + y2) / 2 }; return { answer: ans, draw(c) { line(c, x1, y1, x2, y2, '#fff', 6); }, score: (g) => absScore(Math.hypot(g.x - ans.x, g.y - ans.y), 0, 100 / (Math.min(w, h) * 0.18)) }; },
  });
  mode({
    id: 'center', name: 'Kreismittelpunkt', cat: 'Längen', icon: '🔘', hint: 'Klick auf den Mittelpunkt des Kreisbogens.', input: 'click', flash: 800,
    gen(rnd, w, h) { const r = R(rnd, Math.min(w, h) * 0.2, Math.min(w, h) * 0.38); const cx = R(rnd, r + 20, w - r - 20), cy = R(rnd, r + 20, h - r - 20), s = R(rnd, 0, TAU); return { answer: { x: cx, y: cy }, draw(c) { c.strokeStyle = '#ffd60a'; c.lineWidth = 6; c.beginPath(); c.arc(cx, cy, r, s, s + R(rnd, 1.2, 2.6)); c.stroke(); }, score: (g) => absScore(Math.hypot(g.x - cx, g.y - cy), 0, 100 / (r * 0.6)) }; },
  });
  mode({
    id: 'area-ratio', name: 'Flächen-Duell', cat: 'Längen', icon: '🟦', hint: 'Wie viel Prozent der Fläche des Quadrats hatte der Kreis?', input: 'percent', flash: 900,
    gen(rnd, w, h) { const s = Math.min(w, h) * 0.55; const p = RI(rnd, 10, 100); const r = Math.sqrt(((p / 100) * s * s) / Math.PI); return { answer: p, draw(c) { c.fillStyle = 'rgba(255,255,255,.85)'; c.fillRect(w * 0.3 - s / 2, h / 2 - s / 2, s, s); dot(c, w * 0.74, h / 2, r, '#ff453a'); }, score: (g) => absScore(g, p, 2.5) }; },
  });
  mode({
    id: 'height', name: 'Turmhöhe', cat: 'Längen', icon: '🏢', hint: 'Wie viele graue Klötze hoch war der Turm?', input: 'number', flash: 700,
    gen(rnd, w, h) { const n = RI(rnd, 3, 18); const unit = Math.min((h * 0.8) / n, 40); return { answer: n, draw(c) { c.fillStyle = 'rgba(255,255,255,.55)'; c.fillRect(w * 0.25, h * 0.9 - unit, unit, unit); c.fillStyle = '#0a84ff'; c.fillRect(w * 0.6, h * 0.9 - unit * n, unit * 1.4, unit * n); line(c, 30, h * 0.9, w - 30, h * 0.9, 'rgba(255,255,255,.3)', 2); }, score: (g) => relScore(g, n, 2.5) }; },
  });

  // ---- Position & Gedächtnis
  mode({
    id: 'where', name: 'Wo war der Punkt?', cat: 'Gedächtnis', icon: '📍', hint: 'Klick dorthin, wo der Punkt war.', input: 'click', flash: 450,
    gen(rnd, w, h) { const p = { x: R(rnd, 30, w - 30), y: R(rnd, 30, h - 30) }; return { answer: p, draw(c) { dot(c, p.x, p.y, 10, '#ff453a'); }, score: (g) => absScore(Math.hypot(g.x - p.x, g.y - p.y), 0, 100 / (Math.min(w, h) * 0.2)) }; },
  });
  mode({
    id: 'where-odd', name: 'Der Ausreißer', cat: 'Gedächtnis', icon: '🟡', hint: 'Klick dorthin, wo der GELBE Punkt war.', input: 'click', flash: 800,
    gen(rnd, w, h) { const pts = scatter(rnd, 25, w, h, 9); const t = pts[0]; return { answer: t, draw(c) { pts.forEach((p, i) => dot(c, p.x, p.y, 9, i ? '#0a84ff' : '#ffd60a')); }, score: (g) => absScore(Math.hypot(g.x - t.x, g.y - t.y), 0, 100 / (Math.min(w, h) * 0.18)) }; },
  });
  mode({
    id: 'land', name: 'Wo landet der Ball?', cat: 'Gedächtnis', icon: '🏀', hint: 'Der Ball flog weiter – klick, wo er auf den Boden trifft.', input: 'click', flash: 900,
    gen(rnd, w, h) {
      const g0 = h * 0.88; const vx = R(rnd, 140, 260) * (rnd() < 0.5 ? 1 : -1); const vy = -R(rnd, 220, 360); const grav = 420; const x0 = vx > 0 ? w * 0.12 : w * 0.88; const y0 = g0 - 10;
      const tLand = (-vy + Math.sqrt(vy * vy + 2 * grav * (g0 - y0))) / grav; const land = { x: x0 + vx * tLand, y: g0 };
      return { answer: land, draw(c) { line(c, 20, g0, w - 20, g0, 'rgba(255,255,255,.3)', 3); c.strokeStyle = 'rgba(255,159,10,.7)'; c.lineWidth = 3; c.setLineDash([6, 8]); c.beginPath(); for (let t = 0; t <= tLand * 0.4; t += 0.02) { const x = x0 + vx * t, y = y0 + vy * t + 0.5 * grav * t * t; c[t ? 'lineTo' : 'moveTo'](x, y); } c.stroke(); c.setLineDash([]); const tt = tLand * 0.4; dot(c, x0 + vx * tt, y0 + vy * tt + 0.5 * grav * tt * tt, 12, '#ff9f0a'); }, score: (g) => absScore(Math.abs(g.x - land.x), 0, 100 / (w * 0.15)) };
    },
  });
  mode({
    id: 'gap', name: 'Abstand', cat: 'Gedächtnis', icon: '↔️', hint: 'Wie viel Prozent der Breite lagen die Punkte auseinander?', input: 'percent', flash: 600,
    gen(rnd, w, h) { const p = RI(rnd, 8, 90); const x1 = R(rnd, 20, w - 20 - (w * p) / 100); return { answer: p, draw(c) { dot(c, x1, h / 2, 10); dot(c, x1 + (w * p) / 100, h / 2, 10); }, score: (g) => absScore(g, p, 3) }; },
  });

  // ---- Farben
  mode({
    id: 'hue', name: 'Farbton merken', cat: 'Farben', icon: '🌈', hint: 'Welcher Farbton war es? Zieh den Regler.', input: 'hue', flash: 700,
    gen(rnd, w, h) { const hue = RI(rnd, 0, 359); return { answer: hue, draw(c) { c.fillStyle = hsl(hue, 90, 55); c.fillRect(w * 0.2, h * 0.2, w * 0.6, h * 0.6); }, score: (g) => absScore(angDiff(g, hue), 0, 2.2) }; },
  });
  mode({
    id: 'gray', name: 'Graustufe', cat: 'Farben', icon: '◐', hint: 'Wie hell war das Feld (0 = schwarz, 100 = weiß)?', input: 'percent', flash: 700,
    gen(rnd, w, h) { const p = RI(rnd, 5, 95); return { answer: p, draw(c) { c.fillStyle = hsl(0, 0, p); c.fillRect(w * 0.2, h * 0.2, w * 0.6, h * 0.6); }, score: (g) => absScore(g, p, 3) }; },
  });
  mode({
    id: 'saturation', name: 'Sättigung', cat: 'Farben', icon: '🎚️', hint: 'Wie kräftig war die Farbe (0 = grau, 100 = knallig)?', input: 'percent', flash: 700,
    gen(rnd, w, h) { const p = RI(rnd, 0, 100); const hue = RI(rnd, 0, 359); return { answer: p, draw(c) { c.fillStyle = hsl(hue, p, 50); c.fillRect(w * 0.2, h * 0.2, w * 0.6, h * 0.6); }, score: (g) => absScore(g, p, 2.5) }; },
  });
  mode({
    id: 'color-count', name: 'Wie viele Farben?', cat: 'Farben', icon: '🖍️', hint: 'Wie viele VERSCHIEDENE Farben waren zu sehen?', input: 'number', flash: 900,
    gen(rnd, w, h) { const n = RI(rnd, 2, 7); const cols = COLORS.slice().sort(() => rnd() - 0.5).slice(0, n); const pts = scatter(rnd, 30, w, h, 11); return { answer: n, draw(c) { pts.forEach((p, i) => dot(c, p.x, p.y, 11, cols[i % n])); }, score: (g) => absScore(g, n, 34) }; },
  });

  // ---- Zeitgefühl
  mode({
    id: 'duration', name: 'Wie lange?', cat: 'Zeitgefühl', icon: '⏱️', hint: 'Wie viele Sekunden war das Feld zu sehen?', input: 'number', unit: 's', flash: 0,
    gen(rnd) { const s = Math.round(R(rnd, 0.6, 4.5) * 10) / 10; return { answer: s, flashMs: s * 1000, draw(c, w, h) { c.fillStyle = '#bf5af2'; c.fillRect(w * 0.3, h * 0.3, w * 0.4, h * 0.4); }, score: (g) => relScore(g, s, 1.5) }; },
  });
  mode({
    id: 'timing', name: 'Innere Uhr', cat: 'Zeitgefühl', icon: '⌛', hint: 'Drück auf „Jetzt“, wenn die Zeit um ist – ohne Uhr.', input: 'timing', flash: 0,
    gen(rnd) { const s = RI(rnd, 2, 7); return { answer: s, target: s, draw(c, w, h) { c.fillStyle = '#fff'; c.font = '700 64px Segoe UI, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(`${s} Sekunden`, w / 2, h / 2); }, flashMs: 1200, score: (g) => relScore(g, s, 2) }; },
  });
  mode({
    id: 'blink', name: 'Blinker zählen', cat: 'Zeitgefühl', icon: '💡', hint: 'Wie oft hat das Licht geblinkt?', input: 'number', flash: 0,
    gen(rnd) { const n = RI(rnd, 4, 14); const gap = R(rnd, 110, 170); return { answer: n, blink: { n, gap }, flashMs: n * gap * 2 + 200, draw() {}, score: (g) => absScore(g, n, 20) }; },
  });
  mode({
    id: 'speed', name: 'Wie schnell?', cat: 'Zeitgefühl', icon: '🏎️', hint: 'Wie viele Sekunden brauchte der Punkt für einmal quer über das Feld?', input: 'number', unit: 's', flash: 0,
    gen(rnd) { const s = Math.round(R(rnd, 0.5, 3) * 10) / 10; return { answer: s, move: s, flashMs: s * 1000 + 150, draw() {}, score: (g) => relScore(g, s, 1.6) }; },
  });

  const CATS = [...new Set(M.map((m) => m.cat))];

  /* ------------------------------------------------------------------ Zustand */
  const st = { phase: 'lobby', mode: '', round: 0, rounds: [], total: 0, root: null, stats: null, last: null, timer: 0, guess: null, t0: 0 };

  function newGame(id) {
    const daily = id === 'daily';
    const rnd = daily ? A.seeded('eyeball-' + A.today()) : Math.random;
    st.mode = id;
    st.rounds = [];
    for (let i = 0; i < ROUNDS; i++) {
      const m = id === 'mix' || daily ? M[Math.floor(rnd() * M.length)] : M.find((x) => x.id === id);
      st.rounds.push({ m, rnd: daily ? A.seeded(`eyeball-${A.today()}-${i}`) : Math.random, pts: null, guess: null });
    }
    st.round = 0;
    st.total = 0;
    startRound();
  }

  function startRound() {
    const r = st.rounds[st.round];
    const cv = canvasSize();
    r.data = r.m.gen(r.rnd, cv.w, cv.h);
    st.guess = r.m.input === 'angle' || r.m.input === 'hue' ? 0 : r.m.input === 'percent' ? 50 : null;
    st.phase = 'show';
    paint();
    const flash = r.data.flashMs ?? r.m.flash;
    clearTimeout(st.timer);
    st.timer = setTimeout(() => {
      st.phase = 'guess';
      st.t0 = performance.now();
      paint();
    }, flash);
  }

  function submit(guess) {
    const r = st.rounds[st.round];
    if (st.phase !== 'guess' || guess == null || (typeof guess === 'number' && !Number.isFinite(guess))) return;
    r.guess = guess;
    r.pts = Math.max(0, Math.min(100, r.data.score(guess)));
    st.total += r.pts;
    st.phase = 'result';
    paint();
  }

  async function finish() {
    st.phase = 'end';
    const s = st.stats;
    s.games += 1;
    s.sum += st.total;
    if (st.total > (s.best[st.mode] || 0)) s.best[st.mode] = st.total;
    if (st.mode === 'daily') { s.dailyDone = A.today(); s.dailyScore = st.total; }
    await A.store.set('eyeball', s, true).catch(() => {});
    if (st.total >= 700) A.earn(Math.round(st.total / 100));
    paint();
  }

  /* ------------------------------------------------------------------ Zeichnen */
  function canvasSize() {
    const box = st.root?.querySelector('.eb-stage');
    const w = Math.max(320, Math.min(980, (box?.clientWidth || 860) - 4));
    return { w, h: Math.round(w * 0.56) };
  }

  function drawStage(canvas, r) {
    const { w, h } = canvasSize();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    const c = canvas.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, w, h);
    if (st.phase === 'show') {
      if (r.data.blink) return blink(c, w, h, r.data.blink);
      if (r.data.move) return moveDot(c, w, h, r.data.move);
      r.data.draw(c, w, h);
    } else if (st.phase === 'result') {
      r.data.draw(c, w, h); // Auflösung: die Aufgabe nochmal zeigen
      if (r.m.input === 'click' && r.guess) {
        dot(c, r.guess.x, r.guess.y, 9, '#30d158');
        line(c, r.guess.x, r.guess.y, r.data.answer.x, r.data.answer.y, 'rgba(48,209,88,.6)', 2);
        c.strokeStyle = '#fff'; c.lineWidth = 3; c.beginPath(); c.arc(r.data.answer.x, r.data.answer.y, 14, 0, TAU); c.stroke();
      }
    }
  }
  function blink(c, w, h, { n, gap }) {
    let i = 0;
    const tick = () => {
      if (st.phase !== 'show') return;
      c.clearRect(0, 0, w, h);
      if (i % 2 === 0) dot(c, w / 2, h / 2, Math.min(w, h) * 0.18, '#ffd60a');
      if (++i < n * 2) setTimeout(tick, gap);
    };
    tick();
  }
  function moveDot(c, w, h, secs) {
    const t0 = performance.now();
    const step = (t) => {
      if (st.phase !== 'show') return;
      const p = Math.min(1, (t - t0) / (secs * 1000));
      c.clearRect(0, 0, w, h);
      dot(c, 30 + (w - 60) * p, h / 2, 14, '#ff453a');
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  /* ------------------------------------------------------------------ Oberfläche */
  const fmtAns = (r, v) => {
    if (v == null) return '–';
    if (typeof v === 'object') return 'Position';
    if (r.m.input === 'percent') return `${Math.round(v)} %`;
    if (r.m.input === 'angle' || r.m.input === 'hue') return `${Math.round(v)}°`;
    return `${String(Math.round(v * 10) / 10).replace('.', ',')}${r.m.unit ? ` ${r.m.unit}` : ''}`;
  };

  function inputHtml(r) {
    const m = r.m;
    if (m.input === 'number') return `<form class="eb-in" data-eb-form><input class="rv-input eb-num" type="number" step="any" inputmode="decimal" placeholder="Schätzung" autofocus />${m.unit ? `<span class="eb-unit">${esc(m.unit)}</span>` : ''}<button class="rv-btn primary">OK</button></form>`;
    if (m.input === 'percent') return `<div class="eb-in"><input class="eb-range" type="range" min="0" max="100" value="${st.guess}" data-eb-range /><b class="eb-val">${st.guess} %</b><button class="rv-btn primary" data-eb-ok>OK</button></div>`;
    if (m.input === 'hue') return `<div class="eb-in"><input class="eb-range eb-hue" type="range" min="0" max="359" value="${st.guess}" data-eb-range /><span class="eb-swatch" style="background:hsl(${st.guess} 90% 55%)"></span><button class="rv-btn primary" data-eb-ok>OK</button></div>`;
    if (m.input === 'angle') return `<div class="eb-in"><div class="eb-dial" data-eb-dial><i style="transform:rotate(${st.guess}deg)"></i></div><b class="eb-val">${st.guess}°</b><button class="rv-btn primary" data-eb-ok>OK</button></div>`;
    if (m.input === 'timing') return `<div class="eb-in"><button class="rv-btn primary eb-big" data-eb-now>Jetzt!</button><span class="muted">Die Zeit läuft seit dem Verschwinden.</span></div>`;
    return '<div class="eb-in muted">Klick ins Feld.</div>';
  }

  function paint() {
    const root = st.root;
    if (!root) return;
    const s = st.stats;
    if (st.phase === 'lobby') {
      const dailyDone = s.dailyDone === A.today();
      root.innerHTML = `<div class="eb">
        <header class="eb-head"><div><h2>Augenmaß</h2><p class="muted">Die Aufgabe blitzt nur kurz auf – dann schätzt du aus dem Gedächtnis. ${M.length} Modi, je ${ROUNDS} Runden.</p></div>
          <div class="eb-stats"><span><b>${s.games}</b> Spiele</span><span><b>${s.games ? Math.round(s.sum / s.games) : 0}</b> Ø Punkte</span></div></header>
        <div class="eb-quick"><button class="rv-card eb-tile big" data-eb-start="mix"><span>🎲</span><b>Mix</b><small>10 zufällige Modi</small></button>
          <button class="rv-card eb-tile big" data-eb-start="daily" ${dailyDone ? 'disabled' : ''}><span>📅</span><b>Täglich</b><small>${dailyDone ? `Heute: ${s.dailyScore} Punkte` : 'Für alle gleich'}</small></button></div>
        ${CATS.map((cat) => `<section class="eb-cat"><h3>${esc(cat)}</h3><div class="eb-grid">${M.filter((m) => m.cat === cat).map((m) => `<button class="rv-card eb-tile" data-eb-start="${m.id}" title="${esc(m.hint)}"><span>${m.icon}</span><b>${esc(m.name)}</b><small>${s.best[m.id] ? `Rekord ${s.best[m.id]}` : 'Neu'}</small></button>`).join('')}</div></section>`).join('')}
      </div>`;
      return;
    }
    if (st.phase === 'end') {
      const grade = st.total >= 850 ? 'Adlerauge! 🦅' : st.total >= 650 ? 'Richtig gut 👀' : st.total >= 400 ? 'Solide 👍' : 'Übung macht den Meister 💪';
      root.innerHTML = `<div class="eb eb-end"><div class="rv-card eb-endcard"><h2>${st.total} Punkte</h2><p>${grade}</p>
        <div class="eb-list">${st.rounds.map((r) => `<div><span>${r.m.icon} ${esc(r.m.name)}</span><b>${r.pts}</b></div>`).join('')}</div>
        <div class="eb-row"><button class="rv-btn primary" data-eb-start="${st.mode}" ${st.mode === 'daily' ? 'disabled' : ''}>Nochmal</button><button class="rv-btn" data-eb-lobby>Alle Modi</button></div></div></div>`;
      return;
    }
    const r = st.rounds[st.round];
    root.innerHTML = `<div class="eb eb-play">
      <header class="eb-bar"><button class="rv-btn" data-eb-lobby>‹ Modi</button><span class="eb-mode">${r.m.icon} ${esc(r.m.name)}</span><span class="eb-round">Runde ${st.round + 1}/${ROUNDS}</span><span class="eb-total">${st.total} Pkt.</span></header>
      <p class="eb-hint">${st.phase === 'show' ? 'Gut hinschauen …' : esc(r.m.hint)}</p>
      <div class="eb-stage ${st.phase === 'guess' && r.m.input === 'click' ? 'clickable' : ''}"><canvas data-eb-canvas></canvas>${st.phase === 'guess' && r.m.input !== 'click' ? '<div class="eb-gone">?</div>' : ''}</div>
      ${st.phase === 'guess' ? inputHtml(r) : ''}
      ${st.phase === 'result' ? `<div class="eb-result"><div><small>Deine Schätzung</small><b>${fmtAns(r, r.guess)}</b></div><div><small>Richtig</small><b>${fmtAns(r, r.data.answer)}</b></div><div class="eb-pts ${r.pts >= 80 ? 'good' : r.pts >= 40 ? 'ok' : 'bad'}">+${r.pts}</div><button class="rv-btn primary" data-eb-next>${st.round + 1 < ROUNDS ? 'Weiter' : 'Ergebnis'}</button></div>` : ''}
    </div>`;
    const c = root.querySelector('canvas');
    if (c) drawStage(c, r);
    root.querySelector('.eb-num')?.focus();
  }

  /* ------------------------------------------------------------------ Eingaben */
  const inApp = (e) => st.root && st.root.contains(e.target);
  document.addEventListener('click', (e) => {
    if (!inApp(e)) return;
    const q = (sel) => e.target.closest(sel);
    const start = q('[data-eb-start]')?.dataset.ebStart;
    if (start) return newGame(start);
    if (q('[data-eb-lobby]')) { clearTimeout(st.timer); st.phase = 'lobby'; return paint(); }
    if (q('[data-eb-next]')) { if (++st.round >= ROUNDS) return finish(); return startRound(); }
    if (q('[data-eb-ok]')) return submit(st.guess);
    if (q('[data-eb-now]')) return submit(Math.round((performance.now() - st.t0) / 100) / 10);
    const canvas = q('[data-eb-canvas]');
    const r = st.rounds[st.round];
    if (canvas && st.phase === 'guess' && r?.m.input === 'click') {
      const b = canvas.getBoundingClientRect();
      submit({ x: e.clientX - b.left, y: e.clientY - b.top });
    }
  });
  document.addEventListener('submit', (e) => {
    if (!inApp(e) || !e.target.matches('[data-eb-form]')) return;
    e.preventDefault();
    const v = Number(String(e.target.querySelector('input').value).replace(',', '.'));
    if (Number.isFinite(v)) submit(v);
  });
  document.addEventListener('input', (e) => {
    if (!inApp(e) || !e.target.matches('[data-eb-range]')) return;
    st.guess = Number(e.target.value);
    const val = st.root.querySelector('.eb-val');
    if (val) val.textContent = `${st.guess} %`;
    const sw = st.root.querySelector('.eb-swatch');
    if (sw) sw.style.background = `hsl(${st.guess} 90% 55%)`;
  });
  // Drehregler für Richtungen
  let dialDrag = false;
  const dialSet = (e) => {
    const d = st.root?.querySelector('[data-eb-dial]');
    if (!d) return;
    const b = d.getBoundingClientRect();
    let deg = (Math.atan2(e.clientY - (b.top + b.height / 2), e.clientX - (b.left + b.width / 2)) * 180) / Math.PI + 90;
    deg = Math.round((deg + 360) % 360);
    st.guess = deg;
    d.querySelector('i').style.transform = `rotate(${deg}deg)`;
    const val = st.root.querySelector('.eb-val');
    if (val) val.textContent = `${deg}°`;
  };
  document.addEventListener('pointerdown', (e) => { if (inApp(e) && e.target.closest('[data-eb-dial]')) { dialDrag = true; dialSet(e); } });
  window.addEventListener('pointermove', (e) => { if (dialDrag) dialSet(e); });
  window.addEventListener('pointerup', () => { dialDrag = false; });
  document.addEventListener('keydown', (e) => {
    if (!st.root || !document.contains(st.root)) return;
    if (e.key === 'Enter' && st.phase === 'result') { e.preventDefault(); st.root.querySelector('[data-eb-next]')?.click(); }
    if (e.key === 'Enter' && st.phase === 'guess' && st.root.querySelector('[data-eb-ok]')) { e.preventDefault(); submit(st.guess); }
    if (e.key === ' ' && st.phase === 'guess' && st.rounds[st.round]?.m.input === 'timing') { e.preventDefault(); st.root.querySelector('[data-eb-now]')?.click(); }
  });

  A.define(
    ID,
    { nav: 'Augenmaß', title: 'Augenmaß', sub: '40 Schätz-Spiele', icon: 'target', tint: 'linear-gradient(135deg,#22d3ee,#a855f7)', desc: 'Punkte zählen, Winkel, Füllstände, Längen, Farben, Zeitgefühl – die Aufgabe blitzt nur kurz auf, dann schätzt du aus dem Gedächtnis.' },
    {
      game: true,
      async mount(root) {
        st.root = root;
        if (!st.stats) {
          const saved = await A.store.get('eyeball', {}, true).catch(() => ({}));
          st.stats = { games: Number(saved?.games) || 0, sum: Number(saved?.sum) || 0, best: saved?.best || {}, dailyDone: saved?.dailyDone || '', dailyScore: Number(saved?.dailyScore) || 0 };
        }
        paint();
      },
      unmount() {
        clearTimeout(st.timer);
        st.root = null;
      },
    },
  );
  window.__eyeballModes = M; // für Tests: alle Modi
})();
