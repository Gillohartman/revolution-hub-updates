'use strict';

/*
 * 2.48 Klavier lernen: Lernpfad wie bei Duolingo (Einheiten mit Lektionen), berühmte gemeinfreie Lieder
 * (Klassik + Volkslieder), Akkorde und freies Spielen. Erkennt Töne über das Mikrofon (Tonhöhe, bei
 * Akkorden über ein Chroma-Spektrum), über ein MIDI-Keyboard oder die Computertastatur.
 * Der Lerncoach „Clara“ spricht mit derselben Stimme wie der Schach-Coach und sagt nie zweimal
 * hintereinander dasselbe.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-piano';

  /* ================================================================== Musik-Grundlagen */
  const PC = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const DE = ['C', 'Cis', 'D', 'Dis', 'E', 'F', 'Fis', 'G', 'Gis', 'A', 'B', 'H']; // deutsch: B = Bb, H = B
  const toMidi = (s) => {
    const m = /^([A-G])(#|b)?(-?\d)$/.exec(s);
    if (!m) throw new Error(`Note ${s}`);
    return 12 * (Number(m[3]) + 1) + PC[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
  };
  const name = (m) => DE[((m % 12) + 12) % 12];
  const fullName = (m) => `${name(m)}${Math.floor(m / 12) - 1}`;
  const isBlack = (m) => [1, 3, 6, 8, 10].includes(((m % 12) + 12) % 12);
  const freq = (m) => 440 * 2 ** ((m - 69) / 12);
  /** „E4 E4:2 R:1 …“ → [{ m, d }] (d in Schlägen, R = Pause) */
  const P = (s) => s.trim().split(/\s+/).map((t) => { const [n, d] = t.split(':'); return { m: n === 'R' ? null : toMidi(n), d: Number(d || 1) }; });

  /* ================================================================== Lieder (gemeinfrei) */
  const SONGS = [
    { id: 'entchen', t: 'Alle meine Entchen', by: 'Volkslied', lv: 1, bpm: 100, n: P('C4 D4 E4 F4 G4:2 G4:2 A4 A4 A4 A4 G4:4 A4 A4 A4 A4 G4:4 F4 F4 F4 F4 E4:2 E4:2 D4 D4 D4 D4 C4:4') },
    { id: 'haenschen', t: 'Hänschen klein', by: 'Volkslied', lv: 1, bpm: 104, n: P('G4 E4 E4:2 F4 D4 D4:2 C4 D4 E4 F4 G4 G4 G4:2 G4 E4 E4:2 F4 D4 D4:2 C4 E4 G4 G4 C4:4') },
    { id: 'jakob', t: 'Bruder Jakob', by: 'Volkslied', lv: 1, bpm: 100, n: P('C4 D4 E4 C4 C4 D4 E4 C4 E4 F4 G4:2 E4 F4 G4:2 G4:.5 A4:.5 G4:.5 F4:.5 E4 C4 G4:.5 A4:.5 G4:.5 F4:.5 E4 C4 C4 G3 C4:2 C4 G3 C4:2') },
    { id: 'twinkle', t: 'Morgen kommt der Weihnachtsmann', by: 'Volkslied (Twinkle, Twinkle)', lv: 1, bpm: 100, n: P('C4 C4 G4 G4 A4 A4 G4:2 F4 F4 E4 E4 D4 D4 C4:2 G4 G4 F4 F4 E4 E4 D4:2 G4 G4 F4 F4 E4 E4 D4:2 C4 C4 G4 G4 A4 A4 G4:2 F4 F4 E4 E4 D4 D4 C4:2') },
    { id: 'ode', t: 'Ode an die Freude', by: 'Ludwig van Beethoven', lv: 2, bpm: 108, n: P('E4 E4 F4 G4 G4 F4 E4 D4 C4 C4 D4 E4 E4:1.5 D4:.5 D4:2 E4 E4 F4 G4 G4 F4 E4 D4 C4 C4 D4 E4 D4:1.5 C4:.5 C4:2 D4 D4 E4 C4 D4 E4:.5 F4:.5 E4 C4 D4 E4:.5 F4:.5 E4 D4 C4 D4 G3:2 E4 E4 F4 G4 G4 F4 E4 D4 C4 C4 D4 E4 D4:1.5 C4:.5 C4:2') },
    { id: 'saints', t: 'When the Saints Go Marching In', by: 'Spiritual', lv: 2, bpm: 120, n: P('C4 E4 F4 G4:4 C4 E4 F4 G4:4 C4 E4 F4 G4:2 E4:2 C4:2 E4:2 D4:4 E4 E4 D4 C4:3 C4 E4 G4:2 G4 F4:3 E4 F4 G4:2 E4:2 C4:2 D4:2 C4:4') },
    { id: 'jingle', t: 'Jingle Bells', by: 'James Lord Pierpont', lv: 2, bpm: 120, n: P('E4 E4 E4:2 E4 E4 E4:2 E4 G4 C4:1.5 D4:.5 E4:4 F4 F4 F4:1.5 F4:.5 F4 E4 E4 E4:.5 E4:.5 E4 D4 D4 E4 D4:2 G4:2 E4 E4 E4:2 E4 E4 E4:2 E4 G4 C4:1.5 D4:.5 E4:4 F4 F4 F4:1.5 F4:.5 F4 E4 E4 E4:.5 E4:.5 G4 G4 F4 D4 C4:4') },
    { id: 'birthday', t: 'Happy Birthday', by: 'Mildred & Patty Hill', lv: 2, bpm: 96, n: P('G4:.75 G4:.25 A4 G4 C5 B4:2 G4:.75 G4:.25 A4 G4 D5 C5:2 G4:.75 G4:.25 G5 E5 C5 B4 A4:2 F5:.75 F5:.25 E5 C5 D5 C5:2') },
    { id: 'amazing', t: 'Amazing Grace', by: 'John Newton', lv: 2, bpm: 84, n: P('G3 C4:2 E4:.5 C4:.5 E4:2 D4 C4:2 A3 G3:2 G3 C4:2 E4:.5 C4:.5 E4:2 D4 G4:3') },
    { id: 'auld', t: 'Auld Lang Syne', by: 'Volkslied (Schottland)', lv: 2, bpm: 90, n: P('G3 C4:1.5 C4:.5 C4 E4 D4:1.5 C4:.5 D4 E4 C4:1.5 C4:.5 E4 G4 A4:3') },
    { id: 'stille', t: 'Stille Nacht', by: 'Franz Xaver Gruber', lv: 2, bpm: 96, n: P('G4:1.5 A4:.5 G4 E4:3 G4:1.5 A4:.5 G4 E4:3 D5:2 D5 B4:3 C5:2 C5 G4:3 A4:2 A4 C5:1.5 B4:.5 A4 G4:1.5 A4:.5 G4 E4:3 A4:2 A4 C5:1.5 B4:.5 A4 G4:1.5 A4:.5 G4 E4:3 D5:2 D5 F5:1.5 D5:.5 B4 C5:3 E5:3 C5 G4 E4 G4:1.5 F4:.5 D4 C4:6') },
    { id: 'wiegenlied', t: 'Wiegenlied (Guten Abend, gut’ Nacht)', by: 'Johannes Brahms', lv: 2, bpm: 80, n: P('E4:.5 E4:.5 G4:3 E4:.5 E4:.5 G4:3 E4:.5 G4:.5 C5 B4:1.5 A4:.5 A4 G4 D4:.5 E4:.5 F4 D4 D4:.5 E4:.5 F4:3 D4:.5 F4:.5 B4:.5 A4:.5 G4 B4 C5:3') },
    { id: 'morgen', t: 'Morgenstimmung', by: 'Edvard Grieg', lv: 2, bpm: 90, n: P('G4 E4 D4 C4 D4 E4 G4 E4 D4 C4 D4:.5 E4:.5 D4:.5 E4:.5 G4 E4 G4 A4 E4 A4 G4 E4 D4 C4:3') },
    { id: 'greensleeves', t: 'Greensleeves', by: 'Englisches Volkslied', lv: 3, bpm: 100, n: P('A4 C5:2 D5 E5:1.5 F5:.5 E5 D5:2 B4 G4:1.5 A4:.5 B4 C5:2 A4 A4:1.5 G#4:.5 A4 B4:2 G#4 E4:2 A4 C5:2 D5 E5:1.5 F5:.5 E5 D5:2 B4 G4:1.5 A4:.5 B4 C5:1.5 B4:.5 A4 G#4:1.5 F#4:.5 G#4 A4:3') },
    { id: 'nachtmusik', t: 'Eine kleine Nachtmusik', by: 'Wolfgang Amadeus Mozart', lv: 3, bpm: 110, n: P('G4:2 D4 G4:2 D4 G4 D4 G4 B4 D5:4 C5:2 A4 C5:2 A4 C5 A4 F#4 A4 D4:4') },
    { id: 'menuett', t: 'Menuett in G', by: 'J. S. Bach / Petzold', lv: 3, bpm: 120, n: P('D5:2 G4 A4 B4 C5 D5:2 G4:2 G4:2 E5:2 C5 D5 E5 F#5 G5:2 G4:2 G4:2 C5:2 D5 C5 B4 A4 B4:2 C5 B4 A4 G4 F#4:2 G4 A4 B4 G4 A4:6') },
    { id: 'bergkoenig', t: 'In der Halle des Bergkönigs', by: 'Edvard Grieg', lv: 3, bpm: 110, n: P('A3 B3 C4 D4 E4 C4 E4:2 D#4 B3 D#4:2 D4 A#3 D4:2 A3 B3 C4 D4 E4 C4 E4 A4 G4 E4 C4 E4 G4:4') },
    { id: 'elise', t: 'Für Elise', by: 'Ludwig van Beethoven', lv: 3, bpm: 92, n: P('E5:.5 D#5:.5 E5:.5 D#5:.5 E5:.5 B4:.5 D5:.5 C5:.5 A4:1.5 C4:.5 E4:.5 A4:.5 B4:1.5 E4:.5 G#4:.5 B4:.5 C5:1.5 E4:.5 E5:.5 D#5:.5 E5:.5 D#5:.5 E5:.5 B4:.5 D5:.5 C5:.5 A4:1.5 C4:.5 E4:.5 A4:.5 B4:1.5 E4:.5 C5:.5 B4:.5 A4:2') },
    { id: 'turca', t: 'Türkischer Marsch', by: 'Wolfgang Amadeus Mozart', lv: 3, bpm: 112, n: P('B4:.25 A4:.25 G#4:.25 A4:.25 C5:1 D5:.25 C5:.25 B4:.25 C5:.25 E5:1 F5:.25 E5:.25 D#5:.25 E5:.25 B5:.25 A5:.25 G#5:.25 A5:.25 B5:.25 A5:.25 G#5:.25 A5:.25 C6:2') },
  ];
  const songById = (id) => SONGS.find((s) => s.id === id);

  /* ================================================================== Akkorde */
  const CH = (n, root, kind, notes, tip) => ({ id: n, root, kind, notes: notes.map(toMidi), tip });
  const CHORDS = [
    CH('C', 'C', 'Dur', ['C4', 'E4', 'G4'], 'Daumen auf C, Mittelfinger auf E, kleiner Finger auf G.'),
    CH('F', 'F', 'Dur', ['F4', 'A4', 'C5'], 'Gleiche Handform wie C – nur vier Tasten weiter rechts.'),
    CH('G', 'G', 'Dur', ['G4', 'B4', 'D5'], 'Von G aus: eine Taste auslassen, spielen, eine auslassen, spielen.'),
    CH('Am', 'A', 'Moll', ['A3', 'C4', 'E4'], 'a-Moll klingt traurig – nur weiße Tasten.'),
    CH('Dm', 'D', 'Moll', ['D4', 'F4', 'A4'], 'd-Moll: D, F, A – wieder jede zweite weiße Taste.'),
    CH('Em', 'E', 'Moll', ['E4', 'G4', 'B4'], 'e-Moll: E, G, H.'),
    CH('D', 'D', 'Dur', ['D4', 'F#4', 'A4'], 'D-Dur: In der Mitte liegt die schwarze Taste Fis.'),
    CH('A', 'A', 'Dur', ['A3', 'C#4', 'E4'], 'A-Dur: Cis ist die schwarze Taste in der Mitte.'),
    CH('E', 'E', 'Dur', ['E4', 'G#4', 'B4'], 'E-Dur: Gis in der Mitte.'),
    CH('G7', 'G', 'Septakkord', ['G3', 'B3', 'D4', 'F4'], 'Vier Töne: G, H, D und F – will zurück nach C.'),
    CH('Cmaj7', 'C', 'Major 7', ['C4', 'E4', 'G4', 'B4'], 'Weich und jazzig: C-Dur plus H.'),
    CH('Csus4', 'C', 'Sus 4', ['C4', 'F4', 'G4'], 'Das E wird zum F – klingt offen und schwebend.'),
  ];
  const chordById = (id) => CHORDS.find((c) => c.id === id);
  const chordName = (c) => (c.kind === 'Moll' ? `${c.root.toLowerCase().replace('b', 'h')}-Moll` : c.kind === 'Dur' ? `${c.root === 'B' ? 'H' : c.root}-Dur` : `${c.id}`);

  /* ================================================================== Lernpfad */
  const W = (s) => s.split(' ').map(toMidi);
  const L = (id, t, icon, kind, data) => ({ id, t, icon, kind, data });
  const UNITS = [
    { t: 'Die Klaviatur', sub: 'Finde dich auf den Tasten zurecht', col: '#30d158', ls: [
      L('find-c', 'Das ist C', '🎯', 'find', { pool: W('C4'), count: 4, hint: true }),
      L('find-cde', 'C, D und E', '🎹', 'find', { pool: W('C4 D4 E4'), count: 8, hint: true }),
      L('find-fg', 'F und G', '🎹', 'find', { pool: W('C4 D4 E4 F4 G4'), count: 10, hint: true }),
      L('find-ah', 'A, H und das hohe C', '🎹', 'find', { pool: W('C4 D4 E4 F4 G4 A4 B4 C5'), count: 12 }),
      L('find-black', 'Die schwarzen Tasten', '⬛', 'find', { pool: W('C#4 D#4 F#4 G#4 A#4'), count: 8, hint: true }),
    ] },
    { t: 'Erste Melodien', sub: 'Rechte Hand, fünf Finger', col: '#0a84ff', ls: [
      L('five', 'Fünf-Finger-Übung', '🖐', 'seq', { n: P('C4 D4 E4 F4 G4 F4 E4 D4 C4:2') }),
      L('s-entchen', 'Alle meine Entchen', '🦆', 'song', { song: 'entchen' }),
      L('s-haenschen', 'Hänschen klein', '🎒', 'song', { song: 'haenschen' }),
      L('s-jakob', 'Bruder Jakob', '🔔', 'song', { song: 'jakob' }),
    ] },
    { t: 'Gehör', sub: 'Hören und nachspielen', col: '#bf5af2', ls: [
      L('ear-ceg', 'Hören: C, E, G', '👂', 'ear', { pool: W('C4 E4 G4'), count: 6 }),
      L('ear-five', 'Hören: C bis G', '👂', 'ear', { pool: W('C4 D4 E4 F4 G4'), count: 8 }),
      L('ear-oct', 'Hören: ganze Oktave', '🎧', 'ear', { pool: W('C4 D4 E4 F4 G4 A4 B4 C5'), count: 10 }),
    ] },
    { t: 'Akkorde', sub: 'Drei Töne gleichzeitig', col: '#ff9f0a', ls: [
      L('ch-c', 'C-Dur', '🤘', 'chord', { list: ['C', 'C', 'C'] }),
      L('ch-f', 'F-Dur', '🤘', 'chord', { list: ['F', 'C', 'F'] }),
      L('ch-g', 'G-Dur', '🤘', 'chord', { list: ['G', 'C', 'G'] }),
      L('ch-cad', 'Kadenz: C – F – G – C', '🎼', 'chord', { list: ['C', 'F', 'G', 'C', 'F', 'G', 'C'] }),
    ] },
    { t: 'Beliebte Lieder', sub: 'Die bekanntesten Melodien', col: '#ff375f', ls: [
      L('s-twinkle', 'Morgen kommt der Weihnachtsmann', '⭐', 'song', { song: 'twinkle' }),
      L('s-ode', 'Ode an die Freude', '🎉', 'song', { song: 'ode' }),
      L('s-jingle', 'Jingle Bells', '🔔', 'song', { song: 'jingle' }),
      L('s-birthday', 'Happy Birthday', '🎂', 'song', { song: 'birthday' }),
    ] },
    { t: 'Moll & Begleitung', sub: 'Traurige Akkorde und Pop-Folgen', col: '#64d2ff', ls: [
      L('ch-am', 'a-Moll', '🌧', 'chord', { list: ['Am', 'C', 'Am'] }),
      L('ch-dm-em', 'd-Moll und e-Moll', '🌧', 'chord', { list: ['Dm', 'Em', 'Dm', 'Em'] }),
      L('ch-pop', 'Pop-Folge: Am – F – C – G', '🎤', 'chord', { list: ['Am', 'F', 'C', 'G', 'Am', 'F', 'C', 'G'] }),
      L('ch-g7', 'G7 – zurück nach Hause', '🏠', 'chord', { list: ['C', 'G7', 'C', 'F', 'G7', 'C'] }),
    ] },
    { t: 'Klassik', sub: 'Die großen Komponisten', col: '#ffd60a', ls: [
      L('s-nachtmusik', 'Eine kleine Nachtmusik', '🎻', 'song', { song: 'nachtmusik' }),
      L('s-menuett', 'Menuett in G', '💃', 'song', { song: 'menuett' }),
      L('s-bergkoenig', 'Halle des Bergkönigs', '⛰', 'song', { song: 'bergkoenig' }),
      L('s-elise', 'Für Elise', '🌹', 'song', { song: 'elise' }),
      L('s-turca', 'Türkischer Marsch', '🥁', 'song', { song: 'turca' }),
    ] },
  ];
  const ALL_LESSONS = UNITS.flatMap((u, ui) => u.ls.map((l, li) => ({ ...l, ui, li, col: u.col })));

  /* ================================================================== Coach Clara: viele Sätze */
  const SAY = {
    hello: ['Hallo! Schön, dass du da bist. Lass uns ein bisschen Klavier spielen.', 'Hey, da bist du ja! Bereit für ein paar Töne?', 'Willkommen zurück am Klavier! Ich habe mich schon gefreut.', 'Schön dich zu sehen. Heute wird’s musikalisch!', 'Hallo Pianist! Wollen wir loslegen?'],
    start: ['Los geht’s mit {l}. Ganz entspannt.', '{l} – das schaffst du locker.', 'Okay, {l}. Lockere Schultern, ruhige Hände.', 'Jetzt kommt {l}. Ich höre gut zu.', 'Auf geht’s: {l}. Nimm dir Zeit, Tempo ist egal.', '{l}. Atme kurz durch – und los.'],
    good: ['Bravo!', 'Super!', 'Genau richtig!', 'Klasse!', 'Sehr schön!', 'Perfekt!', 'Weiter so!', 'Ja, genau!', 'Toll gemacht!', 'Treffer!', 'Wunderbar!', 'Stark!'],
    streak: ['Wow, {n} richtig hintereinander! Du bist richtig im Flow.', '{n} Treffer am Stück – Bravo!', 'Unglaublich, {n} in Folge. So klingt Übung!', 'Du bist heute in Topform – {n} hintereinander!', '{n} richtige Töne in Folge. Das ist Musik in meinen Ohren!'],
    miss: ['Fast! Das war {got}, gesucht ist {want}.', 'Knapp daneben – versuch {want}.', 'Kein Problem. {want} ist gleich daneben.', 'Das war {got}. Such mal nach {want}.', 'Nicht schlimm! Fehler gehören dazu. Gesucht: {want}.', 'Hmm, {got}. Probier’s nochmal mit {want}.'],
    missTip: ['Kleiner Tipp: Das C liegt immer links neben den zwei schwarzen Tasten.', 'Tipp: Schau auf die Gruppen der schwarzen Tasten – zwei und drei. Daran erkennst du jeden Ton.', 'Langsam ist schneller. Spiel lieber ruhig und sicher.', 'Tipp: Drück die Taste fest genug, dann höre ich dich besser.', 'Kurze Pause, Hände lockern – dann klappt’s gleich.'],
    done: ['Geschafft! {l} ist erledigt.', 'Bravo, {l} sitzt!', 'Fantastisch, du hast {l} gemeistert.', 'Lektion fertig – ich bin richtig stolz auf dich!', 'Das war richtig gut. {l} abgehakt!'],
    perfect: ['Ohne einen einzigen Fehler! Drei Sterne für dich.', 'Perfekt gespielt – das war fehlerfrei!', 'Null Fehler. Ganz große Klasse!', 'Makellos! So spielt ein Profi.'],
    chordGood: ['Schöner Akkord!', 'Klingt sauber!', 'Der sitzt!', 'Genau so, alle Töne zusammen!', 'Wunderbar voller Klang!'],
    songDone: ['Du hast {s} gespielt – Applaus!', '{s} komplett durchgespielt. Bravo!', 'Hör mal, wie gut {s} schon klingt!', 'Das war {s}. Ich bekomme Gänsehaut!'],
    idle: ['Willst du weitermachen? Der nächste Schritt wartet schon.', 'Fünf Minuten am Tag reichen – Hauptsache regelmäßig.', 'Jeder Profi hat mal mit einem C angefangen.', 'Übung macht den Meister – und du bist auf dem besten Weg.'],
  };
  const lastSaid = {};
  function line(key, vars = {}) {
    const arr = SAY[key] || [''];
    let i = Math.floor(Math.random() * arr.length);
    if (arr.length > 1 && i === lastSaid[key]) i = (i + 1 + Math.floor(Math.random() * (arr.length - 1))) % arr.length;
    lastSaid[key] = i;
    return arr[i].replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? '');
  }

  /* ================================================================== Zustand */
  const st = {
    root: null, tab: 'path', view: null, data: null, saving: 0,
    mic: { on: false, stream: null, ac: null, an: null, fan: null, raf: 0, last: -1, stable: 0, cand: -1, rms: 0, emitted: -1, quietUntil: 0, chroma: null, chordHits: 0 },
    midi: null, held: new Map(), heard: { m: -1, cents: 0, at: 0 },
    coach: { text: '', mood: 'happy', speaking: false, voice: true, lastSpeak: 0, ready: null },
  };
  const defaults = () => ({ done: {}, xp: 0, streak: 0, lastDay: '', noteErr: {}, noteOk: {}, chordErr: {}, chordOk: {}, songs: {}, voice: true });

  async function load() {
    if (st.data) return;
    const d = await A.store.get('piano', null, true).catch(() => null);
    st.data = { ...defaults(), ...(d && typeof d === 'object' ? d : {}) };
    st.coach.voice = st.data.voice !== false;
  }
  function save() {
    clearTimeout(st.saving);
    st.saving = setTimeout(() => A.store.set('piano', st.data, true).catch(() => {}), 600);
  }
  const today = () => new Date().toISOString().slice(0, 10);
  function touchStreak() {
    const d = st.data;
    const t = today();
    if (d.lastDay === t) return;
    const y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
    d.streak = d.lastDay === y ? (d.streak || 0) + 1 : 1;
    d.lastDay = t;
  }

  /* ================================================================== Klang (eigener kleiner Klavier-Synth) */
  let ac = null;
  const audio = () => (ac ||= new AudioContext());
  function playNote(m, dur = 0.9, when = 0, vel = 0.5) {
    const c = audio();
    const t = c.currentTime + when;
    const out = c.createGain();
    out.gain.setValueAtTime(0, t);
    out.gain.linearRampToValueAtTime(vel * 0.32, t + 0.008);
    out.gain.exponentialRampToValueAtTime(vel * 0.12, t + 0.35);
    out.gain.exponentialRampToValueAtTime(0.0005, t + dur + 0.9);
    const lp = c.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(Math.min(9000, freq(m) * 9), t);
    lp.frequency.exponentialRampToValueAtTime(Math.min(3000, freq(m) * 3), t + 0.6);
    out.connect(lp).connect(c.destination);
    [[1, 1, 'triangle'], [2, 0.35, 'sine'], [3, 0.12, 'sine'], [1.003, 0.4, 'sine']].forEach(([mul, g, type]) => {
      const o = c.createOscillator();
      const og = c.createGain();
      o.type = type;
      o.frequency.value = freq(m) * mul;
      og.gain.value = g;
      o.connect(og).connect(out);
      o.start(t);
      o.stop(t + dur + 1);
    });
    // eigenes Spiel nicht über das Mikrofon wieder „hören“
    st.mic.quietUntil = Math.max(st.mic.quietUntil, performance.now() + (when + dur) * 1000 + 350);
  }
  function playSeq(notes, bpm = 100) {
    const beat = 60 / bpm;
    let t = 0.05;
    for (const n of notes) {
      if (n.m != null) playNote(n.m, Math.max(0.25, n.d * beat * 0.95), t);
      t += n.d * beat;
    }
    return t;
  }
  function playChord(c, when = 0) {
    for (const m of c.notes) playNote(m, 1.4, when, 0.4);
  }

  /* ================================================================== Eingaben: Mikrofon, MIDI, Tastatur, Maus */
  function noteOn(m, src) {
    st.heard = { m, cents: 0, at: Date.now() };
    flashKey(m);
    if (src !== 'mic') playNote(m, 0.8);
    handleNote(m, src);
  }

  // Tonhöhe (Autokorrelation, „ACF2+“)
  function pitch(buf, sr) {
    let n = buf.length, rms = 0;
    for (let i = 0; i < n; i++) rms += buf[i] * buf[i];
    rms = Math.sqrt(rms / n);
    st.mic.rms = rms;
    if (rms < 0.02) return -1; // leise Geräusche (Reden, Lüfter) zählen nicht als Ton
    let r1 = 0, r2 = n - 1;
    const th = 0.2;
    for (let i = 0; i < n / 2; i++) if (Math.abs(buf[i]) < th) { r1 = i; break; }
    for (let i = 1; i < n / 2; i++) if (Math.abs(buf[n - i]) < th) { r2 = n - i; break; }
    const b = buf.slice(r1, r2);
    n = b.length;
    const c = new Float32Array(n);
    for (let i = 0; i < n; i++) { let s = 0; for (let j = 0; j < n - i; j++) s += b[j] * b[j + i]; c[i] = s; }
    let d = 0;
    while (d < n - 1 && c[d] > c[d + 1]) d++;
    let max = -1, T = -1;
    for (let i = d; i < n; i++) if (c[i] > max) { max = c[i]; T = i; }
    if (T <= 0 || T >= n - 1) return -1;
    const x1 = c[T - 1], x2 = c[T], x3 = c[T + 1];
    const a = (x1 + x3 - 2 * x2) / 2, bb = (x3 - x1) / 2;
    const T0 = a ? T - bb / (2 * a) : T;
    return sr / T0;
  }

  function micStart() {
    const M = st.mic;
    if (M.on) return Promise.resolve(true);
    if (!M.starting) M.starting = micOpen().finally(() => { M.starting = null; });
    return M.starting;
  }
  async function micOpen() {
    const M = st.mic;
    try {
      M.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    } catch {
      A.toast('Kein Mikrofon gefunden oder Zugriff verweigert.', 'error');
      return false;
    }
    M.ac = new AudioContext();
    const src = M.ac.createMediaStreamSource(M.stream);
    M.an = M.ac.createAnalyser();
    M.an.fftSize = 2048;
    M.fan = M.ac.createAnalyser();
    M.fan.fftSize = 16384;
    M.fan.smoothingTimeConstant = 0.5;
    src.connect(M.an);
    src.connect(M.fan);
    M.on = true;
    const buf = new Float32Array(M.an.fftSize);
    const spec = new Float32Array(M.fan.frequencyBinCount);
    let tick = 0, lastRms = 0;
    const loop = () => {
      if (!M.on) return;
      M.raf = requestAnimationFrame(loop);
      if (++tick % 2) return; // ca. 30 Messungen/s reichen
      M.an.getFloatTimeDomainData(buf);
      const f = pitch(buf, M.ac.sampleRate);
      const now = performance.now();
      if (now < M.quietUntil) { M.emitted = -1; return; }
      if (f > 50 && f < 2200 && M.rms > 0.02) {
        const exact = 69 + 12 * Math.log2(f / 440);
        const m = Math.round(exact);
        st.heard = { m, cents: Math.round((exact - m) * 100), at: Date.now() };
        if (m === M.cand) M.stable++;
        else { M.cand = m; M.stable = 1; }
        const restrike = M.rms > lastRms * 1.8 && M.rms > 0.03;
        if (M.stable >= 3 && (m !== M.emitted || restrike)) { M.emitted = m; handleNote(m, 'mic'); flashKey(m); }
      } else if (M.rms < 0.008) {
        M.emitted = -1;
        M.cand = -1;
      }
      lastRms = M.rms;
      // Akkorde: Chroma-Spektrum (welche der 12 Tonklassen klingen)
      if (expectChord()) {
        M.fan.getFloatFrequencyData(spec);
        const binHz = M.ac.sampleRate / M.fan.fftSize;
        const ch = new Float32Array(12);
        for (let i = Math.floor(60 / binHz); i < Math.min(spec.length, 1400 / binHz); i++) {
          const mag = 10 ** (spec[i] / 20);
          const pc = Math.round(12 * Math.log2((i * binHz) / 440) + 69);
          ch[((pc % 12) + 12) % 12] += mag * mag;
        }
        M.chroma = ch;
        checkChordFromChroma(ch);
      }
      paintTuner();
      const lv = st.root?.querySelector('[data-pn-level]');
      if (lv) lv.style.width = `${Math.min(100, Math.round(M.rms * 900))}%`;
    };
    loop();
    return true;
  }
  function micStop() {
    const M = st.mic;
    M.on = false;
    cancelAnimationFrame(M.raf);
    M.stream?.getTracks().forEach((t) => t.stop());
    M.ac?.close().catch(() => {});
    Object.assign(M, { stream: null, ac: null, an: null, fan: null });
  }

  async function midiStart() {
    if (st.midi || !navigator.requestMIDIAccess) return;
    try {
      st.midi = await navigator.requestMIDIAccess();
      const bind = () => st.midi.inputs.forEach((inp) => {
        inp.onmidimessage = (e) => {
          const [s, n, v] = e.data;
          if ((s & 0xf0) === 0x90 && v > 0) { st.held.set(n, Date.now()); noteOn(n, 'midi'); }
          else if ((s & 0xf0) === 0x80 || ((s & 0xf0) === 0x90 && v === 0)) st.held.delete(n);
        };
      });
      bind();
      st.midi.onstatechange = bind;
    } catch {
      st.midi = null;
    }
  }

  // Computertastatur (QWERTZ): weiße Tasten A S D F G H J K L Ö, schwarze W E T Z U O P
  const KEYMAP = { a: 'C4', w: 'C#4', s: 'D4', e: 'D#4', d: 'E4', f: 'F4', t: 'F#4', g: 'G4', z: 'G#4', h: 'A4', u: 'A#4', j: 'B4', k: 'C5', o: 'C#5', l: 'D5', p: 'D#5', ö: 'E5' };
  function onKey(e) {
    if (!st.root || !document.contains(st.root) || e.repeat || e.ctrlKey || e.altKey || e.metaKey) return;
    if (/input|textarea|select/i.test(e.target?.tagName || '')) return;
    const n = KEYMAP[e.key.toLowerCase()];
    if (!n) return;
    e.preventDefault();
    const m = toMidi(n);
    st.held.set(m, Date.now());
    noteOn(m, 'key');
  }
  function onKeyUp(e) {
    const n = KEYMAP[e.key?.toLowerCase()];
    if (n) setTimeout(() => st.held.delete(toMidi(n)), 400);
  }

  /* ================================================================== Lektionen */
  const expectChord = () => st.view?.task?.type === 'chord';
  function buildTasks(lesson) {
    const d = lesson.data;
    const rnd = () => d.pool[Math.floor(Math.random() * d.pool.length)];
    if (lesson.kind === 'find' || lesson.kind === 'ear') {
      const out = [];
      let last = -1;
      for (let i = 0; i < d.count; i++) {
        let m = rnd();
        if (d.pool.length > 1) while (m === last) m = rnd();
        last = m;
        out.push({ type: lesson.kind, m });
      }
      if (lesson.id === 'find-c') return [W('C4')[0], W('C4')[0], W('C3')[0], W('C5')[0]].map((m) => ({ type: 'find', m, anyOct: true }));
      return out;
    }
    if (lesson.kind === 'chord') return d.list.map((c) => ({ type: 'chord', c: chordById(c) }));
    const notes = lesson.kind === 'song' ? songById(d.song).n : d.n;
    return [{ type: 'seq', notes: notes.filter((n) => n.m != null), song: lesson.kind === 'song' ? songById(d.song) : null, pos: 0 }];
  }
  function startLesson(lesson, opts = {}) {
    roll.shown = 0;
    st.view = { lesson, tasks: buildTasks(lesson), i: 0, err: 0, ok: 0, run: 0, task: null, hint: Boolean(lesson.data?.hint), free: Boolean(opts.free), started: Date.now() };
    st.view.task = st.view.tasks[0];
    coach(line('start', { l: lesson.t }), 'happy', true);
    if (!st.mic.on) micStart();
    paint();
    if (st.view.task.type === 'ear') setTimeout(() => playNote(st.view.task.m, 1.1), 700);
  }
  function startSong(song) {
    startLesson({ id: `song:${song.id}`, t: song.t, kind: 'song', data: { song: song.id }, icon: '🎵', col: '#ff375f' }, { free: true });
  }
  function startChordDrill(c) {
    startLesson({ id: `chord:${c.id}`, t: chordName(c), kind: 'chord', data: { list: [c.id, c.id, c.id] }, icon: '🤘', col: '#ff9f0a' }, { free: true });
  }

  let lastNoteAt = 0, lastNoteM = -1;
  function handleNote(m, src) {
    const v = st.view;
    if (!v || !v.task || v.finished) return;
    const now = Date.now();
    // Mikrofon-Doppler (gleicher Ton kurz hintereinander) ignorieren
    if (src === 'mic' && m === lastNoteM && now - lastNoteAt < 220) return;
    lastNoteAt = now;
    lastNoteM = m;
    const t = v.task;
    if (t.type === 'chord') return checkChordFromHeld();
    const want = t.type === 'seq' ? t.notes[t.pos].m : t.m;
    const okPc = ((m - want) % 12 + 12) % 12 === 0;
    // Mikrofon: Oktave egal (Klaviere klingen oft eine Oktave „daneben“); sonst genau – außer bei „Das ist C“ und Gehör
    const ok = m === want || (okPc && (src === 'mic' || t.anyOct || t.type === 'ear'));
    if (ok) {
      v.ok++;
      v.run++;
      bump(st.data.noteOk, want);
      if (t.type === 'seq') {
        t.pos++;
        if (v.run > 0 && v.run % 10 === 0) coach(line('streak', { n: v.run }), 'happy', true);
        if (t.pos >= t.notes.length) return nextTask(true);
        paintLesson();
        return;
      }
      if (v.run >= 5 && v.run % 5 === 0) coach(line('streak', { n: v.run }), 'happy', true);
      else coach(line('good'), 'happy', Math.random() < 0.25);
      return nextTask(true);
    }
    // falscher Ton
    v.err++;
    v.run = 0;
    bump(st.data.noteErr, want);
    v.wrong = m;
    const many = v.err % 3 === 0;
    coach(many ? line('missTip') : line('miss', { got: name(m), want: name(want) }), 'worried', many);
    if (many) v.hint = true;
    paintLesson();
  }
  function checkChordFromHeld() {
    const v = st.view;
    const c = v?.task?.c;
    if (!c) return;
    const now = Date.now();
    const pcs = new Set([...st.held].filter(([, at]) => now - at < 2200).map(([m]) => ((m % 12) + 12) % 12));
    const need = c.notes.map((m) => m % 12);
    if (need.every((p) => pcs.has(p))) chordHit(c);
    else if (pcs.size >= need.length) {
      // genug Tasten gedrückt, aber falsche Kombination
      v.err++;
      v.run = 0;
      bump(st.data.chordErr, c.id);
      coach(`Fast! Für ${chordName(c)} brauchst du ${need.map((p) => DE[p]).join(', ')}.`, 'worried', v.err % 3 === 0);
      st.held.clear();
      v.hint = true;
      paintLesson();
    }
  }
  function checkChordFromChroma(ch) {
    const c = st.view?.task?.c;
    if (!c || performance.now() < st.mic.quietUntil) return;
    const max = Math.max(...ch);
    if (max <= 0 || st.mic.rms < 0.02) { st.mic.chordHits = 0; return; }
    const need = new Set(c.notes.map((m) => m % 12));
    let inSum = 0, outSum = 0, minIn = 1;
    for (let p = 0; p < 12; p++) {
      const v = ch[p] / max;
      if (need.has(p)) { inSum += v; minIn = Math.min(minIn, v); } else outSum += v;
    }
    const inAvg = inSum / need.size, outAvg = outSum / (12 - need.size);
    if (minIn > 0.12 && outAvg < inAvg * 0.45) st.mic.chordHits++;
    else st.mic.chordHits = 0;
    if (st.mic.chordHits >= 4) { st.mic.chordHits = 0; chordHit(c); }
  }
  function chordHit(c) {
    const v = st.view;
    if (!v || v.task?.c !== c) return;
    v.ok++;
    v.run++;
    bump(st.data.chordOk, c.id);
    st.held.clear();
    c.notes.forEach((m, i) => setTimeout(() => flashKey(m), i * 30));
    coach(line('chordGood'), 'happy', Math.random() < 0.35);
    nextTask(true);
  }
  function nextTask() {
    const v = st.view;
    v.i++;
    v.wrong = null;
    if (v.i >= v.tasks.length) return finish();
    v.task = v.tasks[v.i];
    if (!v.lesson.data?.hint && v.task.type !== 'seq') v.hint = false;
    paintLesson();
    if (v.task.type === 'ear') setTimeout(() => playNote(v.task.m, 1.1), 450);
  }
  function finish() {
    const v = st.view;
    v.finished = true;
    const total = v.ok + v.err;
    const acc = total ? v.ok / total : 1;
    const stars = v.err === 0 ? 3 : acc >= 0.8 ? 2 : 1;
    const xp = 10 + stars * 5;
    const d = st.data;
    touchStreak();
    d.xp = (d.xp || 0) + xp;
    const prev = d.done[v.lesson.id]?.stars || 0;
    d.done[v.lesson.id] = { stars: Math.max(prev, stars), at: Date.now() };
    if (v.lesson.kind === 'song') {
      const id = v.lesson.data.song;
      d.songs[id] = { best: Math.max(d.songs[id]?.best || 0, Math.round(acc * 100)), plays: (d.songs[id]?.plays || 0) + 1 };
    }
    save();
    v.result = { stars, xp, acc: Math.round(acc * 100) };
    const s = v.lesson.kind === 'song' ? songById(v.lesson.data.song)?.t : '';
    const msg = stars === 3 ? `${line(s ? 'songDone' : 'done', { l: v.lesson.t, s })} ${line('perfect')}` : line(s ? 'songDone' : 'done', { l: v.lesson.t, s });
    coach(msg, 'happy', true);
    if (stars === 3) A.earn?.(2);
    paint();
  }
  const bump = (obj, k) => { obj[k] = (obj[k] || 0) + 1; save(); };

  /* ================================================================== Coach: Zusammenfassung */
  function nextLesson() {
    return ALL_LESSONS.find((l) => !st.data.done[l.id]) || null;
  }
  const unlocked = (l) => { const i = ALL_LESSONS.indexOf(l); return i <= 0 || Boolean(st.data.done[ALL_LESSONS[i - 1].id]); };
  function summary() {
    const d = st.data;
    const tips = [];
    const weakNotes = Object.entries(d.noteErr).map(([m, e]) => ({ m: Number(m), e, r: e / (e + (d.noteOk[m] || 0)) })).filter((x) => x.e >= 2).sort((a, b) => b.r - a.r).slice(0, 3);
    const weakChords = Object.entries(d.chordErr).map(([c, e]) => ({ c, e, r: e / (e + (d.chordOk[c] || 0)) })).filter((x) => x.e >= 2).sort((a, b) => b.r - a.r).slice(0, 2);
    const nx = nextLesson();
    const doneN = Object.keys(d.done).length;
    if (!doneN) tips.push('Fang mit der ersten Lektion an: Wir suchen zusammen das C. Das dauert nur zwei Minuten.');
    if (weakNotes.length) tips.push(`Übe noch die Töne ${weakNotes.map((x) => name(x.m)).join(', ')} – da hakt es manchmal. Die Lektion „${weakNotes.some((x) => isBlack(x.m)) ? 'Die schwarzen Tasten' : 'A, H und das hohe C'}“ hilft dabei.`);
    if (weakChords.length) tips.push(`Der Akkord ${weakChords.map((x) => chordName(chordById(x.c) || { kind: '', id: x.c })).join(' und ')} braucht noch etwas Übung. Unter „Akkorde“ kannst du ihn gezielt trainieren.`);
    const tried = Object.keys(d.songs);
    const weakSong = tried.map((id) => ({ s: songById(id), b: d.songs[id].best })).filter((x) => x.s && x.b < 85).sort((a, b) => a.b - b.b)[0];
    if (weakSong) tip(`Bei „${weakSong.s.t}“ hattest du ${weakSong.b} Prozent. Spiel es nochmal langsam – es wird jedes Mal besser.`);
    if (nx) tips.push(`Als Nächstes im Lernpfad: „${nx.t}“.`);
    const fresh = SONGS.filter((s) => !d.songs[s.id] && s.lv <= Math.max(1, Math.ceil((doneN + 1) / 7))).slice(0, 2);
    if (fresh.length) tips.push(`Noch nicht probiert: ${fresh.map((s) => `„${s.t}“`).join(' und ')}.`);
    if (d.streak >= 2) tips.push(`Du übst seit ${d.streak} Tagen am Stück – Bravo, bleib dran!`);
    else if (doneN) tips.push(line('idle'));
    function tip(t) { tips.push(t); }
    return tips;
  }

  /* ================================================================== Coach: Sprechen */
  let speakSeq = 0;
  function coach(text, mood = 'happy', speak = false) {
    st.coach.text = text;
    st.coach.mood = mood;
    const b = st.root?.querySelector('[data-pn-bubble]');
    if (b) { b.textContent = text; b.parentElement?.classList.toggle('worried', mood === 'worried'); b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop'); }
    if (speak && st.coach.voice && Date.now() - st.coach.lastSpeak > 1800) sayAloud(text);
  }
  async function sayAloud(text) {
    st.coach.lastSpeak = Date.now();
    const id = ++speakSeq;
    try {
      if (st.coach.ready === null) {
        const s = await window.hub.coach?.status?.().catch(() => null);
        st.coach.ready = Boolean(s?.installed);
      }
      if (st.coach.ready) {
        const bytes = await window.hub.coach.speak(text);
        if (id !== speakSeq) return;
        const c = audio();
        const buf = await c.decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
        if (id !== speakSeq) return;
        st.coach.src?.stop?.();
        const src = c.createBufferSource();
        const an = c.createAnalyser();
        an.fftSize = 512;
        src.buffer = buf;
        src.connect(an).connect(c.destination);
        st.coach.src = src;
        st.mic.quietUntil = Math.max(st.mic.quietUntil, performance.now() + buf.duration * 1000 + 300);
        talk(an, src);
        src.start();
        return;
      }
    } catch {
      /* dann Windows-Stimme */
    }
    const synth = window.speechSynthesis;
    if (!synth) return;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const vs = synth.getVoices().filter((v) => v.lang?.toLowerCase().startsWith('de'));
    u.voice = vs.find((v) => /hedda|katja|female|frau/i.test(v.name)) || vs[0] || null;
    u.lang = 'de-DE';
    u.rate = 1.02;
    synth.speak(u);
  }
  function talk(an, src) {
    const mouth = st.root?.querySelector('.pn-mouth');
    const data = new Uint8Array(an.fftSize);
    const face = st.root?.querySelector('.pn-coach');
    face?.classList.add('talking');
    let alive = true;
    src.onended = () => { alive = false; face?.classList.remove('talking'); mouth?.setAttribute('d', MOUTH.smile); };
    const loop = () => {
      if (!alive) return;
      an.getByteTimeDomainData(data);
      let s = 0;
      for (const v of data) s += (v - 128) ** 2;
      const rms = Math.sqrt(s / data.length) / 128;
      mouth?.setAttribute('d', rms > 0.12 ? MOUTH.open : rms > 0.05 ? MOUTH.half : MOUTH.smile);
      requestAnimationFrame(loop);
    };
    loop();
  }
  const MOUTH = { smile: 'M47 72q13 9 26 0', half: 'M48 71q12 0 24 0q-12 8-24 0Z', open: 'M48 69q12-3 24 0q-12 14-24 0Z', worried: 'M50 77q10-6 20 0' };
  const coachFace = () => `<svg viewBox="0 0 120 120" class="pn-face" aria-hidden="true">
    <defs><radialGradient id="pn-skin" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#f6d2b3"/><stop offset="1" stop-color="#e2b58e"/></radialGradient></defs>
    <path d="M18 60c-4 26 0 44 10 54h64c10-10 14-28 10-54Z" fill="#2b1a33"/>
    <path d="M24 114c3-17 17-27 36-27s33 10 36 27Z" fill="#5e3bd8"/>
    <circle cx="60" cy="55" r="33" fill="url(#pn-skin)"/>
    <path d="M26 56c-3-27 13-43 35-43 21 0 37 15 34 43-5-14-14-22-27-25-9 6-24 8-42 25Z" fill="#3b2442"/>
    <g fill="#2a1a12"><ellipse cx="47" cy="55" rx="4.5" ry="5.5"/><ellipse cx="73" cy="55" rx="4.5" ry="5.5"/></g>
    <circle cx="48.5" cy="53" r="1.5" fill="#fff"/><circle cx="74.5" cy="53" r="1.5" fill="#fff"/>
    <ellipse cx="36" cy="66" rx="6" ry="3.4" fill="#ef9a8f" opacity=".35"/><ellipse cx="84" cy="66" rx="6" ry="3.4" fill="#ef9a8f" opacity=".35"/>
    <path class="pn-mouth" d="${MOUTH.smile}" fill="#7a2e2e" stroke="#7a2e2e" stroke-width="2.4" stroke-linecap="round"/>
    <g transform="translate(86 20) rotate(14)"><rect x="0" y="0" width="5" height="18" rx="2" fill="#ffd60a"/><circle cx="2.5" cy="19" r="5" fill="#ffd60a"/></g>
  </svg>`;

  /* ================================================================== Zeichnen */
  function keyboardHtml(from = 48, to = 84, mark = {}) {
    const whites = [];
    for (let m = from; m <= to; m++) if (!isBlack(m)) whites.push(m);
    const wPct = 100 / whites.length;
    let wi = 0;
    let html = '';
    for (let m = from; m <= to; m++) {
      const cls = [mark.target?.includes(m) ? 'target' : '', mark.wrong === m ? 'wrong' : ''].join(' ');
      const label = mark.labels ? `<span>${name(m)}${m % 12 === 0 ? `<small>${Math.floor(m / 12) - 1}</small>` : ''}</span>` : '';
      if (isBlack(m)) html += `<button class="pn-k b ${cls}" data-pn-key="${m}" style="left:calc(${wi * wPct}% - ${wPct * 0.32}%);width:${wPct * 0.64}%">${mark.labels ? '' : ''}</button>`;
      else { html += `<button class="pn-k w ${cls}" data-pn-key="${m}" style="left:${wi * wPct}%;width:${wPct}%">${label}</button>`; wi++; }
    }
    return `<div class="pn-kb" data-pn-kb>${html}</div>`;
  }
  function flashKey(m) {
    const k = st.root?.querySelector(`[data-pn-key="${m}"]`);
    if (!k) return;
    k.classList.remove('hit');
    void k.offsetWidth;
    k.classList.add('hit');
  }

  function headerHtml() {
    const d = st.data;
    return `<div class="pn-head"><div><h2>Klavier</h2><p class="muted">Lernen mit Mikrofon, MIDI-Keyboard oder Tastatur</p></div>
      <div class="pn-stats"><span title="Tage am Stück">🔥 <b>${d.streak || 0}</b></span><span title="Erfahrungspunkte">⚡ <b>${d.xp || 0}</b> XP</span>
      ${micButton()}</div></div>
      <nav class="pn-tabs">${[['path', 'Lernpfad'], ['songs', 'Lieder'], ['chords', 'Akkorde'], ['free', 'Frei spielen'], ['coach', 'Coach']].map(([k, t]) => `<button class="${st.tab === k ? 'on' : ''}" data-pn-tab="${k}">${t}</button>`).join('')}</nav>`;
  }
  function coachHtml(big = false) {
    return `<div class="pn-coach ${big ? 'big' : ''} ${st.coach.mood === 'worried' ? 'worried' : ''}">${coachFace()}<div class="pn-bubble" data-pn-bubble>${esc(st.coach.text || line('hello'))}</div></div>`;
  }
  function pathHtml() {
    const d = st.data;
    let n = 0;
    return `<div class="pn-path">${UNITS.map((u, ui) => `<section class="pn-unit" style="--c:${u.col}">
        <div class="pn-unit-head rv-card"><b>Einheit ${ui + 1} · ${esc(u.t)}</b><small>${esc(u.sub)}</small></div>
        <div class="pn-nodes">${u.ls.map((l) => {
          const full = ALL_LESSONS.find((x) => x.id === l.id);
          const open = unlocked(full);
          const done = d.done[l.id];
          const cur = open && !done;
          const off = Math.sin(n++ * 1.1) * 70;
          return `<div class="pn-node-wrap" style="transform:translateX(${off.toFixed(0)}px)"><button class="pn-node ${done ? 'done' : ''} ${cur ? 'cur' : ''} ${open ? '' : 'locked'}" data-pn-lesson="${l.id}" ${open ? '' : 'disabled'} title="${esc(l.t)}"><span>${open ? l.icon : '🔒'}</span></button>
            <small>${esc(l.t)}</small>${done ? `<i class="pn-stars">${'★'.repeat(done.stars)}${'☆'.repeat(3 - done.stars)}</i>` : cur ? '<i class="pn-start">START</i>' : ''}</div>`;
        }).join('')}</div></section>`).join('')}</div>`;
  }
  function songsHtml() {
    const d = st.data;
    return `<div class="pn-grid">${SONGS.map((s) => `<div class="pn-song rv-card"><div class="pn-song-top"><span class="pn-lv l${s.lv}">${['', 'Leicht', 'Mittel', 'Schwer'][s.lv]}</span>${d.songs[s.id] ? `<span class="pn-best">${d.songs[s.id].best}%</span>` : ''}</div>
      <b>${esc(s.t)}</b><small>${esc(s.by)} · ${s.n.filter((x) => x.m != null).length} Töne</small>
      <div class="pn-song-btns"><button class="btn small primary" data-pn-song="${s.id}">Üben</button><button class="btn small ghost" data-pn-listen="${s.id}">▶ Anhören</button></div></div>`).join('')}</div>
      <p class="pn-note muted">Alle Lieder sind gemeinfrei (Klassik und Volkslieder) – die rechte Hand mit der Melodie.</p>`;
  }
  function chordsHtml() {
    const d = st.data;
    return `<div class="pn-grid">${CHORDS.map((c) => `<div class="pn-chord rv-card"><div class="pn-chord-top"><b>${esc(chordName(c))}</b><small>${esc(c.kind)}</small></div>
      <div class="pn-mini">${keyboardHtml(Math.min(...c.notes) - (isBlack(Math.min(...c.notes) - 1) ? 2 : 1), Math.max(...c.notes) + 2, { target: c.notes })}</div>
      <p>${c.notes.map(name).join(' · ')}</p><small class="muted">${esc(c.tip)}</small>
      <div class="pn-song-btns"><button class="btn small primary" data-pn-chord="${c.id}">Üben</button><button class="btn small ghost" data-pn-hear="${c.id}">▶ Anhören</button>${d.chordOk[c.id] ? `<span class="pn-best">✓ ${d.chordOk[c.id]}</span>` : ''}</div></div>`).join('')}</div>`;
  }
  function freeHtml() {
    return `<div class="pn-free rv-card"><div class="pn-tuner" data-pn-tuner><b data-pn-tn>–</b><small data-pn-tc>Spiel einen Ton${st.mic.on ? '' : ' – oder schalte das Mikrofon an'}</small><div class="pn-cents"><i data-pn-tbar></i></div></div>
      <p class="muted">Tastatur: <kbd>A</kbd>–<kbd>Ö</kbd> weiße Tasten, <kbd>W E T Z U O P</kbd> schwarze. Ein MIDI-Keyboard wird automatisch erkannt.</p></div>
      ${keyboardHtml(48, 84, { labels: true })}`;
  }
  function coachTabHtml() {
    const tips = summary();
    const d = st.data;
    const doneN = Object.keys(d.done).length;
    return `<div class="pn-coachtab">${coachHtml(true)}
      <div class="pn-sum rv-card"><h3>Dein Stand</h3>
        <div class="pn-kpis"><span><b>${doneN}</b>/${ALL_LESSONS.length} Lektionen</span><span><b>${Object.keys(d.songs).length}</b> Lieder gespielt</span><span><b>${Object.values(d.chordOk).reduce((a, b) => a + b, 0)}</b> Akkorde</span><span><b>${d.streak || 0}</b> Tage Serie</span></div>
        <h3>Das kannst du üben</h3><ul>${tips.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>
        <div class="pn-song-btns"><button class="btn primary" data-pn-say>🔊 Coach fragen</button>${nextLesson() ? `<button class="btn" data-pn-lesson="${nextLesson().id}">Nächste Lektion</button>` : ''}
        <label class="pn-voice"><input type="checkbox" data-pn-voice ${st.coach.voice ? 'checked' : ''}/> Coach spricht</label></div></div></div>`;
  }
  function lessonHtml() {
    const v = st.view;
    const t = v.task;
    const prog = v.result ? 1 : t?.type === 'seq' ? t.pos / t.notes.length : v.i / v.tasks.length;
    if (v.result) {
      const r = v.result;
      return `<div class="pn-lesson"><div class="pn-lbar"><button class="pn-x" data-pn-close title="Schließen">✕</button><div class="pn-prog"><i style="width:100%"></i></div></div>
        <div class="pn-done"><div class="pn-bigstars">${[1, 2, 3].map((i) => `<span class="${i <= r.stars ? 'on' : ''}" style="--i:${i}">★</span>`).join('')}</div>
        <h2>${r.stars === 3 ? 'Perfekt!' : r.stars === 2 ? 'Sehr gut!' : 'Geschafft!'}</h2><p>${r.acc}% richtig · +${r.xp} XP</p>${coachHtml()}
        <div class="pn-song-btns"><button class="btn primary" data-pn-continue>Weiter</button><button class="btn ghost" data-pn-again>Nochmal</button></div></div></div>`;
    }
    let task = '';
    let mark = { labels: v.hint };
    if (t.type === 'find') { task = `<div class="pn-q"><small>Spiel den Ton</small><b>${esc(name(t.m))}</b>${t.anyOct ? '<em>irgendein C</em>' : ''}</div>`; if (v.hint) mark.target = [t.m]; }
    if (t.type === 'ear') { task = `<div class="pn-q"><small>Hör genau hin und spiel nach</small><button class="pn-ear" data-pn-replay>🔊 Nochmal hören</button>${v.hint ? `<em>Tipp: ${esc(name(t.m))}</em>` : ''}</div>`; }
    if (t.type === 'chord') { task = `<div class="pn-q"><small>Spiel den Akkord</small><b>${esc(chordName(t.c))}</b><em>${t.c.notes.map(name).join(' · ')}</em></div>`; mark.target = t.c.notes; }
    let roll = '';
    let [lo, hi] = [48, 84];
    if (t.type === 'seq') {
      task = `<div class="pn-q small"><small>${t.song ? esc(t.song.t) : 'Spiel die Melodie'} · Ton ${Math.min(t.pos + 1, t.notes.length)} von ${t.notes.length}</small><button class="pn-ear" data-pn-preview>▶ Anhören</button></div>`;
      mark.target = [t.notes[t.pos]?.m];
      mark.labels = true;
      // Tastatur-Ausschnitt passend zum Lied (große Tasten), Noten fallen von oben auf die Tasten
      const ms = t.notes.map((n) => n.m);
      lo = Math.min(...ms) - 2;
      while (lo % 12 !== 0 && lo % 12 !== 5) lo--; // bei C oder F beginnen
      hi = Math.max(...ms) + 2;
      while (isBlack(hi)) hi++;
      if (hi - lo < 24) hi = lo + 24;
      roll = '<div class="pn-roll" data-pn-roll><canvas></canvas></div>';
    }
    if (v.wrong != null) mark.wrong = v.wrong;
    if (t.type === 'chord') lo = Math.min(48, ...t.c.notes);
    st.kbRange = [lo, hi];
    return `<div class="pn-lesson"><div class="pn-lbar"><button class="pn-x" data-pn-close title="Schließen">✕</button><div class="pn-prog" style="--c:${v.lesson.col || '#30d158'}"><i style="width:${Math.round(prog * 100)}%"></i></div><span class="pn-run">${v.run >= 3 ? `🔥 ${v.run}` : ''}</span>${micButton()}</div>
      <div class="pn-stage">${coachHtml()}${task}</div>
      ${st.mic.on ? '' : '<p class="pn-hintmic">Das Mikrofon ist aus – tippe oben auf 🎙, dann höre ich dein echtes Klavier. Du kannst auch auf der Tastatur unten spielen.</p>'}
      <div class="pn-bottom">${roll}${keyboardHtml(lo, hi, mark)}</div></div>`;
  }

  /* ------------------------------------------------------------------ fallende Noten (Canvas) */
  const roll = { raf: 0, shown: 0 };
  function keyRect(m, lo, hi) {
    const whites = [];
    for (let k = lo; k <= hi; k++) if (!isBlack(k)) whites.push(k);
    const w = 1 / whites.length;
    if (!isBlack(m)) return { x: whites.indexOf(m) * w, w };
    const left = whites.filter((k) => k < m).length;
    return { x: left * w - w * 0.32, w: w * 0.64 };
  }
  function drawRoll() {
    cancelAnimationFrame(roll.raf);
    const box = st.root?.querySelector('[data-pn-roll]');
    const t = st.view?.task;
    if (!box || !t || t.type !== 'seq') return;
    const cv = box.querySelector('canvas');
    const dpr = window.devicePixelRatio || 1;
    const W = box.clientWidth, H = box.clientHeight;
    cv.width = W * dpr;
    cv.height = H * dpr;
    const g = cv.getContext('2d');
    g.scale(dpr, dpr);
    const [lo, hi] = st.kbRange;
    const PX = 46; // Pixel pro Schlag
    const frame = () => {
      // weich zum aktuellen Ton gleiten
      roll.shown += (t.pos - roll.shown) * 0.18;
      if (Math.abs(t.pos - roll.shown) < 0.002) roll.shown = t.pos;
      g.clearRect(0, 0, W, H);
      // Hilfslinien an jedem C
      for (let k = lo; k <= hi; k++) if (k % 12 === 0) { const r = keyRect(k, lo, hi); g.fillStyle = 'rgba(255,255,255,.06)'; g.fillRect(r.x * W, 0, 1, H); }
      // Startzeit (in Schlägen) jedes Tons relativ zum gerade gespielten
      let beat = 0;
      const startAt = [];
      for (const n of t.notes) { startAt.push(beat); beat += n.d; }
      const base = interp(startAt, roll.shown);
      t.notes.forEach((n, i) => {
        const y0 = H - (startAt[i] - base) * PX; // Unterkante
        const h = Math.max(14, n.d * PX - 4);
        if (y0 < -10 || y0 - h > H) return;
        const r = keyRect(n.m, lo, hi);
        const x = r.x * W + 2, w = r.w * W - 4;
        const done = i < t.pos, now = i === t.pos;
        const col = done ? 'rgba(48,209,88,.35)' : isBlack(n.m) ? '#7c3aed' : '#0a84ff';
        g.save();
        if (now) { g.shadowColor = '#5ac8fa'; g.shadowBlur = 18; }
        g.fillStyle = now ? '#5ac8fa' : col;
        roundRect(g, x, y0 - h, w, h, 6);
        g.fill();
        g.restore();
        if (w > 18 && h > 16) { g.fillStyle = done ? 'rgba(255,255,255,.5)' : '#fff'; g.font = '700 11px Segoe UI'; g.textAlign = 'center'; g.fillText(name(n.m), x + w / 2, y0 - 6); }
      });
      if (st.view?.task === t && document.contains(cv)) roll.raf = requestAnimationFrame(frame);
    };
    frame();
  }
  function interp(arr, f) {
    const i = Math.floor(f);
    if (i >= arr.length - 1) return arr[arr.length - 1] + (f - (arr.length - 1));
    return arr[i] + (arr[i + 1] - arr[i]) * (f - i);
  }
  function roundRect(g, x, y, w, h, r) {
    g.beginPath();
    g.moveTo(x + r, y);
    g.arcTo(x + w, y, x + w, y + h, r);
    g.arcTo(x + w, y + h, x, y + h, r);
    g.arcTo(x, y + h, x, y, r);
    g.arcTo(x, y, x + w, y, r);
    g.closePath();
  }
  const micButton = () => `<button class="pn-mic ${st.mic.on ? 'on' : ''}" data-pn-mic title="${st.mic.on ? 'Mikrofon aus' : 'Mikrofon an – ich höre dein Klavier'}">🎙 ${st.mic.on ? 'Hört zu' : 'Mikrofon'}<span class="pn-level"><i data-pn-level></i></span></button>`;

  function paint() {
    if (!st.root || !st.data) return;
    if (st.view) return paintLesson();
    const body = st.tab === 'songs' ? songsHtml() : st.tab === 'chords' ? chordsHtml() : st.tab === 'free' ? freeHtml() : st.tab === 'coach' ? coachTabHtml() : `${coachHtml()}${pathHtml()}`;
    st.root.innerHTML = `<div class="pn">${headerHtml()}<div class="pn-body">${body}</div></div>`;
  }
  function paintLesson() {
    if (!st.root) return;
    st.root.innerHTML = `<div class="pn in-lesson">${lessonHtml()}</div>`;
    requestAnimationFrame(drawRoll);
  }
  function paintTuner() {
    if (st.tab !== 'free' || st.view) return;
    const n = st.root?.querySelector('[data-pn-tn]');
    if (!n) return;
    const fresh = Date.now() - st.heard.at < 600;
    n.textContent = fresh && st.heard.m > 0 ? fullName(st.heard.m) : '–';
    const c = st.root.querySelector('[data-pn-tc]');
    if (c && fresh) c.textContent = st.heard.cents ? `${st.heard.cents > 0 ? '+' : ''}${st.heard.cents} Cent` : 'genau getroffen';
    const bar = st.root.querySelector('[data-pn-tbar]');
    if (bar) bar.style.left = `${50 + (fresh ? st.heard.cents : 0) / 1}%`;
  }

  /* ================================================================== Klicks */
  function onClick(e) {
    if (!st.root || !st.root.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    let el;
    if ((el = q('[data-pn-key]'))) { const m = Number(el.dataset.pnKey); st.held.set(m, Date.now()); return noteOn(m, 'mouse'); }
    if ((el = q('[data-pn-tab]'))) { st.tab = el.dataset.pnTab; return paint(); }
    if (q('[data-pn-mic]')) { if (st.mic.on) micStop(); else return micStart().then(paint); return paint(); }
    if ((el = q('[data-pn-lesson]'))) { const l = ALL_LESSONS.find((x) => x.id === el.dataset.pnLesson); if (l && unlocked(l)) startLesson(l); return; }
    if ((el = q('[data-pn-song]'))) return startSong(songById(el.dataset.pnSong));
    if ((el = q('[data-pn-listen]'))) { const s = songById(el.dataset.pnListen); return playSeq(s.n, s.bpm); }
    if ((el = q('[data-pn-chord]'))) return startChordDrill(chordById(el.dataset.pnChord));
    if ((el = q('[data-pn-hear]'))) return playChord(chordById(el.dataset.pnHear));
    if (q('[data-pn-replay]')) return playNote(st.view.task.m, 1.1);
    if (q('[data-pn-preview]')) { const t = st.view.task; return playSeq(t.notes.slice(t.pos, t.pos + 8), t.song?.bpm || 100); }
    if (q('[data-pn-close]') || q('[data-pn-continue]')) { st.view = null; return paint(); }
    if (q('[data-pn-again]')) { const l = st.view.lesson; st.view = null; return l.id.startsWith('song:') ? startSong(songById(l.data.song)) : l.id.startsWith('chord:') ? startChordDrill(chordById(l.data.list[0])) : startLesson(l); }
    if (q('[data-pn-say]')) { const t = summary(); return coach(t.slice(0, 3).join(' '), 'happy', true); }
  }
  function onChange(e) {
    if (!st.root?.contains(e.target)) return;
    if (e.target.matches('[data-pn-voice]')) { st.coach.voice = e.target.checked; st.data.voice = st.coach.voice; save(); if (!st.coach.voice) { window.speechSynthesis?.cancel(); st.coach.src?.stop?.(); } }
  }
  document.addEventListener('click', onClick);
  document.addEventListener('change', onChange);
  document.addEventListener('keydown', onKey);
  document.addEventListener('keyup', onKeyUp);

  A.define(
    ID,
    { nav: 'Klavier', title: 'Klavier lernen', sub: 'Lernpfad, Lieder & Akkorde mit Coach', icon: 'music', tint: 'linear-gradient(135deg,#1c1c1e,#5e5ce6)', desc: 'Lerne Klavier wie mit Duolingo: Dein Klavier wird übers Mikrofon erkannt (oder per MIDI-Keyboard), mit berühmten Liedern, Akkorden und Coach Clara.' },
    {
      game: true,
      async mount(root) {
        st.root = root;
        await load();
        if (!st.coach.text) {
          st.coach.text = line('hello');
          setTimeout(() => st.root && coach(st.coach.text, 'happy', true), 400);
        }
        midiStart();
        paint();
        if (!st.mic.on) micStart().then((ok) => ok && paint());
      },
      unmount() {
        micStop();
        window.speechSynthesis?.cancel();
        try { st.coach.src?.stop?.(); } catch { /* egal */ }
        st.view = null;
        st.root = null;
      },
    },
  );
  window.__piano = { SONGS, CHORDS, UNITS, summary: () => summary(), handleNote: (m) => handleNote(m, 'key'), st };
})();
