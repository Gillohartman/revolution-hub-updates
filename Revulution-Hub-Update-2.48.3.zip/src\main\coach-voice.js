'use strict';

/*
 * 2.48 Coach-Stimme für Hub-Apps (Klavier-Coach): dieselbe Offline-Stimme wie der Schach-Coach
 * („Kerstin“, Piper). Sie liegt im Datenordner des Schach-Moduls – ist sie dort schon geladen,
 * wird sie einfach mitbenutzt; sonst wird sie einmalig (ca. 65 MB) geladen.
 */
const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');

const PIPER_ZIP = 'https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip';
const VOICE = 'https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/de/de_DE/kerstin/low/de_DE-kerstin-low.onnx';

class CoachVoice {
  /** @param {string} dir Ordner der Schach-Stimmen (…/chess/tts) */
  constructor(dir) {
    this.dir = dir;
    this.installing = null;
  }

  exe() {
    const p = path.join(this.dir, 'piper', 'piper.exe');
    return fs.existsSync(p) ? p : '';
  }

  model() {
    return path.join(this.dir, path.basename(VOICE));
  }

  status() {
    return { installed: Boolean(this.exe() && fs.existsSync(this.model()) && fs.existsSync(`${this.model()}.json`)), installing: Boolean(this.installing) };
  }

  async download(url, file) {
    const r = await fetch(url, { redirect: 'follow', headers: { 'user-agent': 'Revulution-Hub' } });
    if (!r.ok) throw new Error(`Download fehlgeschlagen (${r.status})`);
    const out = fs.createWriteStream(`${file}.part`);
    for await (const chunk of r.body) if (!out.write(chunk)) await new Promise((res) => out.once('drain', res));
    await new Promise((res, rej) => out.end((e) => (e ? rej(e) : res())));
    fs.renameSync(`${file}.part`, file);
  }

  async install() {
    if (process.platform !== 'win32') throw new Error('Nur unter Windows verfügbar');
    if (this.status().installed) return this.status();
    if (this.installing) return this.installing;
    this.installing = (async () => {
      fs.mkdirSync(this.dir, { recursive: true });
      if (!this.exe()) {
        const zip = path.join(this.dir, 'piper.zip');
        await this.download(PIPER_ZIP, zip);
        await new Promise((resolve, reject) =>
          execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${this.dir.replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 180000 }, (e) => (e ? reject(e) : resolve())),
        );
        fs.rmSync(zip, { force: true });
      }
      if (!fs.existsSync(`${this.model()}.json`)) await this.download(`${VOICE}.json`, `${this.model()}.json`);
      if (!fs.existsSync(this.model())) await this.download(VOICE, this.model());
      return this.status();
    })();
    try {
      return await this.installing;
    } finally {
      this.installing = null;
    }
  }

  /** Text → WAV-Bytes */
  speak(text) {
    const exe = this.exe();
    if (!exe || !fs.existsSync(this.model())) return Promise.reject(new Error('Stimme nicht installiert'));
    const out = path.join(this.dir, `coach-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.wav`);
    return new Promise((resolve, reject) => {
      const p = spawn(exe, ['--model', this.model(), '--output_file', out, '--length_scale', '0.95', '--sentence_silence', '0.15'], { cwd: path.dirname(exe), windowsHide: true });
      p.on('error', reject);
      p.on('close', () => {
        try {
          const bytes = fs.readFileSync(out);
          fs.rmSync(out, { force: true });
          resolve(new Uint8Array(bytes));
        } catch {
          reject(new Error('Sprachausgabe fehlgeschlagen'));
        }
      });
      p.stdin.end(String(text || '').slice(0, 500), 'utf8');
    });
  }
}

module.exports = { CoachVoice };
