'use strict';

/* 2.38 Mod-Bibliothek (Modrinth): Mods, Shader und Ressourcenpakete suchen, nach Loader und
   Minecraft-Version filtern und mit einem Klick in eine Installation legen. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const PAGE = 'tool-modrinth';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const num = (n) => (n >= 1e6 ? `${(n / 1e6).toFixed(1).replace('.', ',')} Mio.` : n >= 1e3 ? `${Math.round(n / 1e3)}k` : String(n));

  const md = {
    tab: 'own',
    own: null,
    owning: '',
    type: 'mod',
    loader: localStorage.getItem('md-loader') || 'fabric',
    version: localStorage.getItem('md-version') || '',
    sort: 'relevance',
    q: '',
    hits: null,
    total: 0,
    busy: false,
    err: '',
    offset: 0,
    open: null,
    detail: null,
    vers: null,
    targets: null,
    target: localStorage.getItem('md-target') || '',
    games: null,
    installing: '',
    installed: null,
  };
  const render = () => active() && ctx().render();

  function loadBase() {
    if (!md.targets) {
      md.targets = [];
      window.hub.modrinth.targets().then((t) => {
        md.targets = t;
        if (!t.some((x) => x.dir === md.target)) md.target = t[0]?.dir || '';
        render();
      }).catch(() => {});
    }
    if (!md.games) {
      md.games = [];
      window.hub.modrinth.gameVersions().then((g) => {
        md.games = g;
        render();
      }).catch(() => {});
    }
  }
  let searchSeq = 0;
  async function search(more = false) {
    const seq = ++searchSeq;
    md.busy = true;
    md.err = '';
    if (!more) md.offset = 0;
    render();
    try {
      const r = await window.hub.modrinth.search({ q: md.q, type: md.type, loader: md.loader, version: md.version, sort: md.sort, offset: md.offset });
      if (seq !== searchSeq) return;
      md.hits = more ? [...(md.hits || []), ...r.hits] : r.hits;
      md.total = r.total;
    } catch (e) {
      md.err = String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
    md.busy = false;
    render();
  }
  async function openProject(id) {
    md.open = id;
    md.detail = null;
    md.vers = null;
    render();
    try {
      const [p, v] = await Promise.all([window.hub.modrinth.project(id), window.hub.modrinth.versions(id, md.type === 'mod' ? md.loader : '', md.version)]);
      if (md.open !== id) return;
      md.detail = p;
      md.vers = v;
    } catch (e) {
      md.err = String(e?.message || e);
    }
    render();
  }
  let instLoading = false;
  async function loadInstalled() {
    // 2.39: vorher setzte das hier installed=null, das Neuzeichnen startete sofort wieder loadInstalled → Endlosschleife (Blinken)
    if (instLoading) return;
    instLoading = true;
    try {
      md.installed = md.target ? await window.hub.modrinth.installed(md.target).catch(() => []) : [];
    } finally {
      instLoading = false;
    }
    render();
  }

  function filters() {
    const seg = (name, list, cur) => `<div class="seg md-seg" data-lg-key="md-${name}">${list.map(([v, n]) => `<button class="${cur === v ? 'on' : ''}" data-md-${name}="${v}">${n}</button>`).join('')}</div>`;
    return `<div class="md-filters">
      ${seg('type', [['mod', 'Mods'], ['shader', 'Shader'], ['resourcepack', 'Texturen'], ['datapack', 'Datapacks']], md.type)}
      ${md.type === 'mod' ? seg('loader', [['fabric', 'Fabric'], ['forge', 'Forge'], ['neoforge', 'NeoForge'], ['quilt', 'Quilt']], md.loader) : ''}
      <select class="input md-ver" data-md-version><option value="">Alle Versionen</option>${(md.games || []).map((g) => `<option ${g === md.version ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select>
      <select class="input md-sort" data-md-sort>${[['relevance', 'Passend'], ['downloads', 'Meiste Downloads'], ['follows', 'Beliebt'], ['newest', 'Neu'], ['updated', 'Aktualisiert']].map(([v, n]) => `<option value="${v}" ${md.sort === v ? 'selected' : ''}>${n}</option>`).join('')}</select>
    </div>`;
  }
  function targetPick() {
    if (!md.targets?.length) return '<small class="muted">Keine Minecraft-Installation gefunden – starte Minecraft einmal, dann erscheint sie hier.</small>';
    return `<select class="input md-target" data-md-target>${md.targets.map((t) => `<option value="${esc(t.dir)}" ${t.dir === md.target ? 'selected' : ''}>${esc(t.label)}</option>`).join('')}</select>`;
  }
  function browseHtml() {
    if (!md.hits && !md.busy && !md.err) setTimeout(() => search(), 0);
    return `<div class="tool-card md-bar">
        <span class="md-mag">${icon('search', 16)}</span>
        <input class="input" data-md-q value="${esc(md.q)}" placeholder="Mods suchen … z. B. Sodium, Iris, JourneyMap" />
      </div>
      ${filters()}
      ${md.err ? `<p class="err">${esc(md.err)}</p>` : ''}
      <p class="muted tool-note">${md.hits ? `${md.total.toLocaleString('de-DE')} Treffer auf Modrinth` : md.busy ? 'Wird gesucht …' : ''}</p>
      <div class="md-grid">${(md.hits || []).map((h, i) => `<button class="md-card" style="--d:${Math.min(i, 12) * 25}ms" data-md-open="${esc(h.id)}">
          <div class="md-ic">${h.icon ? `<img src="${esc(h.icon)}" alt="" loading="lazy" decoding="async" draggable="false" />` : icon('cube', 26)}</div>
          <div class="md-meta"><b>${esc(h.title)}</b><small>von ${esc(h.author)}</small><p>${esc(h.desc)}</p>
          <div class="md-tags"><span>⬇ ${num(h.downloads)}</span>${h.cats.slice(0, 3).map((c) => `<span>${esc(c)}</span>`).join('')}</div></div>
        </button>`).join('')}</div>
      ${md.hits && md.hits.length < md.total ? `<div class="tool-row center"><button class="btn" data-md-more ${md.busy ? 'disabled' : ''}>${md.busy ? 'Lädt …' : 'Mehr laden'}</button></div>` : ''}`;
  }
  function detailHtml() {
    const p = md.detail;
    const h = (md.hits || []).find((x) => x.id === md.open) || {};
    return `<div class="tool-row"><button class="btn small ghost" data-md-back>← Zurück</button></div>
      <div class="tool-card md-head">
        <div class="md-ic big">${(p?.icon || h.icon) ? `<img src="${esc(p?.icon || h.icon)}" alt="" draggable="false" />` : icon('cube', 34)}</div>
        <div class="grow"><h3>${esc(p?.title || h.title || '…')}</h3><small class="muted">${p ? `⬇ ${num(p.downloads)} · ♥ ${num(p.follows)}${p.license ? ` · ${esc(p.license)}` : ''}` : 'Lädt …'}</small><p>${esc(p?.desc || h.desc || '')}</p></div>
      </div>
      ${p?.gallery?.length ? `<div class="md-gal">${p.gallery.map((u) => `<img src="${esc(u)}" alt="" loading="lazy" draggable="false" />`).join('')}</div>` : ''}
      <div class="tool-card md-install">
        <div class="tool-label">Installieren in</div>${targetPick()}
        <div class="tool-label">Passende Versionen ${md.type === 'mod' ? `(${esc(md.loader)}${md.version ? ` · ${esc(md.version)}` : ''})` : ''}</div>
        ${!md.vers ? '<p class="muted">Versionen werden geladen …</p>' : md.vers.length ? `<div class="md-vers">${md.vers.slice(0, 8).map((v) => `<div class="md-ver-row"><div class="grow"><b>${esc(v.number)}</b><small>${esc(v.games.join(', '))} · ${esc(v.loaders.join(', '))}${v.deps ? ` · ${v.deps} benötigte Mod${v.deps > 1 ? 's' : ''} kommen mit` : ''}</small></div><span class="md-chan ${v.type}">${v.type === 'release' ? 'Stabil' : v.type === 'beta' ? 'Beta' : 'Alpha'}</span><button class="btn small primary" data-md-install="${esc(v.id)}" ${md.installing || !md.target ? 'disabled' : ''}>${md.installing === v.id ? 'Lädt …' : `${icon('download', 14)} Installieren`}</button></div>`).join('')}</div>` : '<p class="muted">Keine Version passt zu diesem Loader/dieser Minecraft-Version. Ändere oben den Filter.</p>'}
      </div>`;
  }
  function installedHtml() {
    if (md.installed === null && md.target && !instLoading) setTimeout(loadInstalled, 0);
    const list = md.installed || [];
    return `<div class="tool-card md-install"><div class="tool-label">Installation</div>${targetPick()}</div>
      ${!md.target ? '' : md.installed === null ? '<p class="muted">Wird gelesen …</p>' : list.length ? `<div class="md-list">${list.map((m) => `<div class="md-ver-row ${m.off ? 'off' : ''}"><span class="md-folder">${m.folder === 'mods' ? '🧩' : m.folder === 'shaderpacks' ? '✨' : '🎨'}</span><div class="grow"><b>${esc(m.file.replace(/\.disabled$/i, ''))}</b><small>${esc(m.folder)}${m.off ? ' · aus' : ''}</small></div>
        <button class="switch ${m.off ? '' : 'on'}" data-md-mod="toggle" data-f="${esc(m.folder)}" data-n="${esc(m.file)}" title="An/Aus"></button>
        <button class="btn small ghost" data-md-mod="folder" data-f="${esc(m.folder)}" data-n="${esc(m.file)}" title="Im Ordner zeigen">${icon('folder', 14)}</button>
        <button class="btn small ghost" data-md-mod="trash" data-f="${esc(m.folder)}" data-n="${esc(m.file)}" title="In den Papierkorb">${icon('trash', 14)}</button></div>`).join('')}</div>` : '<p class="muted">Hier sind noch keine Mods installiert.</p>'}`;
  }
  /* 2.47 Eigene Mods von Revolution – mitgeliefert, ein Klick installiert (Fabric API kommt mit) */
  let ownLoading = false;
  async function loadOwn() {
    if (ownLoading) return;
    ownLoading = true;
    try {
      md.own = await window.hub.modrinth.own(md.target).catch(() => []);
    } finally {
      ownLoading = false;
      render();
    }
  }
  function ownHtml() {
    if (md.own === null && !ownLoading) setTimeout(loadOwn, 0);
    const list = md.own || [];
    return `<div class="tool-card md-install"><div class="tool-label">Installieren in</div>${targetPick()}</div>
      ${md.own === null ? '<p class="muted">Wird geladen …</p>' : list.length ? `<div class="md-own">${list.map((m) => `<div class="tool-card md-own-card">
        <div class="md-own-ic"><span>R</span></div>
        <div class="grow"><div class="md-own-top"><b>${esc(m.name)}</b><span class="md-chan release">v${esc(m.version)}</span>${m.current ? '<span class="md-chan ok">Installiert</span>' : m.installed ? '<span class="md-chan beta">Ältere Version</span>' : ''}</div>
          <small class="muted">von ${esc(m.author || 'Revolution')} · Minecraft ${esc(m.minecraft)} · ${esc(m.loader)} · ${(m.size / 1048576).toFixed(1).replace('.', ',')} MB</small>
          <p>${esc(m.desc)}</p><div class="md-tags">${(m.tags || []).map((t) => `<span>${esc(t)}</span>`).join('')}</div></div>
        <div class="md-own-act"><button class="btn primary" data-md-own="${esc(m.id)}" ${md.owning || !md.target ? 'disabled' : ''}>${md.owning === m.id ? 'Installiert …' : m.current ? 'Neu installieren' : m.installed ? 'Aktualisieren' : `${icon('download', 14)} Installieren`}</button></div>
      </div>`).join('')}</div>` : '<p class="muted">Gerade keine eigenen Mods verfügbar.</p>'}`;
  }
  function html() {
    loadBase();
    return `<div class="seg md-tabs" data-lg-key="md-tabs"><button class="${md.tab === 'own' ? 'on' : ''}" data-md-tab="own">Revolution</button><button class="${md.tab === 'browse' ? 'on' : ''}" data-md-tab="browse">Entdecken</button><button class="${md.tab === 'installed' ? 'on' : ''}" data-md-tab="installed">Installiert</button></div>
      ${md.tab === 'own' ? ownHtml() : md.tab === 'installed' ? installedHtml() : md.open ? detailHtml() : browseHtml()}
      <p class="muted sp-note">${md.tab === 'own' ? 'Eigene Mods von Revolution – kommen direkt mit der App. Benötigte Mods (z. B. Fabric API) lädt der Hub von Modrinth nach.' : 'Daten und Dateien von Modrinth (modrinth.com). Jede Datei wird vor dem Speichern mit ihrer Prüfsumme kontrolliert.'}</p>`;
  }

  let qTimer = 0;
  document.addEventListener('input', (e) => {
    if (!active() || !e.target.matches('[data-md-q]')) return;
    md.q = e.target.value;
    clearTimeout(qTimer);
    qTimer = setTimeout(() => search(), 380);
  });
  document.addEventListener('change', (e) => {
    if (!active()) return;
    if (e.target.matches('[data-md-version]')) {
      md.version = e.target.value;
      localStorage.setItem('md-version', md.version);
      md.open ? openProject(md.open) : search();
    } else if (e.target.matches('[data-md-sort]')) {
      md.sort = e.target.value;
      search();
    } else if (e.target.matches('[data-md-target]')) {
      md.target = e.target.value;
      localStorage.setItem('md-target', md.target);
      if (md.tab === 'installed') loadInstalled();
      if (md.tab === 'own') loadOwn();
    }
  });
  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const t = e.target.closest('[data-md-tab],[data-md-type],[data-md-loader],[data-md-open],[data-md-back],[data-md-more],[data-md-install],[data-md-mod],[data-md-own]');
    if (!t) return;
    if (t.dataset.mdOwn) {
      md.owning = t.dataset.mdOwn;
      render();
      try {
        const got = await window.hub.modrinth.ownInstall(md.owning, md.target);
        ctx().toast?.(`Installiert: ${got.map((x) => x.name).join(', ')}`);
      } catch (err) {
        ctx().toast?.(String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''));
      }
      md.owning = '';
      md.own = null;
      render();
    } else if (t.dataset.mdTab) {
      md.tab = t.dataset.mdTab;
      md.installed = null;
      md.own = null;
      render();
    } else if (t.dataset.mdType) {
      md.type = t.dataset.mdType;
      md.open = null;
      search();
    } else if (t.dataset.mdLoader) {
      md.loader = t.dataset.mdLoader;
      localStorage.setItem('md-loader', md.loader);
      md.open ? openProject(md.open) : search();
    } else if (t.dataset.mdOpen) openProject(t.dataset.mdOpen);
    else if (t.hasAttribute('data-md-back')) {
      md.open = null;
      render();
    } else if (t.hasAttribute('data-md-more')) {
      md.offset = (md.hits || []).length;
      search(true);
    } else if (t.dataset.mdInstall) {
      md.installing = t.dataset.mdInstall;
      render();
      try {
        const got = await window.hub.modrinth.install(md.installing, md.target);
        ctx().toast?.(`Installiert: ${got.map((x) => x.name).join(', ')}`);
      } catch (err) {
        ctx().toast?.(String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''));
      }
      md.installing = '';
      render();
    } else if (t.dataset.mdMod) {
      await window.hub.modrinth.mod(md.target, t.dataset.f, t.dataset.n, t.dataset.mdMod).catch((err) => ctx().toast?.(String(err?.message || err)));
      if (t.dataset.mdMod !== 'folder') loadInstalled();
    }
  });

  T.register(PAGE, { nav: 'Mod-Bibliothek', title: 'Mod-Bibliothek', sub: 'Revolution-Mods & Modrinth', icon: 'cube', tint: 'linear-gradient(135deg,#4ade80,#065f46)', desc: 'Mods, Shader und Texturen von Modrinth suchen und mit einem Klick in deine Minecraft-Installation legen – inklusive benötigter Mods.' }, html);
})();
