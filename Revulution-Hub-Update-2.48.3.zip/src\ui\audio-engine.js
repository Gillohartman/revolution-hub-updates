'use strict';
/*
 * Audio-Engine des Hubs – unsichtbares Fenster, das alle Soundboard-Sounds abspielt
 * (Desktop-Widget und Stream-Deck-Tasten) und auf Wunsch dein echtes Mikrofon mit dem Soundboard mischt.
 *
 * 2.48.3: Der Mikrofon-Mix läuft jetzt DIREKT auf das virtuelle Mikrofon – ein eigener AudioContext mit
 * setSinkId() statt Umweg über MediaStream → <audio>. Der Umweg puffern (Verzögerung der Stimme) und lief
 * im Hintergrundfenster ungleichmäßig (abgehackte Sounds in Discord).
 *
 *   Soundboard ──┬─► Lautsprecher-Kontext (du hörst mit, abschaltbar)
 *                └─► Mix-Kontext ──► virtuelles Mikrofon (z. B. Discord)
 *   echtes Mikrofon ──┘
 *
 * Gesteuert wird alles vom Hauptprozess über window.__engine (executeJavaScript). Sounds kommen als
 * Data-URL herein – nur beim ersten Mal bzw. nach einer Änderung (sonst meldet play() „need“).
 */
(() => {
  const spk = new AudioContext({ latencyHint: 'interactive' }); // Lautsprecher (Mithören)
  const monitor = spk.createGain();
  monitor.connect(spk.destination);

  const st = { muted: false, mix: { on: false, micId: '', outId: '', micVol: 1, sbVol: 1, monitor: true }, micStream: null, micLabel: '', outLabel: '', error: '' };
  // Mix-Kontext (nur solange der Mikrofon-Mix an ist)
  const mx = { ctx: null, sb: null, mic: null, src: null, an: null, outId: null };
  const buffers = new Map(); // pad → { ver, buf }
  const playing = new Set();

  /* ---------- eingebaute Sounds (wie im Soundboard-Widget) */
  function noise(c, dur) {
    const b = c.createBuffer(1, Math.round(c.sampleRate * dur), c.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource();
    s.buffer = b;
    return s;
  }
  function env(c, node, t, a, dur, peak, out) {
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    node.connect(g).connect(out);
    return g;
  }
  const SYNTH = [
    (c, t, o) => { const x = c.createOscillator(); x.frequency.setValueAtTime(150, t); x.frequency.exponentialRampToValueAtTime(40, t + 0.4); env(c, x, t, 0.005, 0.45, 1, o); x.start(t); x.stop(t + 0.5); return 0.5; },
    (c, t, o) => { for (let i = 0; i < 3; i++) { const n = noise(c, 0.2); const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1400; n.connect(f); env(c, f, t + i * 0.012, 0.002, 0.18, 0.7, o); n.start(t + i * 0.012); } return 0.3; },
    (c, t, o) => { for (const fr of [440, 554, 659]) { const x = c.createOscillator(); x.type = 'sawtooth'; x.frequency.value = fr; env(c, x, t, 0.03, 1.1, 0.18, o); x.start(t); x.stop(t + 1.2); } return 1.2; },
    (c, t, o) => { for (const [fr, v] of [[1320, 0.4], [2640, 0.15]]) { const x = c.createOscillator(); x.frequency.value = fr; env(c, x, t, 0.004, 1.4, v, o); x.start(t); x.stop(t + 1.5); } return 1.5; },
    (c, t, o) => { const x = c.createOscillator(); x.type = 'triangle'; x.frequency.setValueAtTime(180, t); x.frequency.exponentialRampToValueAtTime(700, t + 0.25); x.frequency.exponentialRampToValueAtTime(260, t + 0.6); env(c, x, t, 0.01, 0.65, 0.6, o); x.start(t); x.stop(t + 0.7); return 0.7; },
    (c, t, o) => { const n = noise(c, 1.2); const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(60, t + 1.1); n.connect(f); env(c, f, t, 0.005, 1.15, 1, o); n.start(t); return 1.2; },
    (c, t, o) => { [392, 370, 349, 330].forEach((fr, i) => { const x = c.createOscillator(); x.type = 'square'; x.frequency.value = fr; env(c, x, t + i * 0.32, 0.02, i === 3 ? 0.9 : 0.3, 0.12, o); x.start(t + i * 0.32); x.stop(t + i * 0.32 + (i === 3 ? 0.95 : 0.32)); }); return 2; },
    (c, t, o) => { [523, 659, 784, 1047].forEach((fr, i) => { const x = c.createOscillator(); x.type = 'triangle'; x.frequency.value = fr; env(c, x, t + i * 0.07, 0.01, 0.9, 0.25, o); x.start(t + i * 0.07); x.stop(t + 1.1); }); return 1.1; },
  ];

  async function decode(dataUrl) {
    const b64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return spk.decodeAudioData(bytes.buffer);
  }

  /** Ziele für einen Sound: Lautsprecher (wenn Mithören an) und Mix (wenn Mikrofon-Mix an). */
  function targets(volume) {
    const out = [];
    const v = Math.max(0, Math.min(1.5, Number(volume) || 1));
    if (st.mix.monitor !== false || !mx.ctx) { const g = spk.createGain(); g.gain.value = v; g.connect(monitor); out.push({ c: spk, g }); }
    if (mx.ctx && mx.sb) { const g = mx.ctx.createGain(); g.gain.value = v; g.connect(mx.sb); out.push({ c: mx.ctx, g }); }
    return out;
  }

  /** Sound abspielen: pad, data = eigener Sound (Data-URL, nur wenn nötig), ver = Version für den Zwischenspeicher. */
  async function play({ pad = 0, volume = 1, data = '', ver = 0, custom = false } = {}) {
    if (st.muted) return { played: false, muted: true };
    if (spk.state !== 'running') await spk.resume().catch(() => {});
    if (mx.ctx && mx.ctx.state !== 'running') await mx.ctx.resume().catch(() => {});
    if (custom || data) {
      let e = buffers.get(pad);
      if (!e || e.ver !== ver) {
        if (!data) return { played: false, need: true }; // Hauptprozess schickt die Datei nach
        e = { ver, buf: await decode(data) };
        buffers.set(pad, e);
      }
      for (const { c, g } of targets(volume)) {
        const s = c.createBufferSource();
        s.buffer = e.buf; // AudioBuffer gilt in beiden Kontexten
        s.connect(g);
        s.start(c.currentTime + 0.005);
        playing.add(g);
        s.onended = () => { playing.delete(g); g.disconnect(); };
      }
      return { played: true, custom: true, seconds: Math.round(e.buf.duration * 10) / 10 };
    }
    let dur = 1;
    for (const { c, g } of targets(volume)) {
      dur = (SYNTH[pad % SYNTH.length] || SYNTH[0])(c, c.currentTime + 0.005, g);
      playing.add(g);
      setTimeout(() => { playing.delete(g); g.disconnect(); }, (dur + 0.3) * 1000);
    }
    return { played: true, custom: false };
  }
  function stop() {
    for (const g of playing) { try { g.gain.setValueAtTime(0, g.context.currentTime); g.disconnect(); } catch { /* egal */ } }
    playing.clear();
    return true;
  }

  /* ---------- Mikrofon-Mix */
  async function stopMix() {
    if (st.micStream) st.micStream.getTracks().forEach((t) => t.stop());
    st.micStream = null;
    try { mx.src?.disconnect(); } catch { /* egal */ }
    if (mx.ctx) await mx.ctx.close().catch(() => {});
    Object.assign(mx, { ctx: null, sb: null, mic: null, src: null, an: null, outId: null });
    st.outLabel = '';
    st.micLabel = '';
  }
  // kein Schritt darf ewig hängen (Gerät belegt/weg)
  const within = (p, ms, what) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(`${what} antwortet nicht – Gerät belegt oder nicht angeschlossen.`)), ms))]);
  async function applyMix() {
    const m = st.mix;
    monitor.gain.value = m.monitor === false ? 0 : 1;
    st.error = '';
    if (!m.on) { await stopMix(); return status(); }
    try {
      const outId = m.outId || 'default';
      // Ausgabegerät gewechselt → Mix-Kontext neu aufbauen
      if (mx.ctx && mx.outId !== outId) await stopMix();
      if (!mx.ctx) {
        // Mix direkt auf das virtuelle Mikrofon: kleinster Puffer, kein <audio>-Umweg
        mx.ctx = new AudioContext({ latencyHint: 0.01 });
        if (outId !== 'default') await within(mx.ctx.setSinkId(outId), 4000, 'Ausgabe');
        mx.outId = outId;
        mx.sb = mx.ctx.createGain();
        mx.mic = mx.ctx.createGain();
        mx.sb.connect(mx.ctx.destination);
        mx.mic.connect(mx.ctx.destination);
        mx.an = mx.ctx.createAnalyser();
        mx.an.fftSize = 512;
        mx.sb.connect(mx.an);
        mx.mic.connect(mx.an);
      }
      mx.sb.gain.value = Math.max(0, Math.min(1.5, Number(m.sbVol ?? 1)));
      mx.mic.gain.value = Math.max(0, Math.min(2, Number(m.micVol ?? 1)));
      // echtes Mikrofon (ohne Echo-/Rauschfilter – das macht Discord selbst; Filter würden auch verzögern)
      const wantMic = m.micId || 'default';
      if (!st.micStream || st.micStream._id !== wantMic || !mx.src) {
        if (st.micStream) st.micStream.getTracks().forEach((t) => t.stop());
        try { mx.src?.disconnect(); } catch { /* egal */ }
        st.micStream = await within(navigator.mediaDevices.getUserMedia({ audio: { deviceId: m.micId ? { exact: m.micId } : undefined, echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 1, latency: 0.01 } }), 6000, 'Mikrofon');
        st.micStream._id = wantMic;
        mx.src = mx.ctx.createMediaStreamSource(st.micStream);
        mx.src.connect(mx.mic);
        st.micLabel = st.micStream.getAudioTracks()[0]?.label || '';
      }
      if (mx.ctx.state !== 'running') await mx.ctx.resume().catch(() => {});
      const outs = await navigator.mediaDevices.enumerateDevices();
      st.outLabel = outs.find((d) => d.kind === 'audiooutput' && d.deviceId === outId)?.label || '';
    } catch (e) {
      st.error = e?.name === 'NotFoundError' || e?.name === 'OverconstrainedError' ? 'Gerät nicht gefunden – bitte neu wählen.' : e?.name === 'NotAllowedError' ? 'Kein Zugriff aufs Mikrofon (Windows-Datenschutz → Mikrofon).' : String(e?.message || e);
      await stopMix();
    }
    return status();
  }
  async function devices() {
    // Gerätenamen gibt es erst nach einmaligem Mikrofon-Zugriff
    let list = await navigator.mediaDevices.enumerateDevices();
    if (!list.some((d) => d.label)) {
      try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach((t) => t.stop()); list = await navigator.mediaDevices.enumerateDevices(); } catch { /* ohne Namen */ }
    }
    const clean = (d) => ({ id: d.deviceId, label: d.label || (d.kind === 'audioinput' ? 'Mikrofon' : 'Lautsprecher') });
    const skip = (d) => d.deviceId === 'communications';
    return {
      mics: list.filter((d) => d.kind === 'audioinput' && !skip(d)).map(clean),
      outs: list.filter((d) => d.kind === 'audiooutput' && !skip(d)).map(clean),
    };
  }
  // Pegel des Mixes (für die Anzeige im Studio)
  const spkAn = spk.createAnalyser();
  spkAn.fftSize = 512;
  monitor.connect(spkAn);
  const lvBuf = new Float32Array(512);
  function level() {
    const an = mx.an || spkAn;
    an.getFloatTimeDomainData(lvBuf);
    let p = 0;
    for (const v of lvBuf) p = Math.max(p, Math.abs(v));
    return Math.round(Math.min(1, p) * 100);
  }
  function status() {
    return { muted: st.muted, mix: st.mix, active: Boolean(mx.ctx && st.micStream), micLabel: st.micLabel, outLabel: st.outLabel, error: st.error, level: level(), ctx: spk.state, latencyMs: mx.ctx ? Math.round(((mx.ctx.baseLatency || 0) + (mx.ctx.outputLatency || 0)) * 1000) : 0 };
  }

  window.__engine = {
    play,
    stop,
    mute: (on) => { st.muted = Boolean(on); if (st.muted) stop(); return status(); },
    config: (m) => { st.mix = { ...st.mix, ...(m || {}) }; return applyMix(); },
    devices,
    status,
  };
})();
