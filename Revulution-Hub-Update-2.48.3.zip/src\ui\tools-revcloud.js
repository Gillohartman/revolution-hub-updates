'use strict';

/* 2.47.2 Revolution Cloud: eigener Speicher (Premium 10 GB, Max 300 GB) – auf jedem PC mit deinem Konto.
   Ordner für Clips, Screenshots und Projekte, dazu eigene Dateien. Ziehen & Ablegen lädt hoch. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-cloud';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const render = () => active() && ctx().render();
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const size = (b) => (b >= 1024 ** 3 ? `${(b / 1024 ** 3).toFixed(2)} GB` : b >= 1024 ** 2 ? `${(b / 1024 ** 2).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`).replace('.', ',');
  const FOLDERS = [['', 'Alles', '☁️'], ['Clips/', 'Clips', '🎬'], ['Screenshots/', 'Screenshots', '📸'], ['Projekte/', 'Projekte', '🧩'], ['Eigene/', 'Eigene Dateien', '📁']];
  const st = { usage: null, list: null, folder: '', err: '', busy: '', progress: {} };

  async function load() {
    st.err = '';
    try {
      [st.usage, st.list] = await Promise.all([window.hub.cloud.usage(), window.hub.cloud.list(st.folder)]);
    } catch (e) {
      st.err = errText(e);
      st.usage = st.usage || null;
      st.list = st.list || { folders: [], files: [] };
    }
    render();
  }
  window.hub.cloud?.onProgress?.(({ id, p }) => {
    st.progress[id] = p;
    if (p >= 1) delete st.progress[id];
    const el = document.querySelector('.cl-busy b');
    if (el) el.style.width = `${Math.round(p * 100)}%`;
  });

  const icon = (p) => (/\.(mp4|webm|mov|mkv)$/i.test(p) ? '🎬' : /\.(png|jpe?g|gif|webp)$/i.test(p) ? '🖼️' : /\.(zip|rar|7z)$/i.test(p) ? '🗜️' : /\.(stl|3mf|obj)$/i.test(p) ? '🧊' : /\.(docx?|rdoc|md|txt|pdf)$/i.test(p) ? '📄' : '📦');

  function html() {
    if (!st.list && !st.loading) { st.loading = true; load().finally(() => { st.loading = false; }); }
    const u = st.usage;
    const plan = u?.plan === 'max' ? 'Max' : u?.plan === 'pro' ? 'Premium' : '';
    const pct = u?.quota ? Math.min(100, (u.used / u.quota) * 100) : 0;
    const head = `<div class="tool-card cl-head">
        <div class="cl-cap"><span class="cl-cloud">☁️</span><div><b>Revolution Cloud</b><small>${plan ? `${plan} · ${size(u.quota)} Speicher` : 'Speicher für Clips, Screenshots und Projekte'}</small></div></div>
        ${u?.quota ? `<div class="cl-meter"><div class="cl-bar"><i style="width:${pct.toFixed(1)}%" class="${pct > 90 ? 'full' : ''}"></i></div><small>${size(u.used)} von ${size(u.quota)} belegt · ${u.files} Dateien</small></div>` : ''}
        <button class="btn primary" data-cl-up ${u?.quota ? '' : 'disabled'}>⇪ Hochladen</button>
      </div>`;
    if (st.err && !u) {
      const store = /Premium|Max/.test(st.err);
      return `${head}<div class="tool-card cl-empty"><span>${store ? '✨' : '☁️'}</span><b>${esc(st.err)}</b>${store ? '<p>Mit <b>Premium</b> hast du 10 GB, mit <b>Max</b> 300 GB eigenen Cloud-Speicher – auf jedem PC mit deinem Konto.</p><button class="btn primary" data-cl-store>Zum Store</button>' : '<p>Melde dich in der Konto-App an, dann siehst du hier deine Dateien.</p>'}</div>`;
    }
    if (u && !u.quota) {
      return `${head}<div class="tool-card cl-empty"><span>✨</span><b>Cloud-Speicher gibt es mit Premium oder Max</b><p>Premium: 10 GB · Max: 300 GB – Clips, Screenshots, Projekte und eigene Dateien, auf jedem PC mit deinem Konto.</p><button class="btn primary" data-cl-store>Zum Store</button></div>`;
    }
    const files = st.list?.files || [];
    const folders = (st.list?.folders || []).filter((f) => !FOLDERS.some(([k]) => k && k === f));
    return `${head}
      <div class="seg cl-folders" data-lg-key="cl-folders">${FOLDERS.map(([k, n, e]) => `<button class="${st.folder === k ? 'on' : ''}" data-cl-folder="${esc(k)}">${e} ${esc(n)}</button>`).join('')}</div>
      ${st.busy ? `<div class="cl-busy"><span>${esc(st.busy)}</span><i><b></b></i></div>` : ''}
      ${st.err ? `<p class="err">${esc(st.err)}</p>` : ''}
      <div class="tool-card cl-drop" data-cl-drop>
        ${folders.length || files.length ? `<div class="cl-list">${folders.map((f) => `<button class="cl-row folder" data-cl-folder="${esc(f)}"><span>📁</span><b>${esc(f.replace(/\/$/, '').split('/').pop())}</b><small></small></button>`).join('')}
          ${files.map((f) => `<div class="cl-row"><span>${icon(f.path)}</span><b title="${esc(f.path)}">${esc(f.path.split('/').pop())}</b><small>${size(f.size)} · ${new Date(f.at).toLocaleDateString('de-DE')}</small>
            <button class="btn small" data-cl-dl="${esc(f.path)}" title="Herunterladen">⇩</button><button class="btn small ghost" data-cl-del="${esc(f.path)}" title="Löschen">✕</button></div>`).join('')}</div>`
          : `<div class="cl-none"><span>⇪</span><b>Noch leer</b><small>Dateien hierher ziehen oder oben auf „Hochladen“.</small></div>`}
      </div>`;
  }

  async function upload(paths) {
    const folder = st.folder || 'Eigene/';
    st.busy = 'Wird hochgeladen …';
    render();
    try {
      const r = paths ? await window.hub.cloud.uploadPaths(paths, folder) : await window.hub.cloud.upload(folder);
      if (r.count) ctx().toast?.(`${r.count} Datei${r.count > 1 ? 'en' : ''} in der Cloud.`);
    } catch (e) {
      ctx().toast?.(errText(e), 'error');
    }
    st.busy = '';
    st.list = null;
    load();
  }

  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const q = (s) => e.target.closest(s);
    const fo = q('[data-cl-folder]');
    if (fo) { st.folder = fo.dataset.clFolder; st.list = null; return load(); }
    if (q('[data-cl-up]')) return upload();
    if (q('[data-cl-store]')) return window.hub.open('tool-store');
    const dl = q('[data-cl-dl]')?.dataset.clDl;
    if (dl) {
      st.busy = 'Wird heruntergeladen …';
      render();
      try { await window.hub.cloud.download(dl); ctx().toast?.('Im Download-Ordner gespeichert.'); } catch (err) { ctx().toast?.(errText(err), 'error'); }
      st.busy = '';
      return render();
    }
    const del = q('[data-cl-del]')?.dataset.clDel;
    if (del) {
      if (!window.confirm(`„${del.split('/').pop()}“ aus der Cloud löschen?`)) return;
      try { await window.hub.cloud.remove(del); } catch (err) { ctx().toast?.(errText(err), 'error'); }
      st.list = null;
      return load();
    }
  });
  // Ziehen & Ablegen
  document.addEventListener('dragover', (e) => { if (active() && e.target.closest?.('[data-cl-drop]')) { e.preventDefault(); e.target.closest('[data-cl-drop]').classList.add('over'); } });
  document.addEventListener('dragleave', (e) => { e.target.closest?.('[data-cl-drop]')?.classList.remove('over'); });
  document.addEventListener('drop', (e) => {
    const box = e.target.closest?.('[data-cl-drop]');
    if (!active() || !box) return;
    e.preventDefault();
    box.classList.remove('over');
    const paths = [...(e.dataTransfer?.files || [])].map((f) => window.hub.quick?.pathOf?.(f) || f.path).filter(Boolean);
    if (paths.length) upload(paths);
  });

  T.register(PAGE, { nav: 'Cloud', title: 'Revolution Cloud', sub: 'Dein Speicher auf jedem PC', icon: 'cloud', tint: 'linear-gradient(135deg,#60a5fa,#4338ca)', desc: 'Clips, Screenshots, Projekte und eigene Dateien in deiner Cloud – Premium 10 GB, Max 300 GB. Mit deinem Konto auf jedem PC.' }, html);
})();
