'use strict';

/*
 * 2.45 Showtime – Präsentationen wie in PowerPoint: Folien mit Layouts, Designvorlagen,
 * Textfelder, Formen und Bilder, Schriftarten und Formatierung, Animationen pro Element,
 * Folienübergänge, Notizen, Bildschirmpräsentation (Vollbild, Pfeiltasten/Klick) und PDF-Export.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-slides';
  const SW = 1600;
  const SH = 900;
  const uid = () => Math.random().toString(36).slice(2, 10);

  /* ---------------------------------------------------------------- Vorlagen */
  const THEMES = {
    // 2.46: leere Vorlage – weisse Folie, kein Design, eine leere Folie
    blank: { name: 'Leere Präsentation', bg: '#ffffff', fg: '#1d1d1f', accent: '#0a84ff', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', blank: true },
    // 2.46: neue Vorlagen mit Bewegung
    aurora: { name: 'Aurora', bg: 'linear-gradient(160deg,#020617,#0b1b33 60%,#06231f)', fg: '#f0fdfa', accent: '#5eead4', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'blur', sub: 'fade', body: 'fly', trans: 'morph' } },
    galaxy: { name: 'Galaxie', bg: 'radial-gradient(120% 120% at 70% 30%,#1b1140,#05040d 70%)', fg: '#ffffff', accent: '#c084fc', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'zoom', sub: 'fade', body: 'flyl', trans: 'zoom' } },
    liquid: { name: 'Liquid', bg: 'linear-gradient(135deg,#0f0c29,#302b63 55%,#24243e)', fg: '#ffffff', accent: '#f472b6', title: "'Segoe UI Black','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'bounce', sub: 'fade', body: 'float', trans: 'morph' } },
    glass: { name: 'Glas', bg: 'linear-gradient(135deg,#1e293b,#0f172a)', fg: '#f8fafc', accent: '#38bdf8', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'blur', sub: 'fade', body: 'zoom', trans: 'flip' } },
    clean: { name: 'Clean', bg: '#ffffff', fg: '#1d1d1f', accent: '#0a84ff', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '' },
    midnight: { name: 'Midnight', bg: 'linear-gradient(135deg,#0b1020,#1e1b4b)', fg: '#f5f5f7', accent: '#a78bfa', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: 'radial-gradient(60% 60% at 100% 0%,rgba(167,139,250,.35),transparent 70%)', motion: true, intro: { title: 'blur', sub: 'fade', body: 'fly', trans: 'fade' } },
    revolution: { name: 'Revolution', bg: 'linear-gradient(135deg,#120a2a,#2b1460 55%,#0b1a3a)', fg: '#ffffff', accent: '#8b5cf6', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: 'radial-gradient(40% 50% at 85% 30%,rgba(139,92,246,.55),transparent 70%),radial-gradient(30% 40% at 10% 90%,rgba(56,189,248,.35),transparent 70%)', motion: true, intro: { title: 'zoom', sub: 'fade', body: 'flyl', trans: 'morph' } },
    ocean: { name: 'Ozean', bg: 'linear-gradient(160deg,#03263f,#0e7490)', fg: '#ecfeff', accent: '#67e8f9', title: "Georgia,'Times New Roman',serif", body: "'Segoe UI',sans-serif", deco: 'radial-gradient(70% 40% at 50% 110%,rgba(103,232,249,.35),transparent 70%)', motion: true, intro: { title: 'float', sub: 'fade', body: 'fly', trans: 'push' } },
    sunset: { name: 'Sonnenuntergang', bg: 'linear-gradient(135deg,#ff7e5f,#feb47b)', fg: '#2b1b17', accent: '#7c2d12', title: "'Segoe UI Black','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'fly', sub: 'fade', body: 'fade', trans: 'fade' } },
    forest: { name: 'Wald', bg: 'linear-gradient(160deg,#0f2417,#1f4d2e)', fg: '#f0fdf4', accent: '#86efac', title: "'Palatino Linotype',Palatino,serif", body: "'Segoe UI',sans-serif", deco: 'radial-gradient(50% 50% at 0% 0%,rgba(134,239,172,.2),transparent 70%)' },
    paper: { name: 'Papier', bg: '#f7f3ea', fg: '#2d2a26', accent: '#c2410c', title: "Georgia,'Times New Roman',serif", body: "Georgia,serif", deco: 'repeating-linear-gradient(0deg,transparent 0 39px,rgba(0,0,0,.035) 39px 40px)' },
    neon: { name: 'Neon', bg: '#07070c', fg: '#e8fffb', accent: '#22d3ee', title: "Consolas,'Cascadia Mono',monospace", body: "'Segoe UI',sans-serif", deco: 'linear-gradient(90deg,rgba(34,211,238,.18),transparent 30%,transparent 70%,rgba(244,114,182,.18))', motion: true, intro: { title: 'pulse', sub: 'fade', body: 'wipe', trans: 'zoom' } },
    minimal: { name: 'Minimal Grau', bg: '#e9eaee', fg: '#18181b', accent: '#18181b', title: "'Segoe UI Light','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '' },
    bold: { name: 'Kräftig', bg: '#ffd60a', fg: '#111111', accent: '#ff2d55', title: "Impact,'Arial Black',sans-serif", body: "'Segoe UI',sans-serif", deco: '' },
    pastel: { name: 'Pastell', bg: '#fdf4ff', fg: '#3b0764', accent: '#c026d3', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'bounce', sub: 'fade', body: 'float', trans: 'cover' } },
    tech: { name: 'Tech', bg: 'linear-gradient(135deg,#0f172a,#020617)', fg: '#e2e8f0', accent: '#34d399', title: "'Cascadia Mono',Consolas,monospace", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'wipe', sub: 'fade', body: 'flyl', trans: 'push' } },
    corporate: { name: 'Business', bg: '#ffffff', fg: '#0f172a', accent: '#1d4ed8', title: "'Segoe UI Semibold','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '' },
    retro: { name: 'Retro', bg: 'linear-gradient(180deg,#2a1b3d,#44318d 60%,#d83f87)', fg: '#fff7ed', accent: '#ffd166', title: "'Arial Black',Impact,sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'drop', sub: 'fade', body: 'bounce', trans: 'blinds' } },
    gradient: { name: 'Verlauf', bg: 'linear-gradient(135deg,#1e1b4b,#312e81)', fg: '#ffffff', accent: '#f472b6', title: "'Segoe UI Variable Display','Segoe UI',sans-serif", body: "'Segoe UI',sans-serif", deco: '', motion: true, intro: { title: 'blur', sub: 'fade', body: 'fly', trans: 'morph' } },
  };
  // 2.45.1: echte Gestaltung pro Vorlage (SVG-Ebene über dem Hintergrund, 1600×900)
  const ART = {
    aurora: () => '<defs><linearGradient id="au1" x1="0" x2="1"><stop offset="0" stop-color="#5eead4" stop-opacity="0"/><stop offset=".5" stop-color="#5eead4" stop-opacity=".55"/><stop offset="1" stop-color="#818cf8" stop-opacity="0"/></linearGradient><linearGradient id="au2" x1="0" x2="1"><stop offset="0" stop-color="#a78bfa" stop-opacity="0"/><stop offset=".5" stop-color="#f0abfc" stop-opacity=".4"/><stop offset="1" stop-color="#5eead4" stop-opacity="0"/></linearGradient><filter id="aub"><feGaussianBlur stdDeviation="28"/></filter></defs><g filter="url(#aub)"><path class="a-wave" d="M-200 330 C200 180 500 460 800 300 S1400 160 1800 320 L1800 420 C1400 260 1100 520 800 400 S200 300 -200 440Z" fill="url(#au1)"/><path class="a-wave2" d="M-200 470 C300 360 600 600 900 470 S1500 380 1800 480 L1800 560 C1500 470 1200 680 900 560 S300 470 -200 580Z" fill="url(#au2)"/></g>' + Array.from({ length: 40 }, (_, i) => `<circle class="a-tw" style="animation-delay:${(i % 7) * 0.6}s" cx="${(i * 397) % 1600}" cy="${(i * 211) % 520}" r="${(i % 3) * 0.7 + 0.7}" fill="#fff" opacity=".7"/>`).join(''),
    galaxy: (a) => Array.from({ length: 70 }, (_, i) => `<circle class="a-tw" style="animation-delay:${(i % 9) * 0.45}s" cx="${(i * 431) % 1600}" cy="${(i * 277) % 900}" r="${(i % 4) * 0.6 + 0.6}" fill="#fff"/>`).join('') + `<g class="a-orbit" style="transform-origin:1200px 330px"><ellipse cx="1200" cy="330" rx="300" ry="90" fill="none" stroke="${a}" stroke-width="1.5" opacity=".45"/><circle cx="1500" cy="330" r="10" fill="${a}"/></g><g class="a-orbit2" style="transform-origin:1200px 330px"><ellipse cx="1200" cy="330" rx="190" ry="56" fill="none" stroke="#38bdf8" stroke-width="1.2" opacity=".4"/><circle cx="1010" cy="330" r="7" fill="#38bdf8"/></g><circle class="a-pulse" cx="1200" cy="330" r="64" fill="${a}" opacity=".9"/><circle cx="1200" cy="330" r="110" fill="${a}" opacity=".12"/>`,
    liquid: (a) => `<defs><filter id="lqb"><feGaussianBlur stdDeviation="40"/></filter></defs><g filter="url(#lqb)"><circle class="a-blob" cx="1250" cy="250" r="230" fill="${a}" opacity=".75"/><circle class="a-blob2" cx="300" cy="720" r="260" fill="#60a5fa" opacity=".6"/><circle class="a-blob3" cx="900" cy="560" r="170" fill="#a78bfa" opacity=".6"/></g>`,
    glass: (a) => `<circle class="a-blob" cx="1300" cy="220" r="200" fill="${a}" opacity=".5"/><circle class="a-blob2" cx="260" cy="780" r="230" fill="#818cf8" opacity=".45"/><g class="a-float"><rect x="1060" y="420" width="380" height="250" rx="34" fill="rgba(255,255,255,.08)" stroke="rgba(255,255,255,.3)" stroke-width="2"/><rect x="1100" y="470" width="180" height="16" rx="8" fill="rgba(255,255,255,.35)"/><rect x="1100" y="505" width="260" height="12" rx="6" fill="rgba(255,255,255,.18)"/></g><g class="a-float2"><rect x="1180" y="120" width="230" height="150" rx="28" fill="rgba(255,255,255,.07)" stroke="rgba(255,255,255,.25)" stroke-width="2"/></g>`,
    clean: (a) => `<rect x="0" y="0" width="18" height="900" fill="${a}"/><rect x="1380" y="820" width="160" height="8" rx="4" fill="${a}" opacity=".5"/>`,
    midnight: () => Array.from({ length: 60 }, (_, i) => `<circle cx="${(i * 389) % 1600}" cy="${(i * 233) % 900}" r="${(i % 3) * 0.8 + 0.8}" fill="#fff" opacity="${0.25 + (i % 5) * 0.12}" class="a-tw" style="animation-delay:${(i % 8) * 0.5}s"/>`).join('') + '<g class="a-float"><circle cx="1420" cy="160" r="70" fill="#e9e3ff" opacity=".9"/><circle cx="1450" cy="140" r="64" fill="#1e1b4b"/></g>',
    revolution: (a) => `<g class="a-spin" style="transform-origin:1350px 250px"><circle cx="1350" cy="250" r="260" fill="none" stroke="${a}" stroke-width="2" opacity=".5" stroke-dasharray="40 18"/><circle cx="1610" cy="250" r="8" fill="${a}"/></g><g class="a-spin-r" style="transform-origin:1350px 250px"><circle cx="1350" cy="250" r="180" fill="none" stroke="#38bdf8" stroke-width="1.5" opacity=".35" stroke-dasharray="6 14"/></g><path class="a-dash" d="M0 760 Q400 680 800 760 T1600 740" fill="none" stroke="${a}" stroke-width="3" opacity=".6" stroke-dasharray="1600" />`,
    ocean: () => '<g class="a-sway">' + '<path d="M0 720 Q200 680 400 720 T800 720 T1200 720 T1600 720 V900 H0Z" fill="#67e8f9" opacity=".18"/><path d="M0 780 Q200 740 400 780 T800 780 T1200 780 T1600 780 V900 H0Z" fill="#22d3ee" opacity=".22"/><path d="M0 840 Q200 810 400 840 T800 840 T1200 840 T1600 840 V900 H0Z" fill="#ecfeff" opacity=".15"/></g>',
    sunset: () => '<circle class="a-pulse" cx="1300" cy="640" r="220" fill="#fff4e0" opacity=".55"/><path d="M0 760 L300 600 L520 720 L780 560 L1060 740 L1300 620 L1600 760 V900 H0Z" fill="#7c2d12" opacity=".35"/>',
    forest: () => '<path d="M0 900 L160 640 L260 760 L420 520 L560 740 L700 600 L860 820 L1000 580 L1160 780 L1320 560 L1460 760 L1600 640 V900Z" fill="#0b1a10" opacity=".75"/><path d="M0 900 L220 720 L380 860 L600 700 L820 880 L1040 720 L1280 870 L1600 740 V900Z" fill="#14532d" opacity=".6"/>',
    paper: (a) => `<line x1="120" y1="0" x2="120" y2="900" stroke="${a}" stroke-width="2" opacity=".35"/><rect x="1440" y="0" width="70" height="140" fill="${a}" opacity=".85"/>`,
    neon: (a) => '<g class="a-grid">' + Array.from({ length: 17 }, (_, i) => `<line x1="${i * 100}" y1="560" x2="${800 + (i * 100 - 800) * 2.2}" y2="900" stroke="${a}" stroke-width="1" opacity=".35"/>`).join('') + Array.from({ length: 6 }, (_, i) => `<line x1="0" y1="${600 + i * i * 9}" x2="1600" y2="${600 + i * i * 9}" stroke="#f472b6" stroke-width="1" opacity=".35"/>`).join('') + `</g><rect class="a-glow" x="24" y="24" width="1552" height="852" rx="22" fill="none" stroke="${a}" stroke-width="3" opacity=".7"/>`,
    minimal: (a) => `<line x1="100" y1="820" x2="1500" y2="820" stroke="${a}" stroke-width="2" opacity=".25"/>`,
    bold: (a) => `<path d="M1100 0 H1600 V900 H700Z" fill="${a}" opacity=".9"/><path d="M1200 0 H1600 V420Z" fill="#111" opacity=".85"/>`,
    pastel: () => '<circle class="a-blob" cx="1450" cy="120" r="220" fill="#fbcfe8"/><circle class="a-blob2" cx="120" cy="860" r="260" fill="#bfdbfe"/><circle class="a-blob3" cx="1500" cy="820" r="120" fill="#bbf7d0"/>',
    tech: (a) => Array.from({ length: 12 }, (_, i) => `<path d="M${1200 + (i % 4) * 90} ${100 + Math.floor(i / 4) * 90} h40 v40" fill="none" stroke="${a}" stroke-width="2" opacity=".5"/><circle class="a-blink" style="animation-delay:${(i * 0.37) % 3}s" cx="${1240 + (i % 4) * 90}" cy="${140 + Math.floor(i / 4) * 90}" r="5" fill="${a}"/>`).join('') + `<rect x="100" y="820" width="1400" height="2" fill="${a}" opacity=".4"/>`,
    corporate: (a) => `<rect x="0" y="0" width="1600" height="110" fill="${a}"/><rect x="0" y="860" width="1600" height="40" fill="${a}" opacity=".15"/>`,
    retro: () => '<circle class="a-pulse" cx="800" cy="980" r="420" fill="#ff7a59"/>' + Array.from({ length: 6 }, (_, i) => `<rect class="a-scan" style="animation-delay:${i * 0.25}s" x="380" y="${650 + i * 30}" width="840" height="${6 + i * 2}" fill="#2a1b3d"/>`).join(''),
    gradient: () => '<circle class="a-blob" cx="300" cy="200" r="400" fill="#f472b6" opacity=".35"/><circle class="a-blob2" cx="1300" cy="700" r="460" fill="#60a5fa" opacity=".35"/>',
  };
  for (const [k, t] of Object.entries(THEMES)) t.art = ART[k] ? ART[k](t.accent) : '';
  const FONTS = ['Segoe UI', 'Segoe UI Variable Display', 'Segoe UI Light', 'Segoe UI Black', 'Arial', 'Arial Black', 'Calibri', 'Cambria', 'Candara', 'Consolas', 'Constantia', 'Corbel', 'Georgia', 'Impact', 'Palatino Linotype', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana', 'Cascadia Mono', 'Comic Sans MS', 'Bahnschrift', 'Gabriola', 'Ink Free'];
  const ANIMS = [['none', 'Keine'], ['fade', 'Einblenden'], ['fly', 'Hereinfliegen'], ['flyl', 'Von links'], ['flyr', 'Von rechts'], ['zoom', 'Zoomen'], ['wipe', 'Wischen'], ['split', 'Teilen'], ['bounce', 'Aufspringen'], ['spin', 'Drehen'], ['float', 'Schweben'], ['blur', 'Scharfstellen'], ['swing', 'Schwingen'], ['pulse', 'Pulsieren'], ['drop', 'Fallen']];
  const TRANS = [['none', 'Keine'], ['fade', 'Verblassen'], ['push', 'Schieben'], ['zoom', 'Zoom'], ['cover', 'Überdecken'], ['flip', 'Kippen'], ['morph', 'Morphen'], ['wipe', 'Wischen'], ['blinds', 'Jalousie']];
  const SHAPES = [['rect', 'Rechteck'], ['round', 'Abgerundet'], ['ellipse', 'Ellipse'], ['triangle', 'Dreieck'], ['arrow', 'Pfeil'], ['star', 'Stern'], ['line', 'Linie'], ['bubble', 'Sprechblase']];
  const LAYOUTS = [['title', 'Titelfolie'], ['content', 'Titel und Inhalt'], ['two', 'Zwei Inhalte'], ['section', 'Abschnitt'], ['quote', 'Zitat'], ['picture', 'Bild mit Titel'], ['blank', 'Leer']];

  const T = () => THEMES[st.pres?.theme] || THEMES.clean;
  function textEl(x, y, w, h, html, opt = {}) {
    return { id: uid(), type: 'text', x, y, w, h, rot: 0, html, style: { font: opt.font || '', size: opt.size || 40, color: opt.color || '', bold: Boolean(opt.bold), italic: false, underline: false, align: opt.align || 'left', valign: opt.valign || 'top', fill: '', stroke: '', strokeW: 0, radius: 0, opacity: 1, role: opt.role || 'body' }, anim: { type: 'none', dur: 600, delay: 0 } };
  }
  function layoutEls(layout) {
    switch (layout) {
      case 'title': return [textEl(140, 300, 1320, 180, 'Titel der Präsentation', { size: 96, bold: true, align: 'center', valign: 'middle', role: 'title' }), textEl(240, 500, 1120, 90, 'Untertitel – dein Name', { size: 40, align: 'center', role: 'sub' })];
      case 'content': return [textEl(100, 70, 1400, 130, 'Folientitel', { size: 64, bold: true, role: 'title' }), textEl(100, 230, 1400, 590, '<ul><li>Erster Punkt</li><li>Zweiter Punkt</li><li>Dritter Punkt</li></ul>', { size: 38 })];
      case 'two': return [textEl(100, 70, 1400, 130, 'Vergleich', { size: 64, bold: true, role: 'title' }), textEl(100, 230, 670, 590, '<ul><li>Links</li><li>Punkt</li></ul>', { size: 36 }), textEl(830, 230, 670, 590, '<ul><li>Rechts</li><li>Punkt</li></ul>', { size: 36 })];
      case 'section': return [textEl(140, 340, 1320, 160, 'Abschnitt', { size: 110, bold: true, valign: 'middle', role: 'title' }), textEl(140, 520, 1320, 70, 'Kurze Beschreibung', { size: 36, role: 'sub' })];
      case 'quote': return [textEl(200, 240, 1200, 320, '„Ein starkes Zitat steht hier.“', { size: 72, align: 'center', valign: 'middle', role: 'title' }), textEl(200, 600, 1200, 70, '– Autor', { size: 36, align: 'center', role: 'sub' })];
      case 'picture': return [textEl(100, 60, 1400, 120, 'Bildtitel', { size: 60, bold: true, role: 'title' }), { id: uid(), type: 'shape', x: 100, y: 200, w: 1400, h: 620, rot: 0, style: { shape: 'round', fill: 'rgba(128,128,128,.25)', stroke: '', strokeW: 0, radius: 24, opacity: 1, text: 'Bild über „Einfügen → Bild“ hinzufügen' }, anim: { type: 'none', dur: 600, delay: 0 } }];
      default: return [];
    }
  }
  const newSlide = (layout = 'content') => ({ id: uid(), layout, bg: '', transition: { type: 'fade', dur: 600 }, notes: '', els: layoutEls(layout) });
  function newPres(theme = 'revolution') {
    const th = THEMES[theme] || THEMES.revolution;
    if (th.blank) return { id: uid(), title: 'Leere Präsentation', theme, created: Date.now(), updated: Date.now(), slides: [{ ...newSlide('blank'), transition: { type: 'none', dur: 600 } }] };
    const slides = [newSlide('title'), newSlide('content'), newSlide('section'), newSlide('two'), newSlide('quote')];
    // 2.46: Vorlagen bringen passende Animationen mit (nacheinander, mit Verzögerung) – fancy, aber änderbar
    const intro = th.intro || { title: 'fade', sub: 'fade', body: 'fly', trans: 'fade' };
    for (const sl of slides) {
      sl.transition = { type: intro.trans, dur: 700 };
      let d = 0;
      for (const e of sl.els) {
        const role = e.style?.role;
        e.anim = { type: role === 'title' ? intro.title : role === 'sub' ? intro.sub : intro.body, dur: role === 'title' ? 900 : 700, delay: d };
        d += role === 'title' ? 350 : 250;
      }
    }
    return { id: uid(), title: 'Neue Präsentation', theme, created: Date.now(), updated: Date.now(), slides };
  }

  /* ---------------------------------------------------------------- Zustand */
  const st = { root: null, list: [], pres: null, cur: 0, sel: null, tab: 'start', undo: [], redo: [], loaded: false, drag: null, editing: null, show: null, saveTimer: 0 };
  const slide = () => st.pres.slides[st.cur];
  const selEl = () => slide()?.els.find((e) => e.id === st.sel) || null;

  async function load() {
    if (st.loaded) return;
    st.loaded = true;
    const d = await A.store.get('slides', null);
    st.list = Array.isArray(d?.list) ? d.list : [];
  }
  function save() {
    if (!st.pres) return;
    st.pres.updated = Date.now();
    const i = st.list.findIndex((p) => p.id === st.pres.id);
    if (i >= 0) st.list[i] = st.pres;
    else st.list.unshift(st.pres);
    clearTimeout(st.saveTimer);
    st.saveTimer = setTimeout(() => A.store.set('slides', { list: st.list }), 600);
  }
  function snap() {
    st.undo.push(JSON.stringify(st.pres));
    if (st.undo.length > 60) st.undo.shift();
    st.redo = [];
  }
  function undo(back = true) {
    const from = back ? st.undo : st.redo;
    const to = back ? st.redo : st.undo;
    if (!from.length) return;
    to.push(JSON.stringify(st.pres));
    st.pres = JSON.parse(from.pop());
    st.cur = Math.min(st.cur, st.pres.slides.length - 1);
    st.sel = null;
    save();
    paint();
  }

  /* ---------------------------------------------------------------- Zeichnen einer Folie */
  function shapeSvg(el) {
    const s = el.style;
    const f = s.fill || T().accent;
    const k = s.stroke || 'none';
    const sw = s.strokeW || 0;
    const w = el.w;
    const h = el.h;
    const common = `fill="${esc(f)}" stroke="${esc(k)}" stroke-width="${sw}" vector-effect="non-scaling-stroke"`;
    let body = '';
    switch (s.shape) {
      case 'ellipse': body = `<ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2 - sw}" ry="${h / 2 - sw}" ${common}/>`; break;
      case 'triangle': body = `<polygon points="${w / 2},${sw} ${w - sw},${h - sw} ${sw},${h - sw}" ${common}/>`; break;
      case 'arrow': body = `<polygon points="0,${h * 0.3} ${w * 0.62},${h * 0.3} ${w * 0.62},0 ${w},${h / 2} ${w * 0.62},${h} ${w * 0.62},${h * 0.7} 0,${h * 0.7}" ${common}/>`; break;
      case 'star': {
        const pts = [];
        for (let i = 0; i < 10; i++) {
          const r = i % 2 ? 0.42 : 1;
          const a = -Math.PI / 2 + (i * Math.PI) / 5;
          pts.push(`${w / 2 + Math.cos(a) * (w / 2) * r},${h / 2 + Math.sin(a) * (h / 2) * r}`);
        }
        body = `<polygon points="${pts.join(' ')}" ${common}/>`;
        break;
      }
      case 'line': body = `<line x1="0" y1="${h / 2}" x2="${w}" y2="${h / 2}" stroke="${esc(s.fill || s.stroke || T().fg)}" stroke-width="${Math.max(2, sw || 6)}" stroke-linecap="round"/>`; break;
      case 'bubble': body = `<path d="M${24},0 H${w - 24} Q${w},0 ${w},24 V${h * 0.72 - 24} Q${w},${h * 0.72} ${w - 24},${h * 0.72} H${w * 0.36} L${w * 0.2},${h} L${w * 0.24},${h * 0.72} H24 Q0,${h * 0.72} 0,${h * 0.72 - 24} V24 Q0,0 24,0Z" ${common}/>`; break;
      default: body = `<rect x="${sw / 2}" y="${sw / 2}" width="${w - sw}" height="${h - sw}" rx="${s.shape === 'round' ? s.radius || 28 : s.radius || 0}" ${common}/>`;
    }
    return `<svg width="100%" height="100%" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" style="position:absolute;inset:0;overflow:visible">${body}</svg>`;
  }
  function elHtml(el, opts = {}) {
    const s = el.style || {};
    const th = T();
    const pos = `left:${el.x}px;top:${el.y}px;width:${el.w}px;height:${el.h}px;transform:rotate(${el.rot || 0}deg);opacity:${s.opacity ?? 1};`;
    const anim = opts.show && el.anim?.type && el.anim.type !== 'none' ? ` data-anim="${el.anim.type}" style-anim="1"` : '';
    if (el.type === 'image') return `<div class="sl-el sl-img" data-el="${el.id}" style="${pos}border-radius:${s.radius || 0}px"${anim}><img src="${el.src}" alt="" draggable="false" style="object-fit:${s.fit || 'cover'}"/></div>`;
    if (el.type === 'shape') return `<div class="sl-el sl-shape" data-el="${el.id}" style="${pos}"${anim}>${shapeSvg(el)}${s.text ? `<div class="sl-shape-t" style="color:${esc(s.color || th.fg)};font-family:${esc(s.font ? `'${s.font}'` : th.body)};font-size:${s.size || 32}px">${esc(s.text)}</div>` : ''}</div>`;
    const font = s.font ? `'${s.font}'` : s.role === 'title' || s.role === 'sub' ? th.title : th.body;
    const color = s.color || (s.role === 'sub' ? th.fg : th.fg);
    const just = s.valign === 'middle' ? 'center' : s.valign === 'bottom' ? 'flex-end' : 'flex-start';
    return `<div class="sl-el sl-text" data-el="${el.id}" style="${pos}display:flex;flex-direction:column;justify-content:${just};font-family:${esc(font)};font-size:${s.size || 40}px;color:${esc(color)};font-weight:${s.bold ? 700 : 400};font-style:${s.italic ? 'italic' : 'normal'};text-decoration:${s.underline ? 'underline' : 'none'};text-align:${s.align || 'left'};${s.fill ? `background:${esc(s.fill)};` : ''}${s.stroke ? `border:${s.strokeW || 2}px solid ${esc(s.stroke)};` : ''}border-radius:${s.radius || 0}px;${s.role === 'sub' ? 'opacity:.8;' : ''}"${anim}><div class="sl-tx" ${opts.edit === el.id ? 'contenteditable="true" spellcheck="true"' : ''}>${el.html}</div></div>`;
  }
  function slideHtml(sl, opts = {}) {
    const th = T();
    const bg = sl.bg || th.bg;
    return `<div class="sl-slide" style="width:${SW}px;height:${SH}px;background:${esc(bg)};color:${esc(th.fg)};--accent:${th.accent}">${th.deco && !sl.bg ? `<div class="sl-deco" style="background:${th.deco}"></div>` : ''}${th.art && !sl.noArt ? `<svg class="sl-deco" viewBox="0 0 1600 900" preserveAspectRatio="none">${th.art}</svg>` : ''}${sl.els.map((e) => elHtml(e, opts)).join('')}</div>`;
  }

  /* ---------------------------------------------------------------- Startseite (Galerie) */
  function galleryHtml() {
    return `<div class="sl-gallery">
      <div class="rv-row between"><div><h2 class="rv-h">Showtime</h2><p class="rv-sub">Präsentationen mit Vorlagen, Animationen und Bildschirmpräsentation.</p></div></div>
      <h3 class="sl-gh">Neu aus Vorlage</h3>
      <div class="sl-themes">${Object.entries(THEMES).map(([k, t]) => t.blank ? `<button class="sl-theme sl-theme-blank" data-sl-new="${k}"><div class="sl-theme-prev"><em>+</em></div><small>${esc(t.name)}</small></button>` : `<button class="sl-theme ${t.motion ? 'moving' : ''}" data-sl-new="${k}">${t.motion ? '<i class="sl-mv" title="Mit Animationen">✦ Animiert</i>' : ''}<div class="sl-theme-prev" style="background:${t.bg}">${t.deco ? `<i style="background:${t.deco}"></i>` : ''}${t.art ? `<svg class="sl-tart" viewBox="0 0 1600 900" preserveAspectRatio="none">${t.art}</svg>` : ''}<b style="font-family:${esc(t.title)};color:${t.fg}">Aa</b><span style="background:${t.accent}"></span></div><small>${esc(t.name)}</small></button>`).join('')}</div>
      <h3 class="sl-gh">Zuletzt bearbeitet</h3>
      ${st.list.length ? `<div class="sl-recent">${st.list.map((p) => `<div class="sl-recent-it"><button class="sl-recent-open" data-sl-open="${p.id}"><div class="sl-mini">${miniHtml(p, p.slides[0])}</div><b>${esc(p.title)}</b><small>${p.slides.length} Folien · ${new Date(p.updated).toLocaleDateString('de-CH')}</small></button><button class="rv-btn sm ghost" data-sl-del="${p.id}" title="Löschen">✕</button></div>`).join('')}</div>` : '<p class="rv-muted">Noch keine Präsentationen.</p>'}
    </div>`;
  }
  function miniHtml(p, sl) {
    const keep = st.pres;
    st.pres = p;
    const h = `<div class="sl-scale" style="transform:scale(${220 / SW})">${slideHtml(sl)}</div>`;
    st.pres = keep;
    return h;
  }

  /* ---------------------------------------------------------------- Editor */
  function ribbonHtml() {
    const e = selEl();
    const s = e?.style || {};
    const sl = slide();
    const tabs = [['start', 'Start'], ['insert', 'Einfügen'], ['design', 'Entwurf'], ['trans', 'Übergänge'], ['anim', 'Animationen'], ['show', 'Bildschirmpräsentation']];
    let body = '';
    if (st.tab === 'start') {
      body = `<div class="sl-grp"><button class="rv-btn sm" data-sl="add-slide">＋ Neue Folie</button><select class="rv-input sm" data-sl-layout title="Layout">${LAYOUTS.map(([k, n]) => `<option value="${k}" ${sl.layout === k ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select><button class="rv-btn sm" data-sl="dup">Duplizieren</button><button class="rv-btn sm" data-sl="del-slide">Folie löschen</button></div>
        <div class="sl-grp ${e && e.type !== 'image' ? '' : 'off'}"><select class="rv-input sm" data-sl-style="font" style="width:150px"><option value="">Design-Schrift</option>${FONTS.map((f) => `<option ${s.font === f ? 'selected' : ''} style="font-family:'${f}'">${f}</option>`).join('')}</select>
          <input class="rv-input sm" type="number" min="8" max="300" value="${s.size || 40}" data-sl-style="size" style="width:70px" title="Schriftgröße"/>
          <button class="rv-btn sm ${s.bold ? 'on' : ''}" data-sl-toggle="bold"><b>F</b></button><button class="rv-btn sm ${s.italic ? 'on' : ''}" data-sl-toggle="italic"><i>K</i></button><button class="rv-btn sm ${s.underline ? 'on' : ''}" data-sl-toggle="underline"><u>U</u></button>
          <label class="sl-color" title="Schriftfarbe">A<input type="color" value="${s.color && s.color.startsWith('#') ? s.color : '#ffffff'}" data-sl-style="color"/></label>
          ${['left', 'center', 'right'].map((a) => `<button class="rv-btn sm ${s.align === a ? 'on' : ''}" data-sl-align="${a}">${a === 'left' ? '⯇' : a === 'center' ? '☰' : '⯈'}</button>`).join('')}
          <button class="rv-btn sm" data-sl="bullets">• Liste</button><button class="rv-btn sm" data-sl="numbers">1. Liste</button></div>`;
    } else if (st.tab === 'insert') {
      body = `<div class="sl-grp"><button class="rv-btn sm" data-sl="add-text">Textfeld</button><button class="rv-btn sm" data-sl="add-image">Bild</button><button class="rv-btn sm" data-sl="add-table">Tabelle</button></div>
        <div class="sl-grp">${SHAPES.map(([k, n]) => `<button class="rv-btn sm" data-sl-shape="${k}">${esc(n)}</button>`).join('')}</div>`;
    } else if (st.tab === 'design') {
      body = `<div class="sl-grp sl-theme-row">${Object.entries(THEMES).map(([k, t]) => `<button class="sl-tmini ${st.pres.theme === k ? 'on' : ''}" data-sl-theme="${k}" title="${esc(t.name)}" style="background:${t.bg}"><b style="color:${t.fg};font-family:${esc(t.title)}">Aa</b></button>`).join('')}</div>
        <div class="sl-grp"><label class="sl-color" title="Folienhintergrund">Hintergrund<input type="color" value="${sl.bg && sl.bg.startsWith('#') ? sl.bg : '#ffffff'}" data-sl-slidebg/></label><button class="rv-btn sm" data-sl="bg-reset">Design-Hintergrund</button><button class="rv-btn sm" data-sl="bg-all">Auf alle Folien</button></div>`;
    } else if (st.tab === 'trans') {
      body = `<div class="sl-grp">${TRANS.map(([k, n]) => `<button class="rv-btn sm ${sl.transition?.type === k ? 'on' : ''}" data-sl-trans="${k}">${esc(n)}</button>`).join('')}</div>
        <div class="sl-grp"><label class="rv-muted">Dauer <input class="rv-input sm" type="number" min="100" max="4000" step="100" value="${sl.transition?.dur || 600}" data-sl-transdur style="width:80px"/> ms</label><button class="rv-btn sm" data-sl="trans-all">Für alle Folien</button></div>`;
    } else if (st.tab === 'anim') {
      body = e ? `<div class="sl-grp">${ANIMS.map(([k, n]) => `<button class="rv-btn sm ${e.anim?.type === k ? 'on' : ''}" data-sl-anim="${k}">${esc(n)}</button>`).join('')}</div>
        <div class="sl-grp"><label class="rv-muted">Dauer <input class="rv-input sm" type="number" min="100" max="5000" step="100" value="${e.anim?.dur || 600}" data-sl-animprop="dur" style="width:80px"/></label><label class="rv-muted">Verzögerung <input class="rv-input sm" type="number" min="0" max="10000" step="100" value="${e.anim?.delay || 0}" data-sl-animprop="delay" style="width:80px"/></label><label class="rv-muted"><input type="checkbox" data-sl-animwith ${e.anim?.withPrev ? 'checked' : ''}/> mit vorheriger</label><button class="rv-btn sm" data-sl="preview-anim">▶ Vorschau</button></div>`
        : '<div class="sl-grp rv-muted">Wähle ein Element auf der Folie, um eine Animation festzulegen.</div>';
    } else if (st.tab === 'show') {
      body = `<div class="sl-grp"><button class="rv-btn sm primary" data-sl="show-start">▶ Von Beginn an</button><button class="rv-btn sm" data-sl="show-cur">▶ Ab aktueller Folie</button><button class="rv-btn sm" data-sl="pptx">Als PowerPoint (.pptx)</button><button class="rv-btn sm" data-sl="pdf">Als PDF exportieren</button></div><div class="sl-grp rv-muted">Weiter: Klick, Leertaste, → · Zurück: ← · Beenden: Esc</div>`;
    }
    return `<div class="sl-ribbon"><div class="rv-row between"><div class="rv-row"><button class="rv-btn sm ghost" data-sl="home" title="Alle Präsentationen">‹</button><input class="sl-title" value="${esc(st.pres.title)}" data-sl-title spellcheck="false"/></div>
      <div class="rv-row"><button class="rv-btn sm" data-sl="undo" title="Rückgängig (Strg+Z)">↶</button><button class="rv-btn sm" data-sl="redo" title="Wiederholen (Strg+Y)">↷</button><button class="rv-btn sm primary" data-sl="show-start">▶ Präsentieren</button></div></div>
      <div class="rv-tabs sl-tabs">${tabs.map(([k, n]) => `<button class="${st.tab === k ? 'on' : ''}" data-sl-tab="${k}">${n}</button>`).join('')}</div>
      <div class="sl-body">${body}</div></div>`;
  }
  function propsHtml() {
    const e = selEl();
    if (!e) return `<div class="sl-props"><b>Folie ${st.cur + 1}</b><p class="rv-muted">Klicke ein Element an, um es zu bearbeiten. Doppelklick auf Text zum Schreiben.</p><label>Notizen<textarea class="rv-input" data-sl-notes rows="6" placeholder="Sprechernotizen …">${esc(slide().notes || '')}</textarea></label></div>`;
    const s = e.style;
    const num = (k, label, v) => `<label>${label}<input class="rv-input sm" type="number" value="${Math.round(v)}" data-sl-geo="${k}"/></label>`;
    return `<div class="sl-props"><b>${e.type === 'text' ? 'Textfeld' : e.type === 'image' ? 'Bild' : 'Form'}</b>
      <div class="sl-pgrid">${num('x', 'X', e.x)}${num('y', 'Y', e.y)}${num('w', 'Breite', e.w)}${num('h', 'Höhe', e.h)}${num('rot', 'Drehung°', e.rot || 0)}<label>Deckkraft<input type="range" min="0.05" max="1" step="0.05" value="${s.opacity ?? 1}" data-sl-style="opacity"/></label></div>
      ${e.type !== 'image' ? `<label class="rv-row between">Füllung<input type="color" value="${s.fill && s.fill.startsWith('#') ? s.fill : '#8b5cf6'}" data-sl-style="fill"/></label><button class="rv-btn sm ghost" data-sl="nofill">Keine Füllung</button>` : `<label>Anpassung<select class="rv-input sm" data-sl-style="fit"><option value="cover" ${s.fit !== 'contain' ? 'selected' : ''}>Füllen</option><option value="contain" ${s.fit === 'contain' ? 'selected' : ''}>Einpassen</option></select></label>`}
      <label class="rv-row between">Rahmen<input type="color" value="${s.stroke && s.stroke.startsWith('#') ? s.stroke : '#ffffff'}" data-sl-style="stroke"/></label>
      <label>Rahmenbreite<input type="range" min="0" max="20" value="${s.strokeW || 0}" data-sl-style="strokeW"/></label>
      <label>Ecken<input type="range" min="0" max="120" value="${s.radius || 0}" data-sl-style="radius"/></label>
      ${e.type === 'shape' ? `<label>Text in der Form<input class="rv-input sm" value="${esc(s.text || '')}" data-sl-style="text"/></label>` : ''}
      <div class="rv-row"><button class="rv-btn sm" data-sl="front">Nach vorne</button><button class="rv-btn sm" data-sl="back">Nach hinten</button><button class="rv-btn sm danger" data-sl="del-el">Löschen</button></div></div>`;
  }
  function stageHtml() {
    return `<div class="sl-stage" data-sl-stage><div class="sl-fit" data-sl-fit>${slideHtml(slide(), { edit: st.editing })}<div class="sl-handles" data-sl-handles></div></div></div>`;
  }
  function thumbsHtml() {
    return st.pres.slides.map((sl, i) => `<div class="sl-thumb ${i === st.cur ? 'on' : ''}" data-sl-go="${i}" draggable="true" data-sl-drag="${i}"><span>${i + 1}</span><div class="sl-mini">${miniHtml(st.pres, sl)}</div>${sl.transition?.type && sl.transition.type !== 'none' ? '<i title="Übergang">✦</i>' : ''}</div>`).join('');
  }
  function paint() {
    if (!st.root) return;
    if (!st.pres) {
      st.root.innerHTML = galleryHtml();
      return;
    }
    st.root.innerHTML = `<div class="sl-ed">${ribbonHtml()}<div class="sl-work"><aside class="sl-thumbs">${thumbsHtml()}<button class="sl-add" data-sl="add-slide">＋</button></aside><main class="sl-main">${stageHtml()}</main><aside class="sl-side rv-card">${propsHtml()}</aside></div></div>`;
    layoutStage();
  }
  function paintStage() {
    const m = st.root?.querySelector('.sl-main');
    if (!m) return paint();
    m.innerHTML = stageHtml();
    layoutStage();
    const side = st.root.querySelector('.sl-side');
    if (side) side.innerHTML = propsHtml();
    const th = st.root.querySelector('.sl-thumbs');
    if (th) th.innerHTML = `${thumbsHtml()}<button class="sl-add" data-sl="add-slide">＋</button>`;
  }
  function layoutStage() {
    const stage = st.root?.querySelector('[data-sl-stage]');
    const fit = st.root?.querySelector('[data-sl-fit]');
    if (!stage || !fit) return;
    const r = stage.getBoundingClientRect();
    const sc = Math.min((r.width - 24) / SW, (r.height - 24) / SH);
    st.scale = sc;
    fit.style.transform = `scale(${sc})`;
    fit.style.left = `${(r.width - SW * sc) / 2}px`;
    fit.style.top = `${(r.height - SH * sc) / 2}px`;
    paintHandles();
    if (st.editing) {
      const tx = fit.querySelector(`[data-el="${st.editing}"] .sl-tx`);
      if (tx) {
        tx.focus();
        const range = document.createRange();
        range.selectNodeContents(tx);
        range.collapse(false);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      }
    }
  }
  function paintHandles() {
    const h = st.root?.querySelector('[data-sl-handles]');
    if (!h) return;
    const e = selEl();
    if (!e) {
      h.innerHTML = '';
      return;
    }
    const inv = 1 / (st.scale || 1);
    h.innerHTML = `<div class="sl-box" style="left:${e.x}px;top:${e.y}px;width:${e.w}px;height:${e.h}px;transform:rotate(${e.rot || 0}deg);--inv:${inv}">${['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].map((d) => `<i class="sl-h ${d}" data-sl-resize="${d}"></i>`).join('')}<i class="sl-rot" data-sl-rotate title="Drehen"></i></div>`;
  }

  /* ---------------------------------------------------------------- Bearbeiten */
  function commitEditing() {
    if (!st.editing) return;
    const tx = st.root?.querySelector(`[data-el="${st.editing}"] .sl-tx`);
    const e = slide().els.find((x) => x.id === st.editing);
    if (tx && e && tx.innerHTML !== e.html) {
      snap();
      e.html = tx.innerHTML;
      save();
    }
    st.editing = null;
  }
  function addEl(el) {
    snap();
    slide().els.push(el);
    st.sel = el.id;
    save();
    paintStage();
  }
  function setStyle(k, v) {
    const e = selEl();
    if (!e) return;
    snap();
    e.style[k] = v;
    save();
    paintStage();
  }
  function stagePoint(ev) {
    const fit = st.root.querySelector('[data-sl-fit]');
    const r = fit.getBoundingClientRect();
    return { x: (ev.clientX - r.left) / st.scale, y: (ev.clientY - r.top) / st.scale };
  }
  function onPointerDown(ev) {
    if (!st.root?.contains(ev.target) || !st.pres || st.show) return;
    const stage = ev.target.closest('[data-sl-stage]');
    if (!stage) return;
    const rz = ev.target.closest('[data-sl-resize]')?.dataset.slResize;
    const rot = ev.target.closest('[data-sl-rotate]');
    const elNode = ev.target.closest('[data-el]');
    if (st.editing && elNode?.dataset.el === st.editing) return; // im Text tippen/markieren
    commitEditing();
    const p = stagePoint(ev);
    if (rz || rot) {
      const e = selEl();
      snap();
      st.drag = { kind: rz ? 'resize' : 'rotate', dir: rz, start: p, orig: { x: e.x, y: e.y, w: e.w, h: e.h, rot: e.rot || 0 } };
    } else if (elNode) {
      st.sel = elNode.dataset.el;
      const e = selEl();
      snap();
      st.drag = { kind: 'move', start: p, orig: { x: e.x, y: e.y }, moved: false };
      paintHandles();
      const side = st.root.querySelector('.sl-side');
      if (side) side.innerHTML = propsHtml();
      const rib = st.root.querySelector('.sl-ribbon');
      if (rib) rib.outerHTML = ribbonHtml();
    } else {
      st.sel = null;
      paintStage();
      return;
    }
    stage.setPointerCapture?.(ev.pointerId);
    ev.preventDefault();
  }
  function onPointerMove(ev) {
    const d = st.drag;
    if (!d || !st.root) return;
    const e = selEl();
    if (!e) return;
    const p = stagePoint(ev);
    const dx = p.x - d.start.x;
    const dy = p.y - d.start.y;
    if (d.kind === 'move') {
      if (Math.abs(dx) + Math.abs(dy) > 2) d.moved = true;
      e.x = Math.round(d.orig.x + dx);
      e.y = Math.round(d.orig.y + dy);
      // Hilfslinien: an Folienmitte einrasten
      if (Math.abs(e.x + e.w / 2 - SW / 2) < 8) e.x = Math.round(SW / 2 - e.w / 2);
      if (Math.abs(e.y + e.h / 2 - SH / 2) < 8) e.y = Math.round(SH / 2 - e.h / 2);
    } else if (d.kind === 'resize') {
      const o = d.orig;
      let { x, y, w, h } = o;
      if (d.dir.includes('e')) w = Math.max(20, o.w + dx);
      if (d.dir.includes('s')) h = Math.max(20, o.h + dy);
      if (d.dir.includes('w')) {
        w = Math.max(20, o.w - dx);
        x = o.x + (o.w - w);
      }
      if (d.dir.includes('n')) {
        h = Math.max(20, o.h - dy);
        y = o.y + (o.h - h);
      }
      if (ev.shiftKey && e.type !== 'text') {
        const ratio = o.w / o.h;
        if (w / h > ratio) w = h * ratio;
        else h = w / ratio;
      }
      Object.assign(e, { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) });
    } else if (d.kind === 'rotate') {
      const cx = d.orig.x + d.orig.w / 2;
      const cy = d.orig.y + d.orig.h / 2;
      let a = (Math.atan2(p.y - cy, p.x - cx) * 180) / Math.PI + 90;
      if (ev.shiftKey) a = Math.round(a / 15) * 15;
      e.rot = Math.round(a);
    }
    const node = st.root.querySelector(`[data-sl-fit] [data-el="${e.id}"]`);
    if (node) {
      node.style.left = `${e.x}px`;
      node.style.top = `${e.y}px`;
      node.style.width = `${e.w}px`;
      node.style.height = `${e.h}px`;
      node.style.transform = `rotate(${e.rot || 0}deg)`;
      if (e.type === 'shape') node.innerHTML = shapeSvg(e) + (e.style.text ? node.querySelector('.sl-shape-t')?.outerHTML || '' : '');
    }
    paintHandles();
  }
  function onPointerUp() {
    const d = st.drag;
    if (!d) return;
    st.drag = null;
    if (d.kind === 'move' && !d.moved) st.undo.pop();
    save();
    paintStage();
  }
  function onDblClick(ev) {
    if (!st.root?.contains(ev.target) || !st.pres) return;
    const n = ev.target.closest('[data-sl-fit] [data-el]');
    if (!n) return;
    const e = slide().els.find((x) => x.id === n.dataset.el);
    if (e?.type !== 'text') return;
    st.sel = e.id;
    st.editing = e.id;
    paintStage();
  }

  /* ---------------------------------------------------------------- Bildschirmpräsentation */
  function startShow(from = 0) {
    commitEditing();
    const ov = A.h(`<div class="sl-show" tabindex="0"><div class="sl-show-fit"></div><div class="sl-show-bar"><span data-show-n></span><button data-show="prev">‹</button><button data-show="next">›</button><button data-show="end">✕</button></div></div>`);
    document.body.appendChild(ov);
    st.show = { ov, i: from, step: 0, steps: [] };
    document.documentElement.requestFullscreen?.().catch(() => {});
    const fitShow = () => {
      const f = ov.querySelector('.sl-show-fit');
      const sc = Math.min(window.innerWidth / SW, window.innerHeight / SH);
      f.style.transform = `scale(${sc})`;
      f.style.left = `${(window.innerWidth - SW * sc) / 2}px`;
      f.style.top = `${(window.innerHeight - SH * sc) / 2}px`;
    };
    st.show.fit = fitShow;
    window.addEventListener('resize', fitShow);
    showSlide(from, 'none');
    ov.focus();
  }
  function showSlide(i, dirTrans = 'fwd') {
    const sh = st.show;
    const sl = st.pres.slides[i];
    if (!sl) return endShow();
    const f = sh.ov.querySelector('.sl-show-fit');
    const old = f.firstElementChild;
    const wrap = A.h(`<div class="sl-show-slide">${slideHtml(sl, { show: true })}</div>`);
    const tr = dirTrans === 'none' ? 'none' : sl.transition?.type || 'none';
    const dur = sl.transition?.dur || 600;
    wrap.style.setProperty('--td', `${dur}ms`);
    if (tr !== 'none') wrap.classList.add(`tr-${tr}`, dirTrans === 'back' ? 'tr-back' : 'tr-fwd');
    f.appendChild(wrap);
    if (old) setTimeout(() => old.remove(), tr === 'none' ? 0 : dur);
    sh.i = i;
    // Animationsschritte: Elemente „mit vorheriger“ laufen zusammen
    const els = sl.els.filter((e) => e.anim?.type && e.anim.type !== 'none');
    const steps = [];
    for (const e of els) {
      if (e.anim.withPrev && steps.length) steps[steps.length - 1].push(e);
      else steps.push([e]);
    }
    sh.steps = steps;
    sh.step = 0;
    for (const e of els) wrap.querySelector(`[data-el="${e.id}"]`)?.classList.add('an-wait');
    sh.ov.querySelector('[data-show-n]').textContent = `${i + 1} / ${st.pres.slides.length}`;
    sh.fit();
  }
  function showNext() {
    const sh = st.show;
    if (!sh) return;
    if (sh.step < sh.steps.length) {
      const wrap = sh.ov.querySelector('.sl-show-fit').lastElementChild;
      for (const e of sh.steps[sh.step]) {
        const n = wrap.querySelector(`[data-el="${e.id}"]`);
        if (!n) continue;
        n.style.setProperty('--ad', `${e.anim.dur || 600}ms`);
        n.style.setProperty('--adl', `${e.anim.delay || 0}ms`);
        n.classList.remove('an-wait');
        n.classList.add(`an-${e.anim.type}`);
      }
      sh.step += 1;
      return;
    }
    if (sh.i + 1 >= st.pres.slides.length) return endShow();
    showSlide(sh.i + 1, 'fwd');
  }
  function showPrev() {
    const sh = st.show;
    if (!sh || sh.i <= 0) return;
    showSlide(sh.i - 1, 'back');
    // beim Zurückgehen alle Animationen der Folie schon sichtbar
    const wrap = sh.ov.querySelector('.sl-show-fit').lastElementChild;
    wrap.querySelectorAll('.an-wait').forEach((n) => n.classList.remove('an-wait'));
    sh.step = sh.steps.length;
  }
  function endShow() {
    const sh = st.show;
    if (!sh) return;
    window.removeEventListener('resize', sh.fit);
    sh.ov.remove();
    st.show = null;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  }

  /* ---------------------------------------------------------------- PDF */
  async function exportPdf() {
    commitEditing();
    const css = [...document.styleSheets].map((s) => {
      try {
        return [...s.cssRules].filter((r) => /\.sl-/.test(r.cssText)).map((r) => r.cssText).join('\n');
      } catch {
        return '';
      }
    }).join('\n');
    const pages = st.pres.slides.map((sl) => `<div class="pg">${slideHtml(sl)}</div>`).join('');
    const html = `<!doctype html><html><head><meta charset="utf-8"><style>@page{size:13.333in 7.5in;margin:0}html,body{margin:0;padding:0}.pg{width:13.333in;height:7.5in;overflow:hidden;page-break-after:always;position:relative}.pg>.sl-slide{transform:scale(${(13.333 * 96) / SW});transform-origin:0 0}${css}</style></head><body>${pages}</body></html>`;
    try {
      const f = await window.hub.slidesPdf(html, st.pres.title);
      if (f) A.toast('PDF gespeichert.');
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
  }

  /* ---------------------------------------------------------------- PowerPoint (.pptx) */
  function pptxModel() {
    const th = T();
    const toParas = (html) => {
      const doc = new DOMParser().parseFromString(`<div>${html}</div>`, 'text/html').body.firstChild;
      const out = [];
      const walk = (node, bullet) => {
        for (const n of node.childNodes) {
          if (n.nodeType === 3) {
            const t = n.nodeValue.replace(/\s+/g, ' ');
            if (t.trim()) {
              if (!out.length) out.push({ text: '' });
              out[out.length - 1].text += t;
            }
          } else if (n.nodeType === 1) {
            const tag = n.tagName;
            if (tag === 'BR') out.push({ text: '' });
            else if (tag === 'LI') {
              out.push({ text: n.textContent.trim(), bullet });
            } else if (tag === 'UL' || tag === 'OL') walk(n, tag === 'OL' ? 'num' : 'dot');
            else if (tag === 'TR') out.push({ text: [...n.children].map((c) => c.textContent.trim()).join('   |   ') });
            else if (/^(DIV|P|H\d|TABLE|TBODY|THEAD)$/.test(tag)) {
              if (!/^(TABLE|TBODY|THEAD)$/.test(tag)) out.push({ text: '' });
              walk(n, bullet);
            } else walk(n, bullet);
          }
        }
      };
      walk(doc, null);
      return out.filter((p, i) => p.text.trim() || i === 0);
    };
    return {
      title: st.pres.title,
      slides: st.pres.slides.map((sl) => ({
        bg: sl.bg || th.bg,
        els: sl.els.map((el) => {
          const s = el.style || {};
          const font = s.font || ((s.role === 'title' || s.role === 'sub' ? th.title : th.body).split(',')[0].replace(/['"]/g, ''));
          const base = { type: el.type, x: el.x, y: el.y, w: el.w, h: el.h, rot: el.rot || 0, accent: th.accent, style: { ...s, font, color: s.color || th.fg } };
          if (el.type === 'text') base.paras = toParas(el.html);
          if (el.type === 'image') base.src = el.src;
          return base;
        }),
      })),
    };
  }
  async function exportPptx() {
    commitEditing();
    try {
      const f = await window.hub.slidesPptx(pptxModel());
      if (f) A.toast('PowerPoint-Datei gespeichert.');
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
  }

  /* ---------------------------------------------------------------- Ereignisse */
  document.addEventListener('pointerdown', onPointerDown);
  document.addEventListener('pointermove', onPointerMove);
  document.addEventListener('pointerup', onPointerUp);
  document.addEventListener('dblclick', onDblClick);
  window.addEventListener('resize', () => st.root && document.contains(st.root) && layoutStage());
  document.addEventListener('click', (ev) => {
    if (st.show && st.show.ov.contains(ev.target)) {
      const a = ev.target.closest('[data-show]')?.dataset.show;
      if (a === 'prev') return showPrev();
      if (a === 'end') return endShow();
      return showNext();
    }
    if (!st.root?.contains(ev.target)) return;
    const q = (s) => ev.target.closest(s);
    const nw = q('[data-sl-new]')?.dataset.slNew;
    if (nw) {
      st.pres = newPres(nw);
      st.cur = 0;
      st.sel = null;
      st.undo = [];
      save();
      return paint();
    }
    const op = q('[data-sl-open]')?.dataset.slOpen;
    if (op) {
      st.pres = JSON.parse(JSON.stringify(st.list.find((p) => p.id === op)));
      st.cur = 0;
      st.sel = null;
      st.undo = [];
      return paint();
    }
    const del = q('[data-sl-del]')?.dataset.slDel;
    if (del) {
      if (!window.confirm('Diese Präsentation löschen?')) return;
      st.list = st.list.filter((p) => p.id !== del);
      A.store.set('slides', { list: st.list });
      return paint();
    }
    if (!st.pres) return;
    const tab = q('[data-sl-tab]')?.dataset.slTab;
    if (tab) {
      st.tab = tab;
      return paint();
    }
    const go = q('[data-sl-go]')?.dataset.slGo;
    if (go != null) {
      commitEditing();
      st.cur = Number(go);
      st.sel = null;
      return paint();
    }
    const th = q('[data-sl-theme]')?.dataset.slTheme;
    if (th) {
      snap();
      st.pres.theme = th;
      save();
      return paint();
    }
    const tr = q('[data-sl-trans]')?.dataset.slTrans;
    if (tr) {
      snap();
      slide().transition = { ...(slide().transition || {}), type: tr };
      save();
      return paint();
    }
    const an = q('[data-sl-anim]')?.dataset.slAnim;
    if (an && selEl()) {
      snap();
      selEl().anim = { ...(selEl().anim || {}), type: an };
      save();
      return paint();
    }
    const tg = q('[data-sl-toggle]')?.dataset.slToggle;
    if (tg && selEl()) return setStyle(tg, !selEl().style[tg]);
    const al = q('[data-sl-align]')?.dataset.slAlign;
    if (al && selEl()) return setStyle('align', al);
    const shp = q('[data-sl-shape]')?.dataset.slShape;
    if (shp) return addEl({ id: uid(), type: 'shape', x: 600, y: 300, w: shp === 'line' ? 500 : 400, h: shp === 'line' ? 20 : 300, rot: 0, style: { shape: shp, fill: '', stroke: '', strokeW: 0, radius: 0, opacity: 1, text: '' }, anim: { type: 'none', dur: 600, delay: 0 } });
    const a = q('[data-sl]')?.dataset.sl;
    if (!a) return;
    commitEditing();
    const sl = slide();
    const i = st.cur;
    switch (a) {
      case 'home': st.pres = null; break;
      case 'undo': return undo(true);
      case 'redo': return undo(false);
      case 'add-slide': snap(); st.pres.slides.splice(i + 1, 0, newSlide('content')); st.cur = i + 1; st.sel = null; break;
      case 'dup': snap(); st.pres.slides.splice(i + 1, 0, { ...JSON.parse(JSON.stringify(sl)), id: uid(), els: sl.els.map((e) => ({ ...JSON.parse(JSON.stringify(e)), id: uid() })) }); st.cur = i + 1; break;
      case 'del-slide': if (st.pres.slides.length > 1) { snap(); st.pres.slides.splice(i, 1); st.cur = Math.max(0, i - 1); st.sel = null; } break;
      case 'add-text': return addEl(textEl(500, 380, 600, 120, 'Neuer Text', { size: 44 }));
      case 'add-table': {
        const rows = Array.from({ length: 3 }, (_, r) => `<tr>${Array.from({ length: 3 }, (_, c) => (r ? `<td>Zelle</td>` : `<th>Spalte ${c + 1}</th>`)).join('')}</tr>`).join('');
        return addEl(textEl(300, 260, 1000, 360, `<table class="sl-table">${rows}</table>`, { size: 30 }));
      }
      case 'add-image': {
        const inp = document.createElement('input');
        inp.type = 'file';
        inp.accept = 'image/*';
        inp.onchange = () => {
          const f = inp.files?.[0];
          if (!f) return;
          const rd = new FileReader();
          rd.onload = () => {
            const img = new Image();
            img.onload = () => {
              // auf max. 1600 px verkleinern, damit die Datei klein bleibt
              const sc = Math.min(1, 1600 / Math.max(img.width, img.height));
              const c = document.createElement('canvas');
              c.width = Math.round(img.width * sc);
              c.height = Math.round(img.height * sc);
              c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
              const src = c.toDataURL(f.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.86);
              const w = Math.min(1000, c.width);
              const h = (w * c.height) / c.width;
              addEl({ id: uid(), type: 'image', src, x: (SW - w) / 2, y: (SH - h) / 2, w, h, rot: 0, style: { radius: 0, opacity: 1, fit: 'cover' }, anim: { type: 'none', dur: 600, delay: 0 } });
            };
            img.src = rd.result;
          };
          rd.readAsDataURL(f);
        };
        inp.click();
        return;
      }
      case 'bullets':
      case 'numbers': {
        const e = selEl();
        if (e?.type !== 'text') return;
        snap();
        const plain = e.html.replace(/<\/(li|p|div)>/g, '\n').replace(/<br\s*\/?>/g, '\n').replace(/<[^>]+>/g, '').split('\n').map((x) => x.trim()).filter(Boolean);
        const tag = a === 'bullets' ? 'ul' : 'ol';
        e.html = /^<(ul|ol)>/.test(e.html) && e.html.startsWith(`<${tag}>`) ? plain.map((x) => `<div>${esc(x)}</div>`).join('') : `<${tag}>${plain.map((x) => `<li>${esc(x)}</li>`).join('')}</${tag}>`;
        break;
      }
      case 'bg-reset': snap(); sl.bg = ''; break;
      case 'bg-all': snap(); for (const s of st.pres.slides) s.bg = sl.bg; break;
      case 'trans-all': snap(); for (const s of st.pres.slides) s.transition = { ...sl.transition }; break;
      case 'nofill': if (selEl()) { snap(); selEl().style.fill = selEl().type === 'shape' ? 'transparent' : ''; } break;
      case 'front': { const e = selEl(); if (e) { snap(); sl.els = [...sl.els.filter((x) => x !== e), e]; } break; }
      case 'back': { const e = selEl(); if (e) { snap(); sl.els = [e, ...sl.els.filter((x) => x !== e)]; } break; }
      case 'del-el': { const e = selEl(); if (e) { snap(); sl.els = sl.els.filter((x) => x !== e); st.sel = null; } break; }
      case 'preview-anim': {
        const e = selEl();
        const n = e && st.root.querySelector(`[data-sl-fit] [data-el="${e.id}"]`);
        if (!n || !e.anim?.type || e.anim.type === 'none') return;
        n.style.setProperty('--ad', `${e.anim.dur || 600}ms`);
        n.style.setProperty('--adl', '0ms');
        n.classList.remove(`an-${e.anim.type}`);
        void n.offsetWidth;
        n.classList.add(`an-${e.anim.type}`);
        return;
      }
      case 'show-start': return startShow(0);
      case 'show-cur': return startShow(st.cur);
      case 'pdf': return exportPdf();
      case 'pptx': return exportPptx();
      default: return;
    }
    save();
    paint();
  });
  document.addEventListener('change', (ev) => {
    if (!st.root?.contains(ev.target) || !st.pres) return;
    const t = ev.target;
    if (t.matches('[data-sl-title]')) {
      st.pres.title = t.value.trim().slice(0, 80) || 'Präsentation';
      return save();
    }
    if (t.matches('[data-sl-layout]')) {
      snap();
      const sl = slide();
      sl.layout = t.value;
      sl.els = layoutEls(t.value);
      st.sel = null;
      save();
      return paint();
    }
    const k = t.dataset.slStyle;
    if (k) return setStyle(k, t.type === 'number' || t.type === 'range' ? Number(t.value) : t.value);
    const g = t.dataset.slGeo;
    if (g && selEl()) {
      snap();
      selEl()[g] = Number(t.value) || 0;
      save();
      return paintStage();
    }
    if (t.matches('[data-sl-slidebg]')) {
      snap();
      slide().bg = t.value;
      save();
      return paint();
    }
    if (t.matches('[data-sl-transdur]')) {
      slide().transition = { ...(slide().transition || { type: 'fade' }), dur: Number(t.value) || 600 };
      return save();
    }
    const ap = t.dataset.slAnimprop;
    if (ap && selEl()) {
      selEl().anim[ap] = Number(t.value) || 0;
      return save();
    }
    if (t.matches('[data-sl-animwith]') && selEl()) {
      selEl().anim.withPrev = t.checked;
      return save();
    }
  });
  document.addEventListener('input', (ev) => {
    if (!st.root?.contains(ev.target) || !st.pres) return;
    if (ev.target.matches('[data-sl-notes]')) {
      slide().notes = ev.target.value;
      save();
    }
  });
  // Folien per Ziehen umsortieren
  document.addEventListener('dragstart', (ev) => {
    const d = ev.target.closest?.('[data-sl-drag]');
    if (!d || !st.root?.contains(d)) return;
    st.dragSlide = Number(d.dataset.slDrag);
    ev.dataTransfer.effectAllowed = 'move';
  });
  document.addEventListener('dragover', (ev) => {
    if (st.dragSlide != null && ev.target.closest?.('[data-sl-drag]')) ev.preventDefault();
  });
  document.addEventListener('drop', (ev) => {
    const d = ev.target.closest?.('[data-sl-drag]');
    if (st.dragSlide == null || !d) return;
    ev.preventDefault();
    const to = Number(d.dataset.slDrag);
    const from = st.dragSlide;
    st.dragSlide = null;
    if (from === to) return;
    snap();
    const [m] = st.pres.slides.splice(from, 1);
    st.pres.slides.splice(to, 0, m);
    st.cur = to;
    save();
    paint();
  });
  document.addEventListener('keydown', (ev) => {
    if (st.show) {
      if (['ArrowRight', 'ArrowDown', ' ', 'PageDown', 'Enter'].includes(ev.key)) showNext();
      else if (['ArrowLeft', 'ArrowUp', 'PageUp', 'Backspace'].includes(ev.key)) showPrev();
      else if (ev.key === 'Escape') endShow();
      else if (ev.key === 'Home') showSlide(0, 'none');
      else if (ev.key === 'End') showSlide(st.pres.slides.length - 1, 'none');
      else return;
      ev.preventDefault();
      return;
    }
    if (!st.root || !document.contains(st.root) || !st.pres) return;
    const typing = st.editing || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '');
    if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'z' && !st.editing) {
      ev.preventDefault();
      return undo(!ev.shiftKey);
    }
    if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'y' && !st.editing) {
      ev.preventDefault();
      return undo(false);
    }
    if (ev.key === 'F5') {
      ev.preventDefault();
      return startShow(ev.shiftKey ? st.cur : 0);
    }
    if (ev.key === 'Escape' && st.editing) {
      commitEditing();
      return paintStage();
    }
    if (typing) return;
    const e = selEl();
    if ((ev.key === 'Delete' || ev.key === 'Backspace') && e) {
      snap();
      slide().els = slide().els.filter((x) => x !== e);
      st.sel = null;
      save();
      return paintStage();
    }
    if (e && ev.key.startsWith('Arrow')) {
      const step = ev.shiftKey ? 20 : 2;
      snap();
      if (ev.key === 'ArrowLeft') e.x -= step;
      if (ev.key === 'ArrowRight') e.x += step;
      if (ev.key === 'ArrowUp') e.y -= step;
      if (ev.key === 'ArrowDown') e.y += step;
      save();
      ev.preventDefault();
      return paintStage();
    }
    if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'd' && e) {
      ev.preventDefault();
      return addEl({ ...JSON.parse(JSON.stringify(e)), id: uid(), x: e.x + 30, y: e.y + 30 });
    }
  });
  document.addEventListener('focusout', (ev) => {
    if (st.editing && ev.target.matches?.('.sl-tx[contenteditable]') && !ev.relatedTarget?.closest?.('.sl-ribbon')) {
      commitEditing();
      paintStage();
    }
  });

  A.define(
    ID,
    { nav: 'Showtime', title: 'Showtime', sub: 'Präsentationen wie PowerPoint', icon: 'doc', tint: 'linear-gradient(135deg,#fb923c,#c2410c)', desc: 'Folien mit Designvorlagen, Layouts, Schriftarten, Formen, Bildern, Tabellen, Animationen und Übergängen – präsentieren im Vollbild oder als PDF speichern.' },
    {
      async mount(root) {
        st.root = root;
        root.innerHTML = '<div class="rv-empty">Lädt …</div>';
        await load();
        if (st.root === root) paint();
      },
      unmount() {
        commitEditing();
        st.root = null;
      },
      wide: true,
    },
  );
})();
