'use strict';

/*
 * Obere Leiste: das R-Logo, die angehefteten/laufenden Apps der echten
 * Windows-Taskleiste und rechts die Hub-Kontrollen. Alles schwarz, die Leiste
 * selbst transparent. Das Windows-Popup hängt als kleine Karte unter dem Logo.
 */
(() => {
  const $ = (selector) => document.querySelector(selector);
  const esc = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

  let state = null;
  let clockTimer = 0;
  let lastKey = '';
  let drawerWasOpen = false;
  let interactive = null;
  let screenData = null;
  let screenLoading = false;

  function setInteractive(on) {
    if (on === interactive) return;
    interactive = on;
    window.hub.taskbar?.interactive?.(on).catch(() => {});
  }

  const windowsApps = () => (state?.windowsApps || []).slice(0, 18);

  function clockHtml() {
    return '<span class="tb-clock-time" data-clock-time>--:--</span><span class="tb-clock-date" data-clock-date>Revulution</span>';
  }

  function fallback(name) {
    return `<span class="tb-win-fallback">${esc(String(name || '?').slice(0, 1).toUpperCase())}</span>`;
  }

  function appButton(item) {
    const label = item.title || item.name;
    return `<button class="tb-winbtn ${item.self ? 'is-self' : ''} ${item.focused ? 'is-focused' : ''}" data-winapp="${esc(item.id)}" title="${esc(label)}">
      ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
      ${item.kind === 'running' ? '<i class="tb-running"></i>' : ''}
    </button>`;
  }

  const windowsMark = () => `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3 5.2 10.4 4v7.2H3zm8.6-1.35L21 2.6v8.6h-9.4zM3 12.8h7.4V20L3 18.8zm8.6 0H21v8.8l-9.4-1.25z"/></svg>`;

  const TOP_ITEMS = {
    crosshair: { icon: 'crosshair', title: 'Crosshair ein- oder ausschalten' },
    screentime: { icon: 'clock', title: 'Bildschirmzeit öffnen' },
    speed: { icon: 'globe', title: 'WLAN-Test öffnen' },
    settings: { icon: 'settings', title: 'Einstellungen öffnen' },
  };

  function extraHtml() {
    const items = (state?.topbarItems || ['crosshair', 'screentime', 'speed']).filter((id) => TOP_ITEMS[id]);
    return items
      .map((id) => {
        const item = TOP_ITEMS[id];
        if (id === 'crosshair') {
          return `<button class="tb-iconbtn tb-cross ${state?.crosshairOn ? 'on' : ''}" data-tb-top="crosshair" title="${esc(item.title)}">${window.icon(item.icon, 15)}</button>`;
        }
        return `<button class="tb-iconbtn" data-tb-top="${id}" title="${esc(item.title)}">${window.icon(item.icon, 15)}</button>`;
      })
      .join('');
  }

  /* 2.46 Neue Leiste unten: Start · angeheftete/laufende Apps · Medien · Infobereich · Uhr · Glocke.
     Transparenz kommt aus den Einstellungen (Desktop-App → Taskleiste). */
  let trayOpen = false;
  let media = null;
  const startMark = () => '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="1" y="1" width="8" height="8" rx="1.6"/><rect x="11" y="1" width="8" height="8" rx="1.6"/><rect x="1" y="11" width="8" height="8" rx="1.6"/><rect x="11" y="11" width="8" height="8" rx="1.6"/></svg>';
  const ic = {
    wifi: '<svg viewBox="0 0 24 24"><path d="M2.5 9a14 14 0 0 1 19 0M5.8 12.4a9.3 9.3 0 0 1 12.4 0M9.2 15.8a4.5 4.5 0 0 1 5.6 0"/><circle cx="12" cy="19" r="1.3" fill="currentColor" stroke="none"/></svg>',
    vol: '<svg viewBox="0 0 24 24"><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor" stroke="none"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18.2 6.5a8 8 0 0 1 0 11"/></svg>',
    power: '<svg viewBox="0 0 24 24"><path d="M12 3.5v8"/><path d="M7.2 6.6a7.5 7.5 0 1 0 9.6 0"/></svg>',
    bell: '<svg viewBox="0 0 24 24"><path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 1.5h-15z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/></svg>',
    chev: '<svg viewBox="0 0 24 24"><path d="m14.5 6-6 6 6 6"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><rect x="6.5" y="5" width="3.6" height="14" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.9" y="5" width="3.6" height="14" rx="1.2" fill="currentColor" stroke="none"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l10.5-6.5z" fill="currentColor" stroke="none"/></svg>',
  };
  function mediaHtml() {
    const m = media;
    if (!m?.title) return '';
    const art = m.art ? `style="background-image:url('data:image/jpeg;base64,${m.art}')"` : '';
    return `<div class="tbx-media" title="${esc(m.title)}${m.artist ? ` – ${esc(m.artist)}` : ''}"><button class="tbx-art" data-act="player" ${art}></button><button class="tbx-ib tbx-pp" data-media="playpause">${m.playing ? ic.pause : ic.play}</button></div>`;
  }
  function trayHtml() {
    if (!trayOpen) return '';
    return `<div class="tbx-tray">${extraHtml()}<button class="tb-iconbtn" data-act="control" title="Kontrollzentrum">${window.icon('control', 15)}</button><button class="tb-iconbtn" data-act="settings" title="Einstellungen">${window.icon('settings', 15)}</button><button class="tb-iconbtn tb-power" data-act="quit" title="Revulution Hub beenden">${window.icon('power', 15)}</button></div>`;
  }
  function tbxApp(item) {
    const label = item.title || item.name;
    return `<button class="tbx-app ${item.focused ? 'is-focused' : ''} ${item.kind === 'running' ? 'is-running' : ''}" data-winapp="${esc(item.id)}" title="${esc(label)}">
      ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}<i class="tbx-run"></i></button>`;
  }
  function barHtml() {
    return `<div class="tbx-bar" style="--tbx-a:${Math.max(0, Math.min(1, Number(state?.opacity ?? 0.88)))}">
      <div class="tbx-shell">
        <div class="tbx-glass" aria-hidden="true"></div><svg class="tbx-bg" aria-hidden="true"><path d="" /></svg>
        <button class="tbx-start ${state?.drawer ? 'is-open' : ''}" data-act="drawer" title="Start · Apps und Suche">${startMark()}</button>
        <div class="tbx-apps">${windowsApps().map(tbxApp).join('')}</div>
        <span class="tbx-sep"></span>
        <div class="tbx-media-slot">${mediaHtml()}</div>
        <div class="tbx-tray-slot">${trayHtml()}</div>
        <button class="tbx-ib tbx-chev ${trayOpen ? 'open' : ''}" data-act="tray" title="${trayOpen ? 'Weniger' : 'Mehr anzeigen'}">${ic.chev}</button>
        <button class="tbx-ib tbx-sys" data-act="sound" title="Lautstärke und Netzwerk">${ic.wifi}${ic.vol}</button>
        <button class="tbx-clock" data-act="agenda" title="Agenda"><b data-clock-time>--:--</b><small data-clock-num></small></button>
        <button class="tbx-ib tbx-power" data-act="power" title="Herunterfahren, Neu starten oder planen">${ic.power}</button>
        <button class="tbx-ib tbx-bell" data-act="notify" title="Mitteilungen">${ic.bell}${state?.badges ? '<i class="tbx-badge"></i>' : ''}</button>
        <span class="tbx-edge" data-act="show-desktop" title="Desktop anzeigen"></span>
      </div>
    </div>`;
  }
  window.hub.onMedia?.((m) => {
    if (!m) return;
    const same = media && media.title === m.title;
    media = { ...m, art: m.art || (same ? media.art : '') };
    const slot = document.querySelector('.tbx-media-slot');
    if (slot) slot.innerHTML = mediaHtml();
  });
  /* 2.46 Teile der Leiste aktualisieren, ohne sie neu aufzubauen */
  function updateBar() {
    const bar = document.querySelector('.tbx-bar');
    if (!bar) return;
    bar.style.setProperty('--tbx-a', String(Math.max(0, Math.min(1, Number(state?.opacity ?? 0.88)))));
    bar.style.setProperty('--tbx-s', String(Math.max(0.7, Math.min(1.6, Number(state?.scale ?? 1)))));
    bar.classList.toggle('autohide', Boolean(state?.autoHide));
    // Apps: vorhandene Knöpfe wiederverwenden (kein Flackern), nur Neues anlegen, Altes entfernen
    const box = bar.querySelector('.tbx-apps');
    const have = new Map([...box.children].map((el) => [el.dataset.winapp, el]));
    const wanted = windowsApps();
    wanted.forEach((item, i) => {
      let el = have.get(item.id);
      if (!el) {
        const t = document.createElement('div');
        t.innerHTML = tbxApp(item).trim();
        el = t.firstElementChild;
        el.classList.add('tbx-new');
      } else have.delete(item.id);
      el.classList.toggle('is-focused', Boolean(item.focused));
      el.classList.toggle('is-running', item.kind === 'running');
      el.title = item.title || item.name;
      if (box.children[i] !== el) box.insertBefore(el, box.children[i] || null);
    });
    for (const el of have.values()) el.remove();
    const tray = bar.querySelector('.tbx-tray-slot');
    if (tray) tray.innerHTML = trayHtml();
    bar.querySelector('.tbx-chev')?.classList.toggle('open', trayOpen);
    const bell = bar.querySelector('.tbx-bell');
    if (bell) { bell.querySelector('.tbx-badge')?.remove(); if (state?.badges) bell.insertAdjacentHTML('beforeend', '<i class="tbx-badge"></i>'); }
    hillShape();
  }

  /* 2.46 Hügel: Die Leiste wölbt sich dort nach oben, wo die Maus ist – und alles darunter hebt sich mit */
  const hill = { a: 0, ta: 0, mx: 0, tx: 0, raf: 0, centers: null };
  const BUMP = 18;
  function hillShape() {
    const shell = document.querySelector('.tbx-shell');
    const svg = shell?.querySelector('.tbx-bg');
    if (!svg) return;
    const box = shell.getBoundingClientRect(); const w = box.width, h = box.height, r = 16, sig = 58; // 2.47.6: genaue (Bruch-)Breite – sonst Spalt rechts
    svg.setAttribute('viewBox', `0 0 ${w} ${h + BUMP}`);
    const smooth = (t) => (t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t));
    const corner = (x) => { const dx = x < r ? r - x : x > w - r ? x - (w - r) : 0; return r - Math.sqrt(Math.max(0, r * r - dx * dx)); };
    let d = `M0,${h + BUMP} L0,${(BUMP + r).toFixed(2)}`;
    for (let x = 0; x <= w; x += 2) {
      const edge = smooth(Math.min(x, w - x) / (r + 26));
      const y = BUMP + corner(x) - hill.a * edge * Math.exp(-((x - hill.mx) ** 2) / (2 * sig * sig));
      d += ` L${x},${y.toFixed(2)}`;
    }
    d += ` L${w},${(BUMP + r).toFixed(2)} L${w},${h + BUMP} Z`;
    svg.firstElementChild.setAttribute('d', d);
    // 2.47.2: Weichzeichner in exakt derselben Form – Welle und Leiste wirken gleich hell
    const glass = shell.querySelector('.tbx-glass');
    if (glass) glass.style.clipPath = `path('${d}')`;
  }
  function hillLift() {
    const shell = document.querySelector('.tbx-shell');
    if (!shell) return;
    const items = shell.querySelectorAll(':scope > button, :scope > .tbx-apps > button, :scope > .tbx-media-slot .tbx-media, :scope > .tbx-tray-slot .tb-iconbtn');
    for (const el of items) {
      let cx = el.offsetLeft + el.offsetWidth / 2;
      if (el.parentElement !== shell) { let p = el.offsetParent; while (p && p !== shell) { cx += p.offsetLeft; p = p.offsetParent; } }
      const lift = hill.a * Math.exp(-((cx - hill.mx) ** 2) / (2 * 58 * 58));
      el.style.transform = lift > 0.05 ? `translateY(${(-lift * 0.75).toFixed(2)}px) scale(${(1 + lift / 95).toFixed(4)})` : '';
    }
  }
  function hillTick() {
    hill.raf = 0;
    hill.a += (hill.ta - hill.a) * 0.16;
    hill.mx += (hill.tx - hill.mx) * 0.22;
    hillShape();
    hillLift();
    if (Math.abs(hill.ta - hill.a) > 0.02 || Math.abs(hill.tx - hill.mx) > 0.3) hill.raf = requestAnimationFrame(hillTick);
  }
  const hillGo = () => { if (!hill.raf) hill.raf = requestAnimationFrame(hillTick); };
  let peekT = 0;
  function hillBind() {
    const shell = document.querySelector('.tbx-shell');
    if (!shell) return;
    hillShape();
    new ResizeObserver(() => hillShape()).observe(shell);
    shell.addEventListener('pointermove', (e) => {
      const r = shell.getBoundingClientRect();
      const s = r.width / Math.max(1, shell.offsetWidth);
      hill.tx = (e.clientX - r.left) / s;
      if (hill.ta === 0) hill.mx = hill.tx;
      hill.ta = 11;
      hillGo();
    });
    document.addEventListener('pointermove', (e) => {
      const r = shell.getBoundingClientRect();
      const inside = e.clientX >= r.left - 4 && e.clientX <= r.right + 4 && e.clientY >= r.top - 22 && e.clientY <= r.bottom + 4;
      if (!inside && hill.ta) { hill.ta = 0; hillGo(); }
    });
    // Klick-Effekt: kurz größer werden statt einsinken
    shell.addEventListener('pointerdown', (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      b.classList.remove('tbx-click');
      void b.offsetWidth;
      b.classList.add('tbx-click');
      setTimeout(() => b.classList.remove('tbx-click'), 460);
    });
  }
  // Automatisch ausblenden: unten bleibt ein schmaler Streifen, Maus an den Rand holt die Leiste
  document.addEventListener('mousemove', (e) => {
    const bar = document.querySelector('.tbx-bar.autohide');
    if (!bar) return;
    const near = e.clientY >= window.innerHeight - 6 || e.target.closest?.('.tbx-shell, .tb-pop');
    if (near) { clearTimeout(peekT); bar.classList.add('peek'); }
    else if (bar.classList.contains('peek') && !document.body.classList.contains('drawer-open')) { clearTimeout(peekT); peekT = setTimeout(() => bar.classList.remove('peek'), 650); }
  });

  /* 2.46 Maus-Tor: klickbare Flächen an den Hauptprozess melden */
  let rectKey = '';
  function reportRects() {
    const rects = [];
    const add = (el, padTop = 0) => { if (!el) return; const r = el.getBoundingClientRect(); if (r.width && r.height) rects.push({ x: Math.floor(r.left - 2), y: Math.floor(r.top - padTop), w: Math.ceil(r.width + 4), h: Math.ceil(r.height + padTop + 2) }); };
    add(document.querySelector('.tbx-shell'), 20);
    if (document.body.classList.contains('drawer-open')) document.querySelectorAll('.tb-pop, .tb-speed, .tb-screen').forEach((el) => add(el));
    if (document.querySelector('.tbx-bar.autohide')) rects.push({ x: 0, y: window.innerHeight - 6, w: window.innerWidth, h: 6 });
    const key = JSON.stringify(rects);
    if (key !== rectKey) { rectKey = key; window.hub.hitRects?.(rects); }
  }
  setInterval(reportRects, 500);
  window.hub.onHoverOut?.(() => { hill.ta = 0; hillGo(); const bar = document.querySelector('.tbx-bar.autohide'); if (bar && !document.body.classList.contains('drawer-open')) { clearTimeout(peekT); peekT = setTimeout(() => bar.classList.remove('peek'), 650); } });

  /* 2.47.5 Herunterfahren: sofort (mit Bestätigung), Neu starten, Sperren und zu einer Uhrzeit planen */
  const pw = { confirm: '', at: 0, t: 0 };
  const hhmm = (ms) => new Date(ms).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  function powerHtml() {
    const def = new Date(Date.now() + 60 * 60000);
    const val = `${String(def.getHours()).padStart(2, '0')}:${String(def.getMinutes()).padStart(2, '0')}`;
    const big = (act, label, cls = '') => `<button class="tbp-btn ${cls} ${pw.confirm === act ? 'sure' : ''}" data-act="${act}">${pw.confirm === act ? 'Wirklich? Nochmal klicken' : label}</button>`;
    return `<div class="tb-pop tb-sound tb-power-pop" role="dialog" aria-label="Herunterfahren"><section class="tbs-card">
      <div class="tbp-row">${big('pw-off', 'Herunterfahren', 'red')}${big('pw-restart', 'Neu starten')}<button class="tbp-btn" data-act="pw-lock">Sperren</button></div>
      <div class="tbp-plan"><b>Herunterfahren planen</b>
        ${pw.at ? `<div class="tbp-set"><span>Fährt um <b>${hhmm(pw.at)}</b> herunter</span><button class="tbp-mini" data-act="pw-cancel">Abbrechen</button></div>` : ''}
        <div class="tbp-chips"><button class="tbp-mini" data-pw-in="30">in 30 min</button><button class="tbp-mini" data-pw-in="60">in 1 h</button><button class="tbp-mini" data-pw-in="120">in 2 h</button></div>
        <div class="tbp-time"><input type="time" value="${val}" data-pw-time aria-label="Uhrzeit" /><button class="tbp-mini go" data-act="pw-plan">Planen</button></div>
      </div>
    </section></div>`;
  }
  function powerRefresh() {
    const old = document.querySelector('.tb-power-pop');
    if (!old) return;
    const t = document.createElement('div');
    t.innerHTML = powerHtml();
    old.replaceWith(t.firstElementChild);
  }
  function powerLoad() {
    window.hub.taskbar?.power?.('status').then((r) => { pw.at = r?.at || 0; powerRefresh(); }).catch(() => {});
  }
  async function powerPlan(at) {
    try {
      const r = await window.hub.taskbar.power('schedule', at);
      pw.at = r?.at || 0;
    } catch {
      pw.at = 0;
    }
    powerRefresh();
  }
  document.addEventListener('click', (e) => {
    const chip = e.target.closest?.('[data-pw-in]');
    if (chip) powerPlan(Date.now() + Number(chip.dataset.pwIn) * 60000);
  });

  /* 2.46 Ton & Netz: Lautstärke direkt ändern, WLAN sehen und wechseln */
  const snd = { level: 50, muted: false, net: null, t: 0 };
  function soundHtml() {
    return `<div class="tb-pop tb-sound" role="dialog" aria-label="Ton und Netzwerk"><section class="tbs-card">
      <div class="tbs-row"><button class="tbs-ic" data-act="snd-mute" title="Stumm">${ic.vol}</button>
        <input class="tbs-vol" type="range" min="0" max="100" step="1" value="${snd.level}" data-snd-vol aria-label="Lautstärke" /><b class="tbs-val" data-snd-val>${snd.level}</b></div>
      <button class="tbs-net" data-act="snd-net"><span class="tbs-ic on">${ic.wifi}</span><span><b data-snd-ssid>${esc(snd.net?.ssid || (snd.net?.wired ? 'Kabel / Ethernet' : 'Netzwerk'))}</b><small data-snd-sig>${snd.net?.signal ? `Signal ${snd.net.signal} %` : 'Netzwerke anzeigen'}</small></span><i>›</i></button>
      <button class="tbs-link" data-act="snd-out">Ausgabegerät &amp; Ton-Einstellungen</button>
    </section></div>`;
  }
  function soundApply(v) {
    if (!v) return;
    snd.level = v.level; snd.muted = v.muted;
    const r = document.querySelector('[data-snd-vol]'); if (r && document.activeElement !== r) r.value = String(v.muted ? 0 : v.level);
    const o = document.querySelector('[data-snd-val]'); if (o) o.textContent = v.muted ? '0' : String(v.level);
    document.querySelector('.tb-sound')?.classList.toggle('muted', v.muted);
  }
  function soundLoad() {
    window.hub.cc?.volume?.().then(soundApply).catch(() => {});
    window.hub.taskbar?.net?.().then((n) => { snd.net = n; const s = document.querySelector('[data-snd-ssid]'); if (s) s.textContent = n.ssid || (n.wired ? 'Kabel / Ethernet' : 'Nicht verbunden'); const g = document.querySelector('[data-snd-sig]'); if (g) g.textContent = n.signal ? `Signal ${n.signal} %` : 'Netzwerke anzeigen'; }).catch(() => {});
  }
  document.addEventListener('input', (e) => {
    if (!e.target.matches?.('[data-snd-vol]')) return;
    const v = Number(e.target.value);
    const o = document.querySelector('[data-snd-val]'); if (o) o.textContent = String(v);
    clearTimeout(snd.t);
    snd.t = setTimeout(() => window.hub.cc?.volume?.(v).then(soundApply).catch(() => {}), 60);
  });

  function oldBarHtml() {
    return `<div class="tb-bar tb-bottom">
      <div class="tb-pill tb-dock">
      <button class="tb-logo ${state?.drawer ? 'is-open' : ''}" data-act="drawer" title="Desktop · Apps und Widgets">
        <img src="assets/mark.png" alt="R" draggable="false" /><i class="tb-logo-dot"></i>
      </button>
      <span class="tb-divider"></span>
      <div class="tb-apps">${windowsApps().map(appButton).join('')}</div>
      <span class="tb-divider"></span>
      ${extraHtml() ? `<div class="tb-extra">${extraHtml()}</div>` : ''}
      <div class="tb-right">
        <button class="tb-iconbtn" data-act="control" title="Kontrollzentrum">${window.icon('control', 15)}</button>
        <button class="tb-iconbtn tb-power" data-act="quit" title="Revulution Hub beenden">${window.icon('power', 15)}</button>
        <button class="tb-iconbtn" data-act="settings" title="Einstellungen">${window.icon('settings', 15)}${state?.dnd ? '<i class="tb-dot"></i>' : ''}</button>
        <span class="tb-divider"></span>
        <button class="tb-clock" data-act="agenda" title="Agenda">${clockHtml()}</button>
      </div>
    </div>
    </div>`;
  }

  function drawerGrid() {
    const items = windowsApps();
    if (!items.length) {
      return `<p class="drawer-empty">${state?.windowsApps ? 'Keine Apps offen oder angeheftet.' : 'Windows-Apps werden geladen …'}</p>`;
    }
    return items
      .map(
        (item, i) =>
          `<button class="drawer-item" style="--i:${i}" data-winapp="${esc(item.id)}" title="${esc(item.title || item.name)}">
            ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
            <b>${esc(item.name)}</b>${item.kind === 'running' ? '<i class="drawer-run"></i>' : ''}
          </button>`,
      )
      .join('');
  }

  /* Suche: Apps aus dem Startmenü (auch Store-Apps) und Dateien aus dem Windows-Suchindex. */
  let searchSeq = 0;
  let searchTimer = 0;
  let firstResult = '';
  function resultsHtml(q, res, loading) {
    const ql = q.toLocaleLowerCase('de');
    const open = windowsApps().filter((item) => String(item.title || item.name).toLocaleLowerCase('de').includes(ql));
    const apps = (res?.apps || []).filter((a) => !open.some((o) => o.name.toLocaleLowerCase('de') === a.name.toLocaleLowerCase('de')));
    const files = res?.files || [];
    firstResult = open[0] ? `win:${open[0].id}` : apps[0] ? `res:${apps[0].id}` : files[0] ? `res:${files[0].id}` : '';
    const appTile = (a, i, attr) => `<button class="drawer-item" style="--i:${i}" ${attr} title="${esc(a.name)}">${a.icon ? `<img src="${esc(a.icon)}" alt="" draggable="false" />` : fallback(a.name)}<b>${esc(a.name)}</b></button>`;
    let html = '';
    const tiles = [...open.map((o, i) => appTile(o, i, `data-winapp="${esc(o.id)}"`)), ...apps.map((a, i) => appTile(a, i + open.length, `data-result="${esc(a.id)}"`))];
    if (tiles.length) html += `<div class="drawer-sec">APPS</div>${tiles.slice(0, 12).join('')}`;
    if (files.length) {
      html += `<div class="drawer-sec">DATEIEN</div><div class="drawer-files">${files
        .map((f, i) => `<button class="drawer-file" style="--i:${i}" data-result="${esc(f.id)}" title="${esc(f.name)}">${f.icon ? `<img src="${esc(f.icon)}" alt="" draggable="false" />` : '<span class="drawer-file-ic"></span>'}<b>${esc(f.name)}</b><small>${esc(f.dir)}</small></button>`)
        .join('')}</div>`;
    }
    if (loading) html += `<p class="drawer-searching"><i></i><i></i><i></i></p>`;
    if (!html) html = `<p class="drawer-empty">Nichts gefunden für „${esc(q)}“.</p>`;
    return html;
  }
  function runSearch(value) {
    const grid = $('[data-drawer-grid]');
    if (!grid) return;
    const q = String(value || '').trim();
    clearTimeout(searchTimer);
    const seq = ++searchSeq;
    grid.classList.toggle('is-search', Boolean(q));
    if (!q) {
      firstResult = '';
      grid.innerHTML = drawerGrid();
      return;
    }
    grid.innerHTML = resultsHtml(q, null, true);
    searchTimer = setTimeout(async () => {
      // Erst die Apps (sofort), dann die Dateien (Suchindex) – nichts wartet aufeinander.
      const res = { apps: [], files: [] };
      const paint = (loading) => {
        if (seq !== searchSeq) return;
        const g = $('[data-drawer-grid]');
        if (g) g.innerHTML = resultsHtml(q, res, loading);
      };
      const appsP = window.hub.taskbar.searchApps(q).then((a) => { res.apps = a || []; paint(true); }).catch(() => {});
      const filesP = window.hub.taskbar.searchFiles(q).then((f) => { res.files = f || []; }).catch(() => {});
      await appsP;
      await filesP;
      paint(false);
    }, 90);
  }

  function drawerHtml() {
    return `<div class="tb-pop" role="dialog" aria-label="Windows-Apps">
      <section class="tb-drawer">
        <header class="drawer-head">
          <div class="drawer-title"><b>Desktop</b><span>Apps, Fenster & Widgets</span></div>
          <label class="drawer-search">${window.icon('search', 13)}<input type="text" placeholder="Apps & Dateien suchen" data-drawer-search autocomplete="off" spellcheck="false" /></label>
          <button class="drawer-close" data-act="drawer" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        <div class="drawer-grid" data-drawer-grid>${drawerGrid()}</div>
        <footer class="drawer-foot">
          <button class="drawer-action" data-act="home">${window.icon('home', 13)} Revulution Hub</button>
          <button class="drawer-action" data-act="desktop">${window.icon('grid', 13)} Desktop</button>
          <button class="drawer-action" data-act="control">${window.icon('control', 13)} Kontrollzentrum</button>
          <button class="drawer-action" data-act="settings">${window.icon('settings', 13)} Einstellungen</button>
          <button class="drawer-action danger" data-act="lock">${window.icon('shield', 13)} Sperren</button>
        </footer>
      </section>
    </div>`;
  }

  const fmtDur = (secs) => {
    const min = Math.round((Number(secs) || 0) / 60);
    if (!min) return '0 Min.';
    const h = Math.floor(min / 60);
    const m = min % 60;
    return h ? `${h} Std. ${m} Min.` : `${m} Min.`;
  };

  /* ---------------------------------------------------------------- WLAN-Test direkt in der Leiste */
  const spd = { running: false, phase: '', pct: 0, live: {}, shown: { down: 0, up: 0, ping: 0 }, result: null, raf: 0 };
  const SP_PH = { wlan: 'WLAN …', ping: 'PING', down: 'DOWNLOAD', up: 'UPLOAD', done: 'FERTIG' };
  const f1 = (v) => (v == null ? '–' : Number(v) >= 100 ? Math.round(v) : (Math.round(v * 10) / 10).toString().replace('.', ','));
  function speedHtml() {
    const r = spd.result;
    const v = spd.shown;
    const ring = spd.running ? Math.max(2, spd.pct) : r ? 100 : 0;
    return `<div class="tb-pop tb-speed" role="dialog" aria-label="WLAN-Test">
      <section class="tb-drawer tb-speed-card">
        <header class="drawer-head">
          <div class="drawer-title"><b>WLAN-Test</b><span>${spd.running ? 'Messung läuft' : r ? 'Letzte Messung' : 'Bereit'}</span></div>
          <button class="drawer-close" data-act="panel-close" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        <div class="tbs-hero">
          <div class="tbs-ring ${spd.running ? 'run' : ''}" style="--p:${ring}">
            <svg viewBox="0 0 120 120"><circle class="bg" cx="60" cy="60" r="52"/><circle class="fg" cx="60" cy="60" r="52" pathLength="100" style="stroke-dashoffset:${100 - ring}"/></svg>
            <div class="tbs-center"><b data-sp-big>${f1(spd.running ? v.down : r?.down)}</b><small>MBIT/S</small><em data-sp-phase>${spd.running ? SP_PH[spd.phase] || '…' : ''}</em></div>
          </div>
          <div class="tbs-vals">
            <div class="${spd.phase === 'down' ? 'on' : ''}"><span>DOWN</span><b data-sp="down">${f1(spd.running ? v.down : r?.down)}</b></div>
            <div class="${spd.phase === 'up' ? 'on' : ''}"><span>UP</span><b data-sp="up">${f1(spd.running ? v.up : r?.up)}</b></div>
            <div class="${spd.phase === 'ping' ? 'on' : ''}"><span>PING</span><b data-sp="ping">${f1(spd.running ? v.ping : r?.ping)}</b></div>
          </div>
        </div>
        <button class="tbs-run" data-act="speed-run" ${spd.running ? 'disabled' : ''}>${spd.running ? 'Misst …' : r ? 'Nochmal testen' : 'Test starten'}</button>
      </section>
    </div>`;
  }
  /** Werte weich hochzählen statt springen. */
  function speedTween() {
    cancelAnimationFrame(spd.raf);
    const step = () => {
      let moving = false;
      for (const k of ['down', 'up', 'ping']) {
        const target = Number(spd.live[k] ?? 0);
        const cur = spd.shown[k];
        const next = cur + (target - cur) * 0.12;
        spd.shown[k] = Math.abs(target - next) < 0.05 ? target : next;
        if (spd.shown[k] !== target) moving = true;
        const el = document.querySelector(`[data-sp="${k}"]`);
        if (el && spd.running) el.textContent = f1(spd.shown[k]);
      }
      const big = document.querySelector('[data-sp-big]');
      if (big && spd.running) big.textContent = f1(spd.shown.down || spd.shown.ping && 0);
      if (moving || spd.running) spd.raf = requestAnimationFrame(step);
    };
    spd.raf = requestAnimationFrame(step);
  }
  function speedPaint() {
    const card = document.querySelector('.tb-speed');
    if (!card) return;
    const ring = spd.running ? Math.max(2, spd.pct) : spd.result ? 100 : 0;
    card.querySelector('.tbs-ring').classList.toggle('run', spd.running);
    card.querySelector('.tbs-ring .fg').style.strokeDashoffset = String(100 - ring);
    const ph = card.querySelector('[data-sp-phase]');
    if (ph) ph.textContent = spd.running ? SP_PH[spd.phase] || '…' : '';
    card.querySelectorAll('.tbs-vals > div').forEach((d, i) => d.classList.toggle('on', spd.running && ['down', 'up', 'ping'][i] === spd.phase));
  }
  window.hub.onSpeed?.((p) => {
    if (!p) return;
    spd.phase = p.phase;
    spd.pct = Number(p.pct) || spd.pct;
    if (p.value != null && ['down', 'up', 'ping'].includes(p.phase)) spd.live[p.phase] = Number(p.value);
    speedPaint();
  });
  async function speedRun() {
    if (spd.running) return;
    spd.running = true;
    spd.live = {};
    spd.shown = { down: 0, up: 0, ping: 0 };
    spd.pct = 0;
    render.popKey = '';
    render();
    speedTween();
    try {
      spd.result = await window.hub.speed.run();
    } catch {
      spd.result = null;
    }
    spd.running = false;
    render.popKey = '';
    render();
  }

  function screenHtml() {
    const d = screenData;
    const apps = d?.apps?.slice(0, 5) || [];
    const max = Math.max(1, apps[0]?.secs || 1);
    return `<div class="tb-pop tb-screen" role="dialog" aria-label="Bildschirmzeit">
      <section class="tb-drawer tb-screen-card">
        <header class="drawer-head">
          <div class="drawer-title"><b>Bildschirmzeit</b><span>Heute am PC</span></div>
          <button class="drawer-close" data-act="panel-close" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        ${d ? `<div class="tb-sc-total"><b>${fmtDur(d.total)}</b><span>${d.pickups || 0} mal aktiv geworden</span></div>
          <div class="tb-sc-list">${apps.length ? apps.map((a) => `<div class="tb-sc-row"><span>${esc(a.name || a.exe)}</span><b>${fmtDur(a.secs)}</b><i><em style="width:${Math.max(4, Math.round((a.secs / max) * 100))}%"></em></i></div>`).join('') : '<p class="drawer-empty">Heute noch keine Zeit erfasst.</p>'}</div>` : '<p class="drawer-empty">Wird geladen …</p>'}
        <footer class="drawer-foot"><button class="drawer-action" data-act="sc-app">${window.icon('clock', 12)} App öffnen</button></footer>
      </section>
    </div>`;
  }

  async function loadScreenTime() {
    if (screenLoading) return;
    screenLoading = true;
    try {
      screenData = await window.hub.screentime.summary();
    } catch {
      screenData = null;
    } finally {
      screenLoading = false;
      lastKey = '';
      render();
    }
  }

  function render() {
    if (!state) return;
    const panel = state.panel || '';
    const drawer = panel === 'drawer';
    const screen = panel === 'screentime';
    const speed = panel === 'speed';
    const sound = panel === 'sound';
    const power = panel === 'power';
    document.body.classList.toggle('drawer-open', Boolean(panel));
    for (const k of ['drawer', 'screentime', 'speed', 'sound', 'power']) document.body.classList.toggle(`panel-${k}`, panel === k);
    document.documentElement.style.setProperty('--tbx-s', String(Math.max(0.7, Math.min(1.6, Number(state?.scale ?? 1)))));
    document.title = 'Revulution Leiste';
    // Leiste und Popup getrennt: Ein Klick (Menü auf/zu) baut die Leiste nicht neu auf –
    // sonst lief jedes Mal die Einblend-Animation und alles „blinkte“.
    const barKey = JSON.stringify({ windowsApps: state.windowsApps, badges: state.badges, dnd: state.dnd, topbarItems: state.topbarItems, crosshairOn: state.crosshairOn, opacity: state.opacity, scale: state.scale, autoHide: state.autoHide, trayOpen });
    const popKey = JSON.stringify({ panel, screenTotal: screenData?.total || 0, screenApps: screenData?.apps?.length || 0 });
    const tb = $('#tb');
    if (!tb.querySelector('.tbx-bar')) {
      const fresh = document.createElement('div');
      fresh.innerHTML = barHtml();
      tb.prepend(fresh.firstElementChild);
      lastKey = '';
      hillBind();
    }
    if (barKey !== lastKey) { updateBar(); lastKey = barKey; }
    tb.querySelector('.tbx-start')?.classList.toggle('is-open', Boolean(state.drawer));
    // Beim Schließen bleibt das Popup stehen und gleitet weich zurück ins Logo.
    if (panel && popKey !== render.popKey) {
      render.popKey = popKey;
      render.appsKey = '';
      tb.querySelector('.tb-pop')?.remove();
      if (!power) pw.confirm = '';
      tb.insertAdjacentHTML('beforeend', power ? powerHtml() : sound ? soundHtml() : speed ? speedHtml() : screen ? screenHtml() : drawerHtml());
      if (sound) soundLoad();
      if (power) powerLoad();
    }
    // Offene Apps ändern sich: nur das Raster tauschen, ohne das Menü neu aufzubauen.
    const appsKey = JSON.stringify(windowsApps().map((x) => x.id + x.kind));
    const grid = tb.querySelector('[data-drawer-grid]');
    if (grid && appsKey !== render.appsKey && !grid.classList.contains('is-search')) {
      if (render.appsKey) grid.classList.add('settled');
      grid.innerHTML = drawerGrid();
    }
    render.appsKey = appsKey;
    requestAnimationFrame(() => tb.classList.add('ready'));
    tickClock();
    startClock();
    if (drawer && !drawerWasOpen) {
      const input = $('#tb')?.querySelector('[data-drawer-search]');
      if (input && input.value) {
        input.value = '';
        runSearch('');
      }
      setTimeout(() => $('#tb')?.querySelector('[data-drawer-search]')?.focus(), 120);
    }
    if (!window.__tbFocusHook && window.hub.onFocusSearch) {
      // 2.47.2: Hauptprozess hat dem Fenster den Fokus gegeben → Suchfeld aktiv, Tippen geht sofort hinein
      window.__tbFocusHook = true;
      window.hub.onFocusSearch(() => { const i = $('#tb')?.querySelector('[data-drawer-search]'); if (i) { i.focus(); i.select?.(); } });
    }
    if (screen && !screenData) loadScreenTime();
    drawerWasOpen = drawer;
  }

  function locale() {
    return state?.lang === 'en' ? 'en-GB' : state?.lang === 'es' ? 'es-ES' : 'de-DE';
  }

  function tickClock() {
    const now = new Date();
    const time = now.toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' });
    const date = now.toLocaleDateString(locale(), { weekday: 'short', day: 'numeric', month: 'short' });
    document.querySelectorAll('[data-clock-time]').forEach((el) => { el.textContent = time; });
    document.querySelectorAll('[data-clock-date]').forEach((el) => { el.textContent = date; });
    const num = now.toLocaleDateString(locale(), { day: '2-digit', month: '2-digit', year: 'numeric' });
    document.querySelectorAll('[data-clock-num]').forEach((el) => { el.textContent = num; });
  }

  function startClock() {
    clearInterval(clockTimer);
    clockTimer = setInterval(tickClock, 15000);
  }

  function pulse(button) {
    if (!button) return;
    button.classList.remove('pressed');
    void button.offsetWidth;
    button.classList.add('pressed');
    setTimeout(() => button.classList.remove('pressed'), 200);
  }

  function closeDrawer() {
    if (state?.drawer) window.hub.taskbar?.drawer?.(false).catch(() => {});
  }

  document.addEventListener('input', (event) => {
    if (event.target.matches('[data-drawer-search]')) runSearch(event.target.value);
  });

  document.addEventListener('click', (event) => {
    const mb = event.target.closest('[data-media]');
    if (mb) {
      window.hub.cc?.media?.(mb.dataset.media)?.catch?.(() => {});
      if (media) { media.playing = !media.playing; const slot = document.querySelector('.tbx-media-slot'); if (slot) slot.innerHTML = mediaHtml(); }
      return;
    }
    const top = event.target.closest('[data-tb-top]');
    if (top) {
      pulse(top);
      const kind = top.dataset.tbTop;
      if (kind === 'crosshair') return window.hub.crosshair?.toggle?.().catch(() => {});
      if (kind === 'screentime') return window.hub.taskbar?.panel?.('screentime').catch(() => {});
      closeDrawer();
      if (kind === 'settings') return window.hub.openSettings?.().catch(() => {});
      return window.hub.taskbar?.panel?.('speed').catch(() => {});
    }
    const result = event.target.closest('[data-result]');
    if (result) {
      pulse(result);
      window.hub.taskbar?.openResult?.(result.dataset.result).catch(() => {});
      return;
    }
    const winApp = event.target.closest('[data-winapp]');
    if (winApp) {
      pulse(winApp);
      closeDrawer();
      window.hub.taskbar?.launch?.(winApp.dataset.winapp).catch(() => {});
      return;
    }
    const action = event.target.closest('[data-act]');
    if (!action) return;
    pulse(action);
    const act = action.dataset.act;
    if (act === 'drawer') return window.hub.taskbar?.drawer?.(!state?.drawer).catch(() => {});
    if (act === 'tray') { trayOpen = !trayOpen; lastKey = ''; return render(); }
    if (act === 'sound') return window.hub.taskbar?.panel?.('sound').catch(() => {});
    if (act === 'power') return window.hub.taskbar?.panel?.('power').catch(() => {});
    if (act === 'pw-off' || act === 'pw-restart') {
      if (pw.confirm !== act) { pw.confirm = act; clearTimeout(pw.t); pw.t = setTimeout(() => { pw.confirm = ''; powerRefresh(); }, 4000); return powerRefresh(); }
      pw.confirm = '';
      closeDrawer();
      return window.hub.taskbar?.power?.(act === 'pw-off' ? 'shutdown' : 'restart').catch(() => {});
    }
    if (act === 'pw-lock') { closeDrawer(); return window.hub.taskbar?.power?.('lock').catch(() => {}); }
    if (act === 'pw-cancel') return window.hub.taskbar?.power?.('cancel').then(() => { pw.at = 0; powerRefresh(); }).catch(() => {});
    if (act === 'pw-plan') {
      const v = document.querySelector('[data-pw-time]')?.value || '';
      const m = /^(\d{1,2}):(\d{2})$/.exec(v);
      if (!m) return;
      const d = new Date();
      d.setHours(Number(m[1]), Number(m[2]), 0, 0);
      if (d.getTime() <= Date.now() + 30000) d.setDate(d.getDate() + 1); // Uhrzeit schon vorbei → morgen
      return powerPlan(d.getTime());
    }
    if (act === 'snd-mute') { const v = snd.level; return window.hub.cc?.volume?.(snd.muted ? (v || 30) : 0).then(soundApply).catch(() => {}); }
    if (act === 'snd-net') { closeDrawer(); return window.hub.taskbar?.winkey?.('network').catch(() => {}); }
    if (act === 'snd-out') { closeDrawer(); return window.hub.taskbar?.winkey?.('sound').catch(() => {}); }
    if (act === 'player') { closeDrawer(); return window.hub.open('tool-player').catch(() => {}); }
    if (act === 'notify') { closeDrawer(); return window.hub.taskbar?.winkey?.('notifications').catch(() => window.hub.openControl?.().catch(() => {})); }
    if (act === 'show-desktop') return window.hub.taskbar?.winkey?.('desktop').catch(() => {});
    if (act === 'panel-close') return window.hub.taskbar?.drawer?.(false).catch(() => {});
    if (act === 'speed-run') return speedRun();
    if (act === 'sc-app') { closeDrawer(); return window.hub.open('tool-screentime').catch(() => {}); }
    if (act === 'home') { closeDrawer(); return window.hub.open('home').catch(() => {}); }
    if (act === 'desktop') { closeDrawer(); return window.hub.open('tool-desktop').catch(() => {}); }
    if (act === 'control') { closeDrawer(); return window.hub.openControl?.().catch(() => {}); }
    if (act === 'settings') { closeDrawer(); return window.hub.openSettings?.().catch(() => {}); }
    if (act === 'quit') {
      closeDrawer();
      if (window.confirm('Revulution Hub und alle laufenden Aufgaben beenden?')) window.hub.quit?.().catch(() => {});
      return;
    }
    if (act === 'agenda') { closeDrawer(); return window.hub.open('agenda').catch(() => {}); }
    if (act === 'lock') { closeDrawer(); return window.hub.cc?.lock?.().catch(() => {}); }
  });

  document.addEventListener('contextmenu', (event) => {
    const app = event.target.closest?.('[data-winapp]');
    if (!app) return;
    event.preventDefault();
    window.hub.taskbar?.context?.(app.dataset.winapp).catch(() => {});
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && event.target.matches?.('[data-drawer-search]') && firstResult) {
      const [kind, ...rest] = firstResult.split(':');
      const id = rest.join(':');
      if (kind === 'win') {
        closeDrawer();
        window.hub.taskbar?.launch?.(id).catch(() => {});
      } else window.hub.taskbar?.openResult?.(id).catch(() => {});
      return;
    }
    if (event.key === 'Escape') closeDrawer();
  });

  /* Die Leiste ist oben volle Breite, das Popup nur eine kleine Karte. Der
     transparente Rest des Fensters darf keine Klicks auf den Desktop schlucken. */
  document.addEventListener('mousemove', (event) => {
    const hit = document.elementFromPoint(event.clientX, event.clientY);
    setInteractive(Boolean(hit?.closest('.tb-pill, .tbx-shell, body.drawer-open .tb-pop')));
  });
  document.addEventListener('mouseleave', () => setInteractive(false));

  async function refreshTone() {
    try {
      const tone = await window.hub.desktopTone?.();
      $('#tb')?.classList.toggle('on-light', tone === 'light');
    } catch {
      /* dunkel bleiben */
    }
  }
  refreshTone();
  setInterval(refreshTone, 2000);

  window.hub.onTaskbar?.((payload) => {
    state = payload || null;
    render();
  });
  window.hub.taskbarReady?.().catch(() => {});
})();
