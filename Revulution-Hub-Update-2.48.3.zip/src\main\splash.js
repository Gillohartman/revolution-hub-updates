'use strict';

/*
 * 2.47.7 Ladescreen: Direkt nach einer Installation prüft Windows (Smart App Control) jede Programmdatei
 * des Hubs – dann lädt minutenlang keine Hub-Seite. Damit man nicht vor einer grauen Fläche sitzt,
 * zeigt ein kleines eigenes Fenster (über Windows' PowerShell, also ohne Chromium) „Revulution Hub startet …“.
 * Es erscheint nur, wenn der Start länger als 1,5 s dauert, und schließt sich, sobald der Hub fertig ist.
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const SCRIPT = String.raw`
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$W = 440; $H = 250
$f = New-Object System.Windows.Forms.Form
$f.FormBorderStyle = 'None'; $f.StartPosition = 'Manual'; $f.ShowInTaskbar = $true; $f.TopMost = $true
$f.Size = New-Object System.Drawing.Size($W, $H); $f.BackColor = [System.Drawing.Color]::FromArgb(255, 18, 18, 22)
$f.Text = 'Revulution Hub'
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$f.Location = New-Object System.Drawing.Point(([int]($wa.X + ($wa.Width - $W) / 2)), ([int]($wa.Y + ($wa.Height - $H) / 2)))
$f.Add_Shown({ [Console]::Out.WriteLine('shown ' + $f.Location) })
try { $f.Icon = New-Object System.Drawing.Icon($env:REV_SPLASH_ICON) } catch {}
# runde Ecken
$gp = New-Object System.Drawing.Drawing2D.GraphicsPath; $r = 28
$gp.AddArc(0, 0, $r, $r, 180, 90); $gp.AddArc(($W - $r), 0, $r, $r, 270, 90); $gp.AddArc(($W - $r), ($H - $r), $r, $r, 0, 90); $gp.AddArc(0, ($H - $r), $r, $r, 90, 90); $gp.CloseFigure()
$f.Region = New-Object System.Drawing.Region($gp)
$logo = $null; try { $logo = [System.Drawing.Image]::FromFile($env:REV_SPLASH_LOGO) } catch {}
$script:t = 0
$f.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'NonPublic,Instance').SetValue($f, $true, $null)
$f.Add_Paint({
  param($s, $e)
  $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'; $g.TextRenderingHint = 'ClearTypeGridFit'
  if ($logo) { $g.DrawImage($logo, [int](($W - 64) / 2), 34, 64, 64) }
  $title = New-Object System.Drawing.Font('Segoe UI Semibold', 17)
  $sub = New-Object System.Drawing.Font('Segoe UI', 9.5)
  $fmt = New-Object System.Drawing.StringFormat; $fmt.Alignment = 'Center'
  $g.DrawString('Revulution Hub', $title, [System.Drawing.Brushes]::White, [System.Drawing.RectangleF]::new(0, 108, $W, 34), $fmt)
  $grey = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(150, 255, 255, 255))
  $g.DrawString($env:REV_SPLASH_TEXT, $sub, $grey, [System.Drawing.RectangleF]::new(30, 146, ($W - 60), 40), $fmt)
  # Ladebalken: weicher Lichtstreifen, der durchläuft
  $bx = 70; $by = 204; $bw = ($W - 140); $bh = 6
  $track = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(40, 255, 255, 255))
  $g.FillRectangle($track, $bx, $by, $bw, $bh)
  $pos = ($script:t % 120) / 120.0; $seg = $bw * 0.32
  $x = $bx - $seg + ($bw + $seg) * $pos
  $x1 = [Math]::Max($bx, $x); $x2 = [Math]::Min($bx + $bw, $x + $seg)
  if ($x2 -gt $x1) {
    $rect = [System.Drawing.RectangleF]::new($x1, $by, ($x2 - $x1), $bh)
    $br = [System.Drawing.Drawing2D.LinearGradientBrush]::new([System.Drawing.RectangleF]::new(($x - 1), $by, ($seg + 2), $bh), [System.Drawing.Color]::FromArgb(0, 120, 170, 255), [System.Drawing.Color]::FromArgb(255, 150, 120, 255), [single]0)
    $blend = New-Object System.Drawing.Drawing2D.Blend; $blend.Factors = [single[]](0, 1, 0); $blend.Positions = [single[]](0, 0.5, 1); $br.Blend = $blend
    $g.FillRectangle($br, $rect)
  }
})
$timer = New-Object System.Windows.Forms.Timer; $timer.Interval = 16
$timer.Add_Tick({ $script:t++; $f.Invalidate() })
$timer.Start()
# beendet sich selbst, wenn der Hub nicht mehr läuft
$hub = [int]$env:REV_SPLASH_PARENT
$watch = New-Object System.Windows.Forms.Timer; $watch.Interval = 1000
$watch.Add_Tick({ if (-not (Get-Process -Id $hub -ErrorAction SilentlyContinue)) { $f.Close() } })
$watch.Start()
[System.Windows.Forms.Application]::Run($f)
`;

let proc = null;
let timer = null;

/** Nach delay ms anzeigen (falls bis dahin nicht abgesagt). */
function showSplashSoon(delay = 1500, { text } = {}) {
  if (process.platform !== 'win32' || proc || timer) return;
  timer = setTimeout(() => {
    timer = null;
    const ui = path.join(__dirname, '..', 'ui', 'assets');
    const icon = path.join(process.resourcesPath || '', 'icon.ico');
    try {
      proc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-STA', '-EncodedCommand', Buffer.from(SCRIPT, 'utf16le').toString('base64')], {
        windowsHide: true,
        stdio: 'ignore',
        env: {
          ...process.env,
          REV_SPLASH_LOGO: path.join(ui, fs.existsSync(path.join(ui, 'logo-metal.png')) ? 'logo-metal.png' : 'logo.png'),
          REV_SPLASH_ICON: fs.existsSync(icon) ? icon : '',
          REV_SPLASH_TEXT: text || 'Wird gestartet … Nach einem Update prüft Windows den Hub einmal – das kann kurz dauern.',
          REV_SPLASH_PARENT: String(process.pid),
        },
      });
      proc.on('exit', () => { proc = null; });
    } catch {
      proc = null;
    }
  }, delay);
}

function hideSplash() {
  if (timer) { clearTimeout(timer); timer = null; }
  const p = proc;
  proc = null;
  try { p?.kill(); } catch { /* schon zu */ }
}

module.exports = { showSplashSoon, hideSplash };
