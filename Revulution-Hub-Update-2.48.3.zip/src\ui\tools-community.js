'use strict';

/* Hintergründe und Meldungen für alle. Die Verwaltung liegt in der separaten Admin-App. */
(() => {
  const T = window.HubTools;
  if (!T) return;
  const ctx = () => T.ctx();
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hm = (at) => new Date(at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
  const WALL_NAMES = { nebula: 'Nebula', aurora: 'Aurora', galaxy: 'Galaxy', synthwave: 'Synthwave', liquid: 'Liquid', silk: 'Silk', waves: 'Waves', ocean: 'Ocean', clouds: 'Clouds', mountains: 'Mountains', fireflies: 'Fireflies', bokeh: 'Bokeh', lava: 'Lava', warp: 'Warp' };
  const st = { data: null, loading: false, busy: false, error: '', type: 'bug', app: 'Revulution Hub', cloud: null, cloudErr: '', acct: null, sub: null };

  // Anmeldestatus live halten – beim Start ist die Anmeldung oft noch nicht wiederhergestellt
  window.hub.onAccount?.((a) => {
    st.acct = a;
    if (active()) ctx().render();
  });
  /** Cloud: freigegebene Hintergründe + Anmeldestatus fürs Einreichen. */
  async function loadCloud(force = false) {
    if (st.cloud && !force) return;
    st.cloud = st.cloud || [];
    try {
      [st.cloud, st.acct] = await Promise.all([window.hub.community.cloud(force), window.hub.account.state().catch(() => null)]);
      st.cloudErr = '';
    } catch (e) {
      st.cloudErr = /PERMISSION|403/i.test(String(e?.message)) ? 'Die Cloud-Hintergründe sind noch nicht freigeschaltet.' : 'Cloud gerade nicht erreichbar.';
    }
    if (active()) ctx().render();
  }

  /* 2.47 Premium-Bibliothek aus der Cloud (Cloudflare R2): nur Vorschaubilder laden, Original erst beim Setzen */
  const LIB = { items: [], configured: false, loaded: false, loading: false, err: '', paid: false, owned: new Set() };
  async function loadLib(force = false) {
    if (LIB.loading || (LIB.loaded && !force) || !window.hub.library) return;
    LIB.loading = true;
    try {
      const r = await window.hub.library.list(force);
      Object.assign(LIB, { items: r.items || [], configured: Boolean(r.configured), err: '', paid: Boolean(r.paid) });
      if (LIB.paid) LIB.owned = new Set(await window.hub.library.owned().catch(() => []));
    } catch (e) {
      LIB.err = String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
    LIB.loaded = true;
    LIB.loading = false;
    if (active()) ctx().render();
  }
  // Fortschritt beim Herunterladen eines großen Originals
  let libBar = null;
  window.hub.library?.onProgress?.((p) => {
    if (!libBar) {
      libBar = document.createElement('div');
      libBar.className = 'wp-libbar';
      libBar.innerHTML = '<span>Lade Original …</span><i><b></b></i>';
      document.body.appendChild(libBar);
    }
    libBar.querySelector('b').style.width = `${Math.round(p * 100)}%`;
    libBar.querySelector('span').textContent = `Lade Original … ${Math.round(p * 100)} %`;
    if (p >= 1) {
      const el = libBar;
      libBar = null;
      setTimeout(() => el.remove(), 600);
    }
  });

  /** Bild verkleinern (max. 1920 px, JPEG) – passt so in ein Cloud-Dokument. */
  async function shrink(file) {
    const bmp = await createImageBitmap(file);
    let w = bmp.width;
    let h = bmp.height;
    const scale = Math.min(1, 1920 / Math.max(w, h));
    w = Math.round(w * scale);
    h = Math.round(h * scale);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d').drawImage(bmp, 0, 0, w, h);
    for (const q of [0.86, 0.78, 0.7, 0.6, 0.5]) {
      const url = c.toDataURL('image/jpeg', q);
      if (url.length < 900 * 1024) return { url, w, h };
    }
    throw new Error('Das Bild ist zu detailreich – bitte ein kleineres wählen.');
  }

  function submitCard() {
    const signed = st.acct?.signedIn;
    const s = st.sub;
    return `<div class="tool-card bg-submit"><div class="list-row"><div class="grow"><strong>Hintergrund einreichen</strong><small>Dein Bild geht an den Admin. Nach der Freigabe sehen es alle im Hub.</small></div></div>
      ${
        signed
          ? `<div class="bg-sub-row"><div class="bg-sub-prev">${s?.url ? `<img src="${s.url}" alt="" />` : '<span>16:9 · bis 1920 px</span>'}</div>
             <div class="bg-sub-side"><label class="btn small"><input type="file" accept="image/*" data-bg-sub-file hidden />Bild wählen</label>
               <input class="input" data-bg-sub-name maxlength="60" placeholder="Name, z. B. Neon City" value="${esc(s?.name || '')}" />
               <button class="btn primary small" data-bg-sub-send ${s?.url && !st.busy ? '' : 'disabled'}>${st.busy ? 'Wird gesendet …' : 'Einreichen'}</button>
               ${s?.w ? `<small class="muted">${s.w} × ${s.h} px · ${Math.round(s.url.length / 1365)} KB</small>` : ''}</div></div>`
          : '<p class="muted">Zum Einreichen melde dich in den Einstellungen mit deinem Revulution-Konto an.</p>'
      }</div>`;
  }

  /* Community-Galerie ganz oben: großes Titelbild + Kacheln, die beim Drüberfahren aufleben */
  function galleryHtml() {
    loadCloud();
    load();
    const cloud = (st.cloud || []).map((b) => ({ id: b.id, name: b.name, by: b.by || 'Community', img: b.img, kind: 'cloud' }));
    const local = (st.data?.backgrounds || []).filter((b) => b.data).map((b) => ({ id: b.id, name: b.name, by: `${b.downloads || 0} Downloads`, img: b.data, kind: 'local' }));
    const all = [...cloud, ...local];
    const act = (b) => (b.kind === 'cloud' ? `data-bg-cloud-desktop="${esc(b.id)}"` : `data-bg-desktop="${esc(b.id)}"`);
    if (!all.length) return `<section class="cg"><div class="cg-head"><div><span class="cg-eyebrow">● COMMUNITY</span><h2>Hintergründe aus der Community</h2></div><button class="btn small ghost" data-bg-cloud-refresh>Aktualisieren</button></div><div class="cg-empty">${st.cloudErr ? esc(st.cloudErr) : 'Noch nichts freigegeben – reich unten das erste Bild ein!'}</div></section>`;
    const [hero, ...rest] = all;
    return `<section class="cg">
      <div class="cg-head"><div><span class="cg-eyebrow">● COMMUNITY · ${all.length}</span><h2>Hintergründe aus der Community</h2></div><button class="btn small ghost" data-bg-cloud-refresh>Aktualisieren</button></div>
      <div class="cg-hero" style="background-image:url('${hero.img}')"><div class="cg-hero-txt"><small>NEU</small><b>${esc(hero.name)}</b><span>von ${esc(hero.by)}</span></div><button class="btn primary" ${act(hero)}>Als Desktop setzen</button></div>
      ${rest.length ? `<div class="cg-grid">${rest.map((b, i) => `<button class="cg-tile" style="--d:${Math.min(i, 16) * 35}ms" ${act(b)} title="${esc(b.name)} als Desktop setzen"><img src="${b.img}" alt="" loading="lazy" /><span class="cg-tile-txt"><b>${esc(b.name)}</b><small>${esc(b.by)}</small></span><span class="cg-tile-go">Als Desktop</span></button>`).join('')}</div>` : ''}
    </section>`;
  }

  function cloudCard() {
    loadCloud();
    const list = st.cloud || [];
    return `<div class="tool-card"><div class="list-row"><div class="grow"><strong>Aus der Community</strong><small>${st.cloudErr ? esc(st.cloudErr) : `${list.length} freigegebene${list.length === 1 ? 'r' : ''} Hintergr${list.length === 1 ? 'und' : 'ünde'}`}</small></div><button class="btn small ghost" data-bg-cloud-refresh>Aktualisieren</button></div>
      <div class="bg-grid">${list.length ? list.map((b) => `<div class="bg-card"><img src="${b.img}" alt="${esc(b.name)}" loading="lazy" /><div class="bg-meta"><strong>${esc(b.name)}</strong><small>von ${esc(b.by || 'Community')}</small></div><div class="bg-actions"><button class="btn small ghost" data-bg-cloud-desktop="${esc(b.id)}">Als Desktop</button></div></div>`).join('') : '<div class="bg-empty big">Noch nichts freigegeben – reich das erste Bild ein!</div>'}</div></div>`;
  }

  async function load(force = false) {
    if (st.loading || (st.data && !force)) return;
    st.loading = true;
    try {
      st.data = await window.hub.community.status();
      st.error = '';
    } catch (e) {
      st.error = e?.message || 'Datenbank nicht erreichbar.';
    } finally {
      st.loading = false;
      if (active()) ctx().render();
    }
  }

  const active = () => Boolean(document.querySelector('[data-tool-page="tool-backgrounds"]'));

  function bgCard(b) {
    return `<div class="bg-card">${b.data ? `<img src="${b.data}" alt="${esc(b.name)}" loading="lazy" />` : '<div class="bg-empty">Kein Vorschaubild</div>'}<div class="bg-meta"><strong>${esc(b.name)}</strong><small>${b.downloads || 0} Downloads · ${hm(b.at)}</small></div><div class="bg-actions"><button class="btn small ghost" data-bg-desktop="${esc(b.id)}">Als Desktop</button><button class="btn small ghost" data-bg-download="${esc(b.id)}">Herunterladen</button></div></div>`;
  }

  /* ================================================================== 2.34 Wallpaper-App
     Aufbau wie eine moderne Wallpaper-App: Glas-Navigation oben, großes Live-Titelbild mit
     Karussell, Reihen zum Durchscrollen, Detailansicht und schwebende Player-Leiste. */
  const WALL_INFO = {
    nebula: ['Space', 'Leuchtende Gaswolken treiben langsam durch einen tiefvioletten Kosmos.'],
    aurora: ['Nature', 'Grüne und violette Polarlichter wehen wie Vorhänge über den Nachthimmel.'],
    galaxy: ['Space', 'Eine Spiralgalaxie dreht sich ruhig, Sterne glitzern im Vordergrund.'],
    liquid: ['Abstract', 'Flüssige Farben fließen ineinander wie Tinte in Wasser.'],
    silk: ['Abstract', 'Weiche Seidenbahnen wogen in sanften Wellen über den Bildschirm.'],
    waves: ['Abstract', 'Geschichtete Farbwellen rollen diagonal wie Dünen durchs Bild.'],
    ocean: ['Nature', 'Ruhige Meereswellen unter einem weiten Himmel.'],
    clouds: ['Nature', 'Wolken ziehen im Zeitraffer über einen klaren Himmel.'],
    mountains: ['Nature', 'Bergketten im Abendlicht, Nebel liegt in den Tälern.'],
    fireflies: ['Nature', 'Glühwürmchen tanzen in einer warmen Sommernacht.'],
    bokeh: ['Abstract', 'Weiche Lichtkreise schweben unscharf durchs Bild.'],
    warp: ['Space', 'Sterne ziehen in Lichtstreifen vorbei – Sprung durch den Hyperraum.'],
  };
  const ui = { tab: 'home', hero: 0, detail: null, q: '', heroT: 0, cat: '' };
  // Echte Likes aus der Datenbank (wp_likes): Zahl = wie viele Nutzer es geliked haben
  const LK = { counts: {}, mine: [], loaded: false, loading: false, error: '' };
  async function loadLikes(force = false) {
    if (LK.loading || (LK.loaded && !force)) return;
    LK.loading = true;
    try {
      const r = await window.hub.wpLikes(force);
      Object.assign(LK, { counts: r.counts || {}, mine: r.mine || [], error: r.error || '' });
    } catch {
      LK.error = 'offline';
    }
    LK.loaded = true;
    LK.loading = false;
    if (active()) ctx().render();
  }
  window.hub.onAccount?.(() => loadLikes(true));
  const likes = () => new Set(LK.mine);
  const likeCount = (k) => Number(LK.counts[k] || 0);
  async function setLike(key) {
    // sofort anzeigen, dann mit der Datenbank abgleichen
    const had = LK.mine.includes(key);
    LK.mine = had ? LK.mine.filter((x) => x !== key) : [...LK.mine, key];
    LK.counts[key] = Math.max(0, likeCount(key) + (had ? -1 : 1));
    ctx().render();
    try {
      const r = await window.hub.wpLike(key);
      Object.assign(LK, { counts: r.counts || {}, mine: r.mine || [] });
    } catch (e) {
      LK.mine = had ? [...LK.mine, key] : LK.mine.filter((x) => x !== key);
      LK.counts[key] = Math.max(0, likeCount(key) + (had ? 1 : -1));
      ctx().toast(String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
    }
    if (active()) ctx().render();
  }
  function allItems() {
    const hubState = ctx().state();
    const dir = hubState?.wallpaperDir;
    const built = (hubState?.wallpapers || []).map((id) => ({
      key: `b:${id}`, id, kind: 'builtin', name: WALL_NAMES[id] || id, cat: WALL_INFO[id]?.[0] || 'Live', desc: WALL_INFO[id]?.[1] || '',
      img: fileUrl(`${dir}/thumbs/${id}.jpg`), video: fileUrl(`${dir}/live-${id}.mp4`), by: 'Revulution', res: '1920×1080', live: true,
    }));
    const cloud = (st.cloud || []).map((x) => ({ key: `c:${x.id}`, id: x.id, kind: 'cloud', name: x.name, cat: 'Community', desc: `Ein Hintergrund aus der Community, eingereicht von ${x.by || 'jemandem'}.`, img: x.img, by: x.by || 'Community', res: 'bis 1920 px' }));
    const local = (st.data?.backgrounds || []).filter((x) => x.data).map((x) => ({ key: `l:${x.id}`, id: x.id, kind: 'local', name: x.name, cat: 'Bibliothek', desc: `${x.downloads || 0} Downloads.`, img: x.data, by: 'Revulution', res: 'HD' }));
    const premium = LIB.items.map((x) => ({ key: `p:${x.id}`, id: x.id, kind: 'premium', name: x.name, cat: x.cat, desc: x.video ? 'Live-Hintergrund aus der Revulution-Bibliothek – kostenlos für alle.' : 'Hintergrund aus der Revulution-Bibliothek – kostenlos für alle.', img: x.thumb, video: x.video ? x.src : '', price: x.price || 0, locked: (x.price || 0) > 0 && !LIB.owned.has(x.id), by: x.author || 'Unbekannt', res: x.w && x.h ? `${x.w}×${x.h}` : 'HD', live: x.video, at: x.at }));
    return [...built, ...premium, ...cloud, ...local];
  }
  const actAttr = (it) => (it.kind === 'premium' && it.locked ? `data-wp-buy="${esc(it.id)}"` : it.kind === 'premium' ? `data-bg-lib-desktop="${esc(it.id)}"` : it.kind === 'builtin' ? `data-bg-builtin-desktop="${esc(it.id)}"` : it.kind === 'cloud' ? `data-bg-cloud-desktop="${esc(it.id)}"` : `data-bg-desktop="${esc(it.id)}"`);
  const heart = (on) => `<svg viewBox="0 0 24 24" class="wp-heart ${on ? 'on' : ''}"><path d="M12 20s-7-4.4-9.2-9C1.4 8 3.3 4.5 6.6 4.5c2 0 3.4 1.2 5.4 3.2 2-2 3.4-3.2 5.4-3.2 3.3 0 5.2 3.5 3.8 6.5C19 15.6 12 20 12 20Z"/></svg>`;

  function card(it, i = 0) {
    const liked = likes().has(it.key);
    const premium = it.kind !== 'builtin';
    return `<button class="wp-card2 ${premium ? 'prem' : ''}" style="--d:${Math.min(i, 10) * 45}ms" data-wp-open="${esc(it.key)}"${it.video ? ` data-wp-hv="${esc(it.video)}"` : ''}>
      <img src="${it.img}" alt="" loading="lazy" />
      <span class="wp-c-top">${it.live ? '<em>LIVE</em>' : ''}${it.locked ? `<em class="wp-price">${it.price} P</em>` : ''}</span>
      <span class="wp-c-bot"><span class="wp-c-txt"><b>${esc(it.name)}</b><small>${esc(it.cat)}</small></span><span class="wp-like" data-wp-like="${esc(it.key)}">${heart(liked)}${likeCount(it.key).toLocaleString('de-CH')}</span></span>
    </button>`;
  }
  /* 2.47.1: Überschrift anklickbar → alle Hintergründe dieser Reihe als Raster */
  function row(title, list, cat = '', total = list.length) {
    if (!list.length) return '';
    return `<section class="wp-row"><h3 ${cat ? `data-wp-cat="${esc(cat)}" title="Alle anzeigen"` : ''}>${esc(title)} ${cat ? `<small>Alle ${total}</small>` : ''} <i>›</i></h3><div class="wp-scroll">${list.map(card).join('')}</div></section>`;
  }
  /** Liste zu einer Reihe: 'new' | 'popular' | 'liked' | 'cat:<Name>' */
  function catList(key, items) {
    const up = items.filter((x) => x.kind !== 'builtin');
    if (key === 'new') return [...up].sort((x, y) => (y.at || 0) - (x.at || 0));
    // 2.47.2 Top Likes: die meistgelikten zuerst (nur mit Likes); solange noch keiner geliked ist, alle nach Beliebtheit
    if (key === 'popular') return up.filter((x) => likeCount(x.key) > 0).sort((x, y) => likeCount(y.key) - likeCount(x.key) || (y.at || 0) - (x.at || 0));
    if (key === 'liked') return items.filter((x) => likes().has(x.key));
    if (key.startsWith('cat:')) return items.filter((x) => x.cat === key.slice(4));
    return [];
  }
  const catTitle = (key) => (key === 'new' ? 'Neu' : key === 'popular' ? 'Top Likes' : key === 'liked' ? 'Deine Likes' : key.slice(4));
  function hero(items) {
    const feat = items.slice(0, 8);
    if (!feat.length) return '';
    const it = feat[ui.hero % feat.length];
    const liked = likes().has(it.key);
    return `<section class="wp-hero">
      ${it.video ? `<video class="wp-hero-media" src="${it.video}" autoplay muted loop playsinline poster="${it.img}"></video>` : `<div class="wp-hero-media" style="background-image:url('${it.img}')"></div>`}
      <div class="wp-hero-shade"></div>
      <div class="wp-hero-txt" key="${esc(it.key)}">
        <h1>${esc(it.name)}</h1>
        <div class="wp-hero-meta"><span>${esc(it.cat)}</span><span>${esc(it.res)}</span>${it.live ? '<span class="wp-badge">LIVE</span>' : ''}<span class="wp-badge">4K-Schärfe</span></div>
        <p>${esc(it.desc)}</p>
        <div class="wp-hero-btns"><button class="wp-glass-btn red" ${actAttr(it)}>▶ Als Hintergrund</button><button class="wp-glass-btn" data-wp-like="${esc(it.key)}">${heart(liked)} ${likeCount(it.key).toLocaleString('de-CH')}</button><button class="wp-glass-btn" data-wp-open="${esc(it.key)}">Details</button></div>
      </div>
      <button class="wp-arrow l" data-wp-hero="-1">‹</button><button class="wp-arrow r" data-wp-hero="1">›</button>
      <div class="wp-dots">${feat.map((_, i) => `<i class="${i === ui.hero % feat.length ? 'on' : ''}" data-wp-dot="${i}"></i>`).join('')}</div>
    </section>`;
  }
  function detail(it) {
    const liked = likes().has(it.key);
    return `<section class="wp-detail">
      ${it.video ? `<video class="wp-hero-media" src="${it.video}" autoplay muted loop playsinline poster="${it.img}"></video>` : `<div class="wp-hero-media" style="background-image:url('${it.img}')"></div>`}
      <div class="wp-hero-shade full"></div>
      <div class="wp-detail-txt">
        <h1>${esc(it.name)}</h1>
        <div class="wp-chips"><span>Autor: ${esc(it.by)}</span><span>Auflösung: ${esc(it.res)}</span><span>Kategorie: ${esc(it.cat)}</span><span>Likes: ${likeCount(it.key)}</span></div>
        <p>${esc(it.desc)}</p>
        <div class="wp-detail-btns"><span class="wp-line"></span><button class="wp-round" data-wp-like="${esc(it.key)}">${heart(liked)}</button><button class="wp-glass-btn big" ${actAttr(it)}>${it.locked ? `Kaufen · ${it.price} Punkte` : '▶ Als Desktop setzen'}</button><button class="wp-glass-btn big" data-wp-report="${esc(it.key)}" title="Problem mit diesem Hintergrund melden">⚑ Melden</button>${it.kind === 'local' ? `<button class="wp-round" data-bg-download="${esc(it.id)}">↓</button>` : '<span class="wp-round ghost"></span>'}<span class="wp-line"></span></div>
      </div>
    </section>`;
  }
  /** 2.47 Player-Leiste = dein echter Desktop-Hintergrund: Live an/aus, Like, vorheriger/nächster. */
  /** 2.47.2 Automatischer Wechsel: aus / stündlich / täglich (lädt vorher, blendet weich über) */
  const autoSel = () => { const m = ctx().state()?.settings?.wpAuto || 'off'; return `<select class="wp-auto" data-wp-auto title="Automatisch wechseln">${[['off', 'Wechsel: aus'], ['hour', 'Jede Stunde'], ['day', 'Jeden Tag']].map(([v, n]) => `<option value="${v}" ${m === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`; };
  function player(items) {
    const now = ctx().state()?.settings?.desktopNow;
    const it = now?.key ? { ...(items.find((x) => x.key === now.key) || {}), ...now } : null;
    if (!it) return `<div class="wp-player"><span class="wp-pl-txt"><b>Noch kein Hintergrund gesetzt</b><small><i></i>Wähle einen aus der Bibliothek</small></span><button data-wp-step="random" title="Zufälliger Hintergrund">⤮</button>${autoSel()}</div>`;
    const playing = Boolean(it.live && !it.paused);
    const canPlay = Boolean(it.file);
    return `<div class="wp-player"><span class="wp-pl-art" style="background-image:url('${it.img}')"></span><span class="wp-pl-txt"><b>${esc(it.name)}</b><small><i class="${playing ? 'live' : ''}"></i>${playing ? 'Live auf deinem Desktop' : canPlay ? 'Pausiert' : 'Dein Desktop'}</small></span>
      <button data-wp-step="random" title="Zufälliger Hintergrund">⤮</button><button data-wp-like="${esc(it.key)}" title="Gefällt mir">${heart(likes().has(it.key))}</button><button data-wp-step="-1" title="Vorheriger Hintergrund">⏮</button><button class="wp-pl-main" data-wp-play="${playing ? '0' : '1'}" ${canPlay ? '' : 'disabled'} title="${playing ? 'Live-Video anhalten' : 'Live-Video abspielen'}">${playing ? '❚❚' : '▶'}</button><button data-wp-step="1" title="Nächster Hintergrund">⏭</button>${autoSel()}<span class="wp-pl-disc ${playing ? 'spin' : ''}" style="background-image:url('${it.img}')"></span></div>`;
  }

  function html() {
    load();
    loadCloud();
    loadLikes();
    loadLib();
    const items = allItems();
    const q = ui.q.trim().toLowerCase();
    const it = ui.detail && items.find((x) => x.key === ui.detail);
    if (!ui.detail && ui.cat && q) ui.cat = '';
    const liked = items.filter((x) => likes().has(x.key));
    const nav = `<nav class="wp-nav">${it || ui.cat ? `<button class="wp-navback" data-wp-back title="Zurück"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg></button>` : ''}<label class="wp-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg><input data-wp-q placeholder="Suchen" value="${esc(ui.q)}" /></label>
      <div class="wp-tabs">${[['home', 'Bibliothek'], ['live', 'Revulution Live'], ['explore', 'Entdecken'], ['mine', 'Meine'], ['community', 'Community']].map(([k, n]) => `<button class="${ui.tab === k && !it ? 'on' : ''}" data-wp-tab="${k}">${n}</button>`).join('')}</div>
      <span class="grow"></span><button class="wp-glass-btn wp-rand" data-wp-step="random" title="Zufälligen Live-Hintergrund setzen">⤮ Zufällig</button><button class="wp-publish" data-wp-tab="publish">⇪ Hintergrund einreichen</button></nav>`;
    let body;
    if (it) body = detail(it);
    else if (q) body = `<div class="wp-grid">${items.filter((x) => `${x.name} ${x.cat}`.toLowerCase().includes(q)).map(card).join('') || '<p class="muted">Nichts gefunden.</p>'}</div>`;
    else if (ui.cat) { const l = catList(ui.cat, items); body = `<div class="wp-cat-head"><h2>${esc(catTitle(ui.cat))}</h2><span>${l.length} Hintergründe</span></div><div class="wp-grid">${l.map(card).join('') || '<div class="wp-empty">Noch nichts hier.</div>'}</div>`; }
    else if (ui.tab === 'explore') body = row('Top Likes', catList('popular', items).slice(0, 30), 'popular', catList('popular', items).length) + [...new Set(['Space', 'Nature', 'Abstract', ...LIB.items.map((x) => x.cat), 'Community', 'Bibliothek'])].map((c) => { const l = catList(`cat:${c}`, items); return row(c, l.slice(0, 30), `cat:${c}`, l.length); }).join('');
    else if (ui.tab === 'live') body = `<div class="wp-grid">${items.filter((x) => x.kind === 'builtin').map(card).join('')}</div>`;
    else if (ui.tab === 'mine') body = liked.length ? `<div class="wp-grid">${liked.map(card).join('')}</div>` : '<div class="wp-empty">Noch keine Likes – tippe auf ♥ bei einem Hintergrund.</div>';
    else if (ui.tab === 'community') body = `<div class="wp-grid">${items.filter((x) => x.kind !== 'builtin').map(card).join('') || `<div class="wp-empty">${st.cloudErr ? esc(st.cloudErr) : 'Noch nichts freigegeben – reich das erste Bild ein!'}</div>`}</div>`;
    else if (ui.tab === 'publish') body = `<div class="wp-pub">${submitCard()}</div>`;
    else {
      // 2.47: Startseite = Bibliothek (kostenlos für alle). Die mitgelieferten gibt es unter „Revulution Live“.
      const up = items.filter((x) => x.kind !== 'builtin');
      body = up.length
        ? `${hero(up)}${row('Top Likes', catList('popular', items).slice(0, 30), 'popular', catList('popular', items).length)}${row('Neu', catList('new', items).slice(0, 30), 'new', up.length)}${[...new Set(LIB.items.map((x) => x.cat))].map((c) => { const l = catList(`cat:${c}`, items); return row(c, l.slice(0, 30), `cat:${c}`, l.length); }).join('')}${row('Deine Likes', liked.filter((x) => x.kind !== 'builtin'), 'liked')}`
        : LIB.err ? `<div class="wp-empty">${esc(LIB.err)} <button class="wp-glass-btn" data-wp-lib-retry>Nochmal</button></div>` : `<div class="wp-empty wp-prem-soon"><h3>Die Bibliothek lädt …</h3><p>Hunderte Live-Wallpaper in 4K – kostenlos für alle. Gleich geht’s los.</p><button class="wp-glass-btn" data-wp-tab="live">Zu Revulution Live</button></div>`;
    }
    return `<div class="wp-app ${it ? 'detail' : ''}">${nav}<div class="wp-body">${body}</div>${player(items)}</div>`;
  }

  /** Bild und Name des angeklickten Hintergrunds für die Monitor-Vorschau. */
  function pickInfo(e) {
    const el = e.target.closest('[data-bg-builtin-desktop],[data-bg-cloud-desktop],[data-bg-desktop],[data-bg-lib-desktop]');
    const id = el?.dataset.bgBuiltinDesktop || el?.dataset.bgCloudDesktop || el?.dataset.bgDesktop || el?.dataset.bgLibDesktop;
    const it = allItems().find((x) => x.id === id);
    return it ? { img: it.img, name: it.name } : {};
  }
  // Titelbild wechselt alle 9 s von selbst
  setInterval(() => {
    if (!active() || ui.tab !== 'home' || ui.detail || ui.cat || ui.q || document.hidden) return;
    ui.hero += 1;
    ctx().render();
  }, 9000);
  document.addEventListener('click', (e) => {
    if (!active()) return;
    const q = (sel) => e.target.closest?.(sel);
    const abg = q('[data-wp-appbg]')?.dataset.wpAppbg;
    if (abg) {
      const it = allItems().find((x) => x.key === abg);
      if (!it) return;
      const done = () => ctx().toast(`${it.name} ist jetzt der Hintergrund der App.`);
      if (it.kind === 'builtin') return window.hub.setSettings({ wallpaper: it.id }).then(done).catch(() => {});
      if (it.kind === 'premium') return window.hub.library.appBg(it.id).then(done).catch((err) => ctx().toast(String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error'));
      return window.hub.appBgImage(it.img).then(done).catch((err) => ctx().toast(String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error'));
    }
    // 2.42: Melden → Support-Seite mit diesem Hintergrund schon ausgewählt
    const rep = q('[data-wp-report]')?.dataset.wpReport;
    if (rep) {
      const it = allItems().find((x) => x.key === rep);
      return window.revSupport?.({ kind: 'wallpaper', ref: rep, refName: it?.name || rep, img: it?.img || '' });
    }
    const buy = q('[data-wp-buy]')?.dataset.wpBuy;
    if (buy) {
      const it = LIB.items.find((x) => x.id === buy);
      if (!it || !window.confirm(`„${it.name}“ für ${it.price} Punkte kaufen? Er gehört dann deinem Konto – auf jedem PC.`)) return;
      return window.hub.library.buy(buy).then((r) => { LIB.owned.add(buy); ctx().toast(`Gekauft! Noch ${r.points} Punkte.`); ctx().render(); }).catch((err) => ctx().toast(String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error'));
    }
    const play = q('[data-wp-play]')?.dataset.wpPlay;
    if (play != null) {
      return window.hub.library.play(play === '1').then(() => ctx().render()).catch((err) => ctx().toast(String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error'));
    }
    const step = q('[data-wp-step]')?.dataset.wpStep;
    if (step != null) {
      ctx().toast('Nächster Hintergrund wird geladen …');
      return window.hub.library.step(step).then((r) => ctx().toast(r?.live ? 'Live-Hintergrund läuft jetzt auf deinem Desktop.' : 'Desktop-Hintergrund gesetzt.')).catch((err) => ctx().toast(String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error'));
    }
    if (q('[data-wp-lib-retry]')) {
      LIB.loaded = false;
      return loadLib(true);
    }
    const like = q('[data-wp-like]')?.dataset.wpLike;
    if (like) {
      e.stopPropagation();
      return setLike(like);
    }
    const tab = q('[data-wp-tab]')?.dataset.wpTab;
    if (tab) {
      Object.assign(ui, { tab, detail: null, q: '', cat: '' });
      return ctx().render();
    }
    const cat = q('[data-wp-cat]')?.dataset.wpCat;
    if (cat) {
      const sc = document.querySelector('.content');
      ui.catScroll = sc?.scrollTop || 0;
      ui.cat = cat;
      sc?.scrollTo?.({ top: 0 });
      return ctx().render();
    }
    const open = q('[data-wp-open]')?.dataset.wpOpen;
    if (open) {
      const sc = document.querySelector('.content');
      if (!ui.detail) ui.scrollY = sc?.scrollTop || 0; // 2.47: Stelle merken, an die „Zurück“ springt
      ui.detail = open;
      sc?.scrollTo?.({ top: 0 });
      return ctx().render();
    }
    if (q('[data-wp-back]')) {
      let y;
      if (ui.detail) {
        ui.detail = null;
        y = ui.scrollY || 0;
      } else {
        ui.cat = '';
        y = ui.catScroll || 0;
      }
      ctx().render();
      // nach dem Neuzeichnen (Bilder haben feste Seitenverhältnisse, die Höhe stimmt sofort)
      requestAnimationFrame(() => document.querySelector('.content')?.scrollTo?.({ top: y }));
      return;
    }
    const h = q('[data-wp-hero]')?.dataset.wpHero;
    if (h) {
      ui.hero = Math.max(0, ui.hero + Number(h) + 8);
      return ctx().render();
    }
    const dot = q('[data-wp-dot]')?.dataset.wpDot;
    if (dot != null) {
      ui.hero = Number(dot);
      return ctx().render();
    }
    if (q('[data-wp-shuffle]')) {
      ui.hero = Math.floor(Math.random() * 8);
      return ctx().render();
    }
  }, true);
  // 2.47 Karten spielen beim Drüberfahren das echte Live-Video (gestreamt, erst dann geladen)
  document.addEventListener('mouseover', (e) => {
    if (!active()) return;
    const card = e.target.closest?.('[data-wp-hv]');
    if (!card || card.querySelector('video')) return;
    const v = document.createElement('video');
    Object.assign(v, { muted: true, loop: true, autoplay: true, playsInline: true, preload: 'auto' });
    v.className = 'wp-card-vid';
    v.src = card.dataset.wpHv;
    v.addEventListener('playing', () => v.classList.add('on'), { once: true });
    card.querySelector('img')?.after(v);
    const off = () => {
      card.removeEventListener('mouseleave', off);
      v.classList.remove('on');
      setTimeout(() => { v.pause(); v.removeAttribute('src'); v.load(); v.remove(); }, 260);
    };
    card.addEventListener('mouseleave', off);
  });
  document.addEventListener('change', (e) => {
    if (!active() || !e.target.matches?.('[data-wp-auto]')) return;
    window.hub.library.auto(e.target.value).then((m) => ctx().toast(m === 'off' ? 'Automatischer Wechsel aus.' : m === 'hour' ? 'Ab jetzt jede Stunde ein neuer Live-Hintergrund.' : 'Ab jetzt jeden Tag ein neuer Live-Hintergrund.')).catch(() => {});
  });
  document.addEventListener('input', (e) => {
    if (!active() || !e.target.matches?.('[data-wp-q]')) return;
    ui.q = e.target.value;
    clearTimeout(ui.qT);
    ui.qT = setTimeout(() => {
      ctx().render();
      const inp = document.querySelector('[data-wp-q]');
      if (inp) {
        inp.focus();
        inp.setSelectionRange(inp.value.length, inp.value.length);
      }
    }, 180);
  });

  T.register(
    'tool-backgrounds',
    { nav: 'Hintergründe', title: 'Hintergründe', sub: 'Desktop-Bilder und Meldungen', icon: 'image', tint: 'linear-gradient(135deg,#38bdf8,#6366f1)', desc: 'Lade Desktop-Hintergründe herunter oder setze sie direkt als Windows-Hintergrund. Bugs und Ideen gehen an das separate Admin-Center.' },
    html,
  );

  document.addEventListener('click', async (e) => {
    if (!active() || st.busy) return;
    const d = (sel) => e.target.closest?.(sel);
    try {
      const desk = d('[data-bg-desktop]')?.dataset.bgDesktop;
      if (desk) {
        st.busy = true;
        const target = await window.pickWallpaperTarget(pickInfo(e));
        if (!target) return;
        await window.hub.community.desktop(desk, target);
        ctx().toast('Desktop-Hintergrund gesetzt.');
        return ctx().render();
      }
      const cloudDesk = d('[data-bg-cloud-desktop]')?.dataset.bgCloudDesktop;
      if (cloudDesk) {
        st.busy = true;
        const target = await window.pickWallpaperTarget(pickInfo(e));
        if (!target) return;
        await window.hub.community.cloudDesktop(cloudDesk, target);
        ctx().toast('Desktop-Hintergrund gesetzt.');
        return ctx().render();
      }
      const libDesk = d('[data-bg-lib-desktop]')?.dataset.bgLibDesktop;
      if (libDesk) {
        st.busy = true;
        const target = await window.pickWallpaperTarget(pickInfo(e));
        if (!target) return;
        const r = await window.hub.library.desktop(libDesk, target);
        ctx().toast(r?.live ? 'Live-Hintergrund läuft jetzt auf deinem Desktop.' : 'Desktop-Hintergrund gesetzt.');
        return ctx().render();
      }
      if (d('[data-bg-cloud-refresh]')) {
        st.cloud = null;
        return loadCloud(true);
      }
      if (d('[data-bg-sub-send]') && st.sub?.url) {
        st.busy = true;
        ctx().render();
        await window.hub.community.submit({ name: st.sub.name || 'Hintergrund', img: st.sub.url });
        st.sub = null;
        ctx().toast('Danke! Dein Hintergrund ist beim Admin zur Prüfung.');
        return ctx().render();
      }
      const builtinDesk = d('[data-bg-builtin-desktop]')?.dataset.bgBuiltinDesktop;
      if (builtinDesk) {
        st.busy = true;
        const target = await window.pickWallpaperTarget(pickInfo(e));
        if (!target) return;
        await window.hub.community.builtinDesktop(builtinDesk, target);
        ctx().toast('Windows-Hintergrund gesetzt.');
        return ctx().render();
      }
      const dl = d('[data-bg-download]')?.dataset.bgDownload;
      if (dl) {
        st.busy = true;
        const r = await window.hub.community.download(dl);
        const a = document.createElement('a');
        a.href = r.data;
        a.download = r.file || `${r.name}.png`;
        a.click();
        st.data = await window.hub.community.status();
        return ctx().render();
      }
      if (d('[data-report-send]')) {
        st.busy = true;
        await window.hub.community.report({ app: st.app, type: st.type, text: document.querySelector('[data-report-text]')?.value || '' });
        document.querySelector('[data-report-text]').value = '';
        ctx().toast('Danke – die Meldung ist in der Datenbank.');
        st.data = await window.hub.community.status();
        return ctx().render();
      }
    } catch (error) {
      ctx().toast(error.message || 'Das hat nicht geklappt.', 'error');
    } finally {
      st.busy = false;
    }
  });

  document.addEventListener('input', (e) => {
    if (active() && e.target.matches?.('[data-bg-sub-name]') && st.sub) st.sub.name = e.target.value;
  });

  document.addEventListener('change', async (e) => {
    if (!active()) return;
    if (e.target.matches?.('[data-bg-sub-file]') && e.target.files?.[0]) {
      const f = e.target.files[0];
      try {
        const r = await shrink(f);
        st.sub = { ...r, name: st.sub?.name || f.name.replace(/\.[a-z0-9]+$/i, '').slice(0, 60) };
      } catch (error) {
        ctx().toast(error.message || 'Bild konnte nicht gelesen werden.', 'error');
      }
      return ctx().render();
    }
    if (e.target.matches?.('[data-report-app]')) st.app = e.target.value;
    if (e.target.matches?.('[data-report-type]')) st.type = e.target.value;
  });
})();
