'use strict';

/*
 * 2.45 Geräte-Apps (Kategorie Gaming, neben „Geräte & RGB“):
 *  (2.45.2: Maus-Studio und AJAZZ-Studio entfernt – Tastatur/Maus/RGB bleiben in „Geräte & RGB“.)
 *
 *  - Stream-Deck-Studio: Tasten-Raster mit Aktionen (Spotify/Medien, Screenshot, Soundboard, Apps, Webseiten,
 *    Crosshair, Ketten) – per Klick oder per Hardware-Taste (z. B. F13–F24 vom Deck) auslösbar.
 *  - Lüfter: Windows-Kühlrichtlinie, GPU-Lüfter/Temperatur, Mainboard-Sensoren (falls verfügbar).
 * Belegungen landen in denselben Regeln wie die Tastatur-App (eine Engine für alles).
 */
(() => {
  const A = window.RevApp;
  const ME = window.RevMacroEditor;
  if (!A) return;
  const { esc } = A;
  const ctx = () => window.HubTools.ctx();

  /* ---------------------------------------------------------------- gemeinsame Regel-Helfer */
  const kbCfg = () => {
    const s = ctx().state()?.settings?.keyboard || {};
    const c = { enabled: s.enabled === true, profiles: Array.isArray(s.profiles) && s.profiles.length ? JSON.parse(JSON.stringify(s.profiles)) : [{ id: 'global', name: 'Überall', apps: [], on: true, rules: [] }] };
    if (!c.profiles.some((p) => !p.apps?.length)) c.profiles.unshift({ id: 'global', name: 'Überall', apps: [], on: true, rules: [] });
    return c;
  };
  const globalProfile = (c) => c.profiles.find((p) => !p.apps?.length);
  async function kbSave(c, enable = true) {
    if (enable) c.enabled = true;
    await window.hub.setSettings({ keyboard: c });
    const st = await window.hub.keyboard.apply();
    window.__kbReset?.();
    return st;
  }
  function setRule(c, from, rule) {
    const p = globalProfile(c);
    p.rules = p.rules.filter((r) => r.from !== from);
    if (rule) p.rules.push({ from, on: true, ...rule });
  }
  /* ================================================================ Deck Studio (2.45.4)
     Stream Deck / Ulanzi D200: Tasten als echte Bilder (eigenes Bild je Taste oder ein Hintergrundbild über
     alle Tasten), Rechtsklick-Menü, installierte Programme, Tastenkombinationen, Lautstärke, Seiten, Uhren,
     Claude-Status (animiert, Ton + Aufleuchten wenn fertig, rot bei Limit). Das Studio zeigt dieselben Bilder
     wie das Deck. Der Hub läuft bei geschlossenem Fenster weiter, damit das Deck funktioniert. */
  const DECK_ACTIONS = [
    ['none', 'Keine Aktion'], ['media', 'Spotify / Medien'], ['volume', 'Lautstärke'], ['program', 'Programm öffnen'], ['app', 'Hub-App öffnen'], ['open', 'Webseite / Datei öffnen'],
    ['keys', 'Tastenkombination'], ['screenshot', 'Screenshot'], ['record', 'Aufnahme an/aus'], ['widgets', 'Widgets an/aus'], ['agent', 'KI-Agent (Claude, ChatGPT, Freebuff)'], ['clock', 'Uhr'], ['widget', 'Widget (Wetter, PC-Leistung, Erde)'], ['soundmute', 'Soundboard stumm an/aus'], ['soundstop', 'Alle Sounds stoppen'], ['micmute', 'Mikrofon stumm an/aus'],
    ['sound', 'Soundboard-Sound'], ['page', 'Seite wechseln'], ['crosshair', 'Crosshair an/aus'], ['lock', 'PC sperren'], ['timer', 'Timer (mit Ring auf der Taste)'], ['multi', 'Mehrere Aktionen (Kette)'],
  ];
  const CLOCKS = [['digital', 'Digital'], ['analog', 'Analog'], ['sbb', 'Bahnhofsuhr'], ['date', 'Datum']];

  /* ---------------------------------------------------------------- Claude-Status */
  const cl = { status: null, flashUntil: 0, frame: 0 };
  const clText = (s) => (!s || s.off ? 'aus' : s.limit ? 'Limit erreicht' : s.question ? 'Frage' : s.working ? `arbeitet${s.agents ? ` · ${s.agents} Agent${s.agents > 1 ? 'en' : ''}` : ''}` : s.done ? 'fertig' : 'ruht');
  function clState() {
    const s = cl.status;
    if (!s || s.off) return 'off';
    if (s.working) return Date.now() < cl.flashUntil ? 'flash' : 'working'; // 2.45.9: arbeitet geht vor Limit
    if (s.limit) return 'limit';
    if (s.question) return 'question';
    if (Date.now() < cl.flashUntil) return 'flash';
    if (s.working) return 'working';
    if (s.done) return 'done';
    return 'idle';
  }
  // Ton, wenn Claude fertig ist (kein Fenster unten rechts)
  function chime() {
    try {
      const ac = new (window.AudioContext || window.webkitAudioContext)();
      const now = ac.currentTime;
      [[880, 0], [1318.5, 0.16], [1760, 0.32]].forEach(([f, t]) => {
        const o = ac.createOscillator(), g = ac.createGain();
        o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0, now + t);
        g.gain.linearRampToValueAtTime(0.22, now + t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, now + t + 0.55);
        o.connect(g).connect(ac.destination);
        o.start(now + t); o.stop(now + t + 0.6);
      });
      setTimeout(() => ac.close(), 1500);
    } catch { /* kein Ton möglich */ }
  }
  // Tasten, die sich bewegen: KI-Agenten, die gerade arbeiten (Ring dreht) und Claude, wenn es fertig wird (leuchtet auf)
  const agentState = (agent) => {
    if (agent === 'claude' || !agent) { const st = clState(); return st === 'flash' ? 'done' : st; }
    const o = cl.status?.others?.[agent];
    return !cl.status || cl.status.off ? 'off' : o?.status || 'off';
  };
  const claudeKeys = () => (dk.data ? Object.entries(dk.data.pages[ul.deckPage]?.buttons || {}).filter(([, b]) => {
    if (b?.action?.type !== 'agent') return false;
    const ag = b.action.agent || 'claude';
    return agentState(ag) === 'working' || (ag === 'claude' && clState() === 'flash');
  }).map(([i]) => Number(i)) : []);
  if (window.hub.claude) {
    const sigOf = (s) => `${clText(s)}|${s?.others?.codex?.status}|${s?.others?.freebuff?.status}|${Boolean(s?.others?.claudeLogo)}`;
    const onClaude = (s) => {
      const before = sigOf(cl.status);
      cl.status = s;
      if (sigOf(s) !== before) { ulPush(150); if (dk.root) dkPaint(); }
    };
    window.hub.claude.status().then(onClaude).catch(() => {});
    window.hub.claude.onStatus(onClaude);
    window.hub.claude.onDone(() => {
      cl.flashUntil = Date.now() + 6000; // Taste leuchtet 6 s orange auf
      chime();
      ulPush(0);
    });
  }
  // Animation der Claude-Taste (arbeitet: Claude-Symbole; fertig: orange aufleuchten)
  setInterval(() => {
    const keys = claudeKeys();
    if (!keys.length) return;
    cl.frame++;
    if (ul.status?.connected && !ul.busy) {
      ul.busy = true;
      window.hub.ulanzi.push(keys.map((i) => ({ index: i, png: keyImage(dk.data.pages[ul.deckPage].buttons[i], i) })), { partial: true }).catch(() => {}).finally(() => { ul.busy = false; });
    }
    if (dk.root && dk.page === ul.deckPage) for (const i of keys) { const im = dk.root.querySelector(`[data-dk-key="${i}"] img`); if (im) im.src = keyImage(page().buttons[i], i); }
  }, 450);
  const ago = (t) => {
    const m = Math.round((Date.now() - t) / 60000);
    return m < 1 ? 'gerade eben' : m < 60 ? `vor ${m} min` : `vor ${Math.round(m / 60)} h`;
  };
  function claudeCard() {
    const s = cl.status;
    const on = ctx().state()?.settings?.claudeLink === true;
    const chip = (st) => `<span class="cl-chip ${st}">${st === 'working' ? '● arbeitet' : st === 'done' ? '✓ fertig' : st === 'question' ? '? Frage' : st === 'limit' ? '⛔ Limit' : '○ ruht'}</span>`;
    return `<div class="rv-card cl-card"><div class="rv-row between"><div><b>✳️ Claude</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Zeigt, ob Claude arbeitet oder fertig ist – mit allen aktiven Agenten. Eine Taste „KI-Agent“ zeigt das App-Logo mit drehendem Ring, solange gearbeitet wird, leuchtet orange auf und spielt einen Ton, wenn Claude fertig ist, und wird rot beim Limit. Drücken öffnet die App – bei Claude direkt den passenden Chat. Liest nur lokal deine Claude-Verläufe.</p></div>
      <label class="rv-row" style="gap:8px;white-space:nowrap"><input type="checkbox" data-cl-on ${on ? 'checked' : ''}/> Mit Claude verbinden</label></div>
      ${on ? (s?.sessions?.length ? `<div class="cl-list">${s.sessions.slice(0, 6).map((x) => `<div class="cl-row"><span class="cl-proj">${esc(x.project)}</span>${chip(x.status)}<small>${ago(x.at)}</small>${x.agents.length ? `<div class="cl-agents">${x.agents.slice(0, 6).map((a) => `<span class="cl-agent ${a.status}" title="Agent ${esc(a.id)}">🤖 ${a.status === 'working' ? 'arbeitet' : 'fertig'}</span>`).join('')}</div>` : ''}</div>`).join('')}</div>` : '<p class="rv-muted" style="margin:10px 0 0">Keine Claude-Sitzung in den letzten 3 Stunden.</p>') : ''}
    </div>`;
  }

  /* ---------------------------------------------------------------- Daten */
  const dk = { root: null, data: null, page: 0, sel: null, capture: false, loaded: false, clip: null, apps: null };

  /* ---------------------------------------------------------------- 2.45.9 Timer-Ringe und Mikrofon stumm */
  const timers = new Map(); // Aktion der Taste → { end, total }
  const mic = { muted: false, at: 0, busy: false };
  function refreshMic(force) {
    if (mic.busy || (!force && Date.now() - mic.at < 5000)) return;
    mic.busy = true;
    window.hub.deck.micMute('state').then((r) => {
      const was = mic.muted;
      mic.muted = Boolean(r?.muted);
      mic.at = Date.now();
      if (was !== mic.muted) { ulPush(50); if (dk.root) dkPaint(); }
    }).catch(() => { mic.at = Date.now(); }).finally(() => { mic.busy = false; });
  }
  // Timer-Taste: Ring zeigt die Restzeit, in der Mitte mm:ss; abgelaufen = blinkt rot
  function drawTimerKey(g, b) {
    const t = timers.get(b.action);
    const cx = S / 2, cy = 88, R = 62;
    const left = t ? t.end - Date.now() : 0;
    const total = t?.total || Math.max(1, Number(b.action.minutes) || 5) * 60000;
    g.lineCap = 'round';
    g.lineWidth = 12;
    g.strokeStyle = 'rgba(255,255,255,.14)';
    g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.stroke();
    const done = t && left <= 0;
    if (t && !done) {
      const p = Math.max(0, Math.min(1, left / total));
      g.strokeStyle = p > 0.25 ? '#ff9f0a' : '#ff453a';
      g.beginPath(); g.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p); g.stroke();
    } else if (done) {
      g.strokeStyle = Math.floor(Date.now() / 500) % 2 ? '#ff453a' : '#7f1d1d';
      g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.stroke();
    }
    const secs = t ? Math.max(0, Math.ceil(left / 1000)) : total / 1000;
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
    g.font = font(800, secs >= 3600 ? 30 : 38);
    const mm = Math.floor(secs / 60), ss = secs % 60;
    g.fillText(secs >= 3600 ? `${Math.floor(mm / 60)}:${String(mm % 60).padStart(2, '0')} h` : `${mm}:${String(ss).padStart(2, '0')}`, cx, cy);
    g.font = font(700, 24);
    g.fillStyle = 'rgba(255,255,255,.85)';
    g.fillText(done ? 'Fertig!' : t ? (b.label || 'Timer') : `${b.label || 'Timer'} ▶`, cx, 172);
  }

  /* ---------------------------------------------------------------- 2.45.8 Soundboard ins Mikrofon */
  const snd = { st: null, dev: null, devLoading: false, levelT: 0 };
  // Virtuelle Mikrofone erkennt man an der Wiedergabe-Seite („… Input“ / „Virtual“ / „Revolution Mic“)
  const isVirtual = (label) => /cable|virtual|voicemeeter|revolution mic|vb-audio/i.test(label || '');
  function loadSoundState() {
    window.hub.sound?.state().then((s) => { snd.st = s; if (dk.root) dkPaint(); }).catch(() => {});
  }
  function loadSoundDevices() {
    if (snd.devLoading) return;
    snd.devLoading = true;
    window.hub.sound.devices().then((d) => { snd.dev = d; }).catch(() => { snd.dev = { mics: [], outs: [] }; }).finally(() => { snd.devLoading = false; if (dk.root) dkPaint(); });
  }
  if (window.hub.sound) {
    loadSoundState();
    window.hub.sound.onState((s) => {
      const was = snd.st?.muted;
      snd.st = { ...(snd.st || {}), ...s };
      if (was !== s.muted) ulPush(100); // Stumm-Taste umfärben
      if (dk.root) { const lv = dk.root.querySelector('[data-snd-level]'); if (!lv) dkPaint(); }
    });
  }
  // 2.46 eigenes virtuelles Mikrofon (Name frei wählbar, erscheint so in Discord/OBS/Teams)
  const vm = { st: null, loading: false, busy: '', step: '' };
  function loadVmic() {
    if (vm.loading || !window.hub.vmic) return;
    vm.loading = true;
    window.hub.vmic.status().then((s) => { vm.st = s; }).catch(() => { vm.st = { supported: false }; }).finally(() => { vm.loading = false; if (dk.root) dkPaint(); });
  }
  window.hub.vmic?.onStep((t) => { vm.step = t || ''; const el = dk.root?.querySelector('[data-vm-step]'); if (el) el.textContent = vm.step; });
  function vmicCard() {
    if (!window.hub.vmic) return '';
    if (!vm.st) { loadVmic(); return '<div class="vm-box"><div class="vm-ico">🎙</div><div class="vm-txt"><b>Revolution Mic</b><p class="rv-muted">Virtuelles Mikrofon wird gesucht …</p></div></div>'; }
    const v = vm.st;
    if (v.supported === false) return '';
    const name = esc(v.name || 'Revolution Mic');
    const busy = Boolean(vm.busy);
    if (!v.installed) {
      return `<div class="vm-box"><div class="vm-ico">🎙</div><div class="vm-txt"><b>Eigenes Mikrofon einrichten</b>
        <p class="rv-muted">Damit andere deine Sounds hören, legt der Hub ein virtuelles Mikrofon an (Treiber VB-CABLE, kostenlos vom Hersteller; Windows fragt einmal nach Adminrechten). Danach wählst du es in Discord &amp; Co. als Eingabe – dein echtes Mikrofon und das Soundboard kommen dort zusammen an.</p>
        <div class="rv-row vm-row"><input class="rv-input sm" data-vm-name maxlength="40" value="${name}" placeholder="Name des Mikrofons" ${busy ? 'disabled' : ''}/><button class="rv-btn sm primary" data-vm-install ${busy ? 'disabled' : ''}>${busy ? 'Läuft …' : 'Mikrofon einrichten'}</button></div>
        <p class="rv-muted vm-step" data-vm-step>${esc(vm.step)}</p></div></div>`;
    }
    return `<div class="vm-box ok"><div class="vm-ico">🎙</div><div class="vm-txt"><b>${esc(v.mic?.name || name)} <span class="vm-pill">aktiv</span></b>
      <p class="rv-muted">In Discord, OBS, Teams … als <b>Eingabegerät</b> „${esc(v.mic?.label || name)}“ wählen. Der Hub schickt dein Mikrofon + Soundboard dorthin.</p>
      <div class="rv-row vm-row"><input class="rv-input sm" data-vm-name maxlength="40" value="${esc(v.mic?.name || name)}" placeholder="Neuer Name" ${busy ? 'disabled' : ''}/><button class="rv-btn sm" data-vm-rename ${busy ? 'disabled' : ''}>${vm.busy === 'rename' ? 'Benenne um …' : 'Umbenennen'}</button><button class="rv-btn sm" data-vm-route ${busy ? 'disabled' : ''} title="Mix auf dieses Mikrofon legen und einschalten">Verbinden</button></div>
      <label class="rv-row vm-def"><input type="checkbox" data-vm-default ${v.isDefault ? 'checked' : ''} ${busy ? 'disabled' : ''}/> <span><b>Als Windows-Standardmikrofon</b> – damit es auch Spiele wie Fortnite (Sprachchat) automatisch nehmen. Aus = dein altes Mikrofon ist wieder Standard.</span></label>
      <p class="rv-muted vm-step" data-vm-step>${esc(vm.step)}</p></div></div>`;
  }
  async function vmicDo(kind) {
    const name = dk.root?.querySelector('[data-vm-name]')?.value || '';
    vm.busy = kind;
    dkPaint();
    try {
      const r = kind === 'install' ? await window.hub.vmic.install(name) : kind === 'rename' ? await window.hub.vmic.rename(name) : await window.hub.vmic.route();
      vm.st = { ...vm.st, ...r };
      snd.dev = null;
      loadSoundState();
      A.toast(kind === 'rename' ? `Mikrofon heißt jetzt „${r.mic?.name || name}“.` : r.routed ? `„${r.mic?.name || 'Revolution Mic'}“ ist bereit – Mikrofon + Soundboard laufen dorthin.` : 'Mikrofon eingerichtet.');
    } catch (err) {
      A.toast(A.errText(err), 'error');
    } finally {
      vm.busy = '';
      vm.step = '';
      dkPaint();
    }
  }
  function soundCard() {
    const s = snd.st || {};
    const m = s.mix || {};
    if (m.on && !snd.dev) loadSoundDevices();
    const dev = snd.dev;
    const virt = (dev?.outs || []).filter((o) => isVirtual(o.label));
    const opt = (list, id, def) => `<option value="">${def}</option>${(list || []).filter((d) => d.id !== 'default').map((d) => `<option value="${esc(d.id)}" ${d.id === id ? 'selected' : ''}>${esc(d.label)}${isVirtual(d.label) ? ' · virtuell' : ''}</option>`).join('')}`;
    return `<div class="rv-card snd-card"><div class="rv-row between"><div><b>Soundboard &amp; Mikrofon</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Alle Sounds (Desktop-Widget und Deck-Tasten) laufen über den Hub. Auf Wunsch mischt der Hub dein echtes Mikrofon mit dem Soundboard und schickt beides an ein virtuelles Mikrofon – das wählst du dann in Discord als Eingabe.</p></div>
      <div class="rv-row" style="gap:14px;white-space:nowrap"><label class="rv-row" style="gap:8px"><input type="checkbox" data-snd-mute ${s.muted ? 'checked' : ''}/> Soundboard stumm</label><label class="rv-row" style="gap:8px"><input type="checkbox" data-snd-on ${m.on ? 'checked' : ''}/> Ins Mikrofon mischen</label></div></div>
      ${vmicCard()}
      ${m.on ? `<div class="snd-grid">
        <label>Dein Mikrofon<select class="rv-input sm" data-snd-mix="micId">${opt(dev?.mics, m.micId, 'Windows-Standard')}</select></label>
        <label>Ausgabe (virtuelles Mikrofon)<select class="rv-input sm" data-snd-mix="outId">${opt(dev?.outs, m.outId, 'Bitte wählen …')}</select></label>
        <label>Mikrofon-Lautstärke<input type="range" min="0" max="2" step="0.05" value="${m.micVol ?? 1}" data-snd-mix="micVol"/></label>
        <label>Soundboard im Mikrofon<input type="range" min="0" max="1.5" step="0.05" value="${m.sbVol ?? 1}" data-snd-mix="sbVol"/></label>
        <label class="rv-row" style="gap:8px"><input type="checkbox" data-snd-mix="monitor" ${m.monitor !== false ? 'checked' : ''}/> Ich höre die Sounds selbst mit</label>
        <div class="snd-meter"><span>Pegel</span><i><b data-snd-level style="width:${s.level || 0}%"></b></i></div>
      </div>
      <p class="rv-muted snd-status">${s.error ? `<span class="snd-err">${esc(s.error)}</span>` : s.active ? `Läuft: ${esc(s.micLabel || 'Mikrofon')} + Soundboard → ${esc(s.outLabel || 'Ausgabe')}` : 'Noch nicht aktiv – Ausgabe wählen.'}</p>
      ${dev && !virt.length && !vm.st?.installed ? '<p class="rv-muted snd-note">Noch kein virtuelles Mikrofon vorhanden – oben „Mikrofon einrichten“ drücken. Zum Ausprobieren kannst du den Mix auch auf deine Kopfhörer legen.</p>' : ''}` : ''}
    </div>`;
  }
  // Pegelanzeige live, solange das Studio offen ist und der Mix läuft
  setInterval(() => {
    if (!dk.root || !snd.st?.mix?.on) return;
    const lv = dk.root.querySelector('[data-snd-level]');
    if (!lv) return;
    window.hub.sound.state().then((s) => { snd.st = s; lv.style.width = `${s.level || 0}%`; }).catch(() => {});
  }, 250);
  const blankDeck = () => ({ cols: 5, rows: 3, pages: [{ name: 'Seite 1', buttons: {} }] });
  async function dkLoad() {
    if (dk.loaded) return;
    dk.loaded = true;
    dk.data = (await A.store.get('streamdeck', null)) || blankDeck();
    if (!dk.data.pages?.length) dk.data = blankDeck();
    // 2.45.6: alte „Claude-Status“-Tasten (wechselnde Symbole) → KI-Agent Claude (Logo mit Ring); Live-Hintergrund → Standbild
    let migrated = false;
    for (const p of dk.data.pages) {
      for (const btn of Object.values(p.buttons || {})) {
        if (btn?.action?.type === 'claude') { btn.action = { type: 'agent', agent: 'claude' }; migrated = true; }
        for (const st of btn?.action?.steps || []) if (st.type === 'claude') { st.type = 'none'; migrated = true; }
      }
    }
    if (dk.data.bg?.kind === 'live') { dk.data.bg = { ...dk.data.bg, kind: 'image', from: dk.data.bg.id }; delete dk.data.bg.id; migrated = true; }
    // 2.45.7: keine Emojis mehr – Tasten bekommen automatisch das passende Symbol (oder das Programm-Logo)
    if ((dk.data.iconsV || 0) < 2) {
      for (const p of dk.data.pages) for (const btn of Object.values(p.buttons || {})) if (btn && !String(btn.icon || '').startsWith('i:')) delete btn.icon;
      dk.data.iconsV = 2;
      migrated = true;
    }
    if (migrated) A.store.set('streamdeck', dk.data);
    const b = dk.data.pages[0].buttons;
    if (!Object.keys(b).length) {
      // 2.45.9 Standard-Belegung (wie das Deck von Revolution): Medien, Widgets, Crosshair, Mikrofon,
      // Bahnhofsuhr, PC sperren, Wetter, zwei Sounds, Timer, Screenshot; kleines Display = PC-Leistung
      Object.assign(b, {
        0: { id: 'd1', label: 'Play/Pause', color: '#1db954', action: { type: 'media', key: 'playpause' } },
        1: { id: 'd2', label: 'Weiter', color: '#1db954', action: { type: 'media', key: 'next' } },
        2: { id: 'd3', label: 'Widgets', color: '#5e5ce6', icon: 'i:widgets', action: { type: 'widgets' } },
        3: { id: 'd4', label: 'Crosshair', color: '#ff375f', action: { type: 'crosshair' } },
        4: { id: 'd5', label: 'Mikrofon', color: '#5e5ce6', action: { type: 'micmute' } },
        5: { id: 'd6', label: 'Uhr', color: '#0400e0', action: { type: 'clock', style: 'sbb' } },
        6: { id: 'd7', label: 'Sperren', color: '#5e5ce6', icon: 'i:lock', action: { type: 'lock' } },
        7: { id: 'd8', label: 'Wetter', color: '#5e5ce6', action: { type: 'widget', kind: 'weather' } },
        8: { id: 'd9', label: 'Oh Hölle nein', color: '#5e5ce6', action: { type: 'sound', pad: 1, volume: 1 } },
        9: { id: 'd10', label: 'Faaah', color: '#5e5ce6', action: { type: 'sound', pad: 0, volume: 1 } },
        10: { id: 'd11', label: 'Timer', color: '#ff9f0a', action: { type: 'timer', minutes: 5 } },
        11: { id: 'd12', label: 'Screenshot', color: '#0a84ff', action: { type: 'screenshot' } },
      });
      if (!dk.data.ulanziSmall) dk.data.ulanziSmall = 'pc';
      if (!dk.data.bg) dk.data.bg = { kind: 'image', from: 'galaxy', zoom: 1, x: 0, y: 0, dim: 0.15 };
      // die beiden Standard-Sounds auf Platz 1 und 2 legen (nur wenn dort noch nichts liegt)
      window.hub.widgetSound?.slots?.().then((have) => {
        if (!have.includes(0)) window.hub.widgetSound.useDefault(0, 'faaah').catch(() => {});
        if (!have.includes(1)) window.hub.widgetSound.useDefault(1, 'oh-hoelle-nein').catch(() => {});
      }).catch(() => {});
      A.store.set('streamdeck', dk.data);
    }
    // Hintergrund aus der Bibliothek ohne Bild (Standard-Belegung): Standbild nachladen
    if (dk.data.bg?.from && !dk.data.bg.src) {
      window.hub.ulanzi?.liveThumb?.(dk.data.bg.from).then((src) => { if (src && dk.data.bg && !dk.data.bg.src) { dk.data.bg.src = src; A.store.set('streamdeck', dk.data); ulPush(100); if (dk.root) dkPaint(); } }).catch(() => {});
    }
    // Programm-Tasten ohne Logo: echtes Logo nachladen
    for (const p of dk.data.pages) for (const btn of Object.values(p.buttons || {})) if (btn?.action?.type === 'program' && btn.action.appId && !btn.appIcon) fetchAppIcon(btn);
  }
  const dkSave = () => {
    ulPush();
    return A.store.set('streamdeck', dk.data);
  };
  // Echtes Logo eines Programms (z. B. Epic Games Launcher) für die Taste holen
  function fetchAppIcon(btn) {
    window.hub.deck.appIcon(btn.action.appId).then((u) => {
      if (!u || btn.action?.type !== 'program') return;
      btn.appIcon = u;
      A.store.set('streamdeck', dk.data);
      ulPush(200);
      if (dk.root) dkPaint();
    }).catch(() => {});
  }
  const page = () => dk.data.pages[dk.page];
  const selBtn = () => (dk.sel != null ? page().buttons[dk.sel] : null);
  const newId = () => Math.random().toString(36).slice(2, 8);

  /* ---------------------------------------------------------------- Tastenbilder */
  const S = 196;
  const imgCache = new Map();
  let repaintT = 0;
  function img(src) {
    if (!src) return null;
    let e = imgCache.get(src);
    if (!e) {
      e = { el: new Image(), ok: false };
      e.el.onload = () => { e.ok = true; clearTimeout(repaintT); repaintT = setTimeout(() => { if (dk.root) dkPaint(); ulPush(100); }, 60); };
      e.el.src = src;
      imgCache.set(src, e);
    }
    return e.ok ? e.el : null;
  }
  const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect(x, y, w, h, r); };
  function drawCover(g, im, x, y, w, h) {
    const k = Math.max(w / im.width, h / im.height);
    const dw = im.width * k, dh = im.height * k;
    g.drawImage(im, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  }
  // Ausschnitt des Deck-Hintergrunds für Taste i (Raster 5 × 3, ein Bild über alle Tasten)
  function drawDeckBg(g, i) {
    const bg = dk.data?.bg;
    const im = img(bg?.src);
    if (!im) return false;
    const cols = 5, rows = 3, W = cols * S, H = rows * S;
    const z = Math.max(1, Number(bg.zoom) || 1);
    const k = Math.max(W / im.width, H / im.height) * z;
    const dw = im.width * k, dh = im.height * k;
    const ox = (W - dw) / 2 + (Number(bg.x) || 0) * ((dw - W) / 2);
    const oy = (H - dh) / 2 + (Number(bg.y) || 0) * ((dh - H) / 2);
    const col = i % cols, row = Math.floor(i / cols);
    g.drawImage(im, ox - col * S, oy - row * S, dw, dh);
    if (bg.dim) { g.fillStyle = `rgba(0,0,0,${Math.min(0.8, Number(bg.dim))})`; g.fillRect(0, 0, S, S); }
    return true;
  }
  function drawClock(g, style) {
    const d = new Date();
    const hh = d.getHours(), mm = d.getMinutes();
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
    if (style === 'digital' || style === 'date') {
      g.font = '800 64px "Segoe UI", system-ui, sans-serif';
      g.fillText(`${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`, S / 2, style === 'date' ? 74 : S / 2 - 6);
      g.font = '600 24px "Segoe UI", system-ui, sans-serif';
      g.fillStyle = 'rgba(255,255,255,.8)';
      g.fillText(style === 'date' ? d.toLocaleDateString('de-CH', { weekday: 'short', day: 'numeric', month: 'short' }) : d.toLocaleDateString('de-CH', { weekday: 'long' }), S / 2, style === 'date' ? 130 : 148);
      return;
    }
    const cx = S / 2, cy = S / 2, R = 76;
    g.fillStyle = style === 'sbb' ? '#fff' : 'rgba(255,255,255,.08)';
    g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
    g.strokeStyle = style === 'sbb' ? '#111' : 'rgba(255,255,255,.85)';
    for (let i = 0; i < 60; i++) {
      const a = (i / 60) * Math.PI * 2, big = i % 5 === 0;
      g.lineWidth = big ? 5 : 2;
      if (!big && style !== 'sbb') continue;
      g.beginPath(); g.moveTo(cx + Math.sin(a) * (R - (big ? 16 : 7)), cy - Math.cos(a) * (R - (big ? 16 : 7))); g.lineTo(cx + Math.sin(a) * (R - 3), cy - Math.cos(a) * (R - 3)); g.stroke();
    }
    const hand = (a, len, w, col) => { g.strokeStyle = col; g.lineWidth = w; g.lineCap = style === 'sbb' ? 'butt' : 'round'; g.beginPath(); g.moveTo(cx - Math.sin(a) * 12, cy + Math.cos(a) * 12); g.lineTo(cx + Math.sin(a) * len, cy - Math.cos(a) * len); g.stroke(); };
    const handCol = style === 'sbb' ? '#111' : '#fff';
    hand(((hh % 12) + mm / 60) / 12 * Math.PI * 2, R * 0.55, 9, handCol);
    hand(mm / 60 * Math.PI * 2, R * 0.82, 6, handCol);
    if (style === 'sbb') {
      const a = d.getSeconds() / 60 * Math.PI * 2;
      g.strokeStyle = '#e2001a'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - Math.sin(a) * 18, cy + Math.cos(a) * 18); g.lineTo(cx + Math.sin(a) * (R * 0.62), cy - Math.cos(a) * (R * 0.62)); g.stroke();
      g.fillStyle = '#e2001a'; g.beginPath(); g.arc(cx + Math.sin(a) * (R * 0.62), cy - Math.cos(a) * (R * 0.62), 8, 0, Math.PI * 2); g.fill();
    }
  }

  /* ---------------------------------------------------------------- 2.45.7 Symbole (Vektor statt Emoji)
     Eigene Linien-Symbole (24er-Raster): s = Linien, f = gefüllte Flächen. Werden scharf in jeder Grösse gezeichnet. */
  const VI = {
    play: { f: 'M7 4.5v15l12-7.5z' },
    playpause: { f: 'M3.5 5v14l10-7z', s: 'M17 5.5v13 M21 5.5v13' },
    next: { f: 'M4 5v14l11-7z', s: 'M19 5.5v13' },
    prev: { f: 'M20 5v14L9 12z', s: 'M5 5.5v13' },
    stop: { f: 'M6 6h12v12H6z' },
    mute: { s: 'M3.5 9.5h4l5-4.5v14l-5-4.5h-4z M16.5 9.5l5 5 M21.5 9.5l-5 5' },
    volup: { s: 'M3.5 9.5h4l5-4.5v14l-5-4.5h-4z M16 8.5a5 5 0 0 1 0 7 M19 5.5a9 9 0 0 1 0 13' },
    voldown: { s: 'M3.5 9.5h4l5-4.5v14l-5-4.5h-4z M16 8.5a5 5 0 0 1 0 7' },
    camera: { s: 'M3 8.5h3.8L8.6 5.5h6.8l1.8 3H21v11H3z M12 16.8a3.6 3.6 0 1 0 0-7.2 3.6 3.6 0 0 0 0 7.2z' },
    record: { s: 'M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17z', f: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z' },
    widgets: { s: 'M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z' },
    lock: { s: 'M5.5 11h13v10h-13z M8.5 11V7.5a3.5 3.5 0 0 1 7 0V11', f: 'M12 14.2a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 0 0 0-3.2z' },
    timer: { s: 'M12 21.5a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M12 9.5v4l2.6 2 M9.5 2.5h5 M12 2.5v3 M19 6l1.5-1.5' },
    music: { s: 'M9 18V5.5l11-2V16 M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0z M20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z' },
    forward: { s: 'M4.5 12h15 M13 5.5l6.5 6.5-6.5 6.5' },
    back: { s: 'M19.5 12h-15 M11 5.5L4.5 12l6.5 6.5' },
    globe: { s: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M3 12h18 M12 3a13.5 13.5 0 0 1 0 18 M12 3a13.5 13.5 0 0 0 0 18' },
    folder: { s: 'M3 6.5a1.5 1.5 0 0 1 1.5-1.5h4.8l2 2.2h8.2a1.5 1.5 0 0 1 1.5 1.5V18a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18z' },
    window: { s: 'M3.5 5h17v14h-17z M3.5 9h17', f: 'M5.5 6.3h1.4v1.4H5.5z M8 6.3h1.4v1.4H8z' },
    keyboard: { s: 'M2.5 6h19v12h-19z M6 10h.01 M9.3 10h.01 M12.6 10h.01 M15.9 10h.01 M18.5 10h.01 M7 14h10' },
    chain: { s: 'M10 14a4.5 4.5 0 0 0 6.4 0l3.2-3.2a4.5 4.5 0 0 0-6.4-6.4l-1.1 1.1 M14 10a4.5 4.5 0 0 0-6.4 0l-3.2 3.2a4.5 4.5 0 0 0 6.4 6.4l1.1-1.1' },
    star: { s: 'M12 3l2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3l-5.6 2.9 1.1-6.2L3 9.6l6.2-.9z' },
    power: { s: 'M12 3v9 M6.3 6.5a8 8 0 1 0 11.4 0' },
    mic: { s: 'M9 6a3 3 0 0 1 6 0v6a3 3 0 0 1-6 0z M5.5 11.5a6.5 6.5 0 0 0 13 0 M12 18v3.5' },
    micoff: { s: 'M9 6a3 3 0 0 1 5.4-1.8 M15 10v2a3 3 0 0 1-4.6 2.5 M5.5 11.5a6.5 6.5 0 0 0 10.6 5 M18.5 11.5a6.5 6.5 0 0 1-.6 2.7 M12 18v3.5 M3.5 3.5l17 17' },
    headphones: { s: 'M3.5 17v-4a8.5 8.5 0 0 1 17 0v4 M3.5 15h3v6h-3z M17.5 15h3v6h-3z' },
    gamepad: { s: 'M7 7.5h10a5 5 0 0 1 5 5v1.5c0 2.5-1.3 4.5-3 4.5-1.4 0-2.2-1-3-2.3l-.4-.7H8.4l-.4.7C7.2 17.5 6.4 18.5 5 18.5c-1.7 0-3-2-3-4.5v-1.5a5 5 0 0 1 5-5z M7.5 10.5v4 M5.5 12.5h4 M16 11.5h.01 M18 13.5h.01' },
    chat: { s: 'M4 5h16v11H9.5L5 20v-4H4z' },
    mail: { s: 'M3 5.5h18v13H3z M3.5 6l8.5 7 8.5-7' },
    heart: { s: 'M12 20s-8-4.8-8-10.5A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5C20 15.2 12 20 12 20z' },
    bolt: { s: 'M13 2.5L4.5 13.5H12l-1 8 8.5-11H12z' },
    fire: { s: 'M12 21.5c-4 0-6.5-2.8-6.5-6.3 0-4.5 4-6.5 4.5-11 3 1.8 4.5 4.3 4.5 6.8.8-.5 1.4-1.5 1.6-2.6 1.6 1.6 2.4 3.8 2.4 6.3 0 3.8-2.5 6.8-6.5 6.8z' },
    rocket: { s: 'M5 15c-1.5 1.5-2 4.5-2 6 1.5 0 4.5-.5 6-2 M9 13.5l1.5 1.5 M14.5 3.5c3 0 6 3 6 6l-8 8-6-6z M15.5 8.5h.01 M7 12l-3 .5 3-3.5h3 M12 17l-.5 3 3.5-3v-3' },
    bulb: { s: 'M9 18h6 M10 21h4 M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.3 1 2.1h5c0-.8.4-1.6 1-2.1A6 6 0 0 0 12 3z' },
    code: { s: 'M8 7l-5 5 5 5 M16 7l5 5-5 5 M14 4l-4 16' },
    monitor: { s: 'M3 4.5h18v12H3z M8.5 20.5h7 M12 16.5v4' },
    download: { s: 'M12 3.5v11 M7 10l5 5 5-5 M4 20h16' },
    search: { s: 'M10.5 17.5a7 7 0 1 0 0-14 7 7 0 0 0 0 14z M15.5 15.5l5 5' },
    gear: { s: 'M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4z M19.4 13.5l1.6 1.2-1.8 3.1-1.9-.7a7 7 0 0 1-1.9 1.1l-.3 2h-3.6l-.3-2a7 7 0 0 1-1.9-1.1l-1.9.7L5 14.7l1.6-1.2a7 7 0 0 1 0-3l-1.6-1.2 1.8-3.1 1.9.7a7 7 0 0 1 1.9-1.1l.3-2h3.6l.3 2a7 7 0 0 1 1.9 1.1l1.9-.7 1.8 3.1-1.6 1.2a7 7 0 0 1 0 3z' },
    home: { s: 'M3.5 11L12 4l8.5 7 M5.5 9.5V20h5v-5.5h3V20h5V9.5' },
    calendar: { s: 'M4 6h16v14.5H4z M4 10h16 M8.5 3.5v4 M15.5 3.5v4' },
    cart: { s: 'M3 4h2.5l2.2 11h10.6l2-8H6.5 M9.5 20.5h.01 M17 20.5h.01' },
    coffee: { s: 'M4 9h12v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z M16 11h1.5a2.5 2.5 0 0 1 0 5H16 M8 3.5v2.5 M12 3.5v2.5' },
    sun: { s: 'M12 16.5a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9z M12 2.5v2 M12 19.5v2 M2.5 12h2 M19.5 12h2 M5.3 5.3l1.4 1.4 M17.3 17.3l1.4 1.4 M5.3 18.7l1.4-1.4 M17.3 6.7l1.4-1.4' },
    moon: { s: 'M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z' },
    cloud: { s: 'M7 19h10.5a4.5 4.5 0 0 0 .6-9 6 6 0 0 0-11.6 1.6A3.8 3.8 0 0 0 7 19z' },
    rain: { s: 'M7 15h10.5a4.2 4.2 0 0 0 .6-8.4 5.6 5.6 0 0 0-10.8 1.5A3.5 3.5 0 0 0 7 15z M8 18l-1 2.5 M12 18l-1 2.5 M16 18l-1 2.5' },
    snow: { s: 'M7 14h10.5a4.2 4.2 0 0 0 .6-8.4 5.6 5.6 0 0 0-10.8 1.5A3.5 3.5 0 0 0 7 14z M8 18h.01 M12 19.5h.01 M16 18h.01 M10 21.5h.01 M14 21.5h.01' },
    storm: { s: 'M7 14h10.5a4.2 4.2 0 0 0 .6-8.4 5.6 5.6 0 0 0-10.8 1.5A3.5 3.5 0 0 0 7 14z M12.5 14l-2.5 4h3.5l-2 4' },
    fog: { s: 'M4 9h16 M6 13h14 M4 17h13 M8 5h9' },
    cpu: { s: 'M7 7h10v10H7z M10 10h4v4h-4z M9.5 3.5v3 M14.5 3.5v3 M9.5 17.5v3 M14.5 17.5v3 M3.5 9.5h3 M3.5 14.5h3 M17.5 9.5h3 M17.5 14.5h3' },
    crosshair: { special: 'crosshair' },
  };
  const VI_NAMES = { play: 'Play', playpause: 'Play/Pause', next: 'Weiter', prev: 'Zurück', stop: 'Stopp', mute: 'Stumm', volup: 'Lauter', voldown: 'Leiser', camera: 'Kamera', record: 'Aufnahme', widgets: 'Widgets', lock: 'Schloss', timer: 'Timer', music: 'Musik', forward: 'Pfeil →', back: 'Pfeil ←', globe: 'Web', folder: 'Ordner', window: 'Fenster', keyboard: 'Tastatur', chain: 'Kette', star: 'Stern', power: 'Ein/Aus', mic: 'Mikrofon', headphones: 'Kopfhörer', gamepad: 'Gaming', chat: 'Chat', mail: 'Mail', heart: 'Herz', bolt: 'Blitz', fire: 'Feuer', rocket: 'Rakete', bulb: 'Idee', code: 'Code', monitor: 'Bildschirm', download: 'Download', search: 'Suche', gear: 'Einstellungen', home: 'Start', calendar: 'Kalender', cart: 'Einkauf', coffee: 'Kaffee', sun: 'Sonne', moon: 'Mond', cloud: 'Wolke', cpu: 'Prozessor', crosshair: 'Fadenkreuz' };
  const viPath = new Map();
  const p2d = (d) => { let p = viPath.get(d); if (!p) { p = new Path2D(d); viPath.set(d, p); } return p; };
  // Fadenkreuz: Ring, vier Striche mit Lücke, Punkt in der Mitte – leuchtend
  function drawCrosshair(g, cx, cy, size, col = '#ff375f') {
    const r = size * 0.36;
    g.save();
    g.shadowColor = col; g.shadowBlur = size * 0.12;
    g.strokeStyle = col; g.lineCap = 'round';
    g.lineWidth = size * 0.055;
    g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.stroke();
    g.lineWidth = size * 0.07;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      g.beginPath(); g.moveTo(cx + dx * r * 0.45, cy + dy * r * 0.45); g.lineTo(cx + dx * r * 1.3, cy + dy * r * 1.3); g.stroke();
    }
    g.fillStyle = '#fff'; g.shadowColor = '#fff';
    g.beginPath(); g.arc(cx, cy, size * 0.05, 0, Math.PI * 2); g.fill();
    g.restore();
  }
  function drawVI(g, name, cx, cy, size, col = '#fff') {
    const ic = VI[name] || VI.star;
    if (ic.special === 'crosshair') return drawCrosshair(g, cx, cy, size);
    g.save();
    g.translate(cx - size / 2, cy - size / 2);
    g.scale(size / 24, size / 24);
    g.lineCap = 'round'; g.lineJoin = 'round'; g.lineWidth = 2;
    g.strokeStyle = col; g.fillStyle = col;
    if (ic.f) g.fill(p2d(ic.f));
    if (ic.s) g.stroke(p2d(ic.s));
    g.restore();
  }
  // Symbol als SVG für die Auswahl im Studio
  const viSvg = (name, px = 22) => {
    const ic = VI[name];
    if (ic?.special === 'crosshair') return `<svg viewBox="0 0 24 24" width="${px}" height="${px}"><g fill="none" stroke="#ff375f" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="7"/><path d="M15.2 12h6M2.8 12h6M12 15.2v6M12 2.8v6"/></g><circle cx="12" cy="12" r="1.2" fill="#fff"/></svg>`;
    return `<svg viewBox="0 0 24 24" width="${px}" height="${px}">${ic?.f ? `<path d="${ic.f}" fill="currentColor"/>` : ''}${ic?.s ? `<path d="${ic.s}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>` : ''}</svg>`;
  };
  // Passendes Symbol zur Aktion (z. B. PC sperren → Schloss)
  function autoIcon(a) {
    const t = a?.type;
    if (t === 'media') return { playpause: 'playpause', next: 'next', prev: 'prev', stop: 'stop', mute: 'mute' }[a.key] || 'playpause';
    if (t === 'volume') return { volup: 'volup', voldown: 'voldown', mute: 'mute' }[a.key] || 'volup';
    if (t === 'open') return /^https?:/i.test(a.target || '') ? 'globe' : 'folder';
    if (t === 'page') return a.to === 'prev' ? 'back' : 'forward';
    if (t === 'soundmute') return snd.st?.muted ? 'mute' : 'volup';
    if (t === 'micmute') return mic.muted ? 'micoff' : 'mic';
    return { program: 'window', app: 'window', keys: 'keyboard', screenshot: 'camera', record: 'record', widgets: 'widgets', sound: 'music', soundstop: 'stop', crosshair: 'crosshair', lock: 'lock', timer: 'timer', multi: 'chain' }[t] || 'star';
  }
  const iconName = (b) => (typeof b.icon === 'string' && b.icon.startsWith('i:') && VI[b.icon.slice(2)] ? b.icon.slice(2) : autoIcon(b.action));
  // Hub-App-Symbol (farbige Kachel wie im Dock) als Bild
  const artCache = new Map();
  function appArtUrl(id) {
    const a = window.APP_ART?.[id];
    if (!a) return null;
    let u = artCache.get(id);
    if (!u) {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="192" height="192" style="color:${a[1]}"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a[0]}"/><stop offset="1" stop-color="${a[1]}"/></linearGradient></defs><rect width="48" height="48" rx="11" fill="url(#g)"/>${a[2].replace(/currentColor/g, a[1])}</svg>`;
      u = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
      artCache.set(id, u);
    }
    return u;
  }
  // Symbol einer Taste: echtes Programm-Logo, Hub-App-Kachel, sonst Vektor-Symbol (alte Emojis werden beim Laden umgestellt)
  function drawKeyIcon(g, b, cx, cy, size) {
    const t = b.action?.type;
    const own = String(b.icon || '').startsWith('i:');
    const logo = own ? null : t === 'program' && b.appIcon ? img(b.appIcon) : t === 'app' ? img(appArtUrl(b.action.app || 'home')) : null;
    if (logo) {
      const k = Math.min(size / logo.width, size / logo.height) * 1.05;
      g.save(); g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 10;
      g.drawImage(logo, cx - (logo.width * k) / 2, cy - (logo.height * k) / 2, logo.width * k, logo.height * k);
      g.restore();
      return;
    }
    if (b.icon && !String(b.icon).startsWith('i:') && b.icon !== 'auto') {
      g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
      g.font = `${Math.round(size * 0.9)}px "Segoe UI Emoji", sans-serif`;
      g.fillText(b.icon, cx, cy + 4);
      return;
    }
    g.save(); g.shadowColor = 'rgba(0,0,0,.35)'; g.shadowBlur = 8;
    drawVI(g, iconName(b), cx, cy, size * 0.78);
    g.restore();
  }

  /* ---------------------------------------------------------------- 2.45.7 Widgets (Tasten und kleines Display) */
  const wd = { wx: null, wxAt: 0, wxBusy: false, st: null, hist: [], sats: [], satsAt: 0, satsBusy: false, earth: null, earthLoading: false, angle: 0 };
  const WX_KIND = (code) => (code <= 1 ? 'sun' : code <= 3 ? 'cloud' : code <= 48 ? 'fog' : code <= 67 || (code >= 80 && code <= 82) ? 'rain' : code <= 77 || code === 85 || code === 86 ? 'snow' : 'storm');
  const WX_TEXT = { sun: 'Klar', cloud: 'Bewölkt', fog: 'Nebel', rain: 'Regen', snow: 'Schnee', storm: 'Gewitter' };
  async function wdWeather(force) {
    if (wd.wxBusy || (!force && wd.wx && Date.now() - wd.wxAt < 10 * 60000)) return;
    wd.wxBusy = true;
    const c = ctx().state()?.settings?.weatherCity || { name: 'Zürich', lat: 47.37, lon: 8.54 };
    try {
      const d = await window.hub.tool.fetch(`https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1`);
      wd.wx = { city: c.name, t: Math.round(d.current.temperature_2m), code: d.current.weather_code, day: d.current.is_day !== 0, hi: Math.round(d.daily.temperature_2m_max[0]), lo: Math.round(d.daily.temperature_2m_min[0]) };
      wd.wxAt = Date.now();
    } catch { /* letzter Wert bleibt */ }
    wd.wxBusy = false;
  }
  async function wdStats() {
    try {
      wd.st = await window.hub.deck.stats();
      wd.hist.push(wd.st.cpu);
      if (wd.hist.length > 60) wd.hist.shift();
    } catch { /* egal */ }
  }
  function wdEarth() {
    if (wd.earth || wd.earthLoading) return;
    wd.earthLoading = true;
    const im = new Image();
    im.onload = () => { const c = document.createElement('canvas'); c.width = 512; c.height = 256; const g = c.getContext('2d'); g.drawImage(im, 0, 0, 512, 256); wd.earth = g.getImageData(0, 0, 512, 256).data; };
    im.src = 'assets/earth-small.jpg';
  }
  function wdSats() {
    if (wd.satsBusy || Date.now() - wd.satsAt < 5 * 60000) return;
    wd.satsBusy = true;
    window.hub.widgetWorldData('satellites').then((s) => { wd.sats = Array.isArray(s) ? s : []; wd.satsAt = Date.now(); }).catch(() => { wd.satsAt = Date.now() - 4 * 60000; }).finally(() => { wd.satsBusy = false; });
  }
  const font = (w, px) => `${w} ${px}px "Segoe UI", system-ui, sans-serif`;
  function drawWeatherW(g, x, y, w, h) {
    const wx = wd.wx;
    g.textBaseline = 'middle';
    if (!wx) { g.fillStyle = 'rgba(255,255,255,.7)'; g.textAlign = 'center'; g.font = font(600, 22); g.fillText('Wetter lädt …', x + w / 2, y + h / 2); return; }
    const kind = WX_KIND(wx.code);
    const icon = kind === 'sun' && !wx.day ? 'moon' : kind;
    const col = { sun: '#ffd60a', moon: '#e5e7ff', cloud: '#e2e8f0', fog: '#cbd5e1', rain: '#7dd3fc', snow: '#f8fafc', storm: '#fde047' }[icon];
    if (w > h * 1.6) {
      drawVI(g, icon, x + h * 0.5, y + h / 2, h * 0.62, col);
      g.textAlign = 'left'; g.fillStyle = '#fff';
      g.font = font(800, Math.round(h * 0.4)); g.fillText(`${wx.t}°`, x + h * 0.98, y + h * 0.36);
      g.font = font(700, Math.round(h * 0.13)); g.fillStyle = 'rgba(255,255,255,.92)'; g.fillText(wx.city.slice(0, 16), x + h * 1.0, y + h * 0.67);
      g.font = font(600, Math.round(h * 0.11)); g.fillStyle = 'rgba(255,255,255,.7)'; g.fillText(`${WX_TEXT[kind]} · ↑${wx.hi}° ↓${wx.lo}°`, x + h * 1.0, y + h * 0.84);
    } else {
      drawVI(g, icon, x + w / 2, y + h * 0.33, h * 0.4, col);
      g.textAlign = 'center'; g.fillStyle = '#fff';
      g.font = font(800, Math.round(h * 0.24)); g.fillText(`${wx.t}°`, x + w / 2, y + h * 0.69);
      g.font = font(600, Math.round(h * 0.1)); g.fillStyle = 'rgba(255,255,255,.8)'; g.fillText(wx.city.slice(0, 12), x + w / 2, y + h * 0.88);
    }
  }
  function gauge(g, cx, cy, r, v, col, label) {
    const a0 = Math.PI * 0.75, a1 = Math.PI * 2.25;
    g.lineCap = 'round'; g.lineWidth = r * 0.2;
    g.strokeStyle = 'rgba(255,255,255,.14)'; g.beginPath(); g.arc(cx, cy, r, a0, a1); g.stroke();
    g.strokeStyle = col; g.beginPath(); g.arc(cx, cy, r, a0, a0 + (a1 - a0) * Math.max(0.01, Math.min(1, v / 100))); g.stroke();
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
    g.font = font(800, Math.round(r * 0.55)); g.fillText(`${Math.round(v)}%`, cx, cy - r * 0.05);
    g.font = font(800, Math.max(15, Math.round(r * 0.34))); g.fillStyle = 'rgba(255,255,255,.8)'; g.fillText(label, cx, cy + r * 0.82);
  }
  function drawPCW(g, x, y, w, h) {
    const st = wd.st || { cpu: 0, mem: 0 };
    if (w > h * 1.6) {
      const r = h * 0.3;
      gauge(g, x + h * 0.42, y + h * 0.46, r, st.cpu, '#34d399', 'CPU');
      gauge(g, x + h * 1.12, y + h * 0.46, r, st.mem, '#60a5fa', 'RAM');
      // Verlauf der Prozessorlast (letzte 2 Minuten)
      const gx = x + h * 1.6, gw = w - (gx - x) - 14, gy = y + 26, gh = h - 52;
      g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1; g.strokeRect(gx, gy, gw, gh);
      const hs = wd.hist;
      if (hs.length > 1) {
        const pts = hs.map((v, i) => [gx + (i / 59) * gw, gy + gh - (v / 100) * gh]);
        const fill = g.createLinearGradient(0, gy, 0, gy + gh); fill.addColorStop(0, 'rgba(52,211,153,.45)'); fill.addColorStop(1, 'rgba(52,211,153,0)');
        g.beginPath(); g.moveTo(pts[0][0], gy + gh); for (const [px, py] of pts) g.lineTo(px, py); g.lineTo(pts[pts.length - 1][0], gy + gh); g.closePath(); g.fillStyle = fill; g.fill();
        g.beginPath(); pts.forEach(([px, py], i) => (i ? g.lineTo(px, py) : g.moveTo(px, py))); g.strokeStyle = '#34d399'; g.lineWidth = 2.5; g.stroke();
      }
      g.textAlign = 'left'; g.textBaseline = 'alphabetic'; g.fillStyle = 'rgba(255,255,255,.7)'; g.font = font(700, 15);
      g.fillText(`${st.memUsed ? (st.memUsed / 1073741824).toFixed(1) : '–'} / ${st.memTotal ? Math.round(st.memTotal / 1073741824) : '–'} GB · ${st.cores || '–'} Kerne`, gx, y + h - 10);
    } else {
      gauge(g, x + w * 0.5, y + h * 0.3, h * 0.17, st.cpu, '#34d399', 'CPU');
      gauge(g, x + w * 0.5, y + h * 0.74, h * 0.17, st.mem, '#60a5fa', 'RAM');
    }
  }
  // Erde mit Tag/Nacht und Satelliten (wie das Desktop-Widget), Pixel für Pixel
  function sunPoint(now) {
    const d = new Date(now);
    const doy = (now - Date.UTC(d.getUTCFullYear(), 0, 0)) / 86400000;
    const decl = (-23.44 * Math.cos((2 * Math.PI / 365) * (doy + 10)) * Math.PI) / 180;
    const utcH = d.getUTCHours() + d.getUTCMinutes() / 60 + d.getUTCSeconds() / 3600;
    return { decl, lon: ((12 - utcH) * 15 * Math.PI) / 180 };
  }
  function drawGlobeW(g, cx, cy, R, withSats) {
    wdEarth();
    if (withSats) wdSats();
    const sats = withSats ? wd.sats : [];
    const r = sats.length ? R * 0.74 : R;
    if (!wd.earth) { g.fillStyle = '#1e3a8a'; g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fill(); return; }
    const now = Date.now();
    if (!wd.angle) wd.angle = sunPoint(now).lon;
    const N = Math.round(r * 2);
    const c = document.createElement('canvas'); c.width = N; c.height = N;
    const cg = c.getContext('2d');
    const frame = cg.createImageData(N, N);
    const sun = sunPoint(now), sinD = Math.sin(sun.decl), cosD = Math.cos(sun.decl);
    const tilt = 0.3, tS = Math.sin(tilt), tC = Math.cos(tilt), E = wd.earth, half = N / 2;
    for (let yy = 0; yy < N; yy++) for (let xx = 0; xx < N; xx++) {
      const nx = (xx - half + 0.5) / half, ny = (yy - half + 0.5) / half, r2 = nx * nx + ny * ny;
      if (r2 > 1) continue;
      const z = Math.sqrt(1 - r2), wy = -ny * tC + z * tS, wz = ny * tS + z * tC;
      const lat = Math.asin(Math.max(-1, Math.min(1, wy))), lon = Math.atan2(nx, wz) + wd.angle;
      const tx = ((Math.floor((lon / (Math.PI * 2) + 0.5) * 512) % 512) + 512) % 512;
      const ty = Math.max(0, Math.min(255, Math.floor((0.5 - lat / Math.PI) * 256)));
      const s = (ty * 512 + tx) * 4, t = (yy * N + xx) * 4;
      const cosZ = Math.sin(lat) * sinD + Math.cos(lat) * cosD * Math.cos(lon - sun.lon);
      const day = Math.max(0, Math.min(1, (cosZ + 0.12) / 0.3));
      const light = (0.16 + 0.84 * day) * (0.82 + 0.18 * z), blue = (1 - day) * 18;
      frame.data[t] = E[s] * light; frame.data[t + 1] = E[s + 1] * light + blue * 0.4; frame.data[t + 2] = E[s + 2] * light + blue; frame.data[t + 3] = r2 > 0.97 ? 255 * (1 - r2) / 0.03 : 255;
    }
    cg.putImageData(frame, 0, 0);
    g.drawImage(c, cx - r, cy - r);
    const at = g.createRadialGradient(cx, cy, r * 0.98, cx, cy, r * 1.12);
    at.addColorStop(0, 'rgba(120,180,255,.4)'); at.addColorStop(1, 'rgba(120,180,255,0)');
    g.fillStyle = at; g.beginPath(); g.arc(cx, cy, r * 1.12, 0, Math.PI * 2); g.fill();
    if (sats.length) {
      const scale = (alt) => r + 4 + (R - r - 4) * Math.min(1, Math.log10(1 + Math.max(0, alt || 400) / 300) / Math.log10(1 + 36000 / 300));
      g.fillStyle = '#ff9d94';
      for (const it of sats) {
        const la = it.lat * Math.PI / 180, lo = it.lon * Math.PI / 180 - wd.angle;
        const sl = Math.sin(la), cl = Math.cos(la), cd = Math.cos(lo);
        const depth = tS * sl + tC * cl * cd, rr = scale(it.alt);
        const px = cx + rr * cl * Math.sin(lo), py = cy - rr * (tC * sl - tS * cl * cd);
        if (depth < 0 && Math.hypot(px - cx, py - cy) < r) continue;
        g.globalAlpha = depth < 0 ? 0.15 : sats.length > 3000 ? 0.45 : 0.9;
        g.fillRect(px - 0.75, py - 0.75, 1.5, 1.5);
      }
      g.globalAlpha = 1;
    }
  }
  function drawWidgetKey(g, kind) {
    if (kind === 'weather') { wdWeather(); return drawWeatherW(g, 6, 6, S - 12, S - 12); }
    if (kind === 'pc') return drawPCW(g, 6, 6, S - 12, S - 12);
    if (kind === 'globe') return drawGlobeW(g, S / 2, S / 2, 88, true);
    return null;
  }

  /* ---------------------------------------------------------------- 2.45.7 Kleines Display (458 × 196) */
  const SW = 458, SH = 196;
  const SMALL_MODES = [
    ['clock', 'Zeigeruhr', 'Deck'], ['time', 'Digital: Zeit', 'Deck'], ['timedate', 'Digital: Zeit + Datum', 'Deck'], ['timeday', 'Digital: Zeit + Wochentag', 'Deck'], ['full', 'Digital: Datum, Zeit, Tag', 'Deck'], ['stats', 'PC-Werte', 'Deck'],
    ['sbb', 'Bahnhofsuhr (SBB)', 'Hub'], ['weather', 'Wetter', 'Hub'], ['globe', 'Erde mit Satelliten', 'Hub'], ['pc', 'PC-Leistung mit Verlauf', 'Hub'], ['off', 'Aus', ''],
  ];
  const SMALL_CUSTOM = ['sbb', 'weather', 'globe', 'pc'];
  const smallMode = () => (SMALL_MODES.some(([k]) => k === dk.data?.ulanziSmall) ? dk.data.ulanziSmall : 'clock');
  const DAY = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
  /** Bild fürs kleine Display – eigene Anzeigen (SBB, Wetter, Erde, PC) und eine Vorschau der eingebauten. */
  function smallImage(mode) {
    const c = document.createElement('canvas');
    c.width = SW; c.height = SH;
    const g = c.getContext('2d');
    const bgr = g.createLinearGradient(0, 0, 0, SH);
    bgr.addColorStop(0, '#15151c'); bgr.addColorStop(1, '#050507');
    g.fillStyle = bgr; g.fillRect(0, 0, SW, SH);
    const d = new Date();
    const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    const right = (big, small1, small2) => {
      g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
      g.font = font(800, 66); g.fillText(big, 214, 78);
      g.font = font(700, 22); g.fillStyle = 'rgba(255,255,255,.85)'; g.fillText(small1, 216, 128);
      if (small2) { g.font = font(600, 18); g.fillStyle = 'rgba(255,255,255,.6)'; g.fillText(small2, 216, 156); }
    };
    if (mode === 'sbb' || mode === 'clock') {
      drawClock(g, mode === 'sbb' ? 'sbb' : 'analog');
      right(hm, DAY[d.getDay()], d.toLocaleDateString('de-CH', { day: 'numeric', month: 'long', year: 'numeric' }));
    } else if (mode === 'weather') {
      wdWeather();
      drawWeatherW(g, 10, 0, SW - 20, SH);
    } else if (mode === 'globe') {
      drawGlobeW(g, 98, SH / 2, 94, true);
      right(hm, `${wd.sats.length ? wd.sats.length.toLocaleString('de-CH') : '…'} Satelliten`, d.toLocaleDateString('de-CH', { weekday: 'short', day: 'numeric', month: 'short' }));
    } else if (mode === 'pc' || mode === 'stats') {
      drawPCW(g, 0, 0, SW, SH);
    } else if (mode === 'off') {
      g.fillStyle = 'rgba(255,255,255,.35)'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = font(700, 26); g.fillText('Display aus', SW / 2, SH / 2);
    } else {
      // Digitaluhren des Decks (Vorschau)
      g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
      const sub = mode === 'timedate' ? d.toLocaleDateString('de-CH') : mode === 'timeday' ? DAY[d.getDay()] : mode === 'full' ? `${d.toLocaleDateString('de-CH')} · ${DAY[d.getDay()]}` : '';
      g.font = font(800, sub ? 78 : 96); g.fillText(`${hm}:${String(d.getSeconds()).padStart(2, '0')}`, SW / 2, sub ? 80 : SH / 2);
      if (sub) { g.font = font(600, 28); g.fillStyle = 'rgba(255,255,255,.8)'; g.fillText(sub, SW / 2, 150); }
    }
    return c.toDataURL('image/png');
  }
  const sm = { busy: false, last: 0, timer: 0 };
  // Eigene Anzeige aufs Deck schicken (SBB jede Sekunde, PC alle 2 s, Erde alle 3 s, Wetter jede Minute)
  async function smallPush(force) {
    const mode = smallMode();
    if (!SMALL_CUSTOM.includes(mode) || !ul.status?.connected || sm.busy) return;
    const every = { sbb: 1000, pc: 2000, globe: 3000, weather: 60000 }[mode];
    if (!force && Date.now() - sm.last < every - 100) return;
    sm.busy = true;
    sm.last = Date.now();
    try { await window.hub.ulanzi.smallImage(smallImage(mode)); } catch { /* nächster Versuch */ }
    sm.busy = false;
  }
  function applySmall() {
    const mode = smallMode();
    window.hub.ulanzi.small(SMALL_CUSTOM.includes(mode) ? 'image' : mode).catch(() => {});
    if (SMALL_CUSTOM.includes(mode)) { if (mode === 'pc') wdStats(); setTimeout(() => smallPush(true), 300); }
  }
  // Takt für Widgets: PC-Werte holen, Erde drehen, Tasten und kleines Display auffrischen, Studio-Vorschau
  setInterval(() => {
    if (!dk.data) return;
    const p = dk.data.pages[ul.deckPage];
    const keys = Object.entries(p?.buttons || {}).filter(([, b]) => b?.action?.type === 'widget');
    const mode = smallMode();
    const needStats = keys.some(([, b]) => b.action.kind === 'pc') || mode === 'pc' || (dk.root && dk.smallSel);
    if (needStats) wdStats();
    wd.angle += 0.035; // Erde dreht langsam
    const sec = new Date().getSeconds();
    // PC alle 2 s, Erde alle 3 s, Wetter jede Minute (Daten alle 10 min)
    const due = keys.filter(([, b]) => (b.action.kind === 'pc' ? sec % 2 === 0 : b.action.kind === 'globe' ? sec % 3 === 0 : sec === 0 || (!wd.wx && sec % 5 === 0)));
    // 2.45.9: laufende Timer jede Sekunde; Mikrofon-Taste: Zustand alle 5 s nachsehen (falls in Discord umgeschaltet)
    for (const e of Object.entries(p?.buttons || {})) {
      const b = e[1];
      if (b?.action?.type === 'timer') {
        const t = timers.get(b.action);
        if (t && Date.now() - t.end < 15000) due.push(e);
        if (t && Date.now() >= t.end && !t.rang) { t.rang = true; chime(); }
      }
      if (b?.action?.type === 'micmute') refreshMic();
    }
    if (due.length && ul.status?.connected && !ul.busy) {
      ul.busy = true;
      window.hub.ulanzi.push(due.map(([i, b]) => ({ index: Number(i), png: keyImage(b, Number(i)) })), { partial: true }).catch(() => {}).finally(() => { ul.busy = false; });
    }
    if (dk.root && dk.page === ul.deckPage) {
      for (const [i, b] of due) { const im = dk.root.querySelector(`[data-dk-key="${i}"] img`); if (im) im.src = keyImage(b, Number(i)); }
      const prev = dk.root.querySelector('[data-dk-smallprev]');
      if (prev) prev.src = smallImage(mode);
    }
    smallPush();
  }, 1000);

  function keyImage(b, i) {
    const c = document.createElement('canvas');
    c.width = S; c.height = S;
    const g = c.getContext('2d');
    g.fillStyle = '#000';
    g.fillRect(0, 0, S, S);
    const hasBg = drawDeckBg(g, i);
    if (!b) return c.toDataURL('image/png');
    const type = b.action?.type;
    // KI-Agent: echtes App-Logo + Status (arbeitet / Frage / fertig / bereit / aus); Claude leuchtet orange auf, wenn fertig
    if (type === 'agent') {
      const ag = b.action.agent || 'claude';
      const st = agentState(ag);
      const flash = ag === 'claude' && clState() === 'flash';
      const col = flash ? (cl.frame % 2 ? '#ff8a3d' : '#d97757') : { working: '#1e293b', question: '#eab308', done: '#15803d', limit: '#dc2626', ready: '#27272f', idle: '#27272f', off: '#18181b' }[st] || '#27272f';
      rr(g, 6, 6, S - 12, S - 12, 34); g.fillStyle = col; g.fill();
      const logo = img(ag === 'claude' ? cl.status?.others?.claudeLogo : cl.status?.others?.[ag]?.logo);
      if (st === 'working') {
        const a = (cl.frame % 12) / 12 * Math.PI * 2;
        g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 7; g.beginPath(); g.arc(S / 2, 80, 58, 0, Math.PI * 2); g.stroke();
        g.strokeStyle = ag === 'claude' ? '#f4a284' : ag === 'codex' ? '#a7f3d0' : '#93c5fd'; g.lineCap = 'round';
        g.beginPath(); g.arc(S / 2, 80, 58, a, a + Math.PI * 0.7); g.stroke();
      }
      if (logo) { g.save(); g.globalAlpha = st === 'off' ? 0.45 : 1; g.beginPath(); g.arc(S / 2, 80, 46, 0, Math.PI * 2); g.clip(); drawCover(g, logo, S / 2 - 46, 34, 92, 92); g.restore(); }
      else drawVI(g, ag === 'claude' ? 'star' : ag === 'codex' ? 'chat' : 'code', S / 2, 80, 70);
      g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillStyle = st === 'question' ? '#1c1400' : '#fff';
      g.font = '700 28px "Segoe UI", system-ui, sans-serif';
      g.fillText({ working: 'arbeitet', question: 'Frage', done: 'fertig', limit: 'Limit', ready: 'bereit', idle: 'bereit', off: 'aus' }[st] || st, S / 2, 162);
      return c.toDataURL('image/png');
    }
    const own = img(b.image);
    if (own) { g.save(); rr(g, 6, 6, S - 12, S - 12, 34); g.clip(); drawCover(g, own, 6, 6, S - 12, S - 12); g.restore(); }
    else if (!hasBg) {
      const grad = g.createLinearGradient(0, 0, 0, S);
      grad.addColorStop(0, (type === 'soundmute' && snd.st?.muted) || (type === 'micmute' && mic.muted) ? '#dc2626' : b.color || '#2c2c34'); grad.addColorStop(1, '#0b0b10');
      rr(g, 6, 6, S - 12, S - 12, 34); g.fillStyle = grad; g.fill();
    }
    if (type === 'clock') { drawClock(g, b.action.style || 'digital'); return c.toDataURL('image/png'); }
    if (type === 'timer') { drawTimerKey(g, b); return c.toDataURL('image/png'); }
    if (type === 'widget') { drawWidgetKey(g, b.action.kind || 'weather'); return c.toDataURL('image/png'); }
    // 2.45.7: Vektor-Symbol bzw. echtes Logo statt Emoji
    if (!own || b.showIcon) drawKeyIcon(g, b, S / 2, b.label ? 82 : S / 2, b.label ? 104 : 128);
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = hasBg || own ? 10 : 0;
    if (b.label) {
      g.fillStyle = '#fff';
      let size = 30;
      g.font = `700 ${size}px "Segoe UI", system-ui, sans-serif`;
      while (size > 16 && g.measureText(b.label).width > S - 24) g.font = `700 ${(size -= 2)}px "Segoe UI", system-ui, sans-serif`;
      g.fillText(b.label, S / 2, own && !b.showIcon ? 166 : 160);
    }
    return c.toDataURL('image/png');
  }
  // Bild aus Datei: verkleinert als Data-URL (Taste 196², Hintergrund max. 1400 px)
  function pickImage(maxSide, square) {
    return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/*';
      inp.onchange = () => {
        const f = inp.files?.[0];
        if (!f) return resolve(null);
        const r = new FileReader();
        r.onload = () => {
          const im = new Image();
          im.onload = () => {
            const c = document.createElement('canvas');
            if (square) { c.width = c.height = maxSide; drawCover(c.getContext('2d'), im, 0, 0, maxSide, maxSide); }
            else { const k = Math.min(1, maxSide / Math.max(im.width, im.height)); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); }
            resolve(c.toDataURL('image/jpeg', 0.88));
          };
          im.onerror = () => resolve(null);
          im.src = r.result;
        };
        r.readAsDataURL(f);
      };
      inp.click();
    });
  }

  /* ---------------------------------------------------------------- Ulanzi D200 direkt */
  const UL_KEYS = 13;
  const ul = { status: null, timer: 0, deckPage: 0, busy: false };
  // 2.45.6: Hintergründe aus der Bibliothek sind ein Standbild (das Live-Abspielen auf dem Deck ruckelte)
  function ulPush(delay = 450) {
    if (!ul.status?.connected || !dk.data) return;
    clearTimeout(ul.timer);
    ul.timer = setTimeout(async () => {
      if (ul.busy) return ulPush(300);
      ul.busy = true;
      try {
        ul.deckPage = dk.page;
        const p = page();
        const keys = [];
        for (let i = 0; i < UL_KEYS; i++) keys.push({ index: i, png: keyImage(p.buttons[i], i) });
        await window.hub.ulanzi.push(keys);
      } catch (e) {
        A.toast(A.errText(e), 'error');
      } finally {
        ul.busy = false;
      }
    }, delay);
  }
  // Uhr-Tasten jede Minute (Bahnhofsuhr: alle 2 s für den Sekundenzeiger) neu zeichnen
  setInterval(() => {
    if (!dk.data) return;
    const p = dk.data.pages[ul.deckPage];
    const clocks = Object.entries(p?.buttons || {}).filter(([, b]) => b?.action?.type === 'clock');
    if (!clocks.length) return;
    const sbb = clocks.some(([, b]) => b.action.style === 'sbb');
    if (!sbb && new Date().getSeconds() > 2) return;
    if (ul.status?.connected && !ul.busy) {
      ul.busy = true;
      window.hub.ulanzi.push(clocks.map(([i, b]) => ({ index: Number(i), png: keyImage(b, Number(i)) })), { partial: true }).catch(() => {}).finally(() => { ul.busy = false; });
    }
    if (dk.root && dk.page === ul.deckPage) for (const [i, b] of clocks) { const im = dk.root.querySelector(`[data-dk-key="${i}"] img`); if (im) im.src = keyImage(b, Number(i)); }
  }, 2000);
  if (window.hub.ulanzi) {
    window.hub.ulanzi.status().then((s) => { ul.status = s; if (s.connected) dkLoad().then(() => { ulPush(0); applySmall(); }); if (dk.data) dkPaint(); }).catch(() => {});
    window.hub.ulanzi.onStatus((s) => {
      const was = ul.status?.connected;
      ul.status = s;
      applyDeckName();
      if (s.connected && !was) dkLoad().then(() => {
        ulPush(0);
        if (dk.data.ulanziBrightness != null) window.hub.ulanzi.brightness(dk.data.ulanziBrightness).catch(() => {});
        applySmall();
      });
      dkPaint();
    });
    window.hub.ulanzi.onButton(async (b) => {
      if (!b?.pressed) return;
      await dkLoad();
      const btn = dk.data.pages[ul.deckPage]?.buttons[b.index];
      const el = dk.root?.querySelector(`[data-dk-key="${b.index}"]`);
      if (el && dk.page === ul.deckPage) { el.classList.remove('press'); void el.offsetWidth; el.classList.add('press'); }
      if (btn) runAction(btn.action);
    });
  }
  /* Name nach angeschlossenem Gerät */
  const dev = { elgato: false, ulanzi: false, checked: 0 };
  const deckName = () => (ul.status?.connected || dev.ulanzi ? 'Ulanzi D200' : dev.elgato ? 'Stream Deck' : 'Deck Studio');
  function applyDeckName() {
    const meta = window.HubTools.TOOLS?.['tool-streamdeck'];
    if (meta) meta.title = deckName();
    if (ctx().state()?.active === 'tool-streamdeck') {
      const t = document.getElementById('page-title');
      if (t) t.textContent = deckName();
    }
  }
  function detectDecks() {
    if (Date.now() - dev.checked < 10000) return;
    dev.checked = Date.now();
    window.hub.deck?.devices?.().then((d) => {
      const changed = d.elgato !== dev.elgato || d.ulanzi !== dev.ulanzi;
      Object.assign(dev, d);
      applyDeckName();
      if (changed) dkPaint();
    }).catch(() => {});
  }
  function ulCard() {
    const s = ul.status;
    const on = ctx().state()?.settings?.ulanziDirect === true || Boolean(s?.running);
    let info = '';
    try { info = s?.info ? JSON.parse(s.info).Dversion : ''; } catch { /* egal */ }
    const state = !on ? 'Aus' : s?.connected ? `Verbunden${info ? ` · Firmware ${esc(info)}` : ''}` : s?.error ? `Fehler: ${esc(s.error)}` : 'Kein D200 gefunden – per USB anschliessen';
    const small = smallMode();
    return `<div class="rv-card dk-ulanzi"><div class="rv-row between"><div><b>Ulanzi D200 – direkt im Hub</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Ohne Ulanzi Studio. Läuft weiter, wenn du das Hub-Fenster schliesst. Ulanzi Studio dabei bitte beenden.</p></div>
      <label class="rv-row" style="gap:8px;white-space:nowrap"><input type="checkbox" data-ul-on ${on ? 'checked' : ''}/> Direkt steuern</label></div>
      ${on ? `<div class="rv-row between" style="margin-top:10px;flex-wrap:wrap;gap:10px"><span class="rv-pill ${s?.connected ? 'ok' : ''}">${s?.connected ? '🟢' : '⚪'} ${state}</span>
        <div class="rv-row" style="flex-wrap:wrap;gap:10px"><label class="rv-muted">Kleines Display <select class="rv-input sm" data-ul-small>${SMALL_MODES.map(([k, n]) => `<option value="${k}" ${small === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <label class="rv-muted">Helligkeit <input type="range" min="5" max="100" step="5" value="${dk.data.ulanziBrightness ?? 80}" data-ul-bright/></label>
        <button class="rv-btn sm" data-ul-push ${s?.connected ? '' : 'disabled'}>Jetzt übertragen</button></div></div>` : ''}
    </div>`;
  }
  // Hintergründe aus der Hub-Bibliothek: Revulution Live (Videos, für alle) und Premium (nur mit Pro)
  const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
  function libHtml() {
    const hs = ctx().state() || {};
    const pro = Boolean(window.RevStore?.pro?.());
    const live = (hs.wallpapers || []).map((id) => `<button class="dk-lib-item ${dk.data.bg?.id === id ? 'on' : ''}" data-dk-live="${esc(id)}"><img src="${fileUrl(`${hs.wallpaperDir}/thumbs/${id}.jpg`)}" alt=""/><em>LIVE</em><span>${esc(id.charAt(0).toUpperCase() + id.slice(1))}</span></button>`).join('');
    const prem = (dk.premium || []).map((x, i) => `<button class="dk-lib-item ${pro ? '' : 'locked'}" data-dk-prem="${i}"><img src="${esc(x.img)}" alt=""/><em class="prem">${pro ? 'PREMIUM' : '🔒 PREMIUM'}</em><span>${esc(x.name || 'Premium')}</span></button>`).join('');
    return `<div class="dk-lib"><b>Revulution Live</b><small class="rv-muted"> · läuft als Animation auf dem Deck</small><div class="dk-lib-grid">${live || '<p class="rv-muted">Keine Live-Hintergründe gefunden.</p>'}</div>
      <b>Premium</b><small class="rv-muted"> · ${pro ? 'mit deinem Pro-Abo freigeschaltet' : 'mit Pro freischalten'}</small><div class="dk-lib-grid">${prem || `<p class="rv-muted">${dk.premiumLoading ? 'Lädt …' : 'Gerade keine Premium-Hintergründe verfügbar.'}</p>`}</div></div>`;
  }
  function loadPremium() {
    if (dk.premium || dk.premiumLoading) return;
    dk.premiumLoading = true;
    Promise.all([window.hub.community.cloud(false).catch(() => []), window.hub.community.status().catch(() => null)]).then(([cloud, local]) => {
      dk.premium = [...(cloud || []).map((x) => ({ name: x.name, img: x.img })), ...((local?.backgrounds || []).filter((x) => x.data).map((x) => ({ name: x.name, img: x.data })))].filter((x) => /^data:image\//.test(x.img || ''));
    }).finally(() => { dk.premiumLoading = false; if (dk.root) dkPaint(); });
  }
  function bgCard() {
    const bg = dk.data.bg;
    return `<div class="rv-card dk-bgcard"><div class="rv-row between"><div><b>🖼️ Hintergrund über alle Tasten</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 0">Ein Bild über das ganze Deck – Tasten mit Symbol und Text liegen darüber. Hintergründe aus der Bibliothek kommen als Standbild aufs Deck (ruckelfrei).</p></div>
      <div class="rv-row"><button class="rv-btn sm ${dk.libOpen ? 'on' : ''}" data-dk-lib>Aus der Bibliothek …</button><button class="rv-btn sm" data-dk-bgpick>${bg?.src ? 'Eigenes Bild …' : 'Bild wählen …'}</button>${bg?.src ? '<button class="rv-btn sm ghost" data-dk-bgdel>Entfernen</button>' : ''}</div></div>
      ${dk.libOpen ? libHtml() : ''}
      ${bg?.src ? `<div class="dk-bgctl"><label>Zoom<input type="range" min="1" max="3" step="0.05" value="${bg.zoom || 1}" data-dk-bg="zoom"/></label><label>Links/Rechts<input type="range" min="-1" max="1" step="0.02" value="${bg.x || 0}" data-dk-bg="x"/></label><label>Oben/Unten<input type="range" min="-1" max="1" step="0.02" value="${bg.y || 0}" data-dk-bg="y"/></label><label>Abdunkeln<input type="range" min="0" max="0.7" step="0.05" value="${bg.dim || 0}" data-dk-bg="dim"/></label></div>` : ''}
    </div>`;
  }

  /* ---------------------------------------------------------------- Aktionen */
  async function runAction(a) {
    if (!a) return;
    try {
      switch (a.type) {
        case 'media': return await window.hub.cc.media(a.key || 'playpause');
        case 'volume': return await window.hub.cc.media(a.key || 'volup');
        case 'program':
          if (!a.appId) return A.toast('Wähle zuerst ein Programm.', 'error');
          return await window.hub.deck.launch(a.appId);
        case 'keys':
          if (!a.combo) return A.toast('Gib zuerst eine Tastenkombination ein.', 'error');
          return await window.hub.deck.keys(a.combo);
        case 'screenshot': return await window.hub.cc.screenshot();
        case 'record': {
          const r = await window.hub.deck.record();
          if (r?.error) A.toast(r.error, 'error');
          else A.toast(r?.active ? '⏺ Aufnahme läuft' : '⏹ Aufnahme gespeichert');
          return r;
        }
        case 'widgets': {
          const s = await window.hub.desktopWidgets.state();
          const on = s?.enabled === false;
          await window.hub.desktopWidgets.set(on);
          return A.toast(on ? 'Widgets eingeblendet' : 'Widgets ausgeblendet');
        }
        case 'agent': {
          // Taste drücken → App nach vorne holen bzw. starten; bei Claude direkt den passenden Chat
          const r = await window.hub.deck.openAgent(a.agent || 'claude');
          if (cl.status?.off || !cl.status) window.hub.claude.enable(true).then((s) => { cl.status = s; ulPush(100); }).catch(() => {});
          return r;
        }
        case 'clock': return A.toast(new Date().toLocaleString('de-CH', { weekday: 'long', hour: '2-digit', minute: '2-digit' }));
        case 'widget': {
          // Widget-Taste drücken → passende Hub-Seite (Wetter, Task-Manager, Weltansicht)
          const to = { weather: 'tool-weather', pc: 'tool-taskman', globe: 'worldview' }[a.kind || 'weather'];
          if (a.kind === 'weather') wdWeather(true);
          return await window.hub.open(to);
        }
        case 'page': {
          const n = dk.data.pages.length;
          dk.page = a.to === 'next' ? (ul.deckPage + 1) % n : a.to === 'prev' ? (ul.deckPage - 1 + n) % n : Math.max(0, Math.min(n - 1, Number(a.to) || 0));
          dk.sel = null;
          ulPush(0);
          if (dk.root) dkPaint();
          return null;
        }
        case 'sound': {
          // 2.45.8: über die Audio-Engine – stummschaltbar und auf Wunsch auch im Mikrofon (Discord)
          const r = await window.hub.sound.play(Number(a.pad) || 0, Number(a.volume ?? 1));
          if (r?.muted) A.toast('Soundboard ist stumm geschaltet.');
          return r;
        }
        case 'soundmute': {
          const s = await window.hub.sound.mute('toggle');
          return A.toast(s?.muted ? 'Soundboard stumm' : 'Soundboard an');
        }
        case 'soundstop': return await window.hub.sound.stop();
        case 'open': return await window.hub.deck.run(a.target);
        case 'app': return await window.hub.open(a.app || 'home');
        case 'crosshair': return await window.hub.crosshair.toggle();
        case 'lock': return await window.hub.cc.lock();
        case 'timer': {
          // 2.45.9: Ring auf der Taste läuft mit; nochmal drücken während er läuft = abbrechen
          const id = a; // je Taste ein Timer (gleiches Aktions-Objekt)
          const total = Math.max(1, Number(a.minutes) || 5) * 60000;
          if (timers.get(id)?.end > Date.now()) { timers.delete(id); ulPush(50); return A.toast('Timer abgebrochen'); }
          timers.set(id, { end: Date.now() + total, total });
          ulPush(50);
          return await window.hub.cc.timerIsland(total / 1000, a.label || 'Timer').catch(() => null);
        }
        case 'micmute': {
          const r = await window.hub.deck.micMute('toggle');
          mic.muted = Boolean(r?.muted);
          mic.at = Date.now();
          ulPush(50);
          if (dk.root) dkPaint();
          return A.toast(mic.muted ? 'Mikrofon stumm' : 'Mikrofon an');
        }
        case 'multi':
          for (const step of a.steps || []) {
            await runAction(step);
            await new Promise((r) => setTimeout(r, Math.max(0, Number(step.after) || 150)));
          }
          return null;
        default: return null;
      }
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    return null;
  }
  // Hardware-Tasten (über die Tastatur-Engine, z. B. Elgato mit F13–F24) lösen Deck-Tasten aus
  window.hub.deck?.onAction?.(async (id) => {
    if (!String(id).startsWith('deck-')) return;
    await dkLoad();
    const bid = String(id).slice(5);
    for (const p of dk.data.pages) for (const b of Object.values(p.buttons)) if (b?.id === bid) return runAction(b.action);
    return null;
  });
  function loadApps() {
    if (dk.apps || dk.appsLoading) return;
    dk.appsLoading = true;
    window.hub.deck.apps().then((list) => { dk.apps = list; if (dk.root) dkPaint(); }).catch(() => { dk.apps = []; }).finally(() => { dk.appsLoading = false; });
  }
  function actionForm(b) {
    const a = b.action || { type: 'none' };
    const sel = (key, opts) => `<select class="rv-input sm" data-dk-act="${key}">${opts.map(([v, n]) => `<option value="${v}" ${String(a[key]) === String(v) ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>`;
    const apps = Object.entries({ ...window.HubTools.TOOLS }).map(([k, v]) => [k, v.title]).concat([['gaming', 'Gaming Hub'], ['chats', 'Chats'], ['docs', 'Dokumente'], ['video', 'Video-Schnitt'], ['chess', 'Schach'], ['geo', 'GeoRevulution'], ['worldview', 'Weltansicht']]);
    switch (a.type) {
      case 'media': return sel('key', [['playpause', 'Play / Pause'], ['next', 'Nächster Titel'], ['prev', 'Vorheriger Titel'], ['stop', 'Stopp'], ['mute', 'Stumm']]);
      case 'volume': return sel('key', [['volup', 'Lauter'], ['voldown', 'Leiser'], ['mute', 'Stumm an/aus']]);
      case 'program':
        loadApps();
        return `<input class="rv-input sm" list="dk-apps" data-dk-program value="${esc(a.name || '')}" placeholder="${dk.apps ? 'Programm suchen …' : 'Programme werden geladen …'}" style="width:100%"/><datalist id="dk-apps">${(dk.apps || []).map((x) => `<option value="${esc(x.name)}"></option>`).join('')}</datalist><small class="rv-muted">${dk.apps ? `${dk.apps.length} installierte Programme` : ''}</small>`;
      case 'keys': return `<input class="rv-input sm" data-dk-act="combo" value="${esc(a.combo || '')}" placeholder="z. B. ^c  ·  ^+{ESC}  ·  %{F4}" style="width:100%"/><small class="rv-muted">^ = Strg, + = Umschalt, % = Alt, {F5} {ENTER} {TAB} {DEL} …</small>`;
      case 'clock': return sel('style', CLOCKS);
      case 'widget': return `${sel('kind', [['weather', 'Wetter (deine Stadt)'], ['pc', 'PC-Leistung (CPU / RAM)'], ['globe', 'Erde mit Satelliten']])}<small class="rv-muted">Aktualisiert sich selbst auf dem Deck. Drücken öffnet ${a.kind === 'pc' ? 'den Task-Manager' : a.kind === 'globe' ? 'die Weltansicht' : 'das Wetter'}.</small>`;
      case 'agent': {
        const o = cl.status?.others || {};
        const info = (k) => (k === 'claude' ? clText(cl.status) : o[k]?.status ? { working: 'arbeitet', question: 'Frage', done: 'fertig', ready: 'bereit', idle: 'bereit', off: 'aus' }[o[k].status] || o[k].status : 'aus');
        return `${sel('agent', [['claude', 'Claude'], ['codex', 'ChatGPT / Codex'], ['freebuff', 'Freebuff']])}<small class="rv-muted">Jetzt: ${esc(info(a.agent || 'claude'))}${(a.agent || 'claude') === 'freebuff' ? ' · erkannt am Freebuff-Agenten (Chat-Speicher + Werkzeuge)' : ''}</small><small class="rv-muted">Drücken öffnet ${(a.agent || 'claude') === 'claude' ? 'Claude direkt im Chat mit Frage bzw. dem zuletzt fertigen Chat' : (a.agent === 'codex' ? 'ChatGPT' : 'Freebuff')} – startet die App, falls sie zu ist.</small>`;
      }
      case 'page': return sel('to', [['next', 'Nächste Seite'], ['prev', 'Vorherige Seite'], ...dk.data.pages.map((p, i) => [i, p.name])]);
      // 2.45.9: 24 Plätze, Standard-Sounds zum Auswählen (z. B. „Oh Hölle nein“), eigener Sound als Datei
      case 'sound': {
        if (!dk.soundDefaults) { dk.soundDefaults = []; window.hub.widgetSound.defaults?.().then((l) => { dk.soundDefaults = l || []; if (dk.root) dkPaint(); }).catch(() => {}); }
        return `<select class="rv-input sm" data-dk-act="pad">${Array.from({ length: 24 }, (_, i) => `<option value="${i}" ${Number(a.pad) === i ? 'selected' : ''}>Platz ${i + 1}${i < 8 ? '' : ' (nur Deck)'}</option>`).join('')}</select>
        <label class="rv-muted">Standard-Sound <select class="rv-input sm" data-dk-defsoundsel><option value="">${dk.soundDefaults.length} Sounds – auswählen …</option>${dk.soundDefaults.map((s) => `<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('')}</select></label>
        <button class="rv-btn sm" data-dk-soundtest>▶ Anhören</button>
        <button class="rv-btn sm" data-dk-pick>Eigene Datei wählen …</button><label class="rv-muted">Lautstärke <input type="range" min="0" max="1" step="0.05" value="${a.volume ?? 1}" data-dk-act="volume"/></label>`;
      }
      case 'open': return `<input class="rv-input sm" data-dk-act="target" value="${esc(a.target || '')}" placeholder="https://… oder C:\\Pfad\\Datei" style="width:100%"/>`;
      case 'app': return sel('app', apps);
      case 'timer': return `<label class="rv-muted">Minuten <input class="rv-input sm" type="number" min="1" max="600" value="${a.minutes || 5}" data-dk-act="minutes" style="width:80px"/></label>`;
      case 'multi': return `<div class="dk-chain">${(a.steps || []).map((s, i) => `<div class="rv-row"><span class="rv-pill">${i + 1}. ${esc(DECK_ACTIONS.find((x) => x[0] === s.type)?.[1] || s.type)}${s.key ? ` · ${esc(s.key)}` : ''}</span><label class="rv-muted">danach <input class="rv-input sm" type="number" min="0" max="10000" step="50" value="${s.after ?? 150}" data-dk-chainafter="${i}" style="width:80px"/> ms</label><button class="rv-btn sm ghost" data-dk-chaindel="${i}">✕</button></div>`).join('')}
      <div class="rv-row"><select class="rv-input sm" data-dk-chainadd><option value="">＋ Schritt hinzufügen …</option>${DECK_ACTIONS.filter(([k]) => !['none', 'multi', 'clock', 'widget', 'page', 'program', 'keys'].includes(k)).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></div></div>`;
      default: return '';
    }
  }

  /* ---------------------------------------------------------------- Oberfläche */
  function dkPaint() {
    if (!dk.root || !dk.data) return;
    const d = dk.data;
    const p = page();
    const b = selBtn();
    const cells = [];
    const ulOn = ctx().state()?.settings?.ulanziDirect === true && d.cols === 5 && d.rows === 3;
    for (let i = 0; i < d.cols * d.rows; i++) {
      // Kleines Display: Vorschau – Klick öffnet die Auswahl (Uhren, Wetter, Erde, PC-Leistung …)
      if (ulOn && i === UL_KEYS) { cells.push(`<button class="dk-key dk-clock dk-small ${dk.smallSel ? 'sel' : ''}" data-dk-small style="grid-column:span 2" title="Kleines Display des D200 – klicken zum Ändern"><img data-dk-smallprev src="${smallImage(smallMode())}" alt="" draggable="false"/></button>`); break; }
      const x = p.buttons[i];
      const showImg = x || d.bg?.src;
      // 2.45.7: belegte Tasten lassen sich auf einen anderen Platz ziehen (tauschen)
      cells.push(`<button class="dk-key ${dk.sel === i ? 'sel' : ''} ${x ? '' : 'empty'} ${showImg ? 'img' : ''}" data-dk-key="${i}" ${x ? 'draggable="true"' : ''} style="--c:${esc(x?.color || '#2c2c34')}">${showImg ? `<img src="${keyImage(x, i)}" alt="" draggable="false"/>` : ''}${x ? (x.hotkey ? `<i class="dk-hk">${esc(x.hotkey)}</i>` : '') : `<span class="dk-plus">＋</span>`}</button>`);
    }
    const t = b?.action?.type;
    dk.root.innerHTML = `<div class="dv dk">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">${esc(deckName())}</h2><p class="rv-sub">${ul.status?.connected ? 'Dein Ulanzi D200 ist verbunden – Änderungen erscheinen sofort auf dem Deck. Rechtsklick auf eine Taste für mehr.' : dev.elgato ? 'Elgato Stream Deck erkannt: Tasten in der Elgato-Software auf „Hotkey“ F13–F24 legen und hier unter „Hardware-Taste“ zuweisen.' : 'Klicken = ausprobieren, rechts einstellen, Rechtsklick für mehr.'}</p></div>
        <div class="rv-row"><div class="rv-tabs">${d.pages.map((pg, i) => `<button class="${i === dk.page ? 'on' : ''}" data-dk-page="${i}">${esc(pg.name)}</button>`).join('')}<button data-dk-addpage title="Neue Seite">＋</button></div>
        <select class="rv-input sm" data-dk-size>${[[3, 2], [5, 3], [8, 4]].map(([c, r]) => `<option value="${c}x${r}" ${d.cols === c && d.rows === r ? 'selected' : ''}>${c} × ${r}</option>`).join('')}</select></div></div></div>
      ${ulCard()}
      <div class="dk-wrap"><div class="dk-left"><div class="dk-grid" style="grid-template-columns:repeat(${d.cols},1fr)">${cells.join('')}</div>${bgCard()}</div>
      <aside class="rv-card dk-side">${dk.smallSel ? `<b>Kleines Display</b><p class="rv-muted" style="margin:4px 0 8px">„Deck“ zeichnet das D200 selbst, „Hub“ schickt der Hub als Bild.</p>
        <div class="dk-smallgrid">${SMALL_MODES.map(([k, n, src]) => `<button class="dk-smallopt ${smallMode() === k ? 'on' : ''}" data-dk-smallmode="${k}"><img src="${smallImage(k)}" alt=""/><span>${esc(n)}${src ? ` <em>${src}</em>` : ''}</span></button>`).join('')}</div>`
        : b ? `<b>Taste ${dk.sel + 1}</b>
        <label>Aktion<select class="rv-input sm" data-dk-type>${DECK_ACTIONS.map(([k, n]) => `<option value="${k}" ${t === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <div class="dk-act">${actionForm(b)}</div>
        ${t === 'clock' || t === 'agent' || t === 'widget' ? '' : `<label>Beschriftung<input class="rv-input sm" data-dk-field="label" value="${esc(b.label || '')}" maxlength="20"/></label>
        <label>Symbol${t === 'program' && b.appIcon ? ' <small class="rv-muted">(Programm-Logo – oder eigenes Symbol wählen)</small>' : ''}<div class="dk-icons"><button class="dk-ico auto ${!String(b.icon || '').startsWith('i:') ? 'on' : ''}" data-dk-icon="auto" title="Passend zur Aktion">Auto</button>${Object.keys(VI).map((n) => `<button class="dk-ico ${b.icon === `i:${n}` ? 'on' : ''}" data-dk-icon="i:${n}" title="${esc(VI_NAMES[n] || n)}">${viSvg(n, 20)}</button>`).join('')}</div></label>`}
        ${t === 'agent' || t === 'widget' ? '' : `<div class="rv-row between"><span>Bild</span><div class="rv-row"><button class="rv-btn sm" data-dk-img>${b.image ? 'Anderes …' : 'Bild wählen …'}</button>${b.image ? '<button class="rv-btn sm ghost" data-dk-imgdel>✕</button>' : ''}</div></div>
        ${b.image ? `<label class="rv-row" style="gap:8px"><input type="checkbox" data-dk-showicon ${b.showIcon ? 'checked' : ''}/> Symbol über dem Bild</label>` : `<label class="rv-row between">Farbe<input type="color" value="${esc(b.color || '#2c2c34')}" data-dk-field="color"/></label>`}`}
        <label>Hardware-Taste<div class="rv-row"><button class="rv-btn sm ${dk.capture ? 'on' : ''}" data-dk-hotkey>${dk.capture ? 'Taste am Deck drücken …' : b.hotkey ? esc(b.hotkey) : 'Zuweisen'}</button>${b.hotkey ? '<button class="rv-btn sm ghost" data-dk-hotkeydel>✕</button>' : ''}</div></label>
        <div class="rv-row"><button class="rv-btn sm primary" data-dk-test>▶ Testen</button><button class="rv-btn sm danger" data-dk-del>Taste löschen</button></div>`
        : '<b>Taste wählen</b><p class="rv-muted">Klicke eine leere Taste (＋), um sie zu belegen. Ein Klick auf eine belegte Taste führt sie aus und öffnet ihre Einstellungen. Rechtsklick: Bild, Kopieren, Einfügen, Duplizieren, Löschen.</p>'}</aside></div>
      ${window.hub.sound ? soundCard() : ''}
      ${claudeCard()}
    </div>`;
  }
  async function hotkeyRule(b, code) {
    const c = kbCfg();
    if (b.hotkey) setRule(c, b.hotkey, null);
    if (code) setRule(c, code, { type: 'hub', to: `deck-${b.id}` });
    b.hotkey = code || '';
    dkSave();
    try {
      await kbSave(c, Boolean(code) || c.enabled);
    } catch (e) {
      A.toast(A.errText(e), 'error');
    }
    dkPaint();
  }
  async function deleteKey(i) {
    const b = page().buttons[i];
    if (!b) return;
    if (b.hotkey) await hotkeyRule(b, '');
    delete page().buttons[i];
    if (dk.sel === i) dk.sel = null;
    dkSave();
    dkPaint();
  }

  // Rechtsklick-Menü auf einer Taste
  let menuEl = null;
  const closeMenu = () => { menuEl?.remove(); menuEl = null; };
  document.addEventListener('contextmenu', (e) => {
    const key = e.target.closest?.('[data-dk-key]');
    if (!key || !dk.root?.contains(key)) return;
    e.preventDefault();
    closeMenu();
    const i = Number(key.dataset.dkKey);
    const b = page().buttons[i];
    const items = b
      ? [['edit', '✏️ Bearbeiten'], ['run', '▶ Ausführen'], ['img', '🖼️ Bild wählen …'], ...(b.image ? [['imgdel', '🧹 Bild entfernen']] : []), ['copy', '📋 Kopieren'], ...(dk.clip ? [['paste', '📥 Einfügen (ersetzen)']] : []), ['dup', '🧬 Duplizieren'], ['del', '🗑️ Löschen']]
      : [['new', '＋ Neue Taste'], ...(dk.clip ? [['paste', '📥 Einfügen']] : [])];
    menuEl = document.createElement('div');
    menuEl.className = 'dk-menu';
    menuEl.innerHTML = items.map(([k, n]) => `<button data-dkm="${k}" class="${k === 'del' ? 'danger' : ''}">${n}</button>`).join('');
    document.body.appendChild(menuEl);
    const r = menuEl.getBoundingClientRect();
    menuEl.style.left = `${Math.min(e.clientX, innerWidth - r.width - 8)}px`;
    menuEl.style.top = `${Math.min(e.clientY, innerHeight - r.height - 8)}px`;
    menuEl.onclick = async (ev) => {
      const a = ev.target.closest('[data-dkm]')?.dataset.dkm;
      if (!a) return;
      closeMenu();
      const btns = page().buttons;
      if (a === 'edit' || a === 'new') { if (!btns[i]) btns[i] = { id: newId(), label: 'Neu', color: '#5e5ce6', action: { type: 'none' } }; dk.sel = i; dkSave(); return dkPaint(); }
      if (a === 'run') return runAction(btns[i]?.action);
      if (a === 'img') { const src = await pickImage(S, true); if (src) { btns[i].image = src; dkSave(); dkPaint(); } return; }
      if (a === 'imgdel') { delete btns[i].image; dkSave(); return dkPaint(); }
      if (a === 'copy') { dk.clip = JSON.parse(JSON.stringify(btns[i])); return A.toast('Taste kopiert.'); }
      if (a === 'paste') { btns[i] = { ...JSON.parse(JSON.stringify(dk.clip)), id: newId(), hotkey: '' }; dk.sel = i; dkSave(); return dkPaint(); }
      if (a === 'dup') {
        const max = dk.data.cols * dk.data.rows;
        let free = -1;
        for (let k = 0; k < max; k++) if (!btns[k] && !(ctx().state()?.settings?.ulanziDirect && k >= UL_KEYS)) { free = k; break; }
        if (free < 0) return A.toast('Keine freie Taste auf dieser Seite.', 'error');
        btns[free] = { ...JSON.parse(JSON.stringify(btns[i])), id: newId(), hotkey: '' };
        dk.sel = free; dkSave(); return dkPaint();
      }
      if (a === 'del') return deleteKey(i);
    };
  });
  // 2.45.7 Tasten verschieben: belegte Taste auf einen anderen Platz ziehen – leerer Platz = verschieben, belegter = tauschen
  const keyOf = (el) => { const k = el?.closest?.('[data-dk-key]'); return k && dk.root?.contains(k) ? k : null; };
  document.addEventListener('dragstart', (e) => {
    const k = keyOf(e.target);
    if (!k) return;
    dk.drag = Number(k.dataset.dkKey);
    closeMenu();
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', String(dk.drag));
    k.classList.add('dragging');
  });
  document.addEventListener('dragover', (e) => {
    const k = keyOf(e.target);
    if (!k || dk.drag == null) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    dk.root.querySelectorAll('.dk-key.drop').forEach((x) => x !== k && x.classList.remove('drop'));
    if (Number(k.dataset.dkKey) !== dk.drag) k.classList.add('drop');
  });
  document.addEventListener('dragleave', (e) => { const k = keyOf(e.target); if (k && !k.contains(e.relatedTarget)) k.classList.remove('drop'); });
  document.addEventListener('dragend', () => {
    dk.drag = null;
    dk.root?.querySelectorAll('.dk-key.drop, .dk-key.dragging').forEach((x) => x.classList.remove('drop', 'dragging'));
  });
  document.addEventListener('drop', (e) => {
    const k = keyOf(e.target);
    if (!k || dk.drag == null) return;
    e.preventDefault();
    const from = dk.drag, to = Number(k.dataset.dkKey);
    dk.drag = null;
    if (from === to) return dkPaint();
    const btns = page().buttons;
    const a = btns[from], b = btns[to];
    if (b) btns[from] = b; else delete btns[from];
    btns[to] = a;
    dk.sel = to;
    dkSave();
    dkPaint();
  });
  document.addEventListener('pointerdown', (e) => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); }, true);
  window.addEventListener('blur', closeMenu);

  document.addEventListener('click', async (e) => {
    if (!dk.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    if (q('[data-vm-install]')) return vmicDo('install');
    if (q('[data-vm-rename]')) return vmicDo('rename');
    if (q('[data-vm-route]')) return vmicDo('route');
    const vd = q('[data-vm-default]');
    if (vd) {
      vm.busy = 'default';
      window.hub.vmic.setDefault(vd.checked).then((r) => { vm.st = { ...vm.st, ...r }; A.toast(vd.checked ? 'Revolution Mic ist jetzt dein Windows-Mikrofon.' : 'Dein altes Mikrofon ist wieder Standard.'); })
        .catch((err) => { vd.checked = !vd.checked; A.toast(A.errText(err), 'error'); }).finally(() => { vm.busy = ''; dkPaint(); });
      return;
    }
    if (q('[data-dk-small]')) { dk.smallSel = !dk.smallSel; dk.sel = null; if (dk.smallSel) { wdStats(); wdWeather(); } return dkPaint(); }
    const smode = q('[data-dk-smallmode]')?.dataset.dkSmallmode;
    if (smode) {
      dk.data.ulanziSmall = smode;
      A.store.set('streamdeck', dk.data);
      applySmall();
      return dkPaint();
    }
    const key = q('[data-dk-key]')?.dataset.dkKey;
    if (key != null) {
      dk.smallSel = false;
      const i = Number(key);
      if (!page().buttons[i]) page().buttons[i] = { id: newId(), label: 'Neu', color: '#5e5ce6', action: { type: 'none' } };
      else runAction(page().buttons[i].action);
      const el = q('[data-dk-key]');
      el.classList.remove('press');
      void el.offsetWidth;
      el.classList.add('press');
      dk.sel = i;
      dkSave();
      return setTimeout(dkPaint, 120);
    }
    if (q('[data-ul-push]')) return ulPush(0);
    if (q('[data-dk-bgpick]')) {
      const src = await pickImage(1400, false);
      if (src) { dk.data.bg = { src, zoom: 1, x: 0, y: 0, dim: 0.15 }; dkSave(); dkPaint(); }
      return;
    }
    if (q('[data-dk-bgdel]')) { delete dk.data.bg; dkSave(); return dkPaint(); }
    if (q('[data-dk-lib]')) { dk.libOpen = !dk.libOpen; if (dk.libOpen) loadPremium(); return dkPaint(); }
    const liveId = q('[data-dk-live]')?.dataset.dkLive;
    if (liveId) {
      try {
        // Standbild aus dem Live-Hintergrund (erstes Bild des Videos) – nicht animiert, damit nichts ruckelt
        const src = await window.hub.ulanzi.liveThumb(liveId);
        dk.data.bg = { kind: 'image', from: liveId, src, zoom: 1, x: 0, y: 0, dim: 0.15 };
        dkSave();
        dkPaint();
      } catch (err) { A.toast(A.errText(err), 'error'); }
      return;
    }
    const premI = q('[data-dk-prem]')?.dataset.dkPrem;
    if (premI != null) {
      if (!window.RevStore?.pro?.()) { A.toast('Premium-Hintergründe gibt es mit Pro.', 'error'); return window.RevStore?.open?.('pro'); }
      const it = dk.premium?.[Number(premI)];
      if (it) { dk.data.bg = { kind: 'image', src: it.img, zoom: 1, x: 0, y: 0, dim: 0.15 }; dkSave(); dkPaint(); }
      return;
    }
    const pg = q('[data-dk-page]')?.dataset.dkPage;
    if (pg != null) {
      dk.page = Number(pg);
      dk.sel = null;
      ulPush(0);
      return dkPaint();
    }
    if (q('[data-dk-addpage]')) {
      dk.data.pages.push({ name: `Seite ${dk.data.pages.length + 1}`, buttons: {} });
      dk.page = dk.data.pages.length - 1;
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    const ic = q('[data-dk-icon]')?.dataset.dkIcon;
    if (ic) { if (ic === 'auto') delete b.icon; else b.icon = ic; dkSave(); return dkPaint(); }
    if (q('[data-dk-img]')) { const src = await pickImage(S, true); if (src) { b.image = src; dkSave(); dkPaint(); } return; }
    if (q('[data-dk-imgdel]')) { delete b.image; dkSave(); return dkPaint(); }
    if (q('[data-dk-test]')) return runAction(b.action);
    if (q('[data-dk-del]')) return deleteKey(dk.sel);
    if (q('[data-dk-soundtest]')) return window.hub.sound?.play(Number(b.action.pad) || 0, Number(b.action.volume ?? 1)).catch(() => {});
    const defSound = q('[data-dk-defsound]')?.dataset.dkDefsound;
    if (defSound) return applyDefSound(b, defSound);
    if (q('[data-dk-pick]')) {
      const pad = Number(b.action.pad) || 0;
      const name = await window.hub.widgetSound.pick(pad).catch((err) => A.toast(A.errText(err), 'error'));
      if (name) {
        b.label = String(name).replace(/\.[^.]+$/, '').slice(0, 20);
        dkSave();
        dkPaint();
        A.toast(`„${name}“ liegt jetzt auf Platz ${pad + 1} – auch im Soundboard-Widget.`);
      }
      return;
    }
    if (q('[data-dk-hotkey]')) { dk.capture = !dk.capture; return dkPaint(); }
    if (q('[data-dk-hotkeydel]')) return hotkeyRule(b, '');
    const cd = q('[data-dk-chaindel]')?.dataset.dkChaindel;
    if (cd != null) { b.action.steps.splice(Number(cd), 1); dkSave(); return dkPaint(); }
  });
  // Standard-Sound auf den Platz der Taste legen, Namen übernehmen und kurz vorspielen
  async function applyDefSound(b, defSound) {
    const pad = Number(b.action.pad) || 0;
    try {
      const name = await window.hub.widgetSound.useDefault(pad, defSound);
      b.label = String(name).slice(0, 20);
      dkSave();
      dkPaint();
      window.hub.sound?.play(pad, Number(b.action.volume ?? 1)).catch(() => {});
      A.toast(`„${name}“ liegt jetzt auf Platz ${pad + 1}.`);
    } catch (err) { A.toast(A.errText(err), 'error'); }
  }
  // Hintergrund-Regler live (ohne die ganze Seite neu zu bauen)
  document.addEventListener('input', (e) => {
    if (!dk.root?.contains(e.target) || !e.target.matches('[data-dk-bg]') || !dk.data.bg) return;
    dk.data.bg[e.target.dataset.dkBg] = Number(e.target.value);
    dk.root.querySelectorAll('[data-dk-key] img').forEach((im) => { const i = Number(im.closest('[data-dk-key]').dataset.dkKey); im.src = keyImage(page().buttons[i], i); });
    ulPush(350);
    clearTimeout(dk.bgSaveT);
    dk.bgSaveT = setTimeout(() => A.store.set('streamdeck', dk.data), 500);
  });
  document.addEventListener('change', (e) => {
    if (!dk.root?.contains(e.target)) return;
    const t = e.target;
    if (t.matches('[data-dk-bg]')) return;
    if (t.matches('[data-ul-on]')) {
      return window.hub.ulanzi.enable(t.checked).then((s) => {
        ul.status = s;
        if (t.checked && (dk.data.cols !== 5 || dk.data.rows !== 3)) Object.assign(dk.data, { cols: 5, rows: 3 });
        if (ctx().state()?.settings) ctx().state().settings.ulanziDirect = t.checked;
        dkSave();
        dkPaint();
      }).catch((err) => A.toast(A.errText(err), 'error'));
    }
    if (t.matches('[data-cl-on]')) {
      return window.hub.claude.enable(t.checked).then((s) => {
        cl.status = s;
        if (ctx().state()?.settings) ctx().state().settings.claudeLink = t.checked;
        ulPush(100);
        dkPaint();
      }).catch((err) => A.toast(A.errText(err), 'error'));
    }
    // 2.45.8 Soundboard & Mikrofon
    if (t.matches('[data-snd-mute]')) {
      return window.hub.sound.mute(t.checked).then((s) => { snd.st = { ...(snd.st || {}), ...s, muted: t.checked }; ulPush(100); dkPaint(); }).catch((err) => A.toast(A.errText(err), 'error'));
    }
    if (t.matches('[data-snd-on], [data-snd-mix]')) {
      const patch = t.matches('[data-snd-on]') ? { on: t.checked } : { [t.dataset.sndMix]: t.type === 'checkbox' ? t.checked : t.type === 'range' ? Number(t.value) : t.value };
      if (patch.on) loadSoundDevices();
      snd.st = { ...(snd.st || {}), mix: { ...(snd.st?.mix || {}), ...patch } };
      return window.hub.sound.mix(patch).then((s) => { snd.st = { ...snd.st, ...s }; dkPaint(); }).catch((err) => { A.toast(A.errText(err), 'error'); dkPaint(); });
    }
    if (t.matches('[data-ul-small]')) {
      dk.data.ulanziSmall = t.value;
      A.store.set('streamdeck', dk.data);
      applySmall();
      return dkPaint();
    }
    if (t.matches('[data-ul-bright]')) {
      dk.data.ulanziBrightness = Number(t.value);
      A.store.set('streamdeck', dk.data);
      return window.hub.ulanzi.brightness(Number(t.value)).catch(() => {});
    }
    if (t.matches('[data-dk-size]')) {
      const [c, r] = t.value.split('x').map(Number);
      Object.assign(dk.data, { cols: c, rows: r });
      dkSave();
      return dkPaint();
    }
    const b = selBtn();
    if (!b) return;
    if (t.matches('[data-dk-defsoundsel]')) { if (t.value) applyDefSound(b, t.value); return; }
    if (t.matches('[data-dk-showicon]')) b.showIcon = t.checked;
    else if (t.matches('[data-dk-program]')) {
      const app = (dk.apps || []).find((x) => x.name === t.value) || (dk.apps || []).find((x) => x.name.toLowerCase() === t.value.trim().toLowerCase());
      if (!app) { A.toast('Programm nicht gefunden – wähle einen Eintrag aus der Liste.', 'error'); return; }
      b.action.appId = app.id; b.action.name = app.name;
      if (!b.label || b.label === 'Neu') b.label = app.name.slice(0, 20);
      delete b.appIcon;
      fetchAppIcon(b); // echtes Logo des Programms
    } else if (t.dataset.dkField) b[t.dataset.dkField] = t.value;
    else if (t.matches('[data-dk-type]')) {
      b.action = { type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'volume' ? { key: 'volup' } : t.value === 'sound' ? { pad: 0, volume: 1 } : t.value === 'multi' ? { steps: [] } : t.value === 'clock' ? { style: 'digital' } : t.value === 'widget' ? { kind: 'weather' } : t.value === 'page' ? { to: 'next' } : {}) };
      if (t.value !== 'program') delete b.appIcon;
      if (t.value === 'widget') wdWeather();
      if (t.value === 'agent') b.action.agent = 'claude';
      // Agenten-Tasten brauchen die (lokale) Verbindung zu den KI-Apps
      if (t.value === 'agent' && ctx().state()?.settings?.claudeLink !== true) {
        window.hub.claude.enable(true).then((s) => { cl.status = s; if (ctx().state()?.settings) ctx().state().settings.claudeLink = true; dkPaint(); ulPush(100); }).catch(() => {});
      }
      if (t.value === 'program') loadApps();
      // 2.45.9: neue Sound-Taste = neuer, freier Platz (überschreibt keinen Sound einer anderen Taste)
      if (t.value === 'sound') {
        const used = new Set();
        for (const pg of dk.data.pages) for (const x of Object.values(pg.buttons || {})) if (x !== b && x?.action?.type === 'sound') used.add(Number(x.action.pad) || 0);
        let free = 0;
        while (used.has(free) && free < 23) free++;
        b.action.pad = free;
      }
      if (t.value === 'micmute') refreshMic(true);
    } else if (t.dataset.dkAct) b.action[t.dataset.dkAct] = t.type === 'range' || t.type === 'number' || t.dataset.dkAct === 'pad' ? Number(t.value) : t.value;
    else if (t.matches('[data-dk-chainadd]') && t.value) b.action.steps.push({ type: t.value, ...(t.value === 'media' ? { key: 'playpause' } : t.value === 'volume' ? { key: 'volup' } : t.value === 'sound' ? { pad: 0 } : {}), after: 150 });
    else if (t.dataset.dkChainafter != null) b.action.steps[Number(t.dataset.dkChainafter)].after = Number(t.value) || 0;
    dkSave();
    dkPaint();
  });
  document.addEventListener('keydown', (e) => {
    if (!dk.capture || !dk.root || !document.contains(dk.root)) return;
    e.preventDefault();
    e.stopPropagation();
    dk.capture = false;
    const b = selBtn();
    if (!b) return dkPaint();
    if (['Escape'].includes(e.code)) return dkPaint();
    if (!/^F(1[3-9]|2[0-4])$/.test(e.code) && !window.confirm(`„${e.code}“ ist eine normale Taste – sie würde dann überall nur noch diese Deck-Aktion auslösen. Trotzdem verwenden?`)) return dkPaint();
    hotkeyRule(b, e.code);
  }, true);
  // Beim Start des Hubs: Deck-Daten laden, damit Deck-Tasten auch ohne geöffnetes Studio funktionieren
  dkLoad();
  A.define('tool-streamdeck', { nav: 'Deck Studio', title: 'Deck Studio', sub: 'Stream Deck & Ulanzi: Tasten für alles', icon: 'grid', tint: 'linear-gradient(135deg,#818cf8,#312e81)', desc: 'Dein Stream Deck oder Ulanzi-Deck im Hub: Programme, Medien, Lautstärke, Tastenkombinationen, Uhren, Claude-Status, Aufnahme, Widgets, Bilder und ein Hintergrund über alle Tasten.' }, {
    async mount(root) {
      dk.root = root;
      applyDeckName();
      detectDecks();
      root.innerHTML = '<div class="rv-empty">Lädt …</div>';
      await dkLoad();
      if (dk.root === root) dkPaint();
    },
    unmount() {
      dk.root = null;
      dk.capture = false;
      closeMenu();
    },
  });


  /* ================================================================ Clips (eigene App, Engine im Gaming Hub) */
  window.HubTools.register('tool-clips', { nav: 'Clips', title: 'Clips', sub: 'Aufnehmen, Highlights, Facecam', icon: 'camera', tint: 'linear-gradient(135deg,#fb7185,#9f1239)', desc: 'Der Clipper: läuft im Hintergrund, speichert die letzten Sekunden per Hotkey, nimmt lange Aufnahmen auf, mit Facecam, Ton und Keystrokes – und alle Clips zum Ansehen und Schneiden.' }, () => '<div class="page"><div class="empty">Clips wird geöffnet …</div></div>');

  /* ================================================================ Lüfter – wie Fan Control (2.45.3)
     Alle Lüfter-Anschlüsse (Mainboard + Grafikkarte) mit drehendem Lüfter in echter Drehzahl,
     je Anschluss: Auto (BIOS) · Fest (%) · Kurve (Temperatur → %). Der Helfer RevFans.exe
     (Administrator, PawnIO-Treiber) liest und steuert; Kurven laufen dort auch bei geschlossenem Hub-Fenster.
     Windows-Kühlrichtlinie bleibt unten als Zusatz. */
  const fn = { root: null, st: null, timer: 0, busy: false, ctl: null, snap: null, cfg: { controls: {} }, saveT: 0, curveDrag: null, starting: false, err: '' };
  const DEF_CURVE = [[30, 25], [50, 40], [65, 60], [75, 80], [85, 100]];
  function fnPorts() {
    const ports = [];
    for (const h of fn.snap?.hardware || []) {
      for (const s of h.sensors) {
        if (s.type !== 'Control') continue;
        const fan = h.sensors.find((x) => x.type === 'Fan' && x.id === s.id.replace('/control/', '/fan/'));
        ports.push({ id: s.id, name: s.name, hw: h.name, hwType: h.type, pct: s.value, rpm: fan?.value ?? null, control: s.control });
      }
    }
    return ports;
  }
  const fnTemps = () => (fn.snap?.hardware || []).flatMap((h) => h.sensors.filter((s) => s.type === 'Temperature' && Number.isFinite(s.value) && s.value > 0).map((s) => ({ ...s, hw: h.name })));
  const fanSvg = (rpm) => {
    const dur = rpm > 0 ? Math.max(0.12, Math.min(3, 900 / rpm)) : 0;
    return `<svg class="fc-fan ${dur ? 'spin' : ''}" style="--dur:${dur}s" viewBox="0 0 48 48"><circle cx="24" cy="24" r="22" class="fc-ring"/>${[0, 72, 144, 216, 288].map((a) => `<path transform="rotate(${a} 24 24)" d="M24 24c-2-6-1-13 5-16 5 2 4 9 0 13-1.6 1.6-3.4 2.6-5 3z" class="fc-blade"/>`).join('')}<circle cx="24" cy="24" r="4.2" class="fc-hub"/></svg>`;
  };
  function curveSvg(id, points, temp) {
    const W = 300, H = 140, x = (t) => ((t - 20) / 80) * W, y = (p) => H - (p / 100) * H;
    const path = points.map((p, i) => `${i ? 'L' : 'M'}${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join(' ');
    const cur = Number.isFinite(temp) ? `<line x1="${x(temp)}" x2="${x(temp)}" y1="0" y2="${H}" class="fc-now"/>` : '';
    const grid = [40, 60, 80].map((t) => `<line x1="${x(t)}" x2="${x(t)}" y1="0" y2="${H}" class="fc-grid"/><text x="${x(t) + 3}" y="${H - 4}" class="fc-ax">${t}°</text>`).join('') + [25, 50, 75].map((p) => `<line x1="0" x2="${W}" y1="${y(p)}" y2="${y(p)}" class="fc-grid"/><text x="3" y="${y(p) - 3}" class="fc-ax">${p}%</text>`).join('');
    return `<svg class="fc-curve" viewBox="0 0 ${W} ${H}" data-fc-curve="${esc(id)}">${grid}${cur}<path d="${path} L${W},${y(points[points.length - 1][1])}" class="fc-line"/>${points.map((p, i) => `<circle cx="${x(p[0])}" cy="${y(p[1])}" r="7" class="fc-pt" data-fc-pt="${i}"/>`).join('')}</svg>`;
  }
  function fnPaint() {
    if (!fn.root) return;
    const s = fn.st;
    const pol = s?.policy?.ac === 'unknown' && fn.chosen ? fn.chosen : s?.policy?.ac;
    const ctl = fn.ctl;
    const ports = fnPorts();
    const temps = fnTemps();
    const tempOpts = (sel) => temps.map((t) => `<option value="${esc(t.id)}" ${t.id === sel ? 'selected' : ''}>${esc(t.hw)} · ${esc(t.name)} (${Math.round(t.value)}°)</option>`).join('');
    const defaultTemp = (temps.find((t) => /Tctl|Package|CPU/i.test(t.name) && /cpu/i.test(t.id)) || temps[0])?.id;
    let main;
    if (!ctl) main = '<div class="rv-card"><p class="rv-muted">Prüfe Lüftersteuerung …</p></div>';
    else if (!ctl.helper) main = '<div class="rv-card"><b>Lüftersteuerung nicht verfügbar</b><p class="rv-muted">Der Lüfter-Helfer fehlt in dieser Installation – bitte den Hub aktualisieren.</p></div>';
    else if (!ctl.pawnio) main = `<div class="rv-card fc-start"><div><b>Mainboard-Treiber installieren</b><p class="rv-muted">Für die Lüfter braucht Windows den Treiber „PawnIO“ (derselbe wie bei Fan Control, Open Source, signiert). Der Hub lädt den offiziellen Installer, prüft die Signatur und installiert ihn – Windows fragt dabei nach Administratorrechten.</p>${fn.err ? `<p class="fc-err">${esc(fn.err)}</p>` : ''}</div><button class="rv-btn primary" data-fc-driver ${fn.starting ? 'disabled' : ''}>${fn.starting ? 'Installiert …' : 'Treiber installieren'}</button></div>`;
    else if (!fn.snap) main = `<div class="rv-card fc-start"><div><b>Lüftersteuerung starten</b><p class="rv-muted">Wie Fan Control: alle Lüfter sehen und jeden Anschluss einzeln steuern. Windows fragt einmal nach Administratorrechten – die braucht der Zugriff aufs Mainboard.</p>${fn.err ? `<p class="fc-err">${esc(fn.err)}</p>` : ''}</div><button class="rv-btn primary" data-fc-start ${fn.starting ? 'disabled' : ''}>${fn.starting ? 'Startet …' : 'Starten'}</button></div>`;
    else {
      main = `<div class="fc-grid">${ports.map((p) => {
        const c = fn.cfg.controls[p.id] || { mode: 'auto' };
        const temp = c.sensor ? temps.find((t) => t.id === c.sensor)?.value : null;
        return `<div class="fc-card ${c.mode !== 'auto' ? 'manual' : ''}" data-fc-port="${esc(p.id)}">
          <div class="fc-head">${fanSvg(p.rpm)}<div class="fc-names"><b>${esc(p.name)}</b><small>${esc(p.hw)}</small></div></div>
          <div class="fc-vals"><div><small>Drehzahl</small><b>${p.rpm == null ? '–' : `${Math.round(p.rpm)}`}<i>U/min</i></b></div><div><small>Leistung</small><b>${p.pct == null ? '–' : Math.round(p.pct)}<i>%</i></b></div></div>
          <div class="fc-modes">${[['auto', 'Auto'], ['fixed', 'Fest'], ['curve', 'Kurve']].map(([m, n]) => `<button class="${c.mode === m ? 'on' : ''}" data-fc-mode="${m}">${n}</button>`).join('')}</div>
          ${c.mode === 'fixed' ? `<label class="fc-fixed"><input type="range" min="0" max="100" step="1" value="${c.value ?? 50}" data-fc-value/><b>${c.value ?? 50} %</b></label>` : ''}
          ${c.mode === 'curve' ? `<select class="rv-input sm fc-sensor" data-fc-sensor>${tempOpts(c.sensor || defaultTemp)}</select>${curveSvg(p.id, c.points || DEF_CURVE, temp)}<small class="rv-muted">Punkte ziehen · x = Temperatur, y = Lüfter-%</small>` : ''}
          ${c.mode === 'auto' ? '<small class="rv-muted">Steuert das Mainboard (BIOS-Kurve).</small>' : ''}
        </div>`;
      }).join('')}</div>
      <div class="rv-card"><b>Temperaturen</b><div class="fc-temps">${temps.map((t) => `<div><span>${esc(t.name)}<small>${esc(t.hw)}</small></span><b class="${t.value >= 80 ? 'hot' : t.value >= 65 ? 'warm' : ''}">${t.value.toFixed(1)}°C</b></div>`).join('')}</div></div>`;
    }
    fn.root.innerHTML = `<div class="dv">
      <div class="rv-card"><div class="rv-row between"><div><h2 class="rv-h">Lüfter</h2><p class="rv-sub">Alle Lüfter und Anschlüsse – wie Fan Control, direkt im Hub.</p></div><div class="rv-row">${fn.snap ? `<span class="rv-pill ok">● Steuerung aktiv · ${esc(fn.snap.at || '')}</span><button class="rv-btn sm" data-fc-stop title="Alle Lüfter zurück auf Automatik und Helfer beenden">Beenden</button>` : ''}</div></div>${fn.snap?.error ? `<p class="fc-err">${esc(fn.snap.error)}</p>` : ''}</div>
      ${main}
      <div class="rv-card"><b>Windows-Kühlrichtlinie</b><p class="rv-muted" style="font-size:12.5px;margin:4px 0 10px">Aktiv: Lüfter drehen zuerst hoch (kühler, lauter). Passiv: erst wird die CPU gedrosselt (leiser).</p>
        <div class="rv-tabs"><button class="${pol === 'active' ? 'on' : ''}" data-fn-pol="active">❄️ Aktiv – kühl</button><button class="${pol === 'passive' ? 'on' : ''}" data-fn-pol="passive">🤫 Passiv – leise</button></div></div>
    </div>`;
  }
  function fnSave() {
    clearTimeout(fn.saveT);
    fn.saveT = setTimeout(async () => {
      try {
        fn.snap = await window.hub.fanctl.config(fn.cfg);
      } catch (e) {
        A.toast(A.errText(e), 'error');
      }
      fnPaint();
    }, 250);
  }
  async function fnLoad() {
    if (fn.busy || fn.curveDrag) return;
    fn.busy = true;
    try {
      fn.ctl = await window.hub.fanctl.status();
      if (fn.ctl.running) {
        fn.snap = await window.hub.fanctl.list();
        if (fn.snap?.config?.controls && !fn.cfgLoaded) { fn.cfg = { controls: { ...fn.snap.config.controls } }; fn.cfgLoaded = true; }
      } else fn.snap = null;
      if (!fn.st || Date.now() - (fn.stAt || 0) > 15000) { fn.st = await window.hub.fans.state(); fn.stAt = Date.now(); }
    } catch (e) {
      fn.err = A.errText(e);
    }
    fn.busy = false;
    if (!fn.root?.querySelector('select:focus, input[type=range]:active')) fnPaint();
  }
  const portCfg = (id) => (fn.cfg.controls[id] ||= { mode: 'auto' });
  document.addEventListener('click', async (e) => {
    if (!fn.root?.contains(e.target)) return;
    const pol = e.target.closest('[data-fn-pol]')?.dataset.fnPol;
    if (pol) {
      try {
        fn.st.policy = await window.hub.fans.policy(pol);
        fn.chosen = pol;
        A.toast(pol === 'active' ? 'Kühlung: aktiv (Lüfter zuerst).' : 'Kühlung: passiv (leiser).');
      } catch (err) { A.toast(A.errText(err), 'error'); }
      return fnPaint();
    }
    if (e.target.closest('[data-fc-start]')) {
      fn.starting = true; fn.err = ''; fnPaint();
      try {
        fn.snap = await window.hub.fanctl.start();
        fn.cfg = { controls: { ...(fn.snap?.config?.controls || {}) } };
        fn.cfgLoaded = true;
        fn.ctl = await window.hub.fanctl.status();
      } catch (err) { fn.err = A.errText(err); }
      fn.starting = false;
      return fnPaint();
    }
    if (e.target.closest('[data-fc-driver]')) {
      fn.starting = true; fn.err = ''; fnPaint();
      try {
        const r = await window.hub.fanctl.installDriver();
        if (!r?.ok) fn.err = 'Der Treiber wurde nicht installiert.';
        fn.ctl = await window.hub.fanctl.status();
      } catch (err) { fn.err = A.errText(err); }
      fn.starting = false;
      return fnPaint();
    }
    if (e.target.closest('[data-fc-stop]')) {
      await window.hub.fanctl.stop().catch(() => {});
      fn.snap = null; fn.cfgLoaded = false;
      A.toast('Lüfter laufen wieder automatisch (BIOS).');
      return fnPaint();
    }
    const mode = e.target.closest('[data-fc-mode]')?.dataset.fcMode;
    if (mode) {
      const id = e.target.closest('[data-fc-port]').dataset.fcPort;
      const c = portCfg(id);
      c.mode = mode;
      if (mode === 'fixed' && c.value == null) c.value = Math.round(fnPorts().find((p) => p.id === id)?.pct ?? 50);
      if (mode === 'curve') { c.points ||= DEF_CURVE.map((p) => [...p]); c.sensor ||= (fnTemps().find((t) => /Tctl|Package|CPU/i.test(t.name) && /cpu/i.test(t.id)) || fnTemps()[0])?.id; }
      fnPaint();
      return fnSave();
    }
  });
  document.addEventListener('input', (e) => {
    if (!fn.root?.contains(e.target) || !e.target.matches('[data-fc-value]')) return;
    const id = e.target.closest('[data-fc-port]').dataset.fcPort;
    portCfg(id).value = Number(e.target.value);
    e.target.nextElementSibling.textContent = `${e.target.value} %`;
    fnSave();
  });
  document.addEventListener('change', (e) => {
    if (!fn.root?.contains(e.target) || !e.target.matches('[data-fc-sensor]')) return;
    portCfg(e.target.closest('[data-fc-port]').dataset.fcPort).sensor = e.target.value;
    fnSave();
  });
  // Kurvenpunkte ziehen
  document.addEventListener('pointerdown', (e) => {
    const pt = e.target.closest?.('[data-fc-pt]');
    if (!pt || !fn.root?.contains(pt)) return;
    const svg = pt.closest('[data-fc-curve]');
    fn.curveDrag = { id: svg.dataset.fcCurve, i: Number(pt.dataset.fcPt), svg };
    e.preventDefault();
  });
  window.addEventListener('pointermove', (e) => {
    const d = fn.curveDrag;
    if (!d) return;
    const r = d.svg.getBoundingClientRect();
    const t = Math.round(20 + ((e.clientX - r.left) / r.width) * 80);
    const p = Math.round(100 - ((e.clientY - r.top) / r.height) * 100);
    const pts = portCfg(d.id).points;
    const lo = d.i > 0 ? pts[d.i - 1][0] + 1 : 20, hi = d.i < pts.length - 1 ? pts[d.i + 1][0] - 1 : 100;
    pts[d.i] = [Math.max(lo, Math.min(hi, t)), Math.max(0, Math.min(100, p))];
    const temp = fnTemps().find((x) => x.id === portCfg(d.id).sensor)?.value;
    d.svg.outerHTML = curveSvg(d.id, pts, temp);
    d.svg = fn.root.querySelector(`[data-fc-curve="${CSS.escape(d.id)}"]`);
  });
  window.addEventListener('pointerup', () => {
    if (!fn.curveDrag) return;
    fn.curveDrag = null;
    fnSave();
  });
  A.define('tool-fans', { nav: 'Lüfter', title: 'Lüfter', sub: 'Alle Lüfter steuern – wie Fan Control', icon: 'refresh', tint: 'linear-gradient(135deg,#67e8f9,#0e7490)', desc: 'Alle Lüfter mit Drehzahl, jeden Anschluss einzeln steuern: Automatik, fester Wert oder Kurve nach Temperatur – direkt im Hub, ohne Fan Control.' }, {
    mount(root) {
      fn.root = root;
      fnPaint();
      fnLoad();
      clearInterval(fn.timer);
      fn.timer = setInterval(fnLoad, 2000);
    },
    unmount() {
      clearInterval(fn.timer);
      fn.root = null;
    },
  });
})();
