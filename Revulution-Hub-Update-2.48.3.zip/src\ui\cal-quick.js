'use strict';
/*
 * 2.46 Kalender im Apple-Stil – gemeinsam für das Startseiten-Widget und das Desktop-Widget.
 *   RevCal.dots(colors)   Punkte unter einer Tageszahl; mehrere Termine = mehrere Punkte mit weichem Farbübergang
 *   RevCal.month(...)     Monatsraster mit Punkten
 *   RevCal.open(anchor)   Quick-Add-Popover (+): Titel, Tag, Uhrzeit/ganztägig, Dauer, Farbe → Agenda
 */
(() => {
  const COLORS = ['#FF5D6C', '#FF9F0A', '#FFD60A', '#3DDC97', '#38BDF8', '#7C8CFF', '#C9A7FF', '#F06BC0'];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const pad = (n) => String(n).padStart(2, '0');

  function dots(colors) {
    const list = (colors || []).slice(0, 3);
    if (!list.length) return '';
    // jeder Punkt läuft innen in die Farbe des nächsten über – zwei Termine = zwei Punkte, die ineinander übergehen
    return `<i class="rc-dots">${list.map((c, i) => `<b style="--a:${esc(c)};--b:${esc(list[i + 1] || list[i - 1] || c)}"></b>`).join('')}</i>`;
  }

  /** Monatsraster (Montag zuerst). days = { [tag]: [farben] } */
  function month(y, m, days = {}, { today = new Date(), weekdays = ['M', 'D', 'M', 'D', 'F', 'S', 'S'] } = {}) {
    const first = (new Date(y, m, 1).getDay() + 6) % 7;
    const count = new Date(y, m + 1, 0).getDate();
    const isThis = today.getFullYear() === y && today.getMonth() === m;
    let html = weekdays.map((d, i) => `<span class="rc-wd ${i > 4 ? 'we' : ''}">${d}</span>`).join('');
    for (let i = 0; i < first; i++) html += '<span class="rc-d off"></span>';
    for (let d = 1; d <= count; d++) {
      const we = (first + d - 1) % 7 > 4;
      const cls = [isThis && d === today.getDate() ? 'today' : '', isThis && d < today.getDate() ? 'past' : '', we ? 'we' : ''].join(' ');
      html += `<span class="rc-d ${cls}" data-rc-day="${d}"><em>${d}</em>${dots(days[d] || days[String(d)])}</span>`;
    }
    return `<div class="rc-month">${html}</div>`;
  }

  /* ---------------------------------------------------------------- Quick-Add */
  let pop = null;
  let keyboardOff = null;
  function close() {
    if (!pop) return;
    pop.classList.add('out');
    const p = pop;
    pop = null;
    setTimeout(() => p.remove(), 160);
    document.removeEventListener('mousedown', outside, true);
    document.removeEventListener('keydown', onKey, true);
    keyboardOff?.();
    keyboardOff = null;
  }
  function outside(e) { if (pop && !pop.contains(e.target)) close(); }
  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    if (e.key === 'Enter' && pop && e.target.tagName !== 'BUTTON') { e.preventDefault(); save(); }
  }
  async function save() {
    if (!pop) return;
    const f = (k) => pop.querySelector(`[data-rc="${k}"]`);
    const title = f('title').value.trim();
    if (!title) { f('title').focus(); pop.classList.add('shake'); setTimeout(() => pop?.classList.remove('shake'), 400); return; }
    const allDay = f('allday').getAttribute('aria-pressed') === 'true';
    const [Y, M, D] = f('date').value.split('-').map(Number);
    const [h, mi] = (f('time').value || '09:00').split(':').map(Number);
    const start = new Date(Y, (M || 1) - 1, D || 1, allDay ? 0 : h, allDay ? 0 : mi);
    const color = pop.querySelector('.rc-sw.on')?.dataset.c || COLORS[0];
    const btn = f('save');
    btn.disabled = true;
    btn.textContent = '…';
    try {
      await window.hub.agenda.quickAdd({ title, start: start.toISOString(), allDay, minutes: Number(f('dur').value) || 60, color, location: f('loc').value });
      try { localStorage.setItem('rc-color', color); } catch { /* egal */ }
      pop.classList.add('done');
      setTimeout(close, 380);
    } catch (err) {
      btn.disabled = false;
      btn.textContent = 'Hinzufügen';
      const e = pop.querySelector('.rc-err');
      if (e) e.textContent = String(err?.message || err).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
  }

  /**
   * @param {HTMLElement} anchor  Element, an dem das Popover hängt (der +-Knopf)
   * @param {{ date?: Date, keyboard?: (on:boolean)=>void }} opts
   */
  function open(anchor, opts = {}) {
    if (pop) { close(); return; }
    const now = opts.date || new Date();
    const nextHour = new Date(); nextHour.setMinutes(0, 0, 0); nextHour.setHours(nextHour.getHours() + 1);
    let color = COLORS[0];
    try { color = localStorage.getItem('rc-color') || color; } catch { /* egal */ }
    pop = document.createElement('div');
    pop.className = 'rc-pop';
    pop.innerHTML = `
      <div class="rc-pop-head"><b>Neuer Termin</b><button class="rc-x" data-rc="close" aria-label="Schließen">×</button></div>
      <input class="rc-in rc-title" data-rc="title" maxlength="120" placeholder="Titel" autocomplete="off" />
      <input class="rc-in" data-rc="loc" maxlength="120" placeholder="Ort (optional)" autocomplete="off" />
      <div class="rc-row">
        <input class="rc-in" type="date" data-rc="date" value="${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}" />
        <input class="rc-in rc-time" type="time" data-rc="time" value="${pad(nextHour.getHours())}:00" />
      </div>
      <div class="rc-row between">
        <button class="rc-tog" data-rc="allday" aria-pressed="false"><i></i>Ganztägig</button>
        <select class="rc-in rc-dur" data-rc="dur"><option value="15">15 Min.</option><option value="30">30 Min.</option><option value="60" selected>1 Std.</option><option value="90">1,5 Std.</option><option value="120">2 Std.</option><option value="240">4 Std.</option></select>
      </div>
      <div class="rc-sws">${COLORS.map((c) => `<button class="rc-sw ${c === color ? 'on' : ''}" data-c="${c}" style="--c:${c}" aria-label="Farbe ${c}"></button>`).join('')}</div>
      <p class="rc-err"></p>
      <button class="rc-save" data-rc="save">Hinzufügen</button>`;
    document.body.appendChild(pop);
    // Position: unter dem +-Knopf, im Fenster halten
    const r = anchor.getBoundingClientRect();
    const w = 280;
    const h = pop.offsetHeight || 320;
    let left = Math.min(window.innerWidth - w - 10, Math.max(10, r.right - w));
    let top = r.bottom + 8;
    if (top + h > window.innerHeight - 10) top = Math.max(10, r.top - h - 8);
    pop.style.left = `${left}px`;
    pop.style.top = `${top}px`;
    pop.addEventListener('click', (e) => {
      e.stopPropagation();
      const t = e.target.closest('button');
      if (!t) return;
      if (t.dataset.rc === 'close') return close();
      if (t.dataset.rc === 'save') return save();
      if (t.dataset.rc === 'allday') {
        const on = t.getAttribute('aria-pressed') !== 'true';
        t.setAttribute('aria-pressed', String(on));
        pop.classList.toggle('allday', on);
        return;
      }
      if (t.classList.contains('rc-sw')) { pop.querySelectorAll('.rc-sw').forEach((s) => s.classList.toggle('on', s === t)); pop.style.setProperty('--rc-accent', t.dataset.c); }
    });
    pop.style.setProperty('--rc-accent', color);
    if (opts.keyboard) { opts.keyboard(true); keyboardOff = () => opts.keyboard(false); }
    document.addEventListener('keydown', onKey, true);
    pop.querySelector('[data-rc="title"]').focus();
    // Desktop-Widget-Fenster nimmt Tastatur erst nach dem Umschalten an → nochmal fokussieren
    setTimeout(() => {
      document.addEventListener('mousedown', outside, true);
      const t = pop?.querySelector('[data-rc="title"]');
      if (t && document.activeElement !== t) t.focus();
    }, 60);
  }

  /** Der kleine +-Knopf (gleich in beiden Widgets). */
  const plus = (attr = 'data-rc-add') => `<button class="rc-plus" ${attr} title="Termin hinzufügen" aria-label="Termin hinzufügen"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></button>`;

  window.RevCal = { dots, month, open, close, plus, COLORS };
})();
