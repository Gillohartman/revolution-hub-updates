'use strict';
/**
 * 2.46 Eigenes virtuelles Mikrofon („Revolution Mic“)
 *
 * Windows kennt virtuelle Mikrofone nur über einen signierten Audiotreiber. Der Hub nutzt dafür das
 * kostenlose VB-CABLE (VB-Audio) und macht daraus „sein“ Mikrofon:
 *   - prüft, ob ein virtuelles Kabel vorhanden ist (VB-CABLE, Voicemeeter …)
 *   - installiert VB-CABLE auf Knopfdruck (Download vom Hersteller, Windows fragt per UAC nach)
 *   - benennt beide Enden um: Eingang (Wiedergabe) = „<Name> – Hub-Eingang“, Ausgang (Aufnahme) = „<Name>“
 *     → in Discord, OBS, Teams … erscheint das Mikrofon dann unter deinem Namen
 * Umbenennen läuft über die Windows-Audio-API (IPropertyStore, wie in der Systemsteuerung „Sound“).
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const { execFile } = require('child_process');

const CS = String.raw`
using System; using System.Text; using System.Runtime.InteropServices;
namespace RevVMic {
  [StructLayout(LayoutKind.Sequential)] public struct PKEY { public Guid fmtid; public int pid; public PKEY(Guid g, int p) { fmtid = g; pid = p; } }
  [StructLayout(LayoutKind.Explicit, Size = 24)] public struct PV { [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public IntPtr p; }
  [ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IPropertyStore { int GetCount(out uint c); int GetAt(uint i, out PKEY k); int GetValue(ref PKEY k, out PV v); int SetValue(ref PKEY k, ref PV v); int Commit(); }
  [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDevice { int Activate(ref Guid iid, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o); int OpenPropertyStore(int stgm, out IPropertyStore s); int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id); int GetState(out int st); }
  [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDeviceCollection { int GetCount(out uint c); int Item(uint i, out IMMDevice d); }
  [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDeviceEnumerator { int EnumAudioEndpoints(int flow, int mask, out IMMDeviceCollection c); int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice d); }
  [ComImport, Guid("f8679f50-850a-41cf-9c72-430f290290c8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IPolicyConfig { int A(); int B(); int C(); int D(); int E(); int F(); int G(); int H(); int I(); int J(); int SetDefaultEndpoint([MarshalAs(UnmanagedType.LPWStr)] string id, int role); }
  [ComImport, Guid("870af99c-171d-4f9e-af0d-e63df40c2bc9")] class PolicyConfigClient { }
  [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumerator { }
  public static class Api {
    static PKEY DESC = new PKEY(new Guid("a45c254e-df1c-4efd-8020-67d146a850e0"), 2);
    static PKEY IFACE = new PKEY(new Guid("026e516e-b814-414b-83cd-856d6fef4822"), 2);
    static string Read(IPropertyStore s, PKEY k) { PV v; if (s.GetValue(ref k, out v) != 0 || v.vt != 31 || v.p == IntPtr.Zero) return ""; return Marshal.PtrToStringUni(v.p); }
    static IMMDeviceCollection All(int flow) { var e = (IMMDeviceEnumerator)(new MMDeviceEnumerator()); IMMDeviceCollection c; Marshal.ThrowExceptionForHR(e.EnumAudioEndpoints(flow, 1, out c)); return c; }
    public static string List() {
      var sb = new StringBuilder();
      for (int flow = 0; flow < 2; flow++) {
        var c = All(flow); uint n; c.GetCount(out n);
        for (uint i = 0; i < n; i++) { IMMDevice d; c.Item(i, out d); string id; d.GetId(out id); IPropertyStore s; d.OpenPropertyStore(0, out s);
          sb.Append(flow == 0 ? "out" : "in").Append('\t').Append(id).Append('\t').Append(Read(s, DESC)).Append('\t').Append(Read(s, IFACE)).Append('\n'); }
      }
      return sb.ToString();
    }
    public static string DefaultCapture() {
      var e = (IMMDeviceEnumerator)(new MMDeviceEnumerator()); IMMDevice d;
      if (e.GetDefaultAudioEndpoint(1, 0, out d) != 0 || d == null) return ""; string id; d.GetId(out id); return id;
    }
    public static string SetDefault(string id) {
      var p = (IPolicyConfig)(new PolicyConfigClient());
      int a = p.SetDefaultEndpoint(id, 0), b = p.SetDefaultEndpoint(id, 1), c = p.SetDefaultEndpoint(id, 2);
      return (a | b | c) == 0 ? "OK" : "ERR " + a.ToString("X");
    }
    public static string Rename(string id, string name) {
      for (int flow = 0; flow < 2; flow++) {
        var c = All(flow); uint n; c.GetCount(out n);
        for (uint i = 0; i < n; i++) { IMMDevice d; c.Item(i, out d); string did; d.GetId(out did); if (did != id) continue;
          IPropertyStore s; int hr = d.OpenPropertyStore(2, out s); if (hr != 0) return "ERR " + hr.ToString("X");
          var v = new PV(); v.vt = 31; v.p = Marshal.StringToCoTaskMemUni(name);
          var k = DESC; hr = s.SetValue(ref k, ref v); if (hr == 0) hr = s.Commit(); Marshal.FreeCoTaskMem(v.p);
          return hr == 0 ? "OK" : "ERR " + hr.ToString("X"); }
      }
      return "ERR notfound";
    }
  }
}`;

const VIRTUAL = /cable|voicemeeter|vb-audio|virtual/i;
const psEsc = (s) => String(s).replace(/'/g, "''");

function ps(script, timeout = 40000) {
  const encoded = Buffer.from(`[Console]::OutputEncoding=[Text.Encoding]::UTF8\n${script}`, 'utf16le').toString('base64');
  return new Promise((resolve, reject) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, timeout, maxBuffer: 4 * 1024 * 1024 }, (err, out, errOut) => (err ? reject(new Error(String(errOut || err.message).trim().split('\n')[0])) : resolve(String(out || '')))));
}
const addType = () => `Add-Type -TypeDefinition @'\n${CS}\n'@ -Language CSharp`;

/** Alle aktiven Audio-Endpunkte (Wiedergabe „out“ / Aufnahme „in“) mit Name und Treibername. */
async function endpoints() {
  const out = await ps(`${addType()}\n[Console]::Out.Write([RevVMic.Api]::List())`);
  return out.split('\n').filter(Boolean).map((l) => { const [flow, id, name, iface] = l.split('\t'); return { flow, id, name: name || '', iface: (iface || '').trim() }; });
}

/** Das virtuelle Kabel finden: Aufnahme-Ende (das „Mikrofon“) und Wiedergabe-Ende (dahin schickt der Hub den Mix). */
async function status() {
  if (process.platform !== 'win32') return { supported: false };
  const eps = await endpoints();
  const isCable = (e) => /vb-audio virtual cable/i.test(e.iface) || /^cable (in|out)put/i.test(e.name);
  let mic = eps.find((e) => e.flow === 'in' && isCable(e));
  let sink = eps.find((e) => e.flow === 'out' && isCable(e));
  if (!mic || !sink) { // Voicemeeter & Co. als Ausweichlösung
    mic = mic || eps.find((e) => e.flow === 'in' && VIRTUAL.test(`${e.name} ${e.iface}`));
    sink = sink || eps.find((e) => e.flow === 'out' && VIRTUAL.test(`${e.name} ${e.iface}`));
  }
  return {
    supported: true,
    installed: Boolean(mic && sink),
    mic: mic ? { id: mic.id, name: mic.name, label: `${mic.name} (${mic.iface})`, iface: mic.iface } : null,
    sink: sink ? { id: sink.id, name: sink.name, label: `${sink.name} (${sink.iface})`, iface: sink.iface } : null,
  };
}

async function renameOne(id, name) {
  const script = `${addType()}\n[Console]::Out.Write([RevVMic.Api]::Rename('${psEsc(id)}','${psEsc(name)}'))`;
  let r = (await ps(script)).trim();
  if (r === 'OK') return true;
  if (!/ERR 80070005/i.test(r)) throw new Error(`Umbenennen fehlgeschlagen (${r}).`);
  // Ohne Adminrechte verweigert manche Windows-Version das Schreiben → einmal mit UAC
  const tmp = path.join(os.tmpdir(), `rev-vmic-${Date.now()}.ps1`);
  const res = `${tmp}.txt`;
  fs.writeFileSync(tmp, `﻿${script.replace('[Console]::Out.Write(', `Set-Content -Encoding UTF8 -Path '${psEsc(res)}' -Value (`)}`, 'utf8');
  await ps(`Start-Process powershell.exe -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','"${psEsc(tmp)}"'`, 120000).catch(() => { throw new Error('Windows hat das Umbenennen nicht erlaubt (Administrator-Abfrage abgelehnt).'); });
  r = fs.existsSync(res) ? fs.readFileSync(res, 'utf8').replace(/^﻿/, '').trim() : '';
  fs.rmSync(tmp, { force: true }); fs.rmSync(res, { force: true });
  if (r !== 'OK') throw new Error(`Umbenennen fehlgeschlagen (${r || 'abgebrochen'}).`);
  return true;
}

/** Mikrofon umbenennen – erscheint danach überall (Discord, OBS, Windows) unter diesem Namen. */
async function rename(name) {
  const clean = String(name || '').replace(/[\t\n\r]/g, ' ').trim().slice(0, 40) || 'Revolution Mic';
  const s = await status();
  if (!s.installed) throw new Error('Kein virtuelles Mikrofon gefunden – bitte zuerst einrichten.');
  await renameOne(s.mic.id, clean);
  await renameOne(s.sink.id, `${clean} – Hub-Eingang`).catch(() => {}); // nur Kosmetik
  return status();
}

function download(url, file, redirects = 4) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'RevolutionHub' }, timeout: 30000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) { res.resume(); return resolve(download(new URL(res.headers.location, url).toString(), file, redirects - 1)); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`HTTP ${res.statusCode}`)); }
      const ws = fs.createWriteStream(file);
      res.pipe(ws);
      ws.on('finish', () => ws.close(() => resolve(file)));
      ws.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('Zeitüberschreitung')));
    req.on('error', reject);
  });
}

const PACKS = ['https://download.vb-audio.com/Download_CABLE/VBCABLE_Driver_Pack45.zip', 'https://download.vb-audio.com/Download_CABLE/VBCABLE_Driver_Pack43.zip'];

/** VB-CABLE vom Hersteller laden und installieren (Windows fragt per UAC), danach auf den Wunschnamen umbenennen. */
async function install(name, onStep = () => {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rev-vmic-'));
  const zip = path.join(dir, 'vbcable.zip');
  let ok = false;
  onStep('Treiber wird geladen …');
  for (const u of PACKS) { try { await download(u, zip); ok = fs.statSync(zip).size > 100000; if (ok) break; } catch { /* nächste Quelle */ } }
  if (!ok) { const e = new Error('Download nicht möglich.'); e.code = 'DOWNLOAD'; throw e; }
  onStep('Treiber wird installiert – bitte die Windows-Abfrage bestätigen …');
  const ex = path.join(dir, 'x');
  await ps(`Expand-Archive -LiteralPath '${psEsc(zip)}' -DestinationPath '${psEsc(ex)}' -Force`, 60000);
  const setup = path.join(ex, process.arch === 'x64' || process.arch === 'arm64' ? 'VBCABLE_Setup_x64.exe' : 'VBCABLE_Setup.exe');
  if (!fs.existsSync(setup)) throw new Error('Installationsprogramm im Paket nicht gefunden.');
  await ps(`Start-Process -FilePath '${psEsc(setup)}' -ArgumentList '-i','-h' -Verb RunAs -Wait`, 300000).catch(() => { throw new Error('Installation abgebrochen (Administrator-Abfrage abgelehnt).'); });
  fs.rmSync(dir, { recursive: true, force: true });
  onStep('Mikrofon wird eingerichtet …');
  let s = null;
  for (let i = 0; i < 10; i++) { s = await status().catch(() => null); if (s?.installed) break; await new Promise((r) => setTimeout(r, 1500)); }
  if (!s?.installed) throw new Error('Treiber installiert, aber noch nicht aktiv – bitte den PC neu starten.');
  return rename(name);
}

/** Aktuelles Windows-Standardmikrofon (Endpunkt-ID). */
async function defaultCapture() {
  return (await ps(`${addType()}\n[Console]::Out.Write([RevVMic.Api]::DefaultCapture())`)).trim();
}
/** Mikrofon als Windows-Standard setzen (Konsole, Multimedia, Kommunikation) – so nehmen es auch Spiele. */
async function setDefaultCapture(id) {
  const r = (await ps(`${addType()}\n[Console]::Out.Write([RevVMic.Api]::SetDefault('${psEsc(id)}'))`)).trim();
  if (r !== 'OK') throw new Error(`Standardmikrofon konnte nicht gesetzt werden (${r}).`);
  return true;
}

module.exports = { status, rename, install, defaultCapture, setDefaultCapture };
