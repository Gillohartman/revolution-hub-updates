'use strict';

/*
 * 2.47 Premium-Bibliothek aus der Cloud (Cloudflare R2 o. ä. – jeder öffentliche HTTPS-Speicher geht).
 *
 * Aufbau im Speicher (erzeugt von tools/wallpaper-cloud/prepare.js):
 *   index.json            – Liste aller Hintergründe
 *   thumbs/<id>.jpg       – kleine Vorschaubilder (~480 px) für die Galerie
 *   full/<pfad>           – die Originale (Bilder oder Videos)
 *
 * Die App lädt nur index.json und die Vorschaubilder. Das große Original wird erst geladen, wenn
 * jemand es als Desktop oder App-Hintergrund setzt, und dann lokal zwischengespeichert.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const LIST_TTL = 30 * 60000;
const CACHE_LIMIT = 3 * 1024 * 1024 * 1024; // höchstens 3 GB Originale lokal behalten
const VIDEO = /\.(mp4|webm|mov|mkv)$/i;

const clean = (v, max = 80) => String(v ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);

class CloudLibrary {
  /** @param {{ base: () => string, dir: string, keep?: () => string }} o */
  constructor(o) {
    this.baseFn = o.base;
    this.keep = o.keep || (() => ''); // gerade als Live-Desktop laufende Datei nie wegräumen
    this.dir = path.join(o.dir, 'cloud-library');
    this.items = null;
    this.at = 0;
    this.loading = null;
  }

  base() {
    const b = String(this.baseFn() || '').trim().replace(/\/+$/, '');
    // http nur für einen lokalen Testserver
    return /^https:\/\/[^\s"'<>]+$/i.test(b) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(b) ? b : '';
  }

  url(rel) {
    return `${this.base()}/${String(rel).split('/').map(encodeURIComponent).join('/')}`;
  }

  /** Alle Hintergründe (mit Vorschau-URL). Ohne eingerichtete Adresse: leere Liste. */
  async list(force = false) {
    const base = this.base();
    if (!base) return { configured: false, items: [] };
    if (!force && this.items && this.items.base === base && Date.now() - this.at < LIST_TTL) return { configured: true, items: this.items.list, paid: this.items.paid };
    if (this.loading) return this.loading;
    this.loading = (async () => {
      const cacheFile = path.join(this.dir, 'index.json');
      let raw;
      try {
        const r = await fetch(`${base}/index.json`, { cache: 'no-store' });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        raw = await r.json();
        fs.mkdirSync(this.dir, { recursive: true });
        fs.writeFileSync(cacheFile, JSON.stringify(raw));
      } catch (e) {
        // offline: letzte bekannte Liste zeigen
        try {
          raw = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
        } catch {
          throw new Error(`Premium-Bibliothek nicht erreichbar (${e.message || e}).`);
        }
      }
      const list = (Array.isArray(raw?.items) ? raw.items : [])
        .filter((x) => x && typeof x.id === 'string' && typeof x.file === 'string' && /^[a-z0-9-]{3,80}$/.test(x.id) && !x.file.includes('..'))
        .map((x) => ({
          id: x.id,
          name: clean(x.name) || 'Hintergrund',
          cat: clean(x.cat, 40) || 'Premium',
          author: clean(x.author, 40), // 2.47.2: leer = „Unbekannt“
          w: Number(x.w) || 0,
          h: Number(x.h) || 0,
          size: Number(x.size) || 0,
          video: VIDEO.test(x.file),
          thumb: this.url(x.thumb || `thumbs/${x.id}.jpg`),
          remote: this.url(`full/${x.file}`), // Original zum Streamen in der Vorschau
          at: Number(x.at) || 0,
          file: x.file,
        }));
      // 2.47.2: Kaufmodus (vorerst aus) – in index.json „paid: true“ schaltet ihn ein, Preis je Hintergrund (Standard 200)
      const paid = raw?.paid === true;
      for (const it of list) it.price = paid ? Math.max(0, Number(raw.items.find((x) => x.id === it.id)?.price ?? 200)) : 0;
      // 2.47.5: schon heruntergeladene Hintergründe spielen in der App aus der lokalen Datei – auch offline live
      for (const it of list) Object.defineProperty(it, 'src', { enumerable: true, get: () => { const p = this.localPath(it); return p ? require('url').pathToFileURL(p).href : it.remote; } });
      this.items = { base, list, paid };
      this.at = Date.now();
      return { configured: true, items: list, paid };
    })();
    try {
      return await this.loading;
    } finally {
      this.loading = null;
    }
  }

  async entry(id) {
    const { items } = await this.list();
    const it = items.find((x) => x.id === id);
    if (!it) throw new Error('Hintergrund nicht gefunden.');
    return it;
  }

  /** Pfad der schon heruntergeladenen Datei (oder ''). */
  localPath(it) {
    try {
      const ext = (path.extname(it.file) || '.jpg').toLowerCase().slice(0, 6);
      const p = path.join(this.dir, 'files', `${it.id}-${crypto.createHash('sha1').update(it.file).digest('hex').slice(0, 8)}${ext}`);
      return fs.existsSync(p) && fs.statSync(p).size > 0 ? p : '';
    } catch {
      return '';
    }
  }

  /** Original herunterladen (oder aus dem Zwischenspeicher) → lokaler Pfad. */
  async file(id, onProgress) {
    const it = await this.entry(String(id || ''));
    const ext = (path.extname(it.file) || '.jpg').toLowerCase().slice(0, 6);
    const dir = path.join(this.dir, 'files');
    fs.mkdirSync(dir, { recursive: true });
    const dst = path.join(dir, `${it.id}-${crypto.createHash('sha1').update(it.file).digest('hex').slice(0, 8)}${ext}`);
    if (fs.existsSync(dst) && fs.statSync(dst).size > 0) {
      const now = new Date();
      fs.utimesSync(dst, now, now);
      return { path: dst, video: it.video, name: it.name };
    }
    const r = await fetch(this.url(`full/${it.file}`));
    if (!r.ok || !r.body) throw new Error(`Download fehlgeschlagen (HTTP ${r.status}).`);
    const total = Number(r.headers.get('content-length')) || it.size || 0;
    const tmp = `${dst}.part`;
    const out = fs.createWriteStream(tmp);
    let got = 0;
    try {
      for await (const chunk of r.body) {
        got += chunk.length;
        if (!out.write(chunk)) await new Promise((res) => out.once('drain', res));
        if (onProgress && total) onProgress(Math.min(1, got / total));
      }
      await new Promise((res, rej) => out.end((e) => (e ? rej(e) : res())));
      fs.renameSync(tmp, dst);
    } catch (e) {
      out.destroy();
      fs.rmSync(tmp, { force: true });
      throw e;
    }
    this.trim(dir);
    return { path: dst, video: it.video, name: it.name };
  }

  /** Zwischenspeicher klein halten: älteste Dateien zuerst löschen. */
  trim(dir) {
    try {
      const files = fs.readdirSync(dir).map((f) => {
        const p = path.join(dir, f);
        const s = fs.statSync(p);
        return { p, size: s.size, t: s.mtimeMs };
      }).sort((a, b) => b.t - a.t);
      let sum = 0;
      const keep = String(this.keep() || '').toLowerCase();
      for (const f of files) {
        sum += f.size;
        if (sum > CACHE_LIMIT && f.p.toLowerCase() !== keep) fs.rmSync(f.p, { force: true });
      }
    } catch {
      /* egal */
    }
  }

  /** Für Videos ein scharfes Standbild ziehen (Windows-Desktop braucht ein Bild). */
  async still(file) {
    if (!file.video) return file.path;
    const dst = file.path.replace(/\.[^.]+$/, '-still.jpg');
    if (fs.existsSync(dst)) return dst;
    const ffmpeg = require('./desktop-wallpaper').ffmpegPath();
    await new Promise((resolve, reject) => {
      require('child_process').execFile(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-ss', '1', '-i', file.path, '-frames:v', '1', '-q:v', '1', '-y', dst], { windowsHide: true, timeout: 60000 }, (error) => (error || !fs.existsSync(dst) ? reject(new Error('Standbild konnte nicht erzeugt werden.')) : resolve()));
    });
    return dst;
  }

  async desktop(id, opts, onProgress) {
    const f = await this.file(id, onProgress);
    await require('./desktop-wallpaper').applyDesktopWallpaper(await this.still(f), opts || {});
    return true;
  }
}

module.exports = { CloudLibrary };
