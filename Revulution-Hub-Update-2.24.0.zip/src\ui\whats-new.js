'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.24.0',
  title: 'Revulution Hub 2.24',
  sub: 'Schwebende Leiste, freie Widgets und Hintergründe pro Monitor.',
  items: [
    { open: 'home', icon: 'settings', title: 'Schwebende Leiste', text: 'Oben schweben jetzt zwei schlanke Pillen statt eines Balkens – und nichts blinkt mehr beim Klicken.' },
    { open: 'home', icon: 'spark', title: 'Windows-Taste gehört dem Hub', text: 'Kein Startmenü mehr – die Windows-Taste öffnet dein Hub-Menü. Win+E, Win+D & Co. funktionieren weiter.' },
    { open: 'tool-desktop', icon: 'spark', title: 'Widgets frei verschieben', text: 'Jedes Widget einfach mit der Maus ziehen. Neu: Läuft gerade, Kalender und ein Punktmatrix-Gesicht.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Hintergrund pro Monitor', text: 'Monitore auswählen oder über alle strecken – die gewählten leuchten live blau mit Partikeln.' },
    { open: 'home', icon: 'home', title: 'Runde Ecken, mehr Glas', text: 'Kleine runde Fensterecken und ein noch durchsichtigerer Hub.' },
    { open: 'home', icon: 'cpu', title: 'Viel weniger CPU und RAM', text: 'Ein einziger, schlanker System-Wächter statt drei Dauer-Schleifen, versteckte Apps schlafen jetzt, Medien-Abfrage nur noch bei Bedarf.' },
    { open: 'settings', icon: 'settings', title: 'Neue obere Leiste', text: 'Tiefschwarz im Nothing-Stil mit R-Logo, roten Punkten und großer Uhr – und die Windows-Taskleiste bleibt jetzt wirklich weg.' },
    { open: 'home', icon: 'spark', title: 'Glas statt Schwarz', text: 'Der Hub ist echt durchsichtig: dein Desktop scheint live und verschwommen durch. Neue Desktop-Widgets mit Punktmatrix-Uhr.' },
    { open: 'chats', icon: 'chats', title: 'Bessere Anrufe', text: 'Lautstärke der anderen Person (bis 200 %), Anrufe poppen in der Island auf, und du kannst während des Anrufs weiterschreiben.' },
    { open: 'geo', icon: 'geo', title: 'GeoRevulution online', text: 'Schnelles Spiel gegen Zufallsgegner, offene Partys mit Leuten aus aller Welt, neuer Blitz-Modus und stabilere Räume.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Hintergründe einreichen', text: 'Schick eigene Desktop-Bilder ein – nach der Freigabe sehen sie alle im Hub.' },
    { open: 'orbit', icon: 'orbit', title: 'Songtexte animiert', text: 'Die Island zeigt Songtexte wieder mit Karaoke-Animation.' },
    { open: 'home', icon: 'spark', title: 'Favoriten ganz oben', text: 'Tippe auf den Stern einer App – sie erscheint ab sofort in einem eigenen Favoriten-Bereich über allem anderen.' },
    { open: 'tool-speed', icon: 'globe', title: 'WLAN-Test als eigene App', text: 'Download, Upload, Ping und Signalstärke mit animierten Ringen, Verlauf und Tipps, was deine Leitung bremst.' },
    { open: 'settings', icon: 'crosshair', title: 'Crosshair in der Leiste', text: 'Das Fadenkreuz lässt sich oben direkt ein- und ausschalten – standardmäßig aus. Über das Plus kommen weitere Elemente dazu.' },
    { open: 'tool-screentime', icon: 'clock', title: 'Bildschirmzeit mit Gesamtzeit', text: 'Alle Apps und die Gesamtzeit seit dem ersten Tag, echte App-Symbole und ein modernes Fenster für das Tageslimit.' },
    { open: 'settings', icon: 'cpu', title: 'Mehr Leistung sehen', text: 'Der Hub prüft, ob alle Monitore mit ihrer maximalen Hertz-Zahl laufen, und zeigt die größten RAM-Verbraucher mit Beenden-Knopf.' },
  ],
};
