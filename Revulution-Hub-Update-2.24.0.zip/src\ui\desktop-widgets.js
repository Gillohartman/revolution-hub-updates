'use strict';

/* Widgets auf dem Windows-Desktop: ein durchsichtiges Fenster über dem Hauptmonitor.
   Klicks gehen überall durch – nur über einem Widget nimmt das Fenster die Maus,
   damit man es frei ziehen (und beim Musik-Widget bedienen) kann. */
(function () {
  const stage = document.getElementById('stack');
  let state = null;
  let pc = {};
  let screen = null;
  let media = null;
  let interactive = false;

  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const pct = (v) => (v == null || Number.isNaN(Number(v)) ? '–' : `${Math.round(Number(v))} %`);
  const clamp = (v) => Math.max(0, Math.min(100, Number(v) || 0));
  const mmss = (s) => `${Math.floor((Number(s) || 0) / 60)}:${String(Math.floor((Number(s) || 0) % 60)).padStart(2, '0')}`;

  const timeText = () => new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const dayHtml = () => {
    const d = new Date();
    const wd = d.toLocaleDateString('de-DE', { weekday: 'short' }).replace('.', '').toUpperCase();
    return `<b>${esc(wd)}</b> · ${String(d.getDate()).padStart(2, '0')} ${esc(d.toLocaleDateString('de-DE', { month: 'short' }).replace('.', '').toUpperCase())}`;
  };
  const fmtDuration = (seconds) => {
    const s = Math.max(0, Math.round(Number(seconds) || 0));
    const h = Math.floor(s / 3600);
    const m = Math.round((s % 3600) / 60);
    return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m`;
  };
  /** Punkte-Balken: der letzte gefüllte Punkt ist rot. */
  function dots(value, n = 20) {
    const k = Math.round((clamp(value) / 100) * n);
    let html = '<div class="dw-dots">';
    for (let i = 0; i < n; i++) html += `<i class="${i < k - 1 ? 'on' : i === k - 1 ? 'tip' : ''}"></i>`;
    return `${html}</div>`;
  }

  const ICON = {
    prev: '<svg viewBox="0 0 24 24"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M16 5h2v14h-2zM4 5v14l11-7z"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4v16l13-8z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
  };

  /* Standardplätze (rechts oben, untereinander) – danach zählt, wo du sie hinziehst. */
  const W = window.innerWidth;
  const DEFAULTS = {
    clock: { x: W - 330, y: 40 },
    face: { x: W - 560, y: 40 },
    music: { x: W - 340, y: 200 },
    system: { x: W - 300, y: 370 },
    calendar: { x: W - 560, y: 260 },
    screen: { x: W - 300, y: 500 },
    upcoming: { x: W - 300, y: 650 },
  };

  stage.innerHTML = `
    <section class="dw dw-clock" data-w="clock"><time id="dw-time">${timeText()}</time><div class="dw-day" id="dw-day">${dayHtml()}</div></section>
    <section class="dw dw-face" data-w="face"><canvas id="dw-face" width="340" height="340"></canvas></section>
    <section class="dw dw-music" data-w="music"><div class="dw-label">Läuft gerade</div><div id="dw-music-body"></div></section>
    <section class="dw dw-system" data-w="system"><div class="dw-label">System</div><div id="dw-sys-body"></div></section>
    <section class="dw dw-cal" data-w="calendar"><div id="dw-cal-body"></div></section>
    <section class="dw dw-screen" data-w="screen"><div class="dw-label">Bildschirmzeit</div><div id="dw-screen-body"></div></section>
    <section class="dw dw-up" data-w="upcoming"><div class="dw-label">Termine</div><div id="dw-up-body"></div></section>`;

  const cards = Object.fromEntries([...stage.querySelectorAll('[data-w]')].map((el) => [el.dataset.w, el]));

  function place() {
    const pos = state?.settings?.widgetPos || {};
    for (const [id, el] of Object.entries(cards)) {
      const p = pos[id] || DEFAULTS[id];
      el.style.left = `${Math.max(0, Math.min(window.innerWidth - 60, p.x))}px`;
      el.style.top = `${Math.max(0, Math.min(window.innerHeight - 40, p.y))}px`;
    }
  }

  /* ------------------------------------------------------------ Ziehen */
  let drag = null;
  stage.addEventListener('pointerdown', (e) => {
    const el = e.target.closest('.dw');
    if (!el || e.button !== 0 || e.target.closest('button')) return;
    const r = el.getBoundingClientRect();
    drag = { el, dx: e.clientX - r.left, dy: e.clientY - r.top, moved: false };
    el.setPointerCapture(e.pointerId);
    el.classList.add('dragging');
  });
  stage.addEventListener('pointermove', (e) => {
    if (!drag) return;
    drag.moved = true;
    drag.el.style.left = `${Math.max(0, Math.min(window.innerWidth - 60, e.clientX - drag.dx))}px`;
    drag.el.style.top = `${Math.max(0, Math.min(window.innerHeight - 40, e.clientY - drag.dy))}px`;
  });
  stage.addEventListener('pointerup', () => {
    if (!drag) return;
    const { el, moved } = drag;
    el.classList.remove('dragging');
    drag = null;
    if (moved) window.hub.widgetPos?.(el.dataset.w, { x: parseInt(el.style.left, 10), y: parseInt(el.style.top, 10) });
  });

  // Nur über einem Widget nimmt das Fenster die Maus – sonst geht alles zum Desktop durch.
  document.addEventListener('mousemove', (e) => {
    const over = Boolean(drag || document.elementFromPoint(e.clientX, e.clientY)?.closest('.dw'));
    if (over !== interactive) {
      interactive = over;
      window.hub.widgetsInteractive?.(over);
    }
  });

  /* ------------------------------------------------------------ Inhalte */
  function paintClock() {
    const t = document.getElementById('dw-time');
    if (t && t.textContent !== timeText()) t.textContent = timeText();
    const d = document.getElementById('dw-day');
    if (d) d.innerHTML = dayHtml();
  }

  function paintSystem() {
    const body = document.getElementById('dw-sys-body');
    if (!body) return;
    body.innerHTML = [['CPU', pc.cpu], ['RAM', pc.ramPct], ['GPU', pc.gpu]].map(([n, v]) => `<div class="dw-row"><span>${n}</span>${dots(v)}<b>${pct(v)}</b></div>`).join('');
  }

  function paintScreen() {
    const body = document.getElementById('dw-screen-body');
    if (!body) return;
    if (!screen) return (body.innerHTML = '<div class="dw-empty">…</div>');
    const apps = (screen.apps || []).slice(0, 3);
    body.innerHTML = `<div class="dw-big">${fmtDuration(screen.total)}</div><div style="height:10px"></div>${apps.map((a) => `<div class="dw-app"><span>${esc(a.name)}</span>${dots((a.secs / Math.max(1, screen.total)) * 100)}</div>`).join('')}`;
  }

  function paintUpcoming() {
    const body = document.getElementById('dw-up-body');
    if (!body) return;
    const list = (state?.upcoming || []).slice(0, 3);
    if (!list.length) return (body.innerHTML = '<div class="dw-empty">Keine Termine</div>');
    body.innerHTML = list
      .map((e) => {
        const d = new Date(e.start);
        const today = new Date();
        const tomorrow = new Date(Date.now() + 86400000);
        const day = d.toDateString() === today.toDateString() ? 'Heute' : d.toDateString() === tomorrow.toDateString() ? 'Morgen' : d.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
        const when = e.allDay ? `${day} · ganztägig` : `${day} · ${d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
        return `<div class="dw-event"><i></i><div><b>${esc(e.title)}</b><small>${esc(when)}</small></div></div>`;
      })
      .join('');
  }

  function paintCalendar() {
    const body = document.getElementById('dw-cal-body');
    if (!body) return;
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth();
    const first = (new Date(y, m, 1).getDay() + 6) % 7; // Montag zuerst
    const days = new Date(y, m + 1, 0).getDate();
    const prevDays = new Date(y, m, 0).getDate();
    let html = ['MO', 'DI', 'MI', 'DO', 'FR', 'SA', 'SO'].map((d) => `<span class="wd">${d}</span>`).join('');
    for (let i = 0; i < 42; i++) {
      const n = i - first + 1;
      if (n < 1) html += `<span class="d off">${prevDays + n}</span>`;
      else if (n > days) html += `<span class="d off">${n - days}</span>`;
      else html += `<span class="d ${n === now.getDate() ? 'today' : ''}">${n}</span>`;
      if (i >= 34 && n >= days) break;
    }
    const key = `${y}-${m}-${now.getDate()}`;
    if (body.dataset.key === key) return;
    body.dataset.key = key;
    body.innerHTML = `<div class="dw-cal-head"><span>${esc(now.toLocaleDateString('de-DE', { month: 'long' }))}</span><span>${y}</span></div><div class="dw-cal-grid">${html}</div>`;
  }

  function paintMusic() {
    const body = document.getElementById('dw-music-body');
    if (!body) return;
    const m = media;
    cards.music.classList.toggle('playing', Boolean(m?.playing));
    if (!m?.title) return (body.innerHTML = '<div class="dw-empty">Gerade läuft nichts</div>');
    const prog = m.duration > 0 ? (m.position / m.duration) * 100 : 0;
    body.innerHTML = `<div class="dw-mu-top"><div class="dw-art" style="${m.art ? `background-image:url('data:image/jpeg;base64,${m.art}')` : ''}"></div><div class="dw-mu-text"><b>${esc(m.title)}</b><span>${esc(m.artist || '')}</span></div></div>
      <div class="dw-mu-prog"><span>${mmss(m.position)}</span>${dots(prog, 28)}<span>${mmss(m.duration)}</span></div>
      <div class="dw-mu-ctl"><button data-media="prev">${ICON.prev}</button><button class="main" data-media="playpause">${m.playing ? ICON.pause : ICON.play}</button><button data-media="next">${ICON.next}</button></div>`;
  }
  stage.addEventListener('click', (e) => {
    const b = e.target.closest('[data-media]');
    if (!b) return;
    window.hub.cc?.media?.(b.dataset.media)?.catch?.(() => {});
    if (b.dataset.media === 'playpause' && media) {
      media.playing = !media.playing;
      paintMusic();
    }
  });

  /* ------------------------------------------------------------ Punktmatrix-Gesicht */
  const face = { blinkAt: Date.now() + 2500, look: 0, lookTo: 0, lookAt: Date.now() + 1800 };
  function drawFace() {
    const cv = document.getElementById('dw-face');
    if (!cv || cards.face.hidden) return;
    const g = cv.getContext('2d');
    const N = 21;
    const S = cv.width / N;
    const now = Date.now();
    g.clearRect(0, 0, cv.width, cv.height);
    if (now > face.lookAt) {
      face.lookTo = [-1, 0, 0, 1][Math.floor(Math.random() * 4)];
      face.lookAt = now + 1500 + Math.random() * 2500;
    }
    face.look += (face.lookTo - face.look) * 0.35;
    const blink = now > face.blinkAt && now < face.blinkAt + 140;
    if (now > face.blinkAt + 140) face.blinkAt = now + 2200 + Math.random() * 3000;
    const lx = Math.round(face.look);
    const lit = new Set();
    const red = new Set();
    const eye = (cx) => {
      for (let y = 7; y <= 10; y++) for (let x = cx - 2; x <= cx + 1; x++) if (!blink || y === 9) lit.add(`${x + lx},${y}`);
    };
    eye(7);
    eye(14);
    red.add(`${5 + lx},13`);
    red.add(`${15 + lx},13`);
    // Mund: wippt, solange Musik spielt
    const open = media?.playing ? Math.round((Math.sin(now / 160) + 1) * 0.9) : 0;
    for (let x = 9; x <= 11; x++) for (let y = 14; y <= 14 + open; y++) lit.add(`${x + lx},${y}`);
    for (let y = 0; y < N; y++)
      for (let x = 0; x < N; x++) {
        const dx = x - (N - 1) / 2;
        const dy = y - (N - 1) / 2;
        if (dx * dx + dy * dy > 10.2 * 10.2) continue;
        const k = `${x},${y}`;
        g.beginPath();
        g.arc(x * S + S / 2, y * S + S / 2, S * (lit.has(k) || red.has(k) ? 0.4 : 0.22), 0, Math.PI * 2);
        g.fillStyle = red.has(k) ? '#ff2d2d' : lit.has(k) ? '#ffffff' : 'rgba(255,255,255,0.14)';
        g.fill();
      }
  }

  /* ------------------------------------------------------------ Steuerung */
  function apply() {
    const d = state?.settings?.desktopWidgets || {};
    const on = (k, def = true) => (d[k] === undefined ? def : d[k] !== false);
    cards.clock.hidden = !on('clock');
    cards.face.hidden = !on('face');
    cards.music.hidden = !on('music');
    cards.system.hidden = !on('system');
    cards.calendar.hidden = !on('calendar');
    cards.screen.hidden = !on('screentime', false);
    cards.upcoming.hidden = !on('upcoming', false);
    place();
    paintClock();
    paintSystem();
    paintScreen();
    paintUpcoming();
    paintCalendar();
    paintMusic();
  }

  async function loadSystem() {
    if (cards.system.hidden) return;
    try {
      pc = (await window.hub.pcLive()) || {};
      paintSystem();
    } catch {
      /* letzter Wert bleibt */
    }
  }
  async function loadScreen() {
    if (cards.screen.hidden) return;
    try {
      screen = await window.hub.screentime.summary();
      paintScreen();
    } catch {
      /* letzter Wert bleibt */
    }
  }

  setInterval(() => {
    paintClock();
    paintCalendar();
  }, 1000);
  setInterval(loadSystem, 4000);
  setInterval(loadScreen, 60000);
  setInterval(drawFace, 90); // ~11 Bilder/s reichen für das Gesicht

  window.hub.onMedia?.((m) => {
    if (!m) return;
    const art = m.art || media?.art || '';
    const sameSong = media && media.title === m.title && media.artist === m.artist;
    media = { ...m, art: m.art ? m.art : sameSong ? art : '' };
    paintMusic();
  });
  window.hub.onState((next) => {
    state = next;
    apply();
  });
  window.hub
    .state()
    .then((initial) => {
      state = initial;
      apply();
      loadSystem();
      loadScreen();
    })
    .catch(() => {});
})();
