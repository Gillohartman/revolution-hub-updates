'use strict';

/*
 * Obere Leiste: das R-Logo, die angehefteten/laufenden Apps der echten
 * Windows-Taskleiste und rechts die Hub-Kontrollen. Alles schwarz, die Leiste
 * selbst transparent. Das Windows-Popup hängt als kleine Karte unter dem Logo.
 */
(() => {
  const $ = (selector) => document.querySelector(selector);
  const esc = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

  let state = null;
  let clockTimer = 0;
  let lastKey = '';
  let drawerWasOpen = false;
  let interactive = null;
  let screenData = null;
  let screenLoading = false;

  function setInteractive(on) {
    if (on === interactive) return;
    interactive = on;
    window.hub.taskbar?.interactive?.(on).catch(() => {});
  }

  const windowsApps = () => (state?.windowsApps || []).slice(0, 18);

  function clockHtml() {
    return '<span class="tb-clock-time" data-clock-time>--:--</span><span class="tb-clock-date" data-clock-date>Revulution</span>';
  }

  function fallback(name) {
    return `<span class="tb-win-fallback">${esc(String(name || '?').slice(0, 1).toUpperCase())}</span>`;
  }

  function appButton(item) {
    const label = item.title || item.name;
    return `<button class="tb-winbtn" data-winapp="${esc(item.id)}" title="${esc(label)}">
      ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
      ${item.kind === 'running' ? '<i class="tb-running"></i>' : ''}
    </button>`;
  }

  const windowsMark = () => `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3 5.2 10.4 4v7.2H3zm8.6-1.35L21 2.6v8.6h-9.4zM3 12.8h7.4V20L3 18.8zm8.6 0H21v8.8l-9.4-1.25z"/></svg>`;

  const TOP_ITEMS = {
    crosshair: { icon: 'crosshair', title: 'Crosshair ein- oder ausschalten' },
    screentime: { icon: 'clock', title: 'Bildschirmzeit öffnen' },
    speed: { icon: 'globe', title: 'WLAN-Test öffnen' },
    settings: { icon: 'settings', title: 'Einstellungen öffnen' },
  };

  function extraHtml() {
    const items = (state?.topbarItems || ['crosshair', 'screentime', 'speed']).filter((id) => TOP_ITEMS[id]);
    return items
      .map((id) => {
        const item = TOP_ITEMS[id];
        if (id === 'crosshair') {
          return `<button class="tb-iconbtn tb-cross ${state?.crosshairOn ? 'on' : ''}" data-tb-top="crosshair" title="${esc(item.title)}">${window.icon(item.icon, 15)}</button>`;
        }
        return `<button class="tb-iconbtn" data-tb-top="${id}" title="${esc(item.title)}">${window.icon(item.icon, 15)}</button>`;
      })
      .join('');
  }

  function barHtml() {
    return `<div class="tb-bar">
      <div class="tb-pill tb-pill-left">
      <button class="tb-logo ${state?.drawer ? 'is-open' : ''}" data-act="drawer" title="Desktop · Apps und Widgets">
        <img src="assets/mark.png" alt="R" draggable="false" /><i class="tb-logo-dot"></i>
      </button>
      <span class="tb-divider"></span>
      <div class="tb-apps">${windowsApps().map(appButton).join('')}</div>
      </div>
      <div class="tb-pill tb-pill-right">
      ${extraHtml() ? `<div class="tb-extra">${extraHtml()}</div>` : ''}
      <div class="tb-right">
        <button class="tb-iconbtn" data-act="control" title="Kontrollzentrum">${window.icon('control', 15)}</button>
        <button class="tb-iconbtn tb-power" data-act="quit" title="Revulution Hub beenden">${window.icon('power', 15)}</button>
        <button class="tb-iconbtn" data-act="settings" title="Einstellungen">${window.icon('settings', 15)}${state?.dnd ? '<i class="tb-dot"></i>' : ''}</button>
        <span class="tb-divider"></span>
        <button class="tb-clock" data-act="agenda" title="Agenda">${clockHtml()}</button>
      </div>
      </div>
    </div>`;
  }

  function drawerGrid(query = '') {
    const q = String(query || '').trim().toLocaleLowerCase('de');
    const items = windowsApps().filter((item) => !q || String(item.title || item.name).toLocaleLowerCase('de').includes(q));
    if (!items.length) {
      return `<p class="drawer-empty">${state?.windowsApps ? 'Keine App gefunden.' : 'Windows-Apps werden geladen …'}</p>`;
    }
    return items
      .map(
        (item) =>
          `<button class="drawer-item" data-winapp="${esc(item.id)}" title="${esc(item.title || item.name)}">
            ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
            <b>${esc(item.name)}</b>
          </button>`,
      )
      .join('');
  }

  function drawerHtml() {
    return `<div class="tb-pop" role="dialog" aria-label="Windows-Apps">
      <section class="tb-drawer">
        <header class="drawer-head">
          <div class="drawer-title"><b>Desktop</b><span>Apps, Fenster & Widgets</span></div>
          <label class="drawer-search">${window.icon('search', 13)}<input type="text" placeholder="Durchsuchen" data-drawer-search autocomplete="off" spellcheck="false" /></label>
          <button class="drawer-close" data-act="drawer" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        <div class="drawer-grid" data-drawer-grid>${drawerGrid()}</div>
        <footer class="drawer-foot">
          <button class="drawer-action" data-act="home">${window.icon('home', 13)} Revulution Hub</button>
          <button class="drawer-action" data-act="desktop">${window.icon('grid', 13)} Desktop</button>
          <button class="drawer-action" data-act="control">${window.icon('control', 13)} Kontrollzentrum</button>
          <button class="drawer-action" data-act="settings">${window.icon('settings', 13)} Einstellungen</button>
          <button class="drawer-action danger" data-act="lock">${window.icon('shield', 13)} Sperren</button>
        </footer>
      </section>
    </div>`;
  }

  const fmtDur = (secs) => {
    const min = Math.round((Number(secs) || 0) / 60);
    if (!min) return '0 Min.';
    const h = Math.floor(min / 60);
    const m = min % 60;
    return h ? `${h} Std. ${m} Min.` : `${m} Min.`;
  };

  function screenHtml() {
    const d = screenData;
    const apps = d?.apps?.slice(0, 5) || [];
    const max = Math.max(1, apps[0]?.secs || 1);
    return `<div class="tb-pop tb-screen" role="dialog" aria-label="Bildschirmzeit">
      <section class="tb-drawer tb-screen-card">
        <header class="drawer-head">
          <div class="drawer-title"><b>Bildschirmzeit</b><span>Heute am PC</span></div>
          <button class="drawer-close" data-act="panel-close" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        ${d ? `<div class="tb-sc-total"><b>${fmtDur(d.total)}</b><span>${d.pickups || 0} mal aktiv geworden</span></div>
          <div class="tb-sc-list">${apps.length ? apps.map((a) => `<div class="tb-sc-row"><span>${esc(a.name || a.exe)}</span><b>${fmtDur(a.secs)}</b><i><em style="width:${Math.max(4, Math.round((a.secs / max) * 100))}%"></em></i></div>`).join('') : '<p class="drawer-empty">Heute noch keine Zeit erfasst.</p>'}</div>` : '<p class="drawer-empty">Wird geladen …</p>'}
        <footer class="drawer-foot"><button class="drawer-action" data-act="sc-app">${window.icon('clock', 12)} App öffnen</button></footer>
      </section>
    </div>`;
  }

  async function loadScreenTime() {
    if (screenLoading) return;
    screenLoading = true;
    try {
      screenData = await window.hub.screentime.summary();
    } catch {
      screenData = null;
    } finally {
      screenLoading = false;
      lastKey = '';
      render();
    }
  }

  function render() {
    if (!state) return;
    const panel = state.panel || '';
    const drawer = panel === 'drawer';
    const screen = panel === 'screentime';
    document.body.classList.toggle('drawer-open', Boolean(panel));
    document.title = 'Revulution Leiste';
    // Leiste und Popup getrennt: Ein Klick (Menü auf/zu) baut die Leiste nicht neu auf –
    // sonst lief jedes Mal die Einblend-Animation und alles „blinkte“.
    const barKey = JSON.stringify({ windowsApps: state.windowsApps, badges: state.badges, dnd: state.dnd, topbarItems: state.topbarItems, crosshairOn: state.crosshairOn });
    const popKey = JSON.stringify({ panel, screenTotal: screenData?.total || 0, screenApps: screenData?.apps?.length || 0, apps: drawer ? state.windowsApps?.length : 0 });
    const tb = $('#tb');
    if (!tb.querySelector('.tb-bar') || barKey !== lastKey) {
      const old = tb.querySelector('.tb-bar');
      const fresh = document.createElement('div');
      fresh.innerHTML = barHtml();
      if (old) old.replaceWith(fresh.firstElementChild);
      else tb.prepend(fresh.firstElementChild);
      lastKey = barKey;
    }
    tb.querySelector('.tb-logo')?.classList.toggle('is-open', Boolean(state.drawer));
    if (popKey !== render.popKey) {
      render.popKey = popKey;
      tb.querySelector('.tb-pop')?.remove();
      tb.insertAdjacentHTML('beforeend', screen ? screenHtml() : drawerHtml());
    }
    requestAnimationFrame(() => tb.classList.add('ready'));
    tickClock();
    startClock();
    if (drawer && !drawerWasOpen) {
      setTimeout(() => $('#tb')?.querySelector('[data-drawer-search]')?.focus(), 200);
    }
    if (screen && !screenData) loadScreenTime();
    drawerWasOpen = drawer;
  }

  function locale() {
    return state?.lang === 'en' ? 'en-GB' : state?.lang === 'es' ? 'es-ES' : 'de-DE';
  }

  function tickClock() {
    const now = new Date();
    const time = now.toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' });
    const date = now.toLocaleDateString(locale(), { weekday: 'short', day: 'numeric', month: 'short' });
    document.querySelectorAll('[data-clock-time]').forEach((el) => { el.textContent = time; });
    document.querySelectorAll('[data-clock-date]').forEach((el) => { el.textContent = date; });
  }

  function startClock() {
    clearInterval(clockTimer);
    clockTimer = setInterval(tickClock, 15000);
  }

  function pulse(button) {
    if (!button) return;
    button.classList.remove('pressed');
    void button.offsetWidth;
    button.classList.add('pressed');
    setTimeout(() => button.classList.remove('pressed'), 200);
  }

  function closeDrawer() {
    if (state?.drawer) window.hub.taskbar?.drawer?.(false).catch(() => {});
  }

  document.addEventListener('input', (event) => {
    if (event.target.matches('[data-drawer-search]')) {
      const grid = $('[data-drawer-grid]');
      if (grid) grid.innerHTML = drawerGrid(event.target.value);
    }
  });

  document.addEventListener('click', (event) => {
    const top = event.target.closest('[data-tb-top]');
    if (top) {
      pulse(top);
      const kind = top.dataset.tbTop;
      if (kind === 'crosshair') return window.hub.crosshair?.toggle?.().catch(() => {});
      if (kind === 'screentime') return window.hub.taskbar?.panel?.('screentime').catch(() => {});
      closeDrawer();
      if (kind === 'settings') return window.hub.openSettings?.().catch(() => {});
      return window.hub.open?.('tool-speed').catch(() => {});
    }
    const winApp = event.target.closest('[data-winapp]');
    if (winApp) {
      pulse(winApp);
      closeDrawer();
      window.hub.taskbar?.launch?.(winApp.dataset.winapp).catch(() => {});
      return;
    }
    const action = event.target.closest('[data-act]');
    if (!action) return;
    pulse(action);
    const act = action.dataset.act;
    if (act === 'drawer') return window.hub.taskbar?.drawer?.(!state?.drawer).catch(() => {});
    if (act === 'panel-close') return window.hub.taskbar?.drawer?.(false).catch(() => {});
    if (act === 'sc-app') { closeDrawer(); return window.hub.open('tool-screentime').catch(() => {}); }
    if (act === 'home') { closeDrawer(); return window.hub.open('home').catch(() => {}); }
    if (act === 'desktop') { closeDrawer(); return window.hub.open('tool-desktop').catch(() => {}); }
    if (act === 'control') { closeDrawer(); return window.hub.openControl?.().catch(() => {}); }
    if (act === 'settings') { closeDrawer(); return window.hub.openSettings?.().catch(() => {}); }
    if (act === 'quit') {
      closeDrawer();
      if (window.confirm('Revulution Hub und alle laufenden Aufgaben beenden?')) window.hub.quit?.().catch(() => {});
      return;
    }
    if (act === 'agenda') { closeDrawer(); return window.hub.open('agenda').catch(() => {}); }
    if (act === 'lock') { closeDrawer(); return window.hub.cc?.lock?.().catch(() => {}); }
  });

  document.addEventListener('contextmenu', (event) => {
    const app = event.target.closest?.('[data-winapp]');
    if (!app) return;
    event.preventDefault();
    window.hub.taskbar?.context?.(app.dataset.winapp).catch(() => {});
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeDrawer();
  });

  /* Die Leiste ist oben volle Breite, das Popup nur eine kleine Karte. Der
     transparente Rest des Fensters darf keine Klicks auf den Desktop schlucken. */
  document.addEventListener('mousemove', (event) => {
    const hit = document.elementFromPoint(event.clientX, event.clientY);
    setInteractive(Boolean(hit?.closest('.tb-pill, body.drawer-open .tb-pop')));
  });
  document.addEventListener('mouseleave', () => setInteractive(false));

  async function refreshTone() {
    try {
      const tone = await window.hub.desktopTone?.();
      $('#tb')?.classList.toggle('on-light', tone === 'light');
    } catch {
      /* dunkel bleiben */
    }
  }
  refreshTone();
  setInterval(refreshTone, 2000);

  window.hub.onTaskbar?.((payload) => {
    state = payload || null;
    render();
  });
  window.hub.taskbarReady?.().catch(() => {});
})();
