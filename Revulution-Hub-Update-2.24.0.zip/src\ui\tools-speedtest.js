'use strict';

/* WLAN- und Internettest als eigene App – animierte Ringe, Live-Werte und Verlauf. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const fmt = (v) => (v == null ? '–' : String(v).replace('.', ','));
  const PHASES = { wlan: 'WLAN wird geprüft', ping: 'Ping wird gemessen', down: 'Download wird gemessen', up: 'Upload wird gemessen', done: 'Fertig' };
  const sp = { running: false, phase: '', pct: 0, live: {}, result: null, wlan: undefined, history: null, error: '', loaded: false };

  const active = () => Boolean(document.querySelector('[data-tool-page="tool-speed"]'));

  function load() {
    if (sp.loaded) return;
    sp.loaded = true;
    window.hub.speed.wlan().then((w) => { sp.wlan = w || null; if (active()) ctx().render(); }).catch(() => { sp.wlan = null; });
    window.hub.speed.history().then((h) => { sp.history = Array.isArray(h) ? h : []; if (active()) ctx().render(); }).catch(() => { sp.history = []; });
  }

  function signalBars(sig) {
    return `<span class="sp-wifi" style="--s:${sig >= 65 ? '#4ade80' : sig >= 40 ? '#fbbf24' : '#f87171'}"><i class="${sig >= 25 ? 'a' : ''}"></i><i class="${sig >= 50 ? 'a' : ''}"></i><i class="${sig >= 75 ? 'a' : ''}"></i></span>`;
  }

  function wlanLine() {
    const w = sp.running ? sp.wlan : sp.result?.wlan ?? sp.wlan;
    if (w === undefined) return '<span class="muted">WLAN wird gelesen …</span>';
    if (!w) return '<span class="muted">WLAN-Daten sind auf diesem PC nicht verfügbar.</span>';
    if (!w.connected) return '<span class="muted">Nicht per WLAN verbunden – der Test läuft trotzdem.</span>';
    const sig = Number(w.signal) || 0;
    return `${signalBars(sig)}<b>${esc(w.ssid || 'WLAN')}</b><span>${sig} % Signal</span>${w.band ? `<span>${esc(w.band)}</span>` : ''}${w.rx ? `<span>Funkrate ${fmt(w.rx)} MBit/s</span>` : ''}`;
  }

  function bars() {
    return `<div class="spd-bars ${sp.running ? 'on' : ''}">${Array.from({ length: 28 }, (_, i) => `<i style="height:${18 + Math.abs(Math.sin(i * 1.7)) * 58}%;--d:${i * 28}ms"></i>`).join('')}</div>`;
  }

  function html() {
    load();
    const r = sp.result;
    const live = sp.running ? sp.live : r || {};
    const main = live.down ?? null;
    const pct = sp.running ? Math.max(3, Math.min(100, sp.pct || 0)) : r ? 100 : 0;
    const tips = r && !sp.running
      ? r.tips?.length
        ? r.tips.map((x) => `<div class="pc-issue sev${x.sev || 1}"><b>${esc(x.title)}</b><p>${esc(x.text)}</p></div>`).join('')
        : '<div class="pc-issue ok"><b>Alles bestens</b><p>Signal, Ping und Geschwindigkeit sind gut – da bremst nichts.</p></div>'
      : '';
    const hist = (sp.history || []).slice(0, 6);
    return `<div class="spd-hero">
        <div class="spd-rings ${sp.running ? 'run' : ''}" style="--p:${pct}%">
          <i></i><i></i><i></i>
          <div class="spd-center">
            <b>${fmt(sp.running ? live.down : r?.down)}</b>
            <small>MBit/s Download</small>
            <em>${sp.running ? esc(PHASES[sp.phase] || 'Messung läuft') + ` ${Math.round(sp.pct)} %` : r ? 'Letztes Ergebnis' : 'Bereit für den Test'}</em>
          </div>
        </div>
        ${bars()}
      </div>
      <div class="spd-g3">
        <div class="spd-g ${sp.phase === 'down' ? 'on' : ''}"><span>Download</span><b>${fmt(live.down)}</b><small>MBit/s</small></div>
        <div class="spd-g ${sp.phase === 'up' ? 'on' : ''}"><span>Upload</span><b>${fmt(live.up)}</b><small>MBit/s</small></div>
        <div class="spd-g ${sp.phase === 'ping' ? 'on' : ''}"><span>Ping</span><b>${fmt(live.ping)}</b><small>ms</small></div>
      </div>
      <div class="spd-host">${wlanLine()}</div>
      ${sp.error ? `<p class="spd-error">${esc(sp.error)}</p>` : ''}
      ${r && !sp.running ? `<div class="spd-host"><span>Note</span><b>${esc(r.grade || '–')}</b>${r.jitter != null ? `<span>Schwankung</span><b>${fmt(r.jitter)} ms</b>` : ''}${r.loss ? `<span>Verlust</span><b>${fmt(r.loss)} %</b>` : ''}<button class="btn small primary" data-spd-run style="margin-left:auto">${icon('refresh', 14)} Nochmal testen</button></div>` : ''}
      ${!r && !sp.running ? `<button class="btn primary spd-run" data-spd-run>${icon('bolt', 17)} Test starten</button>` : ''}
      ${sp.running ? `<button class="btn spd-run" disabled>${icon('clock', 17)} ${esc(PHASES[sp.phase] || 'Läuft')} …</button>` : ''}
      ${tips ? `<h4 class="pc-h">Was der Test sagt</h4><div class="spd-tips">${tips}</div>` : ''}
      ${hist.length ? `<h4 class="pc-h">Letzte Tests</h4><div class="sp-history">${hist.map((h) => `<div class="sp-history-row"><span>${new Date(h.at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span><b>↓ ${fmt(h.down)}</b><b>↑ ${fmt(h.up)}</b><b>${fmt(h.ping)} ms</b></div>`).join('')}</div>` : ''}
      <p class="muted sp-note">Gemessen über speed.cloudflare.com. Der Test dauert etwa 20 Sekunden und verbraucht je nach Leitung einige MB.</p>`;
  }

  async function run() {
    if (sp.running) return;
    sp.running = true;
    sp.phase = 'wlan';
    sp.pct = 0;
    sp.live = {};
    sp.error = '';
    ctx().render();
    try {
      const r = await window.hub.speed.run();
      sp.result = r;
      sp.wlan = r?.wlan ?? sp.wlan;
      sp.history = [{ at: r.at, down: r.down, up: r.up, ping: r.ping }, ...(sp.history || [])].slice(0, 10);
      ctx().toast?.('Speedtest fertig.');
    } catch (error) {
      sp.error = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
    sp.running = false;
    sp.phase = '';
    if (active()) ctx().render();
  }

  window.hub.onSpeed?.((p) => {
    if (!active() && !sp.running) return;
    sp.phase = p.phase;
    sp.pct = p.pct || 0;
    if (p.phase === 'ping' && p.value != null) sp.live.ping = Math.round(p.value);
    if (p.phase === 'down' && p.value != null) sp.live.down = p.value;
    if (p.phase === 'up' && p.value != null) sp.live.up = p.value;
    if (active()) ctx().render();
  });

  document.addEventListener('click', (e) => {
    if (!active()) return;
    if (e.target.closest('[data-spd-run]')) run();
  });

  T.register('tool-speed', { nav: 'WLAN-Test', title: 'WLAN-Test', sub: 'Speedtest mit Live-Anzeige', icon: 'globe', tint: 'linear-gradient(135deg,#38bdf8,#0e7490)', desc: 'Download, Upload, Ping und WLAN-Signal in einer animierten Live-Ansicht – mit Verlauf und Tipps.' }, html);
})();
