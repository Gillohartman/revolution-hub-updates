'use strict';
/* 2.45 Klick-Bestätigung: nach jedem Klick auf ein Bedienelement erscheint oben links kurz ein
   grüner Haken, der sich selbst zeichnet – so sieht man, dass der Klick angekommen ist. */
(() => {
  const el = document.createElement('div');
  el.className = 'click-check';
  el.setAttribute('aria-hidden', 'true');
  el.innerHTML = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="11"/><path d="M6.8 12.4l3.4 3.4 7-7.4"/></svg>';
  document.body.appendChild(el);
  let timer = 0;
  const show = () => {
    el.classList.remove('show');
    void el.offsetWidth; // Animation neu starten
    el.classList.add('show');
    clearTimeout(timer);
    timer = setTimeout(() => el.classList.remove('show'), 900);
  };
  document.addEventListener('click', (e) => {
    const t = e.target.closest?.('button, a, [data-open], [role="button"], .switch, input[type="checkbox"], input[type="radio"], select, .hc, .ai');
    if (!t || t.disabled || t.closest('[disabled]') || !e.isTrusted) return;
    show();
  }, true);
  // Klicks in eingebetteten Apps (Gaming Hub, Chats, Dokumente …) kommen über den Hauptprozess
  window.hub?.onClickCheck?.(show);
})();
