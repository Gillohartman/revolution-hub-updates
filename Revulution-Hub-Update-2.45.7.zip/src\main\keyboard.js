'use strict';

/*
 * Tastatur-App: Tasten umbelegen, Kombinationen, Text, Programme, Medien, Makros und
 * Profile pro Spiel/App – für jede Tastatur, weil es auf Windows-Ebene passiert
 * (Low-Level-Tastaturhook in einem kleinen PowerShell/C#-Helfer, nur solange Regeln aktiv sind).
 * Licht und Displays steuern die Herstellerprogramme; die App erkennt sie und öffnet sie.
 */
const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');

const CS = String.raw`
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class RevKeys {
  delegate IntPtr HookProc(int n, IntPtr w, IntPtr l);
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr SetWindowsHookEx(int id, HookProc p, IntPtr h, uint t);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int n, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr h, uint a, uint b);
  [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string n);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", SetLastError=true)] static extern uint SendInput(uint n, INPUT[] i, int size);
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint c, uint t);
  [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr h; public uint m; public IntPtr w, l; public uint t; public int x, y; }
  [StructLayout(LayoutKind.Sequential)] struct KBD { public uint vk, scan, flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct MSLL { public int x, y; public uint data, flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT { public ushort vk, scan; public uint flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx, dy; public uint data, flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] struct UNION { [FieldOffset(0)] public MOUSEINPUT m; [FieldOffset(0)] public KEYBDINPUT k; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public UNION u; }

  class Rule { public HashSet<string> Apps; public int Vk; public string Type; public string Data; }

  static HookProc proc = Hook;
  static volatile Dictionary<int, List<Rule>> rules = new Dictionary<int, List<Rule>>();
  static readonly BlockingCollection<Action> work = new BlockingCollection<Action>();
  static readonly HashSet<int> held = new HashSet<int>();
  static uint lastPid; static string lastExe = ""; static long lastAt;
  static readonly IntPtr Tag = new IntPtr(0x52455648); // markiert eigene Eingaben

  static string Foreground() {
    long now = Environment.TickCount;
    uint pid; GetWindowThreadProcessId(GetForegroundWindow(), out pid);
    if (pid == lastPid && now - lastAt < 400) return lastExe;
    lastPid = pid; lastAt = now;
    try { lastExe = Process.GetProcessById((int)pid).ProcessName.ToLowerInvariant(); } catch { lastExe = ""; }
    return lastExe;
  }

  static Rule Find(int vk) {
    List<Rule> list;
    if (!rules.TryGetValue(vk, out list)) return null;
    string exe = null; Rule global = null;
    foreach (var r in list) {
      if (r.Apps == null) { if (global == null) global = r; continue; }
      if (exe == null) exe = Foreground();
      if (r.Apps.Contains(exe)) return r;
    }
    return global;
  }

  static IntPtr Hook(int n, IntPtr w, IntPtr l) {
    if (n >= 0) {
      var k = (KBD)Marshal.PtrToStructure(l, typeof(KBD));
      // 2.45: auch simulierte Tasten anderer Programme (Stream-Deck-Software sendet so) – nur eigene nicht
      if (k.extra != Tag) {
        int msg = w.ToInt32();
        bool down = msg == 0x100 || msg == 0x104;
        Rule r = Find((int)k.vk);
        if (r != null) {
          bool repeat = down && held.Contains(r.Vk);
          if (down) held.Add(r.Vk); else held.Remove(r.Vk);
          Act(r, down, repeat);
          return (IntPtr)1;
        }
      }
    }
    return CallNextHookEx(IntPtr.Zero, n, w, l);
  }

  // 2.45 Maustasten: Mitte (4), Zurück (5), Vor (6) wie Tasten umbelegen
  static HookProc mproc = MHook;
  static IntPtr MHook(int n, IntPtr w, IntPtr l) {
    if (n >= 0) {
      var m = (MSLL)Marshal.PtrToStructure(l, typeof(MSLL));
      if (m.extra != Tag) {
        int msg = w.ToInt32(); int vk = 0; bool down = false;
        if (msg == 0x207 || msg == 0x208) { vk = 4; down = msg == 0x207; }
        else if (msg == 0x20B || msg == 0x20C) { vk = ((m.data >> 16) & 0xFFFF) == 1 ? 5 : 6; down = msg == 0x20B; }
        if (vk != 0) {
          Rule r = Find(vk);
          if (r != null) {
            bool repeat = down && held.Contains(vk);
            if (down) held.Add(vk); else held.Remove(vk);
            Act(r, down, repeat);
            return (IntPtr)1;
          }
        }
      }
    }
    return CallNextHookEx(IntPtr.Zero, n, w, l);
  }

  static bool IsMouse(int vk) { return vk == 1 || vk == 2 || vk == 4 || vk == 5 || vk == 6; }
  static INPUT MouseInput(int vk, bool up) {
    var i = new INPUT(); i.type = 0;
    uint f = 0; uint data = 0;
    if (vk == 1) f = up ? 0x4u : 0x2u;
    else if (vk == 2) f = up ? 0x10u : 0x8u;
    else if (vk == 4) f = up ? 0x40u : 0x20u;
    else { f = up ? 0x100u : 0x80u; data = vk == 5 ? 1u : 2u; }
    i.u.m.flags = f; i.u.m.data = data; i.u.m.extra = Tag;
    return i;
  }

  static bool Extended(int vk) {
    return (vk >= 0x21 && vk <= 0x28) || vk == 0x2D || vk == 0x2E || vk == 0xA3 || vk == 0xA5 || vk == 0x5B || vk == 0x5C || vk == 0x5D || vk == 0x6F || vk == 0x90 || vk == 0x2C;
  }

  static INPUT KeyInput(int vk, bool up) {
    var i = new INPUT(); i.type = 1;
    bool media = vk >= 0xA6 && vk <= 0xB7;
    i.u.k.vk = (ushort)vk;
    i.u.k.scan = media ? (ushort)0 : (ushort)MapVirtualKey((uint)vk, 0);
    uint f = 0;
    if (!media && i.u.k.scan != 0) f |= 0x8; // Scancode – Spiele lesen den
    if (Extended(vk) || media) f |= 0x1;
    if (up) f |= 0x2;
    i.u.k.flags = f; i.u.k.extra = Tag;
    return i;
  }

  static void Send(params INPUT[] list) { SendInput((uint)list.Length, list, Marshal.SizeOf(typeof(INPUT))); }
  static void Key(int vk, bool up) { Send(IsMouse(vk) ? MouseInput(vk, up) : KeyInput(vk, up)); }

  static void Text(string s) {
    var list = new List<INPUT>();
    foreach (char c in s) {
      if (c == '\n') { list.Add(KeyInput(0x0D, false)); list.Add(KeyInput(0x0D, true)); continue; }
      if (c == '\r') continue;
      var d = new INPUT(); d.type = 1; d.u.k.scan = c; d.u.k.flags = 0x4; d.u.k.extra = Tag;
      var u = d; u.u.k.flags = 0x4 | 0x2;
      list.Add(d); list.Add(u);
    }
    if (list.Count > 0) SendInput((uint)list.Count, list.ToArray(), Marshal.SizeOf(typeof(INPUT)));
  }

  static void Act(Rule r, bool down, bool repeat) {
    switch (r.Type) {
      case "key":
        int to = int.Parse(r.Data);
        work.Add(() => Key(to, !down));
        break;
      case "combo":
        if (!down || repeat) return;
        var parts = r.Data.Split('+');
        work.Add(() => {
          foreach (var p in parts) Key(int.Parse(p), false);
          for (int i = parts.Length - 1; i >= 0; i--) Key(int.Parse(parts[i]), true);
        });
        break;
      case "text":
        if (!down || repeat) return;
        string t = Encoding.UTF8.GetString(Convert.FromBase64String(r.Data));
        work.Add(() => Text(t));
        break;
      case "run":
        if (!down || repeat) return;
        string target = Encoding.UTF8.GetString(Convert.FromBase64String(r.Data));
        work.Add(() => { try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); } catch (Exception e) { Console.Out.WriteLine("err " + e.Message); } });
        break;
      case "macro":
        if (!down || repeat) return;
        var steps = r.Data.Split(',');
        work.Add(() => {
          // 2.45: r<n> am Anfang = n-mal wiederholen; c<vk> = Mausklick
          int times = 1;
          if (steps.Length > 0 && steps[0].Length > 1 && steps[0][0] == 'r') times = Math.Max(1, Math.Min(500, int.Parse(steps[0].Substring(1))));
          for (int rep = 0; rep < times; rep++) {
            foreach (var s in steps) {
              if (s.Length < 2 || s[0] == 'r') continue;
              if (s[0] == 'w') { Thread.Sleep(Math.Min(60000, int.Parse(s.Substring(1)))); continue; }
              int vk = int.Parse(s.Substring(1));
              if (s[0] == 'd') Key(vk, false);
              else if (s[0] == 'u') Key(vk, true);
              else { Key(vk, false); Thread.Sleep(15); Key(vk, true); }
            }
          }
        });
        break;
      case "hub":
        // 2.45: Aktion im Hub auslösen (Stream-Deck-Studio: Screenshot, Sound, Spotify …)
        if (!down || repeat) return;
        Console.Out.WriteLine("act " + r.Data);
        break;
      default: break; // "off": Taste schlucken
    }
    if (down && !repeat) Console.Out.WriteLine("hit " + r.Vk);
  }

  static void ReadInput() {
    var next = new Dictionary<int, List<Rule>>();
    string line;
    while ((line = Console.In.ReadLine()) != null) {
      if (line == "CLEAR") { next = new Dictionary<int, List<Rule>>(); continue; }
      if (line == "END") { rules = next; held.Clear(); Console.Out.WriteLine("ready " + next.Count); continue; }
      if (line == "QUIT") break;
      if (!line.StartsWith("RULE ")) continue;
      var p = line.Split(' ');
      if (p.Length < 5) continue;
      var r = new Rule();
      r.Apps = p[1] == "*" ? null : new HashSet<string>(p[1].ToLowerInvariant().Split(','));
      r.Vk = int.Parse(p[2]); r.Type = p[3]; r.Data = p[4];
      List<Rule> list;
      if (!next.TryGetValue(r.Vk, out list)) { list = new List<Rule>(); next[r.Vk] = list; }
      if (r.Apps == null) list.Add(r); else list.Insert(0, r);
    }
    Environment.Exit(0);
  }

  public static void Run(bool mouse) {
    Console.Out.Flush();
    var reader = new Thread(ReadInput); reader.IsBackground = true; reader.Start();
    var worker = new Thread(() => { foreach (var a in work.GetConsumingEnumerable()) { try { a(); } catch { } } });
    worker.IsBackground = true; worker.Start();
    IntPtr hook = SetWindowsHookEx(13, proc, GetModuleHandle(null), 0);
    if (hook == IntPtr.Zero) { Console.Out.WriteLine("err hook " + Marshal.GetLastWin32Error()); return; }
    // Maus-Hook nur, wenn Maustasten umbelegt sind (jede Mausbewegung läuft sonst unnötig hier durch)
    if (mouse && SetWindowsHookEx(14, mproc, GetModuleHandle(null), 0) == IntPtr.Zero) Console.Out.WriteLine("err mousehook " + Marshal.GetLastWin32Error());
    Console.Out.WriteLine("hooked");
    MSG m;
    while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) { }
  }
}
`;

/** KeyboardEvent.code → virtueller Windows-Tastencode. */
const NAMED = {
  Space: 0x20, Enter: 0x0d, NumpadEnter: 0x0d, Tab: 0x09, Escape: 0x1b, Backspace: 0x08, Delete: 0x2e, Insert: 0x2d, Home: 0x24, End: 0x23, PageUp: 0x21, PageDown: 0x22,
  ArrowLeft: 0x25, ArrowUp: 0x26, ArrowRight: 0x27, ArrowDown: 0x28, ShiftLeft: 0xa0, ShiftRight: 0xa1, ControlLeft: 0xa2, ControlRight: 0xa3, AltLeft: 0xa4, AltRight: 0xa5,
  MetaLeft: 0x5b, MetaRight: 0x5c, ContextMenu: 0x5d, CapsLock: 0x14, NumLock: 0x90, ScrollLock: 0x91, Pause: 0x13, PrintScreen: 0x2c,
  Comma: 0xbc, Period: 0xbe, Minus: 0xbd, Equal: 0xbb, Semicolon: 0xba, Slash: 0xbf, Backquote: 0xc0, BracketLeft: 0xdb, BracketRight: 0xdd, Backslash: 0xdc, Quote: 0xde, IntlBackslash: 0xe2,
  NumpadMultiply: 0x6a, NumpadAdd: 0x6b, NumpadSubtract: 0x6d, NumpadDecimal: 0x6e, NumpadDivide: 0x6f,
  MediaPlayPause: 0xb3, MediaTrackNext: 0xb0, MediaTrackPrevious: 0xb1, MediaStop: 0xb2, AudioVolumeMute: 0xad, AudioVolumeDown: 0xae, AudioVolumeUp: 0xaf,
  // 2.45 Maustasten (als Ziel überall, als Auslöser nur Mitte/Zurück/Vor)
  MouseLeft: 0x01, MouseRight: 0x02, MouseMiddle: 0x04, MouseBack: 0x05, MouseForward: 0x06,
};
const MOUSE_FROM = new Set([0x04, 0x05, 0x06]);
const CLICK = { left: 0x01, right: 0x02, middle: 0x04, back: 0x05, forward: 0x06 };
function vkOf(code) {
  const c = String(code || '');
  let m;
  if ((m = /^Key([A-Z])$/.exec(c))) return m[1].charCodeAt(0);
  if ((m = /^Digit(\d)$/.exec(c))) return 0x30 + Number(m[1]);
  if ((m = /^Numpad(\d)$/.exec(c))) return 0x60 + Number(m[1]);
  if ((m = /^F(\d{1,2})$/.exec(c)) && Number(m[1]) >= 1 && Number(m[1]) <= 24) return 0x6f + Number(m[1]);
  return NAMED[c] || 0;
}
const MEDIA = { play: 0xb3, next: 0xb0, prev: 0xb1, stop: 0xb2, mute: 0xad, voldown: 0xae, volup: 0xaf };
const TYPES = ['key', 'combo', 'text', 'run', 'media', 'macro', 'off', 'hub'];

const b64 = (s) => Buffer.from(String(s || ''), 'utf8').toString('base64');
const exeName = (s) =>
  String(s || '')
    .trim()
    .replace(/^.*[\\/]/, '')
    .replace(/\.exe$/i, '')
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, '');

/** Einstellungen säubern: { enabled, profiles: [{ id, name, apps, on, rules: [...] }] } */
function clean(raw = {}) {
  const profiles = (Array.isArray(raw.profiles) ? raw.profiles : []).slice(0, 30).map((p, i) => ({
    id: String(p?.id || `p${Date.now().toString(36)}${i}`).slice(0, 40),
    name: String(p?.name || 'Profil').slice(0, 40),
    apps: (Array.isArray(p?.apps) ? p.apps : []).map(exeName).filter(Boolean).slice(0, 20),
    on: p?.on !== false,
    rules: (Array.isArray(p?.rules) ? p.rules : []).slice(0, 120).map((r) => ({
      from: String(r?.from || '').slice(0, 30),
      type: TYPES.includes(r?.type) ? r.type : 'key',
      to: r?.type === 'combo' || r?.type === 'macro' ? (Array.isArray(r?.to) ? r.to.slice(0, 80) : []) : String(r?.to ?? '').slice(0, 2000),
      on: r?.on !== false,
    })),
  }));
  if (!profiles.length) profiles.push({ id: 'global', name: 'Überall', apps: [], on: true, rules: [] });
  return { enabled: raw.enabled === true, profiles };
}

/** Regeln in Zeilen für den Helfer übersetzen. */
function compile(cfg) {
  const lines = [];
  for (const p of cfg.profiles) {
    if (!p.on) continue;
    const apps = p.apps.length ? p.apps.join(',') : '*';
    for (const r of p.rules) {
      if (!r.on) continue;
      const vk = vkOf(r.from);
      if (!vk) continue;
      let type = r.type;
      let data = '0';
      if (type === 'key') {
        const to = vkOf(r.to);
        if (!to) continue;
        data = String(to);
      } else if (type === 'combo') {
        const keys = r.to.map(vkOf).filter(Boolean);
        if (!keys.length) continue;
        data = keys.join('+');
      } else if (type === 'media') {
        const to = MEDIA[r.to];
        if (!to) continue;
        type = 'key';
        data = String(to);
      } else if (type === 'hub') {
        data = String(r.to || '').replace(/[^a-z0-9-]/gi, '').slice(0, 40);
        if (!data) continue;
      } else if (type === 'text' || type === 'run') {
        if (!r.to) continue;
        data = b64(r.to);
      } else if (type === 'macro') {
        const steps = r.to
          .map((s, idx) => {
            if (s && typeof s === 'object' && Number(s.repeat) > 1 && idx === 0) return `r${Math.min(500, Math.round(Number(s.repeat)))}`;
            if (s && typeof s === 'object' && Number(s.wait) > 0) return `w${Math.min(60000, Math.round(Number(s.wait)))}`;
            if (s && typeof s === 'object' && CLICK[s.click]) return `p${CLICK[s.click]}`;
            const k = vkOf(s?.key);
            if (!k) return '';
            return `${s.act === 'down' ? 'd' : s.act === 'up' ? 'u' : 'p'}${k}`;
          })
          .filter(Boolean);
        if (!steps.length) continue;
        data = steps.join(',');
      }
      lines.push(`RULE ${apps} ${vk} ${type} ${data}`);
    }
  }
  return lines;
}

/* Bekannte Hersteller (USB-Hersteller-ID) und ihre Programme für Licht/Display */
const VENDORS = {
  '0C45': 'AJAZZ / Sonix', '046D': 'Logitech', '1532': 'Razer', '1B1C': 'Corsair', '1038': 'SteelSeries', '0951': 'HyperX', '03F0': 'HyperX', '31E3': 'Wooting', '3434': 'Keychron',
  '258A': 'Sinowealth', '05AC': 'Apple', '045E': 'Microsoft', '1A2C': 'China-Tastatur', '320F': 'Glorious', '0B05': 'ASUS ROG', '1EA7': 'SHARKOON', '04D9': 'Holtek', '2207': 'Rockchip-Gerät',
};
const TOOLS = [
  { id: 'ajazz', name: 'AJAZZ AK820 Pro', what: 'Licht, Display, Makros im Speicher', paths: ['C:\\Program Files (x86)\\AJAZZ AK820Pro\\DeviceDriver.exe'] },
  { id: 'ghub', name: 'Logitech G HUB', what: 'Licht und Tasten bei Logitech', paths: ['C:\\Program Files\\LGHUB\\system_tray\\lghub_system_tray.exe', 'C:\\Program Files\\LGHUB\\lghub.exe'] },
  { id: 'signalrgb', name: 'SignalRGB', what: 'RGB für viele Marken gleichzeitig', paths: ['%LOCALAPPDATA%\\VortxEngine\\SignalRgbLauncher.exe', '%LOCALAPPDATA%\\VortxEngine\\SignalRgb.exe'] },
  { id: 'openrgb', name: 'OpenRGB', what: 'Freies RGB für viele Marken', paths: ['C:\\Program Files\\OpenRGB\\OpenRGB.exe', '%LOCALAPPDATA%\\Programs\\OpenRGB\\OpenRGB.exe'] },
  { id: 'synapse', name: 'Razer Synapse', what: 'Licht und Tasten bei Razer', paths: ['C:\\Program Files (x86)\\Razer\\Synapse3\\WPFUI\\Framework\\Razer Synapse 3 Host\\Razer Synapse 3.exe', 'C:\\Program Files\\Razer\\RazerAppEngine\\RazerAppEngine.exe'] },
  { id: 'icue', name: 'Corsair iCUE', what: 'Licht und Tasten bei Corsair', paths: ['C:\\Program Files\\Corsair\\Corsair iCUE5 Software\\iCUE Launcher.exe', 'C:\\Program Files\\Corsair\\CORSAIR iCUE 5 Software\\iCUE Launcher.exe'] },
  { id: 'gg', name: 'SteelSeries GG', what: 'Licht und Tasten bei SteelSeries', paths: ['C:\\Program Files\\SteelSeries\\GG\\SteelSeriesGG.exe'] },
  { id: 'armoury', name: 'Armoury Crate', what: 'ASUS-Beleuchtung (Aura)', paths: ['C:\\Program Files\\ASUS\\ArmouryDevice\\ArmouryCrate.exe'] },
  { id: 'ulanzi', name: 'Ulanzi Studio', what: 'Ulanzi Stream Deck (Tasten-Bilder, Hotkeys)', paths: ['C:\\Program Files\\Ulanzi Studio\\Ulanzi Studio.exe', 'C:\\Program Files (x86)\\Ulanzi Studio\\Ulanzi Studio.exe', '%LOCALAPPDATA%\\Programs\\Ulanzi Studio\\Ulanzi Studio.exe', 'C:\\Program Files\\UlanziStudio\\UlanziStudio.exe'] },
  { id: 'wootility', name: 'Wootility', what: 'Wooting-Tastaturen', paths: ['%LOCALAPPDATA%\\Programs\\wootility-lekker\\Wootility Lekker.exe', '%LOCALAPPDATA%\\Programs\\wootility\\Wootility.exe'] },
];
const expand = (p) => p.replace(/%([^%]+)%/g, (_m, v) => process.env[v] || '');

class Keyboard {
  constructor({ dir, getConfig, onChange }) {
    this.dir = dir;
    this.getConfig = getConfig;
    this.onChange = onChange || (() => {});
    this.child = null;
    this.ready = false;
    this.error = '';
    this.hits = 0;
    this.lastHit = 0;
  }

  status() {
    const cfg = clean(this.getConfig());
    return { enabled: cfg.enabled, running: Boolean(this.child) && this.ready, rules: compile(cfg).length, error: this.error, hits: this.hits };
  }

  /** Helfer starten/neu laden – nur wenn eingeschaltet und Regeln da sind. */
  apply() {
    const cfg = clean(this.getConfig());
    const lines = compile(cfg);
    if (!cfg.enabled || !lines.length) {
      this.stop();
      return this.status();
    }
    // Maus-Hook nur bei umbelegten Maustasten – ändert sich das, Helfer neu starten
    const mouse = lines.some((l) => MOUSE_FROM.has(Number(l.split(' ')[2])));
    if (this.child && this.mouse !== mouse) this.stop();
    if (!this.child) this.spawn(mouse);
    this.child.stdin.write(['CLEAR', ...lines, 'END', ''].join('\n'));
    return this.status();
  }

  spawn(mouse = false) {
    this.mouse = mouse;
    const file = path.join(this.dir, 'keyboard-helper.ps1');
    const script = `$ErrorActionPreference='Stop'\r\nAdd-Type -TypeDefinition @'\r\n${CS}\r\n'@\r\n[RevKeys]::Run($${mouse ? 'true' : 'false'})\r\n`;
    fs.mkdirSync(this.dir, { recursive: true });
    fs.writeFileSync(file, `\ufeff${script}`, 'utf8');
    this.ready = false;
    this.error = '';
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    this.child = child;
    let err = '';
    child.stdout.on('data', (buf) => {
      for (const line of String(buf).split(/\r?\n/)) {
        if (line.startsWith('act ')) {
          this.onAction?.(line.slice(4).trim());
          continue;
        }
        if (line === 'hooked' || line.startsWith('ready')) this.ready = true;
        else if (line.startsWith('hit ')) {
          this.hits += 1;
          if (Date.now() - this.lastHit < 300) continue;
          this.lastHit = Date.now();
        } else if (line.startsWith('err ')) this.error = line.slice(4);
        else continue;
        this.onChange(this.status());
      }
    });
    child.stderr.on('data', (d) => (err += d));
    child.on('exit', () => {
      if (this.child !== child) return;
      this.child = null;
      this.ready = false;
      if (err.trim()) this.error = err.trim().split(/\r?\n/)[0].slice(0, 200);
      this.onChange(this.status());
    });
    child.stdin.on('error', () => {});
  }

  stop() {
    const c = this.child;
    this.child = null;
    this.ready = false;
    if (c) {
      try {
        c.stdin.write('QUIT\n');
      } catch {
        /* egal */
      }
      setTimeout(() => {
        try {
          c.kill();
        } catch {
          /* egal */
        }
      }, 500);
    }
    this.onChange(this.status());
    return this.status();
  }

  /** Angeschlossene Tastaturen (Windows-Geräteliste) und Hersteller-Programme. */
  devices() {
    const ps = `$all = Get-PnpDevice -PresentOnly; $all | Where-Object { $_.Class -eq 'Keyboard' } | ForEach-Object { $p = $_.InstanceId -replace '^HID\\\\',''; $root = ($_.InstanceId -split '\\\\')[1]; $usb = $all | Where-Object { $_.InstanceId -like ('USB\\' + ($root -replace '&MI_.*','') + '*') -and $_.Class -eq 'USB' } | Select-Object -First 1; $desc = if ($usb) { (Get-PnpDeviceProperty -InstanceId $usb.InstanceId -KeyName DEVPKEY_Device_BusReportedDeviceDesc -ErrorAction SilentlyContinue).Data } else { '' }; [pscustomobject]@{ id = $_.InstanceId; name = $_.FriendlyName; bus = $desc } } | ConvertTo-Json -Compress`;
    return new Promise((resolve) => {
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 20000 }, (_e, out) => {
        let list = [];
        try {
          list = JSON.parse(String(out || '[]'));
          if (!Array.isArray(list)) list = [list];
        } catch {
          list = [];
        }
        const seen = new Map();
        for (const d of list) {
          const m = /VID_([0-9A-F]{4})&PID_([0-9A-F]{4})/i.exec(d?.id || '');
          if (!m) continue;
          const key = `${m[1]}:${m[2]}`.toUpperCase();
          if (seen.has(key)) continue;
          const vid = m[1].toUpperCase();
          let name = d.bus || '';
          if (vid === '0C45' && /FDFD|8009|800A|FEFE/i.test(m[2])) name = 'AJAZZ AK820 Pro';
          if (vid === '046D' && m[2].toUpperCase() === 'C232') continue; // virtuelle G-HUB-Tastatur
          const wireless = /dongle|receiver|2\.4|unifying|lightspeed/i.test(name) || ['FDFD', 'C547', 'C539', 'C548'].includes(m[2].toUpperCase());
          seen.set(key, { vid, pid: m[2].toUpperCase(), vendor: VENDORS[vid] || 'Unbekannter Hersteller', name: name || VENDORS[vid] || 'Tastatur', wireless });
        }
        const tools = TOOLS.map((t) => {
          const hit = t.paths.map(expand).find((p) => p && fs.existsSync(p));
          return { id: t.id, name: t.name, what: t.what, installed: Boolean(hit), path: hit || '' };
        });
        resolve({ keyboards: [...seen.values()], tools });
      });
    });
  }

  /** 2.45 Angeschlossene Mäuse (für das Maus-Studio). */
  mice() {
    const ps = `Get-PnpDevice -PresentOnly -Class Mouse | ForEach-Object { [pscustomobject]@{ id = $_.InstanceId; name = $_.FriendlyName } } | ConvertTo-Json -Compress`;
    return new Promise((resolve) => {
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 15000 }, (_e, out) => {
        let list = [];
        try {
          list = JSON.parse(String(out || '[]'));
          if (!Array.isArray(list)) list = [list];
        } catch {
          list = [];
        }
        const seen = new Map();
        for (const d of list) {
          const m = /VID_([0-9A-F]{4})&PID_([0-9A-F]{4})/i.exec(d?.id || '');
          const key = m ? `${m[1]}:${m[2]}`.toUpperCase() : d?.id;
          if (!key || seen.has(key)) continue;
          const vid = m?.[1]?.toUpperCase() || '';
          seen.set(key, { vid, pid: m?.[2]?.toUpperCase() || '', vendor: VENDORS[vid] || (vid ? 'Unbekannter Hersteller' : 'Eingebaut / Bluetooth'), name: d.name || 'Maus', logitech: vid === '046D' });
        }
        const ghub = TOOLS.find((t) => t.id === 'ghub').paths.map(expand).some((p) => p && fs.existsSync(p));
        resolve({ mice: [...seen.values()], ghub });
      });
    });
  }

  openTool(id) {
    const t = TOOLS.find((x) => x.id === id);
    const p = t?.paths.map(expand).find((x) => x && fs.existsSync(x));
    if (!p) throw new Error('Programm nicht gefunden');
    spawn(p, [], { detached: true, stdio: 'ignore', cwd: path.dirname(p) }).unref();
    return true;
  }
}

module.exports = { Keyboard, clean, compile, vkOf };
