'use strict';
/* 2.45 Symbole der neuen Apps – gleiche Machart wie app-art.js (48×48, weiß auf Farbkachel). */
(() => {
  const ART = window.APP_ART;
  if (!ART) return;
  const W = 'fill="#fff"';
  const C = 'fill="currentColor"';
  const wl = (d, w = 3.2, extra = '') => `<path d="${d}" fill="none" stroke="#fff" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
  const cl = (d, w = 2.4, extra = '') => `<path d="${d}" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
  Object.assign(ART, {
    // 2.45 Weltansicht: eigenes Logo – Globus mit gekippter Umlaufbahn und Satellit
    worldview: ['#7c6cff', '#0e7490', `<circle cx="24" cy="24" r="14.5" ${W}/><path d="M9.6 24h28.8M24 9.6c4.4 4 6.6 8.8 6.6 14.4S28.4 34 24 38.4c-4.4-4.4-6.6-8.8-6.6-14.4S19.6 13.6 24 9.6Z" fill="none" stroke="currentColor" stroke-width="2" opacity=".55"/><ellipse cx="24" cy="24" rx="21" ry="7.5" transform="rotate(-24 24 24)" fill="none" stroke="#fff" stroke-width="2.2" opacity=".9"/><circle cx="41.5" cy="15.2" r="3.4" fill="#ff3b30" stroke="#fff" stroke-width="1.6"/>`],
    // 2.45 Schach: goldener König wie im Referenzbild (Verlauf + Glanzkante)
    chess: ['#3b3f58', '#14151f', `<defs><linearGradient id="rvChessG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3c4"/><stop offset=".45" stop-color="#f3c969"/><stop offset="1" stop-color="#a86b18"/></linearGradient><linearGradient id="rvChessS" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".5" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>
      <path d="M22.6 4.5h2.8v2.6H28v2.6h-2.6v2.5h-2.8V9.7H20V7.1h2.6Z" fill="url(#rvChessG)"/>
      <path d="M24 12.6c3.4 0 5.9 2.2 5.9 5.2 0 2.1-1.2 3.6-2.9 4.6h1.6c.9 0 1.5.7 1.5 1.5s-.6 1.5-1.5 1.5h-.9l1.6 8.7H18.7l1.6-8.7h-.9c-.9 0-1.5-.7-1.5-1.5s.6-1.5 1.5-1.5H21c-1.7-1-2.9-2.5-2.9-4.6 0-3 2.5-5.2 5.9-5.2Z" fill="url(#rvChessG)"/>
      <path d="M14.5 35.6h19c1 0 1.8.8 1.8 1.8v1.4h1c.9 0 1.6.7 1.6 1.6v1.1H10.1v-1.1c0-.9.7-1.6 1.6-1.6h1v-1.4c0-1 .8-1.8 1.8-1.8Z" fill="url(#rvChessG)"/>
      <path d="M20.3 13.6c-1.3.9-2.1 2.4-2.1 4.2 0 1.4.6 2.6 1.6 3.4" fill="none" stroke="url(#rvChessS)" stroke-width="1.4" stroke-linecap="round"/>
      <ellipse cx="24" cy="42.6" rx="13" ry="1.4" fill="#000" opacity=".35"/>`],
    // Wordle: 3×2 Buchstabenkästchen, grün/gelb
    'tool-wordle': ['#4ade80', '#0f766e', `${[0, 1, 2].map((c) => `<rect x="${7 + c * 12}" y="10" width="10" height="10" rx="2.5" fill="${['#30d158', '#e6b422', '#fff'][c]}"/>`).join('')}${[0, 1, 2].map((c) => `<rect x="${7 + c * 12}" y="23" width="10" height="10" rx="2.5" ${W} opacity="${c === 0 ? 1 : 0.55}"/>`).join('')}<rect x="7" y="36" width="34" height="4" rx="2" ${W} opacity=".35"/>`],
    // Size It Up: großes und kleines Objekt mit Maßstab
    'tool-sizeup': ['#fbbf24', '#7c3aed', `<rect x="25" y="9" width="14" height="27" rx="3" ${W}/><circle cx="14" cy="30" r="6" ${W} opacity=".75"/>${wl('M6 40.5h36', 2.6)}${wl('M43 9v27M41 9h4M41 36h4', 2)}`],
    // Tiefgang: Taucherbrille mit Blasen
    'tool-deepdive': ['#38bdf8', '#1e1b4b', `<path d="M8 19c0-3 2.5-5 5.5-5h21c3 0 5.5 2 5.5 5v6c0 3-2.5 5-5.5 5h-5l-2.5-3.5h-6L18.5 30h-5C10.5 30 8 28 8 25Z" ${W}/><circle cx="16.5" cy="22" r="4.5" ${C} opacity=".55"/><circle cx="31.5" cy="22" r="4.5" ${C} opacity=".55"/><circle cx="34" cy="38" r="2.6" ${W} opacity=".7"/><circle cx="27" cy="41" r="1.8" ${W} opacity=".5"/><circle cx="38.5" cy="33" r="1.5" ${W} opacity=".5"/>`],
    // Zeichnen: Pinsel mit Strich
    'tool-draw': ['#f472b6', '#9333ea', `<path d="M33.5 6.5l8 8-17 17-8-8Z" ${W}/><path d="M16.5 23.5l8 8c-1 5-5 9-11.5 9.5-2 .2-3.6-.3-5-1 2.4-1.7 2.5-4 2.6-6.4.2-5 3-8.9 5.9-10.1Z" ${W} opacity=".8"/>${cl('M29 11l8 8', 2)}`],
    // Präsentation: Folie auf Stativ
    'tool-slides': ['#fb923c', '#c2410c', `<rect x="6" y="8" width="36" height="24" rx="3.5" ${W}/>${wl('M24 32v8M17 41l7-4 7 4', 2.8)}<rect x="11" y="13" width="15" height="3.4" rx="1.7" ${C} opacity=".7"/><rect x="11" y="19.5" width="10" height="2.6" rx="1.3" ${C} opacity=".45"/><path d="M27.5 27l4.5-7 4.5 7Z" ${C} opacity=".6"/>`],
    // Task-Manager: Aktivitätskurve in einem Fenster
    'tool-taskman': ['#34d399', '#065f46', `<rect x="6" y="8" width="36" height="32" rx="5" ${W}/>${cl('M10.5 29h6l3.5-9 5 15 4-10 3 4h5.5', 2.8)}`],
    // Lüfter: Rotor
    'tool-fans': ['#67e8f9', '#0e7490', `<circle cx="24" cy="24" r="17.5" ${W} opacity=".25"/>${[0, 90, 180, 270].map((a) => `<path d="M24 24c-2-7-.5-13 5-14.5 4-1 6 3 3.5 6.5-2.4 3.4-5.2 5.6-8.5 8Z" ${W} transform="rotate(${a} 24 24)"/>`).join('')}<circle cx="24" cy="24" r="3.2" ${C}/>`],
    // Stream-Deck-Studio: 3×2 Tasten mit Symbolen
    'tool-streamdeck': ['#818cf8', '#312e81', `${[0, 1, 2].flatMap((c) => [0, 1].map((r) => `<rect x="${6 + c * 12.5}" y="${10 + r * 15}" width="10.5" height="12.5" rx="3" ${W} opacity="${(c + r) % 2 ? 0.7 : 1}"/>`)).join('')}<path d="M10 14.5v4l3.5-2Z" ${C}/><circle cx="23.5" cy="31.2" r="2.4" ${C}/><rect x="33.5" y="14" width="5" height="5" rx="1.2" ${C}/>`],
    // Clips: Aufnahmepunkt in Filmstreifen
    'tool-clips': ['#fb7185', '#9f1239', `<rect x="5.5" y="11" width="37" height="26" rx="5" ${W}/>${[0, 1, 2, 3, 4].map((i) => `<rect x="${9 + i * 7}" y="13" width="3.6" height="3" rx="1" ${C} opacity=".5"/><rect x="${9 + i * 7}" y="32" width="3.6" height="3" rx="1" ${C} opacity=".5"/>`).join('')}<circle cx="24" cy="24" r="5.2" fill="#ff375f"/>`],
  });
})();
