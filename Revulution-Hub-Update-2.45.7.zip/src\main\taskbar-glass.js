'use strict';

/*
 * 2.45 Eigene durchsichtige Windows-Taskleiste (ersetzt TranslucentTB): ein kleiner C#-Helfer setzt
 * über SetWindowCompositionAttribute die Akzent-Füllung aller Taskleisten (Haupt- und Zweitmonitor)
 * und wiederholt das laufend, weil Windows die Füllung bei Startmenü, Maximieren usw. zurücksetzt.
 * Modi: clear (ganz durchsichtig), blur (verschwommen), acrylic (Acryl), normal (Windows-Standard).
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CS = String.raw`
using System;
using System.Runtime.InteropServices;
using System.Threading;
public static class RevTaskbarGlass {
  [StructLayout(LayoutKind.Sequential)] struct ACCENT { public int State; public int Flags; public uint Color; public int Anim; }
  [StructLayout(LayoutKind.Sequential)] struct WCAD { public int Attr; public IntPtr Data; public int Size; }
  [DllImport("user32.dll")] static extern int SetWindowCompositionAttribute(IntPtr h, ref WCAD d);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p, IntPtr after, string cls, string title);
  static void Apply(IntPtr h, int state, uint color) {
    var a = new ACCENT { State = state, Flags = 2, Color = color };
    int size = Marshal.SizeOf(a);
    IntPtr p = Marshal.AllocHGlobal(size);
    Marshal.StructureToPtr(a, p, false);
    var d = new WCAD { Attr = 19, Data = p, Size = size };
    SetWindowCompositionAttribute(h, ref d);
    Marshal.FreeHGlobal(p);
  }
  static void All(int state, uint color) {
    IntPtr t = FindWindowEx(IntPtr.Zero, IntPtr.Zero, "Shell_TrayWnd", null);
    if (t != IntPtr.Zero) Apply(t, state, color);
    IntPtr s = IntPtr.Zero;
    while ((s = FindWindowEx(IntPtr.Zero, s, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero) Apply(s, state, color);
  }
  public static void Run(int state, uint color) {
    var reader = new Thread(() => { string l; while ((l = Console.In.ReadLine()) != null) { if (l == "QUIT") break; } All(0, 0); Environment.Exit(0); });
    reader.IsBackground = true; reader.Start();
    Console.Out.WriteLine("ok");
    while (true) { All(state, color); Thread.Sleep(120); }
  }
}
`;
// AccentState: 2 = Verlauf (mit Alpha → ganz durchsichtig), 3 = Unschärfe, 4 = Acryl
const MODES = { clear: [2, 0x00000000], blur: [3, 0x10000000], acrylic: [4, 0x40101010] };

class TaskbarGlass {
  constructor(dir) {
    this.dir = dir;
    this.child = null;
    this.mode = 'normal';
  }

  set(mode) {
    this.stop();
    this.mode = MODES[mode] ? mode : 'normal';
    if (this.mode === 'normal' || process.platform !== 'win32') return this.mode;
    const [state, color] = MODES[this.mode];
    const file = path.join(this.dir, 'taskbar-glass.ps1');
    fs.mkdirSync(this.dir, { recursive: true });
    fs.writeFileSync(file, `﻿$ErrorActionPreference='Stop'\r\nAdd-Type -TypeDefinition @'\r\n${CS}\r\n'@\r\n[RevTaskbarGlass]::Run(${state}, ${color})\r\n`, 'utf8');
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], { windowsHide: true, stdio: ['pipe', 'ignore', 'ignore'] });
    child.stdin.on('error', () => {});
    child.on('exit', () => {
      if (this.child === child) this.child = null;
    });
    this.child = child;
    return this.mode;
  }

  stop() {
    const c = this.child;
    this.child = null;
    if (!c) return;
    try {
      c.stdin.write('QUIT\n'); // Helfer setzt die Taskleiste vor dem Beenden auf Standard zurück
    } catch {
      /* egal */
    }
    setTimeout(() => {
      try {
        c.kill();
      } catch {
        /* egal */
      }
    }, 800);
  }
}

module.exports = { TaskbarGlass, MODES };
