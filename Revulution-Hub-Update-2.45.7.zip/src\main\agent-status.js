'use strict';
/**
 * Weitere KI-Agenten fürs Deck (2.45.5): ChatGPT/Codex und Freebuff – mit echtem App-Logo und Status.
 *   ChatGPT/Codex  liest ~/.codex/sessions (Ereignisse task_started / task_complete / Rückfragen) → arbeitet, fertig, Frage
 *   Freebuff       hat kein lesbares Protokoll → geschätzt über die Prozessorlast der App: läuft + rechnet = arbeitet
 * Logos: Store-Apps (Claude, ChatGPT/Codex) aus dem Paket, Desktop-Apps (Freebuff) über die Startmenü-Verknüpfung.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const { app, nativeImage } = require('electron');

const ps = (script, timeout = 15000) => new Promise((resolve) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `[Console]::OutputEncoding=[Text.Encoding]::UTF8; ${script}`], { windowsHide: true, timeout, maxBuffer: 4 * 1024 * 1024 }, (err, out) => resolve(err ? '' : String(out || '').trim())));

/* ---------------------------------------------------------------- Logos */
let logoCache = null;
async function storeLogo(pkg) {
  const out = await ps(`$p = Get-AppxPackage -Name '${pkg}' -ErrorAction SilentlyContinue | Select-Object -First 1; if ($p) { $m = [xml](Get-Content (Join-Path $p.InstallLocation 'AppxManifest.xml')); $l = $m.Package.Properties.Logo; $base = Join-Path $p.InstallLocation ([IO.Path]::GetDirectoryName($l)); $name = [IO.Path]::GetFileNameWithoutExtension($l); $f = Get-ChildItem $base -Filter ($name + '*.png') -ErrorAction SilentlyContinue | Sort-Object Length -Descending | Select-Object -First 1; if ($f) { $f.FullName } }`);
  if (!out || !fs.existsSync(out)) return null;
  const img = nativeImage.createFromPath(out);
  return img.isEmpty() ? null : img.resize({ width: 128, height: 128, quality: 'best' }).toDataURL();
}
async function shortcutLogo(name) {
  const target = await ps(`$sh = New-Object -ComObject WScript.Shell; $dirs = @([Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('CommonPrograms')); $l = Get-ChildItem $dirs -Recurse -Filter '*.lnk' -ErrorAction SilentlyContinue | Where-Object { $_.BaseName -match '${name}' } | Select-Object -First 1; if ($l) { $sh.CreateShortcut($l.FullName).TargetPath }`);
  if (!target || !fs.existsSync(target)) return null;
  const img = await app.getFileIcon(target, { size: 'large' }).catch(() => null);
  return img && !img.isEmpty() ? img.toDataURL() : null;
}
/* 2.45.6 Freebuff bringt sein echtes Logo (weißes „F“) in der App mit – direkt aus der installierten App lesen
   (Electron liest Dateien in app.asar wie normale Ordner). Auf dunklem Grund wie in Freebuff selbst. */
const FREEBUFF_DIR = () => path.join(process.env.LOCALAPPDATA || '', 'Programs', '@codebufffreebuff-desktop');
function freebuffLogo() {
  try {
    const svg = fs.readFileSync(path.join(FREEBUFF_DIR(), 'resources', 'app.asar', 'src', 'ui', 'shell', 'freebuff-logo.svg'), 'utf8');
    const inner = svg.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '');
    if (!/<path/.test(inner)) return null;
    const wrapped = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" rx="28" fill="#111214"/><g transform="translate(26 26) scale(0.985)" fill="#fdfdfd">${inner.replace(/fill="[^"]*"/g, '')}</g></svg>`;
    return 'data:image/svg+xml;base64,' + Buffer.from(wrapped).toString('base64');
  } catch { return null; }
}
async function logos() {
  if (logoCache) return logoCache;
  const [claude, codex, freebuff] = await Promise.all([storeLogo('Claude'), storeLogo('OpenAI.Codex'), Promise.resolve(freebuffLogo()).then((l) => l || shortcutLogo('Freebuff'))]);
  logoCache = { claude, codex, freebuff };
  return logoCache;
}

/* ---------------------------------------------------------------- ChatGPT / Codex */
function tail(file, bytes = 64 * 1024) {
  let fd;
  try {
    fd = fs.openSync(file, 'r');
    const size = fs.fstatSync(fd).size, len = Math.min(size, bytes), buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, size - len);
    return buf.toString('utf8');
  } catch { return ''; } finally { if (fd !== undefined) try { fs.closeSync(fd); } catch { /* egal */ } }
}
function codexStatus() {
  const root = path.join(os.homedir(), '.codex', 'sessions');
  if (!fs.existsSync(root)) return { installed: false, status: 'off', sessions: 0 };
  const now = Date.now(), files = [];
  for (const back of [0, 1]) {
    const d = new Date(now - back * 86400000);
    const dir = path.join(root, String(d.getFullYear()), String(d.getMonth() + 1).padStart(2, '0'), String(d.getDate()).padStart(2, '0'));
    try { for (const f of fs.readdirSync(dir)) if (f.endsWith('.jsonl')) { const p = path.join(dir, f); const st = fs.statSync(p); if (now - st.mtimeMs < 3 * 3600000) files.push({ p, m: st.mtimeMs }); } } catch { /* Ordner fehlt */ }
  }
  let best = 'idle', active = 0, at = 0;
  const rank = { question: 4, working: 3, done: 2, idle: 1 };
  for (const { p, m } of files) {
    const lines = tail(p).split('\n');
    let st = 'idle', lastAssistant = '';
    for (let i = lines.length - 1; i >= 0; i--) {
      let o;
      try { o = JSON.parse(lines[i]); } catch { continue; }
      const t = o.payload?.type || '';
      if (!lastAssistant && o.type === 'response_item' && o.payload?.role === 'assistant') lastAssistant = JSON.stringify(o.payload.content || '');
      if (/approval_request|request_user_input|elicitation/i.test(t)) { st = 'question'; break; }
      if (t === 'task_started') { st = now - m < 15 * 60000 ? 'working' : 'idle'; break; }
      if (t === 'task_complete' || t === 'turn_aborted') { st = /\?\s*"?\s*\]?\s*}?\s*\]?$/.test(lastAssistant.replace(/\\n/g, ' ').trim()) ? 'question' : 'done'; break; }
    }
    if (st === 'working') active++;
    if (rank[st] > rank[best]) best = st;
    if (st === 'done') at = Math.max(at, m); // wann fertig – für „angesehen → bereit“
  }
  return { installed: true, status: best, sessions: files.length, active, at };
}

/* ---------------------------------------------------------------- Freebuff
   2.45.6: Früher zählte die Prozessorlast ALLER Freebuff-Prozesse – auch Fenster/Grafik, die schon beim Scrollen
   oder bei Animationen rechnen → „arbeitet“, obwohl nichts lief. Jetzt nur echte Agenten-Signale:
     A  Freebuff schreibt in seine Chat-Datenbank (~/.config/freebuff-desktop/projects/<projekt>/desktop-v2.db[-wal])
     B  der Agent-Prozess (orchestrator in bun.exe) samt seinen Werkzeugen (bash, git …) rechnet
   „arbeitet“ erst, wenn beides zusammen kommt oder ein Signal zwei Messungen hintereinander anhält;
   zurück auf „bereit“ erst nach zwei ruhigen Messungen (kein Flackern). */
const FB_PROJECTS = () => path.join(os.homedir(), '.config', 'freebuff-desktop', 'projects');
function freebuffDbWrite() {
  let newest = 0;
  try {
    for (const d of fs.readdirSync(FB_PROJECTS(), { withFileTypes: true })) {
      if (!d.isDirectory()) continue;
      for (const f of ['desktop-v2.db-wal', 'desktop-v2.db']) {
        try { newest = Math.max(newest, fs.statSync(path.join(FB_PROJECTS(), d.name, f)).mtimeMs); } catch { /* fehlt */ }
      }
    }
  } catch { /* noch nie benutzt */ }
  return newest;
}
let fbPrev = null, fbHits = 0, fbQuiet = 0, fbWorking = false;
async function freebuffStatus() {
  const out = await ps(
    "$all = Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,Name,ExecutablePath -ErrorAction SilentlyContinue; " +
    "$fb = @($all | Where-Object { $_.Name -eq 'Freebuff.exe' }); if (-not $fb.Count) { 'none'; return }; " +
    "$ids = @($all | Where-Object { $_.Name -eq 'bun.exe' -and $_.ExecutablePath -match 'freebuff' } | ForEach-Object { $_.ProcessId }); " +
    "$tree = @($ids); foreach ($i in 1..3) { $tree += @($all | Where-Object { $tree -contains $_.ParentProcessId -and $_.Name -ne 'conhost.exe' -and $tree -notcontains $_.ProcessId } | ForEach-Object { $_.ProcessId }) }; " +
    "$cpu = 0; foreach ($i in $tree) { $p = Get-Process -Id $i -ErrorAction SilentlyContinue; if ($p) { $cpu += $p.CPU } }; " +
    "[string]$cpu + '|' + $tree.Count", 10000);
  if (!out || out === 'none') { fbPrev = null; fbHits = 0; fbQuiet = 0; fbWorking = false; return { status: 'off' }; }
  const [cpuText, countText] = String(out).split('|');
  const cpu = Number(String(cpuText).replace(',', '.'));
  const count = Number(countText) || 0;
  const t = Date.now();
  const prev = fbPrev;
  fbPrev = { cpu, count, t };
  const dbAge = t - freebuffDbWrite();
  const sigDb = dbAge < 12000;
  let load = 0;
  // Prozess-Baum gewechselt (Werkzeug gestartet/beendet) → CPU-Summe nicht vergleichbar, aber selbst ein Zeichen von Arbeit
  const sigTools = Boolean(prev && count > prev.count);
  if (prev && Number.isFinite(cpu) && count === prev.count) load = Math.max(0, (cpu - prev.cpu) / Math.max(0.5, (t - prev.t) / 1000));
  const sigCpu = load > 0.05 || sigTools;
  if (sigDb || sigCpu) { fbHits++; fbQuiet = 0; } else { fbQuiet++; fbHits = 0; }
  if (!fbWorking && ((sigDb && sigCpu) || fbHits >= 2)) fbWorking = true;
  else if (fbWorking && fbQuiet >= 2) fbWorking = false;
  return { status: fbWorking ? 'working' : 'ready', load: Math.round(load * 100) };
}

/* ---------------------------------------------------------------- App öffnen (Deck-Taste)
   2.45.6: Taste drücken → App kommt nach vorne; läuft sie nicht, wird sie gestartet.
   Claude   claude://code/continue?session=local_… öffnet genau den Chat (Claude-Desktop-Verknüpfung, eingebaut in Claude);
            gewählt wird der Chat, der eine Frage hat, sonst der zuletzt fertige, sonst der arbeitende, sonst der letzte.
   Freebuff  Freebuff.exe erneut starten → Freebuff holt sein vorhandenes Fenster nach vorne (keine Chat-Verknüpfung in Freebuff).
   ChatGPT   über die Store-App-Kennung (öffnet bzw. holt die App nach vorne; keine Chat-Verknüpfung bekannt). */
function claudeLocalSession(cliId) {
  if (!/^[0-9a-f-]{36}$/i.test(cliId || '')) return null;
  const roots = [path.join(process.env.LOCALAPPDATA || '', 'Claude-Data'), path.join(process.env.APPDATA || '', 'Claude'), path.join(process.env.LOCALAPPDATA || '', 'Claude-3p')];
  // Nur in „claude*“-Ordnern bis zu „claude-code-sessions“ absteigen, darin zwei Ebenen (Konto/Arbeitsbereich)
  const look = (dir, depth, inside) => {
    let list;
    try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
    for (const e of list) {
      const p = path.join(dir, e.name);
      if (inside && e.isFile() && /^local_[A-Za-z0-9-]{1,64}\.json$/.test(e.name)) {
        try { if (fs.readFileSync(p, 'utf8').slice(0, 400).includes(`"cliSessionId":"${cliId}"`)) return e.name.slice(0, -5); } catch { /* weiter */ }
      } else if (e.isDirectory() && depth > 0 && (inside || e.name === 'claude-code-sessions' || /^claude_/i.test(e.name))) {
        const hit = look(p, depth - 1, inside || e.name === 'claude-code-sessions');
        if (hit) return hit;
      }
    }
    return null;
  };
  for (const r of roots) { const hit = look(r, 4, false); if (hit) return hit; }
  return null;
}
function pickClaudeSession(sessions) {
  const recent = (sessions || []).filter((s) => Date.now() - s.at < 3 * 3600000);
  for (const st of ['question', 'done', 'limit', 'working']) { const s = recent.find((x) => x.status === st); if (s) return s; }
  return recent[0] || null;
}
async function openAgent(agent, sessions) {
  const { shell } = require('electron');
  const { spawn } = require('child_process');
  if (agent === 'claude') {
    const ses = pickClaudeSession(sessions);
    const local = ses ? claudeLocalSession(ses.id) : null;
    await shell.openExternal(`claude://code/continue?session=${local || 'last'}&source=desktop_action`);
    return { opened: 'claude', chat: Boolean(local), project: ses?.project || '' };
  }
  if (agent === 'freebuff') {
    const exe = path.join(FREEBUFF_DIR(), 'Freebuff.exe');
    if (!fs.existsSync(exe)) throw new Error('Freebuff ist nicht installiert.');
    spawn(exe, [], { detached: true, stdio: 'ignore', windowsHide: false }).unref();
    return { opened: 'freebuff', chat: false };
  }
  if (agent === 'codex') {
    spawn('explorer.exe', ['shell:AppsFolder\\OpenAI.Codex_2p2nqsd0c76g0!App'], { detached: true, stdio: 'ignore' }).unref();
    return { opened: 'codex', chat: false };
  }
  throw new Error('Unbekannter Agent.');
}

async function agents() {
  const [codex, freebuff, lg] = await Promise.all([codexStatus(), freebuffStatus(), logos()]);
  return { codex: { ...codex, logo: lg.codex, name: 'ChatGPT' }, freebuff: { ...freebuff, logo: lg.freebuff, name: 'Freebuff' }, claudeLogo: lg.claude };
}

module.exports = { agents, logos, openAgent, claudeLocalSession };
