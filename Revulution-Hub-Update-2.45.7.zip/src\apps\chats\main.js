'use strict';

const fs = require('fs');
const path = require('path');
const { boot, bindHubProfile } = require('../shared/boot');
const bridge = () => global.__revolutionHub.chat;

const ctx = boot('chats', __dirname);
const { app, ipcMain, session } = ctx.electron;
const hub = ctx.hub;
bindHubProfile(ipcMain);
const file = () => path.join(app.getPath('userData'), 'chats.json');

ipcMain.handle('load', () => {
  try {
    return JSON.parse(fs.readFileSync(file(), 'utf8'));
  } catch {
    return null;
  }
});
let timer = null;
let pending = null;
ipcMain.handle('save', (_e, data) => {
  pending = data;
  clearTimeout(timer);
  timer = setTimeout(() => {
    fs.mkdirSync(path.dirname(file()), { recursive: true });
    fs.writeFileSync(`${file()}.tmp`, JSON.stringify(pending));
    fs.renameSync(`${file()}.tmp`, file());
  }, 400);
  return true;
});
ipcMain.handle('identity', (_e, id) => bridge()?.setIdentity(id));
// 2.45.9 Anmelden/Registrieren direkt in den Chats (Konto des Hubs; danach werden Name, Freunde und Nachrichten übernommen)
const acct = () => global.__revolutionHub?.account;
ipcMain.handle('acct-state', () => acct()?.state() || { signedIn: false });
ipcMain.handle('acct-login', (_e, email, password, create) => {
  if (!acct()) throw new Error('Konto ist gerade nicht verfügbar.');
  return acct().login(String(email || ''), String(password || ''), Boolean(create));
});
ipcMain.handle('acct-code', (_e, code) => acct().verifyCode(String(code || '')));
ipcMain.handle('unread', (_e, n) => global.__revolutionHub.setBadge?.('chats', n));
ipcMain.handle('pending', () => bridge()?.take() || []);
ipcMain.handle('is-open', () => hub.active === 'chats' && Boolean(hub.window?.isFocused()));
// 2.45 Bildschirm teilen im Anruf: Quellen (Bildschirme/Fenster) zur Auswahl, dann gezielt freigeben
const capturer = () => ctx.electron.desktopCapturer || require('electron').desktopCapturer;
let shareSource = '';
ipcMain.handle('share-sources', async () => {
  const list = await capturer().getSources({ types: ['screen', 'window'], thumbnailSize: { width: 320, height: 180 }, fetchWindowIcons: false });
  return list.filter((s) => s.name && !/Revulution Hub/i.test(s.name)).slice(0, 24).map((s) => ({ id: s.id, name: s.name, screen: s.id.startsWith('screen:'), thumb: s.thumbnail.isEmpty() ? '' : s.thumbnail.toDataURL() }));
});
ipcMain.handle('share-pick', (_e, id) => {
  shareSource = String(id || '').slice(0, 200);
  return true;
});
app.whenReady().then(() => {
  // Mikrofon für Sprach-Anrufe in dieser App erlauben (nur dieses App-Fenster).
  try {
    const ses = session.fromPartition('persist:chats');
    const allow = (permission) => ['media', 'audioCapture', 'videoCapture', 'display-capture'].includes(String(permission));
    ses.setPermissionRequestHandler((_wc, permission, callback) => callback(allow(permission)));
    ses.setPermissionCheckHandler((_wc, permission) => allow(permission));
    ses.setDisplayMediaRequestHandler(async (_req, callback) => {
      try {
        const list = await capturer().getSources({ types: ['screen', 'window'] });
        const src = list.find((s) => s.id === shareSource) || list.find((s) => s.id.startsWith('screen:')) || list[0];
        callback(src ? { video: src } : {});
      } catch {
        callback({});
      }
    });
  } catch (error) {
    console.error('[chats] Mikrofon-Berechtigung:', error.message);
  }
  const b = bridge();
  if (b) b.onDm = (item) => ctx.send('game-request', item);
});
// Benachrichtigung, wenn eine Nachricht kommt und die Chats nicht offen sind
ipcMain.handle('relay', (_e, item) => global.__revolutionHub?.ajazzFeed?.(item) || false);
ipcMain.handle('call-state', (_e, state) => global.__revolutionHub?.chatCall?.(state) || false);
// 2.39 Melden: Bildschirmfoto des Chats + Meldung an den Admin
ipcMain.handle('snap', async (e) => {
  const img = await e.sender.capturePage();
  let out = img.resize({ width: Math.min(1280, img.getSize().width) });
  let q = 70;
  let url = `data:image/jpeg;base64,${out.toJPEG(q).toString('base64')}`;
  while (url.length > 900 * 1024 && q > 25) {
    q -= 15;
    out = out.resize({ width: Math.round(out.getSize().width * 0.8) });
    url = `data:image/jpeg;base64,${out.toJPEG(q).toString('base64')}`;
  }
  return url;
});
ipcMain.handle('my-card', () => global.__revolutionHub?.achievementsCard?.() || null);
ipcMain.handle('report', async (_e, r) => {
  const fn = global.__revolutionHub?.chatReport;
  if (!fn) throw new Error('Melden ist gerade nicht verfügbar.');
  return fn(r);
});
ipcMain.handle('notify', (_e, { title, body }) => {
  if (hub.active === 'chats' && hub.window?.isFocused()) return false;
  // Läuft die Dynamic Island, landet die Nachricht dort – sonst Windows-Hinweis
  hub.notify(String(title).slice(0, 60), String(body).slice(0, 140), { app: 'Chats', accent: '#38bdf8', glyph: '💬' });
  return true;
});
