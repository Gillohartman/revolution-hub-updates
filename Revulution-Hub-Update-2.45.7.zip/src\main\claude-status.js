'use strict';
/**
 * Claude-Status (2.45.3): zeigt im Deck Studio und auf dem Deck, ob Claude (Claude Code / Desktop-App)
 * gerade arbeitet oder fertig ist – und welche Agenten aktiv sind.
 * Liest nur lokal die Verlaufsdateien unter %USERPROFILE%\.claude\projects (jeweils nur das Ende der Datei).
 * Es werden keine Inhalte angezeigt oder verschickt – nur Projektname, Status und Zeit.
 *   fertig   letzte Antwort von Claude ist abgeschlossen (stop_reason end_turn) → wartet auf dich
 *   arbeitet letzte Aktivität vor < 10 min und nicht abgeschlossen
 *   ruht     länger nichts passiert
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const ROOT = () => path.join(os.homedir(), '.claude', 'projects');
const RECENT_MS = 3 * 60 * 60 * 1000;
const WORKING_MS = 10 * 60 * 1000;

function tail(file, bytes = 96 * 1024) {
  let fd;
  try {
    fd = fs.openSync(file, 'r');
    const size = fs.fstatSync(fd).size;
    const len = Math.min(size, bytes);
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, size - len);
    return buf.toString('utf8');
  } catch {
    return '';
  } finally {
    if (fd !== undefined) try { fs.closeSync(fd); } catch { /* egal */ }
  }
}

function inspect(file, mtime) {
  const lines = tail(file).split('\n');
  let last = null;
  let lastLine = '';
  let meta = {};
  for (let i = lines.length - 1; i >= 0 && !last; i--) {
    const l = lines[i].trim();
    if (!l.startsWith('{')) continue;
    let o;
    try { o = JSON.parse(l); } catch { continue; }
    if (!meta.cwd && o.cwd) meta = { cwd: o.cwd, slug: o.slug || '' };
    if (o.type === 'user' || o.type === 'assistant' || (o.type === 'system' && /error/i.test(o.subtype || o.level || ''))) { last = o; lastLine = l; }
  }
  // Limit aufgebraucht: die letzte Meldung ist ein API-Fehler wegen Nutzungs-/Ratenlimit
  const limit = Boolean(last && (last.isApiErrorMessage || last.type === 'system') && /usage limit|limit reached|rate.?limit|limit (will )?reset|limit erreicht|out of (extra )?usage|quota/i.test(lastLine));
  // Projektname vom Anfang der Sitzung (später kann Claude in Unterordnern arbeiten)
  const head = (() => {
    let fd;
    try { fd = fs.openSync(file, 'r'); const b = Buffer.alloc(32 * 1024); const n = fs.readSync(fd, b, 0, b.length, 0); return b.toString('utf8', 0, n); } catch { return ''; } finally { if (fd !== undefined) try { fs.closeSync(fd); } catch { /* egal */ } }
  })();
  for (const l of head.split('\n')) {
    try { const o = JSON.parse(l); if (o.cwd) { meta = { cwd: o.cwd, slug: o.slug || meta.slug || '' }; break; } } catch { /* weiter */ }
  }
  const age = Date.now() - mtime;
  // Frage: Claude wartet auf eine Antwort – Rückfrage-Dialog (AskUserQuestion/Plan) oder Antwort endet mit „?“
  const content = Array.isArray(last?.message?.content) ? last.message.content : [];
  const asks = last?.type === 'assistant' && content.some((c) => c.type === 'tool_use' && /^(AskUserQuestion|ExitPlanMode)$/.test(c.name || ''));
  const lastText = content.filter((c) => c.type === 'text').map((c) => c.text || '').join(' ').trim();
  const endsWithQuestion = last?.type === 'assistant' && last.message?.stop_reason === 'end_turn' && /\?\s*[)\]»"“]?\s*$/.test(lastText);
  let status = 'idle';
  if (limit) status = 'limit';
  else if (asks || endsWithQuestion) status = 'question';
  else if (last?.type === 'assistant' && last.message?.stop_reason === 'end_turn') status = 'done';
  else if (age < WORKING_MS) status = 'working';
  const at = last?.timestamp ? Date.parse(last.timestamp) || mtime : mtime;
  return { status, at, cwd: meta.cwd || '', slug: meta.slug || '' };
}

function scan() {
  const out = [];
  let dirs = [];
  try { dirs = fs.readdirSync(ROOT(), { withFileTypes: true }).filter((d) => d.isDirectory()); } catch { return { available: false, sessions: [], working: 0, done: 0, agents: 0 }; }
  const now = Date.now();
  for (const d of dirs) {
    const dir = path.join(ROOT(), d.name);
    let files = [];
    try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.jsonl')); } catch { continue; }
    for (const f of files) {
      const file = path.join(dir, f);
      let st;
      try { st = fs.statSync(file); } catch { continue; }
      if (now - st.mtimeMs > RECENT_MS) continue;
      const id = f.slice(0, -6);
      const info = inspect(file, st.mtimeMs);
      const agents = [];
      const subDir = path.join(dir, id, 'subagents');
      try {
        for (const a of fs.readdirSync(subDir).filter((x) => x.endsWith('.jsonl'))) {
          const af = path.join(subDir, a);
          const ast = fs.statSync(af);
          if (now - ast.mtimeMs > RECENT_MS) continue;
          const ai = inspect(af, ast.mtimeMs);
          agents.push({ id: a.replace(/^agent-/, '').slice(0, -6), status: ai.status === 'idle' ? 'done' : ai.status, at: ai.at });
        }
      } catch { /* keine Agenten */ }
      out.push({ id, project: path.basename(info.cwd || d.name), status: info.status, at: info.at, agents: agents.sort((a, b) => b.at - a.at) });
    }
  }
  out.sort((a, b) => b.at - a.at);
  const sessions = out.slice(0, 12);
  return {
    available: true,
    sessions,
    working: sessions.filter((s) => s.status === 'working').length,
    done: sessions.filter((s) => s.status === 'done').length,
    question: sessions.filter((s) => s.status === 'question' && Date.now() - s.at < 60 * 60 * 1000).length,
    // 2.45.9: Limit nur, wenn die NEUESTE Aktivität ein Limit ist und nichts mehr arbeitet (früher blieb es 5 h stehen)
    limit: Boolean(sessions[0]?.status === 'limit' && Date.now() - sessions[0].at < 5 * 60 * 60 * 1000 && !sessions.some((s) => s.status === 'working')),
    agents: sessions.reduce((n, s) => n + s.agents.filter((a) => a.status === 'working').length, 0),
    at: now,
  };
}

/** Beobachtet die Sitzungen, solange eingeschaltet; meldet Änderungen und „Claude ist fertig“. */
class ClaudeWatch {
  constructor({ onChange, onFinished }) {
    this.onChange = onChange;
    this.onFinished = onFinished;
    this.timer = null;
    this.last = null;
    this.prev = new Map();
    // 2.45.7: „fertig“ gilt nur, bis man die App wieder angeklickt hat – danach „bereit“
    this.fg = new (require('./foreground').ForegroundWatch)();
  }
  start() {
    this.fg.start();
    if (this.timer) return this.last || this.tick();
    this.timer = setInterval(() => this.tick(), 3000);
    return this.tick();
  }
  stop() {
    clearInterval(this.timer);
    this.timer = null;
    this.prev.clear();
    this.fg.stop();
    return { available: true, sessions: [], working: 0, done: 0, agents: 0, off: true };
  }
  tick() {
    const s = scan();
    // 2.45.5 weitere Agenten (ChatGPT/Codex, Freebuff) alle ~6 s nachladen – Logos und Status
    if (!this.agentsBusy && Date.now() - (this.agentsAt || 0) > 5500) {
      this.agentsBusy = true;
      require('./agent-status').agents().then((a) => {
        const sig = JSON.stringify([a.codex.status, a.freebuff.status, Boolean(a.codex.logo), Boolean(a.freebuff.logo)]);
        this.others = a;
        this.agentsAt = Date.now();
        if (sig !== this.othersSig) { this.othersSig = sig; this.lastSig = ''; this.tick(); }
      }).catch(() => {}).finally(() => { this.agentsBusy = false; });
    }
    // Angesehen: Claude-App war nach dem Fertigwerden vorne → „fertig“ wird „ruht“ (Taste: „bereit“)
    const seenClaude = this.fg.seenAt('claude');
    for (const ses of s.sessions) if (ses.status === 'done' && ses.at <= seenClaude) { ses.status = 'idle'; ses.seen = true; }
    s.done = s.sessions.filter((x) => x.status === 'done').length;
    if (this.others) {
      const o = { ...this.others };
      for (const k of ['codex', 'freebuff']) if (o[k]?.status === 'done' && (o[k].at || 0) <= this.fg.seenAt(k)) o[k] = { ...o[k], status: 'ready' };
      s.others = o;
    } else s.others = null;
    for (const ses of s.sessions) {
      const before = this.prev.get(ses.id);
      if (before === 'working' && (ses.status === 'done' || ses.status === 'question')) this.onFinished?.(ses);
      this.prev.set(ses.id, ses.status);
    }
    const sig = JSON.stringify([s.sessions.map((x) => [x.id, x.status, x.agents.map((a) => a.status).join('')]), s.others?.codex?.status, s.others?.freebuff?.status]);
    if (!this.last || sig !== this.lastSig) {
      this.lastSig = sig;
      this.onChange?.(s);
    }
    this.last = s;
    return s;
  }
}

module.exports = { ClaudeWatch, scan };
