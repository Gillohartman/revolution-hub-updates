'use strict';

/*
 * 2.45.9 Zeichnen – neu gebaut:
 *   • Unendliche Blätter (beliebig viele), alles als Vektoren → scharf in jeder Zoomstufe (2 % … 10 000 %)
 *   • Pinsel mit Druckstufen (Stift/Windows Ink), Verweilen = breiter, schnell = schmaler
 *   • Füller, Bleistift, Filzstift, Textmarker, Kreide, Airbrush, Radierer (Pixel + ganze Striche)
 *   • Auswahl (Lasso): verschieben, grösser/kleiner, umfärben, duplizieren, löschen, kopieren
 *   • Formen (Linie, Pfeil, Rechteck, Ellipse, mit Füllung), Form-Assistent (still halten → saubere Form)
 *   • Text, Notizzettel, Bilder (öffnen, einfügen, hineinziehen), Füllen (bleibt scharf), Pipette, Laserpointer
 *   • Ebenen, Papier (leer, Punkte, Raster, Linien), Export PNG (Ansicht/alles) und SVG
 *   • Zusammen zeichnen: Raum mit Code (öffentliche MQTT-Server wie Chats/Spiele), Live-Striche und Zeiger
 *   • Stift-Tasten (z. B. ASUS Pen 2.0) und Maus-Seitentasten: Standard zurück/vor, frei belegbar
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-draw';

  /* ================================================================ Symbole */
  const IC = {
    pen: 'M15.5 4.5l4 4L9 19H5v-4z M13.5 6.5l4 4',
    pencil: 'M16.5 3.5l4 4L8 20l-5 1 1-5z M14.5 5.5l4 4 M4 16l4 4',
    marker: 'M9 20l-5-1 1-5 9.5-9.5 4.5 4.5z M12.5 6.5l5 5 M4 21h6',
    highlighter: 'M4 21h7 M8 17l-2 4 M8 17l9-12 4 3-9 12z M8 17l4 3',
    chalk: 'M5 19l9-9 M7 21l12-12a2.1 2.1 0 0 0-3-3L4 18z M4 21h.01 M7 18h.01',
    air: 'M8 11h7v10H8z M10 11V8h3v3 M17.5 5h.01 M20 7h.01 M17 2.5h.01 M20 3.5h.01',
    eraser: 'M8 20h12 M5.5 16.5l9-9 5 5-6.5 6.5H9z M10 12l5 5',
    objeraser: 'M4 20h16 M7 4l10 10 M17 4L7 14',
    select: 'M5 5c4-3 13-2 14 3s-6 7-9 6-6 2-3 5 M12 17l2 5 1.5-3 3 1.5z',
    hand: 'M8 13V5.5a1.5 1.5 0 0 1 3 0V12 M11 11V4.5a1.5 1.5 0 0 1 3 0V12 M14 11.5V6a1.5 1.5 0 0 1 3 0v7.5 M8 12.5L6.5 11a1.6 1.6 0 0 0-2.3 2.2L8 18c1.5 2 3 3 6 3a5 5 0 0 0 5-5V9.5a1.5 1.5 0 0 0-3 0',
    line: 'M5 19L19 5',
    arrow: 'M5 19L19 5 M10 5h9v9',
    rect: 'M4 6h16v12H4z',
    ellipse: 'M12 19c4.4 0 8-3.1 8-7s-3.6-7-8-7-8 3.1-8 7 3.6 7 8 7z',
    text: 'M5 6V4h14v2 M12 4v16 M9 20h6',
    note: 'M5 4h14v11l-5 5H5z M14 20v-5h5',
    fill: 'M5 11l7-7 7 7-7 7z M5 11h14 M20 15s2 2.3 2 3.5a2 2 0 0 1-4 0c0-1.2 2-3.5 2-3.5',
    pick: 'M14.5 4.5l5 5 M17 2l5 5-3 3-5-5z M14 8l-9 9v3h3l9-9',
    laser: 'M12 12m-2.5 0a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0-5 0 M12 3v3 M12 18v3 M3 12h3 M18 12h3 M5.6 5.6l2.1 2.1 M16.3 16.3l2.1 2.1 M5.6 18.4l2.1-2.1 M16.3 7.7l2.1-2.1',
    image: 'M4 5h16v14H4z M4 16l5-5 4 4 2-2 5 5 M15.5 9.5h.01',
    undo: 'M9 14L4 9l5-5 M4 9h10a6 6 0 0 1 0 12h-3',
    redo: 'M15 14l5-5-5-5 M20 9H10a6 6 0 0 0 0 12h3',
    users: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M2 21a7 7 0 0 1 14 0 M16 3.5a4 4 0 0 1 0 7.5 M22 21a7 7 0 0 0-4-6.3',
    penbtn: 'M14 4l6 6-9 9H5v-6z M12 6l6 6 M3 21h18',
    fit: 'M4 9V4h5 M20 9V4h-5 M4 15v5h5 M20 15v5h-5',
    plus: 'M12 5v14 M5 12h14',
    minus: 'M5 12h14',
    trash: 'M4 7h16 M9 7V4h6v3 M6 7l1 13h10l1-13',
    copy: 'M8 8h12v12H8z M4 16V4h12',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    eyeoff: 'M3 3l18 18 M10.6 5.1A10 10 0 0 1 12 5c6 0 10 7 10 7a17 17 0 0 1-3.2 3.9 M6.6 6.6C3.8 8.5 2 12 2 12s4 7 10 7a9.6 9.6 0 0 0 5.4-1.6',
    shape: 'M4 20l5-9 5 9z M14 4h6v6h-6z',
    download: 'M12 3.5v11 M7 10l5 5 5-5 M4 20h16',
    up: 'M12 19V5 M6 11l6-6 6 6',
    down: 'M12 5v14 M6 13l6 6 6-6',
  };
  const svg = (n, s = 20) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" aria-hidden="true"><path d="${IC[n] || IC.pen}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  const TOOLS = [
    ['pen', 'Füller', 'B'], ['pencil', 'Bleistift', 'P'], ['marker', 'Filzstift', 'M'], ['highlighter', 'Textmarker', 'U'], ['chalk', 'Kreide', 'K'], ['air', 'Airbrush', 'Y'],
    ['eraser', 'Radierer', 'E'], ['objeraser', 'Strich-Radierer', 'X'], ['select', 'Auswahl (Lasso)', 'V'], ['hand', 'Verschieben', 'H'],
    ['line', 'Linie', 'L'], ['arrow', 'Pfeil', 'A'], ['rect', 'Rechteck', 'R'], ['ellipse', 'Ellipse', 'O'], ['text', 'Text', 'T'], ['note', 'Notizzettel', 'N'],
    ['fill', 'Füllen', 'G'], ['pick', 'Pipette', 'I'], ['laser', 'Laserpointer', 'Z'],
  ];
  const BRUSH = new Set(['pen', 'pencil', 'marker', 'highlighter', 'chalk', 'air', 'eraser']);
  const SHAPES = new Set(['line', 'arrow', 'rect', 'ellipse']);
  const SWATCHES = ['#111111', '#ffffff', '#8e8e93', '#ff3b30', '#ff9500', '#ffcc00', '#34c759', '#00c7be', '#0a84ff', '#5e5ce6', '#bf5af2', '#ff2d55', '#a2845e', '#1c3d5a', '#f5d0a9', '#7cfc00'];
  const PAPERS = [['plain', 'Leer'], ['dots', 'Punkte'], ['grid', 'Raster'], ['lines', 'Linien']];

  // Stift-/Maustasten: Signal → Aktion
  const ACTIONS = [
    ['none', 'Nichts'], ['undo', 'Rückgängig (zurück)'], ['redo', 'Wiederholen (vor)'], ['eraser', 'Radierer (halten)'], ['objeraser', 'Strich-Radierer (halten)'],
    ['hand', 'Verschieben (halten)'], ['laser', 'Laserpointer (halten)'], ['pick', 'Pipette'], ['select', 'Auswahl-Werkzeug'], ['lasttool', 'Letztes Werkzeug'],
    ['pen', 'Füller'], ['nextcolor', 'Nächste Farbe'], ['fit', 'Alles zeigen'], ['bigger', 'Pinsel grösser'], ['smaller', 'Pinsel kleiner'],
  ];
  const HOLD = new Set(['eraser', 'objeraser', 'hand', 'laser']);
  const SIGNALS = { 'pen-barrel': 'Stift: untere Seitentaste (Rechtsklick)', 'pen-eraser': 'Stift: obere Seitentaste (Radieren)', 'mouse-back': 'Maus: Seitentaste zurück', 'mouse-forward': 'Maus: Seitentaste vor' };
  const DEFAULT_BINDINGS = { 'pen-barrel': 'undo', 'pen-eraser': 'redo', 'mouse-back': 'undo', 'mouse-forward': 'redo' };

  /* ================================================================ Zustand */
  const st = {
    root: null, view: null, ctx: null, dpr: 1,
    tool: 'pen', lastTool: 'pen', color: '#111111', size: 8, opacity: 1, smooth: 0.45, shapeFill: 0, scaleWithZoom: true, assist: true,
    recent: [], idx: null, doc: null, items: new Map(), ver: 0,
    undo: [], redo: [], live: null, ptrs: new Map(), pinch: null, panning: null, spaceDown: false,
    sel: new Set(), selDrag: null, lasso: null, laser: [], textEdit: null,
    saveTimer: 0, dirty: false, raf: 0, layerCache: new Map(), pathCache: new Map(), imgCache: new Map(),
    bindings: { ...DEFAULT_BINDINGS }, capture: false, lastFire: {}, lastPenAt: 0, penButtons: 0, panel: '',
    net: null, peers: new Map(), ghosts: new Map(), me: { name: 'Ich' }, clip: null,
  };
  const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-3);
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const zoomPct = () => (st.doc ? st.doc.view.z / st.dpr : 1);
  const layerOf = (id) => st.doc.layers.find((l) => l.id === id);
  const activeLayer = () => st.doc.layers.find((l) => l.id === st.doc.active) || st.doc.layers[st.doc.layers.length - 1];

  /* ================================================================ Dokument */
  function blankDoc(name) {
    const l = { id: uid(), name: 'Ebene 1', visible: true, opacity: 1, ver: 0 };
    return { v: 2, id: uid(), name: name || 'Blatt', bg: '#ffffff', paper: 'dots', layers: [l], active: l.id, items: [], view: { x: 0, y: 0, z: 1 } };
  }
  function indexDoc() {
    st.items = new Map(st.doc.items.map((it) => [it.id, it]));
    for (const l of st.doc.layers) l.ver = (l.ver || 0) + 1;
    st.ver += 1;
  }
  const bumpLayer = (lid) => { const l = layerOf(lid); if (l) l.ver = (l.ver || 0) + 1; st.ver += 1; };

  /* ================================================================ Geometrie */
  function rng(seed) {
    let s = 0;
    for (const ch of String(seed)) s = (s * 31 + ch.charCodeAt(0)) | 0;
    return () => {
      s = (s + 0x6d2b79f5) | 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const f1 = (n) => Math.round(n * 10) / 10;
  // Punkte eines Strichs: flach [x, y, w, x, y, w, …]
  const ptsOf = (it) => { const out = []; for (let i = 0; i < it.pts.length; i += 3) out.push({ x: it.pts[i], y: it.pts[i + 1], w: it.pts[i + 2] }); return out; };
  /** Umriss eines Strichs mit wechselnder Breite als SVG-Pfad (runde Enden, geglättet). */
  function outlineD(pts, jitter = 0, seed = '') {
    const n = pts.length;
    if (!n) return '';
    const circ = (x, y, r) => `M${f1(x - r)} ${f1(y)}a${f1(r)} ${f1(r)} 0 1 0 ${f1(2 * r)} 0a${f1(r)} ${f1(r)} 0 1 0 ${f1(-2 * r)} 0Z`;
    if (n === 1) return circ(pts[0].x, pts[0].y, Math.max(0.3, pts[0].w / 2));
    const rnd = jitter ? rng(seed) : null;
    const L = [], R = [];
    for (let i = 0; i < n; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
      let tx = b.x - a.x, ty = b.y - a.y;
      const len = Math.hypot(tx, ty) || 1;
      tx /= len; ty /= len;
      const r = Math.max(0.3, pts[i].w / 2) * (rnd ? 1 + (rnd() - 0.5) * jitter : 1);
      L.push([pts[i].x - ty * r, pts[i].y + tx * r]);
      R.push([pts[i].x + ty * r, pts[i].y - tx * r]);
    }
    const side = (P) => {
      let d = '';
      for (let i = 1; i < P.length - 1; i++) d += `Q${f1(P[i][0])} ${f1(P[i][1])} ${f1((P[i][0] + P[i + 1][0]) / 2)} ${f1((P[i][1] + P[i + 1][1]) / 2)}`;
      return `${d}L${f1(P[P.length - 1][0])} ${f1(P[P.length - 1][1])}`;
    };
    const rEnd = Math.max(0.3, pts[n - 1].w / 2), rStart = Math.max(0.3, pts[0].w / 2);
    const Rr = R.slice().reverse();
    return `M${f1(L[0][0])} ${f1(L[0][1])}${side(L)}A${f1(rEnd)} ${f1(rEnd)} 0 0 0 ${f1(Rr[0][0])} ${f1(Rr[0][1])}${side(Rr)}A${f1(rStart)} ${f1(rStart)} 0 0 0 ${f1(L[0][0])} ${f1(L[0][1])}Z`;
  }
  const polyD = (pts) => pts.length ? `M${pts.map((p) => `${f1(p.x)} ${f1(p.y)}`).join('L')}` : '';
  function chalkD(it) {
    const P = ptsOf(it), rnd = rng(it.id);
    let d = '';
    for (let i = 0; i < P.length; i++) {
      const a = P[Math.max(0, i - 1)], b = P[i];
      const dist = Math.hypot(b.x - a.x, b.y - a.y);
      const steps = Math.max(1, Math.ceil(dist / Math.max(1, b.w * 0.3)));
      for (let s = 0; s < steps; s++) {
        const t = s / steps, x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t;
        for (let k = 0; k < 3; k++) {
          if (rnd() < 0.3) continue;
          const rr = rnd() * b.w * 0.55, ang = rnd() * Math.PI * 2, r = 0.4 + rnd() * b.w * 0.14;
          const cx = x + Math.cos(ang) * rr, cy = y + Math.sin(ang) * rr;
          d += `M${f1(cx - r)} ${f1(cy)}a${f1(r)} ${f1(r)} 0 1 0 ${f1(2 * r)} 0a${f1(r)} ${f1(r)} 0 1 0 ${f1(-2 * r)} 0Z`;
        }
      }
    }
    return d;
  }
  function airD(it) {
    const P = ptsOf(it), rnd = rng(it.id);
    let d = '';
    for (const p of P) {
      const n = Math.min(60, Math.round(p.w * 1.2));
      for (let k = 0; k < n; k++) {
        const rr = Math.sqrt(rnd()) * p.w, ang = rnd() * Math.PI * 2, r = Math.max(0.35, p.w * 0.03);
        const cx = p.x + Math.cos(ang) * rr, cy = p.y + Math.sin(ang) * rr;
        d += `M${f1(cx - r)} ${f1(cy)}a${f1(r)} ${f1(r)} 0 1 0 ${f1(2 * r)} 0a${f1(r)} ${f1(r)} 0 1 0 ${f1(-2 * r)} 0Z`;
      }
    }
    return d;
  }
  function shapeD(it) {
    const { x1, y1, x2, y2 } = it;
    if (it.kind === 'line') return `M${f1(x1)} ${f1(y1)}L${f1(x2)} ${f1(y2)}`;
    if (it.kind === 'arrow') {
      const a = Math.atan2(y2 - y1, x2 - x1), h = Math.max(10, it.size * 3.5);
      return `M${f1(x1)} ${f1(y1)}L${f1(x2)} ${f1(y2)}M${f1(x2 - h * Math.cos(a - 0.45))} ${f1(y2 - h * Math.sin(a - 0.45))}L${f1(x2)} ${f1(y2)}L${f1(x2 - h * Math.cos(a + 0.45))} ${f1(y2 - h * Math.sin(a + 0.45))}`;
    }
    const x = Math.min(x1, x2), y = Math.min(y1, y2), w = Math.abs(x2 - x1), h = Math.abs(y2 - y1);
    if (it.kind === 'rect') return `M${f1(x)} ${f1(y)}h${f1(w)}v${f1(h)}h${f1(-w)}Z`;
    const cx = x + w / 2, cy = y + h / 2, rx = Math.max(0.1, w / 2), ry = Math.max(0.1, h / 2);
    return `M${f1(cx - rx)} ${f1(cy)}a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(2 * rx)} 0a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(-2 * rx)} 0Z`;
  }
  const fillD = (it) => it.polys.map((p) => { let d = `M${f1(p[0])} ${f1(p[1])}`; for (let i = 2; i < p.length; i += 2) d += `L${f1(p[i])} ${f1(p[i + 1])}`; return `${d}Z`; }).join('');
  /** SVG-Pfad eines Elements (für Zeichnen, Export und Treffer). */
  function dOf(it) {
    if (it.type === 'stroke') {
      if (it.tool === 'chalk') return chalkD(it);
      if (it.tool === 'air') return airD(it);
      if (it.tool === 'marker' || it.tool === 'highlighter') return polyD(ptsOf(it));
      return outlineD(ptsOf(it), it.tool === 'pencil' ? 0.25 : 0, it.id);
    }
    if (it.type === 'shape') return shapeD(it);
    if (it.type === 'fill') return fillD(it);
    return '';
  }
  function pathOf(it) {
    let c = st.pathCache.get(it.id);
    if (!c || c.v !== it.rev) {
      const d = dOf(it);
      c = { v: it.rev, d, p: d ? new Path2D(d) : null };
      st.pathCache.set(it.id, c);
    }
    return c;
  }
  function bboxOf(it) {
    if (it._bb && it._bbRev === it.rev) return it._bb;
    let b;
    if (it.type === 'stroke') {
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, wm = 0;
      for (let i = 0; i < it.pts.length; i += 3) { const x = it.pts[i], y = it.pts[i + 1]; if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; wm = Math.max(wm, it.pts[i + 2]); }
      const pad = (it.tool === 'highlighter' ? wm * 1.2 : it.tool === 'air' ? wm : wm / 2) + 1;
      b = { x: x0 - pad, y: y0 - pad, w: x1 - x0 + pad * 2, h: y1 - y0 + pad * 2 };
    } else if (it.type === 'shape') {
      const pad = it.size * (it.kind === 'arrow' ? 4 : 1) + 1;
      b = { x: Math.min(it.x1, it.x2) - pad, y: Math.min(it.y1, it.y2) - pad, w: Math.abs(it.x2 - it.x1) + pad * 2, h: Math.abs(it.y2 - it.y1) + pad * 2 };
    } else if (it.type === 'fill') {
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const p of it.polys) for (let i = 0; i < p.length; i += 2) { x0 = Math.min(x0, p[i]); x1 = Math.max(x1, p[i]); y0 = Math.min(y0, p[i + 1]); y1 = Math.max(y1, p[i + 1]); }
      b = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    } else if (it.type === 'text') {
      const lines = String(it.text || '').split('\n');
      b = { x: it.x, y: it.y, w: Math.max(...lines.map((l) => l.length)) * it.size * 0.58 + 4, h: lines.length * it.size * 1.25 + 4 };
    } else b = { x: it.x, y: it.y, w: it.w, h: it.h };
    it._bb = b;
    it._bbRev = it.rev;
    return b;
  }
  const hide = (it) => { delete it._bb; delete it._bbRev; return it; };
  const cleanItem = (it) => { const o = { ...it }; delete o._bb; delete o._bbRev; return o; };
  const inter = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  const distSeg = (px, py, ax, ay, bx, by) => { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let t = l ? ((px - ax) * dx + (py - ay) * dy) / l : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(px - ax - dx * t, py - ay - dy * t); };
  function hit(it, x, y, r) {
    const b = bboxOf(it);
    if (x < b.x - r || x > b.x + b.w + r || y < b.y - r || y > b.y + b.h + r) return false;
    if (it.type === 'stroke') {
      const P = it.pts, extra = it.tool === 'highlighter' ? 1.1 : it.tool === 'air' ? 1 : 0.5;
      if (P.length === 3) return Math.hypot(P[0] - x, P[1] - y) < P[2] * extra + r;
      for (let i = 3; i < P.length; i += 3) if (distSeg(x, y, P[i - 3], P[i - 2], P[i], P[i + 1]) < P[i + 2] * extra + r) return true;
      return false;
    }
    if (it.type === 'shape') {
      if (it.fill && (it.kind === 'rect' || it.kind === 'ellipse')) return true;
      const c = pathOf(it);
      const g = scratch();
      g.lineWidth = it.size + r * 2;
      return g.isPointInStroke(c.p, x, y);
    }
    if (it.type === 'fill') return scratch().isPointInPath(pathOf(it).p, x, y, 'evenodd');
    return true;
  }
  let scratchCtx = null;
  const scratch = () => (scratchCtx ||= document.createElement('canvas').getContext('2d'));

  /** Element verschieben/skalieren (Punkt-Funktion + Massstab für Breiten). */
  function transformItem(it, fx, fy, k) {
    const o = clone(cleanItem(it));
    if (o.type === 'stroke') for (let i = 0; i < o.pts.length; i += 3) { o.pts[i] = f1(fx(o.pts[i])); o.pts[i + 1] = f1(fy(o.pts[i + 1])); o.pts[i + 2] = f1(o.pts[i + 2] * k); }
    else if (o.type === 'shape') { o.x1 = fx(o.x1); o.y1 = fy(o.y1); o.x2 = fx(o.x2); o.y2 = fy(o.y2); o.size *= k; }
    else if (o.type === 'fill') o.polys = o.polys.map((p) => p.map((v, i) => f1(i % 2 ? fy(v) : fx(v))));
    else if (o.type === 'text') { o.x = fx(o.x); o.y = fy(o.y); o.size *= k; }
    else { const x2 = fx(o.x + o.w), y2 = fy(o.y + o.h); o.x = fx(o.x); o.y = fy(o.y); o.w = x2 - o.x; o.h = y2 - o.y; if (o.type === 'note') o.font = (o.font || 18) * k; }
    o.rev = (o.rev || 0) + 1;
    return o;
  }

  /* ================================================================ Zeichnen (Rendern) */
  function drawPaper(g, W, H, view) {
    g.fillStyle = st.doc.bg;
    g.fillRect(0, 0, W, H);
    const kind = st.doc.paper;
    if (kind === 'plain') return;
    let step = 40 * view.z;
    while (step < 14) step *= 5;
    while (step > 400) step /= 5;
    const ox = ((view.x % step) + step) % step, oy = ((view.y % step) + step) % step;
    const dark = luminance(st.doc.bg) < 0.5;
    g.fillStyle = g.strokeStyle = dark ? 'rgba(255,255,255,.14)' : 'rgba(0,0,0,.13)';
    if (kind === 'dots') {
      const r = Math.max(1, Math.min(2.2, step / 22)) * (st.dpr > 1 ? 1.2 : 1);
      for (let x = ox; x < W; x += step) for (let y = oy; y < H; y += step) g.fillRect(x - r / 2, y - r / 2, r, r);
      return;
    }
    g.lineWidth = Math.max(1, st.dpr * 0.8);
    g.beginPath();
    if (kind === 'grid') for (let x = ox; x < W; x += step) { g.moveTo(Math.round(x) + 0.5, 0); g.lineTo(Math.round(x) + 0.5, H); }
    for (let y = oy; y < H; y += step) { g.moveTo(0, Math.round(y) + 0.5); g.lineTo(W, Math.round(y) + 0.5); }
    g.stroke();
  }
  function luminance(hex) { const n = parseInt(String(hex).slice(1), 16); return (0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; }
  function imgOf(src) {
    let e = st.imgCache.get(src);
    if (!e) {
      e = { el: new Image(), ok: false };
      e.el.onload = () => { e.ok = true; for (const l of st.doc?.layers || []) l.ver += 1; requestDraw(); };
      e.el.src = src;
      st.imgCache.set(src, e);
    }
    return e.ok ? e.el : null;
  }
  function wrapLines(g, text, maxW) {
    const out = [];
    for (const para of String(text || '').split('\n')) {
      let line = '';
      for (const word of para.split(' ')) {
        const t = line ? `${line} ${word}` : word;
        if (g.measureText(t).width > maxW && line) { out.push(line); line = word; } else line = t;
      }
      out.push(line);
    }
    return out;
  }
  /** Ein Element in Welt-Koordinaten zeichnen (Transformation ist schon gesetzt). */
  function drawItem(g, it, z) {
    const alpha = it.opacity ?? 1;
    if (it.type === 'stroke') {
      const c = pathOf(it);
      if (!c.p) return;
      g.save();
      if (it.tool === 'eraser') { g.globalCompositeOperation = 'destination-out'; g.fillStyle = '#000'; g.fill(c.p); g.restore(); return; }
      g.globalAlpha = alpha * (it.tool === 'pencil' ? 0.85 : it.tool === 'air' ? 0.55 : it.tool === 'chalk' ? 0.9 : 1);
      if (it.tool === 'marker' || it.tool === 'highlighter') {
        const w = it.pts[2] || it.size;
        g.lineWidth = it.tool === 'highlighter' ? w * 2.2 : w;
        g.lineCap = it.tool === 'highlighter' ? 'square' : 'round';
        g.lineJoin = 'round';
        g.strokeStyle = it.color;
        if (it.tool === 'highlighter') { g.globalAlpha = 0.38 * alpha; g.globalCompositeOperation = 'multiply'; }
        if (it.pts.length === 3) { g.fillStyle = it.color; g.beginPath(); g.arc(it.pts[0], it.pts[1], g.lineWidth / 2, 0, Math.PI * 2); g.fill(); } else g.stroke(c.p);
      } else { g.fillStyle = it.color; g.fill(c.p); }
      g.restore();
      return;
    }
    if (it.type === 'shape') {
      const c = pathOf(it);
      g.save();
      g.globalAlpha = alpha;
      if (it.fill && (it.kind === 'rect' || it.kind === 'ellipse')) { g.fillStyle = it.fill === 2 ? it.color : hexA(it.color, 0.28); g.fill(c.p); }
      g.lineWidth = it.size; g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = it.color;
      g.stroke(c.p);
      g.restore();
      return;
    }
    if (it.type === 'fill') {
      g.save(); g.globalAlpha = alpha; g.fillStyle = it.color; g.fill(pathOf(it).p, 'evenodd'); g.restore();
      return;
    }
    if (it.type === 'text') {
      g.save();
      g.globalAlpha = alpha; g.fillStyle = it.color; g.textBaseline = 'top';
      g.font = `600 ${it.size}px "Segoe UI", system-ui, sans-serif`;
      String(it.text || '').split('\n').forEach((l, i) => g.fillText(l, it.x + 2, it.y + 2 + i * it.size * 1.25));
      g.restore();
      return;
    }
    if (it.type === 'note') {
      g.save();
      g.shadowColor = 'rgba(0,0,0,.22)'; g.shadowBlur = 14 * z; g.shadowOffsetY = 4 * z;
      g.fillStyle = it.color || '#ffe066';
      g.beginPath(); g.roundRect(it.x, it.y, it.w, it.h, Math.min(10, it.w / 10)); g.fill();
      g.shadowColor = 'transparent';
      const fs = it.font || 18;
      g.fillStyle = luminance(it.color || '#ffe066') < 0.45 ? '#fff' : '#1c1c1e'; g.textBaseline = 'top';
      g.font = `600 ${fs}px "Segoe UI", system-ui, sans-serif`;
      const lines = wrapLines(g, it.text, it.w - fs * 1.2);
      lines.forEach((l, i) => { if (fs * 0.6 + (i + 1) * fs * 1.3 < it.h) g.fillText(l, it.x + fs * 0.6, it.y + fs * 0.6 + i * fs * 1.3); });
      g.restore();
      return;
    }
    if (it.type === 'image') {
      const im = imgOf(it.src);
      if (im) { g.save(); g.globalAlpha = alpha; g.imageSmoothingQuality = 'high'; g.drawImage(im, it.x, it.y, it.w, it.h); g.restore(); }
    }
  }
  const hexA = (hex, a) => { const n = parseInt(String(hex).slice(1), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
  function itemsByLayer() {
    if (st._byLayerVer === st.ver && st._byLayer) return st._byLayer;
    const m = new Map(st.doc.layers.map((l) => [l.id, []]));
    for (const it of st.doc.items) (m.get(it.layer) || m.get(st.doc.layers[0].id)).push(it);
    st._byLayer = m;
    st._byLayerVer = st.ver;
    return m;
  }
  /** Eine Ebene in einen Puffer zeichnen (zwischengespeichert, solange Ansicht und Ebene gleich bleiben). */
  function layerBitmap(l, W, H, view, extra) {
    const key = `${W}x${H}|${view.x}|${view.y}|${view.z}|${l.ver}`;
    let c = st.layerCache.get(l.id);
    if (!c) { c = { canvas: document.createElement('canvas'), key: '' }; st.layerCache.set(l.id, c); }
    if (c.canvas.width !== W || c.canvas.height !== H) { c.canvas.width = W; c.canvas.height = H; c.key = ''; }
    if (c.key !== key) {
      const g = c.canvas.getContext('2d');
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.clearRect(0, 0, W, H);
      g.setTransform(view.z, 0, 0, view.z, view.x, view.y);
      const vis = { x: -view.x / view.z, y: -view.y / view.z, w: W / view.z, h: H / view.z };
      for (const it of itemsByLayer().get(l.id) || []) if (inter(bboxOf(it), vis)) drawItem(g, it, view.z);
      c.key = key;
    }
    if (!extra) return c.canvas;
    // aktueller Strich (auch Radierer) auf einer Kopie der Ebene
    let t = st._liveBuf;
    if (!t) t = st._liveBuf = document.createElement('canvas');
    if (t.width !== W || t.height !== H) { t.width = W; t.height = H; }
    const g = t.getContext('2d');
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.clearRect(0, 0, W, H);
    g.drawImage(c.canvas, 0, 0);
    g.setTransform(view.z, 0, 0, view.z, view.x, view.y);
    for (const it of extra) drawItem(g, it, view.z);
    return t;
  }
  /** Ganzes Blatt in einen Kontext zeichnen (Bildschirm oder Export). */
  function renderTo(g, W, H, view, { paper = true, overlays = false } = {}) {
    g.setTransform(1, 0, 0, 1, 0, 0);
    if (paper) drawPaper(g, W, H, view); else g.clearRect(0, 0, W, H);
    const liveLayer = st.live?.item ? st.live.item.layer : null;
    const ghostsBy = new Map();
    if (overlays) for (const gh of st.ghosts.values()) { if (!ghostsBy.has(gh.layer)) ghostsBy.set(gh.layer, []); ghostsBy.get(gh.layer).push(gh); }
    for (const l of st.doc.layers) {
      if (!l.visible) continue;
      const extra = [];
      if (overlays && l.id === liveLayer) extra.push(st.live.item);
      if (overlays && ghostsBy.has(l.id)) extra.push(...ghostsBy.get(l.id));
      const bmp = layerBitmap(l, W, H, view, extra.length ? extra : null);
      g.globalAlpha = l.opacity ?? 1;
      g.drawImage(bmp, 0, 0);
      g.globalAlpha = 1;
    }
    if (overlays) drawOverlays(g, view);
  }
  function drawOverlays(g, view) {
    const sx = (x) => x * view.z + view.x, sy = (y) => y * view.z + view.y;
    g.setTransform(1, 0, 0, 1, 0, 0);
    // Auswahl
    if (st.sel.size) {
      const b = selBox();
      if (b) {
        g.save();
        g.strokeStyle = '#0a84ff'; g.lineWidth = 1.5 * st.dpr; g.setLineDash([6 * st.dpr, 4 * st.dpr]);
        g.strokeRect(sx(b.x), sy(b.y), b.w * view.z, b.h * view.z);
        g.setLineDash([]); g.fillStyle = '#fff'; g.lineWidth = 2 * st.dpr;
        const hs = 9 * st.dpr;
        g.beginPath(); g.rect(sx(b.x + b.w) - hs / 2, sy(b.y + b.h) - hs / 2, hs, hs); g.fill(); g.stroke();
        g.restore();
      }
    }
    if (st.lasso?.length > 1) {
      g.save(); g.strokeStyle = '#0a84ff'; g.fillStyle = 'rgba(10,132,255,.08)'; g.lineWidth = 1.5 * st.dpr; g.setLineDash([5 * st.dpr, 4 * st.dpr]);
      g.beginPath(); st.lasso.forEach((p, i) => (i ? g.lineTo(sx(p.x), sy(p.y)) : g.moveTo(sx(p.x), sy(p.y)))); g.closePath(); g.fill(); g.stroke(); g.restore();
    }
    // Laser (eigener + von anderen)
    const now = performance.now();
    const drawLaser = (pts, col) => {
      const live = pts.filter((p) => now - p.t < 1400);
      if (live.length < 1) return;
      g.save(); g.lineCap = 'round'; g.lineJoin = 'round';
      for (let i = 1; i < live.length; i++) {
        const a = live[i - 1], b = live[i], age = (now - b.t) / 1400;
        g.strokeStyle = col; g.globalAlpha = Math.max(0, 1 - age); g.lineWidth = (6 - age * 4) * st.dpr;
        g.shadowColor = col; g.shadowBlur = 12 * st.dpr;
        g.beginPath(); g.moveTo(sx(a.x), sy(a.y)); g.lineTo(sx(b.x), sy(b.y)); g.stroke();
      }
      const l = live[live.length - 1];
      g.globalAlpha = 1; g.fillStyle = '#fff'; g.beginPath(); g.arc(sx(l.x), sy(l.y), 3.5 * st.dpr, 0, Math.PI * 2); g.fill();
      g.restore();
    };
    drawLaser(st.laser, '#ff2d55');
    for (const p of st.peers.values()) {
      if (p.laser?.length) drawLaser(p.laser, p.color);
      if (p.cur && now - p.cur.t < 8000) {
        const x = sx(p.cur.x), y = sy(p.cur.y);
        g.save();
        g.fillStyle = p.color; g.strokeStyle = '#fff'; g.lineWidth = 1.5 * st.dpr;
        g.beginPath(); g.moveTo(x, y); g.lineTo(x + 3 * st.dpr, y + 15 * st.dpr); g.lineTo(x + 7 * st.dpr, y + 10 * st.dpr); g.lineTo(x + 13 * st.dpr, y + 9 * st.dpr); g.closePath(); g.fill(); g.stroke();
        g.font = `700 ${11 * st.dpr}px "Segoe UI", sans-serif`;
        const w = g.measureText(p.name).width + 10 * st.dpr;
        g.beginPath(); g.roundRect(x + 12 * st.dpr, y + 14 * st.dpr, w, 18 * st.dpr, 9 * st.dpr); g.fill();
        g.fillStyle = '#fff'; g.textBaseline = 'middle'; g.fillText(p.name, x + 17 * st.dpr, y + 23 * st.dpr);
        g.restore();
      }
    }
    // Pinsel-Vorschau (Kreis) für Stift/Maus
    if (st.hover && BRUSH.has(st.tool) && !st.live && !st.ptrs.size) {
      const r = Math.max(1, brushWorld() * (st.tool === 'highlighter' ? 1.1 : 0.5) * view.z);
      g.save(); g.strokeStyle = luminance(st.doc.bg) < 0.5 ? 'rgba(255,255,255,.6)' : 'rgba(0,0,0,.45)'; g.lineWidth = st.dpr;
      g.beginPath(); g.arc(st.hover.x, st.hover.y, r, 0, Math.PI * 2); g.stroke(); g.restore();
    }
  }
  function requestDraw() {
    if (st.raf) return;
    st.raf = requestAnimationFrame(() => {
      st.raf = 0;
      if (!st.view || !st.doc) return;
      renderTo(st.ctx, st.view.width, st.view.height, st.doc.view, { overlays: true });
      // Laser verblasst – weiterzeichnen, solange Spuren da sind
      const now = performance.now();
      if (st.laser.some((p) => now - p.t < 1400) || [...st.peers.values()].some((p) => p.laser?.some((q) => now - q.t < 1400))) requestDraw();
    });
  }

  /* ================================================================ Änderungen, Rückgängig, Teilen */
  /** Änderungen anwenden: add / del / upd / layers / meta. remote = kommt von jemand anderem. */
  function apply(ops, { remote = false, record = null } = {}) {
    const inverse = [];
    for (const op of ops) {
      if (op.op === 'add') {
        for (const raw of op.items) {
          const it = hide({ ...raw, rev: (raw.rev || 0) + 0 });
          if (st.items.has(it.id)) { const i = st.doc.items.findIndex((x) => x.id === it.id); st.doc.items[i] = it; } else st.doc.items.push(it);
          st.items.set(it.id, it);
          bumpLayer(it.layer);
        }
        inverse.unshift({ op: 'del', ids: op.items.map((x) => x.id) });
      } else if (op.op === 'del') {
        const gone = [];
        const ids = new Set(op.ids);
        st.doc.items = st.doc.items.filter((it) => { if (ids.has(it.id)) { gone.push(cleanItem(it)); bumpLayer(it.layer); return false; } return true; });
        for (const id of op.ids) { st.items.delete(id); st.pathCache.delete(id); st.sel.delete(id); }
        if (gone.length) inverse.unshift({ op: 'add', items: gone });
      } else if (op.op === 'upd') {
        const before = [];
        for (const raw of op.items) {
          const cur = st.items.get(raw.id);
          if (!cur) continue;
          before.push(cleanItem(cur));
          const it = hide({ ...raw });
          const i = st.doc.items.indexOf(cur);
          st.doc.items[i] = it;
          st.items.set(it.id, it);
          bumpLayer(cur.layer); bumpLayer(it.layer);
        }
        if (before.length) inverse.unshift({ op: 'upd', items: before });
      } else if (op.op === 'order') {
        const prev = st.doc.items.map((x) => x.id);
        const pos = new Map(op.ids.map((id, i) => [id, i]));
        st.doc.items.sort((a, b) => (pos.get(a.id) ?? 1e9) - (pos.get(b.id) ?? 1e9));
        st.ver += 1; for (const l of st.doc.layers) l.ver += 1;
        inverse.unshift({ op: 'order', ids: prev });
      } else if (op.op === 'layers') {
        inverse.unshift({ op: 'layers', layers: clone(st.doc.layers), active: st.doc.active });
        const old = new Map(st.doc.layers.map((l) => [l.id, l]));
        st.doc.layers = op.layers.map((l) => ({ ...l, ver: (old.get(l.id)?.ver || 0) + 1 }));
        if (!remote && op.active) st.doc.active = op.active;
        if (!layerOf(st.doc.active)) st.doc.active = st.doc.layers[st.doc.layers.length - 1].id;
        st.ver += 1;
      } else if (op.op === 'meta') {
        inverse.unshift({ op: 'meta', bg: st.doc.bg, paper: st.doc.paper });
        if (op.bg) st.doc.bg = op.bg;
        if (op.paper) st.doc.paper = op.paper;
        st.ver += 1;
      }
    }
    if (record) { st.undo.push({ undo: inverse, redo: ops }); if (st.undo.length > 200) st.undo.shift(); st.redo = []; }
    if (!remote) sendOps(ops);
    queueSave();
    requestDraw();
    if (ops.some((o) => o.op === 'layers' || o.op === 'meta')) paintSide();
    return inverse;
  }
  const commit = (ops) => apply(ops, { record: true });
  function undo(back = true) {
    const from = back ? st.undo : st.redo;
    const e = from.pop();
    if (!e) return;
    apply(back ? e.undo : e.redo);
    (back ? st.redo : st.undo).push(e);
    paintSelBar();
  }

  /* ================================================================ Pinsel */
  const brushWorld = () => (st.scaleWithZoom ? st.size / zoomPct() : st.size);
  function widthFor(pressure, pointerType, speed, dwell) {
    const pr = pointerType === 'mouse' || !pressure ? 0.5 : pressure;
    const press = 0.3 + pr * 1.4;
    const fast = Math.max(0.35, Math.min(1.25, 1.25 - speed * 0.35));
    const stay = 1 + Math.min(1.6, dwell / 600);
    return Math.max(0.3, brushWorld() * press * fast * stay);
  }
  const toWorld = (e) => {
    const r = st.view.getBoundingClientRect();
    const v = st.doc.view;
    return { x: ((e.clientX - r.left) * st.dpr - v.x) / v.z, y: ((e.clientY - r.top) * st.dpr - v.y) / v.z };
  };
  function startStroke(e, tool) {
    const p = toWorld(e);
    const L = activeLayer();
    if (!L.visible) { A.toast('Diese Ebene ist ausgeblendet.', 'error'); return null; }
    const now = performance.now();
    const it = { id: uid(), type: 'stroke', tool, layer: L.id, color: st.color, opacity: st.opacity, size: brushWorld(), pts: [], rev: 1 };
    const w0 = tool === 'marker' || tool === 'highlighter' ? brushWorld() : tool === 'air' ? brushWorld() * 2 : tool === 'chalk' ? widthFor(e.pressure, e.pointerType, 0, 0) * 1.9 : tool === 'pencil' ? widthFor(e.pressure, e.pointerType, 0, 0) * 0.5 : widthFor(e.pressure, e.pointerType, 0, 0);
    it.pts.push(f1(p.x), f1(p.y), f1(w0));
    const s = { kind: 'stroke', item: it, tool, smooth: { ...p }, last: { ...p, t: now }, dwell: 0, lastMoveAt: now, pointerType: e.pointerType, lastW: w0 };
    s.timer = setInterval(() => {
      if (st.live !== s) return clearInterval(s.timer);
      const t = performance.now();
      if (t - s.lastMoveAt < 70) return;
      // Verweilen: Füller/Kreide/Airbrush werden breiter
      if (['pen', 'chalk', 'air'].includes(s.tool)) {
        s.dwell += 70;
        const n = it.pts.length;
        const w = s.tool === 'air' ? brushWorld() * 2 * (1 + Math.min(1, s.dwell / 1200)) : widthFor(s.lastPressure ?? e.pressure, s.pointerType, 0, s.dwell) * (s.tool === 'chalk' ? 1.9 : 1);
        it.pts[n - 1] = f1(Math.max(it.pts[n - 1], w));
        it.rev += 1;
        requestDraw();
      }
      // Form-Assistent: still halten → saubere Form
      if (st.assist && !s.shaped && t - s.lastMoveAt > 650 && it.pts.length > 12 && ['pen', 'pencil', 'marker', 'chalk'].includes(s.tool)) {
        const shp = recognize(it);
        if (shp) { s.shaped = shp; st.live = { kind: 'shape', item: shp, recognized: true }; clearInterval(s.timer); requestDraw(); }
      }
    }, 70);
    return s;
  }
  function moveStroke(s, e) {
    const events = e.getCoalescedEvents?.() || [];
    for (const ev of events.length ? events : [e]) {
      const raw = toWorld(ev);
      const k = 1 - st.smooth * 0.85;
      s.smooth.x += (raw.x - s.smooth.x) * k;
      s.smooth.y += (raw.y - s.smooth.y) * k;
      const now = performance.now();
      const dist = Math.hypot(s.smooth.x - s.last.x, s.smooth.y - s.last.y);
      if (dist * st.doc.view.z < 0.8) continue;
      const speed = (dist * st.doc.view.z) / st.dpr / Math.max(1, now - s.last.t);
      if (dist * st.doc.view.z > 2) { s.lastMoveAt = now; s.dwell = Math.max(0, s.dwell - dist * st.doc.view.z * 6); }
      s.lastPressure = ev.pressure;
      let w;
      if (s.tool === 'marker' || s.tool === 'highlighter') w = brushWorld();
      else if (s.tool === 'air') w = brushWorld() * 2;
      else {
        w = widthFor(ev.pressure, s.pointerType, speed, s.dwell) * (s.tool === 'chalk' ? 1.9 : s.tool === 'pencil' ? 0.5 : 1);
        w = s.lastW + (w - s.lastW) * 0.35;
      }
      s.lastW = w;
      s.item.pts.push(f1(s.smooth.x), f1(s.smooth.y), f1(w));
      s.item.rev += 1;
      s.last = { x: s.smooth.x, y: s.smooth.y, t: now };
    }
    sendLive(s.item);
    requestDraw();
  }
  function startShape(e, kind) {
    const p = toWorld(e);
    const L = activeLayer();
    const it = { id: uid(), type: 'shape', kind, layer: L.id, x1: f1(p.x), y1: f1(p.y), x2: f1(p.x), y2: f1(p.y), color: st.color, size: Math.max(0.5, brushWorld() * 0.6), opacity: st.opacity, fill: kind === 'rect' || kind === 'ellipse' ? st.shapeFill : 0, rev: 1 };
    return { kind: 'shape', item: it, start: p };
  }
  function moveShape(s, e) {
    const p = toWorld(e);
    let { x, y } = p;
    if (e.shiftKey) {
      if (s.item.kind === 'line' || s.item.kind === 'arrow') {
        const a = Math.round(Math.atan2(y - s.start.y, x - s.start.x) / (Math.PI / 4)) * (Math.PI / 4), d = Math.hypot(x - s.start.x, y - s.start.y);
        x = s.start.x + Math.cos(a) * d; y = s.start.y + Math.sin(a) * d;
      } else { const m = Math.max(Math.abs(x - s.start.x), Math.abs(y - s.start.y)); x = s.start.x + Math.sign(x - s.start.x || 1) * m; y = s.start.y + Math.sign(y - s.start.y || 1) * m; }
    }
    s.item.x2 = f1(x); s.item.y2 = f1(y); s.item.rev += 1;
    sendLive(s.item);
    requestDraw();
  }
  function endLive() {
    const s = st.live;
    if (!s) return;
    clearInterval(s.timer);
    st.live = null;
    sendLive(null);
    const it = s.item;
    if (s.kind === 'shape' && !s.recognized && Math.hypot(it.x2 - it.x1, it.y2 - it.y1) < 1) return requestDraw();
    commit([{ op: 'add', items: [cleanItem(it)] }]);
    if (it.type === 'stroke' && it.tool !== 'eraser') pushRecent(it.color);
  }

  /** Form-Assistent: Strich als Linie, Rechteck oder Ellipse erkennen. */
  function recognize(it) {
    const P = ptsOf(it);
    const a = P[0], b = P[P.length - 1];
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, len = 0;
    P.forEach((p, i) => { x0 = Math.min(x0, p.x); y0 = Math.min(y0, p.y); x1 = Math.max(x1, p.x); y1 = Math.max(y1, p.y); if (i) len += Math.hypot(p.x - P[i - 1].x, p.y - P[i - 1].y); });
    const diag = Math.hypot(x1 - x0, y1 - y0);
    if (diag < 12 / zoomPct()) return null;
    const avgW = P.reduce((s, p) => s + p.w, 0) / P.length;
    const base = { id: it.id, type: 'shape', layer: it.layer, color: it.color, size: Math.max(0.5, avgW * 0.8), opacity: it.opacity, fill: 0, rev: (it.rev || 0) + 1 };
    // gerade?
    const straight = Math.hypot(b.x - a.x, b.y - a.y);
    const maxDev = Math.max(...P.map((p) => distSeg(p.x, p.y, a.x, a.y, b.x, b.y)));
    if (straight > 0.85 * len && maxDev < Math.max(4 / zoomPct(), straight * 0.05)) return { ...base, kind: 'line', x1: a.x, y1: a.y, x2: b.x, y2: b.y };
    // geschlossen?
    if (Math.hypot(b.x - a.x, b.y - a.y) > diag * 0.25) return null;
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, rx = (x1 - x0) / 2, ry = (y1 - y0) / 2;
    if (rx < 3 || ry < 3) return null;
    const ell = P.reduce((s, p) => s + Math.abs(Math.hypot((p.x - cx) / rx, (p.y - cy) / ry) - 1), 0) / P.length;
    const rect = P.reduce((s, p) => s + Math.min(Math.abs(p.x - x0), Math.abs(p.x - x1), Math.abs(p.y - y0), Math.abs(p.y - y1)), 0) / P.length / Math.max(rx, ry);
    if (rect < 0.06 && rect * 2.2 < ell) return { ...base, kind: 'rect', x1: x0, y1: y0, x2: x1, y2: y1 };
    if (ell < 0.12) return { ...base, kind: 'ellipse', x1: x0, y1: y0, x2: x1, y2: y1 };
    if (rect < 0.08) return { ...base, kind: 'rect', x1: x0, y1: y0, x2: x1, y2: y1 };
    return null;
  }

  /* ================================================================ Strich-Radierer, Auswahl */
  function objectErase(e) {
    const p = toWorld(e);
    const r = Math.max(2, brushWorld() * 0.6);
    const L = activeLayer();
    const hits = st.doc.items.filter((it) => it.layer === L.id && !st.live.gone.has(it.id) && hit(it, p.x, p.y, r));
    if (!hits.length) return;
    for (const it of hits) st.live.gone.add(it.id);
    apply([{ op: 'del', ids: hits.map((x) => x.id) }]).forEach((op) => st.live.inverse.push(op));
  }
  function selBox() {
    let b = null;
    for (const id of st.sel) {
      const it = st.items.get(id);
      if (!it) continue;
      const q = bboxOf(it);
      b = b ? { x: Math.min(b.x, q.x), y: Math.min(b.y, q.y), r: Math.max(b.r, q.x + q.w), bt: Math.max(b.bt, q.y + q.h) } : { x: q.x, y: q.y, r: q.x + q.w, bt: q.y + q.h };
    }
    return b ? { x: b.x, y: b.y, w: b.r - b.x, h: b.bt - b.y } : null;
  }
  function inPoly(x, y, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i], b = poly[j];
      if ((a.y > y) !== (b.y > y) && x < ((b.x - a.x) * (y - a.y)) / (b.y - a.y) + a.x) inside = !inside;
    }
    return inside;
  }
  function samplePts(it) {
    if (it.type === 'stroke') { const out = []; const step = Math.max(3, Math.floor(it.pts.length / 60 / 3) * 3); for (let i = 0; i < it.pts.length; i += step) out.push({ x: it.pts[i], y: it.pts[i + 1] }); return out; }
    if (it.type === 'shape') return [{ x: it.x1, y: it.y1 }, { x: it.x2, y: it.y2 }, { x: (it.x1 + it.x2) / 2, y: (it.y1 + it.y2) / 2 }];
    const b = bboxOf(it);
    return [{ x: b.x, y: b.y }, { x: b.x + b.w, y: b.y }, { x: b.x, y: b.y + b.h }, { x: b.x + b.w, y: b.y + b.h }, { x: b.x + b.w / 2, y: b.y + b.h / 2 }];
  }
  function finishLasso() {
    const poly = st.lasso;
    st.lasso = null;
    st.sel.clear();
    if (!poly || poly.length < 3) return;
    const bb = { x: Math.min(...poly.map((p) => p.x)), y: Math.min(...poly.map((p) => p.y)) };
    bb.w = Math.max(...poly.map((p) => p.x)) - bb.x; bb.h = Math.max(...poly.map((p) => p.y)) - bb.y;
    const L = activeLayer();
    const small = bb.w * zoomPct() < 5 && bb.h * zoomPct() < 5;
    if (small) {
      // Klick: oberstes Element unter dem Zeiger (alle sichtbaren Ebenen)
      const p = poly[0];
      for (let i = st.doc.items.length - 1; i >= 0; i--) { const it = st.doc.items[i]; if (layerOf(it.layer)?.visible && it.tool !== 'eraser' && hit(it, p.x, p.y, 4 / zoomPct())) { st.sel.add(it.id); break; } }
    } else {
      for (const it of st.doc.items) {
        if (it.layer !== L.id || it.tool === 'eraser' || !inter(bboxOf(it), bb)) continue;
        const s = samplePts(it);
        if (s.filter((q) => inPoly(q.x, q.y, poly)).length >= Math.ceil(s.length * 0.6)) st.sel.add(it.id);
      }
    }
    paintSelBar();
  }
  function startSelDrag(e) {
    const p = toWorld(e);
    const b = selBox();
    if (!b) return null;
    const hs = 12 / st.doc.view.z * st.dpr;
    const onHandle = Math.abs(p.x - (b.x + b.w)) < hs && Math.abs(p.y - (b.y + b.h)) < hs;
    const inside = p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h;
    if (!onHandle && !inside) return null;
    return { kind: 'seldrag', mode: onHandle ? 'scale' : 'move', start: p, box: b, orig: [...st.sel].map((id) => cleanItem(st.items.get(id))).filter(Boolean) };
  }
  function moveSelDrag(s, e) {
    const p = toWorld(e);
    let fx, fy, k = 1;
    if (s.mode === 'move') { const dx = p.x - s.start.x, dy = p.y - s.start.y; fx = (x) => x + dx; fy = (y) => y + dy; }
    else {
      const d0 = Math.hypot(s.box.w, s.box.h) || 1, d1 = Math.hypot(Math.max(1, p.x - s.box.x), Math.max(1, p.y - s.box.y));
      k = Math.max(0.05, d1 / d0);
      fx = (x) => s.box.x + (x - s.box.x) * k; fy = (y) => s.box.y + (y - s.box.y) * k;
    }
    for (const o of s.orig) {
      const t = transformItem(o, fx, fy, k);
      const cur = st.items.get(o.id);
      const i = st.doc.items.indexOf(cur);
      if (i >= 0) { st.doc.items[i] = hide(t); st.items.set(t.id, st.doc.items[i]); }
      bumpLayer(t.layer);
    }
    s.moved = true;
    requestDraw();
  }
  function endSelDrag(s) {
    if (!s.moved) return;
    const after = s.orig.map((o) => cleanItem(st.items.get(o.id)));
    st.undo.push({ undo: [{ op: 'upd', items: s.orig }], redo: [{ op: 'upd', items: after }] });
    st.redo = [];
    sendOps([{ op: 'upd', items: after }]);
    queueSave();
  }
  function selItems() { return [...st.sel].map((id) => st.items.get(id)).filter(Boolean); }
  function selAction(a) {
    const items = selItems();
    if (!items.length) return;
    if (a === 'delete') { commit([{ op: 'del', ids: items.map((x) => x.id) }]); st.sel.clear(); }
    else if (a === 'dup') {
      const d = 24 / zoomPct();
      const copies = items.map((it) => ({ ...transformItem(it, (x) => x + d, (y) => y + d, 1), id: uid() }));
      commit([{ op: 'add', items: copies }]);
      st.sel = new Set(copies.map((c) => c.id));
    } else if (a === 'copy') { st.clip = items.map(cleanItem); A.toast(`${items.length} kopiert`); }
    else if (a === 'front' || a === 'back') {
      const ids = new Set(items.map((x) => x.id));
      const rest = st.doc.items.filter((x) => !ids.has(x.id)).map((x) => x.id), mine = st.doc.items.filter((x) => ids.has(x.id)).map((x) => x.id);
      commit([{ op: 'order', ids: a === 'front' ? [...rest, ...mine] : [...mine, ...rest] }]);
    } else if (a === 'recolor') {
      commit([{ op: 'upd', items: items.filter((it) => it.tool !== 'eraser' && it.type !== 'image').map((it) => ({ ...cleanItem(it), color: st.color, rev: (it.rev || 0) + 1 })) }]);
    }
    paintSelBar();
    requestDraw();
  }
  function pasteClip() {
    if (!st.clip?.length) return false;
    const d = 30 / zoomPct();
    const L = activeLayer();
    const copies = st.clip.map((it) => ({ ...transformItem(it, (x) => x + d, (y) => y + d, 1), id: uid(), layer: L.id }));
    st.clip = copies.map(cleanItem);
    commit([{ op: 'add', items: copies }]);
    st.sel = new Set(copies.map((c) => c.id));
    paintSelBar();
    return true;
  }

  /* ================================================================ Füllen (bleibt scharf: Fläche wird als Vektor nachgezeichnet) */
  function fillAt(e) {
    const v = st.doc.view;
    const W0 = st.view.width, H0 = st.view.height;
    const k = Math.min(1.5, 3200 / Math.max(W0, H0));
    const W = Math.round(W0 * k), H = Math.round(H0 * k);
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const g = c.getContext('2d', { willReadFrequently: true });
    const view = { x: v.x * k, y: v.y * k, z: v.z * k };
    g.fillStyle = '#ffffff'; g.fillRect(0, 0, W, H);
    for (const l of st.doc.layers) if (l.visible) { g.globalAlpha = l.opacity ?? 1; g.drawImage(layerBitmap(l, W, H, view), 0, 0); }
    g.globalAlpha = 1;
    st.layerCache.clear(); // Puffer hatten Export-Grösse
    const r = st.view.getBoundingClientRect();
    const x0 = Math.round((e.clientX - r.left) * st.dpr * k), y0 = Math.round((e.clientY - r.top) * st.dpr * k);
    if (x0 < 0 || y0 < 0 || x0 >= W || y0 >= H) return;
    const d = g.getImageData(0, 0, W, H).data;
    const i0 = (y0 * W + x0) * 4, t = [d[i0], d[i0 + 1], d[i0 + 2]];
    const same = (i) => Math.abs(d[i] - t[0]) <= 40 && Math.abs(d[i + 1] - t[1]) <= 40 && Math.abs(d[i + 2] - t[2]) <= 40;
    const mask = new Uint8Array(W * H);
    const stack = [x0, y0];
    let open = false, count = 0;
    while (stack.length) {
      const y = stack.pop();
      let x = stack.pop();
      while (x >= 0 && !mask[y * W + x] && same((y * W + x) * 4)) x--;
      x++;
      let up = false, dn = false;
      while (x < W && !mask[y * W + x] && same((y * W + x) * 4)) {
        mask[y * W + x] = 1; count++;
        if (x === 0 || x === W - 1 || y === 0 || y === H - 1) open = true;
        if (y > 0) { const u = !mask[(y - 1) * W + x] && same(((y - 1) * W + x) * 4); if (u && !up) { stack.push(x, y - 1); up = true; } else if (!u) up = false; }
        if (y < H - 1) { const q = !mask[(y + 1) * W + x] && same(((y + 1) * W + x) * 4); if (q && !dn) { stack.push(x, y + 1); dn = true; } else if (!q) dn = false; }
        x++;
      }
    }
    if (!count) return;
    // 1 Pixel ausdehnen (deckt die weichen Kanten der Linien ab)
    const m2 = mask.slice();
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) if (!mask[y * W + x] && (mask[y * W + x - 1] || mask[y * W + x + 1] || mask[(y - 1) * W + x] || mask[(y + 1) * W + x])) m2[y * W + x] = 1;
    const polys = traceMask(m2, W, H).map((poly) => {
      const simp = rdp(poly, 0.9);
      const out = [];
      for (const [px, py] of simp) out.push(f1((px / k - v.x) / v.z), f1((py / k - v.y) / v.z));
      return out;
    }).filter((p) => p.length >= 6);
    if (!polys.length) return;
    const L = activeLayer();
    commit([{ op: 'add', items: [{ id: uid(), type: 'fill', layer: L.id, color: st.color, opacity: st.opacity, polys, rev: 1 }] }]);
    pushRecent(st.color);
    if (open) A.toast('Die Fläche war nicht geschlossen – bis zum Rand der Ansicht gefüllt.');
  }
  /** Ränder einer Maske als geschlossene Polygone (Pixelkanten, innen rechts). */
  function traceMask(mask, W, H) {
    const next = new Map();
    const key = (x, y) => y * (W + 1) + x;
    const add = (ax, ay, bx, by) => { const k = key(ax, ay); const v = next.get(k); if (v) v.push(key(bx, by)); else next.set(k, [key(bx, by)]); };
    const at = (x, y) => x >= 0 && y >= 0 && x < W && y < H && mask[y * W + x];
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (!mask[y * W + x]) continue;
      if (!at(x, y - 1)) add(x, y, x + 1, y);
      if (!at(x + 1, y)) add(x + 1, y, x + 1, y + 1);
      if (!at(x, y + 1)) add(x + 1, y + 1, x, y + 1);
      if (!at(x - 1, y)) add(x, y + 1, x, y);
    }
    const polys = [];
    for (const [startKey, list] of next) {
      while (list.length) {
        const poly = [];
        let k = startKey;
        let guard = 0;
        do {
          poly.push([k % (W + 1), Math.floor(k / (W + 1))]);
          const l = next.get(k);
          if (!l || !l.length) break;
          k = l.pop();
        } while (k !== startKey && ++guard < 4e6);
        if (poly.length > 2) polys.push(poly);
      }
    }
    return polys;
  }
  function rdp(pts, eps) {
    if (pts.length < 4) return pts;
    const keep = new Uint8Array(pts.length);
    keep[0] = keep[pts.length - 1] = 1;
    const stack = [[0, pts.length - 1]];
    while (stack.length) {
      const [a, b] = stack.pop();
      let md = 0, mi = -1;
      for (let i = a + 1; i < b; i++) { const d = distSeg(pts[i][0], pts[i][1], pts[a][0], pts[a][1], pts[b][0], pts[b][1]); if (d > md) { md = d; mi = i; } }
      if (md > eps && mi > 0) { keep[mi] = 1; stack.push([a, mi], [mi, b]); }
    }
    return pts.filter((_, i) => keep[i]);
  }

  /* ================================================================ Text und Notizen */
  function openText(it, isNew) {
    closeText(true);
    const ta = document.createElement('textarea');
    ta.className = 'dz-textedit';
    ta.value = it.text || '';
    st.root.querySelector('.dz-stage').appendChild(ta);
    st.textEdit = { ta, item: it, isNew, before: isNew ? null : cleanItem(it) };
    placeText();
    setTimeout(() => ta.focus(), 0);
    ta.addEventListener('input', () => { it.text = ta.value; it.rev = (it.rev || 0) + 1; hide(it); bumpLayer(it.layer); requestDraw(); placeText(); });
    ta.addEventListener('keydown', (e) => { if (e.key === 'Escape' || (e.key === 'Enter' && (e.ctrlKey || e.metaKey))) { e.preventDefault(); closeText(true); } e.stopPropagation(); });
    ta.addEventListener('blur', () => setTimeout(() => closeText(true), 50));
    if (isNew) { st.doc.items.push(it); st.items.set(it.id, it); bumpLayer(it.layer); }
    requestDraw();
  }
  function placeText() {
    const t = st.textEdit;
    if (!t) return;
    const v = st.doc.view, it = t.item;
    const sx = (it.x * v.z + v.x) / st.dpr, sy = (it.y * v.z + v.y) / st.dpr;
    const fs = ((it.type === 'note' ? it.font || 18 : it.size) * v.z) / st.dpr;
    Object.assign(t.ta.style, {
      left: `${sx + (it.type === 'note' ? fs * 0.6 : 2)}px`, top: `${sy + (it.type === 'note' ? fs * 0.6 : 2)}px`, fontSize: `${fs}px`, color: 'transparent', caretColor: it.type === 'note' ? '#111' : it.color,
      width: it.type === 'note' ? `${(it.w * v.z) / st.dpr - fs * 1.2}px` : `${Math.max(120, (bboxOf(it).w * v.z) / st.dpr + fs * 2)}px`,
      height: it.type === 'note' ? `${(it.h * v.z) / st.dpr - fs * 1.2}px` : `${Math.max(fs * 1.5, (bboxOf(it).h * v.z) / st.dpr + fs)}px`,
    });
  }
  function closeText(save) {
    const t = st.textEdit;
    if (!t) return;
    st.textEdit = null;
    t.ta.remove();
    const it = t.item;
    const empty = !String(it.text || '').trim() && it.type === 'text';
    if (t.isNew) {
      // als echte Änderung übernehmen (rückgängig + teilen)
      st.doc.items = st.doc.items.filter((x) => x !== it);
      st.items.delete(it.id);
      bumpLayer(it.layer);
      if (save && !empty) commit([{ op: 'add', items: [cleanItem(it)] }]);
    } else if (save && empty) commit([{ op: 'del', ids: [it.id] }]);
    else if (save && t.before && t.before.text !== it.text) {
      st.undo.push({ undo: [{ op: 'upd', items: [t.before] }], redo: [{ op: 'upd', items: [cleanItem(it)] }] });
      sendOps([{ op: 'upd', items: [cleanItem(it)] }]);
      queueSave();
    }
    requestDraw();
  }
  function textAt(e, kind) {
    const p = toWorld(e);
    // bestehenden Text / Zettel bearbeiten
    for (let i = st.doc.items.length - 1; i >= 0; i--) {
      const it = st.doc.items[i];
      if ((it.type === 'text' || it.type === 'note') && layerOf(it.layer)?.visible && hit(it, p.x, p.y, 0)) return openText(it, false);
    }
    const L = activeLayer();
    const z = zoomPct();
    if (kind === 'note') {
      const w = 220 / z, h = 180 / z;
      openText({ id: uid(), type: 'note', layer: L.id, x: p.x - w / 2, y: p.y - h / 2, w, h, text: '', color: '#ffe066', font: 18 / z, rev: 1 }, true);
    } else openText({ id: uid(), type: 'text', layer: L.id, x: p.x, y: p.y - (brushWorld() * 2.6) / 2, text: '', color: st.color, size: Math.max(6 / z, brushWorld() * 2.6), opacity: st.opacity, rev: 1 }, true);
  }

  /* ================================================================ Bilder */
  function addImage(src, at, opt = {}) {
    const im = new Image();
    im.onload = () => {
      // grosse Bilder verkleinern (teilen bleibt schnell)
      let url = src;
      const max = opt.max || 1600; // Screenshots: volle Auflösung (bis 4K), damit Text scharf bleibt
      if (Math.max(im.width, im.height) > max || (!opt.max && src.length > 1.5e6)) {
        const k = Math.min(1, max / Math.max(im.width, im.height));
        const c = document.createElement('canvas');
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        url = opt.max ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', 0.86);
      }
      const v = st.doc.view, z = zoomPct();
      const vw = st.view.width / v.z, vh = st.view.height / v.z;
      const k = opt.fit ? 1 : Math.min(1, (vw * 0.6) / im.width, (vh * 0.6) / im.height) || 1;
      const w = (im.width * k), h = (im.height * k);
      const cx = at ? at.x : -v.x / v.z + vw / 2, cy = at ? at.y : -v.y / v.z + vh / 2;
      commit([{ op: 'add', items: [{ id: uid(), type: 'image', layer: activeLayer().id, x: cx - w / 2, y: cy - h / 2, w, h, src: url, opacity: 1, rev: 1 }] }]);
      if (opt.fit) requestAnimationFrame(fitAll); // neues Screenshot-Blatt: ganzes Bild zeigen
      void z;
    };
    im.src = src;
  }
  function pickImageFile() {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/*';
    inp.onchange = () => { const f = inp.files?.[0]; if (f) readFile(f).then((u) => addImage(u)); };
    inp.click();
  }
  const readFile = (f) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(f); });

  /* ================================================================ Ansicht */
  function resize() {
    if (!st.view) return;
    const box = st.view.parentElement.getBoundingClientRect();
    st.dpr = window.devicePixelRatio || 1;
    const W = Math.max(10, Math.round(box.width * st.dpr)), H = Math.max(10, Math.round(box.height * st.dpr));
    if (st.view.width !== W || st.view.height !== H) {
      const v = st.doc.view;
      // Mitte bleibt in der Mitte (nicht beim ersten Einrichten)
      if (st.sized) { v.x += (W - st.view.width) / 2; v.y += (H - st.view.height) / 2; }
      st.view.width = W; st.view.height = H;
      st.sized = true;
    }
    st.view.style.width = `${box.width}px`;
    st.view.style.height = `${box.height}px`;
    requestDraw();
  }
  function zoomAt(z, ox, oy) {
    const v = st.doc.view;
    z = Math.max(0.02 * st.dpr, Math.min(100 * st.dpr, z));
    v.x = ox - ((ox - v.x) / v.z) * z;
    v.y = oy - ((oy - v.y) / v.z) * z;
    v.z = z;
    afterView();
  }
  function afterView() {
    paintZoom();
    placeText();
    requestDraw();
    queueSave(true);
  }
  function contentBox() {
    let b = null;
    for (const it of st.doc.items) {
      if (it.tool === 'eraser') continue;
      const q = bboxOf(it);
      b = b ? { x0: Math.min(b.x0, q.x), y0: Math.min(b.y0, q.y), x1: Math.max(b.x1, q.x + q.w), y1: Math.max(b.y1, q.y + q.h) } : { x0: q.x, y0: q.y, x1: q.x + q.w, y1: q.y + q.h };
    }
    return b;
  }
  function fitAll() {
    const b = contentBox();
    const v = st.doc.view;
    if (!b) { v.z = st.dpr; v.x = st.view.width / 2; v.y = st.view.height / 2; return afterView(); }
    const w = b.x1 - b.x0, h = b.y1 - b.y0;
    v.z = Math.max(0.02 * st.dpr, Math.min(4 * st.dpr, Math.min(st.view.width / (w * 1.15), st.view.height / (h * 1.15))));
    v.x = st.view.width / 2 - (b.x0 + w / 2) * v.z;
    v.y = st.view.height / 2 - (b.y0 + h / 2) * v.z;
    afterView();
  }

  /* ================================================================ Zeiger: Maus, Stift, Touch + Stift-Tasten */
  function fire(sig) {
    const now = performance.now();
    if (now - (st.lastFire[sig] || 0) < 350) return false;
    st.lastFire[sig] = now;
    if (st.capture) { finishCapture(sig); return true; }
    const act = st.bindings[sig];
    if (!act || act === 'none' || HOLD.has(act)) return false;
    runAction(act);
    flashSignal(sig, act);
    return true;
  }
  function runAction(act) {
    if (act === 'undo') undo(true);
    else if (act === 'redo') undo(false);
    else if (act === 'fit') fitAll();
    else if (act === 'lasttool') setTool(st.lastTool);
    else if (act === 'nextcolor') { const list = [...new Set([...st.recent, ...SWATCHES])]; const i = list.indexOf(st.color); st.color = list[(i + 1) % list.length]; paintSide(); }
    else if (act === 'bigger' || act === 'smaller') { st.size = Math.max(1, Math.min(200, Math.round(st.size * (act === 'bigger' ? 1.25 : 0.8)))); paintSide(); }
    else if (TOOLS.some(([k]) => k === act)) setTool(act);
  }
  function flashSignal(sig, act) {
    const el = st.root?.querySelector('.dz-flash');
    if (!el) return;
    el.textContent = ACTIONS.find((a) => a[0] === act)?.[1] || act;
    el.classList.remove('on'); void el.offsetWidth; el.classList.add('on');
  }
  const penSignal = (e) => (e.button === 5 || (e.buttons & 32) ? 'pen-eraser' : e.button === 2 || (e.buttons & 2) ? 'pen-barrel' : null);

  function onDown(e) {
    if (!st.view || e.target !== st.view) return;
    if (st.textEdit) closeText(true);
    if (e.pointerType === 'pen') st.lastPenAt = performance.now();
    // Maus-Seitentasten
    if (e.pointerType === 'mouse' && (e.button === 3 || e.button === 4)) { e.preventDefault(); fire(e.button === 3 ? 'mouse-back' : 'mouse-forward'); return; }
    // Stift-Seitentasten: „halten“-Aktionen wirken auf diesen Strich, alle anderen lösen sofort aus
    let tool = st.tool;
    if (e.pointerType === 'pen') {
      const sig = penSignal(e);
      if (sig) {
        const act = st.bindings[sig];
        if (st.capture) { fire(sig); return; }
        if (HOLD.has(act)) tool = act;
        else { fire(sig); return; }
      }
    } else if (e.button === 2) return;
    try { st.view.setPointerCapture(e.pointerId); } catch { /* Zeiger schon weg */ }
    st.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, type: e.pointerType });
    if (st.ptrs.size === 2) {
      // zwei Finger: Zoomen/Verschieben, angefangenen Strich verwerfen
      if (st.live) { clearInterval(st.live.timer); if (st.live.inverse?.length) apply(st.live.inverse); st.live = null; sendLive(null); }
      const [a, b] = [...st.ptrs.values()];
      st.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, v: { ...st.doc.view } };
      return;
    }
    if (st.ptrs.size > 2) return;
    if (tool === 'hand' || e.button === 1 || st.spaceDown) { st.panning = { x: e.clientX, y: e.clientY, vx: st.doc.view.x, vy: st.doc.view.y }; st.view.style.cursor = 'grabbing'; return; }
    if (tool === 'pick') {
      const r = st.view.getBoundingClientRect();
      const px = st.ctx.getImageData(Math.round((e.clientX - r.left) * st.dpr), Math.round((e.clientY - r.top) * st.dpr), 1, 1).data;
      st.color = `#${[px[0], px[1], px[2]].map((n) => n.toString(16).padStart(2, '0')).join('')}`;
      if (st.tool === 'pick') setTool(st.lastTool);
      return paintSide();
    }
    if (tool === 'fill') return fillAt(e);
    if (tool === 'text' || tool === 'note') { e.preventDefault(); return textAt(e, tool); }
    if (tool === 'laser') { st.live = { kind: 'laser' }; addLaser(e); return; }
    if (tool === 'objeraser') { st.live = { kind: 'objerase', gone: new Set(), inverse: [] }; objectErase(e); return; }
    if (tool === 'select') {
      const drag = st.sel.size ? startSelDrag(e) : null;
      if (drag) { st.live = drag; return; }
      st.live = { kind: 'lasso' };
      st.lasso = [toWorld(e)];
      return requestDraw();
    }
    if (SHAPES.has(tool)) { st.live = startShape(e, tool); return requestDraw(); }
    if (BRUSH.has(tool)) { st.live = startStroke(e, tool); requestDraw(); }
  }
  function onMove(e) {
    if (!st.view || !st.doc) return;
    const r = st.view.getBoundingClientRect();
    st.hover = e.pointerType === 'touch' ? null : { x: (e.clientX - r.left) * st.dpr, y: (e.clientY - r.top) * st.dpr };
    if (e.pointerType === 'pen') {
      st.lastPenAt = performance.now();
      // Seitentaste beim Schweben gedrückt (steigende Flanke)
      const b = e.buttons & (2 | 32), was = st.penButtons;
      st.penButtons = b;
      if (!(e.buttons & 1) && b && b !== was) { const sig = b & 32 ? 'pen-eraser' : 'pen-barrel'; if (!HOLD.has(st.bindings[sig]) || st.capture) fire(sig); }
    }
    sendCursor(e);
    if (st.ptrs.has(e.pointerId)) st.ptrs.set(e.pointerId, { ...st.ptrs.get(e.pointerId), x: e.clientX, y: e.clientY });
    if (st.pinch && st.ptrs.size === 2) {
      const [a, b] = [...st.ptrs.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y), cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
      const P = st.pinch, v = st.doc.view;
      const z = Math.max(0.02 * st.dpr, Math.min(100 * st.dpr, P.v.z * (d / P.d)));
      const ox = (P.cx - r.left) * st.dpr, oy = (P.cy - r.top) * st.dpr;
      v.z = z;
      v.x = ox - ((ox - P.v.x) / P.v.z) * z + (cx - P.cx) * st.dpr;
      v.y = oy - ((oy - P.v.y) / P.v.z) * z + (cy - P.cy) * st.dpr;
      return afterView();
    }
    if (st.panning) {
      st.doc.view.x = st.panning.vx + (e.clientX - st.panning.x) * st.dpr;
      st.doc.view.y = st.panning.vy + (e.clientY - st.panning.y) * st.dpr;
      return afterView();
    }
    const s = st.live;
    if (!s || !st.ptrs.has(e.pointerId)) { if (BRUSH.has(st.tool)) requestDraw(); return; }
    if (s.kind === 'stroke') moveStroke(s, e);
    else if (s.kind === 'shape' && !s.recognized) moveShape(s, e);
    else if (s.kind === 'laser') addLaser(e);
    else if (s.kind === 'objerase') objectErase(e);
    else if (s.kind === 'lasso') { st.lasso.push(toWorld(e)); requestDraw(); }
    else if (s.kind === 'seldrag') moveSelDrag(s, e);
  }
  function onUp(e) {
    st.ptrs.delete(e.pointerId);
    if (st.ptrs.size < 2) st.pinch = null;
    if (st.panning) { st.panning = null; st.view.style.cursor = cursorFor(st.tool); }
    const s = st.live;
    if (!s || st.ptrs.size) return;
    if (s.kind === 'stroke' || s.kind === 'shape') endLive();
    else {
      st.live = null;
      if (s.kind === 'objerase' && s.inverse.length) { st.undo.push({ undo: s.inverse.slice().reverse(), redo: [{ op: 'del', ids: [...s.gone] }] }); st.redo = []; }
      else if (s.kind === 'lasso') finishLasso();
      else if (s.kind === 'seldrag') endSelDrag(s);
      requestDraw();
    }
  }
  function onWheel(e) {
    if (!st.view || e.target !== st.view) return;
    e.preventDefault();
    const r = st.view.getBoundingClientRect();
    const v = st.doc.view;
    if (e.ctrlKey || e.metaKey || !e.shiftKey) zoomAt(v.z * Math.exp(-e.deltaY * (e.ctrlKey ? 0.01 : 0.0015)), (e.clientX - r.left) * st.dpr, (e.clientY - r.top) * st.dpr);
    else { v.x -= (e.deltaY || e.deltaX) * st.dpr; afterView(); }
  }
  function addLaser(e) {
    const p = toWorld(e);
    st.laser.push({ ...p, t: performance.now() });
    if (st.laser.length > 120) st.laser.splice(0, st.laser.length - 120);
    netSend('laser', { x: f1(p.x), y: f1(p.y) }, 40);
    requestDraw();
  }
  const cursorFor = (t) => (t === 'hand' ? 'grab' : t === 'pick' || t === 'fill' ? 'copy' : t === 'text' || t === 'note' ? 'text' : t === 'select' ? 'default' : 'crosshair');
  function setTool(t) {
    if (t !== st.tool && t !== 'pick') st.lastTool = st.tool;
    st.tool = t;
    if (t !== 'select') { st.sel.clear(); paintSelBar(); }
    if (st.view) st.view.style.cursor = cursorFor(t);
    paintTools();
    paintSide();
    requestDraw();
    savePrefs();
  }

  /* ================================================================ Stift-Tasten zuweisen */
  function startCapture() {
    st.capture = true;
    paintPanel();
  }
  function finishCapture(sig) {
    st.capture = false;
    if (!st.bindings[sig]) st.bindings[sig] = 'undo';
    savePrefs();
    A.toast(`Erkannt: ${sigName(sig)}`);
    paintPanel();
  }
  const sigName = (sig) => SIGNALS[sig] || (sig.startsWith('key:') ? `Taste ${sig.slice(4)}` : sig);
  function comboOf(e) {
    const k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
    if (['Control', 'Shift', 'Alt', 'Meta'].includes(k)) return '';
    return [e.ctrlKey && 'Strg', e.altKey && 'Alt', e.shiftKey && 'Umschalt', e.metaKey && 'Win', k].filter(Boolean).join('+');
  }

  /* ================================================================ Zusammen zeichnen */
  const peerColor = (id) => `hsl(${[...String(id)].reduce((s, c) => s + c.charCodeAt(0) * 37, 0) % 360} 85% 55%)`;
  const throttle = {};
  function netSend(t, data, every = 0) {
    if (!st.net?.room) return;
    if (every) { const now = performance.now(); if (now - (throttle[t] || 0) < every) return; throttle[t] = now; }
    const text = JSON.stringify(data);
    if (text.length < 45000) return st.net.room.send(t, data);
    // grosse Nachrichten in Stücke teilen
    const bid = uid(), n = Math.ceil(text.length / 40000);
    for (let i = 0; i < n; i++) st.net.room.send('part', { bid, pt: t, i, n, s: text.slice(i * 40000, (i + 1) * 40000) });
  }
  function sendOps(ops) { if (st.net?.room && st.net.ready) netSend('ops', { doc: st.doc.id, ops }); }
  function sendLive(item) {
    if (!st.net?.room) return;
    if (!item) return netSend('live', { end: true });
    const now = performance.now();
    if (now - (throttle.live || 0) < 60) { clearTimeout(st._liveT); st._liveT = setTimeout(() => sendLive(st.live?.item || null), 70); return; }
    throttle.live = now;
    netSend('live', { item: cleanItem(item) });
  }
  function sendCursor(e) {
    if (!st.net?.room) return;
    const p = toWorld(e);
    netSend('cur', { x: f1(p.x), y: f1(p.y) }, 80);
  }
  async function joinRoom(code, host) {
    if (!window.RevNet?.Room) return A.toast('Online-Räume sind nicht verfügbar.', 'error');
    leaveRoom(true);
    const me = await A.me();
    st.me.name = (me?.name || 'Ich').slice(0, 20);
    const room = new window.RevNet.Room({ app: 'draw', code, name: st.me.name });
    st.net = { room, code, host, ready: host, readyPeers: new Set(), parts: new Map(), status: 'Verbinde …' };
    paintPanel();
    room.on('peer', (p) => {
      st.peers.set(p.id, { name: p.name || 'Gast', color: peerColor(p.id), laser: [] });
      paintPeers();
      // wer am längsten dabei ist (kleinste ID unter den Bereiten), schickt das Blatt
      if (st.net.ready) {
        const ready = [room.id, ...st.net.readyPeers].filter((id) => id !== p.id).sort();
        if (ready[0] === room.id) sendSync(p.id);
      }
    });
    room.on('left', (id) => { st.peers.delete(id); st.ghosts.delete(id); paintPeers(); requestDraw(); });
    room.on('msg', (m) => onNet(m));
    room.on('disconnect', () => { if (st.net?.room === room) { st.net.status = 'Verbindung verloren'; paintPanel(); } });
    try {
      await room.join();
      st.net.status = 'Verbunden';
      if (host) room.send('ready');
      else setTimeout(() => { if (st.net?.room === room && !st.net.ready) { st.net.ready = true; room.send('ready'); paintPanel(); } }, 5000);
    } catch (err) {
      st.net = null;
      A.toast(`Raum nicht erreichbar: ${A.errText(err)}`, 'error');
    }
    paintPanel();
    paintPeers();
  }
  function sendSync(to) {
    netSend('sync', { to, doc: { ...clone({ ...st.doc, items: st.doc.items.map(cleanItem) }), view: undefined } });
  }
  function leaveRoom(silent) {
    if (!st.net) return;
    try { st.net.room.leave(); } catch { /* egal */ }
    st.net = null;
    st.peers.clear();
    st.ghosts.clear();
    if (!silent) { paintPanel(); paintPeers(); requestDraw(); }
  }
  function onNet(m) {
    if (m.t === 'part') {
      const P = st.net.parts;
      let e = P.get(m.bid);
      if (!e) { e = { n: m.n, got: new Array(m.n), c: 0, t: m.pt, from: m.from, name: m.name }; P.set(m.bid, e); }
      if (!e.got[m.i]) { e.got[m.i] = m.s; e.c++; }
      if (e.c === e.n) { P.delete(m.bid); try { onNet({ ...JSON.parse(e.got.join('')), t: e.t, from: e.from, name: e.name }); } catch { /* defekt */ } }
      return;
    }
    const peer = st.peers.get(m.from) || { name: m.name || 'Gast', color: peerColor(m.from), laser: [] };
    if (!st.peers.has(m.from)) { st.peers.set(m.from, peer); paintPeers(); }
    if (m.t === 'ready') { st.net.readyPeers.add(m.from); return; }
    if (m.t === 'sync') {
      if (m.to !== st.net.room.id || st.net.ready) return;
      const d = m.doc;
      if (!d?.layers?.length) return;
      // Blatt des Raums übernehmen (eigenes Blatt bleibt in der Liste erhalten)
      saveNow();
      const nd = { ...d, view: st.doc.view, id: `room-${st.net.code}`, name: `Gemeinsam ${st.net.code}` };
      st.doc = nd;
      indexDoc();
      upsertBoard(nd);
      st.undo = []; st.redo = [];
      st.net.ready = true;
      st.net.room.send('ready');
      fitAll();
      paintAll();
      A.toast(`Blatt von ${m.name || 'Gast'} übernommen`);
      return;
    }
    if (m.t === 'ops') { if (st.net.ready && Array.isArray(m.ops)) apply(m.ops, { remote: true }); return; }
    if (m.t === 'live') {
      if (m.end) st.ghosts.delete(m.from); else if (m.item) st.ghosts.set(m.from, hide({ ...m.item }));
      requestDraw();
      return;
    }
    if (m.t === 'cur') { peer.cur = { x: m.x, y: m.y, t: performance.now() }; requestDraw(); return; }
    if (m.t === 'laser') { peer.laser = [...(peer.laser || []).filter((p) => performance.now() - p.t < 1400), { x: m.x, y: m.y, t: performance.now() }]; peer.cur = { x: m.x, y: m.y, t: performance.now() }; requestDraw(); }
  }

  /* ================================================================ Speichern, Blätter */
  function queueSave(viewOnly) {
    if (!viewOnly) st.dirty = true;
    clearTimeout(st.saveTimer);
    st.saveTimer = setTimeout(saveNow, viewOnly ? 2500 : 1200);
  }
  async function saveNow() {
    clearTimeout(st.saveTimer);
    if (!st.doc) return;
    const doc = { ...st.doc, items: st.doc.items.map(cleanItem), layers: st.doc.layers.map(({ ver, ...l }) => l) };
    await A.store.set(`draw-board-${st.doc.id}`, doc);
    if (st.dirty) { st.dirty = false; upsertBoard(st.doc); }
  }
  function upsertBoard(d) {
    const b = st.idx.boards.find((x) => x.id === d.id);
    if (b) { b.name = d.name; b.at = Date.now(); } else st.idx.boards.unshift({ id: d.id, name: d.name, at: Date.now() });
    st.idx.active = d.id;
    saveIdx();
  }
  const saveIdx = () => A.store.set('draw-v2', st.idx);
  function savePrefs() {
    if (!st.idx) return;
    st.idx.prefs = { tool: st.tool, color: st.color, size: st.size, opacity: st.opacity, smooth: st.smooth, shapeFill: st.shapeFill, scaleWithZoom: st.scaleWithZoom, assist: st.assist, recent: st.recent };
    st.idx.bindings = st.bindings;
    clearTimeout(st._prefT);
    st._prefT = setTimeout(saveIdx, 600);
  }
  function pushRecent(c) {
    st.recent = [c, ...st.recent.filter((x) => x !== c)].slice(0, 8);
    savePrefs();
    paintSide();
  }
  async function loadBoard(id) {
    const d = await A.store.get(`draw-board-${id}`, null);
    st.doc = d?.layers?.length ? d : blankDoc('Blatt');
    if (!st.doc.view) st.doc.view = { x: 0, y: 0, z: 1 };
    indexDoc();
    st.undo = []; st.redo = []; st.sel.clear();
    st.layerCache.clear(); st.pathCache.clear();
  }
  async function loadAll() {
    if (st.idx) return;
    let idx = await A.store.get('draw-v2', null);
    if (!idx?.boards?.length) {
      idx = { boards: [], active: null, prefs: {}, bindings: { ...DEFAULT_BINDINGS } };
      const d = blankDoc('Mein Blatt');
      // alte Zeichnung (2.45, Pixel-Ebenen) als Bilder übernehmen
      const old = await A.store.get('draw-last', null);
      if (old?.layers?.length) {
        d.name = 'Alte Zeichnung';
        d.bg = old.bg || '#ffffff';
        d.paper = 'plain';
        d.layers = [];
        for (const l of old.layers.slice(0, 12)) {
          const nl = { id: uid(), name: l.name || 'Ebene', visible: l.visible !== false, opacity: Number(l.opacity) || 1 };
          d.layers.push(nl);
          if (l.png) d.items.push({ id: uid(), type: 'image', layer: nl.id, x: 0, y: 0, w: 1920, h: 1200, src: l.png, opacity: 1, rev: 1 });
        }
        d.active = d.layers[d.layers.length - 1].id;
        d.view = { x: 0, y: 0, z: 1 };
        d.needsFit = true;
      }
      await A.store.set(`draw-board-${d.id}`, d);
      idx.boards = [{ id: d.id, name: d.name, at: Date.now() }];
      idx.active = d.id;
      await A.store.set('draw-v2', idx);
    }
    st.idx = idx;
    Object.assign(st, idx.prefs || {});
    st.bindings = { ...DEFAULT_BINDINGS, ...(idx.bindings || {}) };
    if (!TOOLS.some(([k]) => k === st.tool)) st.tool = 'pen';
    await loadBoard(idx.active || idx.boards[0].id);
  }
  async function switchBoard(id) {
    closeText(true);
    await saveNow();
    if (st.net && !String(id).startsWith('room-')) leaveRoom();
    st.idx.active = id;
    // 2.45.9 Tabs: geöffnete Blätter bleiben als Reiter oben
    st.idx.tabs = [...new Set([...(st.idx.tabs || []), id])].filter((t) => st.idx.boards.some((b) => b.id === t)).slice(-12);
    saveIdx();
    await loadBoard(id);
    paintAll();
    if (!st.doc.view.z || st.doc.needsFit) { delete st.doc.needsFit; requestAnimationFrame(fitAll); } else requestDraw();
  }
  async function newBoard() {
    await saveNow();
    const d = blankDoc(`Blatt ${st.idx.boards.length + 1}`);
    d.view = { x: st.view.width / 2, y: st.view.height / 2, z: st.dpr };
    await A.store.set(`draw-board-${d.id}`, d);
    st.idx.boards.unshift({ id: d.id, name: d.name, at: Date.now() });
    await switchBoard(d.id);
  }
  /** Reiter schliessen (das Blatt bleibt gespeichert und lässt sich über „Alle Blätter“ wieder öffnen). */
  async function closeTab(id) {
    const tabs = (st.idx.tabs || []).filter((t) => t !== id);
    if (!tabs.length) return A.toast('Mindestens ein Blatt bleibt offen.', 'error');
    st.idx.tabs = tabs;
    if (st.doc.id === id) await switchBoard(tabs[tabs.length - 1]);
    else { saveIdx(); paintBoards(); }
  }
  /* 2.45.9 Letzte Screenshots: als neues Blatt öffnen (darauf zeichnen, exportieren) oder ins aktuelle einfügen */
  async function openShot(file, here) {
    try {
      const url = await window.hub.draw.readShot(file);
      if (!here) {
        await saveNow();
        const name = `Screenshot ${new Date().toLocaleString('de-CH', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}`;
        const d = blankDoc(name);
        d.paper = 'plain';
        d.view = { x: st.view.width / 2, y: st.view.height / 2, z: st.dpr };
        await A.store.set(`draw-board-${d.id}`, d);
        st.idx.boards.unshift({ id: d.id, name: d.name, at: Date.now() });
        await switchBoard(d.id);
      }
      st.panel = '';
      paintPanel();
      addImage(url, null, { max: 3840, fit: !here });
      if (!BRUSH.has(st.tool)) setTool('pen');
    } catch (err) { A.toast(A.errText(err), 'error'); }
  }
  async function deleteBoard() {
    if (st.idx.boards.length < 2) return A.toast('Das letzte Blatt kann nicht gelöscht werden – leere es stattdessen.', 'error');
    if (!window.confirm(`„${st.doc.name}“ wirklich löschen? Das kann nicht rückgängig gemacht werden.`)) return;
    const id = st.doc.id;
    st.idx.boards = st.idx.boards.filter((b) => b.id !== id);
    st.idx.tabs = (st.idx.tabs || []).filter((t) => t !== id);
    await A.store.set(`draw-board-${id}`, null);
    st.doc = null;
    await switchBoard(st.idx.boards[0].id);
  }

  /* ================================================================ Export */
  function exportPng(all) {
    const v = st.doc.view;
    let W = st.view.width, H = st.view.height, view = { ...v };
    if (all) {
      const b = contentBox();
      if (!b) return A.toast('Das Blatt ist leer.', 'error');
      const pad = 40, w = b.x1 - b.x0 + pad * 2, h = b.y1 - b.y0 + pad * 2;
      const k = Math.min(4, 8000 / Math.max(w, h), Math.sqrt(4e7 / (w * h)));
      W = Math.round(w * k); H = Math.round(h * k);
      view = { x: (-b.x0 + pad) * k, y: (-b.y0 + pad) * k, z: k };
    }
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    renderTo(c.getContext('2d'), W, H, view, { paper: true });
    st.layerCache.clear();
    requestDraw();
    download(c.toDataURL('image/png'), 'png');
  }
  function exportSvg() {
    const b = contentBox();
    if (!b) return A.toast('Das Blatt ist leer.', 'error');
    const pad = 40, x = b.x0 - pad, y = b.y0 - pad, w = b.x1 - b.x0 + pad * 2, h = b.y1 - b.y0 + pad * 2;
    const escA = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
    let out = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${f1(x)} ${f1(y)} ${f1(w)} ${f1(h)}" width="${Math.round(w)}" height="${Math.round(h)}"><rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="${st.doc.bg}"/>`;
    const by = itemsByLayer();
    for (const l of st.doc.layers) {
      if (!l.visible) continue;
      const items = by.get(l.id) || [];
      const erasers = items.filter((it) => it.tool === 'eraser');
      if (erasers.length) out += `<mask id="m${l.id}" maskUnits="userSpaceOnUse" x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}"><rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="#fff"/>${erasers.map((it) => `<path d="${pathOf(it).d}" fill="#000"/>`).join('')}</mask>`;
      out += `<g opacity="${l.opacity ?? 1}"${erasers.length ? ` mask="url(#m${l.id})"` : ''}>`;
      for (const it of items) {
        if (it.tool === 'eraser') continue;
        const op = it.opacity ?? 1;
        if (it.type === 'stroke') {
          const d = pathOf(it).d;
          if (it.tool === 'marker' || it.tool === 'highlighter') {
            const sw = it.tool === 'highlighter' ? (it.pts[2] || it.size) * 2.2 : it.pts[2] || it.size;
            out += `<path d="${d}" fill="none" stroke="${it.color}" stroke-width="${f1(sw)}" stroke-linecap="${it.tool === 'highlighter' ? 'square' : 'round'}" stroke-linejoin="round" opacity="${it.tool === 'highlighter' ? 0.38 * op : op}"${it.tool === 'highlighter' ? ' style="mix-blend-mode:multiply"' : ''}/>`;
          } else out += `<path d="${d}" fill="${it.color}" opacity="${f1(op * (it.tool === 'pencil' ? 0.85 : it.tool === 'air' ? 0.55 : 1) * 100) / 100}"/>`;
        } else if (it.type === 'shape') out += `<path d="${pathOf(it).d}" fill="${it.fill && (it.kind === 'rect' || it.kind === 'ellipse') ? (it.fill === 2 ? it.color : hexA(it.color, 0.28)) : 'none'}" stroke="${it.color}" stroke-width="${f1(it.size)}" stroke-linecap="round" stroke-linejoin="round" opacity="${op}"/>`;
        else if (it.type === 'fill') out += `<path d="${pathOf(it).d}" fill="${it.color}" fill-rule="evenodd" opacity="${op}"/>`;
        else if (it.type === 'text') out += `<text x="${f1(it.x + 2)}" y="${f1(it.y + 2)}" font-family="Segoe UI, sans-serif" font-weight="600" font-size="${f1(it.size)}" fill="${it.color}" opacity="${op}" dominant-baseline="hanging">${String(it.text || '').split('\n').map((t, i) => `<tspan x="${f1(it.x + 2)}" dy="${i ? f1(it.size * 1.25) : 0}">${escA(t)}</tspan>`).join('')}</text>`;
        else if (it.type === 'note') out += `<rect x="${f1(it.x)}" y="${f1(it.y)}" width="${f1(it.w)}" height="${f1(it.h)}" rx="${f1(Math.min(10, it.w / 10))}" fill="${it.color || '#ffe066'}"/><text x="${f1(it.x + (it.font || 18) * 0.6)}" y="${f1(it.y + (it.font || 18) * 0.6)}" font-family="Segoe UI, sans-serif" font-weight="600" font-size="${f1(it.font || 18)}" dominant-baseline="hanging">${escA(it.text || '')}</text>`;
        else if (it.type === 'image') out += `<image href="${it.src}" x="${f1(it.x)}" y="${f1(it.y)}" width="${f1(it.w)}" height="${f1(it.h)}" opacity="${op}"/>`;
      }
      out += '</g>';
    }
    out += '</svg>';
    download(`data:image/svg+xml;charset=utf-8,${encodeURIComponent(out)}`, 'svg');
  }
  function download(url, ext) {
    const a = document.createElement('a');
    a.href = url;
    a.download = `${st.doc.name || 'Zeichnung'} ${new Date().toLocaleString('de-CH').replace(/[/:,]/g, '-')}.${ext}`;
    a.click();
  }

  /* ================================================================ Oberfläche */
  function paintTools() {
    const t = st.root?.querySelector('.dz-tools');
    if (!t) return;
    t.innerHTML = TOOLS.map(([k, n, key], i) => `${[6, 10, 16].includes(i) ? '<i class="dz-sep"></i>' : ''}<button class="dz-tool ${st.tool === k ? 'on' : ''}" data-dz-tool="${k}" title="${esc(n)} (${key})">${svg(k, 21)}</button>`).join('');
  }
  function paintZoom() {
    const z = st.root?.querySelector('[data-dz-zoom]');
    if (z) { const p = zoomPct() * 100; z.textContent = `${p >= 100 ? Math.round(p) : p.toFixed(p < 10 ? 1 : 0)} %`; }
  }
  function paintPeers() {
    const el = st.root?.querySelector('.dz-peers');
    if (!el) return;
    el.innerHTML = st.net ? `<span class="dz-room" title="Raum-Code – zum Kopieren klicken" data-dz="copycode">${svg('users', 15)} ${esc(st.net.code)}</span>${[...st.peers.values()].map((p) => `<span class="dz-peer" style="--c:${p.color}">${esc(p.name)}</span>`).join('')}` : '';
  }
  function paintSelBar() {
    const el = st.root?.querySelector('.dz-selbar');
    if (!el) return;
    const n = st.sel.size;
    el.hidden = !n;
    if (n) el.innerHTML = `<b>${n} ausgewählt</b><button class="rv-btn sm" data-dz-sel="recolor" title="In aktueller Farbe">Umfärben</button><button class="rv-btn sm" data-dz-sel="dup">Duplizieren</button><button class="rv-btn sm" data-dz-sel="copy">Kopieren</button><button class="rv-btn sm" data-dz-sel="front" title="Nach vorne">${svg('up', 15)}</button><button class="rv-btn sm" data-dz-sel="back" title="Nach hinten">${svg('down', 15)}</button><button class="rv-btn sm danger" data-dz-sel="delete">${svg('trash', 15)}</button>`;
  }
  function paintSide() {
    const el = st.root?.querySelector('.dz-side');
    if (!el || !st.doc) return;
    const shape = SHAPES.has(st.tool);
    el.innerHTML = `
      <div class="dz-sec"><b>Farbe</b><div class="dz-colors">${SWATCHES.map((c) => `<button class="dz-sw ${st.color === c ? 'on' : ''}" style="--c:${c}" data-dz-color="${c}" title="${c}"></button>`).join('')}<label class="dz-sw dz-custom" style="--c:${st.color}" title="Eigene Farbe"><input type="color" value="${st.color}" data-dz-colorinput/></label></div>
        ${st.recent.length ? `<small class="rv-muted">Zuletzt</small><div class="dz-colors recent">${st.recent.map((c) => `<button class="dz-sw ${st.color === c ? 'on' : ''}" style="--c:${c}" data-dz-color="${c}"></button>`).join('')}</div>` : ''}</div>
      <div class="dz-sec">
        <label>Grösse <output>${st.size}</output><input type="range" min="1" max="200" value="${st.size}" data-dz-range="size"/></label>
        <label>Deckkraft <output>${Math.round(st.opacity * 100)} %</output><input type="range" min="0.05" max="1" step="0.05" value="${st.opacity}" data-dz-range="opacity"/></label>
        <label>Glätten <output>${Math.round(st.smooth * 100)} %</output><input type="range" min="0" max="0.95" step="0.05" value="${st.smooth}" data-dz-range="smooth"/></label>
        ${shape ? `<label>Füllung <select class="rv-input sm" data-dz-fill>${[[0, 'Keine'], [1, 'Leicht'], [2, 'Voll']].map(([v, n]) => `<option value="${v}" ${st.shapeFill === v ? 'selected' : ''}>${n}</option>`).join('')}</select></label>` : ''}
        <label class="dz-check"><input type="checkbox" data-dz-check="scaleWithZoom" ${st.scaleWithZoom ? 'checked' : ''}/> Pinsel passt sich dem Zoom an</label>
        <label class="dz-check"><input type="checkbox" data-dz-check="assist" ${st.assist ? 'checked' : ''}/> Form-Assistent (am Ende still halten)</label>
      </div>
      <div class="dz-sec"><b>Papier</b><div class="dz-papers">${PAPERS.map(([k, n]) => `<button class="rv-btn sm ${st.doc.paper === k ? 'on' : ''}" data-dz-paper="${k}">${n}</button>`).join('')}<label class="dz-sw dz-custom" style="--c:${st.doc.bg}" title="Papierfarbe"><input type="color" value="${st.doc.bg}" data-dz-bg/></label></div></div>
      <div class="dz-sec dz-layers"><div class="rv-row between"><b>Ebenen</b><span class="rv-row"><button class="rv-btn sm" data-dz="layer-add" title="Neue Ebene">${svg('plus', 14)}</button><button class="rv-btn sm" data-dz="layer-del" title="Ebene löschen" ${st.doc.layers.length < 2 ? 'disabled' : ''}>${svg('minus', 14)}</button></span></div>
        ${[...st.doc.layers].reverse().map((l) => `<div class="dz-layer ${l.id === st.doc.active ? 'on' : ''}" data-dz-layer="${l.id}"><button class="dz-eye" data-dz-eye="${l.id}" title="Ein-/ausblenden">${svg(l.visible ? 'eye' : 'eyeoff', 15)}</button><span data-dz-lname="${l.id}" title="Doppelklick: umbenennen">${esc(l.name)}</span><input type="range" min="0" max="1" step="0.05" value="${l.opacity ?? 1}" data-dz-lop="${l.id}" title="Deckkraft"/></div>`).join('')}</div>`;
  }
  function paintPanel() {
    const el = st.root?.querySelector('.dz-panel');
    if (!el) return;
    el.hidden = !st.panel;
    if (st.panel === 'share') {
      const n = st.net;
      el.innerHTML = `<div class="rv-row between"><b>Zusammen zeichnen</b><button class="rv-btn sm ghost" data-dz="panel-close">✕</button></div>
        ${n ? `<p>Raum-Code: <b class="dz-code">${esc(n.code)}</b> <button class="rv-btn sm" data-dz="copycode">Kopieren</button></p><p class="rv-muted">${esc(n.status)} · ${st.peers.size} ${st.peers.size === 1 ? 'Person' : 'Personen'} dabei</p><button class="rv-btn sm danger" data-dz="leave">Raum verlassen</button>`
        : `<p class="rv-muted">Alle sehen dasselbe Blatt live – Striche, Zeiger und Laserpointer. Gib den Code an Freunde weiter; sie öffnen Zeichnen → Zusammen zeichnen → Beitreten.</p>
          <button class="rv-btn primary" data-dz="host">Dieses Blatt teilen (Raum erstellen)</button>
          <div class="rv-row" style="margin-top:10px"><input class="rv-input sm" data-dz-joincode placeholder="Code vom Freund" maxlength="8" style="text-transform:uppercase;width:150px"/><button class="rv-btn sm" data-dz="join">Beitreten</button></div>
          <p class="rv-muted dz-small">Läuft wie Chats und Online-Spiele über öffentliche Server – teile den Code nur mit Leuten, die mitzeichnen sollen.</p>`}`;
    } else if (st.panel === 'pen') {
      const sigs = [...new Set([...Object.keys(SIGNALS), ...Object.keys(st.bindings)])];
      el.innerHTML = `<div class="rv-row between"><b>Stift- und Maustasten</b><button class="rv-btn sm ghost" data-dz="panel-close">✕</button></div>
        <p class="rv-muted dz-small">Für Stifte wie den ASUS Pen 2.0 (zwei Seitentasten) und Mäuse mit Seitentasten. „Halten“ wirkt, solange die Taste beim Zeichnen gedrückt ist.</p>
        ${sigs.map((s) => `<div class="dz-bind"><span>${esc(sigName(s))}</span><select class="rv-input sm" data-dz-bind="${esc(s)}">${ACTIONS.map(([k, n]) => `<option value="${k}" ${st.bindings[s] === k ? 'selected' : ''}>${n}</option>`).join('')}</select>${SIGNALS[s] ? '' : `<button class="rv-btn sm ghost" data-dz-unbind="${esc(s)}" title="Entfernen">✕</button>`}</div>`).join('')}
        <div class="rv-row" style="margin-top:10px;gap:8px"><button class="rv-btn sm ${st.capture ? 'on' : ''}" data-dz="capture">${st.capture ? 'Jetzt Stift-/Maus- oder Tastaturtaste drücken …' : 'Andere Taste hinzufügen …'}</button><button class="rv-btn sm ghost" data-dz="bind-reset">Standard</button></div>`;
    } else if (st.panel === 'shots') {
      // 2.45.9 Letzte Screenshots (Hub-Screenshots und Windows „Bilder\Screenshots“)
      const list = st.shots;
      if (!list) window.hub.draw?.recentShots(4).then((l) => { st.shots = l || []; paintPanel(); }).catch(() => { st.shots = []; paintPanel(); });
      el.innerHTML = `<div class="rv-row between"><b>Letzte Screenshots</b><button class="rv-btn sm ghost" data-dz="panel-close">✕</button></div>
        <p class="rv-muted dz-small">Klick öffnet den Screenshot als neues Blatt – darauf zeichnen und über „Exportieren“ speichern.</p>
        ${!list ? '<p class="rv-muted">Lädt …</p>' : list.length ? `<div class="dz-shots">${list.map((s, i) => `<div class="dz-shot"><button class="dz-shotimg" data-dz-shot="${i}" title="${esc(s.name)}"><img src="${s.thumb}" alt=""/></button><small>${esc(new Date(s.at).toLocaleString('de-CH', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }))}</small><button class="rv-btn sm ghost" data-dz-shothere="${i}" title="In das aktuelle Blatt einfügen">Ins Blatt</button></div>`).join('')}</div>` : '<p class="rv-muted">Noch keine Screenshots gefunden.</p>'}`;
    } else if (st.panel === 'export') {
      el.innerHTML = `<div class="rv-row between"><b>Exportieren</b><button class="rv-btn sm ghost" data-dz="panel-close">✕</button></div>
        <button class="rv-btn" data-dz="png-all">Ganzes Blatt als PNG (scharf)</button><button class="rv-btn" data-dz="png-view">Aktuelle Ansicht als PNG</button><button class="rv-btn" data-dz="svg">Als SVG (Vektor, unendlich scharf)</button>`;
    } else el.innerHTML = '';
  }
  function paintBoards() {
    const el = st.root?.querySelector('[data-dz-board]');
    if (!el) return;
    // „Alle Blätter“: öffnet ein Blatt als (neuen) Reiter
    el.innerHTML = `<option value="">Alle Blätter (${st.idx.boards.length}) …</option>${st.idx.boards.map((b) => `<option value="${esc(b.id)}">${esc(b.name)}</option>`).join('')}`;
    el.value = '';
    // 2.45.9 Reiter wie im Browser: mehrere Blätter offen, Klick wechselt, × schliesst
    const tabs = st.root.querySelector('.dz-tabs');
    if (!tabs) return;
    if (!st.idx.tabs?.length) st.idx.tabs = [st.doc.id];
    if (!st.idx.tabs.includes(st.doc.id)) st.idx.tabs.push(st.doc.id);
    const name = (id) => (id === st.doc.id ? st.doc.name : st.idx.boards.find((b) => b.id === id)?.name) || 'Blatt';
    tabs.innerHTML = `${st.idx.tabs.map((id) => `<div class="dz-tab ${id === st.doc.id ? 'on' : ''}" data-dz-tab="${esc(id)}" title="${esc(name(id))}"><span>${esc(name(id))}</span>${st.idx.tabs.length > 1 ? `<button class="dz-tabx" data-dz-tabclose="${esc(id)}" title="Reiter schliessen (Blatt bleibt gespeichert)">×</button>` : ''}</div>`).join('')}<button class="dz-tabnew" data-dz="board-new" title="Neues Blatt in neuem Reiter">${svg('plus', 14)}</button>`;
  }
  function paintAll() {
    paintTools(); paintSide(); paintBoards(); paintZoom(); paintSelBar(); paintPanel(); paintPeers();
  }
  function mountUi() {
    st.root.innerHTML = `<div class="dz">
      <div class="dz-tabbar"><div class="dz-tabs"></div><button class="rv-btn sm dz-shotsbtn" data-dz="panel-shots" title="Letzte Screenshots – öffnen, darauf zeichnen, exportieren">${svg('image', 15)} Screenshots</button></div>
      <div class="dz-top rv-card">
        <div class="rv-row"><select class="rv-input sm dz-boards" data-dz-board title="Blatt öffnen"></select><button class="rv-btn sm" data-dz="board-rename" title="Umbenennen">Umbenennen</button><button class="rv-btn sm ghost" data-dz="board-del" title="Blatt löschen">${svg('trash', 15)}</button></div>
        <div class="rv-row"><button class="rv-btn sm" data-dz="undo" title="Rückgängig (Strg+Z)">${svg('undo', 16)}</button><button class="rv-btn sm" data-dz="redo" title="Wiederholen (Strg+Y)">${svg('redo', 16)}</button>
          <button class="rv-btn sm" data-dz="zoom-out" title="Verkleinern">${svg('minus', 15)}</button><span class="rv-pill dz-zoom" data-dz-zoom data-dz="zoom-100" title="Auf 100 %">100 %</span><button class="rv-btn sm" data-dz="zoom-in" title="Vergrössern">${svg('plus', 15)}</button><button class="rv-btn sm" data-dz="fit" title="Alles zeigen (Strg+0)">${svg('fit', 16)}</button></div>
        <div class="rv-row"><button class="rv-btn sm" data-dz="image" title="Bild einfügen">${svg('image', 16)}</button><button class="rv-btn sm" data-dz="panel-pen" title="Stift-Tasten">${svg('penbtn', 16)}</button><button class="rv-btn sm" data-dz="panel-export" title="Exportieren">${svg('download', 16)}</button><button class="rv-btn sm primary" data-dz="panel-share">${svg('users', 16)} Zusammen</button><button class="rv-btn sm" data-dz="clear-layer" title="Ebene leeren">Ebene leeren</button></div>
      </div>
      <div class="dz-body">
        <aside class="dz-tools rv-card"></aside>
        <div class="dz-stage"><canvas class="dz-canvas"></canvas><div class="dz-peers"></div><div class="dz-selbar rv-card" hidden></div><div class="dz-panel rv-card" hidden></div><div class="dz-flash"></div></div>
        <aside class="dz-side rv-card"></aside>
      </div>
    </div>`;
    st.view = st.root.querySelector('.dz-canvas');
    st.ctx = st.view.getContext('2d');
    st.sized = false;
    st.view.addEventListener('pointerdown', onDown);
    st.view.addEventListener('pointermove', onMove);
    st.view.addEventListener('pointerup', onUp);
    st.view.addEventListener('pointercancel', onUp);
    st.view.addEventListener('pointerleave', () => { st.hover = null; requestDraw(); });
    st.view.addEventListener('wheel', onWheel, { passive: false });
    st.view.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      // Stift-Seitentaste als Rechtsklick (manche Stifte melden sie nur so)
      const lastSig = Math.max(0, ...Object.values(st.lastFire));
      if (performance.now() - st.lastPenAt < 1500 && performance.now() - lastSig > 1200) fire('pen-barrel');
    });
    st.view.addEventListener('auxclick', (e) => { if (e.button === 3 || e.button === 4) e.preventDefault(); });
    const stage = st.root.querySelector('.dz-stage');
    stage.addEventListener('dragover', (e) => { if ([...(e.dataTransfer?.items || [])].some((i) => i.type.startsWith('image/'))) e.preventDefault(); });
    stage.addEventListener('drop', (e) => {
      const f = [...(e.dataTransfer?.files || [])].find((x) => x.type.startsWith('image/'));
      if (!f) return;
      e.preventDefault();
      const p = toWorld(e);
      readFile(f).then((u) => addImage(u, p));
    });
    st.ro = new ResizeObserver(() => resize());
    st.ro.observe(stage);
    st.view.style.cursor = cursorFor(st.tool);
    paintAll();
    requestAnimationFrame(() => {
      const v = st.doc.view;
      resize();
      if (st.doc.needsFit || !v.z || (!v.x && !v.y && v.z === 1)) { delete st.doc.needsFit; if (st.doc.items.length) fitAll(); else { v.z = st.dpr; v.x = st.view.width / 2; v.y = st.view.height / 2; afterView(); } }
      paintZoom();
    });
  }

  /* ================================================================ Ereignisse der Oberfläche */
  document.addEventListener('click', (e) => {
    if (!st.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const tool = q('[data-dz-tool]')?.dataset.dzTool;
    if (tool) return setTool(tool);
    const col = q('[data-dz-color]')?.dataset.dzColor;
    if (col) { st.color = col; if (st.tool === 'eraser' || st.tool === 'objeraser' || st.tool === 'pick') setTool(st.lastTool && BRUSH.has(st.lastTool) && st.lastTool !== 'eraser' ? st.lastTool : 'pen'); if (st.sel.size) selAction('recolor'); savePrefs(); return paintSide(); }
    const paper = q('[data-dz-paper]')?.dataset.dzPaper;
    if (paper) return commit([{ op: 'meta', paper }]);
    const eye = q('[data-dz-eye]')?.dataset.dzEye;
    if (eye) { const ls = clone(st.doc.layers); const l = ls.find((x) => x.id === eye); l.visible = !l.visible; return commit([{ op: 'layers', layers: ls }]); }
    const li = q('[data-dz-layer]')?.dataset.dzLayer;
    if (li && !e.target.matches('input')) { st.doc.active = li; st.sel.clear(); paintSelBar(); return paintSide(); }
    const sa = q('[data-dz-sel]')?.dataset.dzSel;
    if (sa) return selAction(sa);
    // 2.45.9 Reiter und Screenshots
    const tclose = q('[data-dz-tabclose]')?.dataset.dzTabclose;
    if (tclose) { e.stopPropagation(); return closeTab(tclose); }
    const tab = q('[data-dz-tab]')?.dataset.dzTab;
    if (tab) return tab === st.doc.id ? null : switchBoard(tab);
    const shot = q('[data-dz-shot]')?.dataset.dzShot ?? q('[data-dz-shothere]')?.dataset.dzShothere;
    if (shot != null && st.shots?.[Number(shot)]) return openShot(st.shots[Number(shot)].path, Boolean(q('[data-dz-shothere]')));
    const ub = q('[data-dz-unbind]')?.dataset.dzUnbind;
    if (ub) { delete st.bindings[ub]; savePrefs(); return paintPanel(); }
    const a = q('[data-dz]')?.dataset.dz;
    if (!a) return;
    const v = st.doc.view;
    if (a === 'undo') undo(true);
    else if (a === 'redo') undo(false);
    else if (a === 'zoom-in' || a === 'zoom-out') zoomAt(v.z * (a === 'zoom-in' ? 1.25 : 0.8), st.view.width / 2, st.view.height / 2);
    else if (a === 'zoom-100') zoomAt(st.dpr, st.view.width / 2, st.view.height / 2);
    else if (a === 'fit') fitAll();
    else if (a === 'image') pickImageFile();
    else if (a === 'clear-layer') {
      const L = activeLayer();
      const ids = st.doc.items.filter((it) => it.layer === L.id).map((x) => x.id);
      if (ids.length) commit([{ op: 'del', ids }]);
    } else if (a === 'layer-add') {
      const ls = clone(st.doc.layers);
      const nl = { id: uid(), name: `Ebene ${ls.length + 1}`, visible: true, opacity: 1 };
      ls.splice(ls.findIndex((l) => l.id === st.doc.active) + 1, 0, nl);
      commit([{ op: 'layers', layers: ls, active: nl.id }]);
    } else if (a === 'layer-del') {
      if (st.doc.layers.length < 2) return;
      const L = activeLayer();
      const ids = st.doc.items.filter((it) => it.layer === L.id).map((x) => x.id);
      commit([...(ids.length ? [{ op: 'del', ids }] : []), { op: 'layers', layers: clone(st.doc.layers.filter((l) => l.id !== L.id)) }]);
    } else if (a.startsWith('panel-')) { st.panel = a === 'panel-close' || st.panel === a.slice(6) ? '' : a.slice(6); st.capture = false; if (st.panel === 'shots') st.shots = null; paintPanel(); }
    else if (a === 'host') joinRoom(window.RevNet?.newCode?.() || uid().slice(0, 6).toUpperCase(), true);
    else if (a === 'join') {
      const code = String(st.root.querySelector('[data-dz-joincode]')?.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (code.length < 4) return A.toast('Bitte den Code vom Freund eingeben.', 'error');
      joinRoom(code, false);
    } else if (a === 'leave') leaveRoom();
    else if (a === 'copycode' && st.net) { navigator.clipboard?.writeText(st.net.code).catch(() => {}); A.toast('Code kopiert'); }
    else if (a === 'capture') { st.capture = !st.capture; paintPanel(); }
    else if (a === 'bind-reset') { st.bindings = { ...DEFAULT_BINDINGS }; savePrefs(); paintPanel(); }
    else if (a === 'png-all') exportPng(true);
    else if (a === 'png-view') exportPng(false);
    else if (a === 'svg') exportSvg();
    else if (a === 'board-new') newBoard();
    else if (a === 'board-del') deleteBoard();
    else if (a === 'board-rename') {
      const n = window.prompt?.('Name des Blatts', st.doc.name);
      if (n && n.trim()) { st.doc.name = n.trim().slice(0, 40); st.dirty = true; saveNow().then(paintBoards); }
    }
  });
  document.addEventListener('dblclick', (e) => {
    const id = e.target.closest?.('[data-dz-lname]')?.dataset.dzLname;
    if (!id || !st.root?.contains(e.target)) return;
    const l = layerOf(id);
    const n = window.prompt?.('Name der Ebene', l.name);
    if (n && n.trim()) { const ls = clone(st.doc.layers); ls.find((x) => x.id === id).name = n.trim().slice(0, 30); commit([{ op: 'layers', layers: ls }]); }
  });
  document.addEventListener('input', (e) => {
    if (!st.root?.contains(e.target)) return;
    const r = e.target.dataset.dzRange;
    if (r) {
      st[r] = Number(e.target.value);
      const out = e.target.parentElement.querySelector('output');
      if (out) out.textContent = r === 'size' ? st.size : `${Math.round(st[r] * 100)} %`;
      savePrefs();
      return requestDraw();
    }
    if (e.target.matches('[data-dz-colorinput]')) { st.color = e.target.value; return savePrefs(); }
    if (e.target.matches('[data-dz-bg]')) { st.doc.bg = e.target.value; st.ver += 1; return requestDraw(); }
    const lop = e.target.dataset.dzLop;
    if (lop) { const l = layerOf(lop); l.opacity = Number(e.target.value); st.ver += 1; requestDraw(); }
  });
  document.addEventListener('change', (e) => {
    if (!st.root?.contains(e.target)) return;
    const t = e.target;
    if (t.matches('[data-dz-colorinput]')) { pushRecent(t.value); return; }
    if (t.matches('[data-dz-bg]')) return commit([{ op: 'meta', bg: t.value }]);
    if (t.dataset.dzLop) return commit([{ op: 'layers', layers: clone(st.doc.layers) }]);
    if (t.matches('[data-dz-board]')) return t.value ? switchBoard(t.value) : null;
    if (t.matches('[data-dz-fill]')) { st.shapeFill = Number(t.value); return savePrefs(); }
    if (t.dataset.dzCheck) { st[t.dataset.dzCheck] = t.checked; return savePrefs(); }
    if (t.dataset.dzBind) { st.bindings[t.dataset.dzBind] = t.value; return savePrefs(); }
  });
  const active = () => st.root && document.contains(st.root);
  document.addEventListener('keydown', (e) => {
    if (!active()) return;
    if (st.capture) {
      const c = comboOf(e);
      if (!c) return;
      e.preventDefault();
      if (c === 'Escape') { st.capture = false; return paintPanel(); }
      return finishCapture(`key:${c}`);
    }
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '')) return;
    const combo = comboOf(e);
    if (combo && st.bindings[`key:${combo}`]) { e.preventDefault(); return fire(`key:${combo}`); }
    const k = e.key.toLowerCase();
    const mod = e.ctrlKey || e.metaKey;
    if (mod && k === 'z') { e.preventDefault(); undo(!e.shiftKey); }
    else if (mod && k === 'y') { e.preventDefault(); undo(false); }
    else if (mod && k === '0') { e.preventDefault(); fitAll(); }
    else if (mod && (k === '+' || k === '=' || k === '-')) { e.preventDefault(); const v = st.doc.view; zoomAt(v.z * (k === '-' ? 0.8 : 1.25), st.view.width / 2, st.view.height / 2); }
    else if (mod && k === 'a') { e.preventDefault(); setTool('select'); const L = activeLayer(); st.sel = new Set(st.doc.items.filter((it) => it.layer === L.id && it.tool !== 'eraser').map((x) => x.id)); paintSelBar(); requestDraw(); }
    else if (mod && k === 'd') { e.preventDefault(); selAction('dup'); }
    else if (mod && k === 'c' && st.sel.size) { e.preventDefault(); selAction('copy'); }
    else if ((k === 'delete' || k === 'backspace') && st.sel.size) { e.preventDefault(); selAction('delete'); }
    else if (k === 'escape') { st.sel.clear(); st.panel = ''; paintPanel(); paintSelBar(); requestDraw(); }
    else if (k === ' ') { st.spaceDown = true; e.preventDefault(); }
    else if (!mod && !e.altKey) {
      if (k === '[' || k === ']') { st.size = Math.max(1, Math.min(200, st.size + (k === ']' ? 2 : -2))); savePrefs(); paintSide(); return requestDraw(); }
      const t = TOOLS.find(([, , key]) => key.toLowerCase() === k);
      if (t) setTool(t[0]);
    }
  });
  document.addEventListener('keyup', (e) => { if (e.key === ' ') st.spaceDown = false; });
  // Einfügen: Bild aus der Zwischenablage oder kopierte Elemente
  document.addEventListener('paste', (e) => {
    if (!active() || /^(INPUT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;
    const f = [...(e.clipboardData?.items || [])].find((i) => i.type.startsWith('image/'))?.getAsFile();
    if (f) { e.preventDefault(); readFile(f).then((u) => addImage(u)); return; }
    if (pasteClip()) e.preventDefault();
  });
  // Maus-Seitentasten nicht als „Zurück“ im Hub auslösen, solange Zeichnen offen ist
  window.addEventListener('mouseup', (e) => { if (active() && (e.button === 3 || e.button === 4)) e.preventDefault(); }, true);

  // Für automatische Tests: Blatt-Koordinaten → Bildschirm (CSS-Pixel relativ zur Zeichenfläche)
  window.__dz = {
    st,
    redraw: () => afterView(),
    toScreen: (x, y) => ({ x: (x * st.doc.view.z + st.doc.view.x) / st.dpr, y: (y * st.doc.view.z + st.doc.view.y) / st.dpr }),
  };

  A.define(
    ID,
    { nav: 'Zeichnen', title: 'Zeichnen', sub: 'Unendliche Blätter, gemeinsam zeichnen', icon: 'palette', tint: 'linear-gradient(135deg,#f472b6,#9333ea)', desc: 'Unendliche Blätter, scharf in jeder Zoomstufe: Druckstufen-Pinsel, Lasso, Formen mit Form-Assistent, Text, Notizzettel, Laserpointer, Ebenen, Export als PNG/SVG – und zusammen live zeichnen. Stift-Tasten frei belegbar.' },
    {
      async mount(root) {
        st.root = root;
        root.innerHTML = '<div class="rv-empty">Lädt …</div>';
        await loadAll();
        if (st.root === root) mountUi();
      },
      unmount() {
        closeText(true);
        saveNow();
        st.ro?.disconnect();
        st.root = null;
        st.view = null;
        st.ctx = null;
        st.panel = '';
        st.layerCache.clear();
      },
      wide: true,
    },
  );
})();
