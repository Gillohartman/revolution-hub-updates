'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.41.0',
  title: 'Revulution Hub 2.41',
  sub: 'Glücksrad, Geo auf echten Straßen, neue Coin-Preise und weniger Arbeitsspeicher.',
  items: [
    { open: 'tool-store', icon: 'spark', title: 'Glücksrad', text: 'Statt täglicher Gratis-Coins: einmal am Tag drehen – mit etwas Glück 50 Coins, ein Premium-Widget oder 25 % Rabatt auf Pro (jeder Preis nur einmal).' },
    { open: 'geo', icon: 'globe', title: 'GeoRevulution', text: 'Du startest immer auf einer echten Straße – kein Foto-Ort und kein „Neuer Ort“-Knopf mehr. Einstellungen als runde Leisten mit Bounce.' },
    { open: 'tool-store', icon: 'spark', title: 'Neue Coin-Preise', text: '100 Coins kosten jetzt CHF 0.77, größere Pakete sind günstiger.' },
    { open: 'tool-keyboard', icon: 'grid', title: 'Tastatur-Display', text: 'Nur noch GIFs von Revulution – weitere Display-GIFs gibt es im Store.' },
    { open: 'chats', icon: 'chat', title: 'Chats & Anrufe', text: 'Anruf-Fenster ohne eckigen Hintergrund, keine Striche mehr auf Knöpfen, Bild-Knopf schön links.' },
    { open: 'agenda', icon: 'calendar', title: 'Neue Fenster', text: 'Termin-Fenster und andere Dialoge ohne Kästen, mit runden Feldern.' },
    { open: 'home', icon: 'layers', title: 'Weniger Arbeitsspeicher', text: 'Widget-Fenster nur noch auf Monitoren mit Widgets, Aufräumen im Hintergrund. Die App ist durchsichtig, ohne eigenes Hintergrundbild.' },
  ],
};
