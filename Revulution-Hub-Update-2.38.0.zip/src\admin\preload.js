'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const call = (ch, ...a) => ipcRenderer.invoke(ch, ...a);
contextBridge.exposeInMainWorld('admin', {
  status: () => call('admin:status'),
  pick: () => call('admin:pick'),
  add: (file, name) => call('admin:add', file, name),
  remove: (id) => call('admin:remove', id),
  desktop: (id) => call('admin:desktop', id),
  reportStatus: (id, status) => call('admin:report-status', id, status),
  openData: () => call('admin:open-data'),
  path: () => call('admin:path'),
  cloud: {
    state: () => call('admin:cloud-state'),
    login: (email, password) => call('admin:login', email, password),
    code: (c) => call('admin:code', c),
    logout: () => call('admin:logout'),
    rules: () => call('admin:rules'),
    pending: () => call('admin:pending'),
    public: () => call('admin:public'),
    approve: (id, name) => call('admin:approve', id, name),
    reject: (id) => call('admin:reject', id),
    unpublish: (id) => call('admin:unpublish', id),
    publish: () => call('admin:publish-files'),
  },
  copy: (t) => call('admin:copy', t),
  sales: () => call('admin:sales'),
  gift: (g) => call('admin:gift', g),
});
