'use strict';

/*
 * Revolution Spiele (2.37): Würfel, Roulette, Plinko, Crash und Duell – nur mit ◆ Punkten.
 * Punkte verdient man in Schach und Geo; sie lassen sich weder kaufen noch in Coins tauschen.
 * Der Zufall entsteht im Hauptprozess, hier läuft nur die Animation.
 */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const ctx = () => T.ctx();
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const active = () => ctx().state()?.active === 'tool-games';
  const pts = () => ctx().profile?.()?.points ?? 0;
  const fmt = (n) => Number(n || 0).toLocaleString('de-CH');
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const st = { tab: 'dice', stake: 100, target: 50, bet: 'red', crashT: 2, crashAuto: false, crash: null, busy: false, last: null, history: [], budget: null, feed: [], feedRoom: null, duel: { room: null, list: [], mine: null, log: '' } };
  /* Live-Gewinne: echte Gewinne aller Spieler, Namen zensiert (z. B. „Da***n“) */
  const censor = (n) => {
    n = String(n || 'Spieler');
    return n.length <= 2 ? `${n[0]}*` : `${n.slice(0, 2)}${'*'.repeat(Math.min(4, n.length - 3))}${n.slice(-1)}`;
  };
  function feedJoin() {
    if (st.feedRoom || !window.RevNet) return;
    const room = new window.RevNet.Room({ app: 'games', code: 'WINS-FEED', name: 'feed' });
    st.feedRoom = room;
    room.on('msg', (m) => {
      if (m.t !== 'win' || !m.payout) return;
      st.feed.unshift({ name: censor(m.name), game: String(m.game || ''), payout: Number(m.payout) || 0, multi: Number(m.multi) || 0, at: Date.now() });
      st.feed = st.feed.slice(0, 30);
      paintFeed();
    });
    room.join().catch(() => (st.feedRoom = null));
  }
  function shareWin(r) {
    if (!r?.payout || (r.multi || 0) < 1.5) return;
    const entry = { name: ctx().profile?.()?.name || 'Spieler', game: st.tab, payout: r.payout, multi: r.multi || 0 };
    st.feed.unshift({ ...entry, name: censor(entry.name), at: Date.now() });
    paintFeed();
    st.feedRoom?.send('win', entry);
  }
  const GAME_NAME = { dice: 'Würfel', roulette: 'Roulette', plinko: 'Plinko', crash: 'Abflug', duel: 'Duell' };
  function feedHtml() {
    return st.feed.length ? st.feed.map((f) => `<div class="gm-feed-row"><b>${esc(f.name)}</b><span>${esc(GAME_NAME[f.game] || f.game)}${f.multi ? ` · ${f.multi}×` : ''}</span><em>+◆ ${fmt(f.payout)}</em></div>`).join('') : '<p class="muted">Noch keine Gewinne – hier erscheinen echte Gewinne anderer Spieler.</p>';
  }
  function paintFeed() {
    const el = document.getElementById('gm-feed');
    if (el) el.innerHTML = feedHtml();
  }
  function loadBudget() {
    window.hub.games.budget?.().then((b) => {
      st.budget = b;
      const el = document.getElementById('gm-budget');
      if (el) el.innerHTML = budgetHtml();
    }).catch(() => {});
  }
  function budgetHtml() {
    const b = st.budget;
    if (!b) return '';
    const left = Math.max(0, b.limit - b.used);
    return `Limit: noch ◆ ${fmt(left)} von ${fmt(b.limit)} bis ${new Date(b.until).toLocaleDateString('de-CH', { day: 'numeric', month: 'short' })}<i style="--p:${Math.min(100, (b.used / b.limit) * 100)}%"></i>`;
  }
  const GAMES = [['dice', 'Würfel', '🎲'], ['roulette', 'Roulette', '🎡'], ['plinko', 'Plinko', '🔻'], ['crash', 'Abflug', '✈️'], ['duel', 'Duell', '⚔️']];
  const ROUL = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
  const RED = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
  const PLINKO = [16, 8, 3, 1.5, 1.1, 0.7, 0.5, 0.7, 1.1, 1.5, 3, 8, 16];

  function stakeBar() {
    return `<div class="gm-stake"><span>Einsatz</span><button data-gm-st="half">½</button><input data-gm-stake inputmode="numeric" value="${st.stake}" /><button data-gm-st="double">2×</button><button data-gm-st="max">Max</button><b class="gm-pts">◆ ${fmt(pts())}</b></div>`;
  }
  function result() {
    const r = st.last;
    if (!r) return '<div class="gm-result idle">Viel Glück!</div>';
    return `<div class="gm-result ${r.win ? 'win' : 'lose'}">${r.win ? `+◆ ${fmt(r.payout)}` : 'Leider nichts'}${r.multi ? ` · ${r.multi}×` : ''}</div>`;
  }
  function panel() {
    switch (st.tab) {
      case 'dice':
        return `<div class="gm-dice"><div class="gm-dice-bar"><i style="width:${st.target}%"></i><em id="gm-roll" style="left:${st.last?.game === 'dice' ? st.last.roll : 50}%">${st.last?.game === 'dice' ? st.last.roll.toFixed(2) : '–'}</em></div>
          <label class="gm-range">Gewinnt unter <b>${st.target}</b> · Chance ${st.target} % · Auszahlung ${(Math.floor((92 / st.target) * 100) / 100).toFixed(2)}×<input type="range" min="2" max="95" value="${st.target}" data-gm-target /></label></div>`;
      case 'roulette': {
        const bets = [['red', 'Rot', '1,9×'], ['black', 'Schwarz', '1,9×'], ['even', 'Gerade', '1,9×'], ['odd', 'Ungerade', '1,9×'], ['green', '0 · Grün', '33×']];
        return `<div class="gm-roul"><div class="gm-wheel" id="gm-wheel">${ROUL.map((n, i) => `<i style="--a:${(i * 360) / 37}deg;--c:${n === 0 ? '#1f9d55' : RED.has(n) ? '#d61f2c' : '#17171b'}"><span>${n}</span></i>`).join('')}<b></b></div>
          <div class="gm-bet-col"><div class="gm-bets">${bets.map(([v, n, m]) => `<button class="${st.bet === v ? 'on' : ''}" data-gm-bet="${v}"><b>${n}</b><small>${m}</small></button>`).join('')}</div>
          <div class="gm-nums">${Array.from({ length: 37 }, (_, n) => `<button class="${st.bet === `num:${n}` ? 'on' : ''} ${n === 0 ? 'z' : RED.has(n) ? 'r' : 'b'}" data-gm-bet="num:${n}">${n}</button>`).join('')}</div><small class="muted">Einzelne Zahl: 34×</small></div></div>`;
      }
      case 'plinko':
        return `<div class="gm-plinko"><canvas id="gm-plinko" width="560" height="380"></canvas><div class="gm-slots">${PLINKO.map((m, i) => `<span class="${st.last?.game === 'plinko' && st.last.slot === i ? 'hit' : ''}" style="--h:${Math.min(1, m / 16)}">${m}×</span>`).join('')}</div></div>`;
      case 'crash':
        return `<div class="gm-crash"><canvas id="gm-crash" width="560" height="300"></canvas><div class="gm-crash-x" id="gm-crash-x">${st.last?.game === 'crash' ? `${(st.last.m || 1).toFixed(2)}×` : '1.00×'}</div>
          ${st.crash ? '<button class="btn primary gm-cashout" data-gm-cashout>Jetzt aussteigen</button>' : ''}
          <div class="gm-auto"><button class="switch ${st.crashAuto ? 'on' : ''}" data-gm-auto></button><span>Automatisch aussteigen ${st.crashAuto ? `bei <b>${st.crashT.toFixed(2)}×</b>` : '(aus – du steigst selbst aus)'}</span></div>
          ${st.crashAuto ? `<label class="gm-range"><input type="range" min="1.1" max="10" step="0.1" value="${st.crashT}" data-gm-crash /></label>` : ''}</div>`;
      case 'duel':
        return duelHtml();
      default:
        return '';
    }
  }
  function html() {
    feedJoin();
    if (!st.budget) loadBudget();
    return `<div class="gm-wrap"><div class="gm">
      <div class="gm-note"><b>⚠ Nicht empfohlen – nur Spielgeld.</b> Gespielt wird ausschließlich mit ◆ Punkten aus Schach und Geo, nie mit echtem Geld. Punkte lassen sich nicht kaufen und nicht in Coins oder Geld tauschen. Der Hausvorteil beträgt 8 % – auf Dauer verliert man. Limit: ◆ 2 000 Einsatz pro 14 Tage, danach Spielpause.<div class="gm-budget" id="gm-budget">${budgetHtml()}</div></div>
      <nav class="seg gm-tabs">${GAMES.map(([id, n, e]) => `<button class="${st.tab === id ? 'on' : ''}" data-gm-tab="${id}">${e} ${n}</button>`).join('')}</nav>
      <div class="gm-stage">${panel()}</div>
      ${st.tab === 'duel' ? '' : `${stakeBar()}<div class="gm-go"><button class="btn primary gm-play" data-gm-play ${st.busy ? 'disabled' : ''}>${st.busy ? '…' : st.tab === 'crash' ? 'Abheben' : st.tab === 'plinko' ? 'Kugel fallen lassen' : st.tab === 'roulette' ? 'Drehen' : 'Würfeln'}</button>${result()}</div>`}
      ${st.history.length ? `<div class="gm-hist">${st.history.slice(0, 14).map((h) => `<span class="${h.win ? 'w' : 'l'}">${h.win ? '+' : '−'}${fmt(h.win ? h.payout - h.stake : h.stake)}</span>`).join('')}</div>` : ''}
    </div>
    <aside class="gm-side"><div class="gm-side-h"><span class="gm-live"></span>Live-Gewinne</div><div id="gm-feed">${feedHtml()}</div></aside></div>`;
  }

  /* ---------------- Animationen */
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function animRoulette(n) {
    const wheel = document.getElementById('gm-wheel');
    if (!wheel) return;
    const idx = ROUL.indexOf(n);
    const turn = 360 * 5 + (360 - (idx * 360) / 37);
    wheel.style.transition = 'none';
    wheel.style.transform = 'rotate(0deg)';
    void wheel.offsetWidth;
    wheel.style.transition = 'transform 3.2s cubic-bezier(.15,.85,.25,1)';
    wheel.style.transform = `rotate(${turn}deg)`;
    await sleep(3300);
  }
  async function animPlinko(path) {
    const cv = document.getElementById('gm-plinko');
    if (!cv) return;
    const g = cv.getContext('2d');
    const rows = 12;
    const W = cv.width;
    const gap = 40;
    const pegs = () => {
      g.clearRect(0, 0, W, cv.height);
      for (let r = 0; r < rows; r++)
        for (let c = 0; c <= r + 1; c++) {
          g.beginPath();
          g.arc(W / 2 + (c - (r + 1) / 2) * gap, 24 + r * 28, 3.5, 0, Math.PI * 2);
          g.fillStyle = 'rgba(255,255,255,.55)';
          g.fill();
        }
    };
    let x = W / 2;
    let pos = 0;
    for (let r = 0; r <= rows; r++) {
      const tx = W / 2 + (pos - r / 2) * gap;
      const ty = 10 + r * 28;
      const sx = x;
      for (let f = 1; f <= 8; f++) {
        pegs();
        const k = f / 8;
        g.beginPath();
        g.arc(sx + (tx - sx) * k, ty - 14 + 14 * k - Math.sin(k * Math.PI) * 8, 7, 0, Math.PI * 2);
        g.fillStyle = '#ffd60a';
        g.shadowColor = '#ffd60a';
        g.shadowBlur = 14;
        g.fill();
        g.shadowBlur = 0;
        await sleep(16);
      }
      x = tx;
      if (r < rows) pos += path[r];
    }
  }
  async function animCrash(target, crashAt) {
    const cv = document.getElementById('gm-crash');
    const label = document.getElementById('gm-crash-x');
    if (!cv) return;
    const g = cv.getContext('2d');
    const end = Math.min(crashAt, Math.max(target, 1.01) > crashAt ? crashAt : target);
    const stop = crashAt < target ? crashAt : target;
    const t0 = performance.now();
    const dur = 900 + Math.log(Math.max(1.01, stop)) * 1500;
    return new Promise((resolve) => {
      const frame = (now) => {
        const k = Math.min(1, (now - t0) / dur);
        const m = 1 + (stop - 1) * k * k;
        g.clearRect(0, 0, cv.width, cv.height);
        g.strokeStyle = 'rgba(255,255,255,.08)';
        for (let i = 1; i < 6; i++) {
          g.beginPath();
          g.moveTo(0, (cv.height / 6) * i);
          g.lineTo(cv.width, (cv.height / 6) * i);
          g.stroke();
        }
        g.beginPath();
        g.moveTo(10, cv.height - 10);
        const px = 10 + (cv.width - 60) * k;
        const py = cv.height - 10 - (cv.height - 50) * Math.min(1, Math.log(m) / Math.log(Math.max(2, stop)));
        g.quadraticCurveTo(px * 0.6, cv.height - 10, px, py);
        g.lineWidth = 3;
        g.strokeStyle = crashAt < target && k === 1 ? '#ff453a' : '#30d158';
        g.stroke();
        g.font = '26px "Segoe UI Emoji"';
        g.fillText(crashAt < target && k === 1 ? '💥' : '✈️', px - 6, py + 4);
        if (label) label.textContent = `${m.toFixed(2)}×`;
        if (k < 1) requestAnimationFrame(frame);
        else resolve(end);
      };
      requestAnimationFrame(frame);
    });
  }

  /* Abflug als Live-Runde: Steigkurve läuft, bis du aussteigst oder er abstürzt */
  async function crashRun() {
    const r = await window.hub.games.play({ game: 'crash', stake: st.stake, opt: { auto: st.crashAuto, target: st.crashT } });
    st.crash = { id: r.round, pts: [] };
    ctx().render();
    const cv = document.getElementById('gm-crash');
    const g = cv?.getContext('2d');
    let res = null;
    while (!res) {
      const t = await window.hub.games.crashTick(st.crash.id);
      st.crash.pts.push(t.m);
      if (g) {
        g.clearRect(0, 0, cv.width, cv.height);
        const n = st.crash.pts.length;
        const top = Math.max(2, t.m * 1.2);
        g.beginPath();
        st.crash.pts.forEach((m, i) => {
          const x = 10 + (i / Math.max(40, n)) * (cv.width - 70);
          const y = cv.height - 12 - ((m - 1) / (top - 1)) * (cv.height - 50);
          if (i) g.lineTo(x, y); else g.moveTo(x, y);
        });
        g.lineWidth = 3;
        g.strokeStyle = t.crashed ? '#ff453a' : '#30d158';
        g.stroke();
        const lx = 10 + ((n - 1) / Math.max(40, n)) * (cv.width - 70);
        const ly = cv.height - 12 - ((t.m - 1) / (top - 1)) * (cv.height - 50);
        g.font = '26px "Segoe UI Emoji"';
        g.fillText(t.crashed ? '💥' : '✈️', lx - 6, ly + 4);
      }
      const lab = document.getElementById('gm-crash-x');
      if (lab) lab.textContent = `${t.m.toFixed(2)}×`;
      if (t.done) res = t;
      else await sleep(90);
    }
    st.crash = null;
    return { game: 'crash', win: !res.crashed && res.payout > 0, payout: res.payout || 0, multi: res.crashed ? 0 : res.m, m: res.m, points: res.points };
  }
  async function play() {
    if (st.busy) return;
    st.busy = true;
    ctx().render();
    try {
      let r;
      if (st.tab === 'crash') r = await crashRun();
      else {
        const opt = st.tab === 'dice' ? { target: st.target } : st.tab === 'roulette' ? { bet: st.bet } : {};
        r = await window.hub.games.play({ game: st.tab, stake: st.stake, opt });
        if (r.game === 'roulette') await animRoulette(r.n);
        if (r.game === 'plinko') await animPlinko(r.path);
        if (r.game === 'dice') {
          const el = document.getElementById('gm-roll');
          if (el) {
            el.style.left = `${r.roll}%`;
            el.textContent = r.roll.toFixed(2);
          }
          await sleep(450);
        }
      }
      st.last = r;
      st.history.unshift({ win: r.win, payout: r.payout, stake: st.stake });
      if (r.win) shareWin(r);
      loadBudget();
    } catch (e) {
      st.crash = null;
      ctx().toast(errText(e), 'error');
    }
    st.busy = false;
    if (active()) ctx().render();
  }

  /* ---------------- Duell: Lobby über das Online-Netz (wie Schach/Geo) */
  function duelHtml() {
    const d = st.duel;
    return `<div class="gm-duel">
      <p class="muted">Fordere andere online heraus: beide setzen gleich viel, beide würfeln 1–100. Wer höher würfelt, bekommt den Pott (minus 5 %).</p>
      ${d.room ? '' : '<button class="btn primary" data-gm-duel="join">Lobby betreten</button>'}
      ${d.room ? `<div class="gm-stake"><span>Einsatz</span><input data-gm-stake inputmode="numeric" value="${st.stake}" /><b class="gm-pts">◆ ${fmt(pts())}</b><button class="btn primary" data-gm-duel="offer">Herausforderung stellen</button></div>
        <div class="gm-offers">${d.list.length ? d.list.map((o) => `<div class="gm-offer"><b>${esc(o.name)}</b><span>◆ ${fmt(o.stake)}</span>${o.mine ? '<em>deine</em>' : `<button class="btn small primary" data-gm-accept="${esc(o.id)}">Annehmen</button>`}</div>`).join('') : '<p class="muted">Noch keine Herausforderungen – stell die erste!</p>'}</div>
        ${d.log ? `<div class="gm-result ${d.win ? 'win' : 'lose'}">${esc(d.log)}</div>` : ''}` : ''}
    </div>`;
  }
  async function duelJoin() {
    if (!window.RevNet) return ctx().toast('Online-Netz nicht verfügbar.', 'error');
    const name = ctx().profile?.()?.name || 'Spieler';
    const room = new window.RevNet.Room({ app: 'games', code: 'DUEL-LOBBY', name });
    st.duel.room = room;
    room.on('msg', onDuel);
    try {
      await room.join();
      room.send('who');
    } catch {
      st.duel.room = null;
      ctx().toast('Lobby nicht erreichbar.', 'error');
    }
    ctx().render();
  }
  const me = () => (window.__duelId ||= Math.random().toString(36).slice(2, 10));
  async function onDuel(m) {
    const d = st.duel;
    if (m.t === 'offer' && !d.list.some((o) => o.id === m.id)) d.list.push({ id: m.id, name: m.name, stake: m.stake, owner: m.owner });
    if (m.t === 'who' && d.mine) d.room.send('offer', d.mine);
    if (m.t === 'gone') d.list = d.list.filter((o) => o.id !== m.id);
    if (m.t === 'accept' && d.mine && m.id === d.mine.id) {
      // jemand nimmt meine Herausforderung an → ich würfle und schicke meinen Wurf
      const mine = await window.hub.games.roll();
      d.room.send('roll', { id: m.id, from: me(), roll: mine, other: m.from });
      d.pending = { id: m.id, stake: d.mine.stake, mine };
      d.room.send('gone', { id: m.id });
      d.list = d.list.filter((o) => o.id !== m.id);
      d.mine = null;
    }
    if (m.t === 'roll' && m.other === me() && d.pending?.id === m.id && d.pending.mine == null) {
      // ich habe angenommen: Gegner-Wurf da → mein Wurf, beide abrechnen
      const mine = await window.hub.games.roll();
      d.room.send('roll2', { id: m.id, roll: mine, other: m.from });
      await settle(d.pending.stake, mine, m.roll);
    }
    if (m.t === 'roll2' && d.pending?.id === m.id && d.pending.mine != null) await settle(d.pending.stake, d.pending.mine, m.roll);
    if (active()) ctx().render();
  }
  async function settle(stake, mine, theirs) {
    const d = st.duel;
    try {
      const r = await window.hub.games.duel({ stake, mine, theirs });
      d.win = r.win;
      d.log = r.tie ? `Unentschieden (${mine} : ${theirs}) – Einsatz zurück.` : r.win ? `Gewonnen! ${mine} : ${theirs} · +◆ ${fmt(r.payout - stake)}` : `Verloren. ${mine} : ${theirs}`;
    } catch (e) {
      d.log = errText(e);
    }
    d.pending = null;
  }

  document.addEventListener('click', (e) => {
    if (!active()) return;
    const q = (s) => e.target.closest?.(s);
    const tab = q('[data-gm-tab]')?.dataset.gmTab;
    if (tab) {
      st.tab = tab;
      st.last = null;
      return ctx().render();
    }
    const s = q('[data-gm-st]')?.dataset.gmSt;
    if (s) {
      st.stake = Math.max(10, Math.min(5000, s === 'half' ? Math.floor(st.stake / 2) : s === 'double' ? st.stake * 2 : Math.min(5000, pts())));
      return ctx().render();
    }
    const bet = q('[data-gm-bet]')?.dataset.gmBet;
    if (bet) {
      st.bet = bet;
      return ctx().render();
    }
    if (q('[data-gm-play]')) return play();
    if (q('[data-gm-cashout]') && st.crash) return window.hub.games.crashCashout(st.crash.id).catch(() => {});
    if (q('[data-gm-auto]')) {
      st.crashAuto = !st.crashAuto;
      return ctx().render();
    }
    const du = q('[data-gm-duel]')?.dataset.gmDuel;
    if (du === 'join') return duelJoin();
    if (du === 'offer') {
      if (st.stake > pts()) return ctx().toast('Nicht genug Punkte.', 'error');
      const offer = { id: `${me()}-${Date.now()}`, name: ctx().profile?.()?.name || 'Spieler', stake: st.stake, owner: me() };
      st.duel.mine = offer;
      st.duel.list.push({ ...offer, mine: true });
      st.duel.room?.send('offer', offer);
      return ctx().render();
    }
    const acc = q('[data-gm-accept]')?.dataset.gmAccept;
    if (acc) {
      const o = st.duel.list.find((x) => x.id === acc);
      if (!o) return;
      if (o.stake > pts()) return ctx().toast('Nicht genug Punkte für diesen Einsatz.', 'error');
      st.duel.pending = { id: o.id, stake: o.stake, mine: null };
      st.duel.room.send('accept', { id: o.id, from: me() });
      st.duel.log = 'Gegner würfelt …';
      return ctx().render();
    }
  });
  document.addEventListener('input', (e) => {
    if (!active()) return;
    if (e.target.matches?.('[data-gm-stake]')) st.stake = Math.max(10, Math.min(5000, Math.floor(Number(e.target.value.replace(/\D/g, '')) || 10)));
    if (e.target.matches?.('[data-gm-target]')) {
      st.target = Number(e.target.value);
      const lab = e.target.closest('.gm-range');
      if (lab) lab.firstChild.textContent = 'Gewinnt unter ';
      lab.querySelector('b').textContent = st.target;
      e.target.parentElement.parentElement.querySelector('.gm-dice-bar i').style.width = `${st.target}%`;
    }
    if (e.target.matches?.('[data-gm-crash]')) {
      st.crashT = Number(e.target.value);
      e.target.closest('.gm-range').querySelector('b').textContent = `${st.crashT.toFixed(2)}×`;
    }
  });

  T.register(
    'tool-games',
    { nav: 'Spiele', title: 'Revolution Spiele', sub: 'Würfel, Roulette, Plinko, Abflug & Duelle', icon: 'spark', tint: 'linear-gradient(135deg,#ffd60a,#ff375f)', desc: 'Spiele mit deinen ◆ Punkten aus Schach und Geo – allein oder im Duell gegen andere. Punkte sind nicht käuflich.' },
    html,
  );
})();
