'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.38.0',
  title: 'Revulution Hub 2.38',
  sub: 'Mod-Bibliothek, 9 neue Widgets, runde Ecken ohne Treppen und ein ruhigeres Schach.',
  items: [
    { open: 'tool-modrinth', icon: 'cube', title: 'Mod-Bibliothek', text: 'Mods, Shader und Texturen von Modrinth suchen und mit einem Klick installieren – passende Version und benötigte Mods kommen automatisch mit.' },
    { open: 'tool-desktop', icon: 'grid', title: '9 neue Widgets', text: 'Pixel-Pflanze zum Gießen, Notizen, To-do, Rechner, PC-Laufzeit, Mikrofon, Live-Kamera, Soundboard und Schnellzugriff für Dateien.' },
    { open: 'tool-speed', icon: 'globe', title: 'WLAN-Test', text: 'Pfeile statt Text im Ring und neue Eignung: Gaming, Fernseher, Handy und Videochat mit je vier Balken.' },
    { open: 'agenda', icon: 'calendar', title: 'Countdown-Ring', text: 'Termine zeigen einen Ring, der sich über 7 Tage schließt – am Tag selbst mit dem Anfangsbuchstaben.' },
    { open: 'chess', icon: 'chess', title: 'Schach', text: 'Neues Startmenü ohne Brett im Hintergrund, der Coach schweigt in der Lobby, runde kurze Tabs.' },
    { open: 'tool-games', icon: 'spark', title: 'Spiele', text: 'Live-Gewinne, Roulette auf jede Zahl, Abflug mit Auto-Aussteigen, Hinweis und Wochenlimit für ◆ Punkte.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Hintergründe', text: 'Premium-Bereich, Revulution Live, Likes ohne Pro und Schnellwechsler per Tastenkürzel (in den Einstellungen).' },
    { open: 'orbit', icon: 'layers', title: 'Island', text: 'Wetter standardmäßig aus, Timer per Rechtsklick löschen, kleinere Knöpfe, Album-Cover und Bass laden still nach.' },
    { open: 'tool-store', icon: 'spark', title: 'Revulution Pro', text: 'Premium-Wallpaper im Abo – Infos und Preise im Store und im Konto.' },
  ],
};
