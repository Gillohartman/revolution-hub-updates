'use strict';

/* 2.38: weitere Desktop-Widgets – PC-Laufzeit, Notizen, To-do, Rechner, Pixel-Pflanze,
   Mikrofon-Monitor, Live-Kamera, Soundboard und Schnellzugriff.
   Notizen/To-do/Pflanze liegen im localStorage, damit alle Monitore dasselbe zeigen. */
(() => {
  const $ = (id) => document.getElementById(id);
  const card = (k) => document.querySelector(`.dw[data-w="${k}"]`);
  const shown = (k) => {
    const el = card(k);
    return Boolean(el && !el.hidden && !el.classList.contains('away'));
  };
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const load = (k, d) => {
    try {
      return JSON.parse(localStorage.getItem(k)) ?? d;
    } catch {
      return d;
    }
  };
  const save = (k, v) => localStorage.setItem(k, JSON.stringify(v));

  /* Tastatur: nur solange ein Feld den Fokus hat, darf das Widget-Fenster Tasten bekommen */
  document.addEventListener('focusin', (e) => {
    if (e.target.matches('textarea, input')) window.hub.widgetsKeyboard?.(true);
  });
  document.addEventListener('focusout', (e) => {
    if (e.target.matches('textarea, input')) setTimeout(() => !document.activeElement?.matches?.('textarea, input') && window.hub.widgetsKeyboard?.(false), 60);
  });
  let calcFocus = false;
  document.addEventListener('pointerdown', (e) => {
    const inCalc = Boolean(e.target.closest('.dw-calc'));
    if (inCalc !== calcFocus) {
      calcFocus = inCalc;
      window.hub.widgetsKeyboard?.(inCalc);
    }
  });

  /* ------------------------------------------------------------ PC-Laufzeit */
  let upBase = null;
  async function paintUptime() {
    if (!shown('uptime')) return;
    if (!upBase || Date.now() - upBase.at > 10 * 60000) {
      const s = await window.hub.widgetUptime?.().catch(() => null);
      if (s != null) upBase = { at: Date.now(), secs: Number(s) };
    }
    if (!upBase) return;
    const secs = upBase.secs + (Date.now() - upBase.at) / 1000;
    const d = Math.floor(secs / 86400);
    const h = Math.floor((secs % 86400) / 3600);
    const m = Math.floor((secs % 3600) / 60);
    $('dw-up-big').innerHTML = `${d ? `${d}<small>T</small> ` : ''}${h}<small>h</small> ${String(m).padStart(2, '0')}<small>m</small>`;
    const since = new Date(Date.now() - secs * 1000);
    $('dw-up-since').textContent = `seit ${since.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' })}, ${since.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
  }

  /* ------------------------------------------------------------ Notizen */
  const notes = $('dw-notes-t');
  notes.value = load('dw-notes', '');
  let noteT = 0;
  notes.addEventListener('input', () => {
    clearTimeout(noteT);
    noteT = setTimeout(() => save('dw-notes', notes.value), 300);
  });

  /* ------------------------------------------------------------ To-do */
  function paintTodo() {
    const list = load('dw-todo', []);
    $('dw-todo-n').textContent = list.length ? `${list.filter((t) => t.done).length}/${list.length}` : '';
    $('dw-todo-list').innerHTML = list.length
      ? list.map((t, i) => `<div class="dw-todo-row ${t.done ? 'done' : ''}" data-nodrag><button class="dw-chk" data-todo-t="${i}">${t.done ? '✓' : ''}</button><span>${esc(t.text)}</span><button class="dw-x-del" data-todo-d="${i}" title="Löschen">✕</button></div>`).join('')
      : '<div class="dw-empty">Nichts zu tun 🎉</div>';
  }
  $('dw-todo-in').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || !e.target.value.trim()) return;
    save('dw-todo', [...load('dw-todo', []), { text: e.target.value.trim().slice(0, 120), done: false }].slice(-30));
    e.target.value = '';
    paintTodo();
  });
  $('dw-todo-list').addEventListener('click', (e) => {
    const list = load('dw-todo', []);
    const t = e.target.closest('[data-todo-t]');
    const d = e.target.closest('[data-todo-d]');
    if (t) list[Number(t.dataset.todoT)].done = !list[Number(t.dataset.todoT)].done;
    else if (d) list.splice(Number(d.dataset.todoD), 1);
    else return;
    save('dw-todo', list);
    paintTodo();
  });

  /* ------------------------------------------------------------ Rechner (wie ein Taschenrechner) */
  const KEYS = ['C', '±', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '0', ',', '⌫', '='];
  $('dw-calc-k').innerHTML = KEYS.map((k) => `<button data-k="${k}" class="${'÷×−+='.includes(k) ? 'op' : 'C±%'.includes(k) ? 'fn' : ''}">${k}</button>`).join('');
  const calc = { cur: '0', acc: null, op: null, fresh: false };
  const num = (s) => Number(String(s).replace(',', '.'));
  const show = (v) => {
    if (!Number.isFinite(v)) return 'Fehler';
    const r = Math.round(v * 1e10) / 1e10;
    return String(r).replace('.', ',');
  };
  function calcOp(a, b, op) {
    return op === '+' ? a + b : op === '−' ? a - b : op === '×' ? a * b : op === '÷' ? a / b : b;
  }
  function press(k) {
    if (/^[0-9]$/.test(k)) {
      calc.cur = calc.fresh || calc.cur === '0' ? k : calc.cur.length < 14 ? calc.cur + k : calc.cur;
      calc.fresh = false;
    } else if (k === ',') {
      if (calc.fresh) calc.cur = '0';
      if (!calc.cur.includes(',')) calc.cur += ',';
      calc.fresh = false;
    } else if (k === 'C') Object.assign(calc, { cur: '0', acc: null, op: null, fresh: false });
    else if (k === '⌫') calc.cur = calc.cur.length > 1 ? calc.cur.slice(0, -1) : '0';
    else if (k === '±') calc.cur = calc.cur.startsWith('-') ? calc.cur.slice(1) : calc.cur === '0' ? '0' : `-${calc.cur}`;
    else if (k === '%') calc.cur = show(num(calc.cur) / 100);
    else if ('÷×−+'.includes(k)) {
      if (calc.op && !calc.fresh) calc.cur = show(calcOp(calc.acc, num(calc.cur), calc.op));
      calc.acc = num(calc.cur);
      calc.op = k;
      calc.fresh = true;
    } else if (k === '=') {
      if (calc.op) calc.cur = show(calcOp(calc.acc, num(calc.cur), calc.op));
      Object.assign(calc, { acc: null, op: null, fresh: true });
    }
    $('dw-calc-d').textContent = calc.cur;
    document.querySelectorAll('#dw-calc-k .op').forEach((b) => b.classList.toggle('on', calc.fresh && b.dataset.k === calc.op));
  }
  $('dw-calc-k').addEventListener('click', (e) => {
    const b = e.target.closest('[data-k]');
    if (b) press(b.dataset.k);
  });
  document.addEventListener('keydown', (e) => {
    if (!calcFocus || e.target.matches('textarea, input')) return;
    const map = { '/': '÷', '*': '×', '-': '−', '+': '+', Enter: '=', '=': '=', Backspace: '⌫', Escape: 'C', '.': ',', ',': ',', '%': '%' };
    const k = /^[0-9]$/.test(e.key) ? e.key : map[e.key];
    if (k) {
      e.preventDefault();
      press(k);
    }
  });

  /* ------------------------------------------------------------ Pixel-Pflanze */
  // Wasser sinkt über 2 Tage auf 0. Gießen (max. alle 6 h) lässt sie eine Stufe wachsen; zu lange trocken = sie welkt.
  const P_MAX = 6;
  function plantState() {
    const p = load('dw-plant', { water: 1, at: Date.now(), growth: 0, lastGrow: 0, dryAt: 0 });
    const water = Math.max(0, p.water - (Date.now() - p.at) / (48 * 3600000));
    return { ...p, water };
  }
  function drawPlant(pour = 0) {
    const p = plantState();
    const c = $('dw-plant-c');
    const g = c.getContext('2d');
    const S = 8;
    g.clearRect(0, 0, 128, 128);
    const px = (x, y, col) => {
      g.fillStyle = col;
      g.fillRect(x * S, y * S, S, S);
    };
    const wilt = p.water <= 0.02;
    const leaf = wilt ? '#a3824a' : '#4ade80';
    const leaf2 = wilt ? '#7c5f32' : '#22a35a';
    const stem = wilt ? '#8a6a3a' : '#2f9e55';
    // Topf
    for (let x = 4; x <= 11; x++) px(x, 12, '#c2410c');
    for (let x = 5; x <= 10; x++) for (let y = 13; y <= 15; y++) px(x, y, y === 13 ? '#ea580c' : '#c2410c');
    for (let x = 5; x <= 10; x++) px(x, 12, '#5b3a1e');
    // Stängel + Blätter je nach Stufe
    const h = 1 + Math.min(P_MAX, p.growth);
    const top = 12 - h;
    for (let y = 11; y >= top; y--) px(7 + ((11 - y) % 3 === 2 ? 1 : 0), y, stem);
    const leaves = [[6, 10], [9, 9], [5, 8], [10, 7], [5, 6], [10, 5]];
    for (let i = 0; i < Math.min(h - 1, leaves.length); i++) {
      const [x, y] = leaves[i];
      px(x, y, leaf);
      px(x + (x < 8 ? -1 : 1), y - (wilt ? -1 : 1), leaf2);
    }
    if (p.growth >= P_MAX && !wilt) {
      // Blüte
      const bx = 7;
      const by = top - 1;
      px(bx, by, '#fde047');
      px(bx - 1, by, '#f472b6');
      px(bx + 1, by, '#f472b6');
      px(bx, by - 1, '#f472b6');
      px(bx, by + 1, '#f472b6');
    }
    // Gießkanne + Tropfen während des Gießens
    if (pour > 0) {
      g.save();
      g.translate(96, 26);
      g.rotate(-0.5 * Math.min(1, pour * 3));
      g.fillStyle = '#60a5fa';
      g.fillRect(-10, -8, 22, 16);
      g.fillRect(-22, -12, 14, 5);
      g.fillStyle = '#93c5fd';
      g.fillRect(-10, -8, 22, 4);
      g.restore();
      g.fillStyle = '#7dd3fc';
      for (let i = 0; i < 6; i++) {
        const t = (pour * 3 + i / 6) % 1;
        g.fillRect(66 + (i % 3) * 6, 30 + t * 60, 3, 5);
      }
    }
    $('dw-plant-w').style.width = `${Math.round(p.water * 100)}%`;
    $('dw-plant-w').style.background = p.water < 0.25 ? '#f87171' : '#60a5fa';
    $('dw-plant-s').textContent = wilt ? 'Durst!' : p.growth >= P_MAX ? 'Blüht' : `Stufe ${p.growth + 1}/${P_MAX + 1}`;
  }
  $('dw-plant-btn').addEventListener('click', () => {
    const p = plantState();
    const grow = Date.now() - (p.lastGrow || 0) > 6 * 3600000;
    save('dw-plant', { water: 1, at: Date.now(), growth: grow ? Math.min(P_MAX, p.growth + 1) : p.growth, lastGrow: grow ? Date.now() : p.lastGrow });
    const t0 = performance.now();
    const step = (t) => {
      const k = (t - t0) / 1400;
      drawPlant(k < 1 ? k : 0);
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });

  /* ------------------------------------------------------------ Mikrofon-Monitor */
  const mic = { stream: null, ctx: null, an: null, hear: null, raf: 0 };
  $('dw-mic-bar').innerHTML = Array.from({ length: 24 }, () => '<i></i>').join('');
  function micStop() {
    cancelAnimationFrame(mic.raf);
    mic.stream?.getTracks().forEach((t) => t.stop());
    mic.ctx?.close().catch(() => {});
    Object.assign(mic, { stream: null, ctx: null, an: null, hear: null });
    $('dw-mic-on').textContent = 'Start';
    $('dw-mic-on').classList.remove('on');
    $('dw-mic-hear').classList.remove('on');
    $('dw-mic-db').textContent = '';
    [...$('dw-mic-bar').children].forEach((i) => (i.className = ''));
  }
  async function micStart() {
    try {
      mic.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    } catch {
      $('dw-mic-db').textContent = 'kein Zugriff';
      return;
    }
    mic.ctx = new AudioContext();
    const src = mic.ctx.createMediaStreamSource(mic.stream);
    mic.an = mic.ctx.createAnalyser();
    mic.an.fftSize = 1024;
    src.connect(mic.an);
    mic.src = src;
    $('dw-mic-on').textContent = 'Stopp';
    $('dw-mic-on').classList.add('on');
    const buf = new Float32Array(mic.an.fftSize);
    const bars = [...$('dw-mic-bar').children];
    let peak = 0;
    const loop = () => {
      mic.an.getFloatTimeDomainData(buf);
      let sum = 0;
      for (const v of buf) sum += v * v;
      const db = 20 * Math.log10(Math.sqrt(sum / buf.length) || 1e-6);
      const lvl = Math.max(0, Math.min(1, (db + 60) / 60));
      peak = Math.max(lvl, peak - 0.01);
      const n = Math.round(lvl * bars.length);
      const pk = Math.round(peak * bars.length) - 1;
      bars.forEach((b, i) => (b.className = i < n ? (i > bars.length * 0.85 ? 'r' : i > bars.length * 0.65 ? 'y' : 'g') : i === pk ? 'pk' : ''));
      $('dw-mic-db').textContent = `${Math.max(-60, Math.round(db))} dB`;
      mic.raf = requestAnimationFrame(loop);
    };
    loop();
  }
  $('dw-mic-on').addEventListener('click', () => (mic.stream ? micStop() : micStart()));
  $('dw-mic-hear').addEventListener('click', () => {
    if (!mic.ctx) return;
    if (mic.hear) {
      mic.src.disconnect(mic.ctx.destination);
      mic.hear = null;
    } else {
      mic.src.connect(mic.ctx.destination);
      mic.hear = true;
    }
    $('dw-mic-hear').classList.toggle('on', Boolean(mic.hear));
  });

  /* ------------------------------------------------------------ Live-Kamera */
  const cam = { stream: null };
  // Damit die Kamera-Anzeige im Hub weiß, wer die Kamera nutzt – und sie abschalten kann
  if (!window.__revCam) {
    window.__revCam = {
      count: () => (cam.stream ? cam.stream.getVideoTracks().filter((t) => t.readyState === 'live').length : 0),
      stop: () => {
        const n = window.__revCam.count();
        camStop();
        return n;
      },
    };
  }
  function camStop() {
    cam.stream?.getTracks().forEach((t) => t.stop());
    cam.stream = null;
    $('dw-cam-v').srcObject = null;
    card('cam').classList.remove('live');
    $('dw-cam-btn').textContent = 'Kamera an';
  }
  $('dw-cam-btn').addEventListener('click', async () => {
    if (cam.stream) return camStop();
    try {
      cam.stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360 } });
    } catch {
      $('dw-cam-off').textContent = 'Keine Kamera gefunden';
      return;
    }
    $('dw-cam-v').srcObject = cam.stream;
    $('dw-cam-v').play().catch(() => {});
    card('cam').classList.add('live');
    $('dw-cam-btn').textContent = 'Aus';
  });

  /* ------------------------------------------------------------ Soundboard (synthetisch, ohne Dateien) */
  let sctx = null;
  const ac = () => (sctx ||= new AudioContext());
  function noise(c, dur) {
    const b = c.createBuffer(1, c.sampleRate * dur, c.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource();
    s.buffer = b;
    return s;
  }
  function env(c, node, t, a, dur, peak = 0.8) {
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    node.connect(g).connect(c.destination);
    return g;
  }
  const PADS = [
    ['🥁', 'Kick', (c, t) => { const o = c.createOscillator(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.4); env(c, o, t, 0.005, 0.45, 1); o.start(t); o.stop(t + 0.5); }],
    ['👏', 'Klatsch', (c, t) => { for (let i = 0; i < 3; i++) { const n = noise(c, 0.2); const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1400; n.connect(f); env(c, f, t + i * 0.012, 0.002, 0.18, 0.7); n.start(t + i * 0.012); } }],
    ['📯', 'Horn', (c, t) => { for (const fr of [440, 554, 659]) { const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = fr; env(c, o, t, 0.03, 1.1, 0.18); o.start(t); o.stop(t + 1.2); } }],
    ['🔔', 'Ding', (c, t) => { for (const [fr, v] of [[1320, 0.4], [2640, 0.15]]) { const o = c.createOscillator(); o.frequency.value = fr; env(c, o, t, 0.004, 1.4, v); o.start(t); o.stop(t + 1.5); } }],
    ['🌀', 'Boing', (c, t) => { const o = c.createOscillator(); o.type = 'triangle'; o.frequency.setValueAtTime(180, t); o.frequency.exponentialRampToValueAtTime(700, t + 0.25); o.frequency.exponentialRampToValueAtTime(260, t + 0.6); env(c, o, t, 0.01, 0.65, 0.6); o.start(t); o.stop(t + 0.7); }],
    ['💥', 'Boom', (c, t) => { const n = noise(c, 1.2); const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(60, t + 1.1); n.connect(f); env(c, f, t, 0.005, 1.15, 1); n.start(t); }],
    ['🎺', 'Fail', (c, t) => { [392, 370, 349, 330].forEach((fr, i) => { const o = c.createOscillator(); o.type = 'square'; o.frequency.value = fr; env(c, o, t + i * 0.32, 0.02, i === 3 ? 0.9 : 0.3, 0.12); o.start(t + i * 0.32); o.stop(t + i * 0.32 + (i === 3 ? 0.95 : 0.32)); }); }],
    ['✨', 'Tada', (c, t) => { [523, 659, 784, 1047].forEach((fr, i) => { const o = c.createOscillator(); o.type = 'triangle'; o.frequency.value = fr; env(c, o, t + i * 0.07, 0.01, 0.9, 0.25); o.start(t + i * 0.07); o.stop(t + 1.1); }); }],
  ];
  $('dw-pads').innerHTML = PADS.map(([e, n], i) => `<button data-pad="${i}" title="${n}"><span>${e}</span><small>${n}</small></button>`).join('');
  $('dw-pads').addEventListener('click', (e) => {
    const b = e.target.closest('[data-pad]');
    if (!b) return;
    const c = ac();
    c.resume?.();
    PADS[Number(b.dataset.pad)][2](c, c.currentTime + 0.01);
    b.classList.remove('hit');
    void b.offsetWidth;
    b.classList.add('hit');
  });

  /* ------------------------------------------------------------ Schnellzugriff */
  async function paintQuick() {
    if (!shown('quick') || !window.hub.quick) return;
    const list = await window.hub.quick.list().catch(() => []);
    $('dw-quick-list').innerHTML = list.length
      ? list.map((f, i) => `<button class="dw-q ${f.missing ? 'gone' : ''}" data-q="${i}" title="${esc(f.path)}\nKlick: öffnen · Rechtsklick: entfernen"><span>${f.dir ? '📁' : /\.(png|jpe?g|gif|webp)$/i.test(f.name) ? '🖼️' : /\.(mp3|wav|ogg|flac)$/i.test(f.name) ? '🎵' : /\.(mp4|mov|mkv)$/i.test(f.name) ? '🎬' : /\.(pdf|docx?|txt)$/i.test(f.name) ? '📄' : '📦'}</span><b>${esc(f.name)}</b></button>`).join('')
      : '<div class="dw-empty">Dateien hierher ziehen oder + drücken</div>';
  }
  $('dw-quick-add').addEventListener('click', () => window.hub.quick?.pick().then(paintQuick).catch(() => {}));
  $('dw-quick-list').addEventListener('click', (e) => {
    const b = e.target.closest('[data-q]');
    if (b) window.hub.quick.open(Number(b.dataset.q)).catch(() => {});
  });
  $('dw-quick-list').addEventListener('contextmenu', (e) => {
    const b = e.target.closest('[data-q]');
    if (!b || e.ctrlKey) return;
    e.preventDefault();
    e.stopPropagation();
    window.hub.quick.remove(Number(b.dataset.q)).then(paintQuick).catch(() => {});
  });
  const qc = card('quick');
  qc.addEventListener('dragover', (e) => {
    e.preventDefault();
    qc.classList.add('over');
  });
  qc.addEventListener('dragleave', () => qc.classList.remove('over'));
  qc.addEventListener('drop', (e) => {
    e.preventDefault();
    qc.classList.remove('over');
    const paths = [...(e.dataTransfer?.files || [])].map((f) => window.hub.quick.pathOf(f)).filter(Boolean);
    if (paths.length) window.hub.quick.add(paths).then(paintQuick).catch(() => {});
  });
  // Ohne das würde Electron eine Datei, die daneben fällt, als Seite öffnen
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => e.preventDefault());

  /* ------------------------------------------------------------ Steuerung */
  function refresh() {
    paintUptime();
    paintTodo();
    if (shown('plant')) drawPlant();
    paintQuick();
    if (!shown('mic') && mic.stream) micStop();
    if (!shown('cam') && cam.stream) camStop();
  }
  window.addEventListener('dw-extra', refresh);
  window.addEventListener('storage', (e) => {
    if (e.key === 'dw-notes' && document.activeElement !== notes) notes.value = load('dw-notes', '');
    if (e.key === 'dw-todo') paintTodo();
    if (e.key === 'dw-plant' && shown('plant')) drawPlant();
  });
  setInterval(() => {
    if (document.hidden) return;
    paintUptime();
    if (shown('plant')) drawPlant();
  }, 60000);
  window.hub.onWidgetsPause?.((on) => on && (micStop(), camStop()));
  refresh();
})();
