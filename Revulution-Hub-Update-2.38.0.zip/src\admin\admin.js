'use strict';

/* Revulution Admin: Einsendungen prüfen, Community-Hintergründe, Meldungen, lokale Bilder. */
(() => {
  const $ = (sel) => document.querySelector(sel);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const when = (at) => (at ? new Date(at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '–');
  const st = { tab: 'pending', acct: null, pending: null, public: null, local: null, filter: 'open', busy: false, rules: '', email: '' };

  let toastTimer = 0;
  function toast(msg, error = false) {
    const el = $('#toast');
    el.textContent = msg;
    el.className = `toast show${error ? ' error' : ''}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.className = 'toast'), 3400);
  }
  const fail = (e) => toast(String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), true);

  async function load(what) {
    try {
      if (what === 'pending' && st.acct?.signedIn) st.pending = await window.admin.cloud.pending();
      if (what === 'public') st.public = await window.admin.cloud.public();
      if (what === 'local') st.local = await window.admin.status();
    } catch (e) {
      fail(e);
      if (what === 'pending') st.pending = st.pending || [];
      if (what === 'public') st.public = st.public || [];
    }
    render();
  }

  const META = {
    pending: ['CLOUD', 'Einsendungen', 'Hintergründe, die Nutzer im Hub eingereicht haben.'],
    public: ['CLOUD', 'Community', 'Freigegebene Hintergründe – alle sehen sie im Hub.'],
    reports: ['LOKAL', 'Meldungen', 'Bugs, Reports und Ideen aus dem Hub.'],
    local: ['LOKAL', 'Lokale Hintergründe', 'Bilder in der lokalen Datenbank dieses PCs.'],
    setup: ['EINMALIG', 'Einrichten', 'Anmeldung und Firestore-Regeln für die Cloud.'],
    sales: ['STORE', 'Käufe & Geschenke', 'Alle Coin-Käufe, Artikel und Spenden – und Coins oder Designs verschenken.'],
  };

  function loginHtml() {
    if (st.acct?.needCode)
      return `<div class="login"><h2>Zwei-Faktor-Code</h2><p>6-stelliger Code aus deiner Authenticator-App.</p><input class="input" id="code" inputmode="numeric" maxlength="7" placeholder="123 456" autofocus /><button class="btn primary" data-act="code">Bestätigen</button></div>`;
    return `<div class="login"><h2>Mit deinem Revulution-Konto anmelden</h2><p>Nur das Admin-Konto darf Einsendungen sehen und freigeben.</p>
      <input class="input" id="email" type="email" placeholder="E-Mail" value="${esc(st.email)}" />
      <input class="input" id="pw" type="password" placeholder="Passwort" />
      <button class="btn primary" data-act="login">Anmelden</button></div>`;
  }

  function cardHtml(b, kind) {
    const acts =
      kind === 'pending'
        ? `<button class="btn primary" data-approve="${esc(b.id)}">Annehmen</button><button class="btn ghost-red" data-reject="${esc(b.id)}">Ablehnen</button>`
        : kind === 'public'
          ? `<button class="btn ghost-red" data-unpublish="${esc(b.id)}">Entfernen</button>`
          : `<button class="btn" data-desktop="${esc(b.id)}">Als Desktop</button><button class="btn ghost-red" data-remove="${esc(b.id)}">Löschen</button>`;
    const img = b.img || b.data;
    return `<div class="card">${img ? `<img src="${img}" alt="" />` : '<img alt="" />'}
      <div class="meta">${kind === 'pending' ? `<input class="input" data-name="${esc(b.id)}" value="${esc(b.name)}" maxlength="60" />` : `<b>${esc(b.name)}</b>`}<small>${esc(b.by || 'Admin')} · ${when(b.at)}${kind === 'local' ? ` · ${b.downloads || 0} Downloads` : ''}</small></div>
      <div class="acts">${acts}</div></div>`;
  }

  function reportHtml(r) {
    const type = r.type === 'idea' ? 'Idee' : r.type === 'report' ? 'Report' : 'Bug';
    return `<div class="report ${r.status === 'done' ? 'done' : ''}"><div class="r-main"><div class="r-head"><span class="tag ${esc(r.type || 'bug')}">${type}</span><b>${esc(r.app || 'Revulution Hub')}</b><small>${when(r.at)} · ${esc(r.by || 'Nutzer')}</small></div><p>${esc(r.text)}</p></div>
      <button class="btn" data-toggle="${esc(r.id)}">${r.status === 'done' ? 'Öffnen' : 'Erledigt'}</button></div>`;
  }

  function salesHtml() {
    if (!st.acct?.signedIn) return loginHtml();
    if (!st.sales) {
      st.sales = 'loading';
      window.admin.sales().then((r) => { st.sales = r; render(); }).catch((e) => { st.sales = { error: String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '') }; render(); });
    }
    const items = Object.entries(window.RevCos?.COSMETICS || {}).flatMap(([slot, list]) => list.filter((it) => it.coins).map((it) => `${slot}/${it.id}`));
    const kind = { coins: 'Coins gekauft', item: 'Artikel', daily: 'Tagesbonus', donation: 'Spende', gift: 'Geschenk' };
    const list = st.sales === 'loading' ? '<div class="empty">LÄDT …</div>' : st.sales?.error ? `<div class="empty">${esc(st.sales.error)}</div>` : !st.sales.length ? '<div class="empty">NOCH KEINE KÄUFE</div>'
      : `<table class="sales"><thead><tr><th>Wann</th><th>Wer</th><th>Was</th><th>Coins</th><th>Betrag</th><th>Status</th></tr></thead><tbody>${st.sales
          .map((r) => `<tr><td>${when(r.at)}</td><td>${esc(r.who)}</td><td>${esc(kind[r.kind] || r.kind)}${r.item ? ` · ${esc(r.item)}` : ''}</td><td class="${(r.coins || 0) < 0 ? 'neg' : 'pos'}">${r.coins ? (r.coins > 0 ? '+' : '') + r.coins : ''}</td><td>${r.amount ? `CHF ${(r.amount / 100).toFixed(2)}` : ''}</td><td>${esc(r.status || '')}</td></tr>`)
          .join('')}</tbody></table>`;
    return `<div class="gift"><h3>Verschenken</h3>
        <input class="input" id="g-email" placeholder="E-Mail des Kontos" />
        <input class="input" id="g-coins" inputmode="numeric" placeholder="Coins (optional)" />
        <input class="input" id="g-item" list="g-items" placeholder="Artikel (optional), z. B. effect/dotburst" />
        <datalist id="g-items">${items.map((i) => `<option value="${esc(i)}"></option>`).join('')}</datalist>
        <button class="btn primary" data-act="gift">Verschenken</button></div>${list}`;
  }

  function bodyHtml() {
    const t = st.tab;
    if (t === 'sales') return salesHtml();
    if (t === 'pending') {
      if (!st.acct?.signedIn) return loginHtml();
      if (!st.pending) return (load('pending'), '<div class="empty">LÄDT …</div>');
      return st.pending.length ? `<div class="grid">${st.pending.map((b) => cardHtml(b, 'pending')).join('')}</div>` : '<div class="empty">KEINE NEUEN EINSENDUNGEN</div>';
    }
    if (t === 'public') {
      if (!st.public) return (load('public'), '<div class="empty">LÄDT …</div>');
      return st.public.length ? `<div class="grid">${st.public.map((b) => cardHtml(b, 'public')).join('')}</div>` : '<div class="empty">NOCH NICHTS FREIGEGEBEN</div>';
    }
    if (t === 'reports' || t === 'local') {
      if (!st.local) return (load('local'), '<div class="empty">LÄDT …</div>');
      if (t === 'local') return st.local.backgrounds.length ? `<div class="grid">${st.local.backgrounds.map((b) => cardHtml(b, 'local')).join('')}</div>` : '<div class="empty">KEINE LOKALEN HINTERGRÜNDE</div>';
      const list = st.local.reports.filter((r) => st.filter === 'all' || (st.filter === 'done' ? r.status === 'done' : r.status !== 'done'));
      return `<div class="filters">${[['open', 'Offen'], ['done', 'Erledigt'], ['all', 'Alle']].map(([v, n]) => `<button class="${st.filter === v ? 'on' : ''}" data-filter="${v}">${n}</button>`).join('')}</div>
        <div class="reports">${list.length ? list.map(reportHtml).join('') : '<div class="empty">ALLES ERLEDIGT</div>'}</div>`;
    }
    // Einrichten
    if (!st.rules) window.admin.cloud.rules().then((r) => ((st.rules = r), render()));
    return `<div class="setup">${st.acct?.signedIn ? '' : loginHtml()}
      <p>Damit Nutzer einreichen und alle die Community-Bilder sehen können, kommen diese Regeln einmal in Firebase dazu:</p>
      <ol><li>Firebase-Konsole → Projekt <code>revolutionhub-56a80</code> → Firestore → <b>Regeln</b></li><li>Den Block unten <b>innerhalb</b> von <code>match /databases/{database}/documents { … }</code> einfügen</li><li><b>Veröffentlichen</b> drücken</li></ol>
      <pre>${esc(st.rules || '…')}</pre>
      <div><button class="btn primary" data-act="copy-rules">Regeln kopieren</button></div>
      ${st.acct?.uid ? `<p class="muted">Deine Admin-UID: <code>${esc(st.acct.uid)}</code></p>` : '<p>Melde dich zuerst an – dann steht deine UID schon richtig in den Regeln.</p>'}</div>`;
  }

  function render() {
    const [eyebrow, title, sub] = META[st.tab];
    $('#eyebrow').textContent = eyebrow;
    $('#title').textContent = title;
    $('#sub').textContent = sub;
    document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === st.tab));
    $('#n-pending').textContent = st.pending?.length ?? '–';
    $('#n-public').textContent = st.public?.length ?? '–';
    $('#n-reports').textContent = st.local ? st.local.reports.filter((r) => r.status !== 'done').length : '–';
    $('#n-local').textContent = st.local?.backgrounds.length ?? '–';
    const acts = { pending: st.acct?.signedIn ? '<button class="btn" data-act="reload">Aktualisieren</button>' : '', public: `<button class="btn" data-act="reload">Aktualisieren</button>${st.acct?.signedIn ? '<button class="btn primary" data-act="publish">Bilder veröffentlichen</button>' : ''}`, local: '<button class="btn" data-act="open-data">Datenordner</button><button class="btn primary" data-act="add-local">Bilder hinzufügen</button>', reports: '<button class="btn" data-act="reload">Aktualisieren</button>', sales: '<button class=\"btn\" data-act=\"reload\">Aktualisieren</button>', sales: '<button class="btn" data-act="reload">Aktualisieren</button>', setup: '' };
    $('#head-actions').innerHTML = acts[st.tab] || '';
    $('#who').innerHTML = st.acct?.signedIn ? `<span>Angemeldet als</span><b>${esc(st.acct.email)}</b><button class="btn" data-act="logout">Abmelden</button>` : '<span>Nicht angemeldet</span><span class="muted">Cloud-Funktionen brauchen dein Konto.</span>';
    $('#body').innerHTML = bodyHtml();
  }

  async function busy(fn) {
    if (st.busy) return;
    st.busy = true;
    document.body.style.cursor = 'progress';
    try {
      await fn();
    } catch (e) {
      fail(e);
    } finally {
      st.busy = false;
      document.body.style.cursor = '';
    }
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest?.('button');
    if (!b) return;
    const d = b.dataset;
    if (d.tab) {
      st.tab = d.tab;
      return render();
    }
    if (d.filter) {
      st.filter = d.filter;
      return render();
    }
    busy(async () => {
      if (d.act === 'gift') {
        const r = await window.admin.gift({ email: $('#g-email')?.value || '', coins: Number($('#g-coins')?.value) || 0, item: $('#g-item')?.value || '' });
        toast(`Verschenkt – Kontostand jetzt ${r.coins} Coins.`);
        st.sales = null;
        return render();
      }
      if (d.act === 'login') {
        st.email = $('#email')?.value || '';
        st.acct = await window.admin.cloud.login(st.email, $('#pw')?.value || '');
        if (st.acct.signedIn) toast('Angemeldet.');
        st.pending = null;
        st.rules = '';
      } else if (d.act === 'code') {
        st.acct = await window.admin.cloud.code($('#code')?.value || '');
        st.pending = null;
        st.rules = '';
        toast('Angemeldet.');
      } else if (d.act === 'logout') {
        st.acct = await window.admin.cloud.logout();
        st.pending = null;
        st.rules = '';
      } else if (d.act === 'reload') {
        st[st.tab === 'reports' ? 'local' : st.tab] = null;
      } else if (d.act === 'publish') {
        const n = await window.admin.cloud.publish();
        if (n) toast(`${n} Bild${n === 1 ? '' : 'er'} veröffentlicht.`);
        st.public = null;
      } else if (d.act === 'copy-rules') {
        await window.admin.copy(st.rules);
        toast('Regeln kopiert.');
      } else if (d.act === 'open-data') {
        await window.admin.openData();
      } else if (d.act === 'add-local') {
        const files = await window.admin.pick();
        for (const f of files) await window.admin.add(f, String(f).split(/[\\/]/).pop().replace(/\.[^.]+$/, ''));
        if (files.length) toast(`${files.length} Bild${files.length === 1 ? '' : 'er'} hinzugefügt.`);
        st.local = null;
      } else if (d.approve) {
        const name = document.querySelector(`[data-name="${CSS.escape(d.approve)}"]`)?.value || '';
        await window.admin.cloud.approve(d.approve, name);
        toast('Freigegeben – jetzt für alle sichtbar.');
        st.pending = st.pending.filter((x) => x.id !== d.approve);
        st.public = null;
      } else if (d.reject) {
        await window.admin.cloud.reject(d.reject);
        toast('Abgelehnt.');
        st.pending = st.pending.filter((x) => x.id !== d.reject);
      } else if (d.unpublish) {
        if (!window.confirm('Diesen Hintergrund für alle entfernen?')) return;
        await window.admin.cloud.unpublish(d.unpublish);
        st.public = st.public.filter((x) => x.id !== d.unpublish);
        toast('Entfernt.');
      } else if (d.desktop) {
        await window.admin.desktop(d.desktop);
        toast('Desktop-Hintergrund gesetzt.');
      } else if (d.remove) {
        if (!window.confirm('Lokalen Hintergrund löschen?')) return;
        await window.admin.remove(d.remove);
        st.local = null;
      } else if (d.toggle) {
        const r = st.local?.reports.find((x) => x.id === d.toggle);
        await window.admin.reportStatus(d.toggle, r?.status === 'done' ? 'open' : 'done');
        st.local = null;
      } else return;
      render();
    });
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'pw' || e.target.id === 'email') document.querySelector('[data-act="login"]')?.click();
    if (e.target.id === 'code') document.querySelector('[data-act="code"]')?.click();
  });

  window.admin.cloud.state().then((s) => {
    st.acct = s;
    render();
  });
  render();
})();
