'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.33.0',
  title: 'Revulution Hub 2.33',
  sub: 'Neuer Revolution Store, Premium-Widgets, scharfe Hintergründe und eine neue Island-Form.',
  items: [
    { open: 'tool-store', icon: 'spark', title: 'Revolution Store neu', text: 'Der alte Shop ist jetzt im Store. Klarer aufgebaut, viel mehr Designs für Profil, Schach, Dynamic Island und Tastatur – mit ◆ Punkten oder Coins. „Anprobieren“ zeigt die echte Animation.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Premium-Widgets', text: 'Trading mit Live-Kursen und Mini-Chart, Stream-Chat für TikTok und Twitch – auf dem Desktop oder als Overlay über Spielen.' },
    { open: 'tool-desktop', icon: 'resize', title: 'Widgets anpassen', text: 'Strg + Rechtsklick auf ein Widget öffnet sein Menü (ausblenden, Größe), Strg + Scrollen ändert die Größe. Eigene Akzentfarbe statt Rot, neues Punkt-Wetter-Widget.' },
    { open: 'tool-keyboard', icon: 'keyboard', title: 'Tastatur-Displays', text: 'Neue animierte Displays für die AJAZZ. Display und LEDs laden nicht mehr alle paar Minuten neu.' },
    { open: 'orbit', icon: 'island', title: 'Dynamic Island', text: 'Sitzt jetzt wie eine echte Notch oben am Rand, ohne die Text-Knöpfe. Live-Spielstände mit Logos, Stand und Minute.' },
    { open: 'tool-backgrounds', icon: 'image', title: 'Scharfe Hintergründe', text: 'Hintergründe werden wieder in voller Auflösung gesetzt statt als kleines Vorschaubild.' },
    { open: 'tool-airplay', icon: 'camera', title: 'iPhone spiegeln', text: 'Das Empfänger-Fenster bleibt versteckt, dein iPhone sieht nur den PC-Namen. Spiegeln klappt jetzt in der App – rund, eckig oder als iPhone-Widget auf dem Desktop.' },
    { open: 'home', icon: 'search', title: 'Bessere App-Suche', text: 'Findet Apps auch bei Tippfehlern und mit Begriffen wie „Musik“, „Shop“ oder „Kalender“. Neuer Kalender auf der Startseite, schlankeres Dock.' },
  ],
};
