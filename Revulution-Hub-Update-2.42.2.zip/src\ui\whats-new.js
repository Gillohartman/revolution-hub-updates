'use strict';
/* â€žWas ist neuâ€œ: nur die Neuerungen dieser Version â€“ Ã¤ltere EintrÃ¤ge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.42.2',
  title: 'Revulution Hub 2.42.2',
  sub: 'KlÃ¼gerer Schach-Bot, Support-Seite, Regenwolke fÃ¼r die Pflanze und neue Erfolge.',
  items: [
    { open: 'chess', icon: 'chess', title: 'Schach', text: 'Die KI opfert keine Figuren mehr sinnlos und rechnet tiefer. Der Coach sagt viel mehr verschiedene SÃ¤tze und erklÃ¤rt Fehler sofort. Neu: Training, Simulieren (freies Brett, Live-Partien zusehen) und das RÃ¤tsel des Tages.' },
    { open: 'tool-support', icon: 'chat', title: 'Support', text: 'Oben neben dem Zahnrad: Feedback geben, Bugs melden oder Hilfe holen â€“ mit Bildschirmfoto. HintergrÃ¼nde meldest du direkt beim Wallpaper.' },
    { open: 'tool-desktop', icon: 'grid', title: 'Pflanze mit Regenwolke', text: 'Statt GieÃŸkanne: Klick auf die Wolke, sobald sie grau ist â€“ es regnet. Pflanze, Notizen und To-dos bleiben jetzt auch nach einem Neustart erhalten.' },
    { open: 'tool-achievements', icon: 'spark', title: 'Mehr Erfolge', text: 'Neu: Am StÃ¼ck, Nachteule, FrÃ¼haufsteher, Turbo-Leitung und Modder â€“ mit deinem Profilbild.' },
    { open: 'orbit', icon: 'calendar', title: 'Island', text: 'Der Countdown-Ring fÃ¼r den nÃ¤chsten Termin ist jetzt auch links in der kleinen Island.' },
    { open: 'home', icon: 'layers', title: 'Design', text: 'Titel oben als runde Pille (Klick zeigt die Beschreibung), alle KnÃ¶pfe und Felder ganz rund.' },
  ],
};
