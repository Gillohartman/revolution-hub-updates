'use strict';

/*
 * Desktop: die Taskleisten-App als eigene Seite. Uhr, Systemwerte,
 * Schnellzugriffe und der Umschalter für die Revulution-Leiste.
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const ctx = () => T.ctx();
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const icon = (n, s) => window.icon(n, s);
  const pc = { live: null, busy: false };

  const fmtTime = () => new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const fmtDay = () => new Date().toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
  const pct = (v) => (v == null || Number.isNaN(Number(v)) ? '–' : `${Math.round(Number(v))} %`);

  function paintClock() {
    const time = document.getElementById('desk-time');
    if (time) time.textContent = fmtTime();
    const day = document.getElementById('desk-day');
    if (day) day.textContent = fmtDay();
  }

  function paintSystem() {
    const l = pc.live;
    if (!l) return;
    const rows = [['cpu', l.cpu], ['ram', l.ramPct], ['gpu', l.gpu]];
    for (const [key, value] of rows) {
      const out = document.querySelector(`[data-desk-pc="${key}"]`);
      if (out) out.textContent = pct(value);
      const bar = document.querySelector(`[data-desk-bar="${key}"]`);
      if (bar) bar.style.width = `${Math.max(0, Math.min(100, Number(value) || 0))}%`;
    }
  }

  async function loadSystem() {
    if (pc.busy) return;
    pc.busy = true;
    try {
      pc.live = await window.hub.pcLive();
      paintSystem();
    } catch {
      /* Werte bleiben beim letzten Stand */
    }
    pc.busy = false;
  }

  function desktopHtml() {
    const replace = Boolean(ctx().state()?.settings?.replaceTaskbar);
    return `<div class="desk-grid">
      <section class="desk-widget desk-clock">
        <div><div class="tool-label">Jetzt</div><time id="desk-time">${fmtTime()}</time><div class="desk-day" id="desk-day">${esc(fmtDay())}</div></div>
        <small>Revulution Desktop · ${replace ? 'Revulution-Leiste aktiv' : 'Windows-Taskleiste aktiv'}</small>
      </section>
      <section class="desk-widget desk-system">
        <div class="list-row" style="padding:0"><div class="tool-label">System</div><small class="muted">live</small></div>
        ${[['cpu', 'Prozessor'], ['ram', 'Arbeitsspeicher'], ['gpu', 'Grafikkarte']].map(([key, name]) => `<div class="desk-file"><span>${esc(name)}</span><b data-desk-pc="${key}">–</b><div class="desk-bar"><i data-desk-bar="${key}" style="width:0%"></i></div></div>`).join('')}
      </section>
      <section class="desk-widget">
        <div class="tool-label">Schnellzugriff</div>
        <div class="desk-actions">
          <button class="desk-action" data-desk-open="control">${icon('control', 18)}<b>Kontrollzentrum</b></button>
          <button class="desk-action" data-desk-open="settings">${icon('settings', 18)}<b>Einstellungen</b></button>
          <button class="desk-action" data-desk-open="home">${icon('grid', 18)}<b>Alle Apps</b></button>
          <button class="desk-action" data-desk-action="lock">${icon('shield', 18)}<b>PC sperren</b></button>
        </div>
      </section>
      <section class="desk-widget desk-taskbar">
        <div class="grow"><div class="tool-label">Taskleiste</div><b>Revulution-Leiste</b><small>Ersetzt die Windows-Taskleiste am unteren Rand.</small></div>
        <button class="switch ${replace ? 'on' : ''}" data-desk-taskbar title="Revulution-Leiste ein- oder ausschalten"></button>
        <div class="desk-preview" aria-hidden="true"><i>R</i><i>K</i><i>E</i><span></span><em>${fmtTime()}</em></div>
      </section>
    </div>`;
  }

  document.addEventListener('click', (e) => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    const open = e.target.closest?.('[data-desk-open]');
    if (open) return window.hub.open(open.dataset.deskOpen).catch(() => {});
    if (e.target.closest?.('[data-desk-action="lock"]')) return window.hub.cc.lock().catch(() => {});
    if (e.target.closest?.('[data-desk-taskbar]')) {
      const on = !ctx().state()?.settings?.replaceTaskbar;
      return window.hub.taskbar.replace(on).then(() => ctx().toast(on ? 'Revulution-Leiste übernimmt.' : 'Windows-Taskleiste ist wieder da.')).catch(() => {});
    }
  });

  setInterval(() => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    paintClock();
    const previewTime = document.querySelector('.desk-preview em');
    if (previewTime) previewTime.textContent = fmtTime();
  }, 1000);
  setInterval(() => {
    if (ctx().state()?.active === 'tool-desktop') loadSystem();
  }, 6000);

  T.register(
    'tool-desktop',
    {
      nav: 'Desktop',
      title: 'Desktop',
      sub: 'Deine Taskleiste als App',
      icon: 'home',
      tint: 'linear-gradient(135deg,#e5e7eb,#6b7280)',
      desc: 'Uhr, Systemwerte, Schnellzugriffe und die Revulution-Leiste an einem Ort.',
    },
    desktopHtml,
  );

  // Beim ersten Öffnen die Livewerte holen und die Uhr direkt stellen.
  const base = T.html;
  T.html = (id) => {
    const html = base(id);
    if (id === 'tool-desktop') setTimeout(() => { paintClock(); if (pc.live) paintSystem(); loadSystem(); }, 0);
    return html;
  };
})();