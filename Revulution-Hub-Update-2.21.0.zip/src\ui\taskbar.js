'use strict';

/*
 * Obere Leiste: das R-Logo, die angehefteten/laufenden Apps der echten
 * Windows-Taskleiste und rechts die Hub-Kontrollen. Alles schwarz, die Leiste
 * selbst transparent. Das Windows-Popup hängt als kleine Karte unter dem Logo.
 */
(() => {
  const $ = (selector) => document.querySelector(selector);
  const esc = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

  let state = null;
  let clockTimer = 0;
  let lastKey = '';
  let drawerWasOpen = false;
  let interactive = null;

  function setInteractive(on) {
    if (on === interactive) return;
    interactive = on;
    window.hub.taskbar?.interactive?.(on).catch(() => {});
  }

  const windowsApps = () => (state?.windowsApps || []).slice(0, 18);

  function clockHtml() {
    return '<span class="tb-clock-time" data-clock-time>--:--</span><span class="tb-clock-date" data-clock-date>Revulution</span>';
  }

  function fallback(name) {
    return `<span class="tb-win-fallback">${esc(String(name || '?').slice(0, 1).toUpperCase())}</span>`;
  }

  function appButton(item) {
    const label = item.title || item.name;
    return `<button class="tb-winbtn" data-winapp="${esc(item.id)}" title="${esc(label)}">
      ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
      ${item.kind === 'running' ? '<i class="tb-running"></i>' : ''}
    </button>`;
  }

  const windowsMark = () => `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3 5.2 10.4 4v7.2H3zm8.6-1.35L21 2.6v8.6h-9.4zM3 12.8h7.4V20L3 18.8zm8.6 0H21v8.8l-9.4-1.25z"/></svg>`;

  function barHtml() {
    return `<div class="tb-bar">
      <button class="tb-logo ${state?.drawer ? 'is-open' : ''}" data-act="drawer" title="Desktop · Apps und Widgets">
        ${windowsMark()}
      </button>
      <span class="tb-divider"></span>
      <div class="tb-apps">${windowsApps().map(appButton).join('')}</div>
      <div class="tb-right">
        <button class="tb-iconbtn" data-act="control" title="Kontrollzentrum">${window.icon('control', 15)}</button>
        <button class="tb-iconbtn tb-power" data-act="quit" title="Revulution Hub beenden">${window.icon('power', 15)}</button>
        <button class="tb-iconbtn" data-act="settings" title="Einstellungen">${window.icon('settings', 15)}${state?.dnd ? '<i class="tb-dot"></i>' : ''}</button>
        <span class="tb-divider"></span>
        <button class="tb-clock" data-act="agenda" title="Agenda">${clockHtml()}</button>
      </div>
    </div>`;
  }

  function drawerGrid(query = '') {
    const q = String(query || '').trim().toLocaleLowerCase('de');
    const items = windowsApps().filter((item) => !q || String(item.title || item.name).toLocaleLowerCase('de').includes(q));
    if (!items.length) {
      return `<p class="drawer-empty">${state?.windowsApps ? 'Keine App gefunden.' : 'Windows-Apps werden geladen …'}</p>`;
    }
    return items
      .map(
        (item) =>
          `<button class="drawer-item" data-winapp="${esc(item.id)}" title="${esc(item.title || item.name)}">
            ${item.icon ? `<img src="${esc(item.icon)}" alt="" draggable="false" />` : fallback(item.name)}
            <b>${esc(item.name)}</b>
          </button>`,
      )
      .join('');
  }

  function drawerHtml() {
    return `<div class="tb-pop" role="dialog" aria-label="Windows-Apps">
      <section class="tb-drawer">
        <header class="drawer-head">
          <div class="drawer-title"><b>Desktop</b><span>Apps, Fenster & Widgets</span></div>
          <label class="drawer-search">${window.icon('search', 13)}<input type="text" placeholder="Durchsuchen" data-drawer-search autocomplete="off" spellcheck="false" /></label>
          <button class="drawer-close" data-act="drawer" title="Schließen">${window.icon('close', 13)}</button>
        </header>
        <div class="drawer-grid" data-drawer-grid>${drawerGrid()}</div>
        <footer class="drawer-foot">
          <button class="drawer-action" data-act="home">${window.icon('home', 13)} Revulution Hub</button>
          <button class="drawer-action" data-act="desktop">${window.icon('grid', 13)} Desktop</button>
          <button class="drawer-action" data-act="control">${window.icon('control', 13)} Kontrollzentrum</button>
          <button class="drawer-action" data-act="settings">${window.icon('settings', 13)} Einstellungen</button>
          <button class="drawer-action danger" data-act="lock">${window.icon('shield', 13)} Sperren</button>
        </footer>
      </section>
    </div>`;
  }

  function render() {
    if (!state) return;
    const drawer = Boolean(state.drawer);
    document.body.classList.toggle('drawer-open', drawer);
    document.title = 'Revulution Leiste';
    const key = JSON.stringify({ drawer, windowsApps: state.windowsApps, badges: state.badges, dnd: state.dnd });
    if (key === lastKey) return tickClock();
    lastKey = key;
    $('#tb').innerHTML = barHtml() + drawerHtml();
    tickClock();
    startClock();
    if (drawer && !drawerWasOpen) {
      setTimeout(() => $('#tb')?.querySelector('[data-drawer-search]')?.focus(), 200);
    }
    drawerWasOpen = drawer;
  }

  function locale() {
    return state?.lang === 'en' ? 'en-GB' : state?.lang === 'es' ? 'es-ES' : 'de-DE';
  }

  function tickClock() {
    const now = new Date();
    const time = now.toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' });
    const date = now.toLocaleDateString(locale(), { weekday: 'short', day: 'numeric', month: 'short' });
    document.querySelectorAll('[data-clock-time]').forEach((el) => { el.textContent = time; });
    document.querySelectorAll('[data-clock-date]').forEach((el) => { el.textContent = date; });
  }

  function startClock() {
    clearInterval(clockTimer);
    clockTimer = setInterval(tickClock, 15000);
  }

  function pulse(button) {
    if (!button) return;
    button.classList.remove('pressed');
    void button.offsetWidth;
    button.classList.add('pressed');
    setTimeout(() => button.classList.remove('pressed'), 200);
  }

  function closeDrawer() {
    if (state?.drawer) window.hub.taskbar?.drawer?.(false).catch(() => {});
  }

  document.addEventListener('input', (event) => {
    if (event.target.matches('[data-drawer-search]')) {
      const grid = $('[data-drawer-grid]');
      if (grid) grid.innerHTML = drawerGrid(event.target.value);
    }
  });

  document.addEventListener('click', (event) => {
    const winApp = event.target.closest('[data-winapp]');
    if (winApp) {
      pulse(winApp);
      closeDrawer();
      window.hub.taskbar?.launch?.(winApp.dataset.winapp).catch(() => {});
      return;
    }
    const action = event.target.closest('[data-act]');
    if (!action) return;
    pulse(action);
    const act = action.dataset.act;
    if (act === 'drawer') return window.hub.taskbar?.drawer?.(!state?.drawer).catch(() => {});
    if (act === 'home') { closeDrawer(); return window.hub.open('home').catch(() => {}); }
    if (act === 'desktop') { closeDrawer(); return window.hub.open('tool-desktop').catch(() => {}); }
    if (act === 'control') { closeDrawer(); return window.hub.openControl?.().catch(() => {}); }
    if (act === 'settings') { closeDrawer(); return window.hub.openSettings?.().catch(() => {}); }
    if (act === 'quit') {
      closeDrawer();
      if (window.confirm('Revulution Hub und alle laufenden Aufgaben beenden?')) window.hub.quit?.().catch(() => {});
      return;
    }
    if (act === 'agenda') { closeDrawer(); return window.hub.open('agenda').catch(() => {}); }
    if (act === 'lock') { closeDrawer(); return window.hub.cc?.lock?.().catch(() => {}); }
  });

  document.addEventListener('contextmenu', (event) => {
    const app = event.target.closest?.('[data-winapp]');
    if (!app) return;
    event.preventDefault();
    window.hub.taskbar?.context?.(app.dataset.winapp).catch(() => {});
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeDrawer();
  });

  /* Die Leiste ist oben volle Breite, das Popup nur eine kleine Karte. Der
     transparente Rest des Fensters darf keine Klicks auf den Desktop schlucken. */
  document.addEventListener('mousemove', (event) => {
    const hit = document.elementFromPoint(event.clientX, event.clientY);
    setInteractive(Boolean(hit?.closest('.tb-bar, .tb-pop')));
  });
  document.addEventListener('mouseleave', () => setInteractive(false));
  window.addEventListener('blur', () => closeDrawer());

  window.hub.onTaskbar?.((payload) => {
    state = payload || null;
    render();
  });
  window.hub.taskbarReady?.().catch(() => {});
})();
