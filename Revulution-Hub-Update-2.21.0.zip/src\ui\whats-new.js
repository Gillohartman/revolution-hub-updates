'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.21.0',
  title: 'Revulution Hub 2.21.0',
  sub: 'Desktop als eigene App, ruhigere Fenster und eine Leiste, die sich wirklich wie Windows anfühlt.',
  items: [
    { open: 'tool-desktop', icon: 'home', title: 'Desktop als eigene App', text: 'Uhr, Systemwerte, Schnellzugriffe und der Taskleisten-Schalter als ruhige Widgets im Stil der Startseite – erreichbar über die Leiste und die App-Übersicht.' },
    { open: 'home', icon: 'spark', title: 'Karten mit Bewegung', text: 'App-Karten kippen beim Darüberfahren leicht mit, und der Glanz wandert mit dem Zeiger. Profilkarte und Suche sind jetzt exakt gleich breit und hoch.' },
    { open: 'settings', icon: 'control', title: 'Ruhige Fenster, echte Livewerte', text: 'Kontrollzentrum und Leiste haben keine doppelten Ränder mehr. CPU, RAM und GPU aktualisieren nur noch die Zahlen – ohne Aufmach-Animation im Sekundentakt.' },
    { open: 'settings', icon: 'power', title: 'Windows-Logo und Power-Knopf', text: 'Die Leiste trägt das Windows-Zeichen, das Startmenü bleibt unten. Die Glocke ist jetzt ein Ausschalter: Erst bestätigen, dann werden alle Aufgaben beendet.' },
  ],
};
