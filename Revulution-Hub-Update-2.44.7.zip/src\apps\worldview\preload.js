'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('worldview', {
  start: () => ipcRenderer.invoke('start'),
  notice: (kind, detail) => ipcRenderer.invoke('notice', kind, detail),
});
