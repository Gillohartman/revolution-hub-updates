'use strict';
(() => {
  const start = document.getElementById('start');
  if (start) {
    start.addEventListener('click', async () => {
      start.disabled = true;
      start.textContent = 'Weltansicht wird geladen …';
      document.getElementById('error').textContent = '';
      try { await window.worldview.start(); }
      catch (error) {
        document.getElementById('error').textContent = error?.message || 'Die Weltansicht konnte nicht gestartet werden.';
        start.disabled = false;
        start.textContent = 'Erneut versuchen';
      }
    });
    return;
  }
  if (document.getElementById('worldview-tools')) return;
  const panel = document.createElement('section');
  panel.id = 'worldview-tools';
  panel.setAttribute('aria-label', 'Standort und Benachrichtigungen');
  panel.innerHTML = `<button type="button" class="worldview-tools-toggle" aria-expanded="false">⌖ &nbsp; Standort & Hinweise</button>
    <div class="worldview-tools-body" hidden>
      <div class="worldview-tools-heading">Dein Standort</div>
      <p>Dein Standort wird nur auf Wunsch ermittelt und nicht an die Datenquellen dieser Hinweise gesendet. Windows-Standortdienste können ihn über einen Standortanbieter bestimmen.</p>
      <button type="button" class="worldview-locate">⌖ &nbsp; Zu meinem Standort</button>
      <div class="worldview-tools-heading">Island-Hinweise</div>
      <label><input type="checkbox" data-alert="military"> Militärflugzeuge in der Nähe</label>
      <label><input type="checkbox" data-alert="earthquake"> Starke Erdbeben weltweit</label>
      <p>Nur bei geöffneter Weltansicht. Flugdaten können fehlen oder ungenau sein; keine offiziellen Warnungen.</p>
      <p class="worldview-status" role="status" aria-live="polite"></p>
    </div>`;
  document.body.appendChild(panel);
  const toggle = panel.querySelector('.worldview-tools-toggle');
  const body = panel.querySelector('.worldview-tools-body');
  const status = panel.querySelector('.worldview-status');
  const locate = panel.querySelector('.worldview-locate');
  const military = panel.querySelector('[data-alert="military"]');
  const earthquake = panel.querySelector('[data-alert="earthquake"]');
  let position = null;
  let militaryTimer = null;
  let earthquakeTimer = null;
  let militaryAbort = null;
  let quakeAbort = null;
  let seenMilitary = new Map();
  let seenQuakes = null;
  let session = 0;
  const message = (text) => { status.textContent = text; };
  toggle.addEventListener('click', () => {
    body.hidden = !body.hidden;
    toggle.setAttribute('aria-expanded', String(!body.hidden));
  });
  function locateUser() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('Standortermittlung ist auf diesem Gerät nicht verfügbar.'));
      navigator.geolocation.getCurrentPosition(result => {
        const { latitude, longitude, accuracy } = result.coords;
        if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return reject(new Error('Kein gültiger Standort verfügbar.'));
        position = { latitude, longitude, accuracy };
        resolve(position);
      }, error => reject(new Error(error.code === 1 ? 'Standortzugriff verweigert. Bitte in Windows erlauben.' : 'Standort nicht verfügbar. Bitte Windows-Standortdienste prüfen.')), { timeout: 15000, maximumAge: 300000, enableHighAccuracy: true });
    });
  }
  locate.addEventListener('click', async () => {
    locate.disabled = true;
    message('Standort wird ermittelt …');
    try {
      const current = await locateUser();
      const search = document.getElementById('location-search');
      if (!search) throw new Error('Die Weltansicht lädt noch. Bitte versuche es erneut.');
      search.value = `${current.latitude}, ${current.longitude}`;
      search.dispatchEvent(new Event('input', { bubbles: true }));
      search.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
      message(`Standort ermittelt (Genauigkeit ca. ${Math.round(current.accuracy)} m).`);
    } catch (error) { message(error.message); }
    finally { locate.disabled = false; }
  });
  function distanceKm(a, lat, lon) {
    const rad = Math.PI / 180;
    const dLat = (lat - a.latitude) * rad, dLon = (lon - a.longitude) * rad;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.latitude * rad) * Math.cos(lat * rad) * Math.sin(dLon / 2) ** 2;
    return 12742 * Math.asin(Math.sqrt(Math.min(1, h)));
  }
  async function checkMilitary() {
    if (!military.checked || !position || militaryAbort) return;
    const controller = new AbortController(); militaryAbort = controller;
    try {
      const response = await fetch('/api/military', { signal: controller.signal, cache: 'no-store' });
      if (!response.ok || response.headers.get('X-Feed-Cache') === 'STALE') throw new Error('Flugdaten vorübergehend nicht verfügbar.');
      const data = await response.json();
      if (!military.checked || controller.signal.aborted || !Array.isArray(data.ac)) return;
      const now = Date.now();
      for (const [id, time] of seenMilitary) if (now - time > 3600000) seenMilitary.delete(id);
      for (const aircraft of data.ac) {
        const lat = aircraft.lat, lon = aircraft.lon, age = aircraft.seen_pos;
        if (!aircraft.hex || typeof lat !== 'number' || typeof lon !== 'number' || !Number.isFinite(age) || age > 60 || age < 0 || aircraft.alt_baro === 'ground') continue;
        const distance = distanceKm(position, lat, lon);
        if (distance > 10 || seenMilitary.has(aircraft.hex)) continue;
        seenMilitary.set(aircraft.hex, now);
        const name = String(aircraft.flight || aircraft.r || 'Unbekannt').trim().replace(/[^a-zA-Z0-9 -]/g, '').slice(0, 24);
        await window.worldview.notice('military', `${name} · etwa ${Math.max(1, Math.round(distance))} km entfernt (ADS-B).`);
      }
    } catch (error) { if (error.name !== 'AbortError') message('Flugdaten vorübergehend nicht verfügbar.'); }
    finally { if (militaryAbort === controller) militaryAbort = null; }
  }
  async function checkEarthquakes() {
    if (!earthquake.checked || quakeAbort) return;
    const controller = new AbortController(); quakeAbort = controller;
    try {
      const response = await fetch('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson', { signal: controller.signal, cache: 'no-store' });
      if (!response.ok) throw new Error('USGS nicht verfügbar');
      const data = await response.json();
      if (!earthquake.checked || controller.signal.aborted || !Array.isArray(data.features)) return;
      const previous = seenQuakes;
      seenQuakes = new Set(data.features.map(item => item.id).filter(Boolean));
      if (!previous) return;
      for (const item of data.features) {
        const p = item.properties || {};
        if (!item.id || previous.has(item.id) || !Number.isFinite(p.mag) || p.mag < 5.5 || !Number.isFinite(p.time) || Date.now() - p.time > 3600000 || p.time > Date.now() + 60000) continue;
        const place = String(p.place || 'Ort unbekannt').replace(/[\r\n]/g, ' ').slice(0, 70);
        await window.worldview.notice('earthquake', `Magnitude ${p.mag.toFixed(1)} · ${place} (USGS).`);
      }
    } catch (error) { if (error.name !== 'AbortError') message('Erdbebendaten vorübergehend nicht verfügbar.'); }
    finally { if (quakeAbort === controller) quakeAbort = null; }
  }
  military.addEventListener('change', async () => {
    const current = ++session;
    clearInterval(militaryTimer); militaryTimer = null;
    militaryAbort?.abort(); militaryAbort = null;
    seenMilitary = new Map();
    if (!military.checked) { message('Flughinweise ausgeschaltet.'); return; }
    try {
      message('Standort für Flughinweise wird ermittelt …');
      const currentPosition = await locateUser();
      if (!military.checked || current !== session) return;
      if (currentPosition.accuracy > 10000) throw new Error('Standort zu ungenau für Hinweise im Umkreis von 10 km.');
      message('Flughinweise an: gemeldete Militärflugzeuge im Umkreis von 10 km.');
      void checkMilitary();
      militaryTimer = setInterval(checkMilitary, 60000);
    } catch (error) { if (current === session) { military.checked = false; message(error.message); } }
  });
  earthquake.addEventListener('change', () => {
    clearInterval(earthquakeTimer); earthquakeTimer = null;
    quakeAbort?.abort(); quakeAbort = null; seenQuakes = null;
    if (!earthquake.checked) { message('Erdbebenhinweise ausgeschaltet.'); return; }
    message('Erdbebenhinweise an: neue Beben ab Magnitude 5,5 weltweit.');
    void checkEarthquakes();
    earthquakeTimer = setInterval(checkEarthquakes, 120000);
  });
  window.addEventListener('pagehide', () => {
    clearInterval(militaryTimer); clearInterval(earthquakeTimer);
    militaryAbort?.abort(); quakeAbort?.abort();
  }, { once: true });
})();
