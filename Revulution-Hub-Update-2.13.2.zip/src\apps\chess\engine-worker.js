'use strict';

/* Engine im Hintergrund-Thread, damit Brett und Animationen flüssig bleiben. */
importScripts('chess-core.js', 'engine.js');

const { Position, uci } = self.ChessCore;
const { Engine, pickMove } = self.ChessEngine;
const engine = new Engine();

function build(startFen, moves) {
  const pos = new Position(startFen);
  for (const u of moves || []) {
    const m = pos.find(u);
    if (!m) break;
    pos.make(m);
  }
  return pos;
}

self.onmessage = (event) => {
  const { id, cmd, startFen, moves, level, played, timeMs, maxDepth } = event.data || {};
  try {
    if (cmd === 'reset') {
      engine.reset();
      return self.postMessage({ id, ok: true });
    }
    const pos = build(startFen, moves);
    if (cmd === 'play') {
      const result = pickMove(engine, pos, level);
      return self.postMessage({ id, ok: true, result });
    }
    if (cmd === 'analyse') {
      // Jeder Zug einzeln bewertet; dazu die beste Folge nach dem gespielten Zug.
      const rows = engine.scoreAll(pos, { maxDepth: maxDepth || 5, timeMs: timeMs || 900, minDepth: 2 });
      return self.postMessage({ id, ok: true, result: { rows, played } });
    }
    if (cmd === 'hint') {
      const r = engine.think(pos, { maxDepth: maxDepth || 8, timeMs: timeMs || 900 });
      return self.postMessage({ id, ok: true, result: r });
    }
    if (cmd === 'eval') {
      const r = engine.think(pos, { maxDepth: maxDepth || 6, timeMs: timeMs || 400 });
      return self.postMessage({ id, ok: true, result: r });
    }
    self.postMessage({ id, ok: false, error: 'unbekannter Befehl' });
  } catch (error) {
    self.postMessage({ id, ok: false, error: String(error && error.message || error) });
  }
};
void uci;
