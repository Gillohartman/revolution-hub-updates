const card = document.getElementById('card');
const artEl = document.getElementById('art');
const titleEl = document.getElementById('title');
const artistEl = document.getElementById('artist');
const barFill = document.getElementById('barFill');
const elapsedEl = document.getElementById('elapsed');
const remainingEl = document.getElementById('remaining');
const lyricEl = document.getElementById('lyric');
const lyricLine = document.getElementById('lyricLine');
const badgeEl = document.getElementById('badge');
const wallEl = document.getElementById('wall');
const vinylEl = document.getElementById('vinyl');
const vinylLabel = document.getElementById('vinylLabel');
const armRot = document.getElementById('armRot');

/* ---------------- Tonarm ----------------
 * Drehpunkt oben rechts (92|8 im 100er-Raster), Armlänge 62. Die Winkel sind
 * so berechnet, dass die Nadel bei Songbeginn auf der äußeren Rille (Radius 46)
 * und am Ende kurz vor dem Etikett (Radius 28) sitzt. Pausiert = Arm in Ruhe.
 */
const ARM_REST = 82;
const ARM_START = 90.5 - 0; // Grad, Arm zeigt dann nach unten auf die äußere Rille
const ARM_END = 108.4;
let armAngle = ARM_REST;
let armOn = true;

function paintArm(position) {
  if (!armRot) return;
  let target = ARM_REST;
  if (armOn && card.classList.contains('is-vinyl') && state.playing) {
    const progress = state.duration > 0 ? Math.min(1, Math.max(0, position / state.duration)) : 0;
    target = ARM_START + (ARM_END - ARM_START) * progress;
  }
  // Weich hin- und herschwenken (Aufsetzen/Abheben), im Song selbst fast unmerklich.
  const delta = target - armAngle;
  armAngle += Math.abs(delta) < 0.01 ? delta : delta * 0.08;
  armRot.setAttribute('transform', `rotate(${(armAngle - 0).toFixed(2)} 92 8)`);
}

/* ---------------- Platten-Knistern ----------------
 * Wird hier im Fenster erzeugt (kein Audio-File): leises Rauschen plus
 * zufällige Knackser, als Schleife. Läuft nur, solange Musik spielt.
 */
const crackle = { context: null, gain: null, source: null, wanted: false, volume: 0.4 };

function crackleBuffer(context) {
  const seconds = 7;
  const rate = context.sampleRate;
  const buffer = context.createBuffer(2, seconds * rate, rate);
  for (let channel = 0; channel < 2; channel += 1) {
    const data = buffer.getChannelData(channel);
    // Rauschen, tiefpassgefiltert (warm statt zischend).
    let low = 0;
    for (let i = 0; i < data.length; i += 1) {
      low += (Math.random() * 2 - 1 - low) * 0.08;
      data[i] = low * 0.05;
    }
    // Knackser: kurze, abklingende Impulse; ab und zu ein lauterer „Pop“.
    const pops = seconds * (9 + Math.random() * 6);
    for (let p = 0; p < pops; p += 1) {
      const start = Math.floor(Math.random() * (data.length - rate * 0.02));
      const big = Math.random() < 0.08;
      const amp = (big ? 0.35 + Math.random() * 0.35 : 0.04 + Math.random() * 0.16) * (Math.random() < 0.5 ? -1 : 1);
      const decay = rate * (big ? 0.004 : 0.0012) * (0.6 + Math.random());
      const length = Math.floor(decay * 5);
      for (let i = 0; i < length && start + i < data.length; i += 1) {
        data[start + i] += amp * Math.exp(-i / decay) * (i % 2 === 0 ? 1 : -0.6);
      }
    }
  }
  return buffer;
}

function updateCrackle(on, volume) {
  crackle.wanted = on;
  crackle.volume = Math.min(1, Math.max(0, volume));
  if (!on) {
    if (crackle.gain && crackle.context) {
      crackle.gain.gain.setTargetAtTime(0, crackle.context.currentTime, 0.15);
    }
    return;
  }
  try {
    if (!crackle.context) {
      crackle.context = new AudioContext();
      crackle.gain = crackle.context.createGain();
      crackle.gain.gain.value = 0;
      const filter = crackle.context.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 120;
      crackle.gain.connect(filter).connect(crackle.context.destination);
      crackle.source = crackle.context.createBufferSource();
      crackle.source.buffer = crackleBuffer(crackle.context);
      crackle.source.loop = true;
      crackle.source.connect(crackle.gain);
      crackle.source.start();
    }
    if (crackle.context.state === 'suspended') crackle.context.resume().catch(() => {});
    crackle.gain.gain.setTargetAtTime(crackle.volume * 0.9, crackle.context.currentTime, 0.25);
  } catch {
    /* ohne Audio eben ohne Knistern */
  }
}

let state = { playing: false, position: 0, duration: 0, lines: [], lyrics: true };
// Lokale Uhr: manche Apps (Browser) melden ihre Position nur einmal und lassen
// sie dann stehen. Wir laufen deshalb selbst weiter und richten uns nur neu aus,
// wenn die Quelle wirklich einen neuen Stand liefert.
// rate: kleine Abweichungen werden über die Abspielgeschwindigkeit ausgeglichen
// (0,75–1,25×), damit die Anzeige nie sichtbar zurückspringt.
let clock = { pos: 0, at: performance.now(), rate: 1 };
let lastRawPosition = null;
let lyricFloor = 0;
let lastKey = '';
let lastArt = '';
let lastWall = '';
let currentLineIndex = -1;
let words = [];
let shift = 0;
let linesVersion = 0;
let lastLinesVersion = -1;

const fmt = (seconds) => {
  const total = Math.max(0, Math.round(seconds));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
};

function currentPosition() {
  if (!state.playing) return Math.max(0, clock.pos);
  const value = clock.pos + ((performance.now() - clock.at) / 1000) * clock.rate;
  return state.duration > 0 ? Math.min(state.duration, value) : value;
}

function setArt(src) {
  // #art ist ein div (kein img) – das Cover kommt als Hintergrundbild, sonst
  // bleibt der Platzhalter für immer stehen.
  if (!src) {
    artEl.classList.add('is-empty');
    artEl.style.backgroundImage = '';
    artEl.textContent = '♪';
    vinylLabel.classList.add('is-empty');
    vinylLabel.style.backgroundImage = '';
    vinylLabel.textContent = '♪';
    return;
  }
  artEl.classList.remove('is-empty');
  artEl.textContent = '';
  artEl.style.backgroundImage = `url("${src}")`;
  vinylLabel.classList.remove('is-empty');
  vinylLabel.textContent = '';
  vinylLabel.style.backgroundImage = `url("${src}")`;
}

function setVinyl(enabled, playing) {
  card.classList.toggle('is-vinyl', enabled);
  vinylEl.hidden = !enabled;
  vinylEl.classList.toggle('is-spinning', enabled && playing);
}

function setWall(src) {
  if (!src) {
    wallEl.hidden = true;
    wallEl.removeAttribute('src');
    return;
  }
  wallEl.hidden = false;
  if (wallEl.getAttribute('src') !== src) wallEl.src = src;
  const played = wallEl.play();
  if (played && typeof played.catch === 'function') played.catch(() => {});
}

function setShade(value) {
  const pct = Number(value);
  if (!Number.isFinite(pct)) return;
  const bottom = Math.min(1, Math.max(0, pct / 100));
  const top = bottom * 0.85;
  document.getElementById('wallShade').style.background =
    `linear-gradient(180deg, rgba(8, 9, 13, ${top.toFixed(3)}), rgba(8, 9, 13, ${bottom.toFixed(3)}))`;
  // Die Karte selbst wird bei wenig Abdunklung durchsichtig.
  document.getElementById('card').style.background =
    `rgba(10, 12, 18, ${(0.1 + 0.72 * bottom).toFixed(3)})`;
}

function buildLine(text) {
  lyricLine.replaceChildren();
  words = String(text || '')
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => {
      const span = document.createElement('span');
      span.className = 'word';
      span.textContent = word;
      lyricLine.appendChild(span);
      return { node: span, length: word.length + 1 };
    });
}

function paintLyric(position) {
  const lines = state.lines || [];
  if (!state.lyrics || lines.length === 0) {
    if (lyricEl.style.display !== 'none') lyricEl.style.display = 'none';
    card.classList.add('no-lyrics');
    badgeEl.textContent = '';
    return;
  }
  if (lyricEl.style.display === 'none') {
    lyricEl.style.display = 'flex';
    card.classList.remove('no-lyrics');
  }

  let index = -1;
  for (let i = 0; i < lines.length; i += 1) {
    if (lines[i].t <= position + 0.08) index = i;
    else break;
  }
  if (index !== currentLineIndex || lastLinesVersion !== linesVersion) {
    currentLineIndex = index;
    lastLinesVersion = linesVersion;
    buildLine(index >= 0 ? lines[index].text : '');
    shift = 0;
    lyricLine.style.transform = 'translateX(0px)';
  }
  if (badgeEl.textContent !== 'Songtext') badgeEl.textContent = 'Songtext';

  const start = index >= 0 ? lines[index].t : 0;
  const end = index + 1 < lines.length ? lines[index + 1].t : start + 3.2;
  const span = Math.max(0.6, end - start);
  const progress = Math.min(1, Math.max(0, (position - start) / span));

  // Wörter nach Zeichenlänge auf die Zeilendauer verteilen: das aktuell
  // gesungene Wort füllt sich, der Rest bleibt blass (Apple-Music-Optik).
  const total = words.reduce((sum, word) => sum + word.length, 0) || 1;
  let cursor = 0;
  const fills = [];
  for (let i = 0; i < words.length; i += 1) {
    const word = words[i];
    const from = cursor / total;
    cursor += word.length;
    const to = cursor / total;
    const local = Math.min(1, Math.max(0, (progress - from) / Math.max(0.0001, to - from)));
    fills.push(local);
    word.node.style.setProperty('--p', local.toFixed(3));
  }
  // Aktives Wort = das erste, das noch nicht fertig ist (sonst das letzte).
  let active = words.findIndex((_, i) => fills[i] < 1);
  if (active < 0) active = words.length - 1;

  // Lange Zeilen mitscrollen, damit das gesungene Wort nicht am Rand hängt.
  const node = words[Math.max(0, active)]?.node;
  if (node) {
    const boxRect = lyricEl.getBoundingClientRect();
    const nodeRect = node.getBoundingClientRect();
    const rawCenter = nodeRect.left - boxRect.left + nodeRect.width / 2 - shift;
    const target = Math.max(boxRect.width - lyricLine.scrollWidth, boxRect.width / 2 - rawCenter);
    const next = Math.min(0, target);
    // Butterweich nachführen: exponentiell ans Ziel herangleiten statt in
    // Stufen zu springen. Pro Frame ein kleiner Schritt, kein Runden – so
    // bouncet nichts, auch wenn sich das Ziel ständig leicht verschiebt.
    if (Math.abs(next - shift) < 0.05) {
      if (shift !== next) {
        shift = next;
        lyricLine.style.transform = `translateX(${shift}px)`;
      }
    } else {
      shift += (next - shift) * 0.16;
      lyricLine.style.transform = `translateX(${shift}px)`;
    }
  }
}

function apply(payload) {
  // Das Fenster wird auf Größe × Faktor gesetzt. Ohne diesen Zoom bliebe der
  // Inhalt bei 100 % und würde unten abgeschnitten.
  const factor = Math.min(2, Math.max(0.6, Number(payload.scale) || 1));
  document.documentElement.style.zoom = String(factor);

  const key = `${payload.title || ''}|${payload.artist || ''}|${payload.app || ''}`;
  const trackChanged = key !== lastKey;
  const reported = Number(payload.position) || 0;

  const previousLines = state.lines;
  if (Array.isArray(payload.lines)) linesVersion += 1;
  state = {
    playing: Boolean(payload.playing),
    position: reported,
    duration: Number(payload.duration) || 0,
    // Liedtext kommt nur bei Änderung mit – sonst den vorhandenen behalten.
    lines: Array.isArray(payload.lines) ? payload.lines : previousLines,
    lyrics: payload.lyrics !== false,
  };

  // Drei Fälle unterscheiden:
  //  - Quelle steht (Browser-Video): Uhr läuft ungestört weiter
  //  - Quelle liefert leicht abweichende Werte: über die Laufrate ausgleichen
  //  - Quelle springt (Spulen, neuer Song): sofort neu ansetzen
  const now = performance.now();
  const predicted = clock.pos + ((now - clock.at) / 1000) * clock.rate;
  const drift = reported - predicted;
  const sourceMoved = lastRawPosition === null || reported !== lastRawPosition;
  lastRawPosition = reported;
  if (trackChanged || !state.playing || (sourceMoved && Math.abs(drift) > 1.5)) {
    clock = { pos: reported, at: now, rate: 1 };
    lyricFloor = reported;
  } else if (sourceMoved) {
    clock = { pos: predicted, at: now, rate: Math.min(1.25, Math.max(0.75, 1 + drift * 0.6)) };
  } else {
    clock = { pos: predicted, at: now, rate: 1 };
  }

  const onlyVinyl = payload.vinylOnly === true;
  card.classList.toggle('only-vinyl', onlyVinyl);
  card.classList.toggle('no-title', payload.showTitle === false);
  card.classList.toggle('no-progress', payload.showProgress === false);
  if (onlyVinyl) {
    // Nur der runde Kreis: kein Wallpaper, keine Fläche dahinter
    // (Inline-Stil, weil setShade die Karte sonst weiter abdunkelt).
    setWall('');
    card.style.background = 'transparent';
  } else {
    setWall(payload.wall);
    setShade(payload.shade);
  }

  if (trackChanged) {
    lastKey = key;
    currentLineIndex = -1;
    titleEl.textContent = payload.title || 'Nichts läuft';
    artistEl.textContent =
      payload.artist || (payload.playing ? '' : 'Starte Musik in Spotify oder im Browser');
  }

  // Cover trifft erst nach dem Titelwechsel ein – deshalb außerhalb des
  // Titelblocks setzen, sonst bleibt der Platzhalter stehen.
  if (payload.art !== undefined && payload.art !== lastArt) {
    lastArt = payload.art;
    setArt(lastArt);
  }

  setVinyl(payload.vinyl === true || onlyVinyl, state.playing);
  armOn = payload.arm !== false;
  card.classList.toggle('no-arm', !armOn);
  updateCrackle(payload.crackle === true && state.playing, (Number(payload.crackleVolume ?? 40) || 0) / 100);
  card.classList.toggle('is-on', Boolean(payload.playing || payload.title));
}

function tick() {
  const position = currentPosition();
  const duration = state.duration || 0;
  elapsedEl.textContent = fmt(position);
  remainingEl.textContent = duration > 0 ? `-${fmt(Math.max(0, duration - position))}` : '-0:00';
  barFill.style.width = duration > 0 ? `${Math.min(100, (position / duration) * 100)}%` : '0%';
  // Songtext läuft nur vorwärts; ein echter Sprung zurück (> 1,5 s) setzt ihn neu.
  if (position < lyricFloor - 1.5) lyricFloor = position;
  else lyricFloor = Math.max(lyricFloor, position);
  paintLyric(lyricFloor);
  paintArm(position);
  requestAnimationFrame(tick);
}

if (window.musicOverlay) {
  window.musicOverlay.onUpdate(apply);
  window.musicOverlay.ready();
} else {
  // Vorschau im Browser (Design-Entwicklung) – ohne App-Daten.
  apply({
    playing: true,
    vinyl: true,
    title: 'Nebula Drive',
    artist: 'Revulution',
    position: 26,
    duration: 214,
    lyrics: true,
    lines: [
      { t: 0, text: 'Wir ziehen durch die Nacht' },
      { t: 6.5, text: 'und die Stadt atmet mit' },
      { t: 12.4, text: 'jeder Schuss ein neuer Takt' },
      { t: 18.2, text: 'und das Licht zieht uns mit' },
      { t: 24.1, text: 'Nebula Drive, wir bleiben wach' },
    ],
  });
}
requestAnimationFrame(tick);
