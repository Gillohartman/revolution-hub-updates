# Liest, was auf dem PC gerade abgespielt wird (Spotify, Browser, Player).
# Gibt pro Durchlauf eine JSON-Zeile aus; das Cover wird nur bei Titelwechsel
# mitgeschickt, damit die Ausgabe klein bleibt.
$ErrorActionPreference = 'SilentlyContinue'
# Ohne UTF-8 macht PowerShell aus Emojis im Titel „?????“.
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime | Out-Null

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  })[0]

function Await($WinRtTask, $ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  $netTask.Wait(-1) | Out-Null
  $netTask.Result
}

$managerType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$streamType = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = $managerType
$null = $streamType

$lastArtKey = ''

while ($true) {
  $payload = '{"playing":false}'
  try {
    $manager = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
    $session = $manager.GetCurrentSession()
    if ($null -ne $session) {
      $props = Await ($session.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
      $info = $session.GetPlaybackInfo()
      $timeline = $session.GetTimelineProperties()

      $art = ''
      $key = ([string]$props.Title) + '|' + ([string]$props.Artist) + '|' + ([string]$props.AlbumTitle)
      if ($key -ne $lastArtKey -and $null -ne $props.Thumbnail) {
        $bytes = $null
        try {
          $stream = Await ($props.Thumbnail.OpenReadAsync()) ($streamType)
          # Der Rückgabewert ist ein COM-Objekt: erst der Cast macht die
          # Stream-Methoden in PowerShell 5.1 aufrufbar.
          $ras = [Windows.Storage.Streams.IRandomAccessStream]$stream
          $reader = [Windows.Storage.Streams.DataReader]::new($ras.GetInputStreamAt(0))
          $loaded = Await ($reader.LoadAsync([uint32]$ras.Size)) ([uint32])
          $bytes = New-Object byte[] $loaded
          $reader.ReadBytes($bytes)
        } catch {
          [Console]::Error.WriteLine('art-cast: ' + $_.Exception.Message)
          try {
            $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($stream)
            $mem = New-Object System.IO.MemoryStream
            $net.CopyTo($mem)
            $bytes = $mem.ToArray()
          } catch {
            [Console]::Error.WriteLine('art-stream: ' + $_.Exception.Message)
          }
        }
        if ($null -ne $bytes -and $bytes.Length -gt 0) {
          $art = [Convert]::ToBase64String($bytes)
          $lastArtKey = $key
        }
      }

      $obj = [ordered]@{
        playing  = ($info.PlaybackStatus -eq 'Playing')
        title    = [string]$props.Title
        artist   = [string]$props.Artist
        album    = [string]$props.AlbumTitle
        app      = [string]$session.SourceAppUserModelId
        position = [math]::Round([double]$timeline.Position.TotalSeconds, 2)
        duration = [math]::Round([double]$timeline.EndTime.TotalSeconds, 2)
        art      = $art
      }
      $payload = ($obj | ConvertTo-Json -Compress)
    }
  } catch {
    $payload = '{"playing":false}'
  }
  [Console]::Out.WriteLine($payload)
  [Console]::Out.Flush()
  # Dreimal pro Sekunde: sonst läuft die Anzeige der Quelle hinterher und der
  # Songtext springt beim Nachkorrigieren zurück.
  Start-Sleep -Milliseconds 300
}
