'use strict';

/**
 * A module's "main window", hosted as a view inside the hub window.
 *
 * The modules still talk to it like a BrowserWindow (load, show, send, minimize…); this
 * class implements that surface and forwards window-level calls to the hub window.
 */

const { WebContentsView } = require('electron');
const { EventEmitter } = require('events');
const { wrapWindowOptions, MODULE_PRELOAD } = require('./shim');

/** Events that belong to the real window and are forwarded from the hub window. */
const WINDOW_EVENTS = new Set(['maximize', 'unmaximize', 'minimize', 'restore', 'focus', 'blur', 'move', 'moved', 'resize', 'resized', 'enter-full-screen', 'leave-full-screen']);

class ModuleView extends EventEmitter {
  constructor(hub, mod, options = {}) {
    super();
    this.__isModuleView = true;
    this.hub = hub;
    this.mod = mod;
    this.pendingLoad = null;
    this.shownOnce = false;
    this.ready = false;

    const { webPreferences } = wrapWindowOptions(mod, options);
    webPreferences.additionalArguments = [...(webPreferences.additionalArguments || []), '--hub-view', `--hub-module=${mod.id}`];
    if (!webPreferences.preload) {
      webPreferences.preload = MODULE_PRELOAD;
      webPreferences.sandbox = false;
    }
    this.view = new WebContentsView({ webPreferences });
    // Transparent: the hub draws one live wallpaper behind every app.
    this.view.setBackgroundColor('#00000000');
    this.view.setVisible(false);
    this.webContents = this.view.webContents;
    this.id = this.webContents.id;

    this.webContents.on('dom-ready', () => {
      if (mod.css) this.webContents.insertCSS(mod.css).catch(() => {});
      if (mod.script) this.webContents.executeJavaScript(mod.script, true).catch(() => {});
      // Sprache: Apps mit eigener Übersetzung bekommen nur die Sprache, alle anderen den Übersetzer.
      if (mod.ownI18n) this.webContents.executeJavaScript(`window.__hubLang = ${JSON.stringify(hub.currentLang?.() || 'de')}; window.dispatchEvent(new CustomEvent('hub-lang', { detail: window.__hubLang }))`, true).catch(() => {});
      else if (hub.translatorScript) this.webContents.executeJavaScript(hub.translatorScript(), true).catch(() => {});
    });
    this.webContents.on('did-finish-load', () => {
      if (this.ready || this.webContents.getURL().startsWith('about:')) return;
      this.ready = true;
      this.emit('ready-to-show');
      hub.pushState();
    });
    this.webContents.on('render-process-gone', (_event, details) => {
      console.error(`[hub] ${mod.id} renderer gone: ${details.reason}`);
    });
    // Links that try to open new windows go to the default browser instead.
    this.webContents.on('did-create-window', (child) => child.setMenu?.(null));

    hub.attachView(this);
  }

  /* -------------------------------------------------------------- loading */
  loadFile(file, options) {
    return this.deferLoad(() => this.webContents.loadFile(file, options));
  }

  loadURL(url, options) {
    return this.deferLoad(() => this.webContents.loadURL(url, options));
  }

  /** Lazy modules only load their UI the first time the user opens them. */
  deferLoad(load) {
    this.lastLoad = load;
    if (this.mod.lazy && !this.hub.wasOpened(this.mod.id)) {
      this.pendingLoad = load;
      return Promise.resolve();
    }
    return load();
  }

  ensureLoaded() {
    if (!this.pendingLoad) return;
    const load = this.pendingLoad;
    this.pendingLoad = null;
    load().catch((error) => console.error(`[hub] ${this.mod.id} failed to load`, error));
  }

  /** App beenden: Seite verwerfen (spart RAM), beim nächsten Öffnen lädt sie neu. */
  unload() {
    if (!this.lastLoad || this.pendingLoad || this.webContents.isDestroyed()) return false;
    this.pendingLoad = this.lastLoad;
    this.ready = false;
    this.webContents.loadURL('about:blank').catch(() => {});
    return true;
  }

  /* ------------------------------------------------------------ visibility */
  show() {
    // The first show() is the module's own "ready-to-show" reveal; the hub decides
    // which page is visible at start, so only later calls switch to the module.
    if (!this.shownOnce) {
      this.shownOnce = true;
      return;
    }
    this.hub.open(this.mod.id);
  }

  showInactive() {}

  focus() {
    this.hub.open(this.mod.id);
    this.webContents.focus();
  }

  hide() {
    this.hub.window?.hide();
  }

  isVisible() {
    return Boolean(this.hub.window?.isVisible() && this.hub.active === this.mod.id);
  }

  isFocused() {
    return Boolean(this.hub.window?.isFocused() && this.hub.active === this.mod.id);
  }

  isDestroyed() {
    return this.webContents.isDestroyed();
  }

  /* ------------------------------------------------- window-level forwards */
  minimize() {
    this.hub.window?.minimize();
  }
  maximize() {
    this.hub.window?.maximize();
  }
  unmaximize() {
    this.hub.window?.unmaximize();
  }
  isMaximized() {
    return Boolean(this.hub.window?.isMaximized());
  }
  isMinimized() {
    return Boolean(this.hub.window?.isMinimized());
  }
  restore() {
    this.hub.window?.restore();
  }
  close() {
    this.hub.window?.close();
  }
  isFullScreen() {
    return Boolean(this.hub.window?.isFullScreen());
  }
  setFullScreen(flag) {
    this.hub.window?.setFullScreen(flag);
  }
  getBounds() {
    return this.hub.window?.getBounds() || { x: 0, y: 0, width: 0, height: 0 };
  }
  getContentBounds() {
    return this.hub.window?.getContentBounds() || this.getBounds();
  }
  getNativeWindowHandle() {
    return this.hub.window?.getNativeWindowHandle();
  }
  setProgressBar(progress, options) {
    this.hub.window?.setProgressBar(progress, options);
  }
  flashFrame(flag) {
    this.hub.window?.flashFrame(flag);
  }
  setTitle() {}
  getTitle() {
    return this.mod.name;
  }
  setIcon() {}
  setMenu() {}
  removeMenu() {}
  setMenuBarVisibility() {}
  setAutoHideMenuBar() {}
  setAlwaysOnTop() {}
  setSkipTaskbar() {}
  center() {}
  setBounds() {}
  setSize() {}
  setMinimumSize() {}
  destroy() {}

  /* ---------------------------------------------------------------- events */
  on(event, listener) {
    if (WINDOW_EVENTS.has(event)) this.hub.window?.on(event, listener);
    else super.on(event, listener);
    return this;
  }

  addListener(event, listener) {
    return this.on(event, listener);
  }

  once(event, listener) {
    if (WINDOW_EVENTS.has(event)) this.hub.window?.once(event, listener);
    else super.once(event, listener);
    return this;
  }
}

module.exports = { ModuleView };
