const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('perfOverlay', {
  onUpdate: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('perf:update', handler);
    return () => ipcRenderer.removeListener('perf:update', handler);
  },
  ready: () => ipcRenderer.send('perf:ready'),
});
