'use strict';

/*
 * Tastatur + Maus als Overlay (Player, Export, Live-Vorschau).
 * Kompakter Gaming-Block statt ganzer Tastatur, daneben eine Maus mit
 * linker/rechter Taste, Mausrad und zwei Seitentasten (M4 hinten, M5 vorne).
 */
(function () {
  const ROWS = [
    [{ l: 'Esc', w: 1.25 }, { l: '1' }, { l: '2' }, { l: '3' }, { l: '4' }, { l: '5' }, { l: '6' }],
    [{ l: 'Tab', w: 1.5 }, { l: 'Q' }, { l: 'W' }, { l: 'E' }, { l: 'R' }, { l: 'T' }],
    [{ l: 'Caps', w: 1.75 }, { l: 'A' }, { l: 'S' }, { l: 'D' }, { l: 'F' }, { l: 'G' }],
    [{ l: 'Shift', w: 2.25 }, { l: 'Y' }, { l: 'X' }, { l: 'C' }, { l: 'V' }, { l: 'B' }],
    [{ l: 'Ctrl', w: 1.5 }, { l: 'Alt', w: 1.25 }, { l: 'Space', w: 4.5 }],
  ];
  const ROW_UNITS = 7.25;

  const PAD_LABELS = {
    'pad-LT': 'LT',
    'pad-RT': 'RT',
    'pad-LB': 'LB',
    'pad-RB': 'RB',
    'pad-StickL': 'L-Stick',
    'pad-StickR': 'R-Stick',
    'pad-LS': 'L3',
    'pad-RS': 'R3',
  };

  const ACCENT = '#3ce88f';
  const ACCENT_TEXT = '#06140c';
  const PAD = '#4b8dff';
  const IDLE = 'rgba(14,17,24,0.78)';
  const IDLE_LINE = 'rgba(255,255,255,0.16)';
  const LABEL = 'rgba(236,242,250,0.92)';

  function roundRect(c, x, y, w, h, r) {
    const radius = Math.max(0, Math.min(r, w / 2, h / 2));
    c.beginPath();
    c.moveTo(x + radius, y);
    c.arcTo(x + w, y, x + w, y + h, radius);
    c.arcTo(x + w, y + h, x, y + h, radius);
    c.arcTo(x, y + h, x, y, radius);
    c.arcTo(x, y, x + w, y, radius);
    c.closePath();
  }

  function fillKey(c, x, y, w, h, r, pressed, color) {
    roundRect(c, x, y, w, h, r);
    if (pressed) {
      c.save();
      c.shadowColor = color;
      c.shadowBlur = h * 0.55;
      c.fillStyle = color;
      c.fill();
      c.restore();
    } else {
      c.fillStyle = IDLE;
      c.fill();
    }
    c.lineWidth = Math.max(1, h * 0.045);
    c.strokeStyle = pressed ? 'rgba(255,255,255,0.75)' : IDLE_LINE;
    c.stroke();
  }

  /**
   * Zeichnet das Overlay unten links.
   * @param {CanvasRenderingContext2D} c
   * @param {number} width  Breite der Zeichenfläche
   * @param {number} height Höhe der Zeichenfläche
   * @param {Set<string>} lit gerade gedrückte Tasten (z. B. 'W', 'M1', 'M4', 'pad-A')
   * @param {{controller?: boolean, scale?: number, anchor?: 'bl'|'center', lift?: number}} [options]
   */
  function draw(c, width, height, lit, options = {}) {
    const keys = lit instanceof Set ? lit : new Set(lit || []);
    const scale = Number(options.scale) || 1;
    const unit = Math.max(14, Math.round(height * 0.036 * scale));
    const gap = Math.max(2, Math.round(unit * 0.13));
    const radius = Math.round(unit * 0.22);
    const rowHeight = unit + gap;
    const keyboardWidth = Math.round(ROW_UNITS * unit + 6 * gap);
    const blockHeight = ROWS.length * rowHeight - gap;
    const mouseWidth = Math.round(unit * 2.35);
    const mouseHeight = blockHeight;
    const panelPad = Math.round(unit * 0.38);
    const spacing = Math.round(unit * 0.55);
    const totalWidth = keyboardWidth + spacing + mouseWidth + panelPad * 2;
    const totalHeight = blockHeight + panelPad * 2;

    const margin = Math.round(unit * 0.9);
    let left = margin;
    let top = height - margin - totalHeight - Math.round(Number(options.lift) || 0);
    // Frei verschoben (im Player gezogen): Position als Anteil der Bildfläche.
    if (options.position && Number.isFinite(options.position.x) && Number.isFinite(options.position.y)) {
      left = Math.round(Math.min(1, Math.max(0, options.position.x)) * Math.max(0, width - totalWidth));
      top = Math.round(Math.min(1, Math.max(0, options.position.y)) * Math.max(0, height - totalHeight));
    } else if (options.anchor === 'center') {
      left = Math.round((width - totalWidth) / 2);
      top = Math.round((height - totalHeight) / 2);
    }

    c.save();
    c.textAlign = 'center';
    c.textBaseline = 'middle';

    // Dezente Fläche hinter dem Block, damit er auf hellen Szenen lesbar bleibt.
    roundRect(c, left, top, totalWidth, totalHeight, Math.round(unit * 0.45));
    c.fillStyle = 'rgba(6,8,12,0.38)';
    c.fill();

    const originX = left + panelPad;
    const originY = top + panelPad;

    ROWS.forEach((row, index) => {
      let x = originX;
      const y = originY + index * rowHeight;
      // Jede Reihe exakt auf Blockbreite strecken, damit rechts alles bündig ist.
      const units = row.reduce((sum, key) => sum + (key.w || 1), 0);
      const perUnit = (keyboardWidth - (row.length - 1) * gap) / units;
      row.forEach((key, keyIndex) => {
        const w =
          keyIndex === row.length - 1
            ? Math.round(originX + keyboardWidth - x)
            : Math.round((key.w || 1) * perUnit);
        const pressed = keys.has(key.l);
        fillKey(c, x, y, w, unit, radius, pressed, ACCENT);
        const size = key.l.length > 2 ? 0.34 : 0.44;
        c.font = `700 ${Math.round(unit * size)}px "Segoe UI", system-ui, sans-serif`;
        c.fillStyle = pressed ? ACCENT_TEXT : LABEL;
        c.fillText(key.l === 'Space' ? '' : key.l, x + w / 2, y + unit / 2 + 1);
        if (key.l === 'Space') {
          c.fillStyle = pressed ? ACCENT_TEXT : 'rgba(236,242,250,0.55)';
          c.fillRect(x + w * 0.3, y + unit * 0.62, w * 0.4, Math.max(1, unit * 0.06));
        }
        x += w + gap;
      });
    });

    drawMouse(c, originX + keyboardWidth + spacing, originY, mouseWidth, mouseHeight, unit, keys);

    if (options.controller !== false) {
      const pads = [...keys].filter((key) => key.startsWith('pad-'));
      if (pads.length > 0) {
        c.font = `700 ${Math.round(unit * 0.36)}px "Segoe UI", system-ui, sans-serif`;
        let x = left;
        const y = top - unit - gap * 2;
        for (const key of pads.slice(0, 8)) {
          const label = PAD_LABELS[key] || key.replace(/^pad-/, '');
          const w = Math.round(c.measureText(label).width + unit * 0.7);
          fillKey(c, x, y, w, unit, radius, true, PAD);
          c.fillStyle = '#ffffff';
          c.fillText(label, x + w / 2, y + unit / 2 + 1);
          x += w + gap;
        }
      }
    }

    c.restore();
    return { left, top, width: totalWidth, height: totalHeight };
  }

  function drawMouse(c, x, y, w, h, unit, keys) {
    const sideInset = Math.round(w * 0.16); // Platz links für die Seitentasten
    const bodyX = x + sideInset;
    const bodyW = w - sideInset;
    const r = bodyW / 2;

    // Gehäuse: oben rund, unten etwas flacher.
    c.beginPath();
    c.moveTo(bodyX, y + r);
    c.arc(bodyX + r, y + r, r, Math.PI, 0);
    c.lineTo(bodyX + bodyW, y + h - r * 0.8);
    c.quadraticCurveTo(bodyX + bodyW, y + h, bodyX + r, y + h);
    c.quadraticCurveTo(bodyX, y + h, bodyX, y + h - r * 0.8);
    c.closePath();
    c.fillStyle = IDLE;
    c.fill();
    c.lineWidth = Math.max(1, unit * 0.05);
    c.strokeStyle = IDLE_LINE;
    c.stroke();

    // Linke und rechte Taste: obere Hälfte des Gehäuses, in der Mitte geteilt.
    const split = y + h * 0.42;
    const mid = bodyX + r;
    const inset = Math.max(2, unit * 0.12);
    const half = (side) => {
      c.beginPath();
      if (side === 'L') {
        c.moveTo(mid - inset / 2, y + inset);
        c.arc(mid, y + r, r - inset, -Math.PI / 2, Math.PI, true);
        c.lineTo(bodyX + inset, split);
        c.lineTo(mid - inset / 2, split);
      } else {
        c.moveTo(mid + inset / 2, y + inset);
        c.arc(mid, y + r, r - inset, -Math.PI / 2, 0, false);
        c.lineTo(bodyX + bodyW - inset, split);
        c.lineTo(mid + inset / 2, split);
      }
      c.closePath();
    };
    for (const [side, key] of [
      ['L', 'M1'],
      ['R', 'M2'],
    ]) {
      half(side);
      const pressed = keys.has(key);
      if (pressed) {
        c.save();
        c.shadowColor = ACCENT;
        c.shadowBlur = unit * 0.6;
        c.fillStyle = ACCENT;
        c.fill();
        c.restore();
      } else {
        c.fillStyle = 'rgba(255,255,255,0.05)';
        c.fill();
      }
      c.lineWidth = Math.max(1, unit * 0.04);
      c.strokeStyle = pressed ? 'rgba(255,255,255,0.75)' : IDLE_LINE;
      c.stroke();
    }

    // Mausrad
    const wheelW = Math.max(4, Math.round(bodyW * 0.16));
    const wheelH = Math.round(h * 0.17);
    const wheelY = y + h * 0.13;
    roundRect(c, mid - wheelW / 2, wheelY, wheelW, wheelH, wheelW / 2);
    const wheel = keys.has('M3');
    c.fillStyle = wheel ? ACCENT : 'rgba(230,236,245,0.45)';
    c.fill();

    // Seitentasten links am Gehäuse: M5 (vorne/oben), M4 (hinten/unten).
    const sideW = Math.round(sideInset + bodyW * 0.22);
    const sideH = Math.round(h * 0.15);
    const sideGap = Math.max(2, Math.round(unit * 0.14));
    const firstY = Math.round(y + h * 0.48);
    c.font = `800 ${Math.round(Math.min(sideH * 0.42, unit * 0.32))}px "Segoe UI", system-ui, sans-serif`;
    for (const [key, sy] of [
      ['M5', firstY],
      ['M4', firstY + sideH + sideGap],
    ]) {
      const pressed = keys.has(key);
      fillKey(c, x, sy, sideW, sideH, Math.round(sideH * 0.32), pressed, ACCENT);
      c.fillStyle = pressed ? ACCENT_TEXT : 'rgba(236,242,250,0.7)';
      c.fillText(key, x + sideW / 2, sy + sideH / 2 + 1);
    }
  }

  /** Zustand zur Zeit `offset` (ms) aus einer Zeitleiste [{o, k}] – plus kurzes Nachleuchten. */
  function stateAt(timeline, offset, glowMs = 140) {
    const lit = new Set();
    if (!Array.isArray(timeline) || timeline.length === 0) return lit;
    let lo = 0;
    let hi = timeline.length - 1;
    let found = -1;
    while (lo <= hi) {
      const m = (lo + hi) >> 1;
      if (timeline[m].o <= offset) {
        found = m;
        lo = m + 1;
      } else {
        hi = m - 1;
      }
    }
    if (found < 0) return lit;
    for (const key of timeline[found].k || []) lit.add(key);
    // Kurze Taps bleiben einen Augenblick sichtbar.
    for (let i = found; i >= 0 && offset - timeline[i].o <= glowMs; i -= 1) {
      if (i > 0) for (const key of timeline[i - 1].k || []) lit.add(key);
    }
    return lit;
  }

  window.KeysOverlay = { draw, stateAt };
})();
