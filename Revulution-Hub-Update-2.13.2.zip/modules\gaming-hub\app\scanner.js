const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const PARSE_TIMEOUT_MS = 180000;
const MIN_FILE_AGE_MS = 60000;
const SCHEMA_VERSION = 4;

function listReplayFiles(dir) {
  try {
    return fs
      .readdirSync(dir)
      .filter((name) => name.toLowerCase().endsWith('.replay'))
      .map((name) => {
        const full = path.join(dir, name);
        let mtimeMs = 0;
        try {
          mtimeMs = fs.statSync(full).mtimeMs;
        } catch {
          mtimeMs = 0;
        }
        return { full, name, mtimeMs };
      })
      .sort((a, b) => b.mtimeMs - a.mtimeMs);
  } catch {
    return [];
  }
}

function parseReplay(parserPath, file) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(parserPath, ['--input', file], { windowsHide: true });
    } catch (error) {
      reject(error);
      return;
    }

    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      try {
        child.kill();
      } catch {
        /* ignore */
      }
      reject(new Error('Zeitüberschreitung beim Parsen'));
    }, PARSE_TIMEOUT_MS);

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });
    child.on('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code !== 0) {
        reject(new Error(stderr.trim() || `Parser beendet mit Code ${code}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout));
      } catch {
        reject(new Error('Parser lieferte ungültiges JSON'));
      }
    });
  });
}

async function scanDirectory({ parserPath, dir, store, onProgress }) {
  const files = listReplayFiles(dir);
  const storedSchemas = new Map(store.data.matches.map((m) => [m.file, Number(m.schema) || 1]));
  const now = Date.now();
  const targets = files.filter((file) => {
    if (now - file.mtimeMs <= MIN_FILE_AGE_MS) return false;
    const schema = storedSchemas.get(file.name);
    if (schema === undefined) return true;
    return schema < SCHEMA_VERSION;
  });

  const summary = {
    found: files.length,
    pending: targets.length,
    parsed: 0,
    skipped: files.length - targets.length,
    failed: [],
  };

  onProgress?.({ phase: 'start', ...summary, current: null });

  for (let index = 0; index < targets.length; index += 1) {
    const file = targets[index];
    onProgress?.({
      phase: 'parsing',
      index: index + 1,
      total: targets.length,
      current: file.name,
      parsed: summary.parsed,
      failed: summary.failed.length,
    });

    try {
      const match = await parseReplay(parserPath, file.full);
      store.upsert(match);
      summary.parsed += 1;
    } catch (error) {
      summary.failed.push({ file: file.name, error: error.message });
    }

    onProgress?.({
      phase: 'progress',
      index: index + 1,
      total: targets.length,
      current: file.name,
      parsed: summary.parsed,
      failed: summary.failed.length,
    });
  }

  store.flush();
  onProgress?.({ phase: 'done', ...summary });
  return summary;
}

module.exports = { listReplayFiles, parseReplay, scanDirectory };
