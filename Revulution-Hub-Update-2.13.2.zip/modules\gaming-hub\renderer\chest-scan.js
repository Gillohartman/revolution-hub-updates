'use strict';

/*
 * Truhen-Erkennung im Spielbild: ein Ausschnitt um das Fadenkreuz geht an die
 * Texterkennung („DURCHSUCHEN“ mit Position), dazu ein Raster mit dem Gold-Anteil
 * je Zelle – Truhen sind golden, Munitionskisten nicht.
 * Nutzt die laufende Clip-Aufnahme; ohne sie öffnet der Zähler eine eigene,
 * die nur Bilder liefert (keine Aufnahme auf der Platte).
 */
(() => {
  const api = window.xh;
  if (!api?.chestsFrame) return;

  // Anteile 0..1 – Hinweis rechts unter dem Fadenkreuz, Todesmeldung unten Mitte.
  // Weit um das Fadenkreuz: der Hinweis hängt in der Welt an der Truhe und wandert mit dem Blickwinkel.
  const PROMPT = { x: 0.28, y: 0.3, w: 0.5, h: 0.5 };
  // XP-Popup („+150 BEHÄLTER GEÖFFNET“) rechts vom Fadenkreuz – nur kurz nach einer Truhe gescannt
  const XP = { x: 0.64, y: 0.3, w: 0.34, h: 0.2 };
  let lastChestAt = 0;
  let xpBusy = false;

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const busy = { prompt: false };
  let enabled = true;
  let gameRunning = false;
  let own = null; // { stream, video }
  let opening = false;
  let timers = [];
  const listeners = new Set();
  let lastPromptPng = null;
  let lastKeys = [];

  /** Bei jedem Druck auf die Interaktionstaste ein Kontrollbild (für die Diagnose). */
  function debugShot() {
    const video = source();
    if (!video || !api.chestsDebugShot) return;
    try {
      const c = document.createElement('canvas');
      c.width = 1280;
      c.height = Math.round(1280 * (video.videoHeight / video.videoWidth));
      c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
      api.chestsDebugShot(c.toDataURL('image/jpeg', 0.75).split(',')[1], lastPromptPng);
    } catch {
      /* egal */
    }
  }
  let chestKey = 'E';
  api.onInput?.((payload) => {
    const keys = payload?.keys || [];
    const wheel = ['M3', 'WheelDown', 'WheelUp'];
    const watch = wheel.includes(chestKey) ? wheel : [chestKey];
    if (gameRunning && enabled && watch.some((k) => keys.includes(k) && !lastKeys.includes(k))) debugShot();
    lastKeys = keys;
  });

  const GRID_COLS = 64;
  const GRID_ROWS = 36;

  /**
   * Ausschnitt für die Texterkennung (nur helle HUD-Schrift bleibt schwarz auf weiß)
   * und dazu ein Raster, wie viel Truhen-Gold in jeder Zelle steckt.
   */
  function crop(video, region, maxWidth, withGold = false) {
    const vw = video.videoWidth;
    const vh = video.videoHeight;
    if (!vw || !vh) return null;
    const sx = Math.round(vw * region.x);
    const sy = Math.round(vh * region.y);
    const sw = Math.round(vw * region.w);
    const sh = Math.round(vh * region.h);
    const factor = Math.min(1.6, maxWidth / sw);
    const dw = Math.max(1, Math.round(sw * factor));
    const dh = Math.max(1, Math.round(sh * factor));
    canvas.width = dw;
    canvas.height = dh;
    ctx.drawImage(video, sx, sy, sw, sh, 0, 0, dw, dh);
    const image = ctx.getImageData(0, 0, dw, dh);
    const data = image.data;
    // Weißabgleich: Farbfilter (Blau-/Lila-Stich) herausrechnen, damit Truhen-Gold gold bleibt.
    let mr = 0, mg = 0, mb = 0, n = 0;
    if (withGold) {
      for (let i = 0; i < data.length; i += 4 * 7) {
        mr += data[i];
        mg += data[i + 1];
        mb += data[i + 2];
        n += 1;
      }
    }
    const avg = n ? (mr + mg + mb) / (3 * n) : 1;
    const kr = n && mr ? (avg * n) / mr : 1;
    const kg = n && mg ? (avg * n) / mg : 1;
    const kb = n && mb ? (avg * n) / mb : 1;
    const isGold = (r, g, b) => r > 190 && g > 140 && b < 120 && r - b > 100 && g - b > 50;
    const goldCount = withGold ? new Float32Array(GRID_COLS * GRID_ROWS) : null;
    const cellW = dw / GRID_COLS;
    const cellH = dh / GRID_ROWS;
    let on = 0;
    for (let i = 0, p = 0; i < data.length; i += 4, p += 1) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      if (goldCount && (isGold(r, g, b) || isGold(Math.min(255, r * kr), Math.min(255, g * kg), Math.min(255, b * kb)))) {
        const x = p % dw;
        const y = (p - x) / dw;
        goldCount[Math.min(GRID_ROWS - 1, Math.floor(y / cellH)) * GRID_COLS + Math.min(GRID_COLS - 1, Math.floor(x / cellW))] += 1;
      }
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const hit = (min > 180 && max - min < 50) || (r > 225 && g > 195 && b < 190);
      if (hit) on += 1;
      const v = hit ? 0 : 255;
      data[i] = v;
      data[i + 1] = v;
      data[i + 2] = v;
      data[i + 3] = 255;
    }
    const share = on / (dw * dh);
    if (share < 0.002 || share > 0.5) return null;
    ctx.putImageData(image, 0, 0);
    const png = canvas.toDataURL('image/png').split(',')[1];
    if (!goldCount) return { png };
    const perCell = cellW * cellH;
    const cells = Array.from(goldCount, (count) => Math.round((count / perCell) * 1000) / 1000);
    return { png, gold: { cols: GRID_COLS, rows: GRID_ROWS, w: dw, h: dh, cells } };
  }

  function source() {
    return window.ClipCapture?.video() || (own?.video.readyState >= 2 ? own.video : null);
  }

  async function scanXp() {
    if (xpBusy || !enabled || !gameRunning || Date.now() - lastChestAt > 6000) return;
    const video = source();
    if (!video) return;
    const cut = crop(video, XP, 700, false);
    if (!cut) return;
    xpBusy = true;
    try {
      await api.chestsFrame(cut.png, 'xp');
    } catch {
      /* egal */
    }
    xpBusy = false;
  }

  async function scan() {
    if (busy.prompt || !enabled || !gameRunning) return;
    const video = source();
    if (!video) return;
    const cut = crop(video, PROMPT, 1100, true);
    if (!cut) return;
    lastPromptPng = cut.png;
    busy.prompt = true;
    try {
      const result = await api.chestsFrame(cut.png, 'prompt', cut.gold);
      for (const fn of listeners) fn('prompt', result);
      if (result?.chest) lastChestAt = Date.now();
    } catch {
      /* Erkennung ist Beiwerk */
    }
    busy.prompt = false;
  }

  /* --------------------------------------------------- eigene Bildquelle */
  async function openOwn() {
    if (own || opening || window.ClipCapture?.video()) return;
    opening = true;
    try {
      const list = await api.captureSources();
      if (!Array.isArray(list) || !list.length) return;
      const game = list.find((s) => /fortnite/i.test(s.name) && !/chrome|edge|firefox|brave|opera|electron/i.test(s.name));
      // Vollbild-Spiele liefern als Fenster oft Schwarz – lieber den Monitor des Spiels.
      const target = (game && list.find((s) => s.kind === 'screen' && String(s.displayId) === String(game.displayId))) || list.find((s) => s.kind === 'screen') || game;
      if (!target) return;
      const ratio = window.devicePixelRatio || 1;
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: target.id,
            maxWidth: Math.round((window.screen?.width || 1920) * ratio),
            maxHeight: Math.round((window.screen?.height || 1080) * ratio),
            maxFrameRate: 10,
          },
        },
      });
      const video = document.createElement('video');
      video.muted = true;
      video.srcObject = stream;
      await video.play().catch(() => {});
      own = { stream, video };
      stream.getVideoTracks()[0]?.addEventListener('ended', closeOwn);
    } catch (error) {
      console.log('[chests] keine Bildquelle:', error.message);
    } finally {
      opening = false;
    }
  }

  function closeOwn() {
    if (!own) return;
    try {
      own.stream.getTracks().forEach((t) => t.stop());
    } catch {
      /* egal */
    }
    own = null;
  }

  /** Eigene Quelle nur, wenn die Clip-Aufnahme nicht läuft; sonst wieder zu. */
  function manageSource() {
    if (!enabled || !gameRunning) return closeOwn();
    if (window.ClipCapture?.video()) return closeOwn();
    openOwn();
  }

  function start() {
    stop();
    timers = [
      setInterval(scan, 160),
      setInterval(scanXp, 320),
      setInterval(manageSource, 4000),
    ];
    manageSource();
  }

  function stop() {
    timers.forEach(clearInterval);
    timers = [];
  }

  api.onGame?.((status) => {
    gameRunning = Boolean(status?.running);
    manageSource();
  });
  api.onChests?.((state) => {
    enabled = state?.settings?.enabled !== false;
    chestKey = state?.settings?.key || chestKey;
    manageSource();
  });
  api.chestsGet?.().then((state) => {
    chestKey = state?.settings?.key || chestKey;
  });
  api.get?.().then((state) => {
    gameRunning = Boolean(state?.meta?.fortniteRunning);
    manageSource();
  });

  window.ChestScan = { onResult: (fn) => listeners.add(fn), offResult: (fn) => listeners.delete(fn), active: () => Boolean(source()) };
  start();
})();
