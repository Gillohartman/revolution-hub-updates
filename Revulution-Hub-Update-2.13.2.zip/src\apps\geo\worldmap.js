'use strict';

/*
 * Weltkarte für das Länder-Quiz und den Lernpfad (alle Länder der Welt).
 *   – Karten-Quiz: Land anklicken und den Namen eintippen; richtig = grün.
 *   – Finde-Modus: ein Name wird genannt, du klickst das Land an.
 *   – Lernpfad: alle Länder, Kontinent für Kontinent in kleinen Einheiten, mit Sternen.
 * Kartendaten: Natural Earth 1:110m (world-atlas, gemeinfrei) – liegt der App bei.
 */
(function () {
  const H = () => window.GeoHost;
  const lang = () => H()?.lang() || 'de';
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const L3 = (de, en, es) => ({ de, en, es })[lang()] || de;

  /* ---------------- Daten laden und dekodieren (TopoJSON) */
  const ALIAS = {
    'W. Sahara': 'EH', 'United States of America': 'US', 'Dem. Rep. Congo': 'CD', 'Dominican Rep.': 'DO', 'Falkland Is.': 'FK', 'Fr. S. Antarctic Lands': 'TF',
    'Central African Rep.': 'CF', Congo: 'CG', 'Eq. Guinea': 'GQ', Palestine: 'PS', Myanmar: 'MM', Turkey: 'TR', 'Solomon Is.': 'SB', 'Bosnia and Herz.': 'BA', Macedonia: 'MK', 'S. Sudan': 'SS',
  };
  const NO_CODE = { 'N. Cyprus': { de: 'Nordzypern', en: 'Northern Cyprus', es: 'Chipre del Norte' }, Somaliland: { de: 'Somaliland', en: 'Somaliland', es: 'Somalilandia' } };
  const norm = (s) => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/ß/g, 'ss').replace(/&/g, ' and ').replace(/[’'`.]/g, '').replace(/[^a-z ]+/g, ' ').replace(/\s+/g, ' ').trim();
  let codeByName = null;
  function a2Of(name) {
    if (ALIAS[name]) return ALIAS[name];
    if (NO_CODE[name]) return '';
    if (!codeByName) {
      codeByName = new Map();
      const en = new Intl.DisplayNames(['en'], { type: 'region' });
      for (let a = 65; a < 91; a += 1)
        for (let b = 65; b < 91; b += 1) {
          const c = String.fromCharCode(a, b);
          let n = '';
          try {
            n = en.of(c);
          } catch {
            continue;
          }
          if (n && n !== c) codeByName.set(norm(n), c);
        }
    }
    return codeByName.get(norm(name)) || '';
  }
  const names = {};
  function displayName(c, l = lang()) {
    if (!c.cc) return NO_CODE[c.en]?.[l] || c.en;
    const key = `${l}|${c.cc}`;
    if (!names[key]) {
      try {
        names[key] = new Intl.DisplayNames([l], { type: 'region' }).of(c.cc);
      } catch {
        names[key] = c.en;
      }
    }
    return names[key];
  }
  /** Welche Antworten zählen als richtig (Deutsch, Englisch, Kurzformen). */
  function answers(c) {
    const set = new Set([norm(displayName(c, 'de')), norm(displayName(c, 'en')), norm(displayName(c, 'es')), norm(c.en)]);
    const extra = { US: ['usa', 'amerika', 'vereinigte staaten', 'us'], GB: ['england', 'grossbritannien', 'uk', 'britain'], CD: ['kongo', 'demokratische republik kongo', 'dr kongo'], CG: ['kongo brazzaville', 'republik kongo'], CZ: ['tschechien', 'tschechische republik'], MM: ['burma', 'birma'], CI: ['elfenbeinkueste', 'ivory coast'], NL: ['holland'], KR: ['korea', 'suedkorea'], KP: ['nordkorea'], AE: ['vae', 'emirate'], BA: ['bosnien'], MK: ['mazedonien'], SZ: ['swasiland'], TL: ['osttimor'] }[c.cc] || [];
    for (const e of extra) set.add(norm(e));
    return set;
  }
  const lev = (a, b) => {
    const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j += 1) d[0][j] = j;
    for (let i = 1; i <= a.length; i += 1)
      for (let j = 1; j <= b.length; j += 1) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[a.length][b.length];
  };
  function isRight(c, typed) {
    const t = norm(typed);
    if (!t) return false;
    for (const a of answers(c)) if (a === t || (a.length >= 6 && lev(a, t) <= (a.length >= 10 ? 2 : 1))) return true;
    return false;
  }

  function continentOf(cc, lon, lat) {
    const fixed = { RU: 'eu', TR: 'eu', CY: 'eu', ER: 'af', EG: 'af', PG: 'oc', SB: 'oc', VU: 'oc', FJ: 'oc', NC: 'oc', GL: 'na', IS: 'eu', KZ: 'as', GE: 'eu', AM: 'as', AZ: 'as', TT: 'sa', FK: 'sa', TF: 'af' }[cc];
    if (fixed) return fixed;
    if (lon < -30) return lat > 12 || (lon < -77 && lat > 7) ? 'na' : 'sa';
    if (lat > 35 && lon < 45 && lon > -25) return 'eu';
    if (lat < 37 && lon > -20 && lon < 52) return lon > 34 && lat > 12 ? 'as' : 'af';
    if (lon > 110 && lat < -10) return 'oc';
    return 'as';
  }

  let world = null;
  async function load() {
    if (world) return world;
    const topo = window.WORLD_TOPO;
    if (!topo) throw new Error('Kartendaten fehlen');
    const [sx, sy] = topo.transform.scale, [tx, ty] = topo.transform.translate;
    const arcs = topo.arcs.map((arc) => {
      let x = 0, y = 0;
      return arc.map(([dx, dy]) => {
        x += dx;
        y += dy;
        return [x * sx + tx, y * sy + ty];
      });
    });
    const ring = (idx) => {
      const pts = [];
      idx.forEach((i, k) => {
        const a = i >= 0 ? arcs[i] : arcs[~i].slice().reverse();
        for (let j = k ? 1 : 0; j < a.length; j += 1) pts.push(a[j]);
      });
      // Längengrade „auffalten“, damit Russland und Fidschi nicht quer über die Karte springen
      for (let j = 1; j < pts.length; j += 1) {
        while (pts[j][0] - pts[j - 1][0] > 180) pts[j] = [pts[j][0] - 360, pts[j][1]];
        while (pts[j][0] - pts[j - 1][0] < -180) pts[j] = [pts[j][0] + 360, pts[j][1]];
      }
      return pts;
    };
    const countries = [];
    for (const g of topo.objects.countries.geometries) {
      const en = g.properties.name;
      if (en === 'Antarctica') continue;
      const polys = g.type === 'Polygon' ? [g.arcs] : g.type === 'MultiPolygon' ? g.arcs : [];
      const rings = polys.flatMap((p) => p.map(ring));
      let d = '', area = 0, cx = 0, cy = 0, best = 0;
      for (const r of rings) {
        d += `M${r.map(([x, y]) => `${X(x).toFixed(2)} ${Y(y).toFixed(2)}`).join('L')}Z`;
        // Mittelpunkt des größten Teils (für Beschriftung und Kontinent)
        let a = 0, mx = 0, my = 0;
        for (let i = 0; i < r.length; i += 1) {
          const [x1, y1] = r[i], [x2, y2] = r[(i + 1) % r.length];
          const f = x1 * y2 - x2 * y1;
          a += f;
          mx += (x1 + x2) * f;
          my += (y1 + y2) * f;
        }
        a /= 2;
        area += Math.abs(a);
        if (Math.abs(a) > best && a) {
          best = Math.abs(a);
          cx = mx / (6 * a);
          cy = my / (6 * a);
        }
      }
      const cc = a2Of(en);
      countries.push({ id: g.id || en, cc, en, d, area, lon: cx, lat: cy, cont: continentOf(cc, cx, cy) });
    }
    world = countries;
    return world;
  }
  const K = 2.6; // Pixel pro Grad
  const X = (lon) => (lon + 180) * K;
  const Y = (lat) => (84 - lat) * K * 1.12;
  const MAP_W = 360 * K, MAP_H = 142 * K * 1.12;

  /* ---------------- Karte zeichnen, Zoomen und Verschieben */
  function mapSvg(list, { cls = () => '', labels = null } = {}) {
    return `<svg class="wm-svg" viewBox="0 0 ${MAP_W} ${MAP_H}" preserveAspectRatio="xMidYMid meet">
      <rect width="${MAP_W}" height="${MAP_H}" class="wm-sea"/>
      <g class="wm-land">${list.map((c) => `<path d="${c.d}" data-c="${esc(c.id)}" class="${cls(c)}"/>`).join('')}</g>
      ${labels ? `<g class="wm-labels">${labels.map((c) => `<text x="${X(c.lon).toFixed(1)}" y="${Y(c.lat).toFixed(1)}">${esc(displayName(c))}</text>`).join('')}</g>` : ''}
    </svg>`;
  }
  /** Ausschnitt in Kartenkoordinaten: [x, y, w, h] */
  function boxOf(list, pad = 0.12) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const c of list) {
      // grobe Ausdehnung aus der Fläche
      const r = Math.max(2, Math.sqrt(c.area) * 0.9);
      x0 = Math.min(x0, X(c.lon - r));
      x1 = Math.max(x1, X(c.lon + r));
      y0 = Math.min(y0, Y(c.lat + r));
      y1 = Math.max(y1, Y(c.lat - r));
    }
    let w = (x1 - x0) * (1 + 2 * pad), h = (y1 - y0) * (1 + 2 * pad);
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    // auf das Seitenverhältnis der Karte bringen, Mitte bleibt Mitte
    if (w / h < MAP_W / MAP_H) w = h * (MAP_W / MAP_H);
    else h = w * (MAP_H / MAP_W);
    return [cx - w / 2, cy - h / 2, w, h];
  }
  function attachPanZoom(host, start) {
    const svg = host.querySelector('.wm-svg');
    let vb = start ? start.slice() : [0, 0, MAP_W, MAP_H];
    let target = vb.slice();
    let raf = 0;
    const apply = () => svg.setAttribute('viewBox', vb.map((v) => v.toFixed(2)).join(' '));
    const animate = () => {
      raf = 0;
      let moving = false;
      for (let i = 0; i < 4; i += 1) {
        const d = target[i] - vb[i];
        if (Math.abs(d) > 0.05) {
          vb[i] += d * 0.25;
          moving = true;
        } else vb[i] = target[i];
      }
      apply();
      if (moving) raf = requestAnimationFrame(animate);
    };
    const kick = () => {
      if (!raf) raf = requestAnimationFrame(animate);
    };
    const clamp = (b) => {
      const cx = b[0] + b[2] / 2, cy = b[1] + b[3] / 2;
      b[2] = Math.max(40, Math.min(MAP_W * 1.1, b[2]));
      b[3] = b[2] * (MAP_H / MAP_W);
      b[0] = cx - b[2] / 2;
      b[1] = cy - b[3] / 2;
      b[0] = Math.max(-MAP_W * 0.1, Math.min(MAP_W - b[2] * 0.4, b[0]));
      b[1] = Math.max(-MAP_H * 0.1, Math.min(MAP_H - b[3] * 0.4, b[1]));
      return b;
    };
    target = clamp(target);
    vb = target.slice();
    apply();
    svg.addEventListener('wheel', (e) => {
      e.preventDefault();
      const r = svg.getBoundingClientRect();
      const s = Math.min(r.width / target[2], r.height / target[3]);
      const ox = (r.width - target[2] * s) / 2, oy = (r.height - target[3] * s) / 2;
      const mx = target[0] + (e.clientX - r.left - ox) / s, my = target[1] + (e.clientY - r.top - oy) / s;
      const f = e.deltaY < 0 ? 0.82 : 1.22;
      const nw = target[2] * f;
      target = clamp([mx - (mx - target[0]) * f, my - (my - target[1]) * f, nw, nw * (MAP_H / MAP_W)]);
      kick();
    }, { passive: false });
    let drag = null;
    svg.addEventListener('pointerdown', (e) => {
      drag = { x: e.clientX, y: e.clientY, b: target.slice(), moved: false };
    });
    window.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const r = svg.getBoundingClientRect();
      const s = Math.min(r.width / target[2], r.height / target[3]);
      const dx = (e.clientX - drag.x) / s, dy = (e.clientY - drag.y) / s;
      if (Math.abs(e.clientX - drag.x) + Math.abs(e.clientY - drag.y) > 4) drag.moved = true;
      if (!drag.moved) return;
      target = clamp([drag.b[0] - dx, drag.b[1] - dy, drag.b[2], drag.b[3]]);
      vb = target.slice();
      apply();
    });
    window.addEventListener('pointerup', () => {
      if (drag) host.dataset.dragged = drag.moved ? '1' : '';
      drag = null;
    });
    return {
      focus(box) {
        target = clamp(box.slice());
        kick();
      },
    };
  }

  /* ---------------- Bildschirm */
  let el = null;
  let run = null;
  function host() {
    if (el) return el;
    el = document.createElement('section');
    el.className = 'screen wm-screen';
    el.id = 'worldmap';
    el.hidden = true;
    document.body.insertBefore(el, document.getElementById('modal-back'));
    el.addEventListener('click', onClick);
    el.addEventListener('keydown', onKey);
    return el;
  }
  function show(html) {
    host().innerHTML = html;
    for (const s of document.querySelectorAll('.screen')) s.hidden = s !== el;
  }
  const state = () => {
    const p = H().profile();
    p.worldmap ||= { best: {}, learn: {} };
    p.worldmap.best ||= {};
    p.worldmap.learn ||= {};
    return p.worldmap;
  };
  const CONT = { eu: L3('Europa', 'Europe', 'Europa'), as: L3('Asien', 'Asia', 'Asia'), af: L3('Afrika', 'Africa', 'África'), na: L3('Nord- & Mittelamerika', 'North & Central America', 'América del Norte'), sa: L3('Südamerika', 'South America', 'América del Sur'), oc: L3('Ozeanien', 'Oceania', 'Oceanía') };
  const CONT_COLOR = { eu: '#38bdf8', as: '#f43f5e', af: '#eab308', na: '#f59e0b', sa: '#22c55e', oc: '#2dd4bf' };

  async function withWorld(fn) {
    show(`<div class="wm-wait">${esc(L3('Karte wird geladen …', 'Loading map …', 'Cargando mapa …'))}</div>`);
    try {
      await load();
    } catch {
      show(`<div class="wm-wait">${esc(L3('Die Weltkarte konnte nicht geladen werden.', 'Could not load the world map.', 'No se pudo cargar el mapa.'))} <button class="btn" data-wm="menu">${esc(L3('Zurück', 'Back', 'Atrás'))}</button></div>`);
      return;
    }
    fn();
  }

  /* ---------------- Karten-Quiz: anklicken & Namen eintippen */
  function startNameQuiz(cont = 'world') {
    const list = world.filter((c) => cont === 'world' || c.cont === cont);
    run = { mode: 'name', cont, list, done: new Map(), sel: null, tries: 0, started: Date.now(), wrong: 0 };
    renderNameQuiz(true);
  }
  function renderNameQuiz(first = false) {
    const r = run;
    const total = r.list.length, ok = [...r.done.values()].filter((v) => v === 'ok').length;
    const selC = r.sel ? world.find((c) => c.id === r.sel) : null;
    const inList = new Set(r.list.map((c) => c.id));
    if (first || !el.querySelector('.wm-svg')) {
      show(`<div class="wm-top"><button class="btn small ghost" data-wm="menu">← ${esc(L3('Menü', 'Menu', 'Menú'))}</button>
          <b>${esc(L3('Länder-Quiz', 'Country quiz', 'Quiz de países'))} · ${esc(r.cont === 'world' ? L3('Ganze Welt', 'Whole world', 'Todo el mundo') : CONT[r.cont])}</b>
          <span class="wm-score" id="wm-score"></span><button class="btn small ghost" data-wm="giveup">${esc(L3('Auflösen', 'Reveal', 'Resolver'))}</button></div>
        <div class="wm-map" id="wm-map">${mapSvg(world, { cls: (c) => (inList.has(c.id) ? 'q' : 'off') })}</div>
        <div class="wm-ask" id="wm-ask"></div>`);
      run.pz = attachPanZoom(el.querySelector('#wm-map'), r.cont === 'world' ? null : boxOf(r.list));
    }
    for (const p of el.querySelectorAll('.wm-land path')) {
      const st = r.done.get(p.dataset.c);
      p.classList.toggle('ok', st === 'ok');
      p.classList.toggle('miss', st === 'miss');
      p.classList.toggle('sel', p.dataset.c === r.sel);
    }
    el.querySelector('#wm-score').textContent = `${ok} / ${total}${r.wrong ? ` · ${r.wrong} ✗` : ''}`;
    const ask = el.querySelector('#wm-ask');
    if (ok + [...r.done.values()].filter((v) => v === 'miss').length >= total) {
      const secs = Math.round((Date.now() - r.started) / 1000);
      const key = `name|${r.cont}`;
      const st = state();
      const pts = H().earn(Math.max(0, ok - (st.best[key] || 0)) + Math.round(ok / 4));
      st.best[key] = Math.max(st.best[key] || 0, ok);
      H().save();
      ask.innerHTML = `<div class="wm-card done"><b>${esc(L3(`Fertig! ${ok} von ${total} Ländern`, `Done! ${ok} of ${total} countries`, `¡Listo! ${ok} de ${total}`))}</b><span>${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')} min${pts ? ` · ◆ +${pts}` : ''}</span><button class="btn primary" data-wm="again">${esc(L3('Nochmal', 'Again', 'Otra vez'))}</button></div>`;
      return;
    }
    if (!selC) {
      ask.innerHTML = `<div class="wm-card hint">${esc(L3('Klick auf ein Land und schreib seinen Namen. Mausrad zoomt, Ziehen verschiebt.', 'Click a country and type its name. Wheel zooms, drag pans.', 'Haz clic en un país y escribe su nombre.'))}</div>`;
      return;
    }
    ask.innerHTML = `<div class="wm-card"><b>${esc(L3('Welches Land ist das?', 'Which country is this?', '¿Qué país es?'))}</b><input class="input" id="wm-in" autocomplete="off" spellcheck="false" placeholder="${esc(L3('Name eingeben …', 'Type the name …', 'Escribe el nombre …'))}" /><button class="btn primary" data-wm="check">OK</button><button class="btn ghost" data-wm="skip">${esc(L3('Weiß ich nicht', "Don't know", 'No sé'))}</button><span class="wm-fb" id="wm-fb"></span></div>`;
    setTimeout(() => el.querySelector('#wm-in')?.focus(), 30);
  }
  function checkName(skip = false) {
    const r = run;
    const c = world.find((x) => x.id === r.sel);
    if (!c) return;
    const val = el.querySelector('#wm-in')?.value || '';
    if (!skip && isRight(c, val)) {
      r.done.set(c.id, 'ok');
      r.sel = null;
      flash(c, true);
      return renderNameQuiz();
    }
    r.tries += 1;
    if (skip || r.tries >= 3) {
      r.done.set(c.id, 'miss');
      r.wrong += 1;
      const fb = el.querySelector('#wm-fb');
      flash(c, false);
      r.sel = null;
      renderNameQuiz();
      H().toast(`${L3('Das war', 'That was', 'Era')} ${displayName(c)}`);
      return fb;
    }
    const fb = el.querySelector('#wm-fb');
    if (fb) fb.textContent = L3(`Nicht ganz – noch ${3 - r.tries} Versuch(e)`, `Not quite – ${3 - r.tries} more`, `Casi – quedan ${3 - r.tries}`);
    el.querySelector('#wm-in')?.select();
  }
  function flash(c, ok) {
    const p = el.querySelector(`.wm-land path[data-c="${CSS.escape(c.id)}"]`);
    if (!p) return;
    p.classList.remove('flash-ok', 'flash-bad');
    void p.getBBox();
    p.classList.add(ok ? 'flash-ok' : 'flash-bad');
  }

  /* ---------------- Finde-Modus (für den Lernpfad) */
  function startFind(list, lesson = null) {
    const order = list.slice().sort(() => Math.random() - 0.5);
    run = { mode: 'find', list, order, i: 0, ok: 0, tries: 0, lesson, answered: null };
    renderFind(true);
  }
  function renderFind(first = false) {
    const r = run;
    const c = r.order[r.i];
    const inList = new Set(r.list.map((x) => x.id));
    if (first) {
      show(`<div class="wm-top"><button class="btn small ghost" data-wm="${r.lesson ? 'path' : 'menu'}">←</button><b id="wm-title"></b><div class="wm-bar"><i id="wm-bar"></i></div><span class="wm-score" id="wm-score"></span></div>
        <div class="wm-map" id="wm-map">${mapSvg(world, { cls: (x) => (inList.has(x.id) ? 'q' : 'off') })}</div><div class="wm-ask" id="wm-ask"></div>`);
      run.pz = attachPanZoom(el.querySelector('#wm-map'), boxOf(r.list));
    }
    el.querySelector('#wm-title').textContent = `${L3('Wo liegt', 'Where is', '¿Dónde está')} ${displayName(c)}?`;
    el.querySelector('#wm-bar').style.width = `${(r.i / r.order.length) * 100}%`;
    el.querySelector('#wm-score').textContent = `${r.i + 1}/${r.order.length}`;
    for (const p of el.querySelectorAll('.wm-land path')) p.classList.remove('sel', 'hintc');
    el.querySelector('#wm-ask').innerHTML = `<div class="wm-card hint">${esc(L3('Klick das Land auf der Karte an.', 'Click the country on the map.', 'Haz clic en el país.'))}${r.tries ? ` <b>${esc(L3(`Versuch ${r.tries + 1}/3`, `Try ${r.tries + 1}/3`, `Intento ${r.tries + 1}/3`))}</b>` : ''}</div>`;
  }
  function pickFind(id) {
    const r = run;
    const c = r.order[r.i];
    const picked = world.find((x) => x.id === id);
    if (!picked) return;
    if (id === c.id) {
      if (!r.tries) r.ok += 1;
      flash(c, true);
      el.querySelector(`.wm-land path[data-c="${CSS.escape(c.id)}"]`)?.classList.add('ok');
      return nextFind();
    }
    r.tries += 1;
    flash(picked, false);
    H().toast(`${L3('Das ist', 'That is', 'Eso es')} ${displayName(picked)}`);
    if (r.tries >= 3) {
      el.querySelector(`.wm-land path[data-c="${CSS.escape(c.id)}"]`)?.classList.add('hintc');
      setTimeout(nextFind, 1300);
      return;
    }
    renderFind();
  }
  function nextFind() {
    const r = run;
    r.tries = 0;
    r.i += 1;
    if (r.i < r.order.length) return renderFind();
    const pct = r.ok / r.order.length;
    let msg = '';
    if (r.lesson) {
      const st = state();
      const stars = pct >= 0.95 ? 3 : pct >= 0.8 ? 2 : pct >= 0.6 ? 1 : 0;
      const before = st.learn[r.lesson.id] || 0;
      const pts = stars > before ? H().earn((stars - before) * 10) : 0;
      st.learn[r.lesson.id] = Math.max(before, stars);
      H().save();
      msg = `<div class="qz-stars">${[1, 2, 3].map((k) => `<i class="${stars >= k ? 'on' : ''}">★</i>`).join('')}</div>${pts ? `<span class="qz-pts">◆ +${pts}</span>` : ''}`;
    }
    el.querySelector('#wm-ask').innerHTML = `<div class="wm-card done"><b>${r.ok} / ${r.order.length} ${esc(L3('beim ersten Versuch', 'on the first try', 'al primer intento'))}</b>${msg}<button class="btn" data-wm="${r.lesson ? 'path' : 'menu'}">${esc(L3('Weiter', 'Continue', 'Seguir'))}</button>${r.lesson ? `<button class="btn primary" data-unit="${r.lesson.id}">${esc(L3('Nochmal', 'Again', 'Otra vez'))}</button>` : ''}</div>`;
  }

  /* ---------------- Lernpfad über alle Länder */
  function units() {
    const out = [];
    for (const cont of ['eu', 'na', 'sa', 'af', 'as', 'oc']) {
      const list = world.filter((c) => c.cont === cont).sort((a, b) => b.area - a.area);
      const n = Math.ceil(list.length / 9);
      for (let k = 0; k < n; k += 1) out.push({ id: `${cont}-${k + 1}`, cont, n: k + 1, of: n, list: list.slice(k * 9, (k + 1) * 9) });
    }
    return out;
  }
  function pathMenu() {
    const st = state();
    const us = units();
    const stars = us.reduce((s, u) => s + (st.learn[u.id] || 0), 0);
    let open = true;
    let lastCont = '';
    show(`<div class="wm-path-wrap"><div class="qz-head"><button class="btn small ghost" data-wm="menu">← ${esc(L3('Zurück', 'Back', 'Atrás'))}</button><h2>${esc(L3('Lernpfad – alle Länder', 'Learning path – all countries', 'Ruta – todos los países'))}</h2></div>
      <p class="muted">${stars} / ${us.length * 3} ★ · ${world.length} ${esc(L3('Länder in', 'countries in', 'países en'))} ${us.length} ${esc(L3('Lektionen', 'lessons', 'lecciones'))}</p>
      <div class="wm-path">${us
        .map((u, i) => {
          const s = st.learn[u.id] || 0;
          const locked = !open;
          if (!s) open = false;
          const head = u.cont !== lastCont ? `<h3 style="--c:${CONT_COLOR[u.cont]}">${esc(CONT[u.cont])}</h3>` : '';
          lastCont = u.cont;
          return `${head}<button class="qz-node ${locked ? 'locked' : ''} ${s ? 'done' : ''}" data-unit="${u.id}" style="--c:${CONT_COLOR[u.cont]};--x:${[0, 46, 70, 46, 0, -46, -70, -46][i % 8]}px"><span class="qz-orb">${locked ? '🔒' : s ? '★' : u.n}</span><span class="qz-ninfo"><b>${esc(CONT[u.cont])} ${u.n}/${u.of}</b><small>${u.list.length} ${esc(L3('Länder', 'countries', 'países'))} · ${[1, 2, 3].map((k) => (s >= k ? '★' : '☆')).join('')}</small></span></button>`;
        })
        .join('')}</div></div>`);
  }
  function unitIntro(u) {
    const inUnit = new Set(u.list.map((c) => c.id));
    show(`<div class="wm-top"><button class="btn small ghost" data-wm="path">←</button><b>${esc(CONT[u.cont])} ${u.n}/${u.of} · ${esc(L3('Präg dir diese Länder ein', 'Memorise these countries', 'Memoriza estos países'))}</b><button class="btn small primary" data-startunit="${u.id}">${esc(L3('Verstanden – abfragen!', 'Got it – quiz me!', '¡Entendido!'))}</button></div>
      <div class="wm-map" id="wm-map">${mapSvg(world, { cls: (c) => (inUnit.has(c.id) ? 'learn' : 'off'), labels: u.list })}</div>
      <div class="wm-chips">${u.list.map((c) => `<span>${esc(displayName(c))}</span>`).join('')}</div>`);
    attachPanZoom(el.querySelector('#wm-map'), boxOf(u.list, 0.25));
  }

  /* ---------------- Ereignisse */
  function onClick(e) {
    const path = e.target.closest('.wm-land path');
    if (path && run && el.dataset.dragged !== '1') {
      if (run.mode === 'name' && path.classList.contains('q') && !run.done.has(path.dataset.c)) {
        run.sel = path.dataset.c;
        run.tries = 0;
        return renderNameQuiz();
      }
      if (run.mode === 'find' && run.order[run.i]) return pickFind(path.dataset.c);
    }
    const su = e.target.closest('[data-startunit]');
    if (su) {
      const u = units().find((x) => x.id === su.dataset.startunit);
      return startFind(u.list, u);
    }
    const unit = e.target.closest('[data-unit]');
    if (unit) {
      if (unit.classList.contains('locked')) return H().toast(L3('Schließe erst die Lektion davor ab.', 'Finish the previous lesson first.', 'Termina antes la lección anterior.'));
      return unitIntro(units().find((x) => x.id === unit.dataset.unit));
    }
    const pick = e.target.closest('[data-wmcont]');
    if (pick) return startNameQuiz(pick.dataset.wmcont);
    const a = e.target.closest('[data-wm]')?.dataset.wm;
    if (!a) return;
    if (a === 'menu') {
      run = null;
      return H().menu();
    }
    if (a === 'path') return pathMenu();
    if (a === 'check') return checkName(false);
    if (a === 'skip') return checkName(true);
    if (a === 'again') return startNameQuiz(run?.cont || 'world');
    if (a === 'giveup' && run?.mode === 'name') {
      for (const c of run.list) if (!run.done.has(c.id)) run.done.set(c.id, 'miss');
      run.wrong = [...run.done.values()].filter((v) => v === 'miss').length;
      run.sel = null;
      return renderNameQuiz();
    }
  }
  function onKey(e) {
    if (e.key === 'Enter' && e.target.id === 'wm-in') checkName(false);
    if (e.key === 'Escape' && run?.mode === 'name' && run.sel) {
      run.sel = null;
      renderNameQuiz();
    }
  }
  function chooser() {
    show(`<div class="wm-path-wrap"><div class="qz-head"><button class="btn small ghost" data-wm="menu">← ${esc(L3('Zurück', 'Back', 'Atrás'))}</button><h2>${esc(L3('Länder-Quiz auf der Weltkarte', 'Country quiz on the world map', 'Quiz en el mapa'))}</h2></div>
      <p class="muted">${esc(L3('Klick auf ein Land und tipp den Namen ein. Wähle, welchen Teil der Welt du schaffen willst:', 'Click a country and type its name. Pick a region:', 'Elige una región:'))}</p>
      <div class="wm-conts">${[['world', L3('Ganze Welt', 'Whole world', 'Todo el mundo'), '#a78bfa'], ...Object.entries(CONT).map(([k, n]) => [k, n, CONT_COLOR[k]])].map(([k, n, col]) => {
        const count = k === 'world' ? world.length : world.filter((c) => c.cont === k).length;
        const best = state().best[`name|${k}`];
        return `<button class="wm-cont" data-wmcont="${k}" style="--c:${col}"><b>${esc(n)}</b><span>${count} ${esc(L3('Länder', 'countries', 'países'))}</span>${best != null ? `<small>${esc(L3('Bestwert', 'Best', 'Mejor'))}: ${best}/${count}</small>` : ''}</button>`;
      }).join('')}</div></div>`);
  }

  window.GeoWorld = {
    openQuiz: () => withWorld(chooser),
    openPath: () => withWorld(pathMenu),
  };
})();
