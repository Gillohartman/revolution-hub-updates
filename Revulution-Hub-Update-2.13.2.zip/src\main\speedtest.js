'use strict';

/*
 * WLAN-/Internet-Geschwindigkeitstest.
 * Misst Ping, Download und Upload gegen die öffentlichen Cloudflare-Speedtest-Server
 * (speed.cloudflare.com) und liest unter Windows die WLAN-Daten (Signal, Band, Funkrate)
 * per „netsh wlan show interfaces“ aus. Danach eine kurze Analyse: woran liegt es?
 *
 * Bewusst zeitbegrenzt (statt feste Datenmenge), damit der Test auch bei sehr langsamem
 * WLAN nach ~20 Sekunden fertig ist und nicht das ganze Datenvolumen verbraucht.
 */
const { execFile } = require('child_process');

const BASE = process.env.HUB_SPEED_URL || 'https://speed.cloudflare.com';
const DOWN_MS = 8000;
const UP_MS = 6000;

let running = null;

function netsh() {
  if (process.platform !== 'win32') return Promise.resolve('');
  return new Promise((resolve) => {
    execFile('netsh', ['wlan', 'show', 'interfaces'], { windowsHide: true, timeout: 8000, encoding: 'latin1' }, (error, stdout) => resolve(error ? '' : String(stdout)));
  });
}

/** netsh ist übersetzt – deshalb Deutsch und Englisch erkennen. */
function parseWlan(text) {
  if (!text || !/SSID/i.test(text)) return null;
  const get = (re) => {
    const m = text.match(re);
    return m ? m[m.length - 1].trim() : '';
  };
  const num = (v) => Number(String(v).replace(',', '.')) || 0;
  const state = get(/^\s*(State|Status)\s*:\s*(.+)$/im);
  if (state && /disconnect|getrennt/i.test(state)) return { connected: false };
  const channel = num(get(/^\s*(Channel|Kanal)\s*:\s*(\d+)/im));
  const bandText = get(/^\s*Band\s*:\s*(.+)$/im);
  const band = /6\s*GHz/i.test(bandText) ? '6 GHz' : /5\s*GHz/i.test(bandText) || channel > 14 ? '5 GHz' : channel ? '2,4 GHz' : bandText || '';
  return {
    connected: true,
    ssid: get(/^\s*SSID\s*:\s*(.+)$/im),
    signal: num(get(/^\s*Signal\s*:\s*(\d+)\s*%/im)),
    rx: num(get(/^\s*(Receive rate|Empfangsrate)[^:]*:\s*([\d.,]+)/im)),
    tx: num(get(/^\s*(Transmit rate|Übertragungsrate|Ubertragungsrate|.bertragungsrate)[^:]*:\s*([\d.,]+)/im)),
    channel,
    band,
    radio: get(/^\s*(Radio type|Funktyp)\s*:\s*(.+)$/im),
  };
}

async function timed(url, options = {}, timeout = 4000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: ctrl.signal, cache: 'no-store' });
  } finally {
    clearTimeout(timer);
  }
}

async function ping(progress) {
  const times = [];
  for (let i = 0; i < 8; i += 1) {
    const t0 = performance.now();
    try {
      const res = await timed(`${BASE}/__down?bytes=0&r=${Math.random()}`, {}, 3000);
      await res.arrayBuffer();
      times.push(performance.now() - t0);
    } catch {
      /* Verlust */
    }
    progress({ phase: 'ping', pct: ((i + 1) / 8) * 100, value: times.length ? Math.min(...times) : null });
  }
  if (!times.length) throw new Error('Keine Verbindung zum Testserver (speed.cloudflare.com).');
  const sorted = [...times].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  const jitter = times.length > 1 ? times.slice(1).reduce((s, t, i) => s + Math.abs(t - times[i]), 0) / (times.length - 1) : 0;
  return { ping: Math.round(median), jitter: Math.round(jitter), loss: Math.round(((8 - times.length) / 8) * 100) };
}

/** Mehrere parallele Downloads, gemessen über eine feste Zeit. */
async function download(progress) {
  const ctrl = new AbortController();
  const start = performance.now();
  let bytes = 0;
  let warm = 0;
  let warmAt = 0;
  const stream = async () => {
    while (!ctrl.signal.aborted) {
      const res = await fetch(`${BASE}/__down?bytes=25000000&r=${Math.random()}`, { signal: ctrl.signal, cache: 'no-store' });
      const reader = res.body.getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        bytes += value.length;
      }
    }
  };
  const timer = setInterval(() => {
    const el = performance.now() - start;
    // die erste Sekunde (TCP-Anlauf) nicht mitzählen
    if (!warmAt && el > 1000) {
      warmAt = performance.now();
      warm = bytes;
    }
    const mbps = warmAt ? ((bytes - warm) * 8) / ((performance.now() - warmAt) / 1000) / 1e6 : (bytes * 8) / (el / 1000) / 1e6;
    progress({ phase: 'down', pct: Math.min(100, (el / DOWN_MS) * 100), value: Math.round(mbps * 10) / 10 });
    // Zeit- und Datenlimit (max. ~250 MB, damit schnelle Leitungen nicht unnötig Volumen ziehen)
    if (el >= DOWN_MS || bytes > 250e6) ctrl.abort();
  }, 200);
  await Promise.allSettled([stream(), stream(), stream(), stream()]);
  clearInterval(timer);
  const secs = warmAt ? (performance.now() - warmAt) / 1000 : (performance.now() - start) / 1000;
  const counted = warmAt ? bytes - warm : bytes;
  if (!bytes) throw new Error('Download fehlgeschlagen.');
  return { down: Math.round(((counted * 8) / secs / 1e6) * 10) / 10, downMB: Math.round((bytes / 1e6) * 10) / 10 };
}

async function upload(progress) {
  const start = performance.now();
  const chunk = new Uint8Array(1_000_000);
  let bytes = 0;
  let stop = false;
  const timer = setInterval(() => {
    const el = performance.now() - start;
    progress({ phase: 'up', pct: Math.min(100, (el / UP_MS) * 100), value: Math.round(((bytes * 8) / (el / 1000) / 1e6) * 10) / 10 });
    if (el >= UP_MS) stop = true;
  }, 200);
  const stream = async () => {
    while (!stop) {
      try {
        const res = await timed(`${BASE}/__up?r=${Math.random()}`, { method: 'POST', body: chunk, headers: { 'Content-Type': 'application/octet-stream' } }, UP_MS + 4000);
        await res.arrayBuffer().catch(() => null);
        if (!stop || performance.now() - start < UP_MS + 3000) bytes += chunk.length;
      } catch {
        break;
      }
    }
  };
  await Promise.allSettled([stream(), stream(), stream()]);
  clearInterval(timer);
  const secs = (performance.now() - start) / 1000;
  return { up: bytes ? Math.round(((bytes * 8) / secs / 1e6) * 10) / 10 : 0 };
}

/** Woran liegt es? Kurze, verständliche Gründe. */
function analyse(r) {
  const tips = [];
  const add = (sev, title, text) => tips.push({ sev, title, text });
  const w = r.wlan;
  if (w?.connected) {
    if (w.signal && w.signal < 40) add(3, 'Sehr schwaches WLAN-Signal', `Nur ${w.signal} % Signal. Geh näher an den Router, stell den Router höher/frei hin oder nutze einen Repeater bzw. ein LAN-Kabel.`);
    else if (w.signal && w.signal < 65) add(2, 'Mittelmäßiges WLAN-Signal', `${w.signal} % Signal – Wände, Möbel und Abstand bremsen. Näher an den Router oder ein Mesh/Repeater hilft.`);
    if (w.band === '2,4 GHz') add(2, 'Langsames 2,4-GHz-Band', 'Du bist im 2,4-GHz-WLAN. Das reicht weit, ist aber langsam und oft überfüllt. Wenn dein Router 5 GHz kann, verbinde dich damit (oft ein zweites WLAN mit „5G“ im Namen).');
    if (w.rx && w.rx < 72) add(2, 'Niedrige Funkrate', `Dein PC und der Router verbinden sich nur mit ${w.rx} MBit/s. Mehr als das kommt nie an – das liegt am Signal oder einem alten WLAN-Adapter.`);
    if (w.rx && r.down && w.rx > 0 && r.down < w.rx * 0.15 && w.signal >= 65) add(2, 'WLAN gut, Internet langsam', `Die Funkverbindung schafft ${w.rx} MBit/s, im Internet kommen aber nur ${String(r.down).replace('.', ',')} MBit/s an. Dann bremst eher der Internet-Anschluss, ein Download/Update im Hintergrund oder ein anderes Gerät im Netz.`);
  } else if (w && !w.connected) add(1, 'Kein WLAN', 'Du bist gerade über Kabel oder gar nicht per WLAN verbunden.');
  if (r.ping >= 100) add(2, 'Hoher Ping', `${r.ping} ms Verzögerung – in Spielen merkst du das. Ursache meist schwaches WLAN oder ein voll ausgelastetes Netz.`);
  if (r.jitter >= 30) add(1, 'Schwankende Verbindung', `Der Ping schwankt um ${r.jitter} ms. Typisch für WLAN mit Störungen (Nachbar-WLANs, Mikrowelle, Wände).`);
  if (r.loss > 0) add(2, 'Paketverlust', `${r.loss} % der Anfragen gingen verloren – die Verbindung bricht kurz ab.`);
  if (r.down != null && r.down < 5) add(3, 'Sehr langsamer Download', `${String(r.down).replace('.', ',')} MBit/s – damit dauern Downloads und Updates lange, Videos ruckeln. Prüfe, ob gerade etwas im Hintergrund lädt (Steam, Windows Update, OneDrive …).`);
  else if (r.down != null && r.down < 25) add(1, 'Eher langsamer Download', `${String(r.down).replace('.', ',')} MBit/s reichen für Surfen und Videos, große Downloads dauern aber.`);
  tips.sort((a, b) => b.sev - a.sev);
  const grade = r.down >= 100 ? 'Sehr schnell' : r.down >= 50 ? 'Schnell' : r.down >= 25 ? 'Gut' : r.down >= 10 ? 'Okay' : r.down >= 3 ? 'Langsam' : 'Sehr langsam';
  return { tips, grade };
}

async function wlanInfo() {
  return parseWlan(await netsh());
}

async function run(progress = () => {}) {
  if (running) return running;
  running = (async () => {
    const result = { at: Date.now() };
    progress({ phase: 'wlan', pct: 0 });
    result.wlan = await wlanInfo();
    Object.assign(result, await ping(progress));
    Object.assign(result, await download(progress));
    Object.assign(result, await upload(progress).catch(() => ({ up: null })));
    Object.assign(result, analyse(result));
    progress({ phase: 'done', pct: 100 });
    return result;
  })().finally(() => setTimeout(() => (running = null), 0));
  return running;
}

module.exports = { run, wlanInfo, parseWlan, analyse };
