'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('geoApp', {
  load: () => ipcRenderer.invoke('load'),
  save: (profile) => ipcRenderer.invoke('save', profile),
  findPano: (q) => ipcRenderer.invoke('pano:find', q),
});
contextBridge.exposeInMainWorld('hubProfile', {
  get: () => ipcRenderer.invoke('hp:get'),
  name: (v) => ipcRenderer.invoke('hp:name', v),
  earn: (n) => ipcRenderer.invoke('hp:earn', n),
  shop: () => ipcRenderer.invoke('hp:shop'),
});

// Chats: Gegner anschreiben oder als Freund hinzufügen (je nach dessen Einstellungen)
contextBridge.exposeInMainWorld('hubChat', {
  identity: () => ipcRenderer.invoke('hc:identity'),
  dm: (peer) => ipcRenderer.invoke('hc:dm', peer),
  friend: (peer) => ipcRenderer.invoke('hc:friend', peer),
});
