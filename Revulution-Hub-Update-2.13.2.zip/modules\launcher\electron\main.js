"use strict";

const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage, nativeTheme } = global.__revolutionHub.shim("launcher");
const path = require("node:path");
const fs = require("node:fs");
const fsp = require("node:fs/promises");

// Only load from the Vite dev server when explicitly asked to; `electron .` otherwise
// runs the built bundle so a missing dev server can never leave a blank window.
const DEV = process.env.REVOLUTION_DEV === "1";
const HEADLESS = process.env.REVOLUTION_HEADLESS === "1";
const DEV_SERVER_URL = process.env.REVOLUTION_DEV_SERVER_URL || "http://localhost:5273";

let mainWindow = null;
let core = null;

/** Lazily load the ESM core modules from the CJS main process. */
async function loadCore() {
  if (core) return core;
  const [
    paths, store, instances, mojang, install, java, auth, loaders, launch, content, http, perf, servers,
  ] = await Promise.all([
    import("../src/core/paths.mjs"),
    import("../src/core/store.mjs"),
    import("../src/core/instances.mjs"),
    import("../src/core/mojang.mjs"),
    import("../src/core/install.mjs"),
    import("../src/core/java.mjs"),
    import("../src/core/auth.mjs"),
    import("../src/core/loaders.mjs"),
    import("../src/core/launch.mjs"),
    import("../src/core/content.mjs"),
    import("../src/core/http.mjs"),
    import("../src/core/perf.mjs"),
    import("../src/core/servers.mjs"),
  ]);
  core = { paths, store, instances, mojang, install, java, auth, loaders, launch, content, http, perf, servers };
  core.paths.ensureDirs();
  return core;
}

function send(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
}

/* ------------------------------------------------------------- accounts */

function accountsPath() {
  return core.paths.accountsFile();
}

/**
 * True when the store on disk exists but this process could not read it. Electron's
 * safeStorage key is bound to the application identity, so a store written by a build
 * with a different name (or on a different OS account) cannot be decrypted here. The
 * flag makes `writeAccounts` preserve that file instead of silently replacing it.
 */
let accountStoreUnreadable = false;

function readAccounts() {
  const file = accountsPath();
  if (!fs.existsSync(file)) return { accounts: [], active: "" };
  try {
    const raw = fs.readFileSync(file, "utf8");
    let json = raw;
    if (raw.startsWith("enc:")) {
      if (!safeStorage.isEncryptionAvailable()) throw new Error("encrypted account data is not readable on this system");
      json = safeStorage.decryptString(Buffer.from(raw.slice(4), "base64"));
    }
    const store_ = parseAccountStore(json);
    accountStoreUnreadable = false;
    return store_;
  } catch (error) {
    // Never fail silently: a user with an unreadable store must learn why instead of
    // being told that no account exists.
    accountStoreUnreadable = true;
    return {
      accounts: [],
      active: "",
      error: `The saved accounts could not be read (${error.message}). The file is kept as a backup — sign in again to add an account.`,
    };
  }
}

/** The stored shape is small and fixed; validate it instead of trusting the file. */
function parseAccountStore(json) {
  const parsed = JSON.parse(json);
  if (!parsed || !Array.isArray(parsed.accounts)) throw new Error("unexpected account store shape");
  return { accounts: parsed.accounts, active: typeof parsed.active === "string" ? parsed.active : "" };
}

function writeAccounts(data) {
  const file = accountsPath();
  // Preserve a store we could not read rather than overwriting it, so switching between
  // builds (or OS accounts) can never destroy a saved login.
  if (accountStoreUnreadable && fs.existsSync(file)) {
    const backup = `${file}.unreadable-${Date.now()}.bak`;
    try {
      fs.renameSync(file, backup);
      console.warn(`[revolution] account store was unreadable; kept a copy at ${backup}`);
    } catch (error) {
      console.warn(`[revolution] could not preserve the unreadable account store: ${error.message}`);
    }
    accountStoreUnreadable = false;
  }
  const json = JSON.stringify(data, null, 2);
  if (safeStorage.isEncryptionAvailable()) {
    fs.writeFileSync(file, `enc:${safeStorage.encryptString(json).toString("base64")}`, "utf8");
  } else {
    fs.writeFileSync(file, json, "utf8");
  }
  return data;
}

function publicAccount(account) {
  if (!account) return null;
  const { accessToken, refreshToken, msAccessToken, ...safe } = account;
  return { ...safe, hasToken: Boolean(accessToken) };
}

async function resolveAccount(accountId, { forLaunch = true } = {}) {
  const store_ = readAccounts();
  const targetId = accountId || store_.active;
  let account = store_.accounts.find((a) => a.id === targetId);
  if (!account) throw new Error("No account selected. Add one in the Accounts tab.");
  if (forLaunch && core.auth.accountNeedsRefresh(account)) {
    const settings = await readSettings();
    try {
      const refreshed = await core.auth.refreshAccount(account, settings.microsoftClientId);
      refreshed.id = account.id;
      const index = store_.accounts.findIndex((a) => a.id === account.id);
      store_.accounts[index] = refreshed;
      writeAccounts(store_);
      account = refreshed;
      send("accounts:changed", store_.accounts.map(publicAccount));
    } catch (err) {
      if (account.type === "offline") return account;
      throw new Error(`Your Minecraft session expired and could not be refreshed (${err.message}). Sign in again in the Accounts tab.`);
    }
  }
  return account;
}

/* ------------------------------------------------------------- settings */

async function readSettings() {
  const c = await loadCore();
  const stored = await c.store.readJson(c.paths.settingsFile(), {});
  return c.store.mergeSettings(stored, {});
}

/**
 * Settings writes are read-merge-write, so two changes made in quick succession (a user clicking
 * theme and accent in the same moment) can interleave: the second reads the pre-first state and
 * writes it back, silently dropping the first change. Chaining the writes keeps every patch.
 */
let settingsWriteQueue = Promise.resolve();

function writeSettings(patch) {
  const write = settingsWriteQueue.then(async () => {
    const c = await loadCore();
    const current = await readSettings();
    const next = c.store.mergeSettings(current, patch);
    await c.store.writeJson(c.paths.settingsFile(), next);
    return next;
  });
  // Keep the queue alive even when one write fails; the caller still sees the rejection.
  settingsWriteQueue = write.then(() => undefined, () => undefined);
  return write;
}

/* ------------------------------------------------------- install + launch */

const runningGames = new Map(); // instanceId -> { child, promise, startedAt }
const jobs = new Map(); // jobId -> { cancelled }

function progressFor(jobId, instanceId) {
  return (payload) => {
    const job = jobs.get(jobId);
    if (job?.cancelled) return;
    send("progress", { jobId, instanceId, ...payload });
  };
}

/**
 * Ensure everything needed to launch is present: game files, assets, natives,
 * and a compatible Java runtime (downloading one when the user allows it).
 */
async function ensureLaunchReady({ instance, onProgress, jobId }) {
  const c = await loadCore();
  const settings = await readSettings();
  const versionJson = await c.mojang.getVersionJson(instance.versionId);
  // Resolve first: loader profiles declare no javaVersion of their own.
  const requirement = await c.java.requiredJavaFor(versionJson);
  const requiredMajor = requirement.major;

  const installations = await c.java.listJavaInstallations();
  const preferred = instance.java?.path || settings.javaPath;
  let chosen = c.java.pickJava(installations, requiredMajor, { preferredPath: preferred });
  if (!chosen && (instance.java?.autoDownloadJava ?? settings.javaAutoDownload)) {
    onProgress({ phase: "java", message: `Downloading Java ${requiredMajor} for Minecraft ${instance.versionId}` });
    const runtime = await c.java.installJavaRuntime(requiredMajor, { onProgress });
    chosen = { path: runtime.binary, major: requiredMajor, vendor: "Eclipse Temurin", valid: true, version: "" };
  }
  if (!chosen) {
    throw new Error(`No compatible Java ${requiredMajor} runtime was found. Install Java ${requiredMajor} or enable automatic downloads in Settings.`);
  }

  onProgress({ phase: "files", message: `Verifying Minecraft ${instance.versionId}` });
  await c.install.installVersion(instance.versionId, {
    onProgress,
    concurrency: settings.concurrentDownloads || 12,
  });

  return { versionJson, resolved: requirement.resolved, javaPath: chosen.path, javaMajor: chosen.major };
}

async function launchInstance({ instanceId, accountId, jobId }) {
  const c = await loadCore();
  const instance = await c.instances.getInstance(instanceId);
  if (!instance.versionId) throw new Error("This instance has no Minecraft version. Set one in the instance settings.");
  const account = await resolveAccount(accountId);
  const settings = await readSettings();
  const onProgress = progressFor(jobId, instanceId);

  if (runningGames.has(instanceId)) throw new Error(`"${instance.name}" is already running.`);

  const { resolved, javaPath, javaMajor } = await ensureLaunchReady({ instance, onProgress, jobId });

  // Fast start and a large view distance: options.txt profile plus the optimisation mods.
  // A missing network or an unsupported loader must never block the launch itself.
  try {
    const perf = await c.perf.preparePerformance({ instance, settings, onProgress });
    if (perf.mods?.length) {
      send("launch:log", { instanceId, line: `# performance: added ${perf.mods.join(", ")}`, stream: "system" });
    }
    send("launch:log", {
      instanceId,
      line: `# performance: render distance ${perf.renderDistance}, simulation distance ${perf.simulationDistance}${perf.bobby ? ", Bobby active" : ""}`,
      stream: "system",
    });
  } catch (err) {
    send("launch:log", { instanceId, line: `# performance setup skipped: ${err.message}`, stream: "system" });
  }

  const command = c.launch.buildLaunchCommand({
    version: resolved,
    instance,
    account,
    settings,
    javaPath,
    javaMajor,
  });

  if (settings.showConsoleOnLaunch) send("console:show", { instanceId });

  const label = `Launching ${instance.name} with ${account.name}`;
  onProgress({ phase: "launch", message: label, done: 1, total: 1 });
  send("launch:log", { instanceId, line: `# ${label}`, stream: "system" });

  const started = c.launch.spawnGame({
    command,
    instance,
    onLog: (line, stream) => send("launch:log", { instanceId, line, stream }),
    onExit: async ({ code, playTimeMs, logFile, error }) => {
      runningGames.delete(instanceId);
      send("launch:exit", { instanceId, code, playTimeMs, logFile, error });
      try {
        const current = await c.instances.getInstance(instanceId);
        await c.instances.updateInstance(instanceId, {
          lastPlayed: Date.now(),
          playTimeMs: (current.playTimeMs || 0) + (playTimeMs || 0),
          lastExitCode: code,
        });
      } catch { /* instance may have been deleted while playing */ }
    },
  });

  runningGames.set(instanceId, { child: started.child, startedAt: started.startedAt, logFile: started.logFile });
  await c.instances.updateInstance(instanceId, { launchCount: (instance.launchCount || 0) + 1, lastPlayed: Date.now() });

  return { pid: started.pid, logFile: started.logFile, command: command.command };
}

/* ----------------------------------------------------------------- window */

/** App icon: the packaged build takes it from the exe, dev builds need it explicitly. */
function appIconPath() {
  const file = path.join(__dirname, "..", "build", "icon.png");
  return fs.existsSync(file) ? file : undefined;
}

function createWindow() {
  mainWindow = global.__revolutionHub.view("launcher", {
    width: 1360,
    height: 860,
    minWidth: 1020,
    minHeight: 640,
    show: false,
    backgroundColor: "#0e0f15",
    icon: appIconPath(),
    frame: false,
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "hidden",
    trafficLightPosition: { x: 14, y: 16 },
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });

  mainWindow.once("ready-to-show", () => {
    if (!HEADLESS) mainWindow.show();
  });

  // Surface renderer errors in the terminal (and in packaged builds, the app log).
  mainWindow.webContents.on("console-message", (_event, level, message, line, source) => {
    if (DEV || level >= 2) console.log(`[renderer:${level}] ${message} (${source}:${line})`);
  });
  mainWindow.webContents.on("render-process-gone", (_event, details) => {
    console.error("[revolution] renderer process gone:", details.reason);
  });

  if (DEV) {
    mainWindow.loadURL(DEV_SERVER_URL);
  } else {
    mainWindow.loadFile(path.join(__dirname, "..", "dist", "index.html"));
  }

  mainWindow.on("closed", () => {
    mainWindow = null;
  });

  return mainWindow;
}

// Revolution Hub: the hub owns the window, the single-instance lock and the app lifecycle.
app.whenReady().then(async () => {
  await loadCore();
  nativeTheme.themeSource = "dark";
  createWindow();
});

app.on("before-quit", () => {
  for (const [, game] of runningGames) {
    try {
      game.child.kill();
    } catch { /* already gone */ }
  }
});

/* -------------------------------------------------------------------- IPC */

function handle(channel, fn) {
  ipcMain.handle(channel, async (_event, ...args) => {
    try {
      const data = await fn(...args);
      return { ok: true, data };
    } catch (err) {
      return { ok: false, error: err?.message || String(err), code: err?.code };
    }
  });
}

// --- app / window
handle("app:info", async () => {
  const c = await loadCore();
  return {
    name: "Revolution",
    version: app.getVersion(),
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    node: process.versions.node,
    platform: process.platform,
    arch: process.arch,
    dataDir: c.paths.dataDir(),
    dev: DEV,
  };
});
handle("window:minimize", async () => { mainWindow?.minimize(); return true; });
handle("window:maximize", async () => {
  if (!mainWindow) return false;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
  return mainWindow.isMaximized();
});
handle("window:close", async () => { mainWindow?.close(); return true; });
handle("shell:openExternal", async (url) => { await shell.openExternal(url); return true; });
handle("shell:openPath", async (target) => { const result = await shell.openPath(target); if (result) throw new Error(result); return true; });
handle("shell:showItem", async (target) => { shell.showItemInFolder(target); return true; });

// --- dialogs
handle("dialog:openFile", async ({ title, filters, multi } = {}) => {
  const result = await dialog.showOpenDialog(mainWindow, { title, filters, properties: multi ? ["openFile", "multiSelections"] : ["openFile"] });
  return result.canceled ? null : result.filePaths;
});
handle("dialog:saveFile", async ({ title, defaultPath, filters } = {}) => {
  const result = await dialog.showSaveDialog(mainWindow, { title, defaultPath, filters });
  return result.canceled ? null : result.filePath;
});
handle("dialog:openDirectory", async ({ title } = {}) => {
  const result = await dialog.showOpenDialog(mainWindow, { title, properties: ["openDirectory", "createDirectory"] });
  return result.canceled ? null : result.filePaths[0];
});

// --- settings
handle("settings:get", () => readSettings());
handle("settings:update", (patch) => writeSettings(patch));

// --- updates: Revolution Hub is updated as a whole, so the launcher's own updater is off.
const UPDATE_STATE = { status: "unconfigured", currentVersion: app.getVersion(), availableVersion: "", releaseNotes: "", progress: 0, transferred: 0, total: 0, bytesPerSecond: 0, error: "", feedUrl: "", feedSource: "none", portable: false, canInstall: false, lastChecked: 0 };
handle("updates:state", () => ({ ...UPDATE_STATE }));
handle("updates:check", () => ({ ...UPDATE_STATE }));
handle("updates:download", () => ({ ...UPDATE_STATE }));
handle("updates:install", () => { throw new Error("Updates kommen mit dem Revolution Hub."); });

// --- instances
handle("instances:list", async () => {
  const c = await loadCore();
  return c.instances.listInstances();
});
handle("instances:get", async (id) => (await loadCore()).instances.getInstance(id));
handle("instances:create", async (patch) => (await loadCore()).instances.createInstance(patch));
handle("instances:update", async (id, patch) => (await loadCore()).instances.updateInstance(id, patch));
handle("instances:delete", async (id) => (await loadCore()).instances.deleteInstance(id));
handle("instances:duplicate", async (id, options) => (await loadCore()).instances.duplicateInstance(id, options || {}));
handle("instances:size", async (id) => (await loadCore()).instances.instanceSize(id));
handle("instances:openFolder", async (id, sub) => {
  const c = await loadCore();
  const base = sub ? path.join(c.paths.gameDir(id), sub) : c.paths.gameDir(id);
  c.paths.ensureDir(base);
  const error = await shell.openPath(base);
  if (error) throw new Error(error);
  return true;
});
handle("instances:untracked", async (id) => (await loadCore()).content.scanUntracked(id));
handle("instances:export", async (id, destFile, options) => (await loadCore()).instances.exportInstance(id, destFile, options || {}));
handle("instances:import", async (file, options) => {
  const c = await loadCore();
  if (/\.mrpack$/i.test(file)) return c.content.installModpack({ mrpackPath: file, name: options?.name });
  return c.instances.importInstanceArchive(file, options || {});
});

handle("perf:boost", async (payload) => {
  const { instanceId, jobId } = payload || {};
  const c = await loadCore();
  const instance = await c.instances.getInstance(instanceId);
  const settings = await readSettings();
  return c.perf.preparePerformance({
    instance,
    settings,
    onProgress: progressFor(jobId || `perf-${instanceId}`, instanceId),
  });
});

// --- versions / metadata
handle("versions:list", async (options) => (await loadCore()).mojang.listVersions(options || {}));
handle("versions:manifest", async (options) => (await loadCore()).mojang.getVersionManifest(options || {}));
handle("versions:json", async (id) => (await loadCore()).mojang.getVersionJson(id));
handle("versions:verify", async (versionId) => (await loadCore()).install.verifyVersion(versionId));
handle("versions:install", async (versionId, options) => {
  const c = await loadCore();
  const jobId = options?.jobId || `install-${versionId}`;
  return c.install.installVersion(versionId, { onProgress: progressFor(jobId, options?.instanceId), skipAssets: options?.skipAssets });
});

// --- java
handle("java:list", async () => (await loadCore()).java.listJavaInstallations());
handle("java:install", async (major, options) => {
  const c = await loadCore();
  const jobId = options?.jobId || `java-${major}`;
  return c.java.installJavaRuntime(major, { onProgress: progressFor(jobId, null) });
});
handle("java:test", async (binary) => (await loadCore()).java.testJava(binary));

// --- loaders
handle("loaders:list", async () => (await loadCore()).loaders.LOADERS);
handle("loaders:versions", async (type, mcVersion) => (await loadCore()).loaders.listLoaderVersions(type, mcVersion));
handle("loaders:install", async ({ mcVersion, type, loaderVersion, javaPath, instanceId, jobId }) => {
  const c = await loadCore();
  return c.loaders.installLoader({ mcVersion, type, loaderVersion, javaPath, onProgress: progressFor(jobId, instanceId) });
});
handle("loaders:installJar", async ({ jarPath, javaPath, jobId }) => {
  const c = await loadCore();
  return c.loaders.installFromInstallerJar({ jarPath, javaPath, onProgress: progressFor(jobId, null) });
});

// --- accounts
handle("accounts:list", async () => {
  const store_ = readAccounts();
  return { accounts: store_.accounts.map(publicAccount), active: store_.active, error: store_.error };
});
handle("accounts:addOffline", async (name) => {
  const c = await loadCore();
  const account = c.auth.offlineAccount(name);
  const store_ = readAccounts();
  if (store_.accounts.some((a) => a.type === "offline" && a.name.toLowerCase() === account.name.toLowerCase())) {
    throw new Error(`An offline account named ${account.name} already exists.`);
  }
  store_.accounts.push(account);
  if (!store_.active) store_.active = account.id;
  writeAccounts(store_);
  send("accounts:changed", store_.accounts.map(publicAccount));
  return { account: publicAccount(account), active: store_.active };
});
handle("accounts:remove", async (id) => {
  const store_ = readAccounts();
  store_.accounts = store_.accounts.filter((a) => a.id !== id);
  if (store_.active === id) store_.active = store_.accounts[0]?.id || "";
  writeAccounts(store_);
  send("accounts:changed", store_.accounts.map(publicAccount));
  return { accounts: store_.accounts.map(publicAccount), active: store_.active };
});
handle("accounts:setActive", async (id) => {
  const store_ = readAccounts();
  if (!store_.accounts.some((a) => a.id === id)) throw new Error("Account not found.");
  store_.active = id;
  const account = store_.accounts.find((a) => a.id === id);
  account.lastUsed = Date.now();
  writeAccounts(store_);
  await writeSettings({ selectedAccount: id });
  send("accounts:changed", store_.accounts.map(publicAccount));
  return { active: id };
});
handle("accounts:deviceCode", async ({ clientId } = {}) => {
  const c = await loadCore();
  const settings = await readSettings();
  return c.auth.startDeviceCode({ clientId: clientId || settings.microsoftClientId });
});
/** Lets the dialog's Cancel button stop a pending device-code poll instead of leaving it
 * running until it times out fifteen minutes later. */
let msaSignIn = null;
handle("accounts:loginMicrosoft", async ({ deviceCode, interval, expiresIn, clientId, jobId }) => {
  const c = await loadCore();
  const settings = await readSettings();
  msaSignIn = new AbortController();
  try {
    const tokens = await c.auth.pollDeviceCode({
      clientId: clientId || settings.microsoftClientId,
      deviceCode,
      interval,
      expiresIn,
      signal: msaSignIn.signal,
      onTick: (tick) => send("progress", { jobId: jobId || "msa-login", phase: "auth", ...tick }),
    });
    const login = await c.auth.completeMinecraftLogin(tokens, {
      onProgress: (p) => send("progress", { jobId: jobId || "msa-login", ...p }),
    });
    const store_ = readAccounts();
    const existing = store_.accounts.find((a) => a.type === "msa" && a.uuid === login.profile.id);
    const account = c.auth.toAccount(login, { previous: existing });
    if (existing) store_.accounts[store_.accounts.findIndex((a) => a.id === existing.id)] = account;
    else store_.accounts.push(account);
    if (!store_.active) store_.active = account.id;
    writeAccounts(store_);
    send("accounts:changed", store_.accounts.map(publicAccount));
    return { account: publicAccount(account), active: store_.active };
  } finally {
    msaSignIn = null;
  }
});
handle("accounts:cancelLogin", async () => {
  msaSignIn?.abort();
  msaSignIn = null;
  return { cancelled: true };
});
handle("accounts:refresh", async (id) => {
  const store_ = readAccounts();
  const settings = await readSettings();
  const account = store_.accounts.find((a) => a.id === id);
  if (!account) throw new Error("Account not found.");
  if (account.type === "offline") return publicAccount(account);
  const refreshed = await core.auth.refreshAccount(account, settings.microsoftClientId);
  refreshed.id = account.id;
  store_.accounts[store_.accounts.findIndex((a) => a.id === account.id)] = refreshed;
  writeAccounts(store_);
  send("accounts:changed", store_.accounts.map(publicAccount));
  return publicAccount(refreshed);
});

// --- game
handle("game:preview", async (instanceId, accountId) => {
  const c = await loadCore();
  const instance = await c.instances.getInstance(instanceId);
  const account = await resolveAccount(accountId, { forLaunch: false });
  const settings = await readSettings();
  const versionJson = await c.mojang.getVersionJson(instance.versionId || instance.mcVersion);
  const requirement = await c.java.requiredJavaFor(versionJson);
  const installations = await c.java.listJavaInstallations();
  const chosen = c.java.pickJava(installations, requirement.major, { preferredPath: instance.java?.path || settings.javaPath });
  return c.launch.buildLaunchCommand({
    version: requirement.resolved,
    instance,
    account,
    settings,
    javaPath: chosen?.path || "<java>",
    javaMajor: requirement.major,
  });
});
/** Install + launch in the background: progress and logs stream over events, so the
 * renderer is never blocked waiting for downloads to finish. Shared by Play and Join. */
function queueLaunch(instanceId, accountId) {
  const jobId = `launch-${instanceId}-${Date.now()}`;
  jobs.set(jobId, { startedAt: Date.now() });
  launchInstance({ instanceId, accountId, jobId })
    .then((result) => {
      send("progress", { jobId, instanceId, phase: "running", message: "Minecraft is running", done: 1, total: 1 });
      send("launch:started", { instanceId, ...result });
    })
    .catch((err) => {
      send("progress", { jobId, instanceId, phase: "error", message: err.message });
      send("launch:failed", { instanceId, error: err.message });
    })
    .finally(() => jobs.delete(jobId));
  return jobId;
}

handle("game:launch", async (instanceId, accountId) => ({
  jobId: queueLaunch(instanceId, accountId),
  started: true,
}));
handle("game:kill", async (instanceId) => {
  const game = runningGames.get(instanceId);
  if (!game) return { killed: false };
  game.child.kill();
  return { killed: true };
});
handle("game:status", async () => Array.from(runningGames.keys()));
handle("game:logs", async (instanceId) => {
  const game = runningGames.get(instanceId);
  if (game?.logFile && fs.existsSync(game.logFile)) return fsp.readFile(game.logFile, "utf8");
  const dir = (await loadCore()).paths.logsDir();
  const files = (await fsp.readdir(dir).catch(() => []))
    .filter((f) => f.startsWith(instanceId))
    .sort()
    .reverse();
  if (!files.length) return "";
  return fsp.readFile(path.join(dir, files[0]), "utf8");
});
handle("game:listLogs", async () => {
  const dir = (await loadCore()).paths.logsDir();
  const entries = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
  const files = [];
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith(".log")) continue;
    const full = path.join(dir, entry.name);
    const stat = await fsp.stat(full);
    files.push({ file: full, name: entry.name, size: stat.size, modified: stat.mtimeMs });
  }
  return files.sort((a, b) => b.modified - a.modified);
});
handle("game:readLog", async (file) => {
  const resolved = path.resolve(file);
  const dir = path.resolve((await loadCore()).paths.logsDir());
  if (!resolved.startsWith(dir)) throw new Error("Log file is outside the Revolution log directory.");
  return fsp.readFile(resolved, "utf8");
});

// --- servers (multiplayer without an account check)
handle("servers:list", async () => (await loadCore()).servers.listServers());
handle("servers:add", async (payload) => (await loadCore()).servers.addServer(payload || {}));
handle("servers:update", async (id, patch) => (await loadCore()).servers.updateServer(id, patch || {}));
handle("servers:remove", async (id) => (await loadCore()).servers.removeServer(id));
handle("servers:ping", async (targets) => (await loadCore()).servers.pingMany(targets || []));
handle("servers:lan", async (options) => (await loadCore()).servers.discoverLan(options || {}));
handle("servers:join", async ({ instanceId, accountId, host, port, serverId } = {}) => {
  const c = await loadCore();
  if (!instanceId) throw new Error("Pick an instance to launch.");
  if (!host) throw new Error("No server address was given.");
  const target = port ? { host: String(host), port: Number(port) } : c.servers.parseAddress(host);
  // The instance remembers where it was sent, so the next Play button goes there too.
  await c.instances.updateInstance(instanceId, { server: { ip: target.host, port: target.port, autoConnect: true } });
  if (serverId) {
    try { c.servers.markPlayed(serverId); } catch { /* the list changed meanwhile */ }
  }
  return { jobId: queueLaunch(instanceId, accountId), started: true, server: target };
});

// --- content (Modrinth)
handle("content:search", async (params) => (await loadCore()).content.searchProjects(params || {}));
handle("content:popular", async (params) => (await loadCore()).content.listPopular(params || {}));
handle("content:project", async (slug) => (await loadCore()).content.getProject(slug));
handle("content:versions", async (slug, options) => (await loadCore()).content.getProjectVersions(slug, options || {}));
handle("content:list", async (instanceId, options) => (await loadCore()).content.listContent(instanceId, options || {}));
handle("content:install", async ({ instanceId, project, version, jobId }) => {
  const c = await loadCore();
  return c.content.installContent({ instanceId, project, version, onProgress: progressFor(jobId, instanceId) });
});
handle("content:toggle", async (instanceId, entryId, enabled) => (await loadCore()).content.setContentEnabled(instanceId, entryId, enabled));
handle("content:remove", async (instanceId, entryId, options) => (await loadCore()).content.removeContent(instanceId, entryId, options || {}));
handle("content:installModpack", async ({ file, name, jobId }) => {
  const c = await loadCore();
  return c.content.installModpack({ mrpackPath: file, name, onProgress: progressFor(jobId, null) });
});
handle("content:exportModpack", async ({ instanceId, destFile, jobId }) => {
  const c = await loadCore();
  return c.content.exportModpack({ instanceId, destFile, onProgress: progressFor(jobId, instanceId) });
});

process.on("uncaughtException", (err) => {
  console.error("[revolution] uncaught exception:", err);
});
process.on("unhandledRejection", (err) => {
  console.error("[revolution] unhandled rejection:", err);
});


// Revolution Hub: the hub reuses the launcher engine (e.g. for the Revolution Client page).
module.exports = { loadCore };
