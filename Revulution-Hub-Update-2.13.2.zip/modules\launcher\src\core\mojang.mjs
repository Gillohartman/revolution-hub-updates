import path from "node:path";
import fsp from "node:fs/promises";
import { fetchJson, download } from "./http.mjs";
import { versionsDir, cacheDir, indexesDir, ensureDir } from "./paths.mjs";
import { readJson, writeJson } from "./store.mjs";

export const VERSION_MANIFEST_URL = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
export const RESOURCES_URL = "https://resources.download.minecraft.net";
export const LAUNCHER_NAME = "Revolution";
export const LAUNCHER_VERSION = "1.0.0";

const MANIFEST_TTL_MS = 10 * 60 * 1000;

/* ------------------------------------------------------------------ rules */

function currentOsName() {
  if (process.platform === "win32") return "windows";
  if (process.platform === "darwin") return "osx";
  return "linux";
}

function archMatches(rule, arch) {
  switch (rule) {
    case "x86":
      return process.arch === "ia32";
    case "x64":
    case "x86_64":
      return process.arch === "x64" || process.arch === "arm64";
    case "arm64":
      return process.arch === "arm64";
    default:
      return false;
  }
}

/** True for http(s) URLs — loader metadata sometimes uses relative or empty values. */
function isRemoteUrl(value) {
  return typeof value === "string" && /^https?:\/\//i.test(value);
}

function osRuleMatches(os = {}) {
  if (os.name && os.name !== currentOsName()) return false;
  if (os.arch && !archMatches(os.arch, process.arch)) return false;
  if (os.version) {
    try {
      if (!new RegExp(os.version).test(process.getSystemVersion ? process.getSystemVersion() : "")) return false;
    } catch {
      return true;
    }
  }
  return true;
}

/** Evaluate a Mojang rules array. `features` supplies demo/resolution flags. */
export function rulesAllow(rules, features = {}) {
  if (!rules || rules.length === 0) return true;
  let allowed = false;
  for (const rule of rules) {
    let matches = true;
    if (rule.os) matches = matches && osRuleMatches(rule.os);
    if (rule.features) {
      for (const [key, value] of Object.entries(rule.features)) {
        if (Boolean(features[key]) !== Boolean(value)) matches = false;
      }
    }
    if (matches) allowed = rule.action === "allow";
  }
  return allowed;
}

/* ------------------------------------------------------- version metadata */

function manifestCacheFile() {
  return path.join(cacheDir(), "version_manifest_v2.json");
}

/** Full Mojang version manifest, cached on disk for MANIFEST_TTL_MS. */
export async function getVersionManifest({ force = false } = {}) {
  ensureDir(cacheDir());
  const file = manifestCacheFile();
  if (!force) {
    const cached = await readJson(file);
    if (cached && cached.fetchedAt && Date.now() - cached.fetchedAt < MANIFEST_TTL_MS) return cached.data;
  }
  const data = await fetchJson(VERSION_MANIFEST_URL);
  await writeJson(file, { fetchedAt: Date.now(), data });
  return data;
}

/** Release versions (newest first) plus the latest release/snapshot tags. */
export async function listVersions({ includeSnapshots = false } = {}) {
  const manifest = await getVersionManifest();
  const versions = manifest.versions.filter((v) =>
    includeSnapshots ? v.type !== "old_alpha" && v.type !== "old_beta" : v.type === "release");
  return { latest: manifest.latest, versions };
}

export function versionJsonPath(id) {
  return path.join(versionsDir(), id, `${id}.json`);
}

/**
 * Fetch (and cache) the version json for `id`. Version ids coming from loader
 * metadata may already be cached locally, in which case no network call is made.
 */
export async function getVersionJson(id, { force = false } = {}) {
  const dest = versionJsonPath(id);
  if (!force) {
    const cached = await readJson(dest);
    if (cached && cached.id) return cached;
  }
  const manifest = await getVersionManifest();
  const entry = manifest.versions.find((v) => v.id === id);
  if (!entry) throw new Error(`Unknown Minecraft version: ${id}`);
  const data = await fetchJson(entry.url);
  ensureDir(path.dirname(dest));
  await fsp.writeFile(dest, JSON.stringify(data, null, 2), "utf8");
  return data;
}

/** Save a locally generated version json (used by Fabric/Forge installers). */
export async function saveVersionJson(data) {
  const dest = versionJsonPath(data.id);
  ensureDir(path.dirname(dest));
  await fsp.writeFile(dest, JSON.stringify(data, null, 2), "utf8");
  return data;
}

/**
 * Identity of a library for override purposes: group, artifact, classifier and the
 * rule set. Two entries that share it are the same dependency at different versions,
 * and the child of an inheritance chain must win — otherwise a loader profile ends up
 * with both its own build and the parent's (NeoForge's asm 9.8 on the module path plus
 * vanilla's asm 9.6 on the classpath makes the game refuse to start). Entries with
 * different rules are kept apart, so per-OS natives are never collapsed.
 */
export function libraryKey(library) {
  const [group, artifact, , classifier] = String(library?.name || "").split(":");
  return `${group}:${artifact}:${classifier || ""}:${JSON.stringify(library?.rules || null)}`;
}

/** Apply child-over-parent overriding to an ordered library list (earlier = parent). */
export function mergeLibraries(...lists) {
  const merged = new Map();
  for (const list of lists) {
    for (const library of list || []) {
      if (!library?.name) continue;
      merged.set(libraryKey(library), library);
    }
  }
  return [...merged.values()];
}

/**
 * Merge a version json with its `inheritsFrom` parent chain (Fabric/Quilt/Forge
 * profiles all use this). Child values win; libraries are overridden by coordinate.
 */
export async function resolveVersion(version, { depth = 0 } = {}) {
  if (!version) throw new Error("resolveVersion requires a version json");
  if (depth > 5) throw new Error("Version inheritance chain is too deep");
  if (!version.inheritsFrom) return { ...version, libraries: mergeLibraries(version.libraries) };

  const parentId = typeof version.inheritsFrom === "string" ? version.inheritsFrom : version.inheritsFrom?.id;
  const parentRaw = await getVersionJson(parentId);
  const parent = await resolveVersion(parentRaw, { depth: depth + 1 });

  return {
    ...parent,
    ...version,
    id: version.id,
    libraries: mergeLibraries(parent.libraries, version.libraries),
    mainClass: version.mainClass || parent.mainClass,
    assets: version.assets || parent.assets,
    assetIndex: version.assetIndex || parent.assetIndex,
    javaVersion: version.javaVersion || parent.javaVersion,
    arguments: {
      game: [...(parent.arguments?.game || []), ...(version.arguments?.game || [])],
      jvm: [...(parent.arguments?.jvm || []), ...(version.arguments?.jvm || [])],
    },
    minecraftArguments: version.minecraftArguments || parent.minecraftArguments,
    downloads: { ...(parent.downloads || {}), ...(version.downloads || {}) },
  };
}

/* ------------------------------------------------------------- libraries */

export function libraryPath(library) {
  const artifact = library.downloads?.artifact;
  if (artifact?.path) return artifact.path;
  const [group, name, version, classifier] = String(library.name || "").split(":");
  if (!group || !name || !version) return null;
  const fileName = classifier ? `${name}-${version}-${classifier}.jar` : `${name}-${version}.jar`;
  return `${group.replace(/\./g, "/")}/${name}/${version}/${fileName}`;
}

/** Native classifier for the current platform, if the library declares one. */
export function nativeClassifier(library) {
  if (!library.natives) return null;
  const key = library.natives[currentOsName()];
  if (!key) return null;
  return key.replace("${arch}", process.arch === "ia32" ? "32" : "64");
}

/**
 * Flatten a resolved version into the concrete set of files the launcher needs:
 * libraries on the classpath, native jars to extract, and the client jar.
 */
export function collectLibraries(version, features = {}) {
  const classpath = [];
  const natives = [];
  const seen = new Set();
  for (const library of version.libraries || []) {
    if (!rulesAllow(library.rules, features)) continue;
    if (library.clientreq === false && !library.downloads) continue;
    const classifier = nativeClassifier(library);
    if (classifier && library.downloads?.classifiers?.[classifier]) {
      const artifact = library.downloads.classifiers[classifier];
      if (!artifact.url) continue;
      natives.push({ name: library.name, ...artifact, classifier, extract: library.extract });
      continue;
    }
    const artifact = library.downloads?.artifact;
    const relative = artifact?.path || libraryPath({ name: library.name });
    if (!relative) continue;
    const key = `${library.name}:${relative}`;
    if (seen.has(key)) continue;
    seen.add(key);

    if (artifact?.url) {
      classpath.push({ name: library.name, ...artifact, path: relative, url: artifact.url });
      continue;
    }

    // Fabric/Quilt metadata names a Maven repository root instead of per-file
    // downloads, and usually carries sha1/size on the entry itself.
    if (library.url && isRemoteUrl(library.url)) {
      const base = String(library.url).endsWith("/") ? library.url : `${library.url}/`;
      classpath.push({
        name: library.name,
        path: relative,
        url: `${base}${relative}`,
        sha1: library.sha1,
        size: library.size,
        maven: true,
      });
      continue;
    }

    // Neither: the artifact is produced locally by a loader installer (Forge's
    // patched client, for example), so it stays on the classpath without a download.
    classpath.push({ name: library.name, path: relative, local: true });
  }
  return { classpath, natives };
}

export async function getAssetIndex(version, { onProgress } = {}) {
  const index = version.assetIndex;
  if (!index?.id) throw new Error(`Version ${version.id} has no asset index`);
  // The client reads this file at <assetsDir>/indexes/<id>.json, so it must live in
  // the canonical location (a missing copy logs "Can't open the resource index file").
  const file = path.join(indexesDir(), `${index.id}.json`);
  const data = await readJson(file);
  if (data?.objects && Object.keys(data.objects).length > 0) return data;
  if (!index.url) throw new Error(`Asset index ${index.id} is not available locally and has no download URL`);
  const json = await fetchJson(index.url);
  await writeJson(file, json);
  if (onProgress) onProgress({ phase: "assets-index", done: 1, total: 1, label: `${index.id} asset index` });
  return json;
}

/** Download a single object from the shared asset store. */
export async function downloadAssetObject(hash, destDir, { onProgress } = {}) {
  const prefix = hash.slice(0, 2);
  const url = `${RESOURCES_URL}/${prefix}/${hash}`;
  const dest = path.join(destDir, prefix, hash);
  const out = await download(url, dest, { expectedSha1: hash });
  if (onProgress) onProgress({ phase: "assets", label: hash });
  return out;
}

export { currentOsName };
