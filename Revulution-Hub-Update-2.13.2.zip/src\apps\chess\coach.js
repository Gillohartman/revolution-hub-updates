'use strict';

/*
 * Coach: bewertet deine Züge (Brillant … Patzer) und erklärt in normaler Sprache,
 * WARUM ein Zug schlecht ist – hängende Figuren, Gabeln, Fesselungen, Matt-Drohungen,
 * verpasste Gewinne und Eröffnungsgrundsätze.
 */
(function (root) {
  const C = root.ChessCore || (typeof require === 'function' ? require('./chess-core.js') : null);
  const { Position, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING, WHITE, F_CAPTURE, F_CASTLE, POINTS, NAME_DE, NAME_DE_ACC, BISHOP_D, ROOK_D, KING_D, KNIGHT_D, sqName, typeOf, colorOf, uci } = C;
  const MATE = 100000;

  const CLASSES = {
    brilliant: { phrase: 'brillant', label: 'Brillant', mark: '!!', color: '#1bada6' },
    great: { phrase: 'stark', label: 'Stark', mark: '!', color: '#5c8bb0' },
    best: { phrase: 'der beste Zug', label: 'Bester Zug', mark: '★', color: '#81b64c' },
    excellent: { phrase: 'exzellent', label: 'Exzellent', mark: '✓', color: '#96bc4b' },
    good: { phrase: 'gut, aber nicht der beste', label: 'Gut', mark: '✓', color: '#95af8a' },
    book: { phrase: 'ein Eröffnungszug', label: 'Eröffnung', mark: '≡', color: '#a88865' },
    forced: { phrase: 'erzwungen', label: 'Erzwungen', mark: '→', color: '#97a3ad' },
    inaccuracy: { phrase: 'ungenau', label: 'Ungenau', mark: '?!', color: '#f7c631' },
    mistake: { phrase: 'ein Fehler', label: 'Fehler', mark: '?', color: '#e58f2a' },
    miss: { phrase: 'ein verpasster Gewinn', label: 'Verpasst', mark: '✗', color: '#ff7769' },
    blunder: { phrase: 'ein Patzer', label: 'Patzer', mark: '??', color: '#ca3431' },
    assisted: { phrase: 'mit Hilfe gespielt', label: 'Mit Hilfe', mark: 'H', color: '#6b7280' },
  };

  // Ab welcher Klasse der Coach eingreift (Empfindlichkeit 1–4).
  const TRIGGERS = {
    1: ['blunder'],
    2: ['blunder', 'mistake', 'miss'],
    3: ['blunder', 'mistake', 'miss', 'inaccuracy'],
    4: ['blunder', 'mistake', 'miss', 'inaccuracy', 'good'],
  };

  const isMate = (s) => Math.abs(s) > MATE - 1000;
  const clampCp = (s) => (isMate(s) ? Math.sign(s) * 2000 : s);
  /** Gewinnwahrscheinlichkeit (0–1) aus Centipawns, wie Lichess. */
  const wp = (cp) => 1 / (1 + Math.exp(-0.00368208 * clampCp(cp)));
  /** Genauigkeit eines Zuges aus dem Verlust an Gewinnchance (Lichess-Formel). */
  const moveAccuracy = (loss) => Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * Math.max(0, loss) * 100) - 3.1669));

  /* ------------------------------------------------------------- Sprache */

  const TEXT = root.ChessCoachText || (typeof require === 'function' ? require('./coach-text.js') : {});
  const sq = (s) => `<b>${sqName(s)}</b>`;
  const mv = (s) => `<b class="san">${s}</b>`;

  function evalText(score, lang = 'de') {
    if (isMate(score)) {
      const plies = MATE - Math.abs(score);
      return `${score > 0 ? '' : '−'}M${Math.ceil(plies / 2)}`;
    }
    const v = score / 100;
    const num = Math.abs(v).toFixed(1);
    return `${v > 0 ? '+' : v < 0 ? '−' : '±'}${lang === 'en' ? num : num.replace('.', ',')}`;
  }

  /** Zugfolge als Text mit Zugnummern, z. B. „12…Lxf3 13.gxf3 Dg5+“. */
  function lineText(pos, ucis, max = 6, lang = 'de') {
    const p = pos.clone();
    const out = [];
    for (let i = 0; i < Math.min(max, ucis.length); i += 1) {
      const m = p.find(ucis[i]);
      if (!m) break;
      const num = p.turn === WHITE ? `${p.full}.` : i === 0 ? `${p.full}…` : '';
      out.push(num + p.san(m, lang));
      p.make(m);
    }
    return out.join(' ');
  }

  /* ------------------------------------------------------------- Taktik-Helfer */

  const pieceAt = (pos, s) => pos.b[s];
  const diff = (pos, color) => pos.material(color) - pos.material(color ^ 8);

  /** Static Exchange: wie viel (Punkte) die Seite am Zug durch Schlagen auf `s` gewinnt. */
  function seeGain(pos, s, depth = 0) {
    if (depth > 8) return 0;
    const target = pos.b[s];
    if (!target) return 0;
    const caps = pos.legalMoves().filter((m) => m.to === s && m.flags & F_CAPTURE);
    if (!caps.length) return 0;
    caps.sort((a, b) => POINTS[typeOf(a.piece)] - POINTS[typeOf(b.piece)] || (typeOf(a.piece) === KING) - (typeOf(b.piece) === KING));
    const m = caps.find((x) => x.promo === 0 || x.promo === QUEEN) || caps[0];
    pos.make(m);
    const value = POINTS[typeOf(target)] + (m.promo ? POINTS[m.promo] - 1 : 0) - seeGain(pos, s, depth + 1);
    pos.unmake();
    return Math.max(0, value);
  }

  /** Eigene Figuren der Farbe `color`, die der Gegner (am Zug) gewinnbringend schlagen kann. */
  function hanging(pos, color) {
    const out = [];
    for (let s = 0; s < 128; s += 1) {
      if (s & 0x88) continue;
      const p = pos.b[s];
      if (!p || colorOf(p) !== color || typeOf(p) === KING) continue;
      const g = seeGain(pos, s);
      if (g >= 1) out.push({ sq: s, type: typeOf(p), gain: g });
    }
    return out.sort((a, b) => b.gain - a.gain);
  }

  /** Was die Figur auf `from` angreift (Felder mit gegnerischen Figuren). */
  function attacksFrom(pos, from) {
    const p = pos.b[from];
    if (!p) return [];
    const t = typeOf(p), c = colorOf(p);
    const out = [];
    const hit = (s) => {
      if (s & 0x88) return false;
      const q = pos.b[s];
      if (q && colorOf(q) !== c) out.push(s);
      return !q;
    };
    if (t === PAWN) {
      const d = c === WHITE ? 16 : -16;
      hit(from + d - 1);
      hit(from + d + 1);
    } else if (t === KNIGHT || t === KING) {
      for (const d of t === KNIGHT ? KNIGHT_D : KING_D) hit(from + d);
    } else {
      const dirs = t === BISHOP ? BISHOP_D : t === ROOK ? ROOK_D : KING_D;
      for (const d of dirs) {
        let s = from + d;
        while (hit(s)) s += d;
      }
    }
    return out;
  }

  /** Gabel: die Figur auf `from` greift zwei lohnende Ziele gleichzeitig an. */
  function forkTargets(pos, from) {
    const attacker = pos.b[from];
    if (!attacker) return [];
    const aVal = POINTS[typeOf(attacker)] || 0;
    const targets = attacksFrom(pos, from).filter((s) => {
      const t = typeOf(pos.b[s]);
      if (t === KING) return true;
      if (t === PAWN) return false;
      // lohnend: wertvoller als der Angreifer oder ungedeckt
      return POINTS[t] > aVal || !pos.attacked(s, colorOf(pos.b[s]));
    });
    return targets.length >= 2 ? targets : [];
  }

  /** Fesselung/Spieß durch eine Langschrittfigur auf `from`. */
  function lineTactic(pos, from) {
    const p = pos.b[from];
    if (!p) return null;
    const t = typeOf(p);
    if (t !== BISHOP && t !== ROOK && t !== QUEEN) return null;
    const dirs = t === BISHOP ? BISHOP_D : t === ROOK ? ROOK_D : KING_D;
    const c = colorOf(p);
    for (const d of dirs) {
      let s = from + d;
      let first = -1;
      while (!(s & 0x88)) {
        const q = pos.b[s];
        if (q) {
          if (colorOf(q) === c) break;
          if (first < 0) first = s;
          else {
            const front = typeOf(pos.b[first]), back = typeOf(q);
            if (back === KING) return { kind: 'pin', front: first, back: s };
            if (POINTS[back] > POINTS[front] && front !== PAWN) return { kind: 'pin', front: first, back: s };
            if (front === KING || POINTS[front] > POINTS[back]) return { kind: 'skewer', front: first, back: s };
            break;
          }
        }
        s += d;
      }
    }
    return null;
  }

  /** Materialbilanz (aus Sicht `color`) nach einer Folge – bis die Schlagserie vorbei ist. */
  function materialAfter(pos, color, ucis, max = 7) {
    const p = pos.clone();
    let value = diff(p, color);
    for (let i = 0; i < Math.min(max, ucis.length); i += 1) {
      const m = p.find(ucis[i]);
      if (!m) break;
      p.make(m);
      value = diff(p, color);
      // nach zwei ruhigen Zügen in Folge ist die Abwicklung vorbei
      const next = ucis[i + 1] ? p.find(ucis[i + 1]) : null;
      if (i >= 1 && !(m.flags & F_CAPTURE) && !(next && next.flags & F_CAPTURE)) break;
    }
    // Endet die Folge mitten im Abtausch, das sichere Zurückschlagen noch mitrechnen.
    const open = hanging(p, p.turn ^ 8)[0];
    if (open) value += p.turn === color ? open.gain : -open.gain;
    return value;
  }

  /* ------------------------------------------------------------- Bewertung */

  function isSacrifice(pos, m) {
    const p = pos.clone();
    p.make(m);
    const us = colorOf(m.piece);
    const got = m.flags & F_CAPTURE ? POINTS[typeOf(m.captured)] : 0;
    let worst = 0;
    for (const h of hanging(p, us)) worst = Math.max(worst, h.gain);
    return worst - got >= 2 ? worst - got : 0;
  }

  /**
   * rows: [{ uci, score, reply }] – jeder legale Zug bewertet, bester zuerst, Werte aus Sicht des Ziehenden.
   * Ergibt { cls, loss, accuracy, best, played, second }.
   */
  /**
   * Wie viel Material ein Zug „aufs Spiel setzt“: landet die Figur auf einem angegriffenen
   * Feld, zählt der Unterschied zum geschlagenen Material – und große Tausche (Dame, Turm)
   * gelten zusätzlich als riskant. So empfiehlt der Coach lieber den sicheren Zug.
   */
  function riskOf(pos, uciText) {
    const m = pos.find(uciText);
    if (!m) return 0;
    const us = pos.turn;
    const mover = POINTS[typeOf(m.piece)] || 0;
    const taken = m.captured ? POINTS[typeOf(m.captured)] || 0 : 0;
    const p = pos.clone();
    p.make(m);
    if (!p.attacked(m.to, us ^ 8)) return 0;
    let risk = Math.max(0, mover - taken);
    if (typeOf(m.piece) === QUEEN || typeOf(m.piece) === ROOK) risk += mover * 0.5; // großer Tausch
    return risk;
  }

  /** Bester Zug, aber auf Sicherheit bedacht: unter fast gleich guten Zügen den sichersten. */
  function safeBest(pos, rows) {
    const top = rows[0];
    if (!top || isMate(top.score)) return top;
    const topRisk = riskOf(pos, top.uci);
    if (!topRisk) return top;
    const window = topRisk >= 9 ? 120 : 70;
    let pick = top;
    let pickRisk = topRisk;
    for (const r of rows.slice(1, 12)) {
      if (r.score < top.score - window || isMate(r.score)) continue;
      const k = riskOf(pos, r.uci);
      if (k < pickRisk || (k === pickRisk && r.score > pick.score)) {
        pick = r;
        pickRisk = k;
      }
    }
    return pick;
  }

  function classify(pos, rows, playedUci, { ply = 99 } = {}) {
    const legalCount = pos.legalMoves().length;
    const best = safeBest(pos, rows);
    const played = rows.find((r) => r.uci === playedUci) || null;
    const second = rows[1] || null;
    if (legalCount === 1) return { cls: 'forced', loss: 0, accuracy: 100, best, played: played || best, second };
    if (!best || !played || !pos.find(playedUci)) return null;
    const wBest = wp(best.score);
    const wPlayed = wp(played.score);
    const loss = Math.max(0, wBest - wPlayed);
    const m = pos.find(playedUci);
    let cls;
    const isBest = played.uci === best.uci || played.uci === rows[0].uci || played.score >= best.score - 5;
    if (isBest || loss <= 0.02) {
      cls = isBest ? 'best' : 'excellent';
      if (ply < 8 && isBest && Math.abs(played.score) < 80) cls = 'book';
      const sac = m ? isSacrifice(pos, m) : 0;
      if (isBest && sac >= 2 && wPlayed >= 0.5 && wp(best.score) < 0.995) cls = 'brilliant';
      else if (isBest && second && wBest - wp(second.score) >= 0.2 && wBest < 0.97 && wBest > 0.3) cls = 'great';
    } else if (loss < 0.05) cls = 'good';
    else if (loss < 0.1) cls = 'inaccuracy';
    else if (loss < 0.2) cls = wBest > 0.85 && wPlayed > 0.5 ? 'miss' : 'mistake';
    else cls = wBest > 0.85 && wPlayed >= 0.4 ? 'miss' : 'blunder';
    if (isMate(best.score) && best.score > 0 && !(isMate(played.score) && played.score > 0)) {
      const n = Math.ceil((MATE - best.score) / 2);
      if (loss >= 0.05) cls = wPlayed > 0.6 ? 'miss' : 'blunder';
      else if (n <= 3) cls = 'miss';
    }
    return { cls, loss, accuracy: moveAccuracy(loss), best, played, second };
  }

  /* ------------------------------------------------------------- Erklärung */

  const RED = '#e5484d', GREEN = '#81b64c', YELLOW = '#f2b632', BLUE = '#4aa3df';

  /**
   * Schlägt der Gegner in der Engine-Folge wirklich auf `target`? Nur dann sagen wir
   * „hängt“ – sonst wäre es eine Behauptung, die die Engine gar nicht spielt.
   * Ergebnis: { move, index } des schlagenden Zuges oder null.
   */
  function captureInLine(after, ucis, target, maxPlies = 5) {
    const p = after.clone();
    const us = after.turn ^ 8;
    for (let i = 0; i < Math.min(maxPlies, ucis.length); i += 1) {
      const m = p.find(ucis[i]);
      if (!m) return null;
      if (i % 2 === 0 && m.to === target && m.flags & F_CAPTURE && colorOf(m.captured) === us) return { move: m, index: i };
      // eigene Figur ist weggezogen → keine Gefahr mehr für dieses Feld
      if (i % 2 === 1 && m.from === target) return null;
      p.make(m);
    }
    return null;
  }

  /** Pfeile der ersten Züge einer Folge (abwechselnd Gegner/du). */
  function lineArrows(pos, ucis, n, colors) {
    const p = pos.clone();
    const out = [];
    for (let i = 0; i < Math.min(n, ucis.length); i += 1) {
      const m = p.find(ucis[i]);
      if (!m) break;
      out.push([m.from, m.to, colors[i % colors.length]]);
      p.make(m);
    }
    return out;
  }

  /**
   * Erklärt den gespielten Zug. reasons/tips: [{ html, arrows:[[from,to,color]], squares:[[sq,color]] }].
   * Die erste Begründung bestimmt, was auf dem Brett standardmäßig zu sehen ist.
   */
  function explain(pos, verdict, lang = 'de') {
    const T = TEXT[lang] || TEXT.de;
    const { best, played, cls } = verdict;
    const m = pos.find(played.uci);
    const bm = pos.find(best.uci);
    const us = pos.turn, them = us ^ 8;
    const reasons = [];
    const add = (html, arrows = [], squares = []) => {
      if (html && !reasons.some((r) => r.html === html)) reasons.push({ html, arrows, squares });
    };

    const after = pos.clone();
    after.make(m);
    const reply = played.reply || [];
    const replyMove = reply[0] ? after.find(reply[0]) : null;
    const replySan = replyMove ? after.san(replyMove, lang) : '';
    const bestSan = bm ? pos.san(bm, lang) : '';
    const playedSan = pos.san(m, lang);
    const replyLine = lineText(after, reply, 6, lang);
    const bestLine = lineText(pos, [best.uci, ...(best.reply || [])], 6, lang);
    const replyArrow = replyMove ? [[replyMove.from, replyMove.to, RED]] : [];
    const bestArrow = bm ? [[bm.from, bm.to, GREEN]] : [];
    const playedArrow = [[m.from, m.to, YELLOW]];
    const sanAt = (p0, ucis, idx) => {
      const p = p0.clone();
      for (let i = 0; i < idx; i += 1) p.make(p.find(ucis[i]));
      return p.san(p.find(ucis[idx]), lang);
    };

    const matNow = diff(pos, us);
    const matAfterReply = materialAfter(after, us, reply);
    const lost = matNow - matAfterReply;
    const matAfterBest = bm ? materialAfter(pos, us, [best.uci, ...(best.reply || [])]) : matNow;
    const bestGain = matAfterBest - matNow;
    const mateAgainst = isMate(played.score) && played.score < 0;

    // 1) Matt gegen dich
    if (mateAgainst) {
      const n = Math.max(1, Math.ceil((MATE - Math.abs(played.score) - 1) / 2));
      add(n === 1 ? T.mate1(mv(playedSan), mv(replySan)) : T.mateN(mv(playedSan), n, mv(replyLine)), lineArrows(after, reply, Math.min(3, n * 2 - 1), [RED, BLUE]), [[after.kings[us >> 3], RED]]);
    }
    // 2) Matt verpasst
    if (isMate(best.score) && best.score > 0 && !(isMate(played.score) && played.score > 0)) {
      const n = Math.ceil((MATE - best.score) / 2);
      add(n === 1 ? T.missMate1(mv(bestSan)) : T.missMateN(n, mv(bestLine)), lineArrows(pos, [best.uci, ...(best.reply || [])], Math.min(3, n * 2 - 1), [GREEN, BLUE]), [[pos.kings[them >> 3], GREEN]]);
    }

    // 3) Die gezogene Figur geht verloren – nur wenn die Engine-Folge sie wirklich schlägt
    const movedType = m.promo || typeOf(m.piece);
    const got = m.flags & F_CAPTURE ? POINTS[typeOf(m.captured)] : 0;
    const hitMoved = !(m.flags & F_CASTLE) ? captureInLine(after, reply, m.to) : null;
    if (hitMoved && !mateAgainst) {
      const gain = seeGain(after, m.to);
      const loss = Math.max(0, gain - got);
      if (loss >= 1) {
        const capSan = sanAt(after, reply, hitMoved.index);
        add(T.hangs(movedType, sq(m.to), after.attacked(m.to, us), mv(capSan), loss), [[hitMoved.move.from, hitMoved.move.to, RED]], [[m.to, RED]]);
      }
    }

    // 4) Andere Figur ungeschützt gelassen / hing schon vorher – ebenfalls nur mit echtem Schlagen
    const before = pos.clone();
    before.makeNull();
    const hangBefore = new Map(hanging(before, us).map((h) => [h.sq, h.gain]));
    if (!mateAgainst) {
      for (const h of hanging(after, us)) {
        if (h.sq === m.to || h.gain < 2) continue;
        const hit = captureInLine(after, reply, h.sq);
        if (!hit) continue;
        const capSan = mv(sanAt(after, reply, hit.index));
        const arrows = [[hit.move.from, hit.move.to, RED]];
        if ((hangBefore.get(h.sq) || 0) >= 2) add(T.hungBefore(h.type, sq(h.sq), capSan), arrows, [[h.sq, RED]]);
        else {
          const defenderLeft = pos.attackers(h.sq, us).includes(m.from);
          add(T.leftUnprot(h.type, sq(h.sq), defenderLeft ? typeOf(m.piece) : 0, sq(m.from), capSan), defenderLeft ? [...playedArrow, ...arrows] : arrows, [[h.sq, RED]]);
        }
        break;
      }
    }

    // 5) Taktik in der Antwort: Gabel, Fesselung, Spieß, Abzug
    if (replyMove && !mateAgainst) {
      const p2 = after.clone();
      p2.make(replyMove);
      const rType = replyMove.promo || typeOf(replyMove.piece);
      const fork = forkTargets(p2, replyMove.to);
      if (fork.length >= 2) {
        add(T.fork(mv(replySan), rType, fork.slice(0, 3).map((s) => [typeOf(p2.b[s]), sq(s)])), [...replyArrow, ...fork.slice(0, 3).map((s) => [replyMove.to, s, '#ff8a3d'])], fork.map((s) => [s, RED]));
      }
      const line = lineTactic(p2, replyMove.to);
      if (line) {
        const ft = typeOf(p2.b[line.front]), bt = typeOf(p2.b[line.back]);
        const marks = [[line.front, RED], [line.back, YELLOW]];
        if (line.kind === 'pin') add(T.pin(mv(replySan), ft, sq(line.front), bt), [...replyArrow, [replyMove.to, line.back, '#ff8a3d']], marks);
        else add(T.skewer(mv(replySan), ft, sq(line.front), bt), [...replyArrow, [replyMove.to, line.back, '#ff8a3d']], marks);
      }
      if (p2.inCheck() && !(replyMove.flags & F_CAPTURE)) {
        const discovered = typeOf(replyMove.piece) !== KING && !p2.attackers(p2.kings[us >> 3], them).includes(replyMove.to);
        if (discovered) add(T.disc(mv(replySan)), replyArrow, [[p2.kings[us >> 3], RED]]);
      }
    }

    // 6) Materialverlust allgemein (aus der Engine-Folge)
    if (lost >= 1 && !mateAgainst && !reasons.length) add(T.lost(mv(replyLine), lost), lineArrows(after, reply, 3, [RED, BLUE]), []);

    // 7) Verpasster Gewinn
    if (bm && bestGain >= 2 && best.score - played.score >= 150 && !(isMate(best.score) && best.score > 0)) {
      const target = bm.flags & F_CAPTURE ? typeOf(bm.captured) : 0;
      if (target && !pos.attacked(bm.to, them)) add(T.missFree(target, sq(bm.to), mv(bestSan)), bestArrow, [[bm.to, GREEN]]);
      else add(T.missGain(mv(bestSan), bestGain, mv(bestLine)), lineArrows(pos, [best.uci, ...(best.reply || [])], 3, [GREEN, BLUE]), []);
    }

    // 8) Eröffnungsgrundsätze
    const tips = [];
    const tip = (html, arrows = [], squares = []) => tips.push({ html, arrows, squares, tip: true });
    let pieces = 0;
    for (let s = 0; s < 128; s += 1) if (!(s & 0x88) && pos.b[s]) pieces += 1;
    if (pos.full <= 12 && pieces >= 24) {
      const t = typeOf(m.piece);
      const homeRank = us === WHITE ? 0 : 7;
      const undeveloped = [];
      for (let f = 0; f < 8; f += 1) {
        const s = homeRank * 16 + f;
        const p = pos.b[s];
        if (p && colorOf(p) === us && (typeOf(p) === KNIGHT || typeOf(p) === BISHOP)) undeveloped.push(s);
      }
      if (t === QUEEN && pos.full <= 7 && !(m.flags & F_CAPTURE)) tip(T.tipQueen, playedArrow);
      if (t === KING && !(m.flags & F_CASTLE) && pos.castle & (us === WHITE ? 3 : 12)) tip(T.tipKing, playedArrow);
      if (t === KNIGHT && ((m.to & 7) === 0 || (m.to & 7) === 7)) tip(T.tipRim, playedArrow);
      if (t === PAWN && ((m.from & 7) === 5 || (m.from & 7) === 6) && pos.full <= 8) tip(T.tipPawns, playedArrow, [[pos.kings[us >> 3], YELLOW]]);
      if (bm && bm.flags & F_CASTLE && verdict.loss >= 0.05) tip(T.tipCastle(mv(bestSan)), bestArrow);
    }

    // 9) Was der beste Zug leistet
    let bestWhy = '';
    if (bm) {
      const p = pos.clone();
      p.make(bm);
      const bits = [];
      if (p.inCheck()) bits.push(T.whyCheck);
      if (bm.flags & F_CAPTURE) bits.push(T.whyCapture(typeOf(bm.captured)));
      const forks = forkTargets(p, bm.to);
      if (forks.length >= 2) bits.push(T.whyFork(forks.slice(0, 2).map((s) => [typeOf(p.b[s]), sqName(s)])));
      else {
        const threats = attacksFrom(p, bm.to).filter((s) => typeOf(p.b[s]) !== PAWN && typeOf(p.b[s]) !== KING && (POINTS[typeOf(p.b[s])] > POINTS[typeOf(bm.piece)] || !p.attacked(s, them)));
        if (threats.length) bits.push(T.whyAttack(typeOf(p.b[threats[0]]), sqName(threats[0])));
      }
      const saved = hanging(before, us).find((h) => h.sq === bm.from && h.gain >= 2);
      if (saved) bits.push(T.whySave(saved.type));
      if (bm.flags & F_CASTLE) bits.push(T.whyCastle);
      if (bits.length) bestWhy = `${mv(bestSan)} ${bits.join(', ')}.`;
    }

    // Nur konkrete Gründe zählen. Allgemeines Gerede („X ist stärker“) gibt es nicht mehr –
    // ohne konkreten Grund meldet sich der Coach gar nicht erst.
    const concrete = reasons.length > 0 || tips.length > 0;

    return {
      concrete,
      title: T.titles[cls] || T.titles.other,
      reasons,
      // Bei einem klaren taktischen Grund nur noch der wichtigste Hinweis dazu
      tips: reasons.length ? tips.filter((x) => !x.html.includes(bestSan) || tips.length === 1).slice(0, 1) : tips,
      bestSan,
      bestLine,
      bestWhy,
      replySan,
      replyLine,
      playedSan,
      evalBefore: evalText(best.score, lang),
      evalAfter: evalText(played.score, lang),
      bestArrow,
      // Was standardmäßig auf dem Brett zu sehen ist: das, was die erste Karte sagt
      marks: reasons[0] || tips[0] || { arrows: replyArrow, squares: [] },
    };
  }

  /** Lob für gute Züge (Brillant/Stark). */
  function praise(pos, verdict, lang = 'de') {
    const T = TEXT[lang] || TEXT.de;
    const m = pos.find(verdict.played.uci);
    const san = mv(pos.san(m, lang));
    if (verdict.cls === 'brilliant') {
      const after = pos.clone();
      after.make(m);
      const h = hanging(after, colorOf(m.piece))[0];
      return T.brilliant(san, h ? h.type : 0, h ? sq(h.sq) : '', mv(lineText(pos, [verdict.played.uci, ...(verdict.played.reply || [])], 5, lang)));
    }
    if (verdict.cls === 'great') return T.great(san);
    return '';
  }

  /* ------------------------------------------------------------- Elo */

  /** Spielstärke einer Partie aus der Genauigkeit (grobe Zuordnung). */
  function accuracyToElo(acc) {
    const table = [[0, 200], [40, 300], [50, 450], [60, 700], [70, 1000], [78, 1300], [84, 1550], [88, 1750], [92, 2000], [95, 2250], [98, 2600], [100, 2900]];
    for (let i = 1; i < table.length; i += 1) {
      const [a1, e1] = table[i - 1], [a2, e2] = table[i];
      if (acc <= a2) return Math.round(e1 + ((acc - a1) / (a2 - a1)) * (e2 - e1));
    }
    return 2900;
  }

  function eloUpdate(rating, opponent, result, games) {
    // Vorläufige Wertung: die ersten Partien bewegen die Elo stark, damit sie schnell stimmt
    const k = games < 15 ? 64 : games < 40 ? 36 : 20;
    const expected = 1 / (1 + 10 ** ((opponent - rating) / 400));
    return Math.round(rating + k * (result - expected));
  }

  const api = { CLASSES, TRIGGERS, safeBest, riskOf, classify, explain, praise, evalText, lineText, wp, moveAccuracy, accuracyToElo, eloUpdate, seeGain, hanging, isSacrifice, MATE };
  root.ChessCoach = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
