'use strict';

(function () {
  const ctx = {
    getData: () => null,
    render: () => {},
    toast: () => {},
    api: null,
    getCrosshair: () => null,
    getKeys: () => [],
  };

  let recording = false;
  let recorder = null;
  let stream = null;
  let streamOwned = true;
  let sources = [];
  let loadingSources = false;
  let lastSaved = null;
  let composite = null;
  let keys = [];
  let container = 'webm';
  let audioStream = null;
  // Facecam: eigener Recorder, eigene Datei je Clip.
  let cam = { stream: null, recorder: null, ext: 'webm' };
  let camDevices = [];
  let camLoading = false;
  let camPreview = null;
  // Face ID (Island) hat Vorrang: der Hub pausiert die Facecam, solange die Island die Kamera braucht.
  let camPaused = false;
  window.__revCamPause = (on) => {
    if (camPaused === Boolean(on)) return;
    camPaused = Boolean(on);
    if (camPaused) {
      stopCam();
      if (camPreview) camPreview.getTracks().forEach((t) => t.stop());
      camPreview = null;
      ctx.toast?.('Facecam pausiert – Face ID nutzt gerade die Kamera.');
    } else setTimeout(() => startCam(), 800);
  };
  // Lange Aufnahme (bis zum Stoppen)
  let rec = { active: false, since: 0, cam: false, bytes: 0, hotkey: 'F10', saving: false };

  const esc = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[c]));

  const fmtBytes = (bytes) => {
    const value = Number(bytes) || 0;
    if (value < 1024) return `${value} B`;
    const units = ['KB', 'MB', 'GB', 'TB'];
    let scaled = value / 1024;
    let index = 0;
    while (scaled >= 1024 && index < units.length - 1) {
      scaled /= 1024;
      index += 1;
    }
    return `${new Intl.NumberFormat('de-DE', { maximumFractionDigits: 1 }).format(scaled)} ${units[index]}`;
  };

  const fmtDate = (ms) => {
    const d = new Date(ms);
    return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}. ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  const BROWSER_WINDOW = /chrome|edge|firefox|brave|opera|vivaldi|claude|freebuff|electron/i;
  /**
   * Vollbild-Spiele liefern über die Fensteraufnahme oft nur ein schwarzes Bild
   * (Windows gibt bei exklusivem Vollbild keine Fensterbilder heraus), der Ton
   * läuft trotzdem weiter. Für das Spiel wird deshalb der Monitor aufgenommen,
   * auf dem es liegt – dort kommt das Bild in jedem Fall an.
   */
  const gameScreen = (list, source) => {
    if (!source || source.kind !== 'window' || !/fortnite/i.test(source.name)) return source;
    if (!source.displayId) return source;
    const screenSource = (list || []).find(
      (entry) => entry.kind === 'screen' && String(entry.displayId) === String(source.displayId),
    );
    return screenSource || source;
  };

  const pickSource = (list) =>
    (list || []).find((source) => /fortnite/i.test(source.name) && !BROWSER_WINDOW.test(source.name)) ||
    (list || []).find((source) => source.primary) ||
    (list || []).find((source) => /^screen/.test(source.id)) ||
    (list || [])[0] ||
    null;

  const settings = () => ctx.getData()?.settings || {};
  const usage = () => ctx.getData()?.clipUsage || { count: 0, bytes: 0, maxBytes: 0 };
  const clips = () => ctx.getData()?.clips || [];

  const KEY_LABELS = {
    Space: 'Space',
    Shift: 'Shift',
    Ctrl: 'Ctrl',
    Alt: 'Alt',
    Tab: 'Tab',
    Esc: 'Esc',
    M1: 'Links',
    M2: 'Rechts',
    M3: 'Mitte',
    M4: 'Maus 4',
    M5: 'Maus 5',
    'pad-LT': 'LT',
    'pad-RT': 'RT',
    'pad-StickL': 'Stick L',
    'pad-StickR': 'Stick R',
  };

  const keyLabel = (key) => KEY_LABELS[key] || key.replace(/^pad-/, '');

  /* ---------------- Zeichnen ins Video ---------------- */

  const imageCache = new Map();

  function crosshairImage(file) {
    let entry = imageCache.get(file);
    if (entry) return entry;
    const img = new Image();
    img.alt = '';
    // Unsichtbar im Dokument, damit GIF-Crosshairs im Clip weiterlaufen.
    img.style.cssText = 'position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0;pointer-events:none';
    img.src = window.xh?.mediaUrl ? window.xh.mediaUrl(file) : file;
    entry = { img, ready: false };
    img.onload = () => {
      entry.ready = true;
    };
    imageCache.set(file, entry);
    document.body.appendChild(img);
    return entry;
  }

  function drawCrosshair(context, width, height) {
    if (!settings().clipBurnCrosshair) return;
    const data = ctx.getCrosshair?.();
    const profile = data?.profile;
    if (!profile) return;

    if (profile.kind === 'image') {
      if (!profile.image) return;
      const entry = crosshairImage(profile.image);
      if (!entry.ready || !entry.img.naturalWidth) return;
      const size = 140 * (profile.imageScale || 1) * (height / 1080) * (Number(data.scale) || 1) * 0.85;
      context.save();
      context.translate(width / 2, height / 2);
      if (profile.rotation) context.rotate((profile.rotation * Math.PI) / 180);
      context.globalAlpha = profile.opacity ?? 1;
      if (profile.blend === 'screen') context.globalCompositeOperation = 'screen';
      context.drawImage(entry.img, -size / 2, -size / 2, size, size);
      context.restore();
      return;
    }

    if (!window.XH) return;
    const scale = (height / 1080) * (Number(data.scale) || 1) * 0.85;
    context.save();
    context.translate(width / 2, height / 2);
    context.scale(scale, scale);
    if (profile.rotation) context.rotate((profile.rotation * Math.PI) / 180);
    context.globalAlpha = profile.opacity ?? 1;
    window.XH.paint(context, profile);
    context.restore();
  }

  /* ---------------- Bibliothek: Zustand ---------------- */

  const CATEGORY_TABS = [
    { id: 'all', label: 'Alle', empty: 'Noch keine Clips.' },
    { id: 'win', label: 'Siege', empty: 'Noch kein Sieg-Clip. Bei „Victory Royale“ wird automatisch gespeichert.' },
    { id: 'kill', label: 'Kills', empty: 'Noch kein Kill-Clip. Eigene Eliminierungen werden automatisch gespeichert.' },
    { id: 'manual', label: 'Eigene', empty: 'Noch keine eigenen Clips. Hotkey drücken, um die letzten Sekunden zu sichern.' },
    { id: 'recording', label: 'Aufnahmen', empty: 'Noch keine Aufnahme. Oben auf „● Aufnehmen“ klicken – läuft, bis du stoppst.' },
    { id: 'fav', label: '★ Favoriten', empty: 'Noch keine Favoriten. Stern auf einem Clip antippen – Favoriten werden nie automatisch gelöscht.' },
  ];
  const PAGE_SIZE = 10;
  // Ansicht der Bibliothek: Tab, Suche, Datum, Sortierung, wie viele sichtbar, Auswahl.
  const lib = { tab: null, query: '', date: '', sort: 'new', shown: PAGE_SIZE, selecting: false, selected: new Set() };
  let diagText = '';
  const thumbQueue = [];
  const thumbBusy = new Set();
  const thumbFailed = new Set();
  let thumbRunning = false;

  const clipUrl = (name) =>
    window.xh?.clipUrl ? window.xh.clipUrl(name) : `xh://clip/${encodeURIComponent(name)}`;

  const inTab = (clip, tab) =>
    tab === 'all' ? true : tab === 'fav' ? clip.favorite === true : (clip.category || 'manual') === tab;
  const byCategory = (category) => clips().filter((clip) => inTab(clip, category));

  function currentTab() {
    if (lib.tab) return lib.tab;
    return 'all';
  }

  const dayKey = (ms) => {
    const d = new Date(ms);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  function dayLabel(key) {
    const today = dayKey(Date.now());
    const yesterday = dayKey(Date.now() - 86400000);
    if (key === today) return 'Heute';
    if (key === yesterday) return 'Gestern';
    const [y, m, d] = key.split('-');
    const weekday = new Date(Number(y), Number(m) - 1, Number(d)).toLocaleDateString('de-DE', { weekday: 'long' });
    return `${weekday}, ${d}.${m}.${y}`;
  }

  /** Clips des aktiven Tabs nach Suche, Datum und Sortierung. */
  function filteredClips() {
    const query = lib.query.trim().toLowerCase();
    const list = byCategory(currentTab()).filter((clip) => {
      if (lib.date && dayKey(clip.mtime) !== lib.date) return false;
      if (!query) return true;
      const haystack = [clipTitle(clip), clip.name, ...(clip.victims || []), fmtDate(clip.mtime)].join(' ').toLowerCase();
      return query.split(/\s+/).every((word) => haystack.includes(word));
    });
    const sorters = {
      new: (a, b) => b.mtime - a.mtime,
      old: (a, b) => a.mtime - b.mtime,
      big: (a, b) => b.bytes - a.bytes,
      kills: (a, b) => (b.kills || 0) - (a.kills || 0) || b.mtime - a.mtime,
    };
    return list.sort(sorters[lib.sort] || sorters.new);
  }

  function clipTitle(clip) {
    if (clip.title) return clip.title;
    if (clip.category === 'win') return 'Victory Royale';
    if (clip.category === 'kill') {
      if (clip.victims?.length > 1) return `${clip.victims.length} Kills`;
      if (clip.victims?.length === 1) return `Kill · ${clip.victims[0]}`;
      return 'Kill';
    }
    return 'Eigener Clip';
  }

  /* ---------------- Live-Aufnahme: Crosshair ins Video ---------------- */

  function startComposite() {
    const video = document.createElement('video');
    video.muted = true;
    video.playsInline = true;
    video.srcObject = stream;

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d', { alpha: false });
    composite = { video, canvas, context, timer: 0 };

    // Bewusst ein Timer statt requestAnimationFrame: im Hintergrund (Spiel im
    // Vordergrund) pausiert rAF, dann liefert der Canvas keine Bilder mehr und
    // der Recorder schreibt nur noch eine Sekunde statt des ganzen Puffers.
    // Keystrokes werden NICHT mehr eingebrannt – sie liegen als Zeitleiste neben
    // dem Clip und lassen sich im Player nachträglich ein- und ausschalten.
    const frame = () => {
      if (!composite) return;
      const width = canvas.width;
      const height = canvas.height;
      if (video.readyState >= 2 && video.videoWidth > 0) {
        context.drawImage(video, 0, 0, width, height);
      } else {
        context.fillStyle = '#05060a';
        context.fillRect(0, 0, width, height);
      }
      drawCrosshair(context, width, height);
    };

    return video
      .play()
      .catch(() => {})
      .then(async () => {
        if (!video.videoWidth) {
          // Manche Fenster liefern die Größe erst ein paar Bilder später.
          await new Promise((resolve) => setTimeout(resolve, 600));
        }
        const width = video.videoWidth || 1280;
        const height = video.videoHeight || 720;
        canvas.width = width;
        canvas.height = height;
        const fps = Math.min(60, Math.max(15, Number(settings().clipFps) || 60));
        frame();
        // Gleichmäßiger Takt: ein Worker-Timer wird im Hintergrund nicht gedrosselt
        // (setInterval im Fenster schon) – sonst springen/ruckeln die Clips.
        if (composite) {
          try {
            const worker = new Worker('frame-timer.js');
            worker.onmessage = frame;
            worker.postMessage(1000 / fps);
            composite.worker = worker;
          } catch {
            composite.timer = setInterval(frame, Math.round(1000 / fps));
          }
        }
        return canvas;
      });
  }

  function stopComposite() {
    if (!composite) return;
    clearInterval(composite.timer);
    try {
      composite.worker?.terminate();
    } catch {
      /* egal */
    }
    try {
      composite.video.pause();
      composite.video.srcObject = null;
    } catch {
      /* egal */
    }
    composite = null;
  }

  const bitrateFor = (quality) => {
    if (quality === 'niedrig') return 2500000;
    if (quality === 'mittel') return 5000000;
    return 9000000;
  };

  /* ---------------- Erkennung: Kills und „Victory Royale“ ----------------
   * Liest Ausschnitte direkt aus der laufenden Aufnahme und schickt sie an die
   * Texterkennung im Hauptprozess. Der entscheidet, ob ein eigener Kill bzw. ein
   * Sieg vorliegt, und schreibt den Clip selbst (mit Nachlauf).
   *
   * Drei Stellen werden gelesen:
   *  - der Kill-Feed links (Zeile mit dem eigenen Namen),
   *  - die Meldung in der Bildmitte, die nur bei EIGENEN Kills erscheint
   *    („ELIMINIERT …“ / „ELIMINATED …“) – braucht keinen Namen,
   *  - der große Sieg-Schriftzug oben.
   */
  // Der Truhen-Zähler liest aus derselben Aufnahme, statt den Bildschirm doppelt zu greifen.
  window.ClipCapture = {
    video: () => (recording && composite?.video && composite.video.readyState >= 2 ? composite.video : null),
  };

  const scanCanvas = document.createElement('canvas');
  const scanContext = scanCanvas.getContext('2d', { willReadFrequently: true });
  const detect = {
    timers: [],
    busy: { feed: false, elim: false, xp: false, win: false },
    lastDebug: 0,
    crops: {},
  };

  /**
   * Ausschnitt (Anteile 0..1) als kontrastreiches PNG. Nur fast weiße, kaum
   * farbige Pixel zählen als Schrift (Fortnite-HUD-Text ist weiß/gelb mit
   * dunklem Rand). Himmel, Gras und Wasser fallen dadurch weg.
   */
  function cropForOcr(region, maxWidth, mode = 'white') {
    const video = composite?.video;
    if (!video || video.readyState < 2 || !video.videoWidth) return null;
    const vw = video.videoWidth;
    const vh = video.videoHeight;
    const sx = Math.round(vw * region.x);
    const sy = Math.round(vh * region.y);
    const sw = Math.round(vw * region.w);
    const sh = Math.round(vh * region.h);
    // Kleine Schrift (Feed) eher vergrößern als verkleinern: Tesseract mag ~30 px hohe Buchstaben.
    const factor = Math.min(2, maxWidth / sw);
    const dw = Math.max(1, Math.round(sw * factor));
    const dh = Math.max(1, Math.round(sh * factor));
    scanCanvas.width = dw;
    scanCanvas.height = dh;
    scanContext.imageSmoothingEnabled = true;
    scanContext.drawImage(video, sx, sy, sw, sh, 0, 0, dw, dh);
    const image = scanContext.getImageData(0, 0, dw, dh);
    const data = image.data;
    let on = 0;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      // Weiße Schrift: hell und farblos. Farbige Namen im Feed (eigener Name
      // grün, Gegner rot, Team gelb/blau): kräftig gesättigt und hell genug.
      // Sand, Himmel und Gras sind zu blass bzw. zu dunkel und fallen raus.
      const white = min > 185 && max - min < 45;
      const yellow = r > 225 && g > 195 && b < 190;
      // Feed-Namen: eigener grün, Gegner rot (an echten Fortnite-Bildern gemessen,
      // so gewählt, dass Sand und Gras nicht mitkommen).
      const green = g > 145 && g - r > 55 && g - b > 30;
      const red = r > 175 && r - g > 90 && r - b > 85;
      const hit =
        white ||
        ((mode === 'feed' || mode === 'color') && yellow) ||
        (mode === 'feed' && (green || red));
      if (hit) on += 1;
      const value = hit ? 0 : 255;
      data[i] = value;
      data[i + 1] = value;
      data[i + 2] = value;
      data[i + 3] = 255;
    }
    const share = on / (dw * dh);
    // Gar keine Schrift oder praktisch alles weiß (Blendung, Menü): nichts zu lesen.
    if (share < 0.0015 || share > 0.6) return null;
    scanContext.putImageData(image, 0, 0);
    return scanCanvas.toDataURL('image/png').split(',')[1];
  }

  // Bildanteile (x, y, Breite, Höhe von 0..1) – an echten Fortnite-Bildern
  // ausgemessen: Feed links Mitte, „ELIMINIERUNG!“ unter dem Fadenkreuz,
  // „+300 GEGNER ELIMINIERT“ rechts.
  const FEED_REGION = { x: 0, y: 0.3, w: 0.42, h: 0.42 };
  const ELIM_REGION = { x: 0.3, y: 0.6, w: 0.4, h: 0.22 };
  const XP_REGION = { x: 0.66, y: 0.3, w: 0.32, h: 0.22 };
  const WIN_REGION = { x: 0.15, y: 0.04, w: 0.7, h: 0.42 };

  async function scan(kind) {
    if (detect.busy[kind] || !recording) return;
    const s = settings();
    if (kind === 'win' ? !s.clipOnWin : !s.clipOnKill) return;
    const api = window.xh;
    const call =
      kind === 'feed'
        ? api?.feedFrame
        : kind === 'elim' || kind === 'xp'
          ? (png) => api?.elimFrame?.(png, kind)
          : api?.victoryFrame;
    if (!call) return;
    const png =
      kind === 'feed'
        ? cropForOcr(FEED_REGION, 1600, 'feed')
        : kind === 'elim'
          ? cropForOcr(ELIM_REGION, 900, 'white')
          : kind === 'xp'
            ? cropForOcr(XP_REGION, 700, 'white')
            : cropForOcr(WIN_REGION, 900, 'color');
    if (!png) return;
    detect.crops[kind] = png;
    detect.busy[kind] = true;
    try {
      await call(png);
    } catch {
      /* Erkennung ist Beiwerk */
    }
    detect.busy[kind] = false;
  }

  /** Alle 20 s ein Kontrollbild in den Diagnose-Ordner – zeigt, was die Erkennung sieht. */
  function debugSnapshot() {
    const video = composite?.video;
    if (!recording || !video || video.readyState < 2 || !window.xh?.clipDebug) return;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1280;
      canvas.height = Math.round(1280 * (video.videoHeight / video.videoWidth));
      canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
      const frame = canvas.toDataURL('image/jpeg', 0.72).split(',')[1];
      window.xh.clipDebug({
        frame,
        feed: detect.crops.feed || null,
        elim: detect.crops.elim || null,
        xp: detect.crops.xp || null,
        win: detect.crops.win || null,
        width: video.videoWidth,
        height: video.videoHeight,
      });
    } catch {
      /* egal */
    }
  }

  function startDetection() {
    stopDetection();
    detect.timers = [
      // Kurze Abstände: jeder Bereich hat seine eigene Sperre, ein langsamer
      // Lesevorgang blockiert also nie die anderen.
      setInterval(() => scan('feed'), 600),
      setInterval(() => scan('elim'), 450),
      setInterval(() => scan('xp'), 450),
      setInterval(() => scan('win'), 1600),
      setInterval(debugSnapshot, 20000),
    ];
    setTimeout(debugSnapshot, 4000);
  }

  function stopDetection() {
    for (const timer of detect.timers) clearInterval(timer);
    detect.timers = [];
  }

  /* ---------------- Oberfläche ---------------- */

  function renderLibrary() {
    const tab = currentTab();
    return `
      <div class="card clip-library" id="clip-library">
        <div class="lib-head">
          <h3>Meine Clips</h3>
          <div class="lib-tabs">
            ${CATEGORY_TABS.map((entry) => {
              const count = byCategory(entry.id).length;
              return `<button class="lib-tab ${entry.id === tab ? 'is-active' : ''} cat-${entry.id}" data-action="clip-tab" data-tab="${entry.id}">
                ${entry.id === 'all' || entry.id === 'fav' ? '' : '<span class="lib-dot"></span>'}${entry.label}<span class="lib-count">${count}</span>
              </button>`;
            }).join('')}
          </div>
        </div>
        <div class="lib-tools">
          <div class="lib-search">
            <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="4.5" /><path d="M10.5 10.5 14 14" /></svg>
            <input id="lib-query" type="search" placeholder="Suchen: Gegner, Titel …" value="${esc(lib.query)}" />
          </div>
          <input id="lib-date" type="date" value="${esc(lib.date)}" title="Nach Datum filtern" />
          ${lib.date ? '<button class="btn btn-ghost" data-action="lib-date-clear" title="Datum zurücksetzen">× Datum</button>' : ''}
          <select id="lib-sort" title="Sortierung">
            ${[
              ['new', 'Neueste zuerst'],
              ['old', 'Älteste zuerst'],
              ['big', 'Größte zuerst'],
              ['kills', 'Meiste Kills'],
            ]
              .map(([value, label]) => `<option value="${value}" ${lib.sort === value ? 'selected' : ''}>${label}</option>`)
              .join('')}
          </select>
          <div class="row-actions" style="margin-left:auto">
            <button class="btn ${lib.selecting ? 'btn-primary' : 'btn-ghost'}" data-action="lib-select">${lib.selecting ? 'Fertig' : 'Auswählen'}</button>
            <button class="btn btn-ghost" data-action="open-clips">Ordner</button>
          </div>
        </div>
        <div id="clip-lib-results">${renderLibraryResults()}</div>
      </div>
    `;
  }

  function renderLibraryResults() {
    const tab = currentTab();
    const meta = CATEGORY_TABS.find((entry) => entry.id === tab) || CATEGORY_TABS[0];
    const list = filteredClips();
    const total = byCategory(tab).length;
    if (list.length === 0) {
      return `<p class="note lib-empty">${
        total === 0 ? esc(meta.empty) : 'Keine Clips passen zu Suche oder Datum.'
      }</p>`;
    }
    const visible = list.slice(0, lib.shown);
    const bytes = list.reduce((sum, clip) => sum + clip.bytes, 0);

    // Nach Tagen gruppieren (nur bei Sortierung nach Datum sinnvoll).
    let body = '';
    if (lib.sort === 'new' || lib.sort === 'old') {
      let lastDay = '';
      let group = [];
      const flush = () => {
        if (group.length === 0) return;
        body += `<div class="lib-day"><span>${esc(dayLabel(lastDay))}</span><span class="meta">${group.length} Clip${group.length === 1 ? '' : 's'}</span></div>`;
        body += `<div class="clip-grid">${group.map(renderClipCard).join('')}</div>`;
        group = [];
      };
      for (const clip of visible) {
        const key = dayKey(clip.mtime);
        if (key !== lastDay) {
          flush();
          lastDay = key;
        }
        group.push(clip);
      }
      flush();
    } else {
      body = `<div class="clip-grid">${visible.map(renderClipCard).join('')}</div>`;
    }

    const selectedCount = [...lib.selected].filter((name) => list.some((clip) => clip.name === name)).length;
    const selectBar = lib.selecting
      ? `<div class="lib-selectbar">
          <strong>${selectedCount} ausgewählt</strong>
          <button class="btn btn-ghost" data-action="lib-select-all">Alle ${list.length} auswählen</button>
          <button class="btn btn-ghost" data-action="lib-select-none" ${selectedCount ? '' : 'disabled'}>Keine</button>
          <button class="btn btn-ghost" data-action="lib-fav-selected" ${selectedCount ? '' : 'disabled'}>★ Favorit</button>
          <button class="btn btn-danger" data-action="lib-delete-selected" ${selectedCount ? '' : 'disabled'}>${selectedCount} löschen</button>
        </div>`
      : '';

    return `
      <div class="lib-summary">${list.length} Clip${list.length === 1 ? '' : 's'} · ${fmtBytes(bytes)}${
        list.length > visible.length ? ` · ${visible.length} angezeigt` : ''
      }</div>
      ${selectBar}
      ${body}
      ${
        list.length > visible.length
          ? `<div class="lib-more"><button class="btn" data-action="lib-more">Mehr anzeigen (${Math.min(PAGE_SIZE, list.length - visible.length)} von ${list.length - visible.length} weiteren)</button></div>`
          : ''
      }
    `;
  }

  /** Nur die Trefferliste neu zeichnen – Suchfeld behält Fokus und Cursor. */
  function refreshResults() {
    const host = document.getElementById('clip-lib-results');
    if (host) host.innerHTML = renderLibraryResults();
    else ctx.render();
    setTimeout(queueThumbs, 50);
  }

  function renderClipCard(clip) {
    const thumb = clip.thumb ? `<img src="${clipUrl(clip.name + '.jpg')}?v=${Math.round(clip.mtime)}" alt="" loading="lazy" />` : '<div class="thumb-empty"></div>';
    const selected = lib.selected.has(clip.name);
    return `
      <div class="clip-card cat-${esc(clip.category)} ${lib.selecting ? 'is-selecting' : ''} ${selected ? 'is-selected' : ''}" data-action="${lib.selecting ? 'lib-toggle' : 'play-clip'}" data-clip="${esc(clip.name)}" title="${lib.selecting ? 'Auswählen' : 'Abspielen'}">
        <div class="clip-thumb">
          ${thumb}
          <span class="clip-badge">${clip.category === 'win' ? '#1' : clip.category === 'kill' ? (clip.kills > 1 ? `${clip.kills}×` : 'Kill') : clip.category === 'recording' ? 'REC' : 'Clip'}</span>${clip.cam ? '<span class="clip-badge cam-badge" title="Mit Facecam">CAM</span>' : ''}
          ${clip.hasKeys ? `<span class="clip-keys-flag ${clip.showKeys ? 'is-on' : ''}" title="Keystrokes ${clip.showKeys ? 'an' : 'aus'}">⌨</span>` : ''}
          ${lib.selecting ? `<span class="clip-check ${selected ? 'is-on' : ''}">${selected ? '✓' : ''}</span>` : '<span class="clip-play">▶</span>'}
        </div>
        <div class="clip-info">
          <strong title="${esc(clip.name)}">${esc(clipTitle(clip))}</strong>
          <span class="meta">${fmtDate(clip.mtime)} · ${fmtBytes(clip.bytes)}</span>
        </div>
        ${
          lib.selecting
            ? ''
            : `<button class="clip-fav ${clip.favorite ? 'is-on' : ''}" data-action="fav-clip" data-clip="${esc(clip.name)}" title="${clip.favorite ? 'Favorit entfernen' : 'Als Favorit merken (wird nie automatisch gelöscht)'}">★</button>
        <button class="clip-del" data-action="delete-clip" data-clip="${esc(clip.name)}" title="Löschen">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.6 8.5h5.8l.6-8.5" /></svg>
        </button>`
        }
      </div>`;
  }

  function render() {
    const s = settings();
    const u = usage();
    const percent = u.maxBytes ? Math.min(100, (u.bytes / u.maxBytes) * 100) : 0;
    const selected = s.clipSourceId;
    const fortnite = sources.filter((source) => /fortnite/i.test(source.name));
    const rest = sources.filter((source) => !/fortnite/i.test(source.name));
    const ordered = [...fortnite, ...rest];
    const names = ctx.getData()?.ownNames || [];
    const needsName = s.clipOnKill && names.length === 0;

    // Vorschaubilder für neue Clips im Hintergrund erzeugen.
    setTimeout(queueThumbs, 50);
    if (micDevices.length === 0 && !micLoading) setTimeout(() => loadMics(false), 80);

    return `
      <div class="card">
        <div class="clip-bar">
          <span class="rec-dot ${recording ? '' : 'is-idle'}"></span>
          <strong>${recording ? 'Aufnahme läuft' : 'Aufnahme aus'}</strong>
          <span class="sub">${
            recording
              ? `Puffer: letzte ${s.clipSeconds} s · ${s.clipOnKill ? 'Kills' : ''}${s.clipOnKill && s.clipOnWin ? ' & ' : ''}${s.clipOnWin ? 'Siege' : ''}${s.clipOnKill || s.clipOnWin ? ' werden automatisch gespeichert' : 'nur Hotkey'}`
              : 'Startet automatisch mit Fortnite – oder hier von Hand'
          }</span>
          <div class="row-actions" style="margin-left:auto">
            <button class="btn ${recording ? 'btn-ghost' : 'btn-primary'}" data-action="toggle-recording">
              ${recording ? 'Aufnahme stoppen' : 'Aufnahme starten'}
            </button>
            <button class="btn" data-action="save-clip" ${recording ? '' : 'disabled'}>
              Clip speichern (${esc(s.clipHotkey || 'F9')})
            </button>
            <button class="btn rec-btn ${rec.active ? 'is-rec' : ''}" data-action="toggle-long-rec" ${recording || rec.active ? '' : 'disabled'} title="Nimmt auf, bis du stoppst (${esc(s.recHotkey || 'F10')})">
              <span class="rec-btn-dot"></span><span id="rec-btn-label">${rec.saving ? 'Wird gespeichert …' : rec.active ? `Stopp · ${recClock()}` : `Aufnehmen (${esc(s.recHotkey || 'F10')})`}</span>
            </button>
          </div>
        </div>
        ${
          needsName
            ? `<p class="note warn" style="margin-top:12px">Für Kill-Clips braucht die Erkennung deinen Fortnite-Namen – trag ihn unten bei „Automatik“ ein.</p>`
            : ''
        }
        <p class="note clip-diag" id="clip-diag">${recording ? esc(diagText || 'Erkennung läuft …') : ''}</p>
      </div>

      ${renderLibrary()}

      <div class="grid two">
        <div class="card">
          <h3>Automatik</h3>
          <div class="row-actions" style="flex-wrap:wrap;gap:8px">
            <button class="btn ${s.clipOnKill ? 'btn-primary' : ''}" data-action="toggle-clip-on-kill">Kills: ${s.clipOnKill ? 'An' : 'Aus'}</button>
            <button class="btn ${s.clipOnWin ? 'btn-primary' : ''}" data-action="toggle-clip-on-win">Siege: ${s.clipOnWin ? 'An' : 'Aus'}</button>
            <button class="btn ${s.clipAutoGame ? 'btn-primary' : ''}" data-action="toggle-clip-auto-game">Mit Spiel starten: ${s.clipAutoGame ? 'An' : 'Aus'}</button>
            <button class="btn ${s.clipAutoStart ? 'btn-primary' : ''}" data-action="toggle-clip-auto-start">Auto-Start: ${s.clipAutoStart ? 'An' : 'Aus'}</button>
            <button class="btn ${s.clipHotkeyEnabled !== false ? 'btn-primary' : ''}" data-action="toggle-clip-hotkey">Hotkey: ${s.clipHotkeyEnabled !== false ? 'An' : 'Aus'}</button>
          </div>
          <div class="inline-fields" style="margin-top:14px">
            <div class="field">
              <label for="clip-name">Dein Fortnite-Name</label>
              <input id="clip-name" type="text" placeholder="${esc(names[0] || 'z. B. DeinName')}" value="${esc(s.displayName || '')}" />
            </div>
            <div class="field">
              <label for="clip-kill-seconds">Sekunden vor dem Kill</label>
              <input id="clip-kill-seconds" type="number" min="5" max="60" step="1" value="${Number(s.clipKillSeconds) || 15}" />
            </div>
            <div class="field">
              <label for="clip-kill-post">Sekunden nach dem Kill</label>
              <input id="clip-kill-post" type="number" min="0.5" max="10" step="0.5" value="${Number.isFinite(Number(s.clipKillPost)) ? Number(s.clipKillPost) : 2}" />
            </div>
          </div>
          <p class="note" style="margin-top:10px">
            Mehrere Kills kurz hintereinander landen in <strong>einem</strong> Clip. Gespeichert wird kurz nach dem
            letzten Kill – dann erscheint nur ein kleiner grüner Haken unten links, kein Popup.
          </p>
        </div>

        <div class="card">
          <h3>Keystrokes</h3>
          <div class="row-actions" style="flex-wrap:wrap;gap:8px">
            <button class="btn ${s.clipKeysShow !== false ? 'btn-primary' : ''}" data-action="toggle-keys-default">Neue Clips: ${s.clipKeysShow !== false ? 'mit Tasten' : 'ohne Tasten'}</button>
            <button class="btn ${s.clipKeystrokesController !== false ? 'btn-primary' : ''}" data-action="toggle-keystrokes-controller">Controller: ${s.clipKeystrokesController !== false ? 'An' : 'Aus'}</button>
          </div>
          <canvas class="keys-live" id="keys-live" width="520" height="208"></canvas>
          <p class="note" style="margin-top:8px">
            Tasten und Maus (inkl. Seitentasten M4/M5) werden bei jedem Clip mitgeschrieben. Im Player lassen sie sich
            pro Clip jederzeit ein- und ausblenden – oder fest ins Video exportieren.
          </p>
        </div>
      </div>

      <div class="grid two">
        <div class="card">
          <h3>Ton</h3>
          <div class="row-actions" style="flex-wrap:wrap;gap:8px">
            <button class="btn ${s.clipAudio !== false ? 'btn-primary' : ''}" data-action="toggle-clip-audio">Spielsound: ${s.clipAudio !== false ? 'An' : 'Aus'}</button>
            <button class="btn ${s.clipMic ? 'btn-primary' : ''}" data-action="toggle-clip-mic">Mikrofon: ${s.clipMic ? 'An' : 'Aus'}</button>
          </div>
          <div class="inline-fields" style="margin-top:14px">
            <div class="field" style="grid-column:1 / -1">
              <label for="clip-mic">Mikrofon</label>
              <select id="clip-mic" ${s.clipMic ? '' : 'disabled'}>
                ${
                  micDevices.length === 0
                    ? '<option value="">Windows-Standard</option>'
                    : micDevices
                        .map((device) => `<option value="${esc(device.id)}" ${device.id === (s.clipMicId || '') ? 'selected' : ''}>${esc(device.label)}</option>`)
                        .join('')
                }
              </select>
              <div class="mic-meter ${s.clipMic ? '' : 'is-off'}" title="Pegel deines Mikrofons">
                <div class="mic-meter-fill" id="mic-meter-fill"></div>
                <div class="mic-meter-peak" id="mic-meter-peak"></div>
                <span class="mic-meter-db" id="mic-meter-db">${s.clipMic ? '…' : 'Mikro aus'}</span>
              </div>
            </div>
            <div class="field">
              <label for="clip-mic-volume">Mikro · ${Number(s.clipMicVolume ?? 100)} %</label>
              <input id="clip-mic-volume" type="range" min="0" max="200" step="5" value="${Number(s.clipMicVolume ?? 100)}" ${s.clipMic ? '' : 'disabled'} />
            </div>
            <div class="field">
              <label for="clip-sys-volume">Spiel · ${Number(s.clipSystemVolume ?? 100)} %</label>
              <input id="clip-sys-volume" type="range" min="0" max="200" step="5" value="${Number(s.clipSystemVolume ?? 100)}" ${s.clipMic && s.clipAudio !== false ? '' : 'disabled'} />
            </div>
          </div>
          <p class="note" style="margin-top:8px">Spielsound und Mikrofon landen zusammen in einer Tonspur. Änderungen gelten sofort – eine laufende Aufnahme startet dafür kurz neu.</p>
        </div>

        <div class="card">
          <h3>Bild</h3>
          <div class="row-actions" style="flex-wrap:wrap;gap:8px">
            <button class="btn ${s.clipBurnCrosshair !== false ? 'btn-primary' : ''}" data-action="toggle-burn-crosshair">Crosshair ins Video: ${s.clipBurnCrosshair !== false ? 'An' : 'Aus'}</button>
          </div>
          <div class="inline-fields" style="margin-top:14px">
            <div class="field">
              <label for="clip-fps">Bildrate</label>
              <select id="clip-fps">
                ${[30, 60]
                  .map((fps) => `<option value="${fps}" ${Number(s.clipFps) === fps ? 'selected' : ''}>${fps} fps</option>`)
                  .join('')}
              </select>
            </div>
            <div class="field">
              <label for="clip-quality">Qualität</label>
              <select id="clip-quality">
                ${['niedrig', 'mittel', 'hoch']
                  .map(
                    (quality) =>
                      `<option value="${quality}" ${s.clipQuality === quality ? 'selected' : ''}>${quality[0].toUpperCase()}${quality.slice(1)}</option>`,
                  )
                  .join('')}
              </select>
            </div>
            <div class="field">
              <label for="clip-seconds">Länge (Hotkey/Sieg)</label>
              <input id="clip-seconds" type="number" min="10" max="120" step="5" value="${Number(s.clipSeconds) || 30}" />
            </div>
            <div class="field">
              <label for="clip-hotkey">Hotkey</label>
              <input id="clip-hotkey" type="text" value="${esc(s.clipHotkey || 'F9')}" />
            </div>
          </div>
        </div>

        <div class="card" style="grid-column:1 / -1">
          <h3>Facecam & lange Aufnahmen</h3>
          <div class="cam-setup">
            <div>
              <div class="row-actions" style="flex-wrap:wrap;gap:8px">
                <button class="btn ${s.camEnabled ? 'btn-primary' : ''}" data-action="toggle-cam">Facecam: ${s.camEnabled ? 'An' : 'Aus'}</button>
              </div>
              <div class="inline-fields" style="margin-top:14px">
                <div class="field">
                  <label for="cam-device">Kamera</label>
                  <select id="cam-device" ${s.camEnabled ? '' : 'disabled'}>
                    ${
                      camDevices.length === 0
                        ? '<option value="">Standard-Kamera</option>'
                        : camDevices.map((device) => `<option value="${esc(device.id)}" ${device.id === (s.camDeviceId || '') ? 'selected' : ''}>${esc(device.label)}</option>`).join('')
                    }
                  </select>
                </div>
                <div class="field">
                  <label for="rec-hotkey">Hotkey für Aufnahme</label>
                  <input id="rec-hotkey" type="text" value="${esc(s.recHotkey || 'F10')}" />
                </div>
              </div>
              <p class="note" style="margin-top:10px">Die Webcam landet als eigene Spur neben jedem Clip und jeder Aufnahme. Im Player kannst du sie danach verschieben, größer/kleiner ziehen, rund machen oder ausschalten – und mit „Exportieren“ fest ins Video übernehmen. Lange Aufnahmen laufen, bis du stoppst, und werden nie automatisch gelöscht.</p>
            </div>
            <div class="cam-preview ${s.camEnabled ? '' : 'is-off'}"><video id="cam-preview" muted playsinline></video><span>${s.camEnabled ? (cam.stream ? 'Live' : 'Vorschau …') : 'Facecam aus'}</span></div>
          </div>
        </div>

        <div class="card" style="grid-column:1 / -1">
          <h3>Speicher</h3>
          <div class="inline-fields">
            <div class="field">
              <label for="clip-max">Max. Speicher (GB)</label>
              <input id="clip-max" type="number" min="0.5" max="50" step="0.5" value="${Number(s.clipMaxGb) || 2}" />
            </div>
          </div>
          <div class="meter" style="margin-top:14px"><div class="meter-fill" style="width:${percent}%"></div></div>
          <p class="note" style="margin-top:10px">${fmtBytes(u.bytes)} von ${fmtBytes(u.maxBytes)} belegt · ${u.count} Clips. Ist der Platz voll, fliegen die ältesten Clips raus.</p>
          <div class="row-actions" style="margin-top:14px">
            <button class="btn btn-danger" data-action="clear-clips">Alle Clips löschen</button>
          </div>
        </div>
      </div>

      <div class="card">
        <h3>Quelle</h3>
        ${
          loadingSources && ordered.length === 0
            ? '<p class="note">Quellen werden geladen …</p>'
            : ordered.length === 0
              ? '<p class="note">Keine Aufnahmequellen gefunden. Prüfe die Windows-Bildschirmaufnahme-Einstellungen.</p>'
              : `<div class="source-grid">
                  ${ordered
                    .map(
                      (source) => `
                    <div class="source ${source.id === selected ? 'is-active' : ''}" data-action="pick-source" data-source-id="${esc(source.id)}">
                      ${source.thumbnail ? `<img src="${source.thumbnail}" alt="" />` : '<div style="aspect-ratio:16/9"></div>'}
                      <div class="name">${esc(source.name)}</div>
                    </div>`,
                    )
                    .join('')}
                </div>`
        }
        <p class="note" style="margin-top:10px">
          Am besten das Fortnite-Fenster wählen – Vollbild-Spiele werden automatisch über den passenden Monitor aufgenommen.
        </p>
      </div>
    `;
  }

  /* ---------------- Vorschaubilder ---------------- */

  function queueThumbs() {
    for (const clip of clips()) {
      if (clip.thumb || thumbBusy.has(clip.name) || thumbFailed.has(clip.name)) continue;
      if (thumbQueue.includes(clip.name)) continue;
      thumbQueue.push(clip.name);
    }
    runThumbs();
  }

  async function runThumbs() {
    if (thumbRunning) return;
    thumbRunning = true;
    while (thumbQueue.length > 0) {
      const name = thumbQueue.shift();
      thumbBusy.add(name);
      const ok = await makeThumb(name).catch(() => false);
      thumbBusy.delete(name);
      if (!ok) thumbFailed.add(name);
      else {
        const clip = clips().find((entry) => entry.name === name);
        if (clip) clip.thumb = true;
        const img = document.querySelector(`.clip-card[data-clip="${CSS.escape(name)}"] .clip-thumb`);
        if (img) {
          const empty = img.querySelector('.thumb-empty');
          if (empty) empty.outerHTML = `<img src="${clipUrl(name + '.jpg')}?v=${Date.now()}" alt="" />`;
        }
      }
    }
    thumbRunning = false;
  }

  /** Dauer ermitteln – WebM aus dem MediaRecorder kennt sie erst nach einem Sprung ans Ende. */
  function resolveDuration(video) {
    return new Promise((resolve) => {
      if (Number.isFinite(video.duration) && video.duration > 0) {
        resolve(video.duration);
        return;
      }
      const done = () => {
        video.removeEventListener('durationchange', check);
        clearTimeout(timer);
        const value = Number.isFinite(video.duration) ? video.duration : 0;
        resolve(value);
      };
      const check = () => {
        if (Number.isFinite(video.duration) && video.duration > 0) done();
      };
      const timer = setTimeout(done, 3000);
      video.addEventListener('durationchange', check);
      try {
        video.currentTime = 1e7;
      } catch {
        done();
      }
    });
  }

  function makeThumb(name) {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.muted = true;
      video.preload = 'auto';
      video.crossOrigin = 'anonymous';
      let finished = false;
      const finish = (value) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        video.removeAttribute('src');
        video.load();
        resolve(value);
      };
      const timer = setTimeout(() => finish(false), 12000);
      video.addEventListener('error', () => finish(false));
      video.addEventListener(
        'loadedmetadata',
        async () => {
          const duration = await resolveDuration(video);
          // Moment des Kills/Siegs: ein paar Sekunden vor Clip-Ende.
          const target = duration > 8 ? duration - 5.5 : Math.max(0.1, duration / 2);
          video.addEventListener(
            'seeked',
            () => {
              try {
                const canvas = document.createElement('canvas');
                canvas.width = 384;
                canvas.height = Math.round(384 * ((video.videoHeight || 9) / (video.videoWidth || 16)));
                canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
                const base64 = canvas.toDataURL('image/jpeg', 0.78).split(',')[1];
                Promise.resolve(window.xh?.clipThumb?.(name, base64)).then((ok) => finish(Boolean(ok)));
              } catch {
                finish(false);
              }
            },
            { once: true },
          );
          video.currentTime = target;
        },
        { once: true },
      );
      video.src = clipUrl(name);
    });
  }

  /* ---------------- Player ---------------- */

  const player = {
    root: null,
    video: null,
    canvas: null,
    clip: null,
    info: null,
    duration: 0,
    raf: 0,
    exporting: null,
  };

  function playerList() {
    if (!player.clip) return [];
    // Blättern im Player folgt der aktuellen Ansicht (Tab, Suche, Datum, Sortierung).
    const list = filteredClips();
    return list.some((clip) => clip.name === player.clip.name) ? list : byCategory(player.clip.category || 'manual');
  }

  function closePlayer() {
    if (player.exporting) return;
    cancelAnimationFrame(player.raf);
    cancelAnimationFrame(player.camRaf);
    const camVideo = player.root?.querySelector('.cp-cam video');
    if (camVideo) {
      camVideo.pause();
      camVideo.removeAttribute('src');
      camVideo.load();
    }
    if (player.video) {
      player.video.pause();
      player.video.removeAttribute('src');
      player.video.load();
    }
    player.root?.remove();
    player.root = null;
    player.video = null;
    player.canvas = null;
    player.clip = null;
    player.info = null;
    document.removeEventListener('keydown', playerKeys, true);
  }

  function playerKeys(event) {
    if (!player.root) return;
    if (event.target?.closest?.('input')) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      closePlayer();
    } else if (event.key === 'ArrowRight' && event.altKey) {
      stepClip(1);
    } else if (event.key === 'ArrowLeft' && event.altKey) {
      stepClip(-1);
    } else if (event.key.toLowerCase() === 'k' && !event.target.closest('input')) {
      toggleClipKeys();
    } else if (event.key === 'Delete') {
      deleteFromPlayer();
    }
  }

  function stepClip(direction) {
    const list = playerList();
    const index = list.findIndex((entry) => entry.name === player.clip?.name);
    const next = list[index + direction];
    if (next) openPlayer(next.name);
  }

  async function openPlayer(name) {
    const clip = clips().find((entry) => entry.name === name);
    if (!clip) return;
    if (!player.root) {
      player.root = document.createElement('div');
      player.root.className = 'clip-player';
      document.body.appendChild(player.root);
      player.root.addEventListener('click', onPlayerClick);
      document.addEventListener('keydown', playerKeys, true);
    }
    cancelAnimationFrame(player.raf);
    player.clip = clip;
    player.info = null;
    player.duration = 0;

    const list = playerList();
    const index = list.findIndex((entry) => entry.name === name);
    player.root.innerHTML = `
      <div class="cp-backdrop" data-cp="close"></div>
      <div class="cp-window cat-${esc(clip.category)}">
        <div class="cp-head">
          <span class="cp-cat">${clip.category === 'win' ? 'Sieg' : clip.category === 'kill' ? 'Kill' : clip.category === 'recording' ? 'Aufnahme' : 'Eigener Clip'}</span>
          <input class="cp-title" id="cp-title" value="${esc(clipTitle(clip))}" maxlength="80" title="Klicken zum Umbenennen" spellcheck="false" />
          <span class="meta">${fmtDate(clip.mtime)} · ${fmtBytes(clip.bytes)}${list.length > 1 && index >= 0 ? ` · ${index + 1}/${list.length}` : ''}</span>
          <button class="cp-fav ${clip.favorite ? 'is-on' : ''}" data-cp="fav" title="Favorit (wird nie automatisch gelöscht)">★</button>
          <button class="win-btn cp-close" data-cp="close" title="Schließen (Esc)">×</button>
        </div>
        <div class="cp-stage">
          <video class="cp-video" controls autoplay playsinline crossorigin="anonymous"></video>
          <canvas class="cp-keys"></canvas>
          <div class="cp-cam" hidden title="Ziehen zum Verschieben, Ecke ziehen für die Größe"><video muted playsinline preload="auto"></video><i class="cp-cam-resize"></i></div>
          <button class="cp-nav cp-prev" data-cp="prev" ${index > 0 ? '' : 'hidden'} title="Vorheriger (Alt+←)">‹</button>
          <button class="cp-nav cp-next" data-cp="next" ${index >= 0 && index < list.length - 1 ? '' : 'hidden'} title="Nächster (Alt+→)">›</button>
        </div>
        <div class="cp-bar">
          <button class="btn cp-keys-btn" data-cp="keys" disabled>Keystrokes …</button>
          <div class="cp-keys-size" id="cp-keys-size" hidden>
            <span>Größe</span>
            <input type="range" id="cp-keys-scale" min="0.4" max="2.5" step="0.05" value="1" />
            <button class="btn btn-ghost" data-cp="keys-reset" title="Position und Größe zurücksetzen">Zurücksetzen</button>
          </div>
          <button class="btn cp-cam-btn" data-cp="cam" hidden>Facecam: An</button>
          <button class="btn btn-ghost cp-cam-round" data-cp="cam-round" hidden>Rund</button>
          <button class="btn" data-cp="export" disabled title="Erstellt eine Kopie mit fest eingebrannten Tasten und Facecam">Exportieren</button>
          <span class="cp-status" id="cp-status"></span>
          <div class="row-actions" style="margin-left:auto">
            <button class="btn btn-ghost" data-cp="reveal">Im Ordner zeigen</button>
            <button class="btn btn-danger" data-cp="delete">Löschen</button>
          </div>
        </div>
      </div>`;

    player.video = player.root.querySelector('.cp-video');
    player.canvas = player.root.querySelector('.cp-keys');
    const video = player.video;
    video.src = clipUrl(name);
    video.addEventListener('loadedmetadata', async () => {
      if (!Number.isFinite(video.duration)) {
        const wasPaused = video.paused;
        player.duration = await resolveDuration(video);
        video.currentTime = 0;
        if (!wasPaused) video.play().catch(() => {});
      } else {
        player.duration = video.duration;
      }
    });

    try {
      player.info = (await window.xh?.clipInfo?.(name)) || null;
    } catch {
      player.info = null;
    }
    if (player.clip?.name !== name) return;
    updateKeysButton();
    wireKeysEditing();
    wireTitleEditing();
    loopKeys();
    setupCam();
  }

  /* ---------------- Facecam im Player ---------------- */

  function camEls() {
    const box = player.root?.querySelector('.cp-cam');
    return { box, video: box?.querySelector('video') };
  }

  /** Sichtbarer Bildbereich des Clips im Player (object-fit: contain). */
  function contentRect() {
    const video = player.video;
    const stage = video?.parentElement;
    if (!video || !stage) return null;
    const box = video.getBoundingClientRect();
    const host = stage.getBoundingClientRect();
    const vw = video.videoWidth || 16;
    const vh = video.videoHeight || 9;
    const scale = Math.min(box.width / vw, box.height / vh);
    const width = vw * scale;
    const height = vh * scale;
    return { left: box.left - host.left + (box.width - width) / 2, top: box.top - host.top + (box.height - height) / 2, width, height };
  }

  function placeCam() {
    const cam = player.info?.cam;
    const { box, video } = camEls();
    if (!box || !cam) return;
    box.hidden = !cam.visible;
    box.classList.toggle('is-round', Boolean(cam.round));
    const rect = contentRect();
    if (!rect) return;
    const aspect = video.videoWidth ? video.videoHeight / video.videoWidth : 9 / 16;
    const width = cam.w * rect.width;
    const height = cam.round ? width : width * aspect;
    const x = Math.min(cam.x, 1 - width / rect.width);
    const y = Math.min(cam.y, 1 - height / rect.height);
    box.style.left = `${rect.left + Math.max(0, x) * rect.width}px`;
    box.style.top = `${rect.top + Math.max(0, y) * rect.height}px`;
    box.style.width = `${width}px`;
    box.style.height = `${height}px`;
  }

  function updateCamButtons() {
    const cam = player.info?.cam;
    const btn = player.root?.querySelector('[data-cp="cam"]');
    const round = player.root?.querySelector('[data-cp="cam-round"]');
    if (!btn || !round) return;
    btn.hidden = !cam;
    round.hidden = !cam || !cam.visible;
    if (!cam) return;
    btn.textContent = `Facecam: ${cam.visible ? 'An' : 'Aus'}`;
    btn.classList.toggle('btn-primary', cam.visible);
    round.textContent = cam.round ? 'Eckig' : 'Rund';
  }

  function saveCam(patch) {
    if (!player.info?.cam || !player.clip) return;
    Object.assign(player.info.cam, patch);
    window.xh?.clipSetMeta?.(player.clip.name, { cam: patch });
  }

  function setupCam() {
    const cam = player.info?.cam;
    const { box, video } = camEls();
    updateCamButtons();
    if (!cam || !box) return;
    video.src = clipUrl(cam.file);
    video.addEventListener('loadedmetadata', placeCam);
    const main = player.video;
    const offset = (Number(cam.offsetMs) || 0) / 1000;
    const sync = (force) => {
      if (!player.video || !video.src) return;
      const target = main.currentTime - offset;
      if (target < 0 || (video.duration && target > video.duration)) {
        video.style.opacity = '0';
        if (!video.paused) video.pause();
        return;
      }
      video.style.opacity = '1';
      if (force || Math.abs(video.currentTime - target) > 0.25) video.currentTime = target;
      video.playbackRate = main.playbackRate;
      if (main.paused && !video.paused) video.pause();
      if (!main.paused && video.paused) video.play().catch(() => {});
    };
    for (const type of ['play', 'pause', 'seeked', 'ratechange']) main.addEventListener(type, () => sync(true));
    const loop = () => {
      if (!player.root || player.video !== main) return;
      sync(false);
      placeCam();
      player.camRaf = requestAnimationFrame(loop);
    };
    cancelAnimationFrame(player.camRaf);
    player.camRaf = requestAnimationFrame(loop);

    // Verschieben und Größe ändern
    box.addEventListener('pointerdown', (event) => {
      const rect = contentRect();
      if (!rect) return;
      event.preventDefault();
      box.setPointerCapture(event.pointerId);
      const resize = event.target.classList.contains('cp-cam-resize');
      const start = { x: event.clientX, y: event.clientY, cam: { ...player.info.cam } };
      box.classList.add('is-dragging');
      const move = (e) => {
        const dx = (e.clientX - start.x) / rect.width;
        const dy = (e.clientY - start.y) / rect.height;
        if (resize) player.info.cam.w = Math.min(0.6, Math.max(0.08, start.cam.w + dx));
        else {
          player.info.cam.x = Math.min(1, Math.max(0, start.cam.x + dx));
          player.info.cam.y = Math.min(1, Math.max(0, start.cam.y + dy));
        }
        placeCam();
      };
      const up = () => {
        box.removeEventListener('pointermove', move);
        box.removeEventListener('pointerup', up);
        box.classList.remove('is-dragging');
        const { x, y, w } = player.info.cam;
        saveCam({ x, y, w });
      };
      box.addEventListener('pointermove', move);
      box.addEventListener('pointerup', up);
    });
  }

  /* Titel umbenennen: Enter oder Fokus weg speichert. */
  function wireTitleEditing() {
    const input = player.root?.querySelector('#cp-title');
    if (!input) return;
    const save = async () => {
      const clip = player.clip;
      if (!clip) return;
      const value = input.value.trim();
      if (value === clipTitle(clip)) return;
      applyListResult(await window.xh.clipSetMeta(clip.name, { title: value }), false);
      clip.title = value;
      refreshResults();
    };
    input.addEventListener('keydown', (event) => {
      event.stopPropagation();
      if (event.key === 'Enter') input.blur();
      if (event.key === 'Escape') {
        input.value = clipTitle(player.clip);
        input.blur();
      }
    });
    input.addEventListener('blur', save);
  }

  /*
   * Keystrokes im Clip verschieben (ziehen) und vergrößern (Regler oder
   * Mausrad über dem Overlay). Gespeichert wird pro Clip – auch der Export
   * nutzt diese Lage.
   */
  let saveKeysTimer = 0;

  function persistKeysLayout() {
    clearTimeout(saveKeysTimer);
    saveKeysTimer = setTimeout(() => {
      const info = player.info;
      if (!info || !player.clip) return;
      window.xh?.clipSetMeta?.(player.clip.name, { keysPos: info.keysPos || null, keysScale: info.keysScale || 1 });
    }, 250);
  }

  function wireKeysEditing() {
    const info = player.info;
    const box = player.root?.querySelector('#cp-keys-size');
    const slider = player.root?.querySelector('#cp-keys-scale');
    const stage = player.root?.querySelector('.cp-stage');
    if (!info || !box || !slider || !stage) return;
    box.hidden = !(info.keys?.length && !info.burned);
    slider.value = String(info.keysScale || 1);
    slider.addEventListener('input', () => {
      info.keysScale = Number(slider.value);
      persistKeysLayout();
    });

    const toCanvas = (event) => {
      const rect = player.canvas.getBoundingClientRect();
      const ratio = player.canvas.width / Math.max(1, rect.width);
      return {
        x: (event.clientX - rect.left) * ratio,
        y: (event.clientY - rect.top) * ratio,
        rect,
        ratio,
      };
    };
    const inside = (point) => {
      const b = player.keysBounds;
      return b && point.x >= b.left && point.x <= b.left + b.width && point.y >= b.top && point.y <= b.top + b.height;
    };

    stage.addEventListener(
      'mousedown',
      (event) => {
        if (event.button !== 0 || !info.showKeys || !info.keys?.length) return;
        const start = toCanvas(event);
        if (!inside(start)) return;
        // Klick gehört dem Overlay, nicht dem Video (kein Pause/Play).
        event.preventDefault();
        event.stopPropagation();
        const bounds = { ...player.keysBounds };
        const offsetX = start.x - bounds.left;
        const offsetY = start.y - bounds.top;
        stage.classList.add('is-dragging-keys');
        const move = (moveEvent) => {
          const point = toCanvas(moveEvent);
          const freeW = Math.max(1, player.canvas.width - bounds.width);
          const freeH = Math.max(1, player.canvas.height - bounds.height);
          info.keysPos = {
            x: Math.min(1, Math.max(0, (point.x - offsetX) / freeW)),
            y: Math.min(1, Math.max(0, (point.y - offsetY) / freeH)),
          };
        };
        const up = () => {
          window.removeEventListener('mousemove', move, true);
          window.removeEventListener('mouseup', up, true);
          stage.classList.remove('is-dragging-keys');
          persistKeysLayout();
        };
        window.addEventListener('mousemove', move, true);
        window.addEventListener('mouseup', up, true);
      },
      true,
    );
    // Klick nach dem Ziehen nicht ans Video weitergeben.
    stage.addEventListener(
      'click',
      (event) => {
        if (info.showKeys && inside(toCanvas(event))) {
          event.preventDefault();
          event.stopPropagation();
        }
      },
      true,
    );
    stage.addEventListener('mousemove', (event) => {
      stage.classList.toggle('over-keys', Boolean(info.showKeys && inside(toCanvas(event))));
    });
    stage.addEventListener(
      'wheel',
      (event) => {
        if (!info.showKeys || !inside(toCanvas(event))) return;
        event.preventDefault();
        info.keysScale = Math.min(2.5, Math.max(0.4, (info.keysScale || 1) * (event.deltaY < 0 ? 1.08 : 1 / 1.08)));
        slider.value = String(info.keysScale);
        persistKeysLayout();
      },
      { passive: false },
    );
  }

  function updateKeysButton() {
    if (!player.root) return;
    const button = player.root.querySelector('[data-cp="keys"]');
    const exportBtn = player.root.querySelector('[data-cp="export"]');
    const info = player.info;
    const hasKeys = Boolean(info?.keys?.length);
    if (button) {
      button.disabled = !hasKeys;
      button.classList.toggle('btn-primary', hasKeys && info.showKeys);
      button.textContent = info?.burned
        ? 'Tasten sind eingebrannt'
        : hasKeys
          ? `Keystrokes: ${info.showKeys ? 'An' : 'Aus'} (K)`
          : 'Keine Tasten aufgezeichnet';
    }
    const hasCam = Boolean(info?.cam?.visible);
    if (exportBtn) exportBtn.disabled = (!hasKeys && !hasCam) || Boolean(player.exporting);
  }

  /** Clip-Zeit (s) → Versatz in der Tasten-Zeitleiste (ms). Gerechnet vom Clip-Ende. */
  function keysOffset() {
    const info = player.info;
    const video = player.video;
    if (!info || !video) return -1;
    const duration = player.duration || (Number.isFinite(video.duration) ? video.duration : 0);
    if (!duration) return -1;
    return info.keysSpan - (duration - video.currentTime) * 1000;
  }

  function loopKeys() {
    cancelAnimationFrame(player.raf);
    const step = () => {
      if (!player.root || !player.canvas || !player.video) return;
      drawPlayerKeys();
      player.raf = requestAnimationFrame(step);
    };
    player.raf = requestAnimationFrame(step);
  }

  function drawPlayerKeys() {
    const canvas = player.canvas;
    const video = player.video;
    const info = player.info;
    const stage = canvas.parentElement;
    const rect = stage.getBoundingClientRect();
    // Das Video wird mit Rändern eingepasst – das Overlay sitzt genau darauf.
    const vw = video.videoWidth || 16;
    const vh = video.videoHeight || 9;
    const fit = Math.min(rect.width / vw, (rect.height - 0) / vh);
    const w = Math.round(vw * fit);
    const h = Math.round(vh * fit);
    const ratio = window.devicePixelRatio || 1;
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    canvas.style.left = `${Math.round((rect.width - w) / 2)}px`;
    canvas.style.top = `${Math.round((rect.height - h) / 2)}px`;
    if (canvas.width !== Math.round(w * ratio) || canvas.height !== Math.round(h * ratio)) {
      canvas.width = Math.round(w * ratio);
      canvas.height = Math.round(h * ratio);
    }
    const context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);
    if (!info?.showKeys || !info.keys?.length || !window.KeysOverlay) {
      player.keysBounds = null;
      return;
    }
    let offset = keysOffset();
    // Vor dem ersten Tastendruck trotzdem zeigen (zum Verschieben).
    if (offset < 0) offset = 0;
    const lit = window.KeysOverlay.stateAt(filterPad(info.keys), offset);
    player.keysBounds = window.KeysOverlay.draw(context, canvas.width, canvas.height, lit, {
      controller: settings().clipKeystrokesController !== false,
      scale: info.keysScale || 1,
      position: info.keysPos || null,
      // Ohne eigene Lage: über der Steuerleiste des Players bleiben.
      lift: 46 * ratio,
    });
    // Beim Hovern/Ziehen einen dezenten Rahmen zeigen.
    if (player.keysBounds && (stage.classList.contains('over-keys') || stage.classList.contains('is-dragging-keys'))) {
      const b = player.keysBounds;
      context.save();
      context.setLineDash([6 * ratio, 4 * ratio]);
      context.strokeStyle = 'rgba(60,232,143,0.9)';
      context.lineWidth = 1.5 * ratio;
      context.strokeRect(b.left - 3 * ratio, b.top - 3 * ratio, b.width + 6 * ratio, b.height + 6 * ratio);
      context.restore();
    }
  }

  function filterPad(timeline) {
    if (settings().clipKeystrokesController !== false) return timeline;
    return timeline.map((entry) => ({ o: entry.o, k: (entry.k || []).filter((key) => !key.startsWith('pad-')) }));
  }

  async function toggleClipKeys() {
    const info = player.info;
    if (!info?.keys?.length || !player.clip) return;
    info.showKeys = !info.showKeys;
    updateKeysButton();
    const result = await window.xh?.clipSetMeta?.(player.clip.name, { showKeys: info.showKeys });
    applyListResult(result, false);
  }

  async function deleteFromPlayer() {
    if (!player.clip || player.exporting) return;
    const list = playerList();
    const index = list.findIndex((entry) => entry.name === player.clip.name);
    const next = list[index + 1] || list[index - 1] || null;
    const name = player.clip.name;
    if (player.video) {
      // Datei freigeben, bevor sie gelöscht wird (Windows sperrt geöffnete Dateien).
      player.video.pause();
      player.video.removeAttribute('src');
      player.video.load();
    }
    const result = await ctx.api.clipDelete(name);
    applyListResult(result, true);
    ctx.toast('Clip gelöscht.');
    if (next && next.name !== name) openPlayer(next.name);
    else closePlayer();
  }

  function setStatus(text) {
    const node = player.root?.querySelector('#cp-status');
    if (node) node.textContent = text || '';
  }

  /**
   * Export mit eingebrannten Tasten: Der Clip wird einmal in Echtzeit
   * abgespielt, Bild + Overlay auf einen Canvas gezeichnet und neu aufgenommen.
   */
  async function exportWithKeys() {
    const info = player.info;
    const clip = player.clip;
    const camInfo = info?.cam?.visible ? info.cam : null;
    if ((!info?.keys?.length && !camInfo) || !clip || player.exporting) return;
    let camSource = null;
    if (camInfo) {
      camSource = document.createElement('video');
      camSource.crossOrigin = 'anonymous';
      camSource.muted = true;
      camSource.preload = 'auto';
      camSource.src = clipUrl(camInfo.file);
      await new Promise((resolve) => {
        camSource.addEventListener('loadedmetadata', resolve, { once: true });
        camSource.addEventListener('error', resolve, { once: true });
        setTimeout(resolve, 5000);
      });
    }
    const source = document.createElement('video');
    source.crossOrigin = 'anonymous';
    source.preload = 'auto';
    source.playsInline = true;
    source.src = clipUrl(clip.name);
    player.exporting = { cancelled: false };
    updateKeysButton();
    setStatus('Export wird vorbereitet …');
    player.video?.pause();

    let audioContext = null;
    try {
      await new Promise((resolve, reject) => {
        source.addEventListener('loadedmetadata', resolve, { once: true });
        source.addEventListener('error', () => reject(new Error('Clip nicht lesbar')), { once: true });
      });
      const duration = await resolveDuration(source);
      source.currentTime = 0;
      const width = source.videoWidth || 1280;
      const height = source.videoHeight || 720;
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const context = canvas.getContext('2d', { alpha: false });
      const fps = Math.min(60, Math.max(24, Number(settings().clipFps) || 60));
      const output = canvas.captureStream(fps);

      // Ton über WebAudio abgreifen – nicht hörbar, aber im Export.
      try {
        audioContext = new AudioContext();
        const node = audioContext.createMediaElementSource(source);
        const target = audioContext.createMediaStreamDestination();
        node.connect(target);
        for (const track of target.stream.getAudioTracks()) output.addTrack(track);
      } catch {
        audioContext = null;
      }

      const wantMp4 = /\.mp4$/i.test(clip.name);
      const candidates = wantMp4
        ? ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm']
        : ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'];
      const mime = candidates.find((type) => window.MediaRecorder && MediaRecorder.isTypeSupported(type));
      const ext = mime && mime.startsWith('video/mp4') ? 'mp4' : 'webm';
      const recorderOut = new MediaRecorder(output, {
        mimeType: mime,
        videoBitsPerSecond: bitrateFor(settings().clipQuality),
        audioBitsPerSecond: 256000,
      });
      const parts = [];
      recorderOut.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) parts.push(event.data);
      };
      const stopped = new Promise((resolve) => {
        recorderOut.onstop = resolve;
      });

      const timeline = filterPad(info.keys || []);
      const camOffset = (Number(camInfo?.offsetMs) || 0) / 1000;
      const drawCam = () => {
        if (!camSource || !camSource.videoWidth) return;
        const target = source.currentTime - camOffset;
        if (target < 0 || (camSource.duration && target > camSource.duration)) return;
        if (Math.abs(camSource.currentTime - target) > 0.2) camSource.currentTime = target;
        if (camSource.paused) camSource.play().catch(() => {});
        const w = camInfo.w * width;
        const aspect = camSource.videoHeight / camSource.videoWidth;
        const h = camInfo.round ? w : w * aspect;
        const x = Math.max(0, Math.min(camInfo.x, 1 - w / width)) * width;
        const y = Math.max(0, Math.min(camInfo.y, 1 - h / height)) * height;
        context.save();
        context.beginPath();
        if (camInfo.round) context.arc(x + w / 2, y + h / 2, w / 2, 0, Math.PI * 2);
        else context.roundRect(x, y, w, h, Math.round(w * 0.06));
        context.clip();
        // Rund: mittigen Ausschnitt nehmen, nicht stauchen.
        if (camInfo.round) {
          const side = Math.min(camSource.videoWidth, camSource.videoHeight);
          context.drawImage(camSource, (camSource.videoWidth - side) / 2, (camSource.videoHeight - side) / 2, side, side, x, y, w, h);
        } else context.drawImage(camSource, x, y, w, h);
        context.restore();
        context.lineWidth = Math.max(2, w * 0.012);
        context.strokeStyle = 'rgba(255,255,255,0.85)';
        context.beginPath();
        if (camInfo.round) context.arc(x + w / 2, y + h / 2, w / 2, 0, Math.PI * 2);
        else context.roundRect(x, y, w, h, Math.round(w * 0.06));
        context.stroke();
      };
      const paint = () => {
        context.drawImage(source, 0, 0, width, height);
        drawCam();
        const offset = info.keysSpan - ((duration || source.duration || 0) - source.currentTime) * 1000;
        if (info.showKeys !== false && timeline.length && offset >= 0 && window.KeysOverlay) {
          window.KeysOverlay.draw(context, width, height, window.KeysOverlay.stateAt(timeline, offset), {
            controller: settings().clipKeystrokesController !== false,
            scale: info.keysScale || 1,
            position: info.keysPos || null,
          });
        }
        const total = duration || source.duration || 1;
        setStatus(`Export läuft … ${Math.min(100, Math.round((source.currentTime / total) * 100))} %`);
      };
      const timer = setInterval(paint, Math.round(1000 / fps));
      recorderOut.start(1000);
      await source.play();
      await new Promise((resolve) => {
        source.addEventListener('ended', resolve, { once: true });
        const guard = setInterval(() => {
          if (!player.exporting || player.exporting.cancelled) {
            clearInterval(guard);
            resolve();
          }
        }, 300);
        source.addEventListener('ended', () => clearInterval(guard), { once: true });
      });
      paint();
      clearInterval(timer);
      recorderOut.stop();
      await stopped;
      source.pause();

      setStatus('Speichere …');
      const blob = new Blob(parts, { type: mime || 'video/webm' });
      const data = new Uint8Array(await blob.arrayBuffer());
      const result = await window.xh?.clipExportSave?.(clip.name, data, ext);
      if (result?.ok) {
        applyListResult(result, true);
        setStatus('');
        ctx.toast('Export fertig – liegt bei den Clips derselben Kategorie (mit Facecam und Tasten, wie im Player eingestellt).');
      } else {
        setStatus('Export fehlgeschlagen.');
      }
    } catch (error) {
      setStatus(`Export fehlgeschlagen: ${error.message}`);
    } finally {
      try {
        audioContext?.close();
      } catch {
        /* egal */
      }
      source.removeAttribute('src');
      source.load();
      if (camSource) {
        camSource.pause();
        camSource.removeAttribute('src');
        camSource.load();
      }
      player.exporting = null;
      updateKeysButton();
    }
  }

  async function onPlayerClick(event) {
    const node = event.target.closest('[data-cp]');
    if (!node) return;
    const action = node.dataset.cp;
    if (action === 'close') closePlayer();
    else if (action === 'prev') stepClip(-1);
    else if (action === 'next') stepClip(1);
    else if (action === 'keys') toggleClipKeys();
    else if (action === 'delete') deleteFromPlayer();
    else if (action === 'export') exportWithKeys();
    else if (action === 'cam' && player.info?.cam) {
      saveCam({ visible: !player.info.cam.visible });
      updateCamButtons();
      updateKeysButton();
      placeCam();
    } else if (action === 'cam-round' && player.info?.cam) {
      saveCam({ round: !player.info.cam.round });
      updateCamButtons();
      placeCam();
    }
    else if (action === 'reveal' && player.clip) window.xh?.clipReveal?.(player.clip.name);
    else if (action === 'keys-reset' && player.info) {
      player.info.keysPos = null;
      player.info.keysScale = 1;
      const slider = player.root.querySelector('#cp-keys-scale');
      if (slider) slider.value = '1';
      persistKeysLayout();
    } else if (action === 'fav' && player.clip) {
      const next = !player.clip.favorite;
      applyListResult(await window.xh.clipSetMeta(player.clip.name, { favorite: next }), false);
      player.clip.favorite = next;
      node.classList.toggle('is-on', next);
      refreshResults();
    }
  }

  function applyListResult(result, rerender) {
    if (!result) return;
    const data = ctx.getData();
    if (data) {
      if (Array.isArray(result.clips)) data.clips = result.clips;
      if (result.usage) data.clipUsage = result.usage;
    }
    if (rerender) ctx.render();
  }

  /* ---------------- Aufnahme ---------------- */

  /*
   * Ton: Spielsound (System-Loopback) und optional ein Mikrofon. Beides wird
   * über WebAudio zu EINER Tonspur gemischt – MediaRecorder schreibt nur eine.
   */
  let mixer = null; // { context, inputs: [MediaStream] }
  let micDevices = [];
  let micLoading = false;

  function closeAudio() {
    if (!mixer) return;
    for (const input of mixer.inputs) {
      try {
        input.getTracks().forEach((track) => track.stop());
      } catch {
        /* egal */
      }
    }
    try {
      mixer.context.close();
    } catch {
      /* egal */
    }
    mixer = null;
  }

  async function systemAudio() {
    try {
      // Mono plus Echo-/Rausch-/Pegel-Filter ruinieren Spielsound: der
      // Loopback wird deshalb ausdrücklich als sauberes Stereo geholt.
      const capture = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 2 },
      });
      capture.getVideoTracks().forEach((track) => track.stop());
      const tracks = capture.getAudioTracks();
      return tracks.length ? new MediaStream(tracks) : null;
    } catch {
      return null;
    }
  }

  async function microphone() {
    const id = settings().clipMicId || '';
    const constraints = {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    };
    try {
      return await navigator.mediaDevices.getUserMedia({
        audio: id ? { ...constraints, deviceId: { exact: id } } : constraints,
        video: false,
      });
    } catch {
      // Gewähltes Gerät weg (abgesteckt): Standard-Mikrofon nehmen.
      if (!id) return null;
      try {
        return await navigator.mediaDevices.getUserMedia({ audio: constraints, video: false });
      } catch {
        return null;
      }
    }
  }

  async function buildAudio() {
    closeAudio();
    const s = settings();
    const wantSystem = s.clipAudio !== false;
    const wantMic = Boolean(s.clipMic);
    if (!wantSystem && !wantMic) return null;

    const system = wantSystem ? await systemAudio() : null;
    const mic = wantMic ? await microphone() : null;
    if (wantMic && !mic) ctx.toast('Mikrofon konnte nicht geöffnet werden – Clip wird ohne Mikro aufgenommen.');
    if (!system && !mic) return null;
    if (system && !mic) return system;

    const context = new AudioContext({ sampleRate: 48000 });
    const target = context.createMediaStreamDestination();
    target.channelCount = 2;
    const inputs = [];
    const add = (stream, volume) => {
      const source = context.createMediaStreamSource(stream);
      const gain = context.createGain();
      gain.gain.value = volume;
      source.connect(gain).connect(target);
      inputs.push(stream);
    };
    if (system) add(system, Math.max(0, Number(s.clipSystemVolume ?? 100)) / 100);
    add(mic, Math.max(0, Number(s.clipMicVolume ?? 100)) / 100);
    mixer = { context, inputs };
    return target.stream;
  }

  /** Mikrofone auflisten. Namen gibt Chromium erst nach einer Freigabe heraus. */
  async function loadMics(force) {
    if (micLoading || (micDevices.length > 0 && !force)) return;
    micLoading = true;
    try {
      let list = await navigator.mediaDevices.enumerateDevices();
      if (list.some((device) => device.kind === 'audioinput' && !device.label)) {
        try {
          const probe = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
          probe.getTracks().forEach((track) => track.stop());
          list = await navigator.mediaDevices.enumerateDevices();
        } catch {
          /* ohne Freigabe eben ohne Namen */
        }
      }
      micDevices = list
        .filter((device) => device.kind === 'audioinput' && device.deviceId !== 'communications')
        .map((device, index) => ({
          id: device.deviceId === 'default' ? '' : device.deviceId,
          label: device.deviceId === 'default'
            ? `Windows-Standard${device.label ? ` (${device.label.replace(/^Default - |^Standard - /, '')})` : ''}`
            : device.label || `Mikrofon ${index + 1}`,
        }));
      if (!micDevices.some((device) => device.id === '')) micDevices.unshift({ id: '', label: 'Windows-Standard' });
    } catch {
      micDevices = [{ id: '', label: 'Windows-Standard' }];
    }
    micLoading = false;
    ctx.render();
  }

  if (navigator.mediaDevices?.addEventListener) {
    navigator.mediaDevices.addEventListener('devicechange', () => loadMics(true));
  }

  /** Ton-Einstellung geändert: laufende Aufnahme mit neuem Ton neu starten. */
  async function restartIfRecording() {
    if (!recording) return;
    stopRecording();
    await startRecording();
    ctx.toast('Aufnahme mit neuen Ton-Einstellungen neu gestartet.');
  }


  async function ensureSources() {
    if (loadingSources || sources.length > 0) return;
    loadingSources = true;
    ctx.render();
    try {
      const result = await ctx.api.captureSources();
      sources = Array.isArray(result) ? result : [];
      const knownId = settings().clipSourceId;
      const stillThere = sources.some((source) => source.id === knownId);
      if (!knownId || !stillThere) {
        const preferred = pickSource(sources);
        if (preferred) await saveAndRefresh({ clipSourceId: preferred.id });
      }
    } catch {
      sources = [];
    }
    loadingSources = false;
    ctx.render();
  }

  /* ---------------- Facecam ---------------- */

  async function loadCams(force) {
    if (camLoading || (camDevices.length > 0 && !force)) return;
    camLoading = true;
    try {
      let list = await navigator.mediaDevices.enumerateDevices();
      if (list.some((device) => device.kind === 'videoinput' && !device.label)) {
        try {
          const probe = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          probe.getTracks().forEach((track) => track.stop());
          list = await navigator.mediaDevices.enumerateDevices();
        } catch {
          /* ohne Freigabe ohne Namen */
        }
      }
      camDevices = list
        .filter((device) => device.kind === 'videoinput')
        .map((device, index) => ({ id: device.deviceId, label: device.label || `Kamera ${index + 1}` }));
    } catch {
      camDevices = [];
    }
    camLoading = false;
    ctx.render();
  }

  async function openCamStream() {
    const id = settings().camDeviceId;
    return navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        ...(id ? { deviceId: { exact: id } } : {}),
        width: { ideal: 1280 },
        height: { ideal: 720 },
        frameRate: { ideal: 30, max: 30 },
      },
    });
  }

  async function startCam() {
    if (cam.recorder || !settings().camEnabled || camPaused) return;
    try {
      cam.stream = await openCamStream();
      const candidates = ['video/mp4;codecs=avc1.42E01E', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
      const mime = candidates.find((type) => window.MediaRecorder && MediaRecorder.isTypeSupported(type));
      cam.ext = mime && mime.startsWith('video/mp4') ? 'mp4' : 'webm';
      cam.recorder = new MediaRecorder(cam.stream, { mimeType: mime, videoBitsPerSecond: 3500000 });
      await ctx.api.camReset({ ext: cam.ext });
      let first = true;
      cam.recorder.ondataavailable = async (event) => {
        if (!event.data || event.data.size === 0) return;
        ctx.api.camChunk(new Uint8Array(await event.data.arrayBuffer()), first);
        first = false;
      };
      cam.recorder.start(1000);
      attachCamPreview();
    } catch (error) {
      stopCam();
      ctx.toast(`Facecam nicht verfügbar: ${error.message}`);
    }
  }

  function stopCam() {
    try {
      cam.recorder?.stop();
    } catch {
      /* egal */
    }
    try {
      cam.stream?.getTracks().forEach((track) => track.stop());
    } catch {
      /* egal */
    }
    cam = { stream: null, recorder: null, ext: cam.ext };
    ctx.api?.camStop?.();
    attachCamPreview();
  }

  /** Vorschau im Clips-Tab: die laufende Cam, sonst kurz eine eigene. */
  async function attachCamPreview() {
    const video = document.getElementById('cam-preview');
    if (!video) return;
    if (!settings().camEnabled) {
      video.srcObject = null;
      if (camPreview) camPreview.getTracks().forEach((t) => t.stop());
      camPreview = null;
      return;
    }
    let source = cam.stream;
    if (!source) {
      if (camPaused) return;
      if (!camPreview) {
        try {
          camPreview = await openCamStream();
        } catch {
          camPreview = null;
        }
      }
      source = camPreview;
    } else if (camPreview) {
      camPreview.getTracks().forEach((t) => t.stop());
      camPreview = null;
    }
    if (video.srcObject !== source) {
      video.srcObject = source;
      video.play().catch(() => {});
    }
  }

  function releaseCamPreview() {
    if (camPreview) camPreview.getTracks().forEach((t) => t.stop());
    camPreview = null;
  }

  /* ---------------- Lange Aufnahme ---------------- */

  function recClock() {
    if (!rec.active) return '0:00';
    const seconds = Math.floor((Date.now() - rec.since) / 1000);
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const sec = String(seconds % 60).padStart(2, '0');
    return h ? `${h}:${String(m).padStart(2, '0')}:${sec}` : `${m}:${sec}`;
  }

  setInterval(() => {
    if (!rec.active) return;
    const label = document.getElementById('rec-btn-label');
    if (label) label.textContent = `Stopp · ${recClock()}`;
  }, 1000);

  async function toggleLongRec() {
    const result = await ctx.api.recToggle();
    if (result?.error) ctx.toast(result.error);
    else if (result?.saved) ctx.toast('Aufnahme gespeichert – liegt unter „Aufnahmen“.');
    else if (result?.active) ctx.toast(`Aufnahme läuft${result.cam ? ' – mit Facecam' : ''}. Stoppen mit ${result.hotkey}.`);
  }

  window.xh?.onRecState?.((state) => {
    rec = { ...rec, ...state };
    ctx.render();
  });
  window.xh?.onRecSaving?.((state) => {
    rec.saving = Boolean(state?.saving);
    ctx.render();
  });
  // Kamera-Vorschau nur, solange der Clips-Tab offen ist (sonst bliebe die Cam-LED an).
  setInterval(() => {
    if (camPreview && !document.getElementById('cam-preview')) releaseCamPreview();
  }, 1500);

  // Wechselt die Live-Erkennung auf einen anderen Monitor (z. B. weil Fortnite startet),
  // muss die Clip-Aufnahme mitwechseln – sonst nimmt sie weiter den alten Bildschirm auf.
  window.addEventListener('live-stream-changed', () => {
    if (!recording || streamOwned) return;
    clearTimeout(startRecording.switchT);
    startRecording.switchT = setTimeout(async () => {
      if (!recording) return;
      stopRecording();
      await new Promise((r) => setTimeout(r, 400));
      startRecording();
    }, 1200);
  });

  async function startRecording() {
    if (recording) return;
    const sourceId = settings().clipSourceId;
    if (!sourceId) {
      ctx.toast('Bitte zuerst ein Fenster als Quelle wählen.');
      return;
    }
    const chosen = gameScreen(sources, sources.find((source) => source.id === sourceId));
    const captureId = chosen?.id || sourceId;
    const shared = window.LiveMonitor?.getStream?.() || null;
    try {
      stream = shared || await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: captureId,
            maxWidth: 1920,
            maxHeight: 1080,
            maxFrameRate: Number(settings().clipFps) || 60,
          },
        },
      });

      // System-Ton (Loopback) mitnehmen – ohne ihn sind die Clips stumm.
      // Nur getDisplayMedia mit Loopback ist in Electron stabil; der alte
      // chromeMediaSource-Weg reißt den Renderer beim Start der Aufnahme mit.
      audioStream = await buildAudio();
      const withAudio = Boolean(audioStream && audioStream.getAudioTracks().length > 0);

      // MP4 zuerst: Windows kann WebM ohne Zusatz-Codec nicht abspielen
      // ("Datei ist nicht lesbar"). WebM bleibt als Rückfall.
      const candidates = withAudio
        ? [
            'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
            'video/mp4;codecs=avc1,mp4a.40.2',
            'video/webm;codecs=vp9,opus',
            'video/webm;codecs=vp8,opus',
            'video/webm',
          ]
        : ['video/mp4;codecs=avc1.42E01E', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
      const mime = candidates.find((type) => window.MediaRecorder && MediaRecorder.isTypeSupported(type));
      container = mime && mime.startsWith('video/mp4') ? 'mp4' : 'webm';

      const canvas = await startComposite();
      const output = canvas.captureStream(Number(settings().clipFps) || 60);
      if (audioStream) {
        for (const track of audioStream.getAudioTracks()) output.addTrack(track);
      }

      recorder = new MediaRecorder(output, {
        mimeType: mime,
        videoBitsPerSecond: bitrateFor(settings().clipQuality),
        audioBitsPerSecond: 256000,
      });

      // Format mitgeben: Auto-Clips (Kill, Sieg) schreibt der Hauptprozess und
      // braucht die richtige Endung – sonst liegt ein MP4 als .webm auf der Platte.
      await ctx.api.clipReset({ ext: container });

      let first = true;
      recorder.ondataavailable = async (event) => {
        if (!event.data || event.data.size === 0) return;
        const buffer = new Uint8Array(await event.data.arrayBuffer());
        ctx.api.clipChunk(buffer, first);
        first = false;
      };

      recorder.start(1000);
      streamOwned = !shared;
      // Tasten laufen immer mit – die Zeitleiste landet neben jedem Clip.
      try {
        await ctx.api.inputStart();
      } catch {
        /* Keystrokes sind Beiwerk */
      }
      recording = true;
      startDetection();
      await startCam();
      ctx.render();
      ctx.toast(
        chosen && chosen.id !== sourceId
          ? 'Aufnahme läuft über den Monitor – Vollbild-Spiele liefern als Fenster oft nur ein schwarzes Bild.'
          : 'Aufnahme gestartet – Kills und Siege werden automatisch gespeichert.',
      );
    } catch (error) {
      ctx.toast(`Aufnahme fehlgeschlagen: ${error.message}`);
      recording = false;
      stopDetection();
      closeAudio();
      stopComposite();
      ctx.render();
    }
  }

  function stopRecording() {
    // Eine laufende lange Aufnahme wird vorher sauber abgeschlossen.
    if (rec.active) ctx.api.recStop?.();
    stopCam();
    stopDetection();
    closeAudio();
    if (audioStream) {
      try {
        audioStream.getTracks().forEach((track) => track.stop());
      } catch {
        /* egal */
      }
      audioStream = null;
    }
    try {
      recorder?.stop();
    } catch {
      /* ignore */
    }
    if (streamOwned) {
      try {
        stream?.getTracks().forEach((track) => track.stop());
      } catch {
        /* ignore */
      }
    }
    stopComposite();
    recorder = null;
    stream = null;
    streamOwned = true;
    recording = false;
    ctx.render();
  }

  async function save() {
    if (!recording) {
      ctx.toast('Aufnahme läuft nicht – starte sie im Clips-Tab.');
      return;
    }
    const result = await ctx.api.clipSave({ seconds: settings().clipSeconds, ext: container });
    if (result?.ok) {
      applyListResult(result, true);
      lastSaved = { name: result.name, bytes: result.bytes };
    } else if (result?.reason === 'empty-buffer') {
      ctx.toast('Puffer noch leer – ein paar Sekunden warten.');
    } else if (result && !result.ok) {
      ctx.toast('Clip konnte nicht gespeichert werden.');
    }
  }

  async function saveAndRefresh(patch) {
    const data = await ctx.api.saveSettings(patch);
    const current = ctx.getData();
    if (current && data) {
      current.settings = data.settings;
      current.clips = data.clips;
      current.clipUsage = data.clipUsage;
    }
    ctx.render();
  }

  async function autoStart() {
    if (recording) return;
    if (!settings().clipAutoStart) return;
    await ensureSources();
    if (recording) return;
    const id = settings().clipSourceId;
    if (!id || !sources.some((source) => source.id === id)) {
      const preferred = pickSource(sources);
      if (!preferred) return;
      await saveAndRefresh({ clipSourceId: preferred.id });
    }
    await startRecording();
  }

  async function handleAction(action, node) {
    switch (action) {
      case 'toggle-recording':
        if (recording) stopRecording();
        else await startRecording();
        return true;
      case 'save-clip':
        await save();
        return true;
      case 'clip-tab':
        lib.tab = node.dataset.tab;
        lib.shown = PAGE_SIZE;
        ctx.render();
        return true;
      case 'lib-more':
        lib.shown += PAGE_SIZE;
        refreshResults();
        return true;
      case 'lib-date-clear':
        lib.date = '';
        lib.shown = PAGE_SIZE;
        ctx.render();
        return true;
      case 'lib-select':
        lib.selecting = !lib.selecting;
        lib.selected.clear();
        ctx.render();
        return true;
      case 'lib-toggle': {
        const name = node.dataset.clip;
        if (lib.selected.has(name)) lib.selected.delete(name);
        else lib.selected.add(name);
        refreshResults();
        return true;
      }
      case 'lib-select-all':
        for (const clip of filteredClips()) lib.selected.add(clip.name);
        refreshResults();
        return true;
      case 'lib-select-none':
        lib.selected.clear();
        refreshResults();
        return true;
      case 'lib-delete-selected': {
        const names = [...lib.selected];
        if (names.length === 0) return true;
        if (names.length > 3 && !confirm(`${names.length} Clips löschen?`)) return true;
        applyListResult(await window.xh.clipDeleteMany(names), false);
        lib.selected.clear();
        ctx.render();
        ctx.toast(`${names.length} Clip${names.length === 1 ? '' : 's'} gelöscht.`);
        return true;
      }
      case 'lib-fav-selected': {
        let result = null;
        for (const name of lib.selected) result = await window.xh.clipSetMeta(name, { favorite: true });
        applyListResult(result, false);
        lib.selected.clear();
        lib.selecting = false;
        ctx.render();
        return true;
      }
      case 'fav-clip': {
        const clip = clips().find((entry) => entry.name === node.dataset.clip);
        if (!clip) return true;
        applyListResult(await window.xh.clipSetMeta(clip.name, { favorite: !clip.favorite }), false);
        refreshResults();
        const count = document.querySelector('.lib-tab[data-tab="fav"] .lib-count');
        if (count) count.textContent = String(byCategory('fav').length);
        return true;
      }
      case 'play-clip':
        await openPlayer(node.dataset.clip);
        return true;
      case 'pick-source': {
        const id = node.dataset.sourceId;
        await saveAndRefresh({ clipSourceId: id });
        ctx.render();
        return true;
      }
      case 'toggle-clip-auto-start':
        await saveAndRefresh({ clipAutoStart: !settings().clipAutoStart });
        if (settings().clipAutoStart) await autoStart();
        return true;
      case 'toggle-clip-on-kill':
        await saveAndRefresh({ clipOnKill: !settings().clipOnKill });
        return true;
      case 'toggle-clip-on-win':
        await saveAndRefresh({ clipOnWin: !settings().clipOnWin });
        return true;
      case 'toggle-clip-auto-game':
        await saveAndRefresh({ clipAutoGame: !settings().clipAutoGame });
        return true;
      case 'toggle-burn-crosshair':
        await saveAndRefresh({ clipBurnCrosshair: settings().clipBurnCrosshair === false });
        return true;
      case 'toggle-keys-default':
        await saveAndRefresh({ clipKeysShow: settings().clipKeysShow === false });
        return true;
      case 'toggle-keystrokes-controller':
        await saveAndRefresh({ clipKeystrokesController: settings().clipKeystrokesController === false });
        return true;
      case 'toggle-clip-hotkey':
        await saveAndRefresh({ clipHotkeyEnabled: settings().clipHotkeyEnabled === false });
        return true;
      case 'toggle-clip-audio':
        await saveAndRefresh({ clipAudio: settings().clipAudio === false });
        await restartIfRecording();
        return true;
      case 'toggle-long-rec':
        await toggleLongRec();
        return true;
      case 'toggle-cam': {
        const next = !settings().camEnabled;
        await saveAndRefresh({ camEnabled: next });
        if (next) {
          await loadCams(true);
          if (recording) await startCam();
        } else {
          stopCam();
          releaseCamPreview();
        }
        ctx.render();
        return true;
      }
      case 'toggle-clip-mic':
        await saveAndRefresh({ clipMic: !settings().clipMic });
        if (settings().clipMic) await loadMics(true);
        await restartIfRecording();
        return true;
      case 'open-clips': {
        const meta = ctx.getData()?.meta;
        const ok = await ctx.api.openPath(meta?.clipsDir || '');
        if (!ok) ctx.toast('Clip-Ordner konnte nicht geöffnet werden.');
        return true;
      }
      case 'clear-category': {
        const tab = CATEGORY_TABS.find((entry) => entry.id === node.dataset.tab);
        if (!tab || !confirm(`Alle ${tab.label}-Clips löschen?`)) return true;
        applyListResult(await ctx.api.clipClear(tab.id), true);
        return true;
      }
      case 'clear-clips': {
        if (!confirm('Wirklich alle Clips löschen?')) return true;
        applyListResult(await ctx.api.clipClear(), true);
        return true;
      }
      case 'delete-clip': {
        // Direkt löschen – ohne Rückfrage, wie gewünscht.
        applyListResult(await ctx.api.clipDelete(node.dataset.clip), false);
        ctx.render();
        ctx.toast('Clip gelöscht.');
        return true;
      }
      default:
        return false;
    }
  }

  // Suche live beim Tippen; Datum und Sortierung beim Ändern.
  let queryTimer = 0;
  document.addEventListener('input', (event) => {
    if (event.target.id !== 'lib-query') return;
    clearTimeout(queryTimer);
    queryTimer = setTimeout(() => {
      lib.query = event.target.value;
      lib.shown = PAGE_SIZE;
      refreshResults();
    }, 120);
  });

  document.addEventListener('change', async (event) => {
    if (event.target.id === 'lib-date' || event.target.id === 'lib-sort') {
      if (event.target.id === 'lib-date') lib.date = event.target.value;
      else lib.sort = event.target.value;
      lib.shown = PAGE_SIZE;
      ctx.render();
      return;
    }
    const id = event.target.id;
    const fields = [
      'clip-max',
      'clip-seconds',
      'clip-hotkey',
      'clip-fps',
      'clip-quality',
      'clip-kill-seconds',
      'clip-kill-post',
      'clip-name',
      'clip-mic',
      'clip-mic-volume',
      'clip-sys-volume',
      'cam-device',
      'rec-hotkey',
    ];
    if (!fields.includes(id)) return;
    const value = event.target.value;
    const patch = {
      'clip-max': { clipMaxGb: Number(value) },
      'clip-seconds': { clipSeconds: Number(value) },
      'clip-fps': { clipFps: Number(value) },
      'clip-quality': { clipQuality: value },
      'clip-kill-seconds': { clipKillSeconds: Number(value) },
      'clip-kill-post': { clipKillPost: Number(value) },
      'clip-name': { displayName: value.trim() },
      'clip-hotkey': { clipHotkey: value.trim() || 'F9' },
      'clip-mic': { clipMicId: value },
      'clip-mic-volume': { clipMicVolume: Number(value) },
      'clip-sys-volume': { clipSystemVolume: Number(value) },
      'cam-device': { camDeviceId: value },
      'rec-hotkey': { recHotkey: value.trim() || 'F10' },
    }[id];
    await saveAndRefresh(patch);
    if (['clip-mic', 'clip-mic-volume', 'clip-sys-volume'].includes(id)) await restartIfRecording();
    if (id === 'cam-device') {
      releaseCamPreview();
      if (cam.recorder) {
        stopCam();
        await startCam();
      }
      attachCamPreview();
    }
  });

  async function rearm() {
    if (!settings().clipAutoStart) return;
    let list = sources;
    try {
      const fresh = await ctx.api.captureSources();
      if (Array.isArray(fresh) && fresh.length > 0) {
        sources = fresh;
        list = fresh;
      }
    } catch {
      /* ignore */
    }
    const fortnite = (list || []).find(
      (source) => /fortnite/i.test(source.name) && !BROWSER_WINDOW.test(source.name),
    );
    if (!fortnite) {
      if (!recording) await autoStart();
      return;
    }
    if (settings().clipSourceId === fortnite.id) {
      if (!recording) await autoStart();
      return;
    }
    await saveAndRefresh({ clipSourceId: fortnite.id });
    if (recording) stopRecording();
    await startRecording();
  }

  /* ---------------- Live-Vorschau der Tasten ---------------- */

  const liveFlash = new Map();

  function pushKeys(next) {
    keys = Array.isArray(next) ? next : [];
    drawLivePreview();
  }

  function drawLivePreview() {
    const canvas = document.getElementById('keys-live');
    if (!canvas || !window.KeysOverlay) return;
    const ratio = window.devicePixelRatio || 1;
    const cssWidth = canvas.clientWidth || 520;
    const cssHeight = Math.round(cssWidth * 0.4);
    if (canvas.width !== Math.round(cssWidth * ratio)) {
      canvas.width = Math.round(cssWidth * ratio);
      canvas.height = Math.round(cssHeight * ratio);
      canvas.style.height = `${cssHeight}px`;
    }
    const now = performance.now();
    const withPad = settings().clipKeystrokesController !== false;
    for (const key of keys) liveFlash.set(key, now + 140);
    const lit = new Set();
    for (const [key, until] of liveFlash) {
      if (until > now) lit.add(key);
      else liveFlash.delete(key);
    }
    if (!withPad) for (const key of [...lit]) if (key.startsWith('pad-')) lit.delete(key);
    const context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);
    // Höhe so wählen, dass der Block die Vorschau gut ausfüllt.
    window.KeysOverlay.draw(context, canvas.width, canvas.height, lit, {
      controller: withPad,
      anchor: 'center',
      scale: 3.2,
    });
    if (liveFlash.size > 0) {
      clearTimeout(drawLivePreview.timer);
      drawLivePreview.timer = setTimeout(drawLivePreview, 150);
    }
  }

  /* ---------------- Mikrofon-Pegel ----------------
   * Eigene, kleine Mikro-Abfrage nur für die Anzeige im Clips-Tab: zeigt live,
   * ob das gewählte Mikrofon etwas hört. Läuft nur, solange die Leiste sichtbar ist.
   */
  const meter = { stream: null, context: null, analyser: null, raf: 0, id: null, peak: 0, peakAt: 0, opening: false };

  function stopMicMeter() {
    cancelAnimationFrame(meter.raf);
    meter.raf = 0;
    try {
      meter.stream?.getTracks().forEach((track) => track.stop());
    } catch {
      /* egal */
    }
    try {
      meter.context?.close();
    } catch {
      /* egal */
    }
    meter.stream = null;
    meter.context = null;
    meter.analyser = null;
    meter.id = null;
  }

  async function startMicMeter() {
    const fill = document.getElementById('mic-meter-fill');
    const s = settings();
    if (!fill || !s.clipMic) {
      stopMicMeter();
      return;
    }
    const wanted = s.clipMicId || '';
    if (meter.stream && meter.id === wanted) {
      if (!meter.raf) loopMicMeter();
      return;
    }
    if (meter.opening) return;
    meter.opening = true;
    stopMicMeter();
    try {
      const audio = { echoCancellation: false, noiseSuppression: false, autoGainControl: false };
      meter.stream = await navigator.mediaDevices.getUserMedia({
        audio: wanted ? { ...audio, deviceId: { exact: wanted } } : audio,
        video: false,
      });
      meter.context = new AudioContext();
      meter.analyser = meter.context.createAnalyser();
      meter.analyser.fftSize = 1024;
      meter.analyser.smoothingTimeConstant = 0.2;
      meter.context.createMediaStreamSource(meter.stream).connect(meter.analyser);
      meter.id = wanted;
      loopMicMeter();
    } catch {
      stopMicMeter();
      const db = document.getElementById('mic-meter-db');
      if (db) db.textContent = 'Mikro nicht erreichbar';
    }
    meter.opening = false;
  }

  function loopMicMeter() {
    const samples = new Float32Array(meter.analyser ? meter.analyser.fftSize : 1024);
    let level = 0;
    const step = () => {
      const fill = document.getElementById('mic-meter-fill');
      if (!fill || !meter.analyser || !settings().clipMic) {
        // Tab gewechselt oder Mikro aus: Abfrage beenden.
        stopMicMeter();
        return;
      }
      meter.analyser.getFloatTimeDomainData(samples);
      let sum = 0;
      for (let i = 0; i < samples.length; i += 1) sum += samples[i] * samples[i];
      const rms = Math.sqrt(sum / samples.length);
      const gain = Math.max(0, Number(settings().clipMicVolume ?? 100)) / 100;
      const db = Math.max(-60, 20 * Math.log10(rms * gain + 1e-8));
      // -60 dB … 0 dB auf 0 … 100 %; schnell hoch, langsam runter.
      const target = Math.min(1, Math.max(0, (db + 60) / 60));
      level = target > level ? target : level + (target - level) * 0.12;
      const now = performance.now();
      if (level >= meter.peak || now - meter.peakAt > 1200) {
        meter.peak = level;
        meter.peakAt = now;
      }
      fill.style.width = `${(level * 100).toFixed(1)}%`;
      // Farbverlauf gehört zur ganzen Leiste: grün, erst ganz oben gelb/rot.
      const full = fill.parentElement?.clientWidth || 0;
      if (full) fill.style.backgroundSize = `${full}px 100%`;
      const peak = document.getElementById('mic-meter-peak');
      if (peak) peak.style.left = `calc(${(meter.peak * 100).toFixed(1)}% - 2px)`;
      const label = document.getElementById('mic-meter-db');
      if (label) label.textContent = db <= -59 ? 'still' : `${Math.round(db)} dB`;
      meter.raf = requestAnimationFrame(step);
    };
    cancelAnimationFrame(meter.raf);
    meter.raf = requestAnimationFrame(step);
  }

  function afterRender() {
    drawLivePreview();
    startMicMeter();
    if (settings().camEnabled && camDevices.length === 0 && !camLoading) setTimeout(() => loadCams(false), 80);
    if (document.getElementById('cam-preview')) attachCamPreview();
    else releaseCamPreview();
  }

  window.ClipUI = {
    init: (options) => Object.assign(ctx, options),
    render,
    afterRender,
    ensureSources,
    save,
    handleAction,
    autoStart,
    rearm,
    pushKeys,
    openPlayer,
    getKeys: () => keys,
    start: startRecording,
    stop: stopRecording,
    isRecording: () => recording,
    camState: () => ({ on: Boolean(cam.recorder), ext: cam.ext, state: cam.recorder?.state || '' }),
    isPlayerOpen: () => Boolean(player.root),
    setDiag: (text) => {
      diagText = String(text || '');
      const node = document.getElementById('clip-diag');
      if (node && recording) node.textContent = diagText;
    },
  };
})();
