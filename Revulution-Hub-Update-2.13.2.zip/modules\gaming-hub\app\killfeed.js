/**
 * Liest den Kill-Feed aus dem OCR-Text.
 *
 * Fortnite schreibt in den Feed: „Killer hat Opfer mit einem Gewehr eliminiert“
 * (deutsch) bzw. „Killer eliminated Opfer (111) with a pistol (97 m)“ (englisch).
 * Eine Zeile zaehlt nur dann als eigener Kill, wenn der eigene Name darin
 * vorkommt – und das Opfer wird direkt hinter dem eigenen Namen gesucht. Das ist
 * deutlich stabiler als „laengstes Wort“ oder „Wort vor der Level-Klammer“,
 * weil OCR Woerter oft ohne Leerzeichen aneinander klebt.
 * Reine Funktionen ohne Electron, damit sie testbar bleiben.
 */

function normalize(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

function distance(a, b) {
  const left = String(a || '');
  const right = String(b || '');
  if (left === right) return 0;
  if (!left.length) return right.length;
  if (!right.length) return left.length;

  let previous = Array.from({ length: right.length + 1 }, (_, index) => index);
  for (let i = 1; i <= left.length; i += 1) {
    const current = [i];
    for (let j = 1; j <= right.length; j += 1) {
      const cost = left[i - 1] === right[j - 1] ? 0 : 1;
      current[j] = Math.min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost);
    }
    previous = current;
  }
  return previous[right.length];
}

function isSameName(candidate, ownNames) {
  const value = normalize(candidate);
  if (value.length < 3) return false;
  for (const own of ownNames || []) {
    const target = normalize(own);
    if (!target) continue;
    if (value === target) return true;
    if (target.length >= 5 && value.length >= 5 && distance(value, target) <= 2) return true;
  }
  return false;
}

function cleanWord(word) {
  return String(word || '').replace(/^[^A-Za-z0-9]+|[^A-Za-z0-9]+$/g, '');
}

// UI-Woerter, die nie ein Spielername sind.
const STOPWORDS = new Set([
  'eliminated',
  'eliminiert',
  'eliminier',
  'elimination',
  'eliminations',
  'knocked',
  'downed',
  'down',
  'ausgeschaltet',
  'ausschaltet',
  'besiegt',
  'beseitigt',
  'erledigt',
  'getoetet',
  'player',
  'spieler',
  'squad',
  'team',
  'with',
  'mit',
  'hat',
  'hast',
  'haben',
  'have',
  'has',
  'was',
  'were',
  'wurde',
  'you',
  'du',
  'ihr',
  'und',
  'and',
  'the',
  'der',
  'die',
  'das',
  'von',
  'by',
  'for',
  'fuer',
  'für',
  'level',
  'lvl',
  'rest',
  'gegeben',
  'boden',
  'geschickt',
  'ein',
  'eine',
  'einen',
  'einem',
  'einer',
  'den',
  'dem',
  'des',
  'zu',
  'im',
  'in',
  'an',
  'auf',
  'aus',
  'ist',
  'war',
]);

// Waffen und Verben tauchen im Feed direkt neben dem Namen auf.
const WEAPON_WORDS = /gewehr|schrot|pistole|maschinenpistole|schleuder|sniper|shotgun|pistol|smg|rifle|bogen|bow|pickaxe|spitzhacke|granate|faust|steinschleu/i;
const VERB_START = /^(elimin|ausschalt|besieg|beseitig|erledig|getoet|getöt|killed|kill|knock|nieder|boden|rest|geschickt)/i;

/** Sieht der Text wie ein Spielername aus? Filtert OCR-Muell und UI-Woerter aus. */
function isPlausibleName(name) {
  const value = cleanWord(name);
  const letters = (value.match(/[A-Za-z]/g) || []).length;
  if (value.length < 3 || value.length > 24) return false;
  if (letters < 3) return false;
  if (STOPWORDS.has(normalize(value))) return false;
  if (WEAPON_WORDS.test(value)) return false;
  if (VERB_START.test(value)) return false;
  return true;
}

// Kill- und Knock-Zeilen unterscheiden sich nur in der Beschriftung.
const KNOCK_WORDS = /knock|down|boden|angeschlagen|niedergeschlagen|kampfunfaehig|kampfunfähig|ausgeknockt/i;
// OCR schneidet Woerter ab („eliminie“ statt „eliminiert“) – deshalb Wortstaemme.
const KILL_WORDS = /elimin|ausgeschalt|ausschalt|besieg|beseitig|erledig|getoet|getöt|killed|den\s*rest|rest\s*gegeben/i;

function stateOfLine(line) {
  const text = String(line || '');
  if (KNOCK_WORDS.test(text)) return 'down';
  return KILL_WORDS.test(text) ? 'dead' : null;
}

/**
 * Sucht den eigenen Namen in der Zeile. Erst exakt, dann mit einer kleinen
 * Fehlertoleranz – OCR verwechselt regelmaessig einzelne Zeichen.
 */
function findOwn(text, ownNames) {
  const value = String(text || '');
  if (!value) return null;
  const lower = value.toLowerCase();
  const names = (ownNames || [])
    .map((name) => String(name || '').trim())
    .filter((name) => name.length >= 3)
    .sort((a, b) => b.length - a.length)
    .slice(0, 8);

  let best = null;
  for (const name of names) {
    const index = lower.indexOf(name.toLowerCase());
    if (index >= 0 && (!best || name.length > best.length)) best = { index, length: name.length };
  }
  if (best) return best;

  for (const name of names) {
    const span = name.length;
    const limit = Math.max(1, Math.floor(span * 0.2));
    const target = name.toLowerCase();
    for (let start = 0; start + span <= value.length; start += 1) {
      let letters = 0;
      for (let offset = 0; offset < span; offset += 1) {
        if (/[A-Za-z0-9]/.test(value[start + offset])) letters += 1;
      }
      if (letters < span - 1) continue;
      if (distance(value.slice(start, start + span).toLowerCase(), target) <= limit) {
        return { index: start, length: span };
      }
    }
  }
  return null;
}

// Opfer steht direkt vor seiner Level-Klammer: „RoDnik92 (111)“.
const LEVEL_ANCHOR = /([A-Za-z0-9_.-]{2,})\s*\(\s*\d{1,3}\s*\)/;

/** Opfer hinter dem eigenen Namen: „… hat OPFER mit/den Rest …“. */
function victimAfterOwn(line, ownNames) {
  const text = String(line || '');
  const own = findOwn(text, ownNames);
  if (!own) return null;

  // OCR haengt Zahlen des eigenen Namens an und klebt Woerter zusammen.
  const after = text.slice(own.index + own.length).replace(/^[\s\d.,:_'’"-]+/, '');

  // „hat OPFER mit …“ – auch wenn OCR alles zusammen klebt („hatXmit“).
  let match = /hat\s*(.{2,28}?)\s*mit/i.exec(after);
  if (!match) match = /hat\s*([^\s]{2,24})/i.exec(after);
  if (!match) match = /^eliminat\w*\s*([A-Za-z0-9_.\-]{2,24})/i.exec(after);
  if (!match) {
    // „OPFER mit einem Gewehr eliminiert“ – Opfer steht vor der Waffe.
    match = /^([A-Za-z0-9_.\-]{2,24}?)\s*mit/i.exec(after);
  }
  if (!match) return null;

  let name = cleanWord(match[1]);
  const level = LEVEL_ANCHOR.exec(after);
  if (level && normalize(level[1]).startsWith(normalize(name))) name = cleanWord(level[1]);
  return isPlausibleName(name) ? name.slice(0, 24) : null;
}

/** Opfer zuerst: „OPFER wurde aus der Ferne von DIR … ausgeschaltet!“ */
function victimBeforeOwn(line, ownNames) {
  const text = String(line || '');
  const wurde = /\bwurde\b/i.exec(text);
  if (!wurde) return null;
  const before = text.slice(0, wurde.index).trim();
  const name = cleanWord(before.split(/\s+/).pop() || '');
  const ownBefore = findOwn(before, ownNames);
  // Steht der eigene Name schon davor, ist die eigene Zeile gemeint (unten).
  if (ownBefore) return null;
  return isPlausibleName(name) ? name : null;
}

/** -> [{ victimName, state }] */
function parseFeed(text, ownNames) {
  const hits = [];
  const seen = new Set();

  const push = (victim, state) => {
    const key = normalize(victim);
    if (!key || seen.has(key)) return;
    seen.add(key);
    hits.push({ victimName: victim, state: state === 'down' ? 'down' : 'dead' });
  };

  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = String(raw || '').trim();
    if (line.length < 6) continue;
    if (!findOwn(line, ownNames)) continue;

    // „<eigener Name> hat <Opfer>“ ist schon fuer sich eine Kill-Zeile; das Verb
    // am Ende kann OCR abgeschnitten haben.
    let victim = victimAfterOwn(line, ownNames) || victimBeforeOwn(line, ownNames);
    const state = stateOfLine(line) || 'dead';
    if (!victim) {
      // Gegnername unlesbar (farbig auf hellem Grund)? „<eigener Name> hat …
      // eliminiert/erledigt“ reicht als eigener Kill – der Name ist egal.
      const own = findOwn(line, ownNames);
      const after = own ? line.slice(own.index + own.length) : '';
      if (!/^[\s\d().,:_'’"-]{0,8}hat/i.test(after) || stateOfLine(line) !== 'dead') continue;
      victim = 'Gegner';
    }
    push(victim, state);
  }

  return hits;
}

module.exports = { parseFeed, normalize, distance, isSameName, stateOfLine, isPlausibleName };
