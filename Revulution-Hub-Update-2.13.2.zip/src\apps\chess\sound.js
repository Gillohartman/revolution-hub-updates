'use strict';

/* Alle Töne werden live erzeugt (keine Audiodateien). */
(function () {
  let ctx = null;
  let master = null;
  let reverb = null;
  let enabled = true;

  function audio() {
    if (!ctx) {
      ctx = new AudioContext();
      master = ctx.createGain();
      master.gain.value = 0.55;
      master.connect(ctx.destination);
      // kleiner Hall aus gefiltertem Rauschen
      const len = ctx.sampleRate * 1.6;
      const buf = ctx.createBuffer(2, len, ctx.sampleRate);
      for (let ch = 0; ch < 2; ch += 1) {
        const d = buf.getChannelData(ch);
        for (let i = 0; i < len; i += 1) d[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 3;
      }
      reverb = ctx.createConvolver();
      reverb.buffer = buf;
      const wet = ctx.createGain();
      wet.gain.value = 0.35;
      reverb.connect(wet).connect(master);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, { at = 0, dur = 0.25, type = 'sine', vol = 0.2, wet = false, slide = 0, attack = 0.008 } = {}) {
    const a = audio();
    const t = a.currentTime + at;
    const osc = a.createOscillator();
    const g = a.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(master);
    if (wet) g.connect(reverb);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  function knock({ at = 0, freq = 1800, vol = 0.5, dur = 0.05, q = 1.2 } = {}) {
    const a = audio();
    const t = a.currentTime + at;
    const len = Math.floor(a.sampleRate * dur);
    const buf = a.createBuffer(1, len, a.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i += 1) d[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 4;
    const src = a.createBufferSource();
    src.buffer = buf;
    const f = a.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = freq;
    f.Q.value = q;
    const g = a.createGain();
    g.gain.value = vol;
    src.connect(f).connect(g).connect(master);
    src.start(t);
  }

  const sounds = {
    move() {
      knock({ freq: 1500, vol: 0.9 });
      tone(180, { dur: 0.06, vol: 0.12, type: 'triangle' });
    },
    capture() {
      knock({ freq: 900, vol: 1.1, dur: 0.07 });
      knock({ at: 0.03, freq: 2200, vol: 0.5 });
      tone(120, { dur: 0.1, vol: 0.18, type: 'triangle' });
    },
    castle() {
      knock({ freq: 1500, vol: 0.8 });
      knock({ at: 0.09, freq: 1300, vol: 0.8 });
    },
    check() {
      knock({ freq: 1500, vol: 0.8 });
      tone(880, { at: 0.02, dur: 0.18, type: 'triangle', vol: 0.12 });
      tone(1320, { at: 0.1, dur: 0.22, type: 'triangle', vol: 0.1 });
    },
    best() {
      tone(1046, { dur: 0.35, vol: 0.08, wet: true });
      tone(1568, { at: 0.06, dur: 0.4, vol: 0.06, wet: true });
    },
    great() {
      [784, 1046, 1318].forEach((f, i) => tone(f, { at: i * 0.07, dur: 0.5, vol: 0.09, type: 'triangle', wet: true }));
    },
    brilliant() {
      // Aufsteigendes Arpeggio mit Glitzern und Hall
      [523, 659, 784, 1046, 1318, 1568, 2093].forEach((f, i) =>
        tone(f, { at: i * 0.065, dur: 0.9 - i * 0.05, vol: 0.11, type: i % 2 ? 'sine' : 'triangle', wet: true }),
      );
      for (let i = 0; i < 14; i += 1) tone(2600 + Math.random() * 2600, { at: 0.35 + i * 0.045, dur: 0.25, vol: 0.035, wet: true });
      tone(130, { at: 0.42, dur: 1.1, vol: 0.16, type: 'sine', wet: true });
      tone(196, { at: 0.42, dur: 1.1, vol: 0.1, type: 'sine', wet: true });
    },
    oops() {
      // „Oh-oh“: zwei fallende Töne
      tone(520, { dur: 0.22, type: 'sawtooth', vol: 0.06, slide: -60 });
      tone(390, { at: 0.24, dur: 0.38, type: 'sawtooth', vol: 0.06, slide: -120 });
      tone(260, { at: 0.24, dur: 0.38, type: 'sine', vol: 0.1, slide: -80 });
    },
    nice() {
      tone(660, { dur: 0.18, vol: 0.08, type: 'triangle' });
      tone(990, { at: 0.08, dur: 0.3, vol: 0.08, type: 'triangle', wet: true });
    },
    win() {
      [523, 659, 784].forEach((f, i) => tone(f, { at: i * 0.12, dur: 0.3, vol: 0.12, type: 'triangle', wet: true }));
      [523, 659, 784, 1046].forEach((f) => tone(f, { at: 0.42, dur: 1.2, vol: 0.07, type: 'triangle', wet: true }));
    },
    lose() {
      [392, 370, 349, 262].forEach((f, i) => tone(f, { at: i * 0.18, dur: 0.4, vol: 0.09, type: 'triangle', wet: true }));
    },
    draw() {
      tone(523, { dur: 0.4, vol: 0.09, type: 'triangle', wet: true });
      tone(523, { at: 0.2, dur: 0.6, vol: 0.07, type: 'sine', wet: true });
    },
    start() {
      [392, 523, 659].forEach((f, i) => tone(f, { at: i * 0.08, dur: 0.35, vol: 0.08, type: 'triangle', wet: true }));
    },
  };

  window.ChessSound = {
    play(name) {
      if (!enabled || !sounds[name]) return;
      try {
        sounds[name]();
      } catch {
        /* ohne Ton */
      }
    },
    set enabled(value) {
      enabled = Boolean(value);
    },
    get enabled() {
      return enabled;
    },
  };
})();
