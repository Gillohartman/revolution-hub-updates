'use strict';

/*
 * Schachregeln: 0x88-Brett, Zuggenerator, Ziehen/Zurücknehmen, FEN, SAN (deutsch),
 * Spielende-Erkennung. Läuft im Renderer und im Engine-Worker.
 */
(function (root) {
  const PAWN = 1, KNIGHT = 2, BISHOP = 3, ROOK = 4, QUEEN = 5, KING = 6;
  const WHITE = 0, BLACK = 8;
  const F_CAPTURE = 1, F_EP = 2, F_CASTLE = 4, F_DOUBLE = 8, F_PROMO = 16;

  const VALUE = [0, 100, 320, 330, 500, 900, 0];
  const POINTS = [0, 1, 3, 3, 5, 9, 0];
  const KNIGHT_D = [33, 31, 18, 14, -33, -31, -18, -14];
  const KING_D = [1, -1, 16, -16, 15, 17, -15, -17];
  const BISHOP_D = [15, 17, -15, -17];
  const ROOK_D = [1, -1, 16, -16];
  const FEN_CHARS = ' pnbrqk';
  const SAN_DE = { 2: 'S', 3: 'L', 4: 'T', 5: 'D', 6: 'K' };
  const SAN_EN = { 2: 'N', 3: 'B', 4: 'R', 5: 'Q', 6: 'K' };
  const SAN_ES = { 2: 'C', 3: 'A', 4: 'T', 5: 'D', 6: 'R' };
  const NAME_DE = ['', 'Bauer', 'Springer', 'Läufer', 'Turm', 'Dame', 'König'];
  const NAME_DE_ACC = ['', 'Bauern', 'Springer', 'Läufer', 'Turm', 'Dame', 'König'];
  const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

  // Rochaderechte, die ein Zug von/auf diesem Feld löscht.
  const CASTLE_MASK = new Int8Array(128).fill(15);
  CASTLE_MASK[0] = 15 & ~2;
  CASTLE_MASK[7] = 15 & ~1;
  CASTLE_MASK[4] = 15 & ~3;
  CASTLE_MASK[112] = 15 & ~8;
  CASTLE_MASK[119] = 15 & ~4;
  CASTLE_MASK[116] = 15 & ~12;

  // Zobrist mit zwei 32-Bit-Hälften (feste Saat → gleiche Werte in Worker und Seite).
  let seed = 0x9e3779b9;
  const rnd = () => {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    return seed | 0;
  };
  const ZA = new Int32Array(16 * 128), ZB = new Int32Array(16 * 128);
  for (let i = 0; i < ZA.length; i += 1) {
    ZA[i] = rnd();
    ZB[i] = rnd();
  }
  const Z_SIDE_A = rnd(), Z_SIDE_B = rnd();
  const ZC_A = new Int32Array(16), ZC_B = new Int32Array(16);
  for (let i = 0; i < 16; i += 1) {
    ZC_A[i] = rnd();
    ZC_B[i] = rnd();
  }
  const ZE_A = new Int32Array(8), ZE_B = new Int32Array(8);
  for (let i = 0; i < 8; i += 1) {
    ZE_A[i] = rnd();
    ZE_B[i] = rnd();
  }

  const sqName = (sq) => 'abcdefgh'[sq & 7] + ((sq >> 4) + 1);
  const sqFrom = (name) => (parseInt(name[1], 10) - 1) * 16 + (name.charCodeAt(0) - 97);
  const typeOf = (p) => p & 7;
  const colorOf = (p) => p & 8;
  const uci = (m) => sqName(m.from) + sqName(m.to) + (m.promo ? FEN_CHARS[m.promo] : '');

  class Position {
    constructor(fen = START_FEN) {
      this.load(fen);
    }

    load(fen) {
      const parts = String(fen).trim().split(/\s+/);
      this.b = new Int8Array(128);
      this.kings = [0, 0];
      let rank = 7, file = 0;
      for (const ch of parts[0]) {
        if (ch === '/') {
          rank -= 1;
          file = 0;
        } else if (/\d/.test(ch)) file += Number(ch);
        else {
          const lower = ch.toLowerCase();
          const type = FEN_CHARS.indexOf(lower);
          const color = ch === lower ? BLACK : WHITE;
          const sq = rank * 16 + file;
          this.b[sq] = type | color;
          if (type === KING) this.kings[color >> 3] = sq;
          file += 1;
        }
      }
      this.turn = parts[1] === 'b' ? BLACK : WHITE;
      const c = parts[2] || '-';
      this.castle = (c.includes('K') ? 1 : 0) | (c.includes('Q') ? 2 : 0) | (c.includes('k') ? 4 : 0) | (c.includes('q') ? 8 : 0);
      this.ep = parts[3] && parts[3] !== '-' ? sqFrom(parts[3]) : -1;
      this.half = Number(parts[4]) || 0;
      this.full = Number(parts[5]) || 1;
      this.hist = [];
      this.computeHash();
      this.keys = [this.key()];
    }

    computeHash() {
      let a = 0, b = 0;
      for (let sq = 0; sq < 128; sq += 1) {
        if (sq & 0x88 || !this.b[sq]) continue;
        a ^= ZA[this.b[sq] * 128 + sq];
        b ^= ZB[this.b[sq] * 128 + sq];
      }
      if (this.turn === BLACK) {
        a ^= Z_SIDE_A;
        b ^= Z_SIDE_B;
      }
      a ^= ZC_A[this.castle];
      b ^= ZC_B[this.castle];
      if (this.ep >= 0) {
        a ^= ZE_A[this.ep & 7];
        b ^= ZE_B[this.ep & 7];
      }
      this.ha = a;
      this.hb = b;
    }

    key() {
      return (this.ha >>> 0) * 2097152 + (this.hb & 0x1fffff);
    }

    clone() {
      const p = Object.create(Position.prototype);
      p.b = new Int8Array(this.b);
      p.kings = this.kings.slice();
      p.turn = this.turn;
      p.castle = this.castle;
      p.ep = this.ep;
      p.half = this.half;
      p.full = this.full;
      p.ha = this.ha;
      p.hb = this.hb;
      p.hist = [];
      p.keys = this.keys.slice();
      return p;
    }

    fen() {
      let out = '';
      for (let rank = 7; rank >= 0; rank -= 1) {
        let empty = 0;
        for (let file = 0; file < 8; file += 1) {
          const p = this.b[rank * 16 + file];
          if (!p) {
            empty += 1;
            continue;
          }
          if (empty) out += empty;
          empty = 0;
          const ch = FEN_CHARS[typeOf(p)];
          out += colorOf(p) === WHITE ? ch.toUpperCase() : ch;
        }
        if (empty) out += empty;
        if (rank) out += '/';
      }
      let c = '';
      if (this.castle & 1) c += 'K';
      if (this.castle & 2) c += 'Q';
      if (this.castle & 4) c += 'k';
      if (this.castle & 8) c += 'q';
      return `${out} ${this.turn === WHITE ? 'w' : 'b'} ${c || '-'} ${this.ep >= 0 ? sqName(this.ep) : '-'} ${this.half} ${this.full}`;
    }

    /* ------------------------------------------------------------- Angriffe */

    attacked(sq, by) {
      const b = this.b;
      if (by === WHITE) {
        if (!((sq - 15) & 0x88) && b[sq - 15] === (PAWN | WHITE)) return true;
        if (!((sq - 17) & 0x88) && b[sq - 17] === (PAWN | WHITE)) return true;
      } else {
        if (!((sq + 15) & 0x88) && b[sq + 15] === (PAWN | BLACK)) return true;
        if (!((sq + 17) & 0x88) && b[sq + 17] === (PAWN | BLACK)) return true;
      }
      for (const d of KNIGHT_D) {
        const t = sq + d;
        if (!(t & 0x88) && b[t] === (KNIGHT | by)) return true;
      }
      for (const d of KING_D) {
        const t = sq + d;
        if (!(t & 0x88) && b[t] === (KING | by)) return true;
      }
      for (const d of BISHOP_D) {
        let t = sq + d;
        while (!(t & 0x88)) {
          const p = b[t];
          if (p) {
            if (colorOf(p) === by && (typeOf(p) === BISHOP || typeOf(p) === QUEEN)) return true;
            break;
          }
          t += d;
        }
      }
      for (const d of ROOK_D) {
        let t = sq + d;
        while (!(t & 0x88)) {
          const p = b[t];
          if (p) {
            if (colorOf(p) === by && (typeOf(p) === ROOK || typeOf(p) === QUEEN)) return true;
            break;
          }
          t += d;
        }
      }
      return false;
    }

    /** Alle Felder, von denen Figuren der Farbe `by` das Feld angreifen. */
    attackers(sq, by) {
      const out = [];
      const b = this.b;
      const pawnFrom = by === WHITE ? [sq - 15, sq - 17] : [sq + 15, sq + 17];
      for (const t of pawnFrom) if (!(t & 0x88) && b[t] === (PAWN | by)) out.push(t);
      for (const d of KNIGHT_D) {
        const t = sq + d;
        if (!(t & 0x88) && b[t] === (KNIGHT | by)) out.push(t);
      }
      for (const d of KING_D) {
        const t = sq + d;
        if (!(t & 0x88) && b[t] === (KING | by)) out.push(t);
      }
      for (const [dirs, a, c] of [[BISHOP_D, BISHOP, QUEEN], [ROOK_D, ROOK, QUEEN]]) {
        for (const d of dirs) {
          let t = sq + d;
          while (!(t & 0x88)) {
            const p = b[t];
            if (p) {
              if (colorOf(p) === by && (typeOf(p) === a || typeOf(p) === c)) out.push(t);
              break;
            }
            t += d;
          }
        }
      }
      return out;
    }

    inCheck(color = this.turn) {
      return this.attacked(this.kings[color >> 3], color ^ 8);
    }

    /* ------------------------------------------------------------- Züge */

    moves(capturesOnly = false) {
      const out = [];
      const b = this.b;
      const us = this.turn, them = us ^ 8;
      const add = (from, to, piece, flags, captured) => {
        if (typeOf(piece) === PAWN && ((to >> 4) === 7 || (to >> 4) === 0)) {
          for (const promo of capturesOnly ? [QUEEN] : [QUEEN, KNIGHT, ROOK, BISHOP]) out.push({ from, to, piece, captured, promo, flags: flags | F_PROMO });
        } else out.push({ from, to, piece, captured, promo: 0, flags });
      };
      for (let from = 0; from < 128; from += 1) {
        if (from & 0x88) {
          from += 7;
          continue;
        }
        const piece = b[from];
        if (!piece || colorOf(piece) !== us) continue;
        const type = typeOf(piece);
        if (type === PAWN) {
          const dir = us === WHITE ? 16 : -16;
          const startRank = us === WHITE ? 1 : 6;
          const one = from + dir;
          if (!(one & 0x88) && !b[one]) {
            const promoting = (one >> 4) === 7 || (one >> 4) === 0;
            if (!capturesOnly || promoting) add(from, one, piece, 0, 0);
            const two = one + dir;
            if (!capturesOnly && (from >> 4) === startRank && !b[two]) add(from, two, piece, F_DOUBLE, 0);
          }
          for (const side of [-1, 1]) {
            const to = from + dir + side;
            if (to & 0x88) continue;
            if (b[to] && colorOf(b[to]) === them) add(from, to, piece, F_CAPTURE, b[to]);
            else if (to === this.ep) add(from, to, piece, F_CAPTURE | F_EP, PAWN | them);
          }
        } else if (type === KNIGHT || type === KING) {
          for (const d of type === KNIGHT ? KNIGHT_D : KING_D) {
            const to = from + d;
            if (to & 0x88) continue;
            const target = b[to];
            if (!target) {
              if (!capturesOnly) add(from, to, piece, 0, 0);
            } else if (colorOf(target) === them) add(from, to, piece, F_CAPTURE, target);
          }
          if (type === KING && !capturesOnly) this.castleMoves(from, piece, out);
        } else {
          const dirs = type === BISHOP ? BISHOP_D : type === ROOK ? ROOK_D : KING_D;
          for (const d of dirs) {
            let to = from + d;
            while (!(to & 0x88)) {
              const target = b[to];
              if (!target) {
                if (!capturesOnly) add(from, to, piece, 0, 0);
              } else {
                if (colorOf(target) === them) add(from, to, piece, F_CAPTURE, target);
                break;
              }
              to += d;
            }
          }
        }
      }
      return out;
    }

    castleMoves(from, piece, out) {
      const b = this.b;
      const us = this.turn, them = us ^ 8;
      if (us === WHITE && from === 4) {
        if (this.castle & 1 && !b[5] && !b[6] && b[7] === (ROOK | WHITE) && !this.attacked(4, them) && !this.attacked(5, them) && !this.attacked(6, them))
          out.push({ from, to: 6, piece, captured: 0, promo: 0, flags: F_CASTLE });
        if (this.castle & 2 && !b[3] && !b[2] && !b[1] && b[0] === (ROOK | WHITE) && !this.attacked(4, them) && !this.attacked(3, them) && !this.attacked(2, them))
          out.push({ from, to: 2, piece, captured: 0, promo: 0, flags: F_CASTLE });
      } else if (us === BLACK && from === 116) {
        if (this.castle & 4 && !b[117] && !b[118] && b[119] === (ROOK | BLACK) && !this.attacked(116, them) && !this.attacked(117, them) && !this.attacked(118, them))
          out.push({ from, to: 118, piece, captured: 0, promo: 0, flags: F_CASTLE });
        if (this.castle & 8 && !b[115] && !b[114] && !b[113] && b[112] === (ROOK | BLACK) && !this.attacked(116, them) && !this.attacked(115, them) && !this.attacked(114, them))
          out.push({ from, to: 114, piece, captured: 0, promo: 0, flags: F_CASTLE });
      }
    }

    put(sq, p) {
      this.b[sq] = p;
      this.ha ^= ZA[p * 128 + sq];
      this.hb ^= ZB[p * 128 + sq];
    }

    remove(sq) {
      const p = this.b[sq];
      this.ha ^= ZA[p * 128 + sq];
      this.hb ^= ZB[p * 128 + sq];
      this.b[sq] = 0;
    }

    /** Führt einen (pseudo-legalen) Zug aus. Gibt false zurück und nimmt ihn zurück, wenn er den eigenen König im Schach lässt. */
    make(m) {
      const us = this.turn;
      this.hist.push({ m, castle: this.castle, ep: this.ep, half: this.half, ha: this.ha, hb: this.hb });
      this.ha ^= ZC_A[this.castle];
      this.hb ^= ZC_B[this.castle];
      if (this.ep >= 0) {
        this.ha ^= ZE_A[this.ep & 7];
        this.hb ^= ZE_B[this.ep & 7];
      }
      if (m.flags & F_EP) this.remove(m.to + (us === WHITE ? -16 : 16));
      else if (m.flags & F_CAPTURE) this.remove(m.to);
      this.remove(m.from);
      this.put(m.to, m.promo ? m.promo | us : m.piece);
      if (m.flags & F_CASTLE) {
        const [rf, rt] = m.to === 6 ? [7, 5] : m.to === 2 ? [0, 3] : m.to === 118 ? [119, 117] : [112, 115];
        const rook = this.b[rf];
        this.remove(rf);
        this.put(rt, rook);
      }
      if (typeOf(m.piece) === KING) this.kings[us >> 3] = m.to;
      this.castle &= CASTLE_MASK[m.from] & CASTLE_MASK[m.to];
      this.ep = m.flags & F_DOUBLE ? m.from + (us === WHITE ? 16 : -16) : -1;
      this.half = typeOf(m.piece) === PAWN || m.flags & F_CAPTURE ? 0 : this.half + 1;
      if (us === BLACK) this.full += 1;
      this.turn = us ^ 8;
      this.ha ^= Z_SIDE_A ^ ZC_A[this.castle];
      this.hb ^= Z_SIDE_B ^ ZC_B[this.castle];
      if (this.ep >= 0) {
        this.ha ^= ZE_A[this.ep & 7];
        this.hb ^= ZE_B[this.ep & 7];
      }
      this.keys.push(this.key());
      if (this.attacked(this.kings[us >> 3], us ^ 8)) {
        this.unmake();
        return false;
      }
      return true;
    }

    unmake() {
      const h = this.hist.pop();
      if (!h) return null;
      const m = h.m;
      this.keys.pop();
      this.turn ^= 8;
      const us = this.turn;
      if (us === BLACK) this.full -= 1;
      this.b[m.to] = 0;
      this.b[m.from] = m.piece;
      if (m.flags & F_EP) this.b[m.to + (us === WHITE ? -16 : 16)] = m.captured;
      else if (m.flags & F_CAPTURE) this.b[m.to] = m.captured;
      if (m.flags & F_CASTLE) {
        const [rf, rt] = m.to === 6 ? [7, 5] : m.to === 2 ? [0, 3] : m.to === 118 ? [119, 117] : [112, 115];
        this.b[rf] = this.b[rt];
        this.b[rt] = 0;
      }
      if (typeOf(m.piece) === KING) this.kings[us >> 3] = m.from;
      this.castle = h.castle;
      this.ep = h.ep;
      this.half = h.half;
      this.ha = h.ha;
      this.hb = h.hb;
      return m;
    }

    makeNull() {
      this.hist.push({ m: null, castle: this.castle, ep: this.ep, half: this.half, ha: this.ha, hb: this.hb });
      if (this.ep >= 0) {
        this.ha ^= ZE_A[this.ep & 7];
        this.hb ^= ZE_B[this.ep & 7];
      }
      this.ep = -1;
      this.turn ^= 8;
      this.ha ^= Z_SIDE_A;
      this.hb ^= Z_SIDE_B;
      this.keys.push(this.key());
    }

    unmakeNull() {
      const h = this.hist.pop();
      this.keys.pop();
      this.turn ^= 8;
      this.ep = h.ep;
      this.ha = h.ha;
      this.hb = h.hb;
    }

    legalMoves() {
      const out = [];
      for (const m of this.moves()) {
        if (this.make(m)) {
          this.unmake();
          out.push(m);
        }
      }
      return out;
    }

    find(uciText) {
      const t = String(uciText || '').toLowerCase();
      const legal = this.legalMoves();
      return legal.find((m) => uci(m) === t) || (t.length === 4 ? legal.find((m) => uci(m) === `${t}q`) : null) || null;
    }

    /** Wiederholungen der aktuellen Stellung seit dem letzten Bauernzug/Schlagen. */
    repetitions() {
      const k = this.keys[this.keys.length - 1];
      let count = 0;
      for (let i = this.keys.length - 1, n = 0; i >= 0 && n <= this.half; i -= 1, n += 1) if (this.keys[i] === k) count += 1;
      return count;
    }

    insufficient() {
      const minors = [];
      for (let sq = 0; sq < 128; sq += 1) {
        if (sq & 0x88) continue;
        const p = this.b[sq];
        if (!p || typeOf(p) === KING) continue;
        if (typeOf(p) === PAWN || typeOf(p) === ROOK || typeOf(p) === QUEEN) return false;
        minors.push({ p, sq });
      }
      if (minors.length <= 1) return true;
      if (minors.every((x) => typeOf(x.p) === BISHOP)) {
        const shade = (sq) => ((sq >> 4) + (sq & 7)) & 1;
        return minors.every((x) => shade(x.sq) === shade(minors[0].sq));
      }
      return false;
    }

    /** null = läuft; sonst { result: '1-0'|'0-1'|'1/2-1/2', reason } */
    status() {
      const legal = this.legalMoves();
      if (!legal.length) {
        if (this.inCheck()) return { result: this.turn === WHITE ? '0-1' : '1-0', reason: 'Schachmatt' };
        return { result: '1/2-1/2', reason: 'Patt' };
      }
      if (this.half >= 100) return { result: '1/2-1/2', reason: '50-Züge-Regel' };
      if (this.repetitions() >= 3) return { result: '1/2-1/2', reason: 'Dreifache Wiederholung' };
      if (this.insufficient()) return { result: '1/2-1/2', reason: 'Zu wenig Material' };
      return null;
    }

    /** Kurznotation; lang = 'de' (S, L, T, D, K) oder 'en'. */
    san(m, lang = 'de') {
      const letters = lang === 'de' ? SAN_DE : lang === 'es' ? SAN_ES : SAN_EN;
      let s;
      if (m.flags & F_CASTLE) s = (m.to & 7) === 6 ? 'O-O' : 'O-O-O';
      else {
        const type = typeOf(m.piece);
        s = '';
        if (type === PAWN) {
          if (m.flags & F_CAPTURE) s += 'abcdefgh'[m.from & 7];
        } else {
          s += letters[type];
          const rivals = this.legalMoves().filter((o) => o.to === m.to && o.piece === m.piece && o.from !== m.from);
          if (rivals.length) {
            const sameFile = rivals.some((o) => (o.from & 7) === (m.from & 7));
            const sameRank = rivals.some((o) => (o.from >> 4) === (m.from >> 4));
            if (!sameFile) s += 'abcdefgh'[m.from & 7];
            else if (!sameRank) s += (m.from >> 4) + 1;
            else s += sqName(m.from);
          }
        }
        if (m.flags & F_CAPTURE) s += 'x';
        s += sqName(m.to);
        if (m.promo) s += `=${letters[m.promo]}`;
      }
      if (this.make(m)) {
        if (this.inCheck()) s += this.legalMoves().length ? '+' : '#';
        this.unmake();
      }
      return s;
    }

    /** Material in Bauerneinheiten für eine Farbe. */
    material(color) {
      let sum = 0;
      for (let sq = 0; sq < 128; sq += 1) {
        if (sq & 0x88) continue;
        const p = this.b[sq];
        if (p && colorOf(p) === color) sum += POINTS[typeOf(p)];
      }
      return sum;
    }
  }

  const api = {
    Position,
    PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING, WHITE, BLACK,
    F_CAPTURE, F_EP, F_CASTLE, F_DOUBLE, F_PROMO,
    VALUE, POINTS, NAME_DE, NAME_DE_ACC, START_FEN,
    KNIGHT_D, KING_D, BISHOP_D, ROOK_D,
    sqName, sqFrom, typeOf, colorOf, uci,
  };
  root.ChessCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
