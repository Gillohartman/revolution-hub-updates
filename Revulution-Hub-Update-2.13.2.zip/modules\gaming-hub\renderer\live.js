'use strict';

/*
 * Live-Erkennung: liest den Kill-Feed im Spiel, ohne dass die Clip-Aufnahme laufen muss.
 * Die Aufnahme läuft nur für die OCR (kein Video auf der Platte, kein MediaRecorder).
 */
(() => {
  const FORTNITE = /fortnite/i;
  const BROWSER = /chrome|edge|firefox|brave|opera|vivaldi|claude|freebuff|electron/i;
  const RETRY_MS = 8000;
  const SOURCE_CHECK_MS = 8000;

  const ctx = { api: null, getSettings: () => ({}), onStatus: () => {} };

  const state = {
    wanted: false,
    status: 'off', // off | starting | live | no-source | error
    sourceId: null,
    sourceName: '',
    message: 'Live-Erkennung aus',
    since: 0,
  };

  let stream = null;
  let retryTimer = null;
  let checkTimer = null;
  let connecting = false;

  const streamAlive = () =>
    Boolean(stream && stream.getVideoTracks().some((track) => track.readyState === 'live'));

  const snapshot = () => ({
    ...state,
    active: state.status === 'live',
    streamLive: streamAlive(),
  });

  function publish(message) {
    if (typeof message === 'string') state.message = message;
    console.log('[live]', state.status, '·', state.message);
    try {
      ctx.onStatus(snapshot());
    } catch {
      /* Anzeige darf die Erkennung nie stoppen */
    }
  }

  /** Monitor, auf dem ein Fenster liegt (für Vollbild-Spiele). */
  const screenFor = (list, source) => {
    if (!source || source.displayId == null || source.displayId === '') return null;
    return (
      list.find(
        (entry) => /^screen/.test(entry.id) && String(entry.displayId) === String(source.displayId),
      ) || null
    );
  };

  /**
   * Quelle für die OCR. Vollbild-Spiele liefern über die Fensteraufnahme oft nur
   * ein schwarzes Bild – dann liest die Erkennung nichts und Kills bleiben aus.
   * In dem Fall wird der Monitor gelesen, auf dem das Spiel liegt.
   */
  function resolveSource(list) {
    const settings = ctx.getSettings() || {};
    const byId = (id) => (id ? list.find((source) => source.id === id) || null : null);
    // Das Spiel hat Vorrang: eine alte Clip-Quelle (z. B. Browser) soll die Erkennung nicht kapern.
    const game =
      list.find((source) => FORTNITE.test(source.name) && !BROWSER.test(source.name)) || null;
    if (game) return screenFor(list, game) || game;
    return (
      byId(settings.liveSourceId) ||
      byId(settings.clipSourceId) ||
      list.find((source) => source.primary) ||
      list.find((source) => /^screen/.test(source.id)) ||
      list[0]
    );
  }

  /**
   * Bildschirm in voller Aufloesung greifen. Eine verkleinerte Aufnahme (frueher
   * 1920 px breit) macht die kleinen Namen im Kill-Feed unlesbar – auf einem
   * 5120 px breiten Monitor blieben davon rund 6 Pixel Hoebe uebrig.
   */
  function screenSize() {
    const ratio = window.devicePixelRatio || 1;
    const width = Math.round((window.screen?.width || 1920) * ratio);
    const height = Math.round((window.screen?.height || 1080) * ratio);
    return { width: Math.max(640, width), height: Math.max(480, height) };
  }

  function openStream(source) {
    const size = screenSize();
    return navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        mandatory: {
          chromeMediaSource: 'desktop',
          chromeMediaSourceId: source.id,
          // Grosszügig: Chromium liefert dann die echte Auflösung des Spiel-Monitors.
          maxWidth: Math.max(size.width, 7680),
          maxHeight: Math.max(size.height, 4320),
          maxFrameRate: 30,
        },
      },
    });
  }

  function closeStream() {
    if (!stream) return;
    try {
      stream.getTracks().forEach((track) => track.stop());
    } catch {
      /* ignore */
    }
    stream = null;
  }

  function scheduleRetry() {
    if (!state.wanted) return;
    clearTimeout(retryTimer);
    retryTimer = setTimeout(connect, RETRY_MS);
  }

  async function connect() {
    if (!state.wanted || connecting) return;
    connecting = true;
    clearTimeout(retryTimer);
    retryTimer = null;

    if (!state.sourceId) {
      state.status = 'starting';
      publish('Suche Fortnite-Fenster …');
    }

    let list = [];
    try {
      const result = await ctx.api?.captureSources?.();
      if (Array.isArray(result)) list = result;
    } catch {
      list = [];
    }

    const source = list.length > 0 ? resolveSource(list) : null;
    if (!source) {
      state.status = 'no-source';
      publish('Kein Fenster gefunden – starte Fortnite');
      connecting = false;
      scheduleRetry();
      return;
    }

    closeStream();
    window.DamageOCR?.detach();

    try {
      stream = await openStream(source);
      stream.getVideoTracks()[0]?.addEventListener('ended', () => {
        if (!state.wanted) return;
        state.status = 'starting';
        publish('Aufnahme beendet – verbinde neu');
        connect();
      });

      const settings = ctx.getSettings() || {};
      window.DamageOCR?.attach(stream, {
        api: ctx.api,
        numbers: settings.damageOcr !== false,
        feed: settings.killFeed !== false,
      });

      const changed = state.sourceId !== source.id;
      state.sourceId = source.id;
      state.sourceName = source.name;
      state.status = 'live';
      if (changed) window.dispatchEvent(new CustomEvent('live-stream-changed', { detail: { id: source.id, name: source.name } }));
      state.since = Date.now();
      publish(`Liest den Kill-Feed aus „${source.name}“`);
    } catch (error) {
      closeStream();
      state.sourceId = null;
      state.sourceName = source.name;
      state.status = 'error';
      publish(`Aufnahme fehlgeschlagen: ${error.message}`);
      window.DamageOCR?.detach();
      scheduleRetry();
    }

    connecting = false;
  }

  async function checkSource() {
    if (!state.wanted || connecting) return;

    if (!streamAlive()) {
      connect();
      return;
    }

    let list = [];
    try {
      const result = await ctx.api?.captureSources?.();
      if (Array.isArray(result)) list = result;
    } catch {
      list = [];
    }
    if (list.length === 0) return;

    // Quelle weg (Spiel beendet) oder inzwischen eine bessere da (Spiel
    // gestartet): neu verbinden.
    const next = resolveSource(list);
    const gone = !list.some((source) => source.id === state.sourceId);
    if (!next || gone || next.id !== state.sourceId) connect();
  }

  function start() {
    state.wanted = true;
    clearInterval(checkTimer);
    checkTimer = setInterval(checkSource, SOURCE_CHECK_MS);
    connect();
  }

  function stop() {
    state.wanted = false;
    clearTimeout(retryTimer);
    retryTimer = null;
    clearInterval(checkTimer);
    checkTimer = null;
    closeStream();
    window.DamageOCR?.detach();
    state.status = 'off';
    state.sourceId = null;
    state.sourceName = '';
    state.since = 0;
    publish('Live-Erkennung aus');
  }

  window.LiveMonitor = {
    init(options) {
      Object.assign(ctx, options || {});
    },
    start,
    stop,
    restart() {
      if (!state.wanted) {
        start();
        return;
      }
      closeStream();
      window.DamageOCR?.detach();
      connect();
    },
    /** Die Clip-Aufnahme nutzt denselben Stream, statt das Fenster doppelt zu greifen. */
    getStream() {
      return streamAlive() ? stream : null;
    },
    isWanted: () => state.wanted,
    setFlags(patch) {
      window.DamageOCR?.setFlags?.(patch);
    },
    status: snapshot,
  };
})();
