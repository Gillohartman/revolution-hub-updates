# Audio-Mixer für die App: liest das Standard-Ausgabegerät und alle laufenden
# Audio-Sitzungen (Apps) über die Windows-CoreAudio-Schnittstelle und setzt
# Lautstärke bzw. Stummschaltung. Läuft dauerhaft und liest Befehle von stdin,
# weil das Kompilieren der Schnittstellen bei jedem Start zu lange dauert.
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Globalization;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace RxAudio
{
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    internal class MMDeviceEnumeratorComObject { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IMMDeviceEnumerator
    {
        int EnumAudioEndpoints(int dataFlow, int stateMask, out IntPtr devices);
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IMMDevice
    {
        int Activate(ref Guid id, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object interfacePointer);
        int OpenPropertyStore(int stgmAccess, out IntPtr properties);
        int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        int GetState(out int state);
    }

    [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioEndpointVolume
    {
        int RegisterControlChangeNotify(IntPtr notify);
        int UnregisterControlChangeNotify(IntPtr notify);
        int GetChannelCount(out int count);
        int SetMasterVolumeLevel(float level, ref Guid context);
        int SetMasterVolumeLevelScalar(float level, ref Guid context);
        int GetMasterVolumeLevel(out float level);
        int GetMasterVolumeLevelScalar(out float level);
        int SetChannelVolumeLevel(uint channel, float level, ref Guid context);
        int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid context);
        int GetChannelVolumeLevel(uint channel, out float level);
        int GetChannelVolumeLevelScalar(uint channel, out float level);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid context);
        int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
        int GetVolumeStepInfo(out uint step, out uint stepCount);
        int VolumeStepUp(ref Guid context);
        int VolumeStepDown(ref Guid context);
        int QueryHardwareSupport(out uint mask);
        int GetVolumeRange(out float min, out float max, out float increment);
    }

    [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionManager2
    {
        int GetAudioSessionControl(IntPtr sessionGuid, uint streamFlags, out IntPtr sessionControl);
        int GetSimpleAudioVolume(IntPtr sessionGuid, uint streamFlags, out IntPtr audioVolume);
        int GetSessionEnumerator(out IAudioSessionEnumerator sessionEnumerator);
        int RegisterSessionNotification(IntPtr notification);
        int UnregisterSessionNotification(IntPtr notification);
        int RegisterDuckNotification(string sessionId, IntPtr notification);
        int UnregisterDuckNotification(IntPtr notification);
    }

    [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionEnumerator
    {
        int GetCount(out int count);
        int GetSession(int index, out IAudioSessionControl session);
    }

    [ComImport, Guid("F4B1A599-7266-4319-A8CA-E70ACB11E8CD"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionControl
    {
        int GetState(out int state);
        int GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        int SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name, ref Guid context);
        int GetIconPath([MarshalAs(UnmanagedType.LPWStr)] out string path);
        int SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path, ref Guid context);
        int GetGroupingParam(out Guid param);
        int SetGroupingParam(ref Guid param, ref Guid context);
        int RegisterAudioSessionNotification(IntPtr notify);
        int UnregisterAudioSessionNotification(IntPtr notify);
    }

    [ComImport, Guid("BFB7FF88-7239-4FC9-8FA2-07C950BE9C6D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionControl2
    {
        int GetState(out int state);
        int GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        int SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name, ref Guid context);
        int GetIconPath([MarshalAs(UnmanagedType.LPWStr)] out string path);
        int SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path, ref Guid context);
        int GetGroupingParam(out Guid param);
        int SetGroupingParam(ref Guid param, ref Guid context);
        int RegisterAudioSessionNotification(IntPtr notify);
        int UnregisterAudioSessionNotification(IntPtr notify);
        int GetSessionIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        int GetSessionInstanceIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        int GetProcessId(out uint pid);
        // Ohne PreserveSig wandelt die CLR das S_FALSE in 0 um – dann würden
        // alle Sitzungen als Systemklänge gelten und der Mixer bliebe leer.
        [PreserveSig] int IsSystemSoundsSession();
        int SetDuckingPreference([MarshalAs(UnmanagedType.Bool)] bool optOut);
    }

    [ComImport, Guid("87CE5498-68D6-44E5-9215-6DA47EF883D8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface ISimpleAudioVolume
    {
        int SetMasterVolume(float level, ref Guid context);
        int GetMasterVolume(out float level);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid context);
        int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
    }

    public static class Mixer
    {
        static readonly Guid IID_EndpointVolume = new Guid("5CDF2C82-841E-4546-9722-0CF74078229A");
        static readonly Guid IID_SessionManager = new Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F");
        static IMMDeviceEnumerator enumerator;
        // Gemerkte Objekte: sonst enumeriert jeder Regler-Schritt alle
        // Sitzungen neu und der Ton hinkt der Maus hinterher.
        static IAudioEndpointVolume endpointVolume;
        static readonly Dictionary<int, ISimpleAudioVolume> sessionCache =
            new Dictionary<int, ISimpleAudioVolume>();

        static IMMDevice DefaultDevice()
        {
            if (enumerator == null) enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumeratorComObject());
            IMMDevice device;
            int hr = enumerator.GetDefaultAudioEndpoint(0, 1, out device);
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            return device;
        }

        static IAudioEndpointVolume EndpointVolume()
        {
            if (endpointVolume != null) return endpointVolume;
            IMMDevice device = DefaultDevice();
            Guid iid = IID_EndpointVolume;
            object raw;
            int hr = device.Activate(ref iid, 23, IntPtr.Zero, out raw);
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            endpointVolume = (IAudioEndpointVolume)raw;
            return endpointVolume;
        }

        static IAudioSessionEnumerator Sessions()
        {
            IMMDevice device = DefaultDevice();
            Guid iid = IID_SessionManager;
            object raw;
            int hr = device.Activate(ref iid, 23, IntPtr.Zero, out raw);
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            var manager = (IAudioSessionManager2)raw;
            IAudioSessionEnumerator list;
            hr = manager.GetSessionEnumerator(out list);
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            return list;
        }

        public static float MasterLevel()
        {
            float level;
            EndpointVolume().GetMasterVolumeLevelScalar(out level);
            return level;
        }

        public static bool MasterMuted()
        {
            bool mute;
            EndpointVolume().GetMute(out mute);
            return mute;
        }

        public static void SetMaster(float volume, int mute)
        {
            Guid context = Guid.Empty;
            var endpoint = EndpointVolume();
            if (volume >= 0) endpoint.SetMasterVolumeLevelScalar(Math.Max(0f, Math.Min(1f, volume)), ref context);
            if (mute >= 0) endpoint.SetMute(mute == 1, ref context);
        }

        static string Escape(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            var sb = new StringBuilder(text.Length + 8);
            foreach (char c in text)
            {
                if (c == '"' || c == '\\') sb.Append('\\').Append(c);
                else if (c < ' ') sb.Append(' ');
                else sb.Append(c);
            }
            return sb.ToString();
        }

        static string Number(double value)
        {
            return value.ToString("0.###", CultureInfo.InvariantCulture);
        }

        public static string ListJson()
        {
            var sb = new StringBuilder();
            sb.Append("{\"master\":").Append(Number(MasterLevel()));
            sb.Append(",\"muted\":").Append(MasterMuted() ? "true" : "false");
            sb.Append(",\"apps\":[");
            try
            {
                var list = Sessions();
                int count;
                list.GetCount(out count);
                bool first = true;
                for (int i = 0; i < count; i++)
                {
                    IAudioSessionControl control;
                    if (list.GetSession(i, out control) != 0) continue;
                    var control2 = control as IAudioSessionControl2;
                    if (control2 == null) continue;
                    // Systemklänge haben keinen Prozess – die gehören nicht in den Mixer.
                    if (control2.IsSystemSoundsSession() == 0) continue;
                    uint pid;
                    control2.GetProcessId(out pid);
                    if (pid == 0) continue;
                    var volume = control as ISimpleAudioVolume;
                    if (volume == null) continue;
                    sessionCache[(int)pid] = volume;
                    int state;
                    control.GetState(out state);
                    // 0 = inaktiv, 2 = abgelaufen: nur laufende Apps anzeigen.
                    if (state == 2) continue;
                    float level;
                    volume.GetMasterVolume(out level);
                    bool mute;
                    volume.GetMute(out mute);
                    string name;
                    try { name = Process.GetProcessById((int)pid).ProcessName; }
                    catch { name = "pid " + pid; }
                    if (!first) sb.Append(',');
                    first = false;
                    sb.Append("{\"pid\":").Append(pid)
                      .Append(",\"name\":\"").Append(Escape(name)).Append('"')
                      .Append(",\"volume\":").Append(Number(level))
                      .Append(",\"muted\":").Append(mute ? "true" : "false")
                      .Append(",\"active\":").Append(state == 1 ? "true" : "false")
                      .Append('}');
                }
            }
            catch (Exception error)
            {
                return "{\"error\":\"" + Escape(error.Message) + "\",\"apps\":[]}";
            }
            sb.Append("]}");
            return sb.ToString();
        }

        public static void SetApp(int targetPid, float volume, int mute)
        {
            Guid context = Guid.Empty;
            // Schneller Weg: das Objekt aus der letzten Liste benutzen.
            ISimpleAudioVolume known;
            if (sessionCache.TryGetValue(targetPid, out known) && known != null)
            {
                try
                {
                    if (volume >= 0) known.SetMasterVolume(Math.Max(0f, Math.Min(1f, volume)), ref context);
                    if (mute >= 0) known.SetMute(mute == 1, ref context);
                    return;
                }
                catch
                {
                    sessionCache.Remove(targetPid);
                }
            }
            var list = Sessions();
            int count;
            list.GetCount(out count);
            for (int i = 0; i < count; i++)
            {
                IAudioSessionControl control;
                if (list.GetSession(i, out control) != 0) continue;
                var control2 = control as IAudioSessionControl2;
                if (control2 == null) continue;
                uint pid;
                control2.GetProcessId(out pid);
                if ((int)pid != targetPid) continue;
                var sessionVolume = control as ISimpleAudioVolume;
                if (sessionVolume == null) continue;
                sessionCache[(int)pid] = sessionVolume;
                if (volume >= 0) sessionVolume.SetMasterVolume(Math.Max(0f, Math.Min(1f, volume)), ref context);
                if (mute >= 0) sessionVolume.SetMute(mute == 1, ref context);
            }
        }
    }
}
'@

function Reply($id, $json) {
  Write-Output ('{"id":' + $id + ',"data":' + $json + '}')
}

function ReplyError($id, $message) {
  $safe = ([string]$message) -replace '\\', '\\\\' -replace '"', '\"'
  Write-Output ('{"id":' + $id + ',"error":"' + $safe + '"}')
}

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  $line = $line.Trim()
  if (-not $line) { continue }

  $message = $null
  try { $message = $line | ConvertFrom-Json } catch { $message = $null }
  if ($null -eq $message) { continue }
  $id = [string]$message.id
  $cmd = [string]$message.cmd

  try {
    switch ($cmd) {
      'list' { Reply $id ([RxAudio.Mixer]::ListJson()) }
      'master' {
        $volume = -1.0
        $mute = -1
        if ($null -ne $message.volume) { $volume = [double]$message.volume }
        if ($null -ne $message.mute) { $mute = [int]$message.mute }
        [RxAudio.Mixer]::SetMaster([float]$volume, $mute)
        Reply $id ('{"master":' + [RxAudio.Mixer]::MasterLevel() + '}')
      }
      'app' {
        $volume = -1.0
        $mute = -1
        if ($null -ne $message.volume) { $volume = [double]$message.volume }
        if ($null -ne $message.mute) { $mute = [int]$message.mute }
        [RxAudio.Mixer]::SetApp([int]$message.pid, [float]$volume, $mute)
        Reply $id '{"ok":true}'
      }
      default { Reply $id '{"ok":false}' }
    }
  } catch {
    ReplyError $id $_.Exception.Message
  }
}
