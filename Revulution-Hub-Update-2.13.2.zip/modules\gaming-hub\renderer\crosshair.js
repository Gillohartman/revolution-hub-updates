const viewEl = document.getElementById('view');
const titleEl = document.getElementById('view-title');
const subEl = document.getElementById('view-sub');
const chipEl = document.getElementById('display-chip');
const gameNote = document.getElementById('game-note');
const powerBtn = document.getElementById('power');
const powerText = document.getElementById('power-text');
const powerHint = document.getElementById('power-hint');
const toastEl = document.getElementById('toast');
const wallEl = document.getElementById('wall');

let app = null;
let meta = null;
let view = 'overview';
let saveTimer = null;
let toastTimer = null;
let audioCtx = null;
let painting = false;
let erasing = false;
// Spiegeln ist aus: gemalt wird genau die Zelle, die man antippt.
let mirror = false;
let brush = '#3ce88f';

const GRID = 15;
// Auflösung des Rasters für neue Designs (mehr Zellen = kleinere Pixel).
let gridSize = 15;

const COLORS = [
  '#ffffff',
  '#3ce88f',
  '#22d3ee',
  '#ff3ba7',
  '#a855f7',
  '#ff2d55',
  '#f59e0b',
  '#f472b6',
  '#a3e635',
];

const VIEWS = {
  overview: ['Übersicht', 'Crosshair für Fortnite, direkt auf dem richtigen Monitor.'],
  designs: ['Designs', 'Fertige Designs – ein Klick, und es ist dein Crosshair.'],
  adjust: ['Anpassen', 'Länge, Dicke, Lücke, Farbe, Kontur und Drehung.'],
  pixels: ['Pixeln', 'Dein eigenes Fadenkreuz, Pixel für Pixel.'],
  images: ['Bilder & GIFs', 'Eigenes PNG, WebP oder animiertes GIF als Crosshair.'],
  profiles: ['Profile', 'Sets für verschiedene Spiele oder Stimmungen.'],
  hotkeys: ['Tastenkürzel', 'Steuerung im Spiel, ohne das Fenster zu öffnen.'],
  settings: ['Einstellungen', 'Monitor, Position, Hintergründe, Verhalten und Hilfe.'],
  clips: ['Clips', 'Aufnehmen wie mit Medal: Puffer, Kills, Siege und Tasten.'],
  music: ['Musik', 'Cover, Restzeit und Songtext als kleines Overlay.'],
  chests: ['Truhen', 'Zählt jede geöffnete Truhe – insgesamt, für immer.'],
  perf: ['Leistung', 'FPS, Ping, CPU, GPU und RAM als Overlay – jeden Wert einzeln.'],
  audio: ['Audio', 'Systemlautstärke und jede App einzeln regeln.'],
  stats: ['Statistiken', 'Bonus: deine Fortnite-Replays, lokal ausgewertet.'],
  screentime: ['Bildschirmzeit', 'Wie lange du heute und in der Woche am PC warst.'],
  notes: ['Notizen', 'Kurze Notizen, sofort festgehalten – lokal auf deinem PC.'],
};

const MODES = [
  { id: 'br', name: 'Battle Royale' },
  { id: 'zeroBuild', name: 'Null Bauen' },
  { id: 'reload', name: 'Reload' },
];

const KIND_LABELS = {
  cross: 'Kreuz',
  x: 'X',
  t: 'T-Form',
  dot: 'Punkt',
  circle: 'Ring',
  circleDot: 'Ring + Punkt',
  brackets: 'Klammern',
  chevron: 'Pfeile',
  triangle: 'Dreieck',
  square: 'Quadrat',
  pixels: 'Pixel-Design',
  image: 'Bild / GIF',
};

const h = (html) => {
  const template = document.createElement('template');
  template.innerHTML = html.trim();
  return template.content.firstElementChild;
};

const mediaUrl = (file) => window.xh.mediaUrl(file);
const wallUrl = (name) => `wall://media/${encodeURIComponent(name)}`;

function currentProfile() {
  const list = app?.profiles || [];
  return list.find((profile) => profile.id === app?.activeId) || list[0] || null;
}

/** Rang-Crosshair: Abzeichen, Farbe und Animation kommen vom Rang des Modus. */
function displayProfile() {
  const profile = currentProfile();
  if (!profile?.autoRank) return profile;
  const rank = (window.XH?.RANKS || []).find(
    (entry) => entry.id === (app?.ranks || {})[app?.rankMode || 'br'],
  );
  const badge = !rank ? 'unranked' : rank.id === 'unreal' ? 'champion' : rank.id;
  return {
    ...profile,
    kind: 'image',
    image: `ranks/${badge}.png`,
    blend: 'normal',
    imageScale: 0.45,
    outline: 0,
    color: rank?.color || '#ffffff',
    animation: !rank ? 'breathe' : rank.id === 'unreal' ? 'rainbow' : rank.animation,
  };
}

/* ---------------- Klick-Sounds ---------------- */

let clickTemplate = null;

function playClick(kind = 'tap') {
  if (!app?.clickSound) return;
  try {
    // Klicksound aus dem Downloads-Ordner (macOS-/Minecraft-Menü-Klick).
    clickTemplate = clickTemplate || new Audio('assets/click.mp3');
    const node = clickTemplate.cloneNode(true);
    node.volume = kind === 'toggle' ? 0.55 : 0.38;
    node.playbackRate = kind === 'toggle' ? 1.08 : 1.02;
    const played = node.play();
    if (played && played.catch) played.catch(() => {});
  } catch {
    /* Sound ist nur Beiwerk */
  }
}

document.addEventListener(
  'click',
  (event) => {
    const target = event.target.closest('button, .design, .wall-card, .nav-item, .pixel-cell');
    if (!target || target.disabled) return;
    playClick(target.classList.contains('toggle') || target.classList.contains('power') ? 'toggle' : 'tap');
  },
  true,
);

function showToast(text) {
  // Im Fokus-Modus bleiben Hinweise aus – aber nur, solange das Fenster im
  // Hintergrund ist, sonst wäre jede Bedienung der App stumm.
  if (app?.focusMode && !document.hasFocus()) return;
  toastEl.textContent = text;
  toastEl.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toastEl.hidden = true;
  }, 2200);
}

/* ---------------- Hintergrund ---------------- */

function applyShade() {
  const raw = Number(app?.wallShade);
  const pct = Number.isFinite(raw) ? Math.min(100, Math.max(0, raw)) : 80;
  const root = document.documentElement.style;
  root.setProperty('--wall-shade-top', ((pct / 100) * 0.85).toFixed(3));
  root.setProperty('--wall-shade-bottom', (pct / 100).toFixed(3));
  // Flächen (Seitenleiste, Karten, Kopfzeile) folgen der Abdunklung: bei 0 %
  // scheint das Live-Wallpaper überall durch.
  root.setProperty('--shade-a', (pct / 100).toFixed(3));
}

function applyWallpaper() {
  const name = app?.wallpaper;
  if (!name) {
    wallEl.hidden = true;
    delete wallEl.dataset.name;
    wallEl.pause();
    wallEl.removeAttribute('src');
    return;
  }
  if (wallEl.dataset.name !== name) {
    wallEl.dataset.name = name;
    wallEl.src = wallUrl(name);
  }
  wallEl.hidden = false;
  const played = wallEl.play();
  if (played && played.catch) played.catch(() => {});
}

// Der Live-Hintergrund darf nie stehen bleiben – auch nicht nach Ansichtswechseln.
wallEl.addEventListener('pause', () => {
  if (wallEl.hidden || !wallEl.dataset.name) return;
  const played = wallEl.play();
  if (played && played.catch) played.catch(() => {});
});

setInterval(() => {
  if (wallEl.hidden || !wallEl.dataset.name) return;
  if (wallEl.paused || wallEl.ended) {
    const played = wallEl.play();
    if (played && played.catch) played.catch(() => {});
  }
}, 2000);

function updateChrome() {
  const profile = currentProfile();
  const on = Boolean(app?.enabled);
  powerBtn.classList.toggle('is-on', on);
  powerText.textContent = on ? 'Crosshair an' : 'Crosshair aus';
  powerHint.textContent = app?.hotkeysEnabled ? app?.hotkeys?.toggle || '—' : '—';

  const display =
    (meta?.displays || []).find((entry) => entry.id === app?.displayId) ||
    (meta?.displays || []).find((entry) => entry.primary);
  chipEl.textContent = display ? `${display.width} × ${display.height}` : 'Bildschirm';
  gameNote.textContent = meta?.fortniteRunning
    ? `Fortnite läuft · ${profile ? profile.name : 'kein Design'}`
    : `Fortnite: nicht erkannt · ${profile ? profile.name : 'kein Design'}`;

  const focusBtn = document.getElementById('btn-focus');
  if (focusBtn) {
    focusBtn.classList.toggle('btn-primary', Boolean(app?.focusMode));
    focusBtn.textContent = app?.focusMode ? 'Fokus an' : 'Fokus';
    focusBtn.title = app?.focusMode
      ? 'Fokus-Modus aktiv – Hinweise und Windows-Benachrichtigungen sind stumm'
      : 'Fokus-Modus: Hinweise und Benachrichtigungen stumm schalten';
  }

  const [title, sub] = VIEWS[view] || VIEWS.overview;
  titleEl.textContent = title;
  subEl.textContent = sub;
  applyShade();
  applyWallpaper();
}

function mountMark(host, profile, scale) {
  if (!host) return;
  if (!profile) {
    host.replaceChildren();
    return;
  }
  XH.render(host, profile, { scale, mediaUrl });
  host.style.opacity = String(profile.opacity);
  host.style.transform = profile.rotation ? `rotate(${profile.rotation}deg)` : '';
}

/* ---------------- Bausteine ---------------- */

function slider({ label, value, min, max, step = 1, unit = '', onInput }) {
  const wrapper = h(`
    <div class="field">
      <label>${label}</label>
      <div class="row">
        <input type="range" min="${min}" max="${max}" step="${step}" value="${value}" />
        <span class="value">${value}${unit}</span>
      </div>
    </div>
  `);
  const input = wrapper.querySelector('input');
  const out = wrapper.querySelector('.value');
  input.addEventListener('input', () => {
    const next = Number(input.value);
    out.textContent = `${next}${unit}`;
    onInput(next);
  });
  return wrapper;
}

function toggleRow({ title, desc, checked, onChange }) {
  const row = h(`
    <div class="switch">
      <div class="switch-text">
        <strong>${title}</strong>
        ${desc ? `<span>${desc}</span>` : ''}
      </div>
      <button class="toggle ${checked ? 'is-on' : ''}" aria-pressed="${checked}"></button>
    </div>
  `);
  const button = row.querySelector('.toggle');
  button.addEventListener('click', () => {
    const next = !button.classList.contains('is-on');
    button.classList.toggle('is-on', next);
    button.setAttribute('aria-pressed', String(next));
    onChange(next);
  });
  return row;
}

function colorRow(selected, onPick, { small = false } = {}) {
  const row = h('<div class="swatches"></div>');
  for (const color of COLORS) {
    const button = h(
      `<button class="swatch ${color === selected ? 'is-active' : ''}" style="background:${color}${small ? ';width:22px;height:22px' : ''}"></button>`,
    );
    button.title = color;
    button.addEventListener('click', () => {
      row.querySelectorAll('.swatch').forEach((node) => node.classList.remove('is-active'));
      button.classList.add('is-active');
      onPick(color);
    });
    row.appendChild(button);
  }
  return row;
}

/* ---------------- Speichern ---------------- */

function patchProfile(changes, { immediate = false } = {}) {
  const profile = { ...currentProfile(), ...changes };
  app.profiles = app.profiles.map((entry) => (entry.id === profile.id ? profile : entry));
  drawStage();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(
    async () => {
      const next = await window.xh.updateProfile(profile);
      if (next?.app) {
        app = next.app;
        meta = next.meta;
        updateChrome();
      }
    },
    immediate ? 0 : 160,
  );
}

async function patchApp(patch, { rerender = false } = {}) {
  app = { ...app, ...patch };
  updateChrome();
  if (rerender) renderView();
  const next = await window.xh.save(patch);
  if (next?.app) {
    app = next.app;
    meta = next.meta;
    updateChrome();
    if (rerender) renderView();
  }
}

function drawStage() {
  const mark = document.getElementById('stage-mark');
  const stage = document.getElementById('stage');
  if (!mark) return;
  mountMark(mark, displayProfile(), 2.4);
  if (stage) stage.classList.toggle('is-off', !app?.enabled);
}

/* ---------------- Ansichten ---------------- */

function renderView() {
  if (!app) return;
  updateChrome();
  viewEl.replaceChildren();

  const views = {
    overview: renderOverview,
    designs: renderDesigns,
    adjust: renderAdjust,
    pixels: renderPixels,
    images: renderImages,
    profiles: renderProfiles,
    hotkeys: renderHotkeys,
    settings: renderSettings,
    clips: renderClips,
    music: renderMusic,
    chests: renderChests,
    perf: renderPerf,
    audio: renderAudio,
    stats: renderStats,
    screentime: renderScreentime,
    notes: renderNotes,
  };
  (views[view] || renderOverview)();
}

function renderOverview() {
  const profile = currentProfile();

  const wrap = h(`
    <div class="grid two">
      <div class="card">
        <div class="card-head">
          <div>
            <h2>Aktives Crosshair</h2>
            <p>${profile ? profile.name : 'Kein Design'} · ${profile ? KIND_LABELS[profile.kind] || profile.kind : ''}</p>
          </div>
          <span class="tag ${app.enabled ? 'green' : ''}">${app.enabled ? 'an' : 'aus'}</span>
        </div>
        <div class="stage" id="stage"><div class="stage-mark" id="stage-mark"></div><b>Vorschau 2,4× · im Spiel 1:1</b></div>
        <div class="row-actions" style="margin-top:14px">
          <button class="btn btn-primary" id="stage-preview">Im Overlay zeigen</button>
          <button class="btn" id="stage-next">Nächstes Design</button>
          <button class="btn" id="stage-gallery">Galerie</button>
          <button class="btn" id="stage-pixel">Pixeln</button>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div><h2>Schnell anpassen</h2><p>Gilt direkt für das aktive Design</p></div></div>
        <div id="quick"></div>
        <div class="field">
          <label>Farbe</label>
          <div id="quick-color"></div>
        </div>
        <div class="row-actions">
          <button class="btn" id="quick-edit">Alles anpassen</button>
          <button class="btn" id="quick-image">Bild oder GIF</button>
        </div>
      </div>
    </div>
  `);

  const quick = wrap.querySelector('#quick');
  const base = profile || {};

  quick.appendChild(
    slider({
      label: 'Größe (gesamt)',
      value: app.scale,
      min: 0.4,
      max: 3,
      step: 0.05,
      unit: '×',
      onInput: (value) => {
        app.scale = value;
        patchApp({ scale: value });
      },
    }),
  );
  quick.appendChild(
    slider({
      label: 'Länge',
      value: base.length ?? 14,
      min: 2,
      max: 40,
      onInput: (value) => patchProfile({ length: value }),
    }),
  );
  quick.appendChild(
    slider({
      label: 'Dicke',
      value: base.thickness ?? 3,
      min: 1,
      max: 12,
      onInput: (value) => patchProfile({ thickness: value }),
    }),
  );
  quick.appendChild(
    slider({
      label: 'Lücke',
      value: base.gap ?? 5,
      min: 0,
      max: 24,
      onInput: (value) => patchProfile({ gap: value }),
    }),
  );
  quick.appendChild(
    slider({
      label: 'Deckkraft',
      value: Math.round((base.opacity ?? 1) * 100),
      min: 20,
      max: 100,
      step: 5,
      unit: '%',
      onInput: (value) => patchProfile({ opacity: value / 100 }),
    }),
  );

  wrap
    .querySelector('#quick-color')
    .appendChild(colorRow(base.color || '#3ce88f', (color) => patchProfile({ color })));

  wrap.querySelector('#stage-preview').addEventListener('click', async () => {
    await window.xh.preview(8000);
    showToast('Crosshair wird 8 Sekunden im Overlay gezeigt');
  });
  wrap.querySelector('#stage-next').addEventListener('click', async () => {
    const list = app.profiles;
    const index = list.findIndex((entry) => entry.id === app.activeId);
    const next = list[(index + 1) % list.length];
    await patchApp({ activeId: next.id });
    renderView();
  });
  wrap.querySelector('#stage-gallery').addEventListener('click', () => setView('designs'));
  wrap.querySelector('#stage-pixel').addEventListener('click', () => setView('pixels'));
  wrap.querySelector('#quick-edit').addEventListener('click', () => setView('adjust'));
  wrap.querySelector('#quick-image').addEventListener('click', uploadImage);

  viewEl.appendChild(wrap);
  drawStage();
}

function renderDesigns() {
  const wrap = h(`
    <div class="card">
      <div class="card-head">
        <div><h2>Community-Designs</h2><p>${XH.catalog().length} Designs · Klick übernimmt es sofort</p></div>
        <input type="text" id="design-search" placeholder="Design suchen …" style="max-width:240px" />
      </div>
      <div class="grid cards" id="design-grid"></div>
      <p class="hint">Eigene Bilder und GIFs findest du unter <b>Bilder &amp; GIFs</b>, eigene Pixel unter <b>Pixeln</b> – alles bleibt lokal auf deinem PC.</p>
    </div>
  `);

  const grid = wrap.querySelector('#design-grid');
  const catalog = XH.catalog();

  const paint = (filter = '') => {
    grid.replaceChildren();
    const needle = filter.trim().toLowerCase();
    for (const design of catalog) {
      if (needle && !design.name.toLowerCase().includes(needle)) continue;
      const active = currentProfile() && currentProfile().name === design.name;
      const card = h(`
        <button class="design ${active ? 'is-active' : ''}">
          <span class="design-check">✓</span>
          <span class="design-swatch"></span>
          <span class="design-name">${design.name}</span>
        </button>
      `);
      if (design.autoRank) {
        const rank =
          (window.XH?.RANKS || []).find(
            (entry) => entry.id === (app?.ranks || {})[app?.rankMode || 'br'],
          ) || (window.XH?.RANKS || [])[0];
        const badge = rank?.id === 'unreal' ? 'champion' : rank?.id || 'unranked';
        card.querySelector('.design-swatch').appendChild(
          h(`<img src="xh://rank/${badge}.png" alt="" style="width:72px;height:72px;object-fit:contain;mix-blend-mode:screen" />`),
        );
      } else {
        const thumb = XH.thumbnail(design, 84);
        if (thumb) card.querySelector('.design-swatch').appendChild(thumb);
      }
      card.addEventListener('click', async () => {
        const next = await window.xh.addProfile({ ...design, builtin: false });
        app = next.app;
        meta = next.meta;
        updateChrome();
        renderView();
        showToast(`„${design.name}“ ist aktiv`);
      });
      grid.appendChild(card);
    }
    if (grid.children.length === 0) {
      grid.appendChild(h('<div class="empty">Kein Design gefunden.</div>'));
    }
  };

  wrap.querySelector('#design-search').addEventListener('input', (event) => paint(event.target.value));
  viewEl.appendChild(wrap);
  paint();
}

function renderAdjust() {
  const profile = currentProfile();
  if (!profile) return;

  const wrap = h(`
    <div class="grid two">
      <div class="card">
        <div class="card-head"><div><h2>Vorschau</h2><p>${profile.name}</p></div></div>
        <div class="stage" id="stage"><div class="stage-mark" id="stage-mark"></div><b>1:1 Verhältnis</b></div>
        <div class="field" style="margin-top:14px">
          <label>Design-Name</label>
          <div class="row">
            <input type="text" id="profile-name" value="${profile.name}" maxlength="40" />
            <button class="btn" id="profile-duplicate">Duplizieren</button>
          </div>
        </div>
        <div class="field">
          <label>Form</label>
          <select id="profile-kind">
            ${Object.entries(KIND_LABELS)
              .filter(([key]) => key !== 'image')
              .map(([key, label]) => `<option value="${key}" ${profile.kind === key ? 'selected' : ''}>${label}</option>`)
              .join('')}
          </select>
        </div>
        <div class="field">
          <label>Farbe</label>
          <div id="adjust-color"></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div><h2>Feinabstimmung</h2><p>Änderungen sind sofort im Overlay</p></div></div>
        <div id="adjust-fields"></div>
      </div>
    </div>
  `);

  const fields = wrap.querySelector('#adjust-fields');
  fields.appendChild(slider({ label: 'Länge', value: profile.length, min: 2, max: 40, onInput: (v) => patchProfile({ length: v }) }));
  fields.appendChild(slider({ label: 'Dicke', value: profile.thickness, min: 1, max: 12, onInput: (v) => patchProfile({ thickness: v }) }));
  fields.appendChild(slider({ label: 'Lücke', value: profile.gap, min: 0, max: 24, onInput: (v) => patchProfile({ gap: v }) }));
  fields.appendChild(slider({ label: 'Punkt', value: profile.dot, min: 0, max: 10, onInput: (v) => patchProfile({ dot: v }) }));
  fields.appendChild(slider({ label: 'Ring-Radius', value: profile.ring, min: 0, max: 40, onInput: (v) => patchProfile({ ring: v }) }));
  fields.appendChild(
    slider({
      label: 'Kontur',
      value: profile.outline,
      min: 0,
      max: 4,
      step: 0.25,
      onInput: (v) => patchProfile({ outline: v }),
    }),
  );
  fields.appendChild(
    slider({
      label: 'Drehung',
      value: profile.rotation,
      min: -180,
      max: 180,
      unit: '°',
      onInput: (v) => patchProfile({ rotation: v }),
    }),
  );
  fields.appendChild(
    slider({
      label: 'Deckkraft',
      value: Math.round(profile.opacity * 100),
      min: 20,
      max: 100,
      step: 5,
      unit: '%',
      onInput: (v) => patchProfile({ opacity: v / 100 }),
    }),
  );
  fields.appendChild(
    slider({
      label: 'Pixel-Größe',
      value: profile.pixelSize || 4,
      min: 1,
      max: 12,
      onInput: (v) => patchProfile({ pixelSize: v }),
    }),
  );

  const aimToggle = h(`
    <button class="btn ${profile.aimTighten !== false ? 'btn-primary' : ''}" id="aim-tighten" style="margin-top:6px">
      Beim Zielen enger (Rechtsklick): ${profile.aimTighten !== false ? 'An' : 'Aus'}
    </button>
  `);
  aimToggle.addEventListener('click', () => {
    patchProfile({ aimTighten: profile.aimTighten === false }, { immediate: true });
    renderView();
  });
  fields.appendChild(aimToggle);

  wrap
    .querySelector('#adjust-color')
    .appendChild(colorRow(profile.color, (color) => patchProfile({ color })));

  wrap.querySelector('#profile-name').addEventListener('change', (event) => {
    patchProfile({ name: event.target.value.trim().slice(0, 40) || 'Design' }, { immediate: true });
  });

  wrap.querySelector('#profile-kind').addEventListener('change', (event) => {
    patchProfile({ kind: event.target.value }, { immediate: true });
    renderView();
  });

  wrap.querySelector('#profile-duplicate').addEventListener('click', async () => {
    const next = await window.xh.addProfile({ ...profile, id: undefined, name: `${profile.name} Kopie` });
    app = next.app;
    meta = next.meta;
    renderView();
  });

  viewEl.appendChild(wrap);
  drawStage();
}

/* ---------------- Pixel-Editor ---------------- */

function emptyGrid(size = gridSize) {
  return Array.from({ length: size }, () => Array(size).fill(''));
}

/** Setzt vorhandene Pixel auf ein anderes Raster um (nächster Nachbar). */
function resizeGrid(source, size) {
  const from = source.length || GRID;
  return Array.from({ length: size }, (_, y) =>
    Array.from({ length: size }, (_, x) => {
      const sx = Math.min(from - 1, Math.floor(((x + 0.5) * from) / size));
      const sy = Math.min(from - 1, Math.floor(((y + 0.5) * from) / size));
      return source[sy]?.[sx] || '';
    }),
  );
}

async function startPixelProfile(pixels) {
  const next = await window.xh.addProfile({
    name: 'Eigenes Pixel',
    kind: 'pixels',
    pixelSize: 4,
    color: brush,
    pixels: pixels || emptyGrid(),
  });
  app = next.app;
  meta = next.meta;
  updateChrome();
  renderView();
}

function renderPixels() {
  const profile = currentProfile();
  const isPixel = profile && profile.kind === 'pixels';

  const wrap = h(`
    <div class="grid two">
      <div class="card">
        <div class="card-head">
          <div><h2>Pixel-Editor</h2><p>${isPixel ? profile.name : 'Noch kein Pixel-Design aktiv'}</p></div>
          <button class="btn" id="pixel-new">${isPixel ? 'Neues leeres Design' : 'Pixel-Design erstellen'}</button>
        </div>
        <div class="pixel-grid" id="pixel-grid"></div>
        <div class="field" style="margin-top:16px">
          <label>Raster</label>
          <select id="pixel-raster">
            <option value="9">9 × 9 – grobe Pixel</option>
            <option value="11">11 × 11</option>
            <option value="15">15 × 15 – Standard</option>
            <option value="19">19 × 19</option>
            <option value="23">23 × 23</option>
            <option value="27">27 × 27 – feine Pixel</option>
          </select>
        </div>
        <div class="field" style="margin-top:16px">
          <label>Pinsel-Farbe</label>
          <div id="pixel-colors"></div>
        </div>
        <p class="hint">Linksklick malt, Rechtsklick radiert. Die Mitte und die Achsen sind leicht grau markiert. „Spiegeln“ malt auf Wunsch die Gegenseite mit.</p>
      </div>

      <div class="card">
        <div class="card-head"><div><h2>Vorschau</h2><p>So sieht es im Spiel aus</p></div></div>
        <div class="stage" id="stage"><div class="stage-mark" id="stage-mark"></div><b>1:1 im Spiel</b></div>
        <div id="pixel-fields"></div>
        <div class="pixel-actions">
          <button class="btn" id="pixel-mirror"></button>
          <button class="btn" id="pixel-clear">Alles löschen</button>
        </div>
      </div>
    </div>
  `);

  let draft =
    isPixel && Array.isArray(profile.pixels) && profile.pixels.length
      ? profile.pixels.map((row) => [...row])
      : emptyGrid();
  const size = draft.length;

  const grid = wrap.querySelector('#pixel-grid');
  grid.style.setProperty('--cols', String(size));

  const commit = () => {
    if (!isPixel) return;
    patchProfile({ pixels: draft.map((row) => [...row]), kind: 'pixels' });
  };

  const paintCell = (cell) => {
    const x = Number(cell.dataset.x);
    const y = Number(cell.dataset.y);
    const color = erasing ? '' : brush;
    draft[y][x] = color;
    const apply = (node, value) => {
      node.style.background = value || '';
      node.classList.toggle('is-on', Boolean(value));
    };
    apply(cell, color);
    if (mirror) {
      const twinX = size - 1 - x;
      draft[y][twinX] = color;
      const twin = grid.querySelector(`[data-x="${twinX}"][data-y="${y}"]`);
      if (twin) apply(twin, color);
    }
    commit();
  };

  const mid = Math.floor((size - 1) / 2);
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const cell = document.createElement('button');
      cell.className = 'pixel-cell';
      cell.dataset.x = String(x);
      cell.dataset.y = String(y);
      if (x === mid || y === mid) cell.classList.add('is-axis');
      if (x === mid && y === mid) cell.classList.add('is-center');
      if (draft[y][x]) {
        cell.style.background = draft[y][x];
        cell.classList.add('is-on');
      }
      cell.addEventListener('contextmenu', (event) => event.preventDefault());
      cell.addEventListener('mousedown', (event) => {
        event.preventDefault();
        if (!isPixel) {
          startPixelProfile(draft);
          return;
        }
        painting = true;
        erasing = event.button === 2 || event.shiftKey;
        paintCell(cell);
      });
      cell.addEventListener('mouseenter', () => {
        if (painting && isPixel) paintCell(cell);
      });
      grid.appendChild(cell);
    }
  }

  grid.addEventListener('contextmenu', (event) => event.preventDefault());

  wrap.querySelector('#pixel-colors').appendChild(
    colorRow(brush, (color) => {
      brush = color;
      if (isPixel) patchProfile({ color });
    }),
  );

  const fields = wrap.querySelector('#pixel-fields');
  fields.appendChild(
    slider({
      label: 'Pixel-Größe',
      value: profile?.pixelSize || 4,
      min: 1,
      max: 12,
      onInput: (v) => {
        if (isPixel) patchProfile({ pixelSize: v });
      },
    }),
  );

  const raster = wrap.querySelector('#pixel-raster');
  raster.value = String(size);
  raster.addEventListener('change', () => {
    const next = Number(raster.value) || GRID;
    gridSize = next;
    if (!isPixel) {
      draft = emptyGrid(next);
      renderView();
      return;
    }
    const scaled = resizeGrid(draft, next);
    draft = scaled;
    patchProfile({ pixels: scaled.map((row) => [...row]), kind: 'pixels' }, { immediate: true });
    renderView();
  });

  const mirrorBtn = wrap.querySelector('#pixel-mirror');
  mirrorBtn.textContent = mirror ? 'Spiegeln: an' : 'Spiegeln: aus';
  mirrorBtn.classList.toggle('btn-primary', mirror);
  mirrorBtn.addEventListener('click', () => {
    mirror = !mirror;
    mirrorBtn.textContent = mirror ? 'Spiegeln: an' : 'Spiegeln: aus';
    mirrorBtn.classList.toggle('btn-primary', mirror);
  });

  wrap.querySelector('#pixel-clear').addEventListener('click', () => {
    if (!isPixel) return;
    draft = emptyGrid(size);
    renderView();
    patchProfile({ pixels: emptyGrid(size) }, { immediate: true });
  });

  wrap.querySelector('#pixel-new').addEventListener('click', () => {
    startPixelProfile(emptyGrid());
  });

  viewEl.appendChild(wrap);
  drawStage();
}

async function uploadImage() {
  const next = await window.xh.pickImage();
  if (next?.app) {
    app = next.app;
    meta = next.meta;
    updateChrome();
    renderView();
    showToast(next.error ? `Fehler: ${next.error}` : 'Bild als Crosshair übernommen');
  }
}

function renderImages() {
  const wrap = h(`
    <div class="card">
      <div class="card-head">
        <div><h2>Eigenes Bild oder GIF</h2><p>PNG, JPG, WebP, SVG oder animiertes GIF</p></div>
        <button class="btn btn-primary" id="image-add">Datei wählen</button>
      </div>
      <div class="drop" id="image-drop">
        <strong>Datei hier ablegen oder klicken</strong>
        <span>Am besten ein quadratisches Bild mit transparentem Hintergrund. GIFs laufen im Overlay animiert weiter. Alles bleibt lokal.</span>
      </div>
      <h3 class="section">Deine Bilder</h3>
      <div class="list" id="image-list"></div>
    </div>
  `);

  const list = wrap.querySelector('#image-list');
  const images = app.customImages || [];

  if (images.length === 0) {
    list.appendChild(h('<div class="empty">Noch keine eigenen Bilder. Lade ein PNG oder GIF hoch.</div>'));
  }

  for (const image of images) {
    const profile = app.profiles.find((entry) => entry.image === image.file);
    const active = profile && profile.id === app.activeId;
    const row = h(`
      <div class="list-row ${active ? 'is-active' : ''}">
        <div class="list-thumb"><img src="${mediaUrl(image.file)}" alt="" /></div>
        <div class="list-text">
          <strong>${image.name}</strong>
          <span>${image.file.toLowerCase().endsWith('.gif') ? 'Animiertes GIF' : 'Bild'}${profile ? ` · ${profile.name}` : ''}</span>
        </div>
        <div class="row-actions">
          <button class="btn" data-act="use" ${profile ? '' : 'disabled'}>Nutzen</button>
          <button class="btn btn-danger" data-act="delete">Löschen</button>
        </div>
      </div>
    `);
    row.querySelector('[data-act="use"]').addEventListener('click', async () => {
      if (!profile) return;
      await patchApp({ activeId: profile.id });
      renderView();
    });
    row.querySelector('[data-act="delete"]').addEventListener('click', async () => {
      const next = await window.xh.deleteImage(image.id);
      app = next.app;
      meta = next.meta;
      renderView();
      showToast('Bild entfernt');
    });
    list.appendChild(row);
  }

  const drop = wrap.querySelector('#image-drop');
  drop.addEventListener('click', uploadImage);
  drop.addEventListener('dragover', (event) => {
    event.preventDefault();
    drop.style.borderColor = '#4b5b73';
  });
  drop.addEventListener('dragleave', () => {
    drop.style.borderColor = '';
  });
  drop.addEventListener('drop', (event) => {
    event.preventDefault();
    drop.style.borderColor = '';
    uploadImage();
  });

  wrap.querySelector('#image-add').addEventListener('click', uploadImage);
  viewEl.appendChild(wrap);
}

function renderProfiles() {
  const wrap = h(`
    <div class="card">
      <div class="card-head">
        <div><h2>Profile</h2><p>${app.profiles.length} Designs gespeichert</p></div>
        <div class="row-actions">
          <button class="btn" id="profile-export">Exportieren</button>
          <button class="btn" id="profile-import">Importieren</button>
          <button class="btn" id="profile-new">Aktuelles duplizieren</button>
        </div>
      </div>
      <div class="list" id="profile-list"></div>
      <p class="hint">Eingebaute Designs bleiben immer erhalten. Eigene Designs und Bilder kannst du löschen.</p>
    </div>
  `);

  const list = wrap.querySelector('#profile-list');
  for (const profile of app.profiles) {
    const active = profile.id === app.activeId;
    const row = h(`
      <div class="list-row ${active ? 'is-active' : ''}">
        <div class="list-thumb"></div>
        <div class="list-text">
          <strong>${profile.name}</strong>
          <span>${KIND_LABELS[profile.kind] || profile.kind}${profile.builtin ? ' · eingebaut' : ' · eigenes'}</span>
        </div>
        <div class="row-actions">
          <button class="btn" data-act="use">${active ? 'Aktiv' : 'Aktivieren'}</button>
          <button class="btn btn-danger" data-act="delete" ${profile.builtin ? 'disabled' : ''}>Löschen</button>
        </div>
      </div>
    `);

    const thumbHost = row.querySelector('.list-thumb');
    if (profile.autoRank) {
      const rank = (window.XH?.RANKS || []).find(
        (entry) => entry.id === (app?.ranks || {})[app?.rankMode || 'br'],
      );
      const badge = rank?.id === 'unreal' ? 'champion' : rank?.id || 'unranked';
      thumbHost.appendChild(h(`<img src="xh://rank/${badge}.png" alt="" style="mix-blend-mode:screen" />`));
    } else if (profile.kind === 'image') {
      thumbHost.appendChild(h(`<img src="${mediaUrl(profile.image)}" alt="" />`));
    } else {
      const thumb = XH.thumbnail(profile, 40);
      if (thumb) thumbHost.appendChild(thumb);
    }

    row.querySelector('[data-act="use"]').addEventListener('click', async () => {
      await patchApp({ activeId: profile.id });
      renderView();
    });
    row.querySelector('[data-act="delete"]').addEventListener('click', async () => {
      const next = await window.xh.deleteProfile(profile.id);
      app = next.app;
      meta = next.meta;
      renderView();
      showToast('Profil gelöscht');
    });
    list.appendChild(row);
  }

  wrap.querySelector('#profile-new').addEventListener('click', async () => {
    const profile = currentProfile();
    if (!profile) return;
    const next = await window.xh.addProfile({ ...profile, id: undefined, name: `${profile.name} Kopie` });
    app = next.app;
    meta = next.meta;
    renderView();
  });
  wrap.querySelector('#profile-export').addEventListener('click', async () => {
    const done = await window.xh.exportConfig();
    showToast(done ? 'Konfiguration gespeichert' : 'Export abgebrochen');
  });
  wrap.querySelector('#profile-import').addEventListener('click', async () => {
    const next = await window.xh.importConfig();
    if (next?.app) {
      app = next.app;
      meta = next.meta;
      renderView();
      showToast('Konfiguration geladen');
    }
  });

  viewEl.appendChild(wrap);
}

function renderHotkeys() {
  const on = Boolean(app.hotkeysEnabled);
  const toggleCard = h(`
    <div class="card" style="margin-bottom:14px">
      <div id="hotkey-toggle"></div>
      <p class="hint">Solange das aus ist, belegt die App keine globalen Tasten – F8 und F9 bleiben dann für andere Programme frei.</p>
    </div>
  `);
  toggleCard.querySelector('#hotkey-toggle').appendChild(
    toggleRow({
      title: 'Tastenkürzel aktiv',
      desc: on ? 'Kürzel unten und der Clip-Hotkey sind belegt' : 'aus – nichts wird im System belegt',
      checked: on,
      onChange: async (value) => {
        await patchApp({ hotkeysEnabled: value });
        renderView();
        showToast(value ? 'Tastenkürzel aktiv' : 'Tastenkürzel aus');
      },
    }),
  );
  viewEl.appendChild(toggleCard);

  const wrap = h(`
    <div class="card">
      <div class="card-head"><div><h2>Tastenkürzel</h2><p>Funktionieren auch, während Fortnite im Vordergrund ist</p></div></div>
      <div id="hotkey-list"></div>
      <p class="hint">Ins Feld klicken und Tastenkombination drücken, z. B. <span class="kbd">F8</span> oder <span class="kbd">Strg</span> + <span class="kbd">Alt</span> + <span class="kbd">X</span>. Feld leeren schaltet das Kürzel ab.</p>
    </div>
  `);

  const list = wrap.querySelector('#hotkey-list');
  const labels = {
    toggle: 'Crosshair an / aus',
    cycle: 'Nächstes Design',
    bigger: 'Größer',
    smaller: 'Kleiner',
    music: 'Musik-Player an / aus',
  };

  // Crosshair pro Waffe: Taste 1–5 schaltet das Design um.
  const weaponCard = h(`
    <div class="card" style="margin-top:14px">
      <div class="card-head"><div><h2>Crosshair pro Waffe</h2><p>Taste 1–5 wechselt das Design – z. B. Gewehr, Schrot, SMG, Sniper</p></div></div>
      <div id="weapon-list"></div>
      <p class="hint">Drückst du die Taste im Spiel, wechselt das Overlay sofort das Crosshair mit.</p>
    </div>
  `);
  const weaponList = weaponCard.querySelector('#weapon-list');
  const profileNames = new Map((app.profiles || []).map((item) => [item.id, item.name]));
  for (const key of ['1', '2', '3', '4', '5']) {
    const current = app.weaponHotkeys?.[key] || '';
    const row = h(`
      <div class="list-row">
        <div class="list-text">
          <strong>Taste ${key}</strong>
          <span>${current ? profileNames.get(current) || 'Design' : 'nicht belegt'}</span>
        </div>
        <select data-key="${key}" style="max-width:220px">
          <option value="">nicht belegt</option>
          ${(app.profiles || [])
            .map((item) => `<option value="${item.id}" ${item.id === current ? 'selected' : ''}>${item.name}</option>`)
            .join('')}
        </select>
      </div>
    `);
    row.querySelector('select').addEventListener('change', async (event) => {
      const next = { ...(app.weaponHotkeys || {}) };
      if (event.target.value) next[key] = event.target.value;
      else delete next[key];
      await patchApp({ weaponHotkeys: next });
      renderView();
      showToast(event.target.value ? `Taste ${key} wechselt jetzt das Crosshair` : `Taste ${key} geleert`);
    });
    weaponList.appendChild(row);
  }
  wrap.appendChild(weaponCard);

  for (const [key, label] of Object.entries(labels)) {
    const row = h(`
      <div class="hotkey-row">
        <p>${label}</p>
        <input class="hotkey-input" type="text" readonly ${on ? '' : 'disabled'} value="${app.hotkeys[key] || ''}" placeholder="—" data-key="${key}" />
      </div>
    `);
    const input = row.querySelector('input');
    input.addEventListener('keydown', async (event) => {
      event.preventDefault();
      if (event.key === 'Escape' || event.key === 'Backspace' || event.key === 'Delete') {
        input.value = '';
        const hotkeys = { ...app.hotkeys, [key]: '' };
        await patchApp({ hotkeys });
        showToast('Kürzel entfernt');
        return;
      }
      const parts = [];
      if (event.ctrlKey) parts.push('Control');
      if (event.altKey) parts.push('Alt');
      if (event.shiftKey) parts.push('Shift');
      if (event.metaKey) parts.push('Super');
      const code = event.code;
      let main = '';
      if (/^Key[A-Z]$/.test(code)) main = code.slice(3);
      else if (/^Digit[0-9]$/.test(code)) main = code.slice(5);
      else if (/^F\d{1,2}$/.test(code)) main = code;
      else if (code === 'Space') main = 'Space';
      else if (code.startsWith('Arrow')) main = code.slice(5);
      if (!main) return;
      parts.push(main);
      input.value = parts.join(' + ');
      const hotkeys = { ...app.hotkeys, [key]: parts.join('+') };
      await patchApp({ hotkeys });
      showToast('Kürzel gespeichert');
    });
    list.appendChild(row);
  }

  viewEl.appendChild(wrap);
}

function renderSettings() {
  const wrap = h(`
    <div class="grid two">
      <div class="card">
        <div class="card-head"><div><h2>Anzeige</h2><p>Wo und wie das Crosshair erscheint</p></div></div>
        <div class="field">
          <label>Monitor</label>
          <select id="set-display">
            <option value="auto" ${app.displayId === 'auto' ? 'selected' : ''}>Automatisch (Monitor des Hub-Fensters)</option>
            ${(meta?.displays || [])
              .map(
                (display) =>
                  `<option value="${display.id}" ${app.displayId === display.id ? 'selected' : ''}>${display.label} · ${display.width}×${display.height}${display.primary ? ' (Haupt)' : ''}</option>`,
              )
              .join('')}
          </select>
        </div>
        <div id="set-offset"></div>
        <div id="set-scale"></div>
        <div id="set-toggles"></div>
      </div>

      <div class="card">
        <div class="card-head"><div><h2>System</h2><p>Start, Ton und Verhalten der App</p></div></div>
        <div id="sys-toggles"></div>
        <h3 class="section">Daten</h3>
        <div class="row-actions">
          <button class="btn" id="set-export">Konfiguration exportieren</button>
          <button class="btn" id="set-import">Importieren</button>
          <button class="btn btn-danger" id="set-reset">Zurücksetzen</button>
        </div>
        <p class="hint">Config-Ordner: <br /><span id="set-dir"></span></p>
      </div>
    </div>
  `);

  wrap.querySelector('#set-dir').textContent = meta?.xhDir || '';

  wrap.querySelector('#set-display').addEventListener('change', (event) => {
    patchApp({ displayId: event.target.value }, { rerender: true });
  });

  wrap.querySelector('#set-offset').appendChild(
    slider({
      label: 'Versatz X',
      value: app.offsetX,
      min: -400,
      max: 400,
      unit: ' px',
      onInput: (value) => {
        app.offsetX = value;
        patchApp({ offsetX: value });
      },
    }),
  );
  wrap.querySelector('#set-offset').appendChild(
    slider({
      label: 'Versatz Y',
      value: app.offsetY,
      min: -400,
      max: 400,
      unit: ' px',
      onInput: (value) => {
        app.offsetY = value;
        patchApp({ offsetY: value });
      },
    }),
  );
  wrap.querySelector('#set-scale').appendChild(
    slider({
      label: 'Größe',
      value: app.scale,
      min: 0.4,
      max: 3,
      step: 0.05,
      unit: '×',
      onInput: (value) => {
        app.scale = value;
        patchApp({ scale: value });
      },
    }),
  );

  wrap.querySelector('#set-toggles').appendChild(
    toggleRow({
      title: 'Immer sichtbar',
      desc: 'Crosshair bleibt an, auch wenn Fortnite nicht läuft (F8 schaltet genau das)',
      checked: app.alwaysOn || !app.onlyInGame,
      onChange: (value) => patchApp({ alwaysOn: value, onlyInGame: !value }),
    }),
  );

  wrap.querySelector('#sys-toggles').appendChild(
    toggleRow({
      title: 'Klick-Sounds',
      desc: 'Kurzer Ton beim Bedienen der App',
      checked: app.clickSound,
      onChange: (value) => patchApp({ clickSound: value }),
    }),
  );
  wrap.querySelector('#sys-toggles').appendChild(
    toggleRow({
      title: 'In Aufnahmen sichtbar',
      desc: 'Medal, OBS und Bildschirmaufnahmen filmen das Crosshair mit',
      checked: app.captureVisible !== false,
      onChange: (value) => patchApp({ captureVisible: value }),
    }),
  );
  wrap.querySelector('#sys-toggles').appendChild(
    toggleRow({
      title: 'Fenster schließen lässt Crosshair an',
      desc: 'Die App läuft im Infobereich weiter, bis du sie dort beendest',
      checked: app.closeToTray,
      onChange: (value) => patchApp({ closeToTray: value }),
    }),
  );
  wrap.querySelector('#sys-toggles').appendChild(
    toggleRow({
      title: 'Mit Windows starten',
      desc: 'Crosshair ist nach dem Anmelden sofort bereit',
      checked: app.autoStart,
      onChange: (value) => patchApp({ autoStart: value }),
    }),
  );

  wrap.querySelector('#set-export').addEventListener('click', async () => {
    const done = await window.xh.exportConfig();
    showToast(done ? 'Konfiguration gespeichert' : 'Export abgebrochen');
  });
  wrap.querySelector('#set-import').addEventListener('click', async () => {
    const next = await window.xh.importConfig();
    if (next?.app) {
      app = next.app;
      meta = next.meta;
      renderView();
      showToast('Konfiguration geladen');
    }
  });
  wrap.querySelector('#set-reset').addEventListener('click', async () => {
    const next = await window.xh.reset();
    app = next.app;
    meta = next.meta;
    renderView();
    showToast('Einstellungen zurückgesetzt');
  });

  viewEl.appendChild(wrap);
  viewEl.appendChild(renderWallpapers());
  viewEl.appendChild(helpCard());
}

function renderWallpapers() {
  const card = h(`
    <div class="card" style="margin-top:14px">
      <div class="card-head">
        <div><h2>Hintergrund</h2><p>Live-Wallpaper aus Revolution Browser</p></div>
        <div class="row-actions">
          <button class="btn" id="wall-custom">Eigene Datei</button>
          <button class="btn ${app.wallpaper ? '' : 'btn-primary'}" id="wall-none">Ohne</button>
        </div>
      </div>
      <div class="wall-grid" id="wall-grid"></div>
    </div>
  `);

  const grid = card.querySelector('#wall-grid');

  let shadeTimer = null;
  card.insertBefore(
    slider({
      label: 'Abdunklung des Hintergrunds',
      value: Number.isFinite(Number(app.wallShade)) ? Number(app.wallShade) : 80,
      min: 0,
      max: 100,
      step: 5,
      unit: ' %',
      onInput: (value) => {
        app.wallShade = value;
        applyShade();
        // Erst nach dem Loslassen speichern, sonst schreibt jeder Pixel.
        clearTimeout(shadeTimer);
        shadeTimer = setTimeout(() => patchApp({ wallShade: value }), 180);
      },
    }),
    grid,
  );
  const items = meta?.wallpapers || [];

  if (items.length === 0) {
    grid.appendChild(h('<div class="empty">Keine Hintergründe gefunden.</div>'));
  }

  for (const item of items) {
    const active = app.wallpaper === item.name;
    const node = h(`
      <button class="wall-card ${active ? 'is-active' : ''}">
        <video muted loop playsinline preload="metadata" src="${wallUrl(item.name)}" poster="${item.poster ? wallUrl(item.poster) : ''}"></video>
        <span>${item.label}${active ? ' · aktiv' : ''}</span>
      </button>
    `);
    const video = node.querySelector('video');
    node.addEventListener('mouseenter', () => {
      const played = video.play();
      if (played && played.catch) played.catch(() => {});
    });
    node.addEventListener('mouseleave', () => {
      video.pause();
      video.currentTime = 0;
    });
    node.addEventListener('click', async () => {
      await patchApp({ wallpaper: item.name });
      applyWallpaper();
      renderView();
    });
    grid.appendChild(node);
  }

  card.querySelector('#wall-custom').addEventListener('click', async () => {
    const next = await window.xh.pickWallpaper();
    if (next?.app) {
      app = next.app;
      meta = next.meta;
      applyWallpaper();
      renderView();
      showToast('Hintergrund gesetzt');
    }
  });
  card.querySelector('#wall-none').addEventListener('click', async () => {
    await patchApp({ wallpaper: '' });
    applyWallpaper();
    renderView();
  });

  return card;
}

/* ---------------- Auswertung aus den Replays ---------------- */

const statsState = { period: 'all', data: null, loading: false };

const escHtml = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

async function statsLoad() {
  if (statsState.data) return statsState.data;
  if (statsState.loading) return {};
  statsState.loading = true;
  try {
    statsState.data = (await window.xh.statsData()) || {};
  } catch {
    statsState.data = {};
  }
  statsState.loading = false;
  return statsState.data;
}

function statsMatches() {
  const all = (statsState.data?.matches || []).filter((match) => match && match.me);
  const days = statsState.period === '7d' ? 7 : statsState.period === '30d' ? 30 : 0;
  const now = Date.now();
  const list = days
    ? all.filter((match) => {
        const at = new Date(match.date || match.parsedAt || 0).getTime();
        return Number.isFinite(at) && now - at <= days * 86400000;
      })
    : all;
  return list
    .slice()
    .sort(
      (a, b) =>
        new Date(b.date || b.parsedAt || 0).getTime() - new Date(a.date || a.parsedAt || 0).getTime(),
    );
}

async function paintStats(host) {
  if (!host) return;
  host.innerHTML = '<p class="note">Lade Daten …</p>';
  await statsLoad();
  const list = statsMatches();
  if (list.length === 0) {
    host.innerHTML =
      '<p class="note">Keine Matches in diesem Zeitraum. Mit „Replays scannen“ holst du sie hierher.</p>';
    return;
  }

  const int = (value) => new Intl.NumberFormat('de-DE').format(Math.round(Number(value) || 0));
  const dec = (value) =>
    new Intl.NumberFormat('de-DE', { maximumFractionDigits: 1 }).format(Number(value) || 0);

  let kills = 0;
  let wins = 0;
  let placed = 0;
  let placementSum = 0;
  let damage = 0;
  let taken = 0;
  let materials = 0;
  let revives = 0;
  const weapons = new Map();

  for (const match of list) {
    kills += match.me.kills || 0;
    if (match.me.placement === 1) wins += 1;
    if (match.me.placement > 0) {
      placed += 1;
      placementSum += match.me.placement;
    }
    const stats = match.stats || {};
    damage += stats.damageToPlayers || 0;
    taken += stats.damageTaken || 0;
    materials += stats.materialsGathered || 0;
    revives += stats.revives || 0;
    for (const kill of match.kills || []) {
      if (kill.killerName !== match.me.name || !kill.weapon) continue;
      weapons.set(kill.weapon, (weapons.get(kill.weapon) || 0) + 1);
    }
  }

  const kd = kills / Math.max(1, list.length - wins);
  const topWeapons = [...weapons.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6);
  const recent = list.slice(0, 8);

  host.innerHTML = `
    <div class="stat-grid">
      <div class="stat"><span>Matches</span><strong>${int(list.length)}</strong></div>
      <div class="stat"><span>Kills</span><strong>${int(kills)}</strong></div>
      <div class="stat"><span>K/D</span><strong>${dec(kd)}</strong></div>
      <div class="stat"><span>Siege</span><strong>${int(wins)}</strong></div>
      <div class="stat"><span>Ø Platzierung</span><strong>${placed ? dec(placementSum / placed) : '–'}</strong></div>
      <div class="stat"><span>Schaden</span><strong>${int(damage)}</strong></div>
      <div class="stat"><span>Schaden genommen</span><strong>${int(taken)}</strong></div>
      <div class="stat"><span>Material</span><strong>${int(materials)}</strong></div>
      <div class="stat"><span>Revives</span><strong>${int(revives)}</strong></div>
    </div>
    <div class="grid two" style="margin-top:14px">
      <div>
        <h3 class="section">Top-Waffen</h3>
        ${
          topWeapons.length
            ? topWeapons
                .map(
                  ([name, count]) =>
                    `<div class="list-row"><div class="list-text"><strong>${escHtml(name)}</strong><span>${int(count)} Kills</span></div></div>`,
                )
                .join('')
            : '<p class="note">Noch keine Waffen-Kills erfasst.</p>'
        }
      </div>
      <div>
        <h3 class="section">Letzte Matches</h3>
        ${recent
          .map((match) => {
            const date = new Date(match.date || match.parsedAt || 0);
            const when = Number.isNaN(date.getTime())
              ? '–'
              : date.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' });
            const place = match.me.placement ? `#${match.me.placement}` : '–';
            return `<div class="list-row"><div class="list-text"><strong>${place} · ${int(match.me.kills || 0)} Kills</strong><span>${when}${match.me.placement === 1 ? ' · Sieg' : ''}</span></div></div>`;
          })
          .join('')}
      </div>
    </div>
  `;
}

function renderStats() {
  const last = meta?.lastMatch ? new Date(meta.lastMatch) : null;
  const ranks = app.ranks || {};
  const rankList = window.XH?.RANKS || [];

  const wrap = h(`
    <div class="card">
      <div class="card-head">
        <div><h2>Statistiken</h2><p>Bonus: lokale Auswertung deiner Fortnite-Replays</p></div>
        <div class="row-actions">
          <button class="btn" id="stats-scan">Replays scannen</button>
        </div>
      </div>
      <div class="stat-grid">
        <div class="stat"><span>Matches</span><strong>${meta?.matches ?? 0}</strong></div>
        <div class="stat"><span>Gegner</span><strong>${meta?.players ?? 0}</strong></div>
        <div class="stat"><span>Letztes Match</span><strong>${last ? last.toLocaleDateString('de-DE') : '–'}</strong></div>
      </div>

      <div class="card-head" style="margin-top:18px"><div><h2>Dein Rang</h2><p>Gilt für Battle Royale, Null Bauen und Reload – das Crosshair übernimmt Farbe und Abzeichen</p></div></div>
      <div class="rank-grid" id="rank-grid"></div>
      <p class="hint">„Crosshair in Rangfarbe“ aktiviert das animierte Rang-Design (Bronze bis Unreal) in genau dieser Farbe.</p>
    </div>
  `);

  wrap.querySelector('#stats-scan').addEventListener('click', async () => {
    showToast('Replays werden gelesen …');
    await window.xh.scan();
    const next = await window.xh.get();
    app = next.app;
    meta = next.meta;
    renderView();
    showToast('Scan fertig');
  });

  // Ein Rang für alle Modi – man hat überall denselben.
  const grid = wrap.querySelector('#rank-grid');
  const currentRank = Object.values(ranks).find(Boolean) || '';
  const rank = rankList.find((entry) => entry.id === currentRank);
  // Der Rang lässt sich nicht einstellen – er kommt ausschließlich aus Fortnite.
  const card = h(`
    <div class="rank-card ${rank ? 'is-set' : ''}" ${rank ? `style="--rank:${rank.color}"` : ''}>
      <span class="rank-badge">${rank ? rank.name : 'Kein Rang'}</span>
      <strong>Dein Rang · gilt für alle Modi</strong>
      <span class="sub">${rank ? 'So erkannt aus Fortnite – nicht manuell änderbar' : 'Wird automatisch erkannt, sobald du mit Rang in der Lobby stehst'}</span>
      <button class="btn" data-rank="${currentRank}" ${rank ? '' : 'disabled'}>Crosshair in Rangfarbe</button>
    </div>
  `);

  card.querySelector('[data-rank]').addEventListener('click', async () => {
    if (!currentRank) return;
    const profile = (app.profiles || []).find((entry) => entry.autoRank);
    if (!profile) {
      showToast('Rang-Crosshair nicht gefunden');
      return;
    }
    await patchApp({ activeId: profile.id });
    renderView();
    showToast('Rang-Crosshair ist aktiv');
  });

  grid.appendChild(card);

  // Auswertung direkt im Tab – kein zweites Fenster, keine alte App mehr.
  const statsCard = h(`
    <div class="card" style="margin-top:14px">
      <div class="card-head">
        <div><h2>Auswertung</h2><p>Aus deinen gespeicherten Replays</p></div>
        <div class="row-actions" id="stats-periods">
          <button class="btn btn-primary" data-period="all">Lifetime</button>
          <button class="btn" data-period="7d">7 Tage</button>
          <button class="btn" data-period="30d">30 Tage</button>
        </div>
      </div>
      <div id="stats-body"><p class="note">Lade Daten …</p></div>
    </div>
  `);
  wrap.appendChild(statsCard);
  statsCard.querySelectorAll('[data-period]').forEach((button) => {
    button.addEventListener('click', () => {
      statsState.period = button.dataset.period;
      statsCard
        .querySelectorAll('[data-period]')
        .forEach((node) => node.classList.toggle('btn-primary', node === button));
      paintStats(statsCard.querySelector('#stats-body'));
    });
  });
  paintStats(statsCard.querySelector('#stats-body'));

  const modeBar = h(`
    <div class="row-actions" style="margin-top:14px;flex-wrap:wrap;gap:8px">
      <button class="btn ${app.rankAuto ? 'btn-primary' : ''}" id="rank-auto">Auto-Erkennung: ${app.rankAuto ? 'An' : 'Aus'}</button>
    </div>
  `);
  modeBar.querySelector('#rank-auto').addEventListener('click', async () => {
    await patchApp({ rankAuto: !app.rankAuto });
    renderView();
    showToast(app.rankAuto ? 'Rang-Erkennung an – Lobby wird gelesen' : 'Rang-Erkennung aus');
  });

  wrap.appendChild(modeBar);

  const detected = meta?.rank?.lastDetection;
  if (detected) {
    const rankName =
      (window.XH?.RANKS || []).find((entry) => entry.id === detected.rank)?.name || detected.rank;
    const modeNames = (detected.modes || [])
      .map((id) => MODES.find((entry) => entry.id === id)?.name || id)
      .join(', ');
    wrap.appendChild(
      h(`
        <p class="hint" style="margin-top:10px">
          Zuletzt in der Lobby erkannt: <b>${rankName}</b> für ${modeNames} ·
          ${new Date(detected.at).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })} Uhr
        </p>
      `),
    );
  }

  viewEl.appendChild(wrap);
}

/* ---------------- Clips (Medal-Ersatz) ---------------- */

let clipReady = false;

const clipApi = {
  captureSources: () => window.xh.captureSources(),
  clipChunk: (buffer, isFirst) => window.xh.clipChunk(buffer, isFirst),
  clipReset: (options) => window.xh.clipReset(options),
  camChunk: (buffer, isFirst) => window.xh.camChunk(buffer, isFirst),
  camReset: (options) => window.xh.camReset(options),
  camStop: () => window.xh.camStop(),
  recToggle: () => window.xh.recToggle(),
  recStop: () => window.xh.recStop(),
  clipSave: (options) => window.xh.clipSave(options),
  clipClear: (category) => window.xh.clipClear(category),
  clipDelete: (name) => window.xh.clipDelete(name),
  getState: () => window.xh.get(),
  saveSettings: (patch) => window.xh.saveSettings(patch),
  openPath: (target) => window.xh.openPath(target),
  inputStart: () => window.xh.inputStart(),
  inputStop: () => window.xh.inputStop(),
};

function clipData() {
  // Schreibt direkt in meta.clip zurück: Löschen oder Umschalten im Clips-Tab
  // ist sofort sichtbar, ohne auf den nächsten Status vom Hauptprozess zu warten.
  if (!meta) return { settings: {}, clips: [], clipUsage: {}, ownNames: [], meta: {} };
  if (!meta.clip) meta.clip = { settings: {}, clips: [], usage: {} };
  const clip = meta.clip;
  return {
    get settings() {
      return clip.settings || {};
    },
    set settings(value) {
      if (value && typeof value === 'object') clip.settings = { ...clip.settings, ...value };
    },
    get clips() {
      return clip.clips || [];
    },
    set clips(value) {
      if (Array.isArray(value)) clip.clips = value;
    },
    get clipUsage() {
      return clip.usage || {};
    },
    set clipUsage(value) {
      if (value) clip.usage = value;
    },
    ownNames: clip.ownNames || [],
    meta: { clipsDir: clip.dir },
  };
}

function ensureClipUI() {
  if (clipReady || !window.ClipUI) return;
  window.ClipUI.init({
    getData: clipData,
    render: () => {
      const host = document.getElementById('clip-host');
      if (host) {
        host.innerHTML = window.ClipUI.render();
        window.ClipUI.afterRender?.();
      }
    },
    toast: showToast,
    api: clipApi,
    getCrosshair: () => ({ profile: currentProfile(), scale: app?.scale || 1 }),
    getKeys: () => (window.ClipUI ? window.ClipUI.getKeys() : []),
  });
  clipReady = true;
}

function renderClips() {
  if (!window.ClipUI) {
    viewEl.appendChild(h('<div class="card"><h3>Clips</h3><p class="note">Recorder konnte nicht geladen werden.</p></div>'));
    return;
  }
  ensureClipUI();
  const host = h('<div id="clip-host"></div>');
  viewEl.appendChild(host);
  host.innerHTML = window.ClipUI.render();
  window.ClipUI.afterRender?.();
  window.ClipUI.ensureSources();
  window.xh.inputStart();
}

function helpCard() {
  const wrap = h(`
    <div class="card" style="margin-top:14px">
      <div class="card-head"><div><h2>So funktioniert es</h2><p>In vier Schritten zum eigenen Crosshair</p></div></div>
      <div class="list">
        <div class="list-row"><div class="list-text"><strong>1. Design wählen</strong><span>Unter „Designs“ eins der fertigen Crosshairs anklicken, unter „Pixeln“ dein eigenes malen oder unter „Bilder &amp; GIFs“ ein Bild laden.</span></div></div>
        <div class="list-row"><div class="list-text"><strong>2. Anpassen</strong><span>Größe, Länge, Dicke, Lücke, Farbe und Kontur – die Vorschau zeigt sofort das Ergebnis.</span></div></div>
        <div class="list-row"><div class="list-text"><strong>3. F8 drücken</strong><span>Crosshair an – und zwar dauerhaft, auch ohne laufendes Spiel. Nochmal F8 schaltet es aus.</span></div></div>
        <div class="list-row"><div class="list-text"><strong>4. Fortnite starten</strong><span>Das Crosshair sitzt mittig auf dem Spielmonitor, ohne Popups und ohne Eingriff ins Spiel.</span></div></div>
      </div>
      <h3 class="section">Gut zu wissen</h3>
      <p class="hint">
        Das Crosshair ist ein Overlay über dem Spielbild und liest oder verändert keine Spieldaten. Fenster schließen beendet es nicht:
        die App bleibt im Infobereich, bis du sie dort über „Beenden“ schließt.<br /><br />
        Tastenkürzel: <span class="kbd">${app.hotkeys.toggle || '—'}</span> an/aus ·
        <span class="kbd">${app.hotkeys.cycle || '—'}</span> nächstes Design ·
        <span class="kbd">${app.hotkeys.bigger || '—'}</span> größer ·
        <span class="kbd">${app.hotkeys.smaller || '—'}</span> kleiner ·
        <span class="kbd">${app.hotkeys.music || '—'}</span> Musik-Player an/aus.
      </p>
    </div>
  `);
  return wrap;
}

/* ---------------- Leistung ---------------- */

let perfInfo = null;

function perfPreview(host, data) {
  if (!host) return;
  const rows = Array.isArray(data?.rows) ? data.rows : [];
  const parts = [];
  if (rows.includes('fps')) {
    parts.push(
      `<div class="pp-row pp-fps"><span class="pp-k">${data.fpsLabel === 'FPS' ? 'FPS' : 'Hz'}</span><b>${data.fps ?? '–'}</b><span class="pp-sub">${data.ms ?? '–'} ms</span></div>`,
    );
  }
  if (rows.includes('cpu')) {
    parts.push(
      `<div class="pp-row"><span class="pp-k">CPU</span><b>${data.cpu ?? 0}%</b><span class="pp-sub">${data.temp ? `${data.temp}°C` : ''}</span></div>`,
    );
  }
  if (rows.includes('gpu')) {
    parts.push(`<div class="pp-row"><span class="pp-k">GPU</span><b>${data.gpu ?? 0}%</b></div>`);
  }
  if (rows.includes('ram')) {
    parts.push(
      `<div class="pp-row"><span class="pp-k">RAM</span><b>${Number(data.ram || 0).toFixed(1)} GB</b><span class="pp-sub">/ ${Number(data.ramTotal || 0).toFixed(1)} GB</span></div>`,
    );
  }
  if (rows.includes('ping')) {
    parts.push(
      `<div class="pp-row"><span class="pp-k">PING</span><b>${data.ping ? `${data.ping} ms` : '– ms'}</b></div>`,
    );
  }
  host.innerHTML = parts.join('') || '<div class="pp-row"><span class="pp-k">AUS</span><b>–</b></div>';
}

function renderPerf() {
  const wrap = h('<div class="card"><h2>Leistung</h2><p class="hint">Wird geladen …</p></div>');
  viewEl.appendChild(wrap);
  if (!perfInfo) {
    window.xh
      .perfGet()
      .then((info) => {
        perfInfo = info;
        renderView();
      })
      .catch(() => showToast('Leistungs-Overlay nicht erreichbar'));
    return;
  }
  paintPerf(wrap);
}

let gameFpsSt = null;
function gameFpsCard() {
  const card = h('<div class="card gf-card"><h2>Echte Spiel-FPS</h2><p class="hint">Wird geprüft …</p></div>');
  if (!window.xh.gameFps) return card;
  if (!gameFpsSt) {
    window.xh.gameFps.status().then((st) => {
      gameFpsSt = st;
      renderView();
    });
    return card;
  }
  const st = gameFpsSt;
  const act = async (name) => {
    try {
      if (name === 'install') gameFpsSt = { ...st, busy: 'download' };
      if (name === 'grant') gameFpsSt = { ...st, busy: 'grant' };
      renderView();
      gameFpsSt = await window.xh.gameFps[name]();
      if (name === 'install' && gameFpsSt.installed) gameFpsSt = await window.xh.gameFps.grant();
    } catch (error) {
      showToast(error?.message || 'Hat nicht geklappt');
      gameFpsSt = await window.xh.gameFps.status();
    }
    renderView();
  };
  let text = '';
  let button = '';
  if (st.busy === 'download') text = 'PresentMon wird geladen …';
  else if (st.busy === 'grant') text = 'Bitte die Windows-Abfrage mit <b>Ja</b> bestätigen …';
  else if (!st.installed) {
    text = 'Windows verrät die Bildrate eines Spiels nur über Intels kostenloses Messwerkzeug <b>PresentMon</b> (ca. 1 MB). Einmal einrichten: laden und die Messung erlauben (Windows fragt einmal nach Admin-Rechten).';
    button = '<button class="btn primary" data-gf="install">Einrichten</button>';
  } else if (st.permission === 'ok') text = st.fps ? `Läuft – gerade <b>${st.fps} FPS</b> in Fortnite.` : 'Eingerichtet ✓ Sobald Fortnite läuft, zeigt das Overlay die echten FPS.';
  else if (st.permission === 'pending') {
    text = 'Erlaubt ✓ Melde dich einmal bei Windows ab und wieder an (oder starte den PC neu) – danach misst der Hub die echten FPS.';
    button = '<button class="btn" data-gf="retry">Schon gemacht</button>';
  } else if (st.permission === 'denied') {
    text = 'Die Messung braucht noch die Erlaubnis von Windows.';
    button = '<button class="btn primary" data-gf="grant">Erlauben</button> <button class="btn" data-gf="retry">Nochmal versuchen</button>';
  } else {
    text = 'Eingerichtet. Sobald Fortnite läuft, zeigt das Overlay die echten FPS. Klappt es nicht, einmal erlauben:';
    button = '<button class="btn" data-gf="grant">Messung erlauben</button>';
  }
  card.innerHTML = `<h2>Echte Spiel-FPS</h2><p class="hint">${text}</p>${st.error ? `<p class="hint" style="color:#ff8a8a">${st.error.replace(/</g, '&lt;')}</p>` : ''}<div class="gf-btns">${button}</div>`;
  card.querySelectorAll('[data-gf]').forEach((b) => b.addEventListener('click', () => act(b.dataset.gf)));
  return card;
}
if (window.xh?.onGameFps) {
  window.xh.onGameFps((st) => {
    const was = JSON.stringify(gameFpsSt);
    gameFpsSt = st;
    if (was !== JSON.stringify(st) && document.querySelector('.gf-card')) renderView();
  });
}

function paintPerf(wrap) {
  queueMicrotask(() => {
    if (wrap.isConnected && !document.querySelector('.gf-card')) wrap.after(gameFpsCard());
  });
  const settings = perfInfo?.settings || {};
  const data = perfInfo?.data || {};
  const enabled = settings.enabled === true;
  const save = async (patch) => {
    perfInfo = await window.xh.perfSet(patch);
    renderView();
  };

  wrap.replaceChildren();
  wrap.appendChild(
    h(`
      <div class="card-head">
        <div><h2>Performance-Overlay</h2><p>FPS, Ping, CPU, GPU und RAM – jeder Wert lässt sich einzeln ausschalten</p></div>
        <span class="tag ${enabled ? 'green' : ''}">${enabled ? 'an' : 'aus'}</span>
      </div>
    `),
  );

  const toggles = h('<div></div>');
  toggles.appendChild(
    toggleRow({
      title: 'Overlay anzeigen',
      desc: 'Karte erscheint über dem Spiel – mit deinem Live-Hintergrund',
      checked: enabled,
      onChange: (value) => save({ enabled: value }),
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'FPS',
      desc: 'Echte Spiel-FPS samt Frame-Zeit (nach dem Einrichten unten), sonst die Hz deines Monitors',
      checked: settings.fps !== false,
      onChange: (value) => save({ fps: value }),
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'CPU',
      desc: 'Prozessor-Auslastung, mit Temperatur wenn das Board sie liefert',
      checked: settings.cpu !== false,
      onChange: (value) => save({ cpu: value }),
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'GPU',
      desc: 'Grafikkarte-Auslastung über die 3D-Engine',
      checked: settings.gpu !== false,
      onChange: (value) => save({ gpu: value }),
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'RAM',
      desc: 'Belegter Arbeitsspeicher und Gesamtgröße',
      checked: settings.ram !== false,
      onChange: (value) => save({ ram: value }),
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Ping',
      desc: 'Latenz zum Internet (1.1.1.1), im Spiel ist sie meist etwas niedriger',
      checked: settings.ping !== false,
      onChange: (value) => save({ ping: value }),
    }),
  );
  wrap.appendChild(toggles);

  const preview = h(`
    <div class="field" style="margin-top:16px">
      <label>Vorschau</label>
      <div class="perf-preview"><div class="pp-card" id="perf-live"></div></div>
    </div>
  `);
  wrap.appendChild(preview);
  perfPreview(preview.querySelector('#perf-live'), data);

  const presets = h(`
    <div class="field">
      <label>Position</label>
      <div id="perf-presets" style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px"></div>
    </div>
  `);
  const presetHost = presets.querySelector('#perf-presets');
  const spots = [
    ['tl', '↖ Oben links'],
    ['tc', '↑ Oben mitte'],
    ['tr', '↗ Oben rechts'],
    ['ml', '← Mitte links'],
    ['mc', '• Mitte'],
    ['mr', '→ Mitte rechts'],
    ['bl', '↙ Unten links'],
    ['bc', '↓ Unten mitte'],
    ['br', '↘ Unten rechts'],
  ];
  for (const [id, label] of spots) {
    const active = (settings.preset || 'tr') === id;
    const button = h(
      `<button class="btn" style="justify-content:center;font-size:11.5px;padding:7px 4px;${active ? 'border-color:rgba(60,232,143,0.65);color:#d8ffe9' : ''}">${label}</button>`,
    );
    button.addEventListener('click', () => save({ preset: id }));
    presetHost.appendChild(button);
  }
  wrap.appendChild(presets);

  wrap.appendChild(
    h(`
      <div class="field">
        <label for="perf-scale">Größe: <b id="perf-scale-value">${Math.round((Number(settings.scale) || 0.45) * 100)} %</b></label>
        <input id="perf-scale" type="range" min="0.35" max="2" step="0.05" value="${Number(settings.scale) || 0.45}" />
      </div>
    `),
  );
  const scaleInput = wrap.querySelector('#perf-scale');
  scaleInput.addEventListener('input', (event) => {
    const label = wrap.querySelector('#perf-scale-value');
    if (label) label.textContent = `${Math.round(Number(event.target.value) * 100)} %`;
  });
  scaleInput.addEventListener('change', (event) => save({ scale: Number(event.target.value) }));

  wrap.appendChild(
    h(`
      <p class="hint">
        Die FPS-Zeile zeigt die Bildwiederholrate deines Monitors – Windows gibt die Bildrate eines Spiels
        nicht ohne Eingriff ins Spiel heraus. Temperaturen erscheinen nur, wenn dein Mainboard sie bereitstellt.
        Klicks gehen durch das Overlay hindurch, es stört also nie beim Zielen.
      </p>
    `),
  );
}

/* ---------------- Audio-Mixer ---------------- */

let audioInfo = null;
let audioLoading = false;

// Regler wirken schon beim Ziehen: der erste Wert geht sofort raus, weitere
// Änderungen ersetzen sich gegenseitig, solange der Aufruf noch läuft. So
// entsteht keine Warteschlange und der Ton folgt dem Finger.
const audioQueue = new Map();

function pushAudio(key, action) {
  const entry = audioQueue.get(key) || { busy: false, next: null };
  entry.next = action;
  audioQueue.set(key, entry);
  if (entry.busy) return;
  const pump = () => {
    const job = entry.next;
    entry.next = null;
    if (!job) {
      entry.busy = false;
      audioQueue.delete(key);
      return;
    }
    entry.busy = true;
    Promise.resolve()
      .then(job)
      .catch(() => {})
      .finally(pump);
  };
  pump();
}

function renderAudio() {
  const wrap = h('<div class="card"><h2>Audio-Mixer</h2><p class="hint">Wird geladen …</p></div>');
  viewEl.appendChild(wrap);
  if (!audioInfo) {
    if (!audioLoading) {
      audioLoading = true;
      window.xh
        .audioList()
        .then((info) => {
          audioInfo = info || { apps: [] };
        })
        .catch(() => {
          audioInfo = { apps: [], error: 'Mixer nicht erreichbar' };
        })
        .finally(() => {
          audioLoading = false;
          if (view === 'audio') renderView();
        });
    }
    return;
  }
  paintAudio(wrap);
}

function paintAudio(wrap) {
  const master = Number(audioInfo?.master) || 0;
  const muted = audioInfo?.muted === true;
  wrap.replaceChildren();
  wrap.appendChild(
    h(`
      <div class="card-head">
        <div><h2>Audio-Mixer</h2><p>Systemlautstärke und jede App einzeln – direkt aus Windows</p></div>
        <button class="btn" id="audio-refresh">Aktualisieren</button>
      </div>
    `),
  );

  const list = h('<div class="list"></div>');

  const masterRow = h(`
    <div class="list-row mixer-row">
      <div class="list-text"><strong>System</strong><span id="master-pct">${Math.round(master * 100)} %</span></div>
      <input type="range" min="0" max="100" value="${Math.round(master * 100)}" id="master-range" />
      <button class="btn ${muted ? 'btn-danger' : ''}" id="master-mute">${muted ? 'Stumm' : 'Ton'}</button>
    </div>
  `);
  const masterRange = masterRow.querySelector('#master-range');
  masterRange.addEventListener('input', () => {
    const pct = Number(masterRange.value);
    const label = masterRow.querySelector('#master-pct');
    if (label) label.textContent = `${pct} %`;
    pushAudio('master', () => window.xh.audioMaster({ volume: pct / 100 }).catch(() => {}));
  });
  const masterMute = masterRow.querySelector('#master-mute');
  masterMute.addEventListener('click', async () => {
    const next = !(audioInfo?.muted === true);
    await window.xh.audioMaster({ mute: next }).catch(() => {});
    audioInfo = { ...(audioInfo || {}), muted: next };
    renderView();
  });
  list.appendChild(masterRow);

  const seen = new Set();
  for (const app of audioInfo?.apps || []) {
    if (!app || seen.has(app.pid)) continue;
    seen.add(app.pid);
    const volume = Math.round((Number(app.volume) || 0) * 100);
    const isMuted = app.muted === true;
    const row = h(`
      <div class="list-row mixer-row">
        <div class="list-text"><strong>${escHtml(app.name || 'App')}</strong><span>${volume} %</span></div>
        <input type="range" min="0" max="100" value="${volume}" />
        <button class="btn ${isMuted ? 'btn-danger' : ''}">${isMuted ? 'Stumm' : 'Ton'}</button>
      </div>
    `);
    const range = row.querySelector('input');
    range.addEventListener('input', () => {
      const pct = Number(range.value);
      const label = row.querySelector('.list-text span');
      if (label) label.textContent = `${pct} %`;
      pushAudio(`app-${app.pid}`, () =>
        window.xh.audioApp({ pid: app.pid, volume: pct / 100 }).catch(() => {}),
      );
    });
    const muteButton = row.querySelector('button');
    muteButton.addEventListener('click', async () => {
      const next = !isMuted;
      await window.xh.audioApp({ pid: app.pid, mute: next }).catch(() => {});
      app.muted = next;
      renderView();
    });
    list.appendChild(row);
  }

  if (seen.size === 0) {
    list.appendChild(h('<div class="empty">Gerade spielt keine App Ton ab.</div>'));
  }
  wrap.appendChild(list);

  wrap.appendChild(
    h(`
      <p class="hint">
        ${audioInfo?.error ? `Hinweis: ${escHtml(audioInfo.error)}<br />` : ''}
        Die Liste zeigt alle Apps, die gerade Audio ausgeben. Neue Apps erscheinen nach „Aktualisieren“.
      </p>
    `),
  );

  wrap.querySelector('#audio-refresh').addEventListener('click', async () => {
    audioInfo = await window.xh.audioList().catch(() => ({ apps: [] }));
    renderView();
  });
}

/* ---------------- Quick Notes ---------------- */

let notesList = null;
let notesSaveTimer = null;

function queueNotesSave() {
  clearTimeout(notesSaveTimer);
  notesSaveTimer = setTimeout(() => {
    if (!Array.isArray(notesList)) return;
    window.xh.notesSave(notesList).catch(() => {});
  }, 450);
}

function renderNotes() {
  const wrap = h(`
    <div class="card">
      <div class="card-head">
        <div><h2>Quick Notes</h2><p>Callouts, Builds, Ideen – alles an einer Stelle</p></div>
        <button class="btn btn-primary" id="note-add">Neue Notiz</button>
      </div>
      <div class="notes" id="notes-list"></div>
      <p class="hint">Wird automatisch gespeichert und bleibt lokal auf deinem PC.</p>
    </div>
  `);
  viewEl.appendChild(wrap);
  const host = wrap.querySelector('#notes-list');

  const paint = () => {
    host.replaceChildren();
    if (!Array.isArray(notesList) || notesList.length === 0) {
      host.appendChild(h('<div class="empty">Noch keine Notiz. Leg oben eine an.</div>'));
      return;
    }
    for (const note of notesList) {
      const at = new Date(note.at);
      const card = h(`
        <div class="note-card">
          <div class="note-head">
            <span>${at.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' })} · ${at.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}</span>
            <button class="btn btn-danger" data-del="${note.id}">Löschen</button>
          </div>
          <textarea maxlength="4000" placeholder="Schreib los …"></textarea>
        </div>
      `);
      const area = card.querySelector('textarea');
      area.value = note.text || '';
      area.addEventListener('input', () => {
        note.text = area.value;
        queueNotesSave();
      });
      card.querySelector('[data-del]').addEventListener('click', () => {
        notesList = notesList.filter((entry) => entry.id !== note.id);
        paint();
        queueNotesSave();
      });
      host.appendChild(card);
    }
  };

  wrap.querySelector('#note-add').addEventListener('click', () => {
    if (!Array.isArray(notesList)) notesList = [];
    notesList.unshift({ id: `${Date.now().toString(36)}`, text: '', at: Date.now() });
    paint();
    queueNotesSave();
    const first = host.querySelector('textarea');
    if (first) first.focus();
  });

  if (Array.isArray(notesList)) {
    paint();
    return;
  }
  window.xh
    .notesGet()
    .then((list) => {
      notesList = Array.isArray(list) ? list : [];
      if (view === 'notes') renderView();
    })
    .catch(() => {
      notesList = [];
    });
}

/* ---------------- Bildschirmzeit ---------------- */

function durationText(seconds) {
  const value = Math.max(0, Math.round(Number(seconds) || 0));
  if (value < 60) return '0 min';
  if (value < 3600) return `${Math.round(value / 60)} min`;
  return `${Math.floor(value / 3600)} h ${Math.round((value % 3600) / 60)} min`;
}

function dayLabel(key) {
  const date = new Date(`${key}T12:00:00`);
  const names = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
  const pad = (value) => String(value).padStart(2, '0');
  const stamp = `${names[date.getDay()]}, ${pad(date.getDate())}.${pad(date.getMonth() + 1)}.`;
  const now = new Date();
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.toDateString() === now.toDateString()) return `Heute · ${stamp}`;
  if (date.toDateString() === yesterday.toDateString()) return `Gestern · ${stamp}`;
  return stamp;
}

async function renderScreentime() {
  const wrap = h('<div class="card"><h2>Bildschirmzeit</h2><p class="hint">Wird geladen …</p></div>');
  viewEl.appendChild(wrap);
  let data = null;
  try {
    data = await window.xh.screenTime();
  } catch {
    data = null;
  }
  if (view !== 'screentime') return;
  if (!data) {
    wrap.replaceChildren(h('<p class="note">Bildschirmzeit ist gerade nicht verfügbar.</p>'));
    return;
  }

  const days = Array.isArray(data.days) ? data.days : [];
  const history = Array.isArray(data.history) ? data.history : [];
  const all = [...history, ...days];
  const max = Math.max(1, ...all.map((day) => Number(day.seconds) || 0));
  const labels = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
  const shareOf = (day) => {
    const value = Number(day.seconds) || 0;
    return value > 0 ? Math.round(((Number(day.game) || 0) / value) * 100) : 0;
  };

  wrap.replaceChildren();
  wrap.appendChild(
    h(`
      <div class="card-head">
        <div><h2>Bildschirmzeit</h2><p>Gemessen, solange Revulution Gaming Hub läuft</p></div>
        <span class="tag green">Heute ${durationText(data.today)}</span>
      </div>
      <div class="stat-grid">
        <div class="stat"><span>Heute</span><strong>${durationText(data.today)}</strong></div>
        <div class="stat"><span>Davon im Spiel</span><strong>${durationText(data.todayGame)}</strong></div>
        <div class="stat"><span>Im Schnitt pro Tag</span><strong>${durationText(data.average)}</strong></div>
        <div class="stat"><span>Seit dem ersten Start</span><strong>${durationText(data.allTime)}</strong></div>
      </div>
    `),
  );

  const bars = h('<div class="st-bars"></div>');
  for (const day of days) {
    const date = new Date(`${day.key}T12:00:00`);
    const height = Math.max(2, Math.round(((Number(day.seconds) || 0) / max) * 100));
    bars.appendChild(
      h(`
        <div class="st-bar" title="${durationText(day.seconds)} · Spiel ${durationText(day.game)} · ${shareOf(day)} % im Spiel">
          <b>${Math.round((Number(day.seconds) || 0) / 360) / 10}h</b>
          <i style="height:${height}%"></i>
          <span>${labels[date.getDay()]}</span>
        </div>
      `),
    );
  }
  wrap.appendChild(bars);

  // Verlauf: zwei Wochen mit Datum, Spielzeit und Anteil – nicht nur Balken.
  const historyBox = h('<div style="margin-top:18px"></div>');
  historyBox.appendChild(h('<h3 class="section">Verlauf</h3>'));
  for (const day of [...all].reverse()) {
    historyBox.appendChild(
      h(`
        <div class="clip-row">
          <span class="grow">${dayLabel(day.key)}</span>
          <span class="meta">${shareOf(day)} % im Spiel</span>
          <span class="meta">Spiel ${durationText(day.game)}</span>
          <strong>${durationText(day.seconds)}</strong>
        </div>
      `),
    );
  }
  wrap.appendChild(historyBox);

  const tracked = Number(data.trackedDays) || 0;
  const best = data.best;
  wrap.appendChild(
    h(
      `<p class="hint">${
        best ? `Bester Tag: ${dayLabel(best.key)} mit ${durationText(best.seconds)}. ` : ''
      }Daten für ${tracked} ${tracked === 1 ? 'Tag' : 'Tage'} aufgezeichnet. Die Zeit zählt nur, während die App geöffnet ist – ein systemweiter Bildschirm-Tracker bräuchte Zugriff auf alle Windows-Sitzungen.</p>`,
    ),
  );
}

/* ---------------- Navigation ---------------- */

let musicInfo = null;

/* ---------------- Truhen-Zähler ---------------- */

let chestInfo = null;
let chestPromptAt = 0;
let chestLastText = '';

function renderChests() {
  const wrap = h('<div class="chest-page"><div class="card"><p class="hint">Wird geladen …</p></div></div>');
  viewEl.appendChild(wrap);
  if (!chestInfo) {
    window.xh
      .chestsGet()
      .then((info) => {
        chestInfo = info;
        if (view === 'chests') renderView();
      })
      .catch(() => showToast('Truhen-Zähler nicht erreichbar'));
    return;
  }
  paintChests(wrap);
}

function chestStatusText() {
  const settings = chestInfo?.settings || {};
  if (!settings.enabled) return { cls: '', text: 'Zähler ist aus' };
  if (!meta?.fortniteRunning && !window.__fortniteRunning) return { cls: '', text: 'Wartet auf Fortnite' };
  if (Date.now() - chestPromptAt < 1500) return { cls: 'gold', text: 'Truhe im Blick' };
  if (!window.ChestScan?.active()) return { cls: '', text: 'Bild wird verbunden …' };
  return { cls: 'green', text: 'Erkennung läuft' };
}

function paintChests(wrap) {
  const info = chestInfo;
  const settings = info.settings || {};
  const on = settings.enabled !== false;
  wrap.replaceChildren();

  const hero = h(`
    <div class="card chest-hero">
      <div class="chest-hero-art"><svg viewBox="0 0 64 64" id="chest-art">${window.CHEST_ART('page')}</svg></div>
      <div class="chest-hero-nums">
        <div><span>Truhen insgesamt</span><strong id="chest-total">${info.allTime}</strong></div>
        <div><span>Heute</span><strong id="chest-today">${info.today || 0}</strong></div>
      </div>
      <div class="chest-hero-side">
        <span class="tag" id="chest-status"></span>
        <div class="chest-adjust">
          <button class="btn" data-chest="minus" title="Gesamt um 1 verringern">−1</button>
          <button class="btn" data-chest="plus" title="Gesamt um 1 erhöhen">+1</button>
        </div>
      </div>
      <div class="chest-diag" id="chest-diag">Wartet auf „Durchsuchen“ neben dem Fadenkreuz …</div>
    </div>
  `);
  wrap.appendChild(hero);

  wrap.appendChild(
    h(`
      <div class="card">
        <div class="stat-grid">
          <div class="stat"><span>Gesamt</span><strong data-chest-live="allTime">${info.allTime}</strong></div>
          <div class="stat"><span>Heute</span><strong data-chest-live="today">${info.today || 0}</strong></div>
          <div class="stat"><span>Letzte Truhe</span><strong data-chest-live="last">${info.lastOpenAt ? new Date(info.lastOpenAt).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '–'}</strong></div>
        </div>
      </div>
    `),
  );

  const settingsCard = h(`
    <div class="card">
      <div class="card-head"><div><h2>Zähler & Overlay</h2><p>Erkennt den Truhen-Hinweis neben dem Fadenkreuz und deine Interaktionstaste</p></div>
      <span class="tag ${on ? 'green' : ''}">${on ? 'an' : 'aus'}</span></div>
    </div>
  `);
  const set = async (patch, rerender = true) => {
    chestInfo = await window.xh.chestsSet(patch);
    if (rerender) renderView();
  };
  settingsCard.appendChild(toggleRow({ title: 'Truhen zählen', desc: 'Jede geöffnete Truhe zählt sofort mit', checked: on, onChange: (v) => set({ enabled: v }) }));
  settingsCard.appendChild(toggleRow({ title: 'Overlay im Spiel', desc: 'Kleine Karte mit Truhe und Gesamtzahl – blendet sich mit Fortnite ein', checked: settings.overlay !== false, onChange: (v) => set({ overlay: v }) }));
  settingsCard.appendChild(toggleRow({ title: 'Ton', desc: 'Kurzer Glitzer-Ton bei jeder Truhe', checked: settings.sound === true, onChange: (v) => set({ sound: v }) }));

  const keys = (info.keys || []).filter((k) => !k.startsWith('pad-'));
  const pads = (info.keys || []).filter((k) => k.startsWith('pad-'));
  const scale = Number(settings.scale) || 1;
  settingsCard.appendChild(
    h(`
      <div class="chest-options">
      <div class="field chest-keys">
        <div><label>Interaktionstaste (Tastatur)</label>
          <select class="select" id="chest-key">${keys.map((k) => `<option value="${k}" ${k === settings.key ? 'selected' : ''}>${{ M3: 'Mausrad-Klick', M4: 'Maus 4', M5: 'Maus 5', WheelDown: 'Mausrad runter', WheelUp: 'Mausrad hoch' }[k] || k}</option>`).join('')}</select></div>
        <div><label>Controller</label>
          <select class="select" id="chest-pad">${pads.map((k) => `<option value="${k}" ${k === settings.pad ? 'selected' : ''}>${k.replace('pad-', '')} (Xbox)</option>`).join('')}</select></div>
      </div>
      <div class="field">
        <label for="chest-scale">Größe: <b id="chest-scale-value">${Math.round(scale * 100)} %</b></label>
        <input id="chest-scale" type="range" min="0.6" max="2" step="0.05" value="${scale}" />
      </div>
      <div class="field">
        <label>Position im Spiel</label>
        <div class="chest-presets">
          ${[
            ['tl', '↖ Oben links'],
            ['tc', '↑ Oben mitte'],
            ['tr', '↗ Oben rechts'],
            ['ml', '← Mitte links'],
            ['', ''],
            ['mr', '→ Mitte rechts'],
            ['bl', '↙ Unten links'],
            ['bc', '↓ Unten mitte'],
            ['br', '↘ Unten rechts'],
          ]
            .map(([id, text]) => (id ? `<button class="btn ${id === settings.preset ? 'is-picked' : ''}" data-chest-preset="${id}">${text}</button>` : '<span></span>'))
            .join('')}
        </div>
      </div>
      <div class="row-actions">
        <button class="btn btn-primary" data-chest="test-open">Truhe testen</button>
        <button class="btn" data-chest="preview">Overlay zeigen</button>
      </div>
      <p class="hint">Tests zeigen nur die Animation – deine Zahlen bleiben unverändert. Gezählt wird, wenn „Durchsuchen“ neben dem Fadenkreuz steht, daneben goldene Truhenfarbe ist (Munitionskisten zählen nicht), du die Taste drückst und der Hinweis verschwindet.</p>
      </div>
    `),
  );
  wrap.appendChild(settingsCard);

  wrap.appendChild(
    h(`
      <div class="card chest-danger">
        <div class="card-head"><div><h2>Gesamtzähler zurücksetzen</h2><p>Setzt Gesamt und Heute auf 0. Zur Sicherheit mit deinem Fortnite-Namen bestätigen.</p></div></div>
        <div class="chest-reset">
          <input type="text" id="chest-ign" placeholder="Dein Fortnite-Name (IGN)" autocomplete="off" spellcheck="false" />
          <button class="btn btn-danger" data-chest="reset" disabled>Zurücksetzen</button>
        </div>
      </div>
    `),
  );

  const ign = wrap.querySelector('#chest-ign');
  const resetBtn = wrap.querySelector('[data-chest="reset"]');
  ign.addEventListener('input', () => {
    resetBtn.disabled = ign.value.trim().length < 3;
  });

  wrap.querySelector('#chest-key').addEventListener('change', (e) => set({ key: e.target.value }, false));
  wrap.querySelector('#chest-pad').addEventListener('change', (e) => set({ pad: e.target.value }, false));
  const scaleInput = wrap.querySelector('#chest-scale');
  scaleInput.addEventListener('input', () => {
    wrap.querySelector('#chest-scale-value').textContent = `${Math.round(Number(scaleInput.value) * 100)} %`;
  });
  scaleInput.addEventListener('change', () => set({ scale: Number(scaleInput.value) }, false));

  wrap.addEventListener('click', async (event) => {
    const presetBtn = event.target.closest('[data-chest-preset]');
    if (presetBtn) return set({ preset: presetBtn.dataset.chestPreset });
    const btn = event.target.closest('[data-chest]');
    if (!btn) return;
    const act = btn.dataset.chest;
    if (act === 'plus') chestInfo = await window.xh.chestsAdjust(1);
    else if (act === 'minus') chestInfo = await window.xh.chestsAdjust(-1);
    else if (act === 'test-open') window.xh.chestsTest();
    else if (act === 'preview') window.xh.chestsPreview();
    else if (act === 'reset') {
      const result = await window.xh.chestsReset(ign.value);
      if (!result?.ok) {
        showToast(result?.reason || 'Nicht zurückgesetzt');
        ign.classList.add('shake');
        setTimeout(() => ign.classList.remove('shake'), 500);
        return;
      }
      chestInfo = result;
      showToast('Truhen-Zähler zurückgesetzt');
      renderView();
      return;
    }
    updateChestLive();
  });

  updateChestLive();
}

/** Zahlen und Status auf der Seite ohne Neuaufbau aktualisieren. */
function updateChestLive(event) {
  if (view !== 'chests' || !chestInfo) return;
  const today = document.getElementById('chest-today');
  const total = document.getElementById('chest-total');
  const status = document.getElementById('chest-status');
  if (today) today.textContent = String(chestInfo.today || 0);
  for (const el of document.querySelectorAll('[data-chest-live]')) {
    const k = el.dataset.chestLive;
    el.textContent = k === 'last'
      ? (chestInfo.lastOpenAt ? new Date(chestInfo.lastOpenAt).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '–')
      : String(chestInfo[k] || 0);
  }
  if (total && total.textContent !== String(chestInfo.allTime)) {
    total.textContent = String(chestInfo.allTime);
    total.classList.remove('pop');
    void total.offsetWidth;
    total.classList.add('pop');
  }
  if (event?.type === 'open') {
    const art = document.querySelector('.chest-hero-art');
    art?.classList.remove('open');
    void art?.offsetWidth;
    art?.classList.add('open');
  }
  if (status) {
    const s = chestStatusText();
    status.className = `tag ${s.cls}`;
    status.textContent = s.text;
  }
}

window.xh.onChests?.((state) => {
  if (!state) return;
  if (state.event?.type === 'prompt' && state.event.visible) chestPromptAt = Date.now();
  if (state.event?.test) return; // Test-Animationen ändern die echten Zahlen nicht
  const structural = state.event?.type === 'reset';
  chestInfo = state;
  if (view !== 'chests') return;
  if (structural) renderView();
  else updateChestLive(state.event);
});
window.xh.onGame?.((status) => {
  window.__fortniteRunning = Boolean(status?.running);
  updateChestLive();
});
// Was die Erkennung gerade liest – zum Prüfen, ob der Truhen-Hinweis ankommt.
let chestKeyAt = 0;
window.xh.onInput?.((payload) => {
  const key = chestInfo?.settings?.key;
  const wheel = ['M3', 'WheelDown', 'WheelUp'];
  const watch = wheel.includes(key) ? wheel : [key];
  if (key && payload?.keys?.some((k) => watch.includes(k))) chestKeyAt = Date.now();
});
window.ChestScan?.onResult((kind, result) => {
  if (kind !== 'prompt' || view !== 'chests') return;
  const diag = document.getElementById('chest-diag');
  if (!diag) return;
  const keyHint = Date.now() - chestKeyAt < 1500 ? ' · Taste erkannt' : '';
  const goldText = `Gold ${(((result?.gold) || 0) * 100).toFixed(1).replace('.', ',')} %`;
  let line = 'Kein „Durchsuchen“ im Blick';
  if (result?.chest) line = `Truhe im Blick ✓ · ${goldText}`;
  else if (result?.search) line = `„Durchsuchen“ gelesen · ${goldText} → keine Truhe`;
  diag.textContent = line + keyHint;
  diag.classList.toggle('hit', Boolean(result?.chest));
});
setInterval(() => updateChestLive(), 1000);

function renderMusic() {
  const wrap = h('<div class="card"><h2>Musik-Overlay</h2><p class="hint">Wird geladen …</p></div>');
  viewEl.appendChild(wrap);
  if (!musicInfo) {
    window.xh
      .musicGet()
      .then((info) => {
        musicInfo = info;
        renderView();
      })
      .catch(() => showToast('Musik-Overlay nicht erreichbar'));
    return;
  }
  paintMusic(wrap);
}

function paintMusic(wrap) {
  const settings = musicInfo?.settings || {};
  const state = musicInfo?.state || {};
  const scale = Number(settings.scale) || 1;
  const enabled = settings.enabled !== false;

  wrap.replaceChildren();
  const head = h(`
    <div class="card-head">
      <div>
        <h2>Musik-Overlay</h2>
        <p>Cover, Restzeit und Songtext oben am Bildschirm</p>
      </div>
      <span class="tag ${enabled ? 'green' : ''}">${enabled ? 'an' : 'aus'}</span>
    </div>
  `);
  wrap.appendChild(head);

  const toggles = h('<div id="music-toggles"></div>');
  toggles.appendChild(
    toggleRow({
      title: 'Overlay anzeigen',
      desc: 'Blendet die Karte ein, sobald auf dem PC Musik läuft',
      checked: enabled,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ enabled: value });
        renderView();
      },
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Songtext',
      desc: 'Aktuelle Zeile läuft mit und füllt sich beim Singen',
      checked: settings.lyrics !== false,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ lyrics: value });
        renderView();
      },
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Plattenspieler',
      desc: 'Cover dreht statt als Kachel wie eine Schallplatte',
      checked: settings.vinyl === true,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ vinyl: value });
        renderView();
      },
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Tonarm',
      desc: 'Nadel liegt auf der Platte und wandert mit dem Song nach innen',
      checked: settings.arm !== false,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ arm: value });
        renderView();
      },
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Platten-Knistern',
      desc: 'Leises Vinyl-Knistern, solange Musik läuft',
      checked: settings.crackle === true,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ crackle: value });
        renderView();
      },
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Titel & Interpret',
      desc: 'Songname und Künstler unter dem Cover',
      checked: settings.title !== false,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ title: value });
        renderView();
      },
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Fortschritt & Zeiten',
      desc: 'Balken mit Laufzeit und Restzeit',
      checked: settings.progress !== false,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ progress: value });
        renderView();
      },
    }),
  );
  toggles.appendChild(
    toggleRow({
      title: 'Nur Schallplatte',
      desc: 'Zeigt ausschließlich den runden Kreis – ohne Karte, Text und Balken',
      checked: settings.vinylOnly === true,
      onChange: async (value) => {
        musicInfo = await window.xh.musicSet({ vinylOnly: value, vinyl: value || settings.vinyl });
        renderView();
      },
    }),
  );
  wrap.appendChild(toggles);

  wrap.appendChild(
    h(`
      <div class="field">
        <label for="music-scale">Größe: <b id="music-scale-value">${Math.round(scale * 100)} %</b></label>
        <input id="music-scale" type="range" min="0.6" max="2" step="0.05" value="${scale}" />
      </div>
    `),
  );
  wrap.appendChild(
    h(`
      <div class="field" ${settings.crackle === true ? '' : 'style="opacity:.5"'}>
        <label for="music-crackle">Knistern-Lautstärke: <b id="music-crackle-value">${Math.round(Number(settings.crackleVolume ?? 40))} %</b></label>
        <input id="music-crackle" type="range" min="0" max="100" step="5" value="${Math.round(Number(settings.crackleVolume ?? 40))}" ${settings.crackle === true ? '' : 'disabled'} />
      </div>
    `),
  );

  // Das Overlay sitzt im Arbeitsbereich (ohne Taskleiste) – das Feld soll
  // dieselbe Fläche zeigen, sonst landet die Karte tiefer als der Punkt.
  const screenWidth = window.screen?.availWidth || 1920;
  const screenHeight = window.screen?.availHeight || 1080;
  const preset = settings.preset || 'tl';
  const fx = settings.x === null || settings.x === undefined ? 0.09 : Math.min(1, Math.max(0, Number(settings.x) / screenWidth));
  const fy = settings.y === null || settings.y === undefined ? 0.1 : Math.min(1, Math.max(0, Number(settings.y) / screenHeight));

  const spots = {
    tl: [0.09, 0.12],
    tc: [0.5, 0.12],
    tr: [0.91, 0.12],
    ml: [0.09, 0.5],
    mc: [0.5, 0.5],
    mr: [0.91, 0.5],
    bl: [0.09, 0.88],
    bc: [0.5, 0.88],
    br: [0.91, 0.88],
  };
  const presetList = [
    ['tl', '↖ Oben links'],
    ['tc', '↑ Oben mitte'],
    ['tr', '↗ Oben rechts'],
    ['ml', '← Mitte links'],
    ['mc', '• Mitte'],
    ['mr', '→ Mitte rechts'],
    ['bl', '↙ Unten links'],
    ['bc', '↓ Unten mitte'],
    ['br', '↘ Unten rechts'],
  ];
  wrap.appendChild(
    h(`
      <div class="field">
        <label>Position – Ecke wählen oder unten frei ziehen</label>
        <div id="music-presets" style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">
          ${presetList
            .map(
              ([id, text]) =>
                `<button class="btn" data-preset="${id}" style="justify-content:center;font-size:11.5px;padding:7px 4px;${id === preset ? 'border-color:rgba(60,232,143,0.65);color:#d8ffe9' : ''}">${text}</button>`,
            )
            .join('')}
        </div>
      </div>
    `),
  );

  const stage = h(`
    <div class="field">
      <label>Frei verschieben – Karte im Feld ziehen</label>
      <div id="music-stage" style="position:relative;height:150px;border-radius:12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.12);overflow:hidden;touch-action:none;cursor:grab">
        <div id="music-dot" style="position:absolute;transform:translate(-50%,-50%);padding:5px 10px;border-radius:9px;background:rgba(10,12,18,0.92);border:1px solid rgba(60,232,143,0.6);font-size:11px;white-space:nowrap;pointer-events:none">♪ Overlay</div>
      </div>
    </div>
  `);
  wrap.appendChild(stage);

  const actions = h(`
    <div class="row-actions" style="margin-top:4px">
      <button class="btn btn-primary" id="music-demo">Vorschau zeigen</button>
    </div>
    <p class="hint">
      ${state?.title ? `Läuft gerade: <strong>${escHtml(state.title)}</strong>${state.artist ? ` – ${escHtml(state.artist)}` : ''}` : 'Gerade läuft keine Musik.'}
    </p>
  `);
  wrap.appendChild(actions);

  const dot = stage.querySelector('#music-dot');
  const box = stage.querySelector('#music-stage');
  // Die Karte ist nicht der Punkt: gespeichert wird die linke obere Ecke, im
  // Feld zeigt der Punkt aber die Mitte der Karte. Beides wird hier umgerechnet,
  // damit die Karte genau dort landet, wo sie im Feld zu sehen ist.
  // Im Kreis-Modus ist das Overlay ein Quadrat um die Platte: dann muss die
  // Zieh-Rechnung mit dieser kleineren Fläche arbeiten, sonst bleibt der Kreis
  // vor der Ecke stehen. Größe und Modus kommen live aus den Einstellungen.
  const cardSize = () => {
    const now = (musicInfo && musicInfo.settings) || settings;
    const factor = Number(now.scale) || scale;
    const circle = now.vinylOnly === true;
    return {
      w: Math.round((circle ? 140 : 380) * factor),
      h: Math.round((circle ? 140 : 118) * factor),
    };
  };
  const clamp = (value, low, high) => Math.min(high, Math.max(low, value));
  const posFromCenter = (centerX, centerY) => {
    const { w, h } = cardSize();
    return {
      x: Math.round(clamp(centerX - w / 2, 0, Math.max(0, screenWidth - w))),
      y: Math.round(clamp(centerY - h / 2, 0, Math.max(0, screenHeight - h))),
    };
  };
  const posFromSpot = (px, py) => posFromCenter(px * screenWidth, py * screenHeight);
  const drawDot = (position) => {
    const { w, h } = cardSize();
    dot.style.left = `${clamp(((position.x + w / 2) / screenWidth) * 100, 4, 96)}%`;
    dot.style.top = `${clamp(((position.y + h / 2) / screenHeight) * 100, 6, 94)}%`;
  };
  const startPos = (() => {
    const { w, h } = cardSize();
    return preset === 'free' && Number.isFinite(Number(settings.x)) && Number.isFinite(Number(settings.y))
      ? posFromCenter(Number(settings.x) + w / 2, Number(settings.y) + h / 2)
      : posFromSpot(...(spots[preset] || [fx, fy]));
  })();
  let current = startPos;
  requestAnimationFrame(() => drawDot(current));

  // Ziehen liegt auf dem ganzen Feld (nicht auf dem Punkt), hält den Abstand
  // zwischen Maus und Kartenmitte fest und zeichnet nur ein Mal pro Frame.
  let dragging = false;
  let frame = 0;
  let grabDX = 0;
  let grabDY = 0;
  let moved = false;
  let lastPreview = 0;
  const pointerAbs = (event) => {
    const rect = box.getBoundingClientRect();
    return {
      x: clamp((event.clientX - rect.left) / rect.width, 0, 1) * screenWidth,
      y: clamp((event.clientY - rect.top) / rect.height, 0, 1) * screenHeight,
    };
  };
  const preview = (position) => {
    const now = performance.now();
    // Höchstens alle 60 ms: das Overlay soll live folgen, ohne zu flackern.
    if (now - lastPreview < 60) return;
    lastPreview = now;
    window.xh.musicPreview?.({ x: position.x, y: position.y });
  };
  box.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    dragging = true;
    moved = false;
    box.setPointerCapture(event.pointerId);
    box.style.cursor = 'grabbing';
    const pointer = pointerAbs(event);
    const { w, h } = cardSize();
    grabDX = pointer.x - (current.x + w / 2);
    grabDY = pointer.y - (current.y + h / 2);
  });
  box.addEventListener('pointermove', (event) => {
    if (!dragging) return;
    const pointer = pointerAbs(event);
    const position = posFromCenter(pointer.x - grabDX, pointer.y - grabDY);
    if (position.x === current.x && position.y === current.y) return;
    current = position;
    moved = true;
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      drawDot(current);
      preview(current);
    });
  });
  const dropDot = async (event) => {
    if (!dragging) return;
    dragging = false;
    box.style.cursor = 'grab';
    if (box.hasPointerCapture(event.pointerId)) box.releasePointerCapture(event.pointerId);
    if (frame) {
      cancelAnimationFrame(frame);
      frame = 0;
    }
    if (!moved) return;
    drawDot(current);
    wrap.querySelectorAll('[data-preset]').forEach((button) => {
      button.style.borderColor = '';
      button.style.color = '';
    });
    musicInfo = await window.xh.musicSet({ preset: 'free', x: current.x, y: current.y });
    showToast('Position gespeichert');
  };
  box.addEventListener('pointerup', dropDot);
  box.addEventListener('pointercancel', dropDot);

  wrap.querySelectorAll('[data-preset]').forEach((button) => {
    button.addEventListener('click', async () => {
      musicInfo = await window.xh.musicSet({ preset: button.dataset.preset });
      renderView();
    });
  });

  wrap.querySelector('#music-crackle')?.addEventListener('input', (event) => {
    const label = wrap.querySelector('#music-crackle-value');
    if (label) label.textContent = `${event.target.value} %`;
  });
  wrap.querySelector('#music-crackle')?.addEventListener('change', async (event) => {
    musicInfo = await window.xh.musicSet({ crackleVolume: Number(event.target.value) });
  });
  wrap.querySelector('#music-scale').addEventListener('input', (event) => {
    const label = wrap.querySelector('#music-scale-value');
    if (label) label.textContent = `${Math.round(Number(event.target.value) * 100)} %`;
  });
  wrap.querySelector('#music-scale').addEventListener('change', async (event) => {
    musicInfo = await window.xh.musicSet({ scale: Number(event.target.value) });
    renderView();
  });

  wrap.querySelector('#music-demo').addEventListener('click', async () => {
    musicInfo = await window.xh.musicDemo();
    showToast('Vorschau läuft – Musik-Overlay sollte oben erscheinen');
    renderView();
  });
}

function setView(next) {
  view = next;
  document.querySelectorAll('.nav-item').forEach((item) => {
    item.classList.toggle('is-active', item.dataset.view === next);
  });
  renderView();
  viewEl.scrollTop = 0;
}

document.querySelectorAll('.nav-item').forEach((item) => {
  item.addEventListener('click', () => setView(item.dataset.view));
});

powerBtn.addEventListener('click', async () => {
  const next = await window.xh.toggle();
  app = next.app;
  meta = next.meta;
  applyWallpaper();
  renderView();
  showToast(app.enabled ? 'Crosshair ist an – bleibt an' : 'Crosshair ist aus');
});

document.getElementById('win-min').addEventListener('click', () => window.xh.minimize());
document.getElementById('win-close').addEventListener('click', () => window.xh.closeWindow());

document.getElementById('btn-test').addEventListener('click', async () => {
  await window.xh.preview(8000);
  showToast('Crosshair wird 8 Sekunden im Overlay gezeigt');
});

document.getElementById('btn-focus').addEventListener('click', async () => {
  const next = !app.focusMode;
  await patchApp({ focusMode: next });
  renderView();
  showToast(
    next
      ? 'Fokus-Modus an – keine Hinweise, Windows-Benachrichtigungen stumm'
      : 'Fokus-Modus aus – Hinweise wieder aktiv',
  );
});

document.addEventListener('mouseup', () => {
  painting = false;
  erasing = false;
});

document.addEventListener('click', async (event) => {
  const node = event.target.closest('[data-action]');
  if (!node || !window.ClipUI || !node.closest('#clip-host')) return;
  if (await window.ClipUI.handleAction(node.dataset.action, node)) {
    event.preventDefault();
  }
});

if (window.xh?.onClipTrigger) {
  window.xh.onClipTrigger(async (payload) => {
    if (!window.ClipUI) return;
    if (window.ClipUI.isRecording()) {
      window.ClipUI.save();
      return;
    }
    // Kein Spiel offen: Schnellclip vom gewählten Monitor.
    ensureClipUI();
    showToast('Schnellclip vom Monitor …');
    await window.ClipUI.ensureSources();
    await window.ClipUI.start();
    setTimeout(() => {
      if (window.ClipUI?.isRecording()) window.ClipUI.save();
    }, 4500);
  });
}

// Der Puffer lebt nach dem Spielende weiter: der Replay-Scan startet erst ein
// paar Sekunden später und schreibt Sieg-/Match-Clips daraus.
let clipStopTimer = null;

if (window.xh?.onAutoGame) {
  window.xh.onAutoGame(async (payload) => {
    if (!meta?.clip?.settings?.clipAutoGame) return;
    ensureClipUI();
    if (!window.ClipUI) return;
    if (payload?.start) {
      clearTimeout(clipStopTimer);
      clipStopTimer = null;
      await window.ClipUI.ensureSources();
      await window.ClipUI.autoStart();
      return;
    }
    // Nicht sofort stoppen, sonst ist der Puffer leer, wenn der Sieg-Clip nach
    // dem Match geschrieben wird.
    clearTimeout(clipStopTimer);
    clipStopTimer = setTimeout(() => {
      clipStopTimer = null;
      if (window.ClipUI?.isRecording()) window.ClipUI.stop();
    }, 180000);
  });
}

if (window.xh?.onClipDiag) {
  window.xh.onClipDiag((info) => {
    if (window.ClipUI?.setDiag && info?.text) window.ClipUI.setDiag(info.text);
  });
}

// Neuer Clip (Kill, Sieg, Hotkey): Liste aktualisieren. Im Spiel selbst gibt es
// nur den kleinen Haken oben links – der Hinweis hier bleibt im Hub-Fenster.
if (window.xh?.onClipsChanged) {
  window.xh.onClipsChanged((info) => {
    if (meta?.clip) {
      if (Array.isArray(info?.clips)) meta.clip.clips = info.clips;
      if (info?.usage) meta.clip.usage = info.usage;
    }
    if (view === 'clips' && window.ClipUI && !window.ClipUI.isPlayerOpen?.()) {
      const host = document.getElementById('clip-host');
      if (host) {
        host.innerHTML = window.ClipUI.render();
        window.ClipUI.afterRender?.();
      }
    }
    const saved = info?.saved;
    if (saved) {
      const label = saved.category === 'win' ? 'Sieg-Clip gespeichert' : saved.category === 'kill' ? 'Kill-Clip gespeichert' : 'Clip gespeichert';
      showToast(label);
    }
  });
}

if (window.xh?.onView) {
  window.xh.onView((next) => {
    if (typeof next === 'string') setView(next);
  });
}

if (window.xh?.onInput) {
  window.xh.onInput((payload) => {
    if (window.ClipUI) window.ClipUI.pushKeys(payload?.keys || []);
  });
}

if (window.xh?.onState) {
  window.xh.onState((payload) => {
    if (!payload?.app) return;
    const previousWall = app?.wallpaper;
    app = payload.app;
    meta = payload.meta;
    updateChrome();
    if (previousWall !== app.wallpaper) applyWallpaper();
    if (document.getElementById('stage-mark')) drawStage();
    if (view === 'clips' && window.ClipUI) {
      const host = document.getElementById('clip-host');
      // Nicht neu aufbauen, während jemand in einem Eingabefeld tippt.
      const typing = document.activeElement && host?.contains(document.activeElement) && /INPUT|SELECT/.test(document.activeElement.tagName);
      if (host && !typing) {
        host.innerHTML = window.ClipUI.render();
        window.ClipUI.afterRender?.();
      }
    }
  });
}

if (window.xh?.onMusicState) {
  window.xh.onMusicState((info) => {
    musicInfo = info;
    if (view === 'music') renderView();
  });
}

if (window.xh?.onPerfState) {
  window.xh.onPerfState((info) => {
    perfInfo = info;
    // Nur die Zahlen der Vorschau neu schreiben: ein kompletter Neuaufbau
    // würde den Größenregler unter dem Mauszeiger wegrutschen lassen.
    const host = document.getElementById('perf-live');
    if (host) perfPreview(host, info?.data || {});
  });
}

(async function boot() {
  const initial = await window.xh.get();
  app = initial.app;
  meta = initial.meta;
  updateChrome();
  renderView();
  // Keystrokes früh starten, sonst sind die ersten Clips ohne Tastatur.
  if (meta?.clip?.settings?.clipKeystrokes) window.xh.inputStart().catch(() => {});
})();
