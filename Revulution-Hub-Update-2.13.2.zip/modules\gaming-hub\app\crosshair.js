const HEX = /^#[0-9a-f]{6}$/i;
const PIXEL_GRID = 15;
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const num = (value, fallback, min, max) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? clamp(parsed, min, max) : fallback;
};

const KINDS = new Set([
  'cross',
  'x',
  't',
  'dot',
  'circle',
  'circleDot',
  'brackets',
  'chevron',
  'triangle',
  'square',
  'pixels',
  'image',
]);

/** Animationen, die im Overlay und in der Galerie laufen. */
const ANIMATIONS = new Set([
  'none',
  'pulse',
  'breathe',
  'rainbow',
  'glitch',
  'orbit',
  'spin',
  'flame',
  'spark',
  'neon',
  'comet',
]);

/** Fortnite-Ränge in Spielreihenfolge samt Farbe. */
const RANKS = [
  { id: 'bronze', name: 'Bronze', color: '#c8813f', animation: 'pulse' },
  { id: 'silver', name: 'Silber', color: '#c3ccd8', animation: 'spark' },
  { id: 'gold', name: 'Gold', color: '#ffca3a', animation: 'pulse' },
  { id: 'platinum', name: 'Platin', color: '#5ad2e6', animation: 'comet' },
  { id: 'diamond', name: 'Diamant', color: '#7aa8ff', animation: 'spark' },
  { id: 'elite', name: 'Elite', color: '#a97bff', animation: 'neon' },
  { id: 'champion', name: 'Champion', color: '#ff6b9d', animation: 'glitch' },
  { id: 'unreal', name: 'Unreal', color: '#ff9ff3', animation: 'rainbow' },
];

/** Spielmodi mit eigenem Rang. */
const MODES = [
  { id: 'br', name: 'Battle Royale' },
  { id: 'zeroBuild', name: 'Null Bauen' },
  { id: 'reload', name: 'Reload' },
];

const RANK_IDS = new Set(RANKS.map((rank) => rank.id));

let sequence = 0;
const newId = (prefix = 'p') => `${prefix}-${Date.now().toString(36)}-${(sequence += 1).toString(36)}`;

function emptyPixels() {
  return Array.from({ length: PIXEL_GRID }, () => Array(PIXEL_GRID).fill(''));
}

function normalizePixels(input) {
  const source = Array.isArray(input) ? input : [];
  return Array.from({ length: PIXEL_GRID }, (_, y) =>
    Array.from({ length: PIXEL_GRID }, (_, x) => {
      const value = Array.isArray(source[y]) ? source[y][x] : '';
      return typeof value === 'string' && HEX.test(value) ? value.toLowerCase() : '';
    }),
  );
}

/** Ein Crosshair-Design mit allen Darstellungswerten. */
function normalizeProfile(input = {}, fallbackName = 'Design') {
  if (!input || typeof input !== 'object') input = {};
  const kind = KINDS.has(input.kind) ? input.kind : 'cross';
  return {
    id: typeof input.id === 'string' && input.id.length > 0 ? input.id.slice(0, 48) : newId(),
    name: String(input.name || fallbackName).slice(0, 40) || fallbackName,
    kind,
    builtin: Boolean(input.builtin),
    rank: RANK_IDS.has(input.rank) ? input.rank : '',
    // Auto-Design: Farbe und Animation kommen vom Rang des gewählten Modus.
    autoRank: Boolean(input.autoRank),
    animation: ANIMATIONS.has(input.animation) ? input.animation : 'none',
    color: HEX.test(input.color) ? String(input.color).toLowerCase() : '#3ce88f',
    length: Math.round(num(input.length, 14, 2, 70)),
    thickness: Math.round(num(input.thickness, 3, 1, 16)),
    gap: Math.round(num(input.gap, 5, 0, 40)),
    dot: Math.round(num(input.dot, 0, 0, 16)),
    ring: Math.round(num(input.ring, 12, 0, 70)),
    outline: Math.round(num(input.outline, 1.5, 0, 6) * 4) / 4,
    opacity: Math.round(num(input.opacity, 1, 0.1, 1) * 100) / 100,
    rotation: Math.round(num(input.rotation, 0, -180, 180)),
    // Beim Zielen (rechte Maustaste) rückt das Crosshair enger zusammen.
    // Standard ist bewusst AUS – erst einschalten, wenn man es will.
    aimTighten: input.aimTighten === true,
    blend: input.blend === 'screen' ? 'screen' : 'normal',
    image: typeof input.image === 'string' ? input.image.slice(0, 200) : '',
    imageScale: Math.round(num(input.imageScale, 1, 0.1, 5) * 100) / 100,
    pixelSize: Math.round(num(input.pixelSize, 4, 1, 16)),
    pixels: normalizePixels(input.pixels),
  };
}

/** Ein einziges Rang-Crosshair, das sich dem Rang automatisch anpasst. */
function rankProfiles() {
  const auto = normalizeProfile({
    id: 'rank-auto',
    name: 'Auto (Rangfarbe)',
    builtin: true,
    autoRank: true,
    kind: 'cross',
    color: '#3ce88f',
    length: 15,
    thickness: 3.5,
    gap: 6,
    outline: 2,
    animation: 'pulse',
  });  auto.name = 'Rang-Crosshair';
  return [auto];
}

/** Designs, die beim ersten Start in der Galerie liegen. */
function defaultProfiles() {
  const preset = (id, name, extra) => normalizeProfile({ id, name, builtin: true, ...extra });

  return [
    ...rankProfiles(),
    preset('classic', 'Klassisch', { kind: 'cross', color: '#3ce88f', length: 14, gap: 5, thickness: 3 }),
    preset('neon-pink', 'Neon Pink', { kind: 'cross', color: '#ff3ba7', length: 12, gap: 6, thickness: 3 }),
    preset('cyan-x', 'Cyan X', { kind: 'x', color: '#22d3ee', length: 12, gap: 5, thickness: 3 }),
    preset('white-min', 'Weiß Minimal', { kind: 'cross', color: '#ffffff', length: 9, gap: 4, thickness: 2 }),
    preset('red-dot', 'Roter Punkt', { kind: 'dot', color: '#ff2d55', dot: 3, thickness: 1, outline: 1 }),
    preset('violet-ring', 'Violett Ring', { kind: 'circleDot', color: '#a855f7', ring: 13, dot: 2, thickness: 2 }),
    preset('green-brackets', 'Grüne Klammern', { kind: 'brackets', color: '#22e06a', length: 10, gap: 6, thickness: 2 }),
    preset('amber-chevron', 'Amber Pfeile', { kind: 'chevron', color: '#f59e0b', length: 11, gap: 5, thickness: 2 }),
    preset('blue-triangle', 'Blau Dreieck', { kind: 'triangle', color: '#38bdf8', length: 13, gap: 6, thickness: 2 }),
    preset('pink-square', 'Pink Quadrat', { kind: 'square', color: '#f472b6', length: 11, gap: 5, thickness: 2 }),
    preset('purple-t', 'Lila T', { kind: 't', color: '#c084fc', length: 13, gap: 5, thickness: 3 }),
    preset('classic-dot', 'Klassisch + Punkt', { kind: 'cross', color: '#3ce88f', length: 15, gap: 6, thickness: 3, dot: 2 }),
    preset('cyan-ring', 'Cyan Kreis', { kind: 'circle', color: '#06b6d4', ring: 16, thickness: 2 }),
    preset('white-cross-dark', 'Weiß Kontur', { kind: 'cross', color: '#f8fafc', length: 16, gap: 6, thickness: 2, outline: 2.5 }),
    preset('ice-cross', 'Eis Kreuz', { kind: 'cross', color: '#bfe9ff', length: 18, gap: 7, thickness: 2, outline: 2 }),
    preset('lime-t', 'Limette T', { kind: 't', color: '#a3e635', length: 15, gap: 4, thickness: 3 }),
    preset('magenta-square', 'Magenta Rahmen', { kind: 'square', color: '#ff4dd2', length: 14, gap: 7, thickness: 2, outline: 2 }),
    preset('sunset-triangle', 'Sunset Dreieck', { kind: 'triangle', color: '#ff8a3d', length: 16, gap: 7, thickness: 2 }),
    preset('steel-brackets', 'Stahl Klammern', { kind: 'brackets', color: '#cbd5e1', length: 13, gap: 8, thickness: 3, outline: 2 }),
    preset('violet-chevron', 'Violett Pfeile', { kind: 'chevron', color: '#8b5cf6', length: 14, gap: 6, thickness: 3 }),
    preset('aqua-ring-dot', 'Aqua Ring + Punkt', { kind: 'circleDot', color: '#2dd4bf', ring: 18, dot: 2.5, thickness: 2, outline: 1.5 }),
    preset('crimson-x', 'Crimson X', { kind: 'x', color: '#ef4444', length: 15, gap: 4, thickness: 3, outline: 2 }),
    preset('gold-dot', 'Gold Punkt', { kind: 'dot', color: '#fbbf24', dot: 4, outline: 2 }),
    preset('teal-mini', 'Teal Mini', { kind: 'cross', color: '#14b8a6', length: 8, gap: 3, thickness: 2 }),
    preset('ghost-plus', 'Geist Plus', { kind: 'cross', color: '#e2e8f0', length: 20, gap: 8, thickness: 2, outline: 3 }),
    preset('pulse-ring', 'Puls Ring', { kind: 'circle', color: '#f472b6', ring: 20, thickness: 2, animation: 'breathe' }),
  ];
}

const DEFAULT_HOTKEYS = { toggle: 'F8', cycle: 'F7', bigger: 'F6', smaller: 'F5', music: '' };

/**
 * Es gibt nur einen Rang für alle Spielmodi – man hat überall denselben.
 * Die Modus-Schlüssel bleiben, damit gespeicherte Daten weiter passen.
 */
function normalizeRanks(input) {
  const source = input && typeof input === 'object' ? input : {};
  const single = MODES.map((mode) => source[mode.id]).find((value) => RANK_IDS.has(value)) || '';
  const ranks = {};
  for (const mode of MODES) ranks[mode.id] = single;
  return ranks;
}

const DEFAULT_APP = {
  enabled: true,
  // Solange die App offen ist, ist das Crosshair zu sehen.
  alwaysOn: true,
  activeId: 'classic',
  profiles: [],
  customImages: [],
  displayId: 'auto',
  offsetX: 0,
  offsetY: 0,
  scale: 1,
  onlyInGame: true,
  hideWhenUnfocused: false,
  autoStart: true,
  closeToTray: true,
  clickSound: true,
  captureVisible: true,
  wallpaper: 'live-nebula.mp4',
  // Abdunklung des Live-Hintergrunds in Prozent (0 = klar, 100 = fast schwarz).
  wallShade: 80,
  ranks: normalizeRanks(),
  rankMode: 'br',
  rankAuto: true,
  weaponHotkeys: {},
  hotkeys: { ...DEFAULT_HOTKEYS },
  // Globale Tastenkürzel sind opt-in: erst wenn der Nutzer sie einschaltet,
  // belegt die App F8/F9 und blockiert sie damit in anderen Programmen.
  hotkeysEnabled: false,
  // Fokus-Modus: Hinweise, Popups und Windows-Benachrichtigungen stumm.
  focusMode: false,
};

function normalizeApp(input) {
  const source = input && typeof input === 'object' ? input : {};
  const profiles = Array.isArray(source.profiles) ? source.profiles : [];
  // Erster Start nach dem Update: Crosshair und Autostart einmal auf „an“.
  const freshStart = source.startOnDefault !== true;

  // Eigene Designs behalten, eingebaute Designs aktualisieren.
  // Alte Einzel-Rangdesigns entfallen: es gibt nur noch das eine Rang-Crosshair.
  const byId = new Map();
  for (const profile of profiles) {
    const normalized = normalizeProfile(profile);
    if (normalized.id.startsWith('rank-') && normalized.id !== 'rank-auto') continue;
    byId.set(normalized.id, normalized);
  }
  for (const preset of defaultProfiles()) {
    if (byId.has(preset.id)) {
      const existing = byId.get(preset.id);
      byId.set(preset.id, { ...preset, ...existing, name: existing.name || preset.name, builtin: true });
    } else {
      byId.set(preset.id, preset);
    }
  }

  // Rang-Crosshair zuerst, damit es oben in der Liste steht.
  const rankOrder = new Map([['rank-auto', 0]]);
  const list = [...byId.values()].sort(
    (a, b) => (rankOrder.get(a.id) ?? 99) - (rankOrder.get(b.id) ?? 99),
  );
  // Einmalige Umstellung: „beim Zielen kleiner“ war vorher überall an, ist
  // jetzt standardmäßig aus. Ohne diese Migration würden alte Profile weiter
  // enger springen, obwohl der Schalter aus ist.
  if (source.aimTightenDefault !== true) {
    for (const profile of list) profile.aimTighten = false;
  }

  const activeId = list.some((profile) => profile.id === source.activeId)
    ? source.activeId
    : list[0].id;

  const images = Array.isArray(source.customImages)
    ? source.customImages
        .filter((image) => image && typeof image.file === 'string' && image.file.length > 0)
        .slice(0, 120)
        .map((image) => ({
          id: typeof image.id === 'string' && image.id ? image.id.slice(0, 48) : newId('img'),
          name: String(image.name || image.file).slice(0, 60),
          file: image.file.slice(0, 200),
          added: Number(image.added) || Date.now(),
        }))
    : [];

  const hotkeys = {};
  for (const key of Object.keys(DEFAULT_HOTKEYS)) {
    const value = source.hotkeys?.[key];
    // Fehlt der Eintrag, gilt das Standardkürzel; ein leerer Text schaltet es ab.
    hotkeys[key] = typeof value === 'string' ? value.trim().slice(0, 32) : DEFAULT_HOTKEYS[key];
  }

  // Crosshair pro Waffe: Taste 1–5 -> Design. Nur vorhandene Designs zählen.
  const ids = new Set(list.map((profile) => profile.id));
  const weaponHotkeys = {};
  for (const key of ['1', '2', '3', '4', '5']) {
    const value = source.weaponHotkeys?.[key];
    if (typeof value === 'string' && ids.has(value)) weaponHotkeys[key] = value;
  }
  if (!source.weaponHotkeys || typeof source.weaponHotkeys !== 'object') {
    const fallback = ['classic', 'cyan-x', 'white-min', 'red-dot', 'green-brackets'].filter((id) => ids.has(id));
    fallback.forEach((id, index) => {
      weaponHotkeys[String(index + 1)] = id;
    });
  }

  return {
    // Einmal-Umstellung: Der Wunsch „Crosshair soll immer da sein“ hat
    // Vorrang vor einem alten Aus-Zustand im Profil.
    enabled: freshStart
      ? true
      : typeof source.enabled === 'boolean'
        ? source.enabled
        : DEFAULT_APP.enabled,
    // Einmal-Umstellung: Das Crosshair bleibt sichtbar, solange der Hub offen
    // ist. Erst wenn der Nutzer den Schalter selbst anfasst, zählt seine Wahl.
    alwaysOn: freshStart
      ? true
      : source.alwaysOnDefault === true && typeof source.alwaysOn === 'boolean'
        ? source.alwaysOn
        : DEFAULT_APP.alwaysOn,
    alwaysOnDefault: true,
    startOnDefault: true,
    activeId,
    profiles: list.map((profile) => ({ ...profile, builtin: Boolean(profile.builtin) })),
    customImages: images,
    displayId: typeof source.displayId === 'string' ? source.displayId : 'auto',
    offsetX: Math.round(num(source.offsetX, 0, -4000, 4000)),
    offsetY: Math.round(num(source.offsetY, 0, -4000, 4000)),
    scale: Math.round(num(source.scale, 1, 0.3, 4) * 100) / 100,
    onlyInGame: typeof source.onlyInGame === 'boolean' ? source.onlyInGame : true,
    hideWhenUnfocused:
      typeof source.hideWhenUnfocused === 'boolean' ? source.hideWhenUnfocused : false,
    // Einmal-Umstellung: Der Hub startet mit Windows, damit das Crosshair nach
    // einem Neustart wieder da ist. Abschalten geht in den Einstellungen.
    autoStart:
      source.autoStartDefault === true && typeof source.autoStart === 'boolean'
        ? source.autoStart
        : DEFAULT_APP.autoStart,
    autoStartDefault: true,
    closeToTray: typeof source.closeToTray === 'boolean' ? source.closeToTray : true,
    clickSound: typeof source.clickSound === 'boolean' ? source.clickSound : true,
    captureVisible:
      typeof source.captureVisible === 'boolean' ? source.captureVisible : DEFAULT_APP.captureVisible,
    wallpaper:
      typeof source.wallpaper === 'string' ? source.wallpaper.slice(0, 200) : DEFAULT_APP.wallpaper,
    wallShade: Math.round(num(source.wallShade, 80, 0, 100)),
    ranks: normalizeRanks(source.ranks),
    rankMode: MODES.some((mode) => mode.id === source.rankMode)
      ? source.rankMode
      : DEFAULT_APP.rankMode,
    rankAuto: typeof source.rankAuto === 'boolean' ? source.rankAuto : DEFAULT_APP.rankAuto,
    hotkeysEnabled: source.hotkeysEnabled === true,
    focusMode: source.focusMode === true,
    aimTightenDefault: true,
    weaponHotkeys,
    hotkeys,
  };
}

function activeProfile(app) {
  const list = Array.isArray(app?.profiles) ? app.profiles : [];
  return list.find((profile) => profile.id === app?.activeId) || list[0] || normalizeProfile({});
}

module.exports = {
  ANIMATIONS,
  DEFAULT_APP,
  DEFAULT_HOTKEYS,
  KINDS,
  MODES,
  PIXEL_GRID,
  RANKS,
  activeProfile,
  defaultProfiles,
  emptyPixels,
  newId,
  normalizeApp,
  normalizeProfile,
  normalizeRanks,
  rankProfiles,
};
