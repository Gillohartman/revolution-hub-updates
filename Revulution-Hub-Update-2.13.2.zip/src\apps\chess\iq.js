'use strict';

/*
 * IQ-Test (50 Fragen) für den Schach-Coach.
 * Zahlenreihen, Buchstabenreihen, Analogien, Matrizen (Figuren-Muster), räumliches
 * Denken (gespiegelte Figur finden) und Logik. Am Ende: IQ-Schätzung aus dem Test und
 * eine zweite Schätzung, in die dein Schach (Genauigkeit, Lerntempo) einfließt.
 *
 * Das ist eine Unterhaltungs-Schätzung – kein wissenschaftlich geeichter IQ-Test.
 */
(function (root) {
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  function rng(seed) {
    let s = seed >>> 0 || 1;
    return () => {
      s ^= s << 13;
      s ^= s >>> 17;
      s ^= s << 5;
      return (s >>> 0) / 4294967296;
    };
  }

  function build(seed = Date.now()) {
    const R = rng(seed);
    const ri = (a, b) => a + Math.floor(R() * (b - a + 1));
    const pick = (arr) => arr[Math.floor(R() * arr.length)];
    const shuffle = (arr) => {
      const a = [...arr];
      for (let i = a.length - 1; i > 0; i -= 1) {
        const j = Math.floor(R() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    };
    const numOpts = (ans) => {
      const set = new Set([ans]);
      const deltas = shuffle([1, -1, 2, -2, 3, -3, 5, -5, 10, -10, Math.max(1, Math.round(Math.abs(ans) * 0.1)), -Math.max(1, Math.round(Math.abs(ans) * 0.1))]);
      for (const d of deltas) {
        if (set.size >= 4) break;
        set.add(ans + d);
      }
      return shuffle([...set]).map(String);
    };
    const Q = [];

    /* ---------- Zahlenreihen (15) */
    const series = [
      (d) => { const a = ri(1, 20), s = ri(3, 9); return { seq: [0, 1, 2, 3, 4].map((i) => a + i * s), ans: a + 5 * s, d }; },
      (d) => { const a = ri(2, 5), f = ri(2, 3); return { seq: [0, 1, 2, 3].map((i) => a * f ** i), ans: a * f ** 4, d }; },
      (d) => { const a = ri(10, 30), u = ri(4, 9), v = ri(1, 3); const s = [a]; for (let i = 1; i < 6; i += 1) s.push(s[i - 1] + (i % 2 ? u : -v)); return { seq: s, ans: s[5] - v + 0 === 0 ? 0 : s[5] + (6 % 2 ? u : -v), d }; },
      (d) => { const a = ri(1, 9); const s = [a]; for (let i = 1; i < 6; i += 1) s.push(s[i - 1] + i); return { seq: s, ans: s[5] + 6, d }; },
      (d) => { const c = ri(-2, 3), o = ri(1, 3); const s = [0, 1, 2, 3, 4].map((i) => (i + o) ** 2 + c); return { seq: s, ans: (5 + o) ** 2 + c, d }; },
      (d) => { const a = ri(1, 3), b = ri(2, 5); const s = [a, b]; for (let i = 2; i < 6; i += 1) s.push(s[i - 1] + s[i - 2]); return { seq: s, ans: s[4] + s[5], d }; },
      (d) => { const a = ri(1, 5), b = ri(20, 40), u = ri(2, 4), v = ri(3, 6); const s = []; for (let i = 0; i < 7; i += 1) s.push(i % 2 ? b - Math.floor(i / 2) * v : a + (i / 2) * u); return { seq: s, ans: b - 3 * v + 0 * u, d, fix: (arr) => arr }; },
      (d) => { const a = ri(1, 4), m = ri(2, 3), p = ri(1, 3); const s = [a]; for (let i = 1; i < 5; i += 1) s.push(s[i - 1] * m + p); return { seq: s, ans: s[4] * m + p, d }; },
      (d) => { const pr = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]; const o = ri(0, 5); return { seq: pr.slice(o, o + 5), ans: pr[o + 5], d }; },
      (d) => { const o = ri(1, 3); const s = [0, 1, 2, 3, 4].map((i) => ((i + o) * (i + o + 1)) / 2); return { seq: s, ans: ((5 + o) * (6 + o)) / 2, d }; },
      (d) => { const o = ri(1, 2); const s = [0, 1, 2, 3].map((i) => (i + o) ** 3); return { seq: s, ans: (4 + o) ** 3, d }; },
      (d) => { const a = ri(2, 6); const s = [a]; for (let i = 1; i < 5; i += 1) s.push(i % 2 ? s[i - 1] * 2 : s[i - 1] - 1); return { seq: s, ans: 5 % 2 ? s[4] * 2 : s[4] - 1, d }; },
      (d) => { const a = ri(50, 90), s = [a]; for (let i = 1; i < 6; i += 1) s.push(s[i - 1] - i * 2); return { seq: s, ans: s[5] - 12, d }; },
      (d) => { const a = ri(1, 3); const s = [a]; for (let i = 1; i < 5; i += 1) s.push(s[i - 1] * (i + 1)); return { seq: s, ans: s[4] * 6, d }; },
      (d) => { const a = ri(3, 9); const s = [a, a * 2 + 1]; for (let i = 2; i < 5; i += 1) s.push(s[i - 1] * 2 + (i % 2 ? 1 : -1)); return { seq: s, ans: s[4] * 2 + 1, d }; },
    ];
    const diffs = [1, 1, 2, 1, 2, 2, 3, 2, 2, 2, 2, 3, 2, 3, 3];
    series.forEach((f, i) => {
      let { seq, ans, d } = f(diffs[i]);
      if (i === 2) {
        // abwechselnd +u / −v: nächstes Glied neu berechnen
        const u = seq[1] - seq[0], v = seq[1] - seq[2];
        ans = seq[seq.length - 1] + (seq.length % 2 ? u : -v);
      }
      if (i === 11) ans = seq.length % 2 ? seq[seq.length - 1] * 2 : seq[seq.length - 1] - 1;
      Q.push({ cat: 'Zahlenreihe', d, q: `Welche Zahl kommt als Nächstes?`, show: `<div class="iq-seq">${seq.map((x) => `<span>${x}</span>`).join('')}<span class="q">?</span></div>`, opts: numOpts(ans), ans: String(ans) });
    });

    /* ---------- Buchstabenreihen (6) */
    const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const letterQs = [
      () => { const s = ri(0, 8), k = ri(2, 3); const seq = [0, 1, 2, 3, 4].map((i) => A[s + i * k]); return { seq, ans: A[s + 5 * k], d: 1 }; },
      () => { const s = ri(18, 25), k = ri(2, 3); const seq = [0, 1, 2, 3].map((i) => A[s - i * k]); return { seq, ans: A[s - 4 * k], d: 1 }; },
      () => { const s = ri(0, 4); const seq = []; let p = s; for (let i = 0; i < 5; i += 1) { seq.push(A[p]); p += i + 1; } return { seq, ans: A[p], d: 2 }; },
      () => { const s = ri(0, 5), e = ri(20, 25); const seq = [A[s], A[e], A[s + 1], A[e - 1], A[s + 2]]; return { seq, ans: A[e - 2], d: 2 }; },
      () => { const s = ri(0, 6); const seq = [A[s] + A[s + 1], A[s + 2] + A[s + 3], A[s + 4] + A[s + 5]]; return { seq, ans: A[s + 6] + A[s + 7], d: 2, pair: true }; },
      () => { const s = ri(0, 3); const seq = [0, 1, 2, 3].map((i) => A[s + i * i]); return { seq, ans: A[s + 16], d: 3 }; },
    ];
    for (const f of letterQs) {
      const { seq, ans, d, pair } = f();
      const set = new Set([ans]);
      const base = A.indexOf(ans[0]);
      for (const k of shuffle([1, -1, 2, -2, 3])) {
        if (set.size >= 4) break;
        const c = A[base + k];
        if (c) set.add(pair ? c + (A[base + k + 1] || 'Z') : c);
      }
      Q.push({ cat: 'Buchstaben', d, q: 'Welcher Buchstabe (bzw. welches Paar) kommt als Nächstes?', show: `<div class="iq-seq">${seq.map((x) => `<span>${x}</span>`).join('')}<span class="q">?</span></div>`, opts: shuffle([...set]), ans });
    }

    /* ---------- Analogien (6 aus 12) */
    const analog = [
      ['Hand : Handschuh = Fuß : ?', 'Socke', ['Zeh', 'Bein', 'Schritt'], 1],
      ['Vogel : Nest = Biene : ?', 'Stock', ['Honig', 'Blume', 'Flügel'], 1],
      ['Buch : Seite = Baum : ?', 'Blatt', ['Holz', 'Wald', 'Wurzel'], 1],
      ['Kalt : Eis = Heiß : ?', 'Dampf', ['Sommer', 'Ofen', 'Sonne'], 2],
      ['Uhr : Zeit = Waage : ?', 'Gewicht', ['Größe', 'Metall', 'Küche'], 1],
      ['Maler : Pinsel = Schriftsteller : ?', 'Stift', ['Buch', 'Papier', 'Leser'], 2],
      ['Hunger : Essen = Müdigkeit : ?', 'Schlaf', ['Bett', 'Nacht', 'Gähnen'], 2],
      ['König : Schach = Tor : ?', 'Fußball', ['Mauer', 'Burg', 'Torwart'], 2],
      ['Wasser : Durst = Wissen : ?', 'Neugier', ['Schule', 'Buch', 'Lehrer'], 3],
      ['Samen : Pflanze = Ei : ?', 'Vogel', ['Nest', 'Schale', 'Frühstück'], 2],
      ['Laut : Leise = Selten : ?', 'Oft', ['Nie', 'Manchmal', 'Gestern'], 2],
      ['Thermometer : Temperatur = Kompass : ?', 'Richtung', ['Karte', 'Norden', 'Nadel'], 3],
    ];
    for (const [q, ans, wrong, d] of shuffle(analog).slice(0, 6)) Q.push({ cat: 'Analogie', d, q, show: '', opts: shuffle([ans, ...wrong]), ans });

    /* ---------- Matrizen (10) */
    const SHAPES = ['circle', 'square', 'tri', 'diamond', 'star'];
    const FILLS = ['none', 'half', 'full'];
    const shapeSvg = (shape, x, y, r, fill, rot = 0) => {
      const col = '#a78bfa';
      const f = fill === 'full' ? col : fill === 'half' ? 'url(#iqh)' : 'none';
      const t = `transform="rotate(${rot} ${x} ${y})"`;
      if (shape === 'circle') return `<circle cx="${x}" cy="${y}" r="${r}" fill="${f}" stroke="${col}" stroke-width="2.5"/>`;
      if (shape === 'square') return `<rect x="${x - r}" y="${y - r}" width="${2 * r}" height="${2 * r}" fill="${f}" stroke="${col}" stroke-width="2.5" ${t}/>`;
      if (shape === 'tri') return `<polygon points="${x},${y - r} ${x + r},${y + r * 0.85} ${x - r},${y + r * 0.85}" fill="${f}" stroke="${col}" stroke-width="2.5" ${t}/>`;
      if (shape === 'diamond') return `<polygon points="${x},${y - r} ${x + r},${y} ${x},${y + r} ${x - r},${y}" fill="${f}" stroke="${col}" stroke-width="2.5" ${t}/>`;
      const pts = [];
      for (let i = 0; i < 10; i += 1) {
        const a = (Math.PI / 5) * i - Math.PI / 2;
        const rr = i % 2 ? r * 0.45 : r;
        pts.push(`${(x + Math.cos(a) * rr).toFixed(1)},${(y + Math.sin(a) * rr).toFixed(1)}`);
      }
      return `<polygon points="${pts.join(' ')}" fill="${f}" stroke="${col}" stroke-width="2.5" ${t}/>`;
    };
    const cellSvg = (c) => {
      const n = c.count;
      const pos = n === 1 ? [[40, 40]] : n === 2 ? [[24, 40], [56, 40]] : n === 3 ? [[40, 22], [22, 56], [58, 56]] : [[24, 24], [56, 24], [24, 56], [56, 56]];
      const r = n === 1 ? 20 : n === 2 ? 13 : 11;
      return `<svg viewBox="0 0 80 80" class="iq-cell"><defs><pattern id="iqh" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="3" height="6" fill="#a78bfa"/></pattern></defs>${pos.map(([x, y]) => shapeSvg(c.shape, x, y, r, c.fill, c.rot || 0)).join('')}</svg>`;
    };
    for (let k = 0; k < 10; k += 1) {
      const rowShapes = shuffle(SHAPES).slice(0, 3);
      const colFill = shuffle(FILLS);
      const mode = k < 3 ? 'count' : k < 6 ? 'fill' : k < 8 ? 'countfill' : 'rot';
      const grid = [];
      for (let r = 0; r < 3; r += 1)
        for (let c = 0; c < 3; c += 1) {
          const cell = { shape: rowShapes[r], count: 1, fill: 'none', rot: 0 };
          if (mode === 'count' || mode === 'countfill') cell.count = k % 2 ? 3 - c : c + 1;
          if (mode === 'fill' || mode === 'countfill') cell.fill = colFill[(c + (mode === 'countfill' ? r : 0)) % 3];
          if (mode === 'rot') {
            cell.shape = 'tri';
            cell.fill = FILLS[r];
            cell.rot = ((c + r) * 90) % 360;
          }
          grid.push(cell);
        }
      const ans = grid[8];
      const variants = [
        { ...ans, count: ans.count === 4 ? 3 : ans.count + 1 },
        { ...ans, fill: FILLS[(FILLS.indexOf(ans.fill) + 1) % 3] },
        { ...ans, shape: rowShapes[1] === ans.shape ? rowShapes[0] : rowShapes[1] },
        { ...ans, rot: (ans.rot + 90) % 360 },
      ];
      const key = (c) => `${c.shape}${c.count}${c.fill}${c.rot}`;
      const opts = [ans];
      for (const v of shuffle(variants)) if (opts.length < 4 && !opts.some((o) => key(o) === key(v))) opts.push(v);
      const shuffled = shuffle(opts);
      Q.push({
        cat: 'Matrix',
        d: mode === 'count' ? 1 : mode === 'fill' ? 2 : 3,
        q: 'Welches Feld ergänzt das Muster unten rechts?',
        show: `<div class="iq-matrix">${grid.map((c, i) => (i === 8 ? '<div class="iq-cell q">?</div>' : cellSvg(c))).join('')}</div>`,
        opts: shuffled.map((c) => key(c)),
        optHtml: shuffled.map(cellSvg),
        ans: key(ans),
      });
    }

    /* ---------- Räumlich: gespiegelte Figur (7) */
    const POLY = [
      [[0, 0], [0, 1], [0, 2], [1, 2]],
      [[0, 0], [1, 0], [1, 1], [2, 1]],
      [[0, 0], [0, 1], [1, 1], [1, 2], [1, 3]],
      [[0, 0], [1, 0], [2, 0], [2, 1], [3, 1]],
      [[0, 1], [1, 1], [1, 0], [2, 0], [1, 2]],
      [[0, 0], [0, 1], [0, 2], [1, 1], [1, 3]],
      [[0, 0], [1, 0], [1, 1], [1, 2], [2, 2], [3, 2]],
    ];
    const rot = (cells, times) => {
      let c = cells;
      for (let i = 0; i < times; i += 1) c = c.map(([x, y]) => [-y, x]);
      const mx = Math.min(...c.map((p) => p[0])), my = Math.min(...c.map((p) => p[1]));
      return c.map(([x, y]) => [x - mx, y - my]);
    };
    const mirror = (cells) => rot(cells.map(([x, y]) => [-x, y]), 0);
    const polySvg = (cells) => {
      const w = Math.max(...cells.map((p) => p[0])) + 1, h = Math.max(...cells.map((p) => p[1])) + 1;
      const s = 64 / Math.max(w, h, 3);
      return `<svg viewBox="-4 -4 72 72" class="iq-cell">${cells.map(([x, y]) => `<rect x="${x * s + (64 - w * s) / 2}" y="${y * s + (64 - h * s) / 2}" width="${s - 2}" height="${s - 2}" rx="2" fill="#38bdf8"/>`).join('')}</svg>`;
    };
    POLY.forEach((poly, i) => {
      const odd = ri(0, 3);
      const items = [0, 1, 2, 3].map((k) => (k === odd ? rot(mirror(poly), ri(0, 3)) : rot(poly, (k + i) % 4)));
      Q.push({ cat: 'Räumlich', d: i < 2 ? 2 : 3, q: 'Drei Figuren sind nur gedreht. Welche ist gespiegelt?', show: '', opts: ['0', '1', '2', '3'], optHtml: items.map(polySvg), ans: String(odd) });
    });

    /* ---------- Logik (6) */
    const logic = [
      ['Ein Schläger und ein Ball kosten zusammen 1,10 €. Der Schläger kostet 1 € mehr als der Ball. Was kostet der Ball?', '0,05 €', ['0,10 €', '0,01 €', '0,15 €'], 2],
      ['5 Maschinen brauchen 5 Minuten für 5 Teile. Wie lange brauchen 100 Maschinen für 100 Teile?', '5 Minuten', ['100 Minuten', '20 Minuten', '1 Minute'], 2],
      ['Seerosen verdoppeln ihre Fläche jeden Tag. Nach 48 Tagen ist der See voll. Nach wie vielen Tagen war er halb bedeckt?', '47', ['24', '46', '12'], 2],
      ['Alle Blips sind Blops. Einige Blops sind Blups. Sind dann sicher einige Blips Blups?', 'Nicht sicher', ['Ja', 'Nein, nie', 'Nur alle'], 3],
      ['Wenn gestern Freitag war – welcher Tag ist übermorgen?', 'Montag', ['Sonntag', 'Dienstag', 'Samstag'], 1],
      ['Ein Springer steht auf a1. Wie viele Züge braucht er mindestens bis b2?', '4', ['2', '3', '5'], 3],
      ['Welche Zahl passt nicht: 2, 3, 5, 9, 11, 13?', '9', ['2', '11', '13'], 1],
      ['Wie viel Grad liegen um 3:30 Uhr zwischen Stunden- und Minutenzeiger?', '75°', ['90°', '60°', '105°'], 3],
      ['Lisa ist älter als Tom. Tom ist älter als Mia. Mia ist älter als Ben. Wer ist am zweitjüngsten?', 'Mia', ['Tom', 'Ben', 'Lisa'], 1],
    ];
    for (const [q, ans, wrong, d] of shuffle(logic).slice(0, 6)) Q.push({ cat: 'Logik', d, q, show: '', opts: shuffle([ans, ...wrong]), ans });

    return shuffle(Q).sort((a, b) => a.d - b.d + (R() - 0.5) * 1.2);
  }

  /** Rohwert → IQ (Unterhaltungs-Norm: Durchschnitt ≈ 55 % gewichtet richtig). */
  function score(questions, answers, secs) {
    let got = 0, max = 0, right = 0;
    questions.forEach((q, i) => {
      const w = q.d === 3 ? 1.6 : q.d === 2 ? 1.25 : 1;
      max += w;
      if (answers[i] === q.ans) {
        got += w;
        right += 1;
      }
    });
    const pct = got / max;
    const speed = secs < 15 * 60 && pct > 0.5 ? 2 : 0;
    const iq = Math.round(Math.max(55, Math.min(150, 100 + ((pct - 0.55) / 0.16) * 15 + speed)));
    const cats = {};
    questions.forEach((q, i) => {
      cats[q.cat] = cats[q.cat] || { right: 0, total: 0 };
      cats[q.cat].total += 1;
      if (answers[i] === q.ans) cats[q.cat].right += 1;
    });
    return { iq, right, total: questions.length, pct, cats };
  }

  /**
   * Abgleich mit dem Schach: Genauigkeit in Partien, Trefferquote im Lernpfad und
   * Lerntempo (Elo pro Woche) verschieben die Schätzung leicht (max. ± 12 Punkte).
   */
  function chessAdjust(iq, chess) {
    const parts = [];
    if (chess.acc) parts.push(Math.max(-2, Math.min(2, (chess.acc - 70) / 10)));
    if (chess.lessonAcc != null) parts.push(Math.max(-2, Math.min(2, (chess.lessonAcc - 65) / 12)));
    if (chess.perWeek != null) parts.push(Math.max(-2, Math.min(2, chess.perWeek / 15)));
    if (!parts.length) return { iq, delta: 0, note: 'Noch zu wenig Schach-Daten – spiel ein paar Partien und Lektionen.' };
    const z = parts.reduce((a, b) => a + b, 0) / parts.length;
    const delta = Math.round(z * 6);
    return { iq: Math.max(55, Math.min(155, iq + delta)), delta, note: '' };
  }

  root.ChessIQ = { build, score, chessAdjust, esc };
})(typeof window !== 'undefined' ? window : globalThis);
