'use strict';

/*
 * Länder-Quiz und Lernpfad für GeoRevolution.
 *   – Quiz: Flaggen, Hauptstädte, Kontinente und „Welches Land ist hier?“ auf der Karte.
 *   – Lernpfad: Einheiten nach Region; erst kennenlernen, dann abfragen – mit Sternen.
 * geo.js stellt über window.GeoHost Profil, Speichern, Punkte und Sprache bereit.
 */
(function () {
  // Land | Hauptstadt | Kontinent | Breite | Länge (der Hauptstadt)
  const RAW = `DE|Berlin|eu|52.52|13.40
FR|Paris|eu|48.86|2.35
IT|Rom|eu|41.90|12.50
ES|Madrid|eu|40.42|-3.70
PT|Lissabon|eu|38.72|-9.14
GB|London|eu|51.51|-0.13
IE|Dublin|eu|53.35|-6.26
NL|Amsterdam|eu|52.37|4.90
BE|Brüssel|eu|50.85|4.35
LU|Luxemburg|eu|49.61|6.13
CH|Bern|eu|46.95|7.45
AT|Wien|eu|48.21|16.37
PL|Warschau|eu|52.23|21.01
CZ|Prag|eu|50.08|14.44
SK|Bratislava|eu|48.15|17.11
HU|Budapest|eu|47.50|19.04
SI|Ljubljana|eu|46.06|14.51
HR|Zagreb|eu|45.81|15.98
RS|Belgrad|eu|44.79|20.45
RO|Bukarest|eu|44.43|26.10
BG|Sofia|eu|42.70|23.32
GR|Athen|eu|37.98|23.73
TR|Ankara|eu|39.93|32.86
UA|Kiew|eu|50.45|30.52
RU|Moskau|eu|55.76|37.62
SE|Stockholm|eu|59.33|18.07
NO|Oslo|eu|59.91|10.75
DK|Kopenhagen|eu|55.68|12.57
FI|Helsinki|eu|60.17|24.94
IS|Reykjavík|eu|64.15|-21.94
EE|Tallinn|eu|59.44|24.75
LV|Riga|eu|56.95|24.11
LT|Vilnius|eu|54.69|25.28
US|Washington, D.C.|na|38.90|-77.04
CA|Ottawa|na|45.42|-75.70
MX|Mexiko-Stadt|na|19.43|-99.13
CU|Havanna|na|23.11|-82.37
GT|Guatemala-Stadt|na|14.63|-90.51
CR|San José|na|9.93|-84.08
PA|Panama-Stadt|na|8.98|-79.52
JM|Kingston|na|17.97|-76.79
DO|Santo Domingo|na|18.49|-69.93
BR|Brasília|sa|-15.79|-47.88
AR|Buenos Aires|sa|-34.60|-58.38
CL|Santiago|sa|-33.45|-70.67
PE|Lima|sa|-12.05|-77.04
CO|Bogotá|sa|4.71|-74.07
VE|Caracas|sa|10.48|-66.90
EC|Quito|sa|-0.18|-78.47
BO|Sucre|sa|-19.03|-65.26
UY|Montevideo|sa|-34.90|-56.16
PY|Asunción|sa|-25.26|-57.58
CN|Peking|as|39.90|116.41
JP|Tokio|as|35.68|139.69
KR|Seoul|as|37.57|126.98
MN|Ulaanbaatar|as|47.89|106.91
IN|Neu-Delhi|as|28.61|77.21
PK|Islamabad|as|33.68|73.05
BD|Dhaka|as|23.81|90.41
NP|Kathmandu|as|27.72|85.32
ID|Jakarta|as|-6.21|106.85
TH|Bangkok|as|13.76|100.50
VN|Hanoi|as|21.03|105.85
KH|Phnom Penh|as|11.56|104.92
PH|Manila|as|14.60|120.98
MY|Kuala Lumpur|as|3.14|101.69
SG|Singapur|as|1.35|103.82
SA|Riad|as|24.71|46.68
AE|Abu Dhabi|as|24.45|54.38
IL|Jerusalem|as|31.77|35.21
IR|Teheran|as|35.69|51.39
IQ|Bagdad|as|33.31|44.36
KZ|Astana|as|51.17|71.43
EG|Kairo|af|30.04|31.24
MA|Rabat|af|34.02|-6.84
DZ|Algier|af|36.75|3.06
TN|Tunis|af|36.81|10.18
NG|Abuja|af|9.06|7.49
GH|Accra|af|5.60|-0.19
SN|Dakar|af|14.72|-17.47
ET|Addis Abeba|af|9.03|38.74
KE|Nairobi|af|-1.29|36.82
TZ|Dodoma|af|-6.16|35.75
UG|Kampala|af|0.35|32.58
ZA|Pretoria|af|-25.75|28.19
NA|Windhoek|af|-22.56|17.08
BW|Gaborone|af|-24.63|25.92
MG|Antananarivo|af|-18.88|47.51
AU|Canberra|oc|-35.28|149.13
NZ|Wellington|oc|-41.29|174.78
FJ|Suva|oc|-18.14|178.44
PG|Port Moresby|oc|-9.44|147.18`;
  const ALL = RAW.split('\n').map((l) => {
    const [cc, capital, cont, lat, lng] = l.split('|');
    return { cc, capital, cont, lat: Number(lat), lng: Number(lng) };
  });
  const BY = Object.fromEntries(ALL.map((c) => [c.cc, c]));

  const UNITS = [
    { id: 'eu-west', color: '#38bdf8', t: { de: 'Westeuropa', en: 'Western Europe', es: 'Europa occidental' }, cc: ['DE', 'FR', 'ES', 'PT', 'GB', 'IE', 'NL', 'BE'] },
    { id: 'eu-mid', color: '#818cf8', t: { de: 'Mitteleuropa & Alpen', en: 'Central Europe & Alps', es: 'Europa central' }, cc: ['CH', 'AT', 'IT', 'LU', 'PL', 'CZ', 'SK', 'HU'] },
    { id: 'eu-north', color: '#22d3ee', t: { de: 'Nordeuropa & Baltikum', en: 'Northern Europe & Baltics', es: 'Europa del norte' }, cc: ['SE', 'NO', 'DK', 'FI', 'IS', 'EE', 'LV', 'LT'] },
    { id: 'eu-south', color: '#a78bfa', t: { de: 'Südost- & Osteuropa', en: 'South-East & Eastern Europe', es: 'Europa del este' }, cc: ['GR', 'TR', 'HR', 'SI', 'RS', 'RO', 'BG', 'UA', 'RU'] },
    { id: 'na', color: '#f59e0b', t: { de: 'Nord- & Mittelamerika', en: 'North & Central America', es: 'América del Norte y Central' }, cc: ['US', 'CA', 'MX', 'CU', 'GT', 'CR', 'PA', 'JM', 'DO'] },
    { id: 'sa', color: '#22c55e', t: { de: 'Südamerika', en: 'South America', es: 'América del Sur' }, cc: ['BR', 'AR', 'CL', 'PE', 'CO', 'VE', 'EC', 'BO', 'UY', 'PY'] },
    { id: 'as-east', color: '#f43f5e', t: { de: 'Ost- & Südostasien', en: 'East & South-East Asia', es: 'Asia oriental' }, cc: ['CN', 'JP', 'KR', 'MN', 'ID', 'TH', 'VN', 'KH', 'PH', 'MY', 'SG'] },
    { id: 'as-west', color: '#fb923c', t: { de: 'Süd- & Westasien', en: 'South & West Asia', es: 'Asia del sur y oeste' }, cc: ['IN', 'PK', 'BD', 'NP', 'SA', 'AE', 'IL', 'IR', 'IQ', 'KZ'] },
    { id: 'af-north', color: '#eab308', t: { de: 'Nord- & Westafrika', en: 'North & West Africa', es: 'África del norte y oeste' }, cc: ['EG', 'MA', 'DZ', 'TN', 'NG', 'GH', 'SN'] },
    { id: 'af-south', color: '#84cc16', t: { de: 'Ost- & Südafrika', en: 'East & Southern Africa', es: 'África del este y sur' }, cc: ['ET', 'KE', 'TZ', 'UG', 'ZA', 'NA', 'BW', 'MG'] },
    { id: 'oc', color: '#2dd4bf', t: { de: 'Ozeanien', en: 'Oceania', es: 'Oceanía' }, cc: ['AU', 'NZ', 'FJ', 'PG'] },
  ];
  const CONT = {
    eu: { de: 'Europa', en: 'Europe', es: 'Europa' }, na: { de: 'Nordamerika', en: 'North America', es: 'América del Norte' }, sa: { de: 'Südamerika', en: 'South America', es: 'América del Sur' },
    as: { de: 'Asien', en: 'Asia', es: 'Asia' }, af: { de: 'Afrika', en: 'Africa', es: 'África' }, oc: { de: 'Ozeanien', en: 'Oceania', es: 'Oceanía' },
  };
  const TX = {
    de: { quiz: 'Länder-Quiz', quizD: 'Flaggen, Hauptstädte und Karte – wie gut kennst du die Welt?', learn: 'Lernpfad', learnD: 'Lerne die Länder der Welt Region für Region – mit Sternen.', back: 'Zurück', mixed: 'Gemischt', flags: 'Flaggen', capitals: 'Hauptstädte', map: 'Karte', conts: 'Kontinente', world: 'Ganze Welt', start: 'Quiz starten', q: 'Frage', next: 'Weiter', done: 'Fertig', again: 'Nochmal', right: 'Richtig!', wrong: 'Falsch – richtig ist', qFlag: 'Zu welchem Land gehört diese Flagge?', qCap: 'Welches Land hat die Hauptstadt {x}?', qCapOf: 'Wie heißt die Hauptstadt von {x}?', qCont: 'Auf welchem Kontinent liegt {x}?', qMap: 'Welches Land ist hier markiert?', result: '{n} von {m} richtig', points: '+{n} Punkte', learnIntro: 'Präge dir diese Länder ein', capital: 'Hauptstadt', gotIt: 'Verstanden – abfragen!', locked: 'Schließe erst die Einheit davor ab.', streak: 'Serie', best: 'Bestwert', lesson: 'Lektion', stars: 'Sterne', kind: 'Art', region: 'Region', count: 'Fragen', perfect: 'Perfekt!', good: 'Gut gemacht!', tryAgain: 'Das geht noch besser.', needed: 'Mindestens 60 % für einen Stern.' },
    en: { quiz: 'Country quiz', quizD: 'Flags, capitals and map – how well do you know the world?', learn: 'Learning path', learnD: 'Learn the countries of the world region by region – with stars.', back: 'Back', mixed: 'Mixed', flags: 'Flags', capitals: 'Capitals', map: 'Map', conts: 'Continents', world: 'Whole world', start: 'Start quiz', q: 'Question', next: 'Next', done: 'Finish', again: 'Again', right: 'Correct!', wrong: 'Wrong – it is', qFlag: 'Which country does this flag belong to?', qCap: 'Which country has the capital {x}?', qCapOf: 'What is the capital of {x}?', qCont: 'On which continent is {x}?', qMap: 'Which country is marked here?', result: '{n} of {m} correct', points: '+{n} points', learnIntro: 'Memorise these countries', capital: 'Capital', gotIt: 'Got it – quiz me!', locked: 'Finish the previous unit first.', streak: 'Streak', best: 'Best', lesson: 'Lesson', stars: 'stars', kind: 'Type', region: 'Region', count: 'Questions', perfect: 'Perfect!', good: 'Well done!', tryAgain: 'You can do better.', needed: 'At least 60 % for a star.' },
    es: { quiz: 'Quiz de países', quizD: 'Banderas, capitales y mapa: ¿cuánto conoces el mundo?', learn: 'Ruta de aprendizaje', learnD: 'Aprende los países del mundo región por región, con estrellas.', back: 'Atrás', mixed: 'Mixto', flags: 'Banderas', capitals: 'Capitales', map: 'Mapa', conts: 'Continentes', world: 'Todo el mundo', start: 'Empezar', q: 'Pregunta', next: 'Siguiente', done: 'Terminar', again: 'Otra vez', right: '¡Correcto!', wrong: 'Incorrecto: es', qFlag: '¿De qué país es esta bandera?', qCap: '¿Qué país tiene la capital {x}?', qCapOf: '¿Cuál es la capital de {x}?', qCont: '¿En qué continente está {x}?', qMap: '¿Qué país está marcado aquí?', result: '{n} de {m} correctas', points: '+{n} puntos', learnIntro: 'Memoriza estos países', capital: 'Capital', gotIt: 'Entendido: ¡pregúntame!', locked: 'Termina antes la unidad anterior.', streak: 'Racha', best: 'Mejor', lesson: 'Lección', stars: 'estrellas', kind: 'Tipo', region: 'Región', count: 'Preguntas', perfect: '¡Perfecto!', good: '¡Bien hecho!', tryAgain: 'Puedes hacerlo mejor.', needed: 'Al menos 60 % para una estrella.' },
  };

  const H = () => window.GeoHost;
  const lang = () => H()?.lang() || 'de';
  const t = (k, p = {}) => String(TX[lang()]?.[k] ?? TX.de[k] ?? k).replace(/\{(\w+)\}/g, (_, x) => p[x] ?? '');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const name = (cc) => H()?.countryName(cc) || cc;
  const flag = (cc, cls = '') => `<span class="qz-flag ${cls}"><img src="https://flagcdn.com/w320/${cc.toLowerCase()}.png" alt="" draggable="false" data-flag="${cc}" /></span>`;
  const shuffle = (a) => {
    const b = a.slice();
    for (let i = b.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [b[i], b[j]] = [b[j], b[i]];
    }
    return b;
  };
  const state = () => {
    const p = H().profile();
    p.quiz ||= { best: {}, learn: {} };
    p.quiz.best ||= {};
    p.quiz.learn ||= {};
    return p.quiz;
  };

  let el = null;
  let run = null; // laufendes Quiz
  let map = null;
  const setup = { kind: 'mixed', region: 'world', count: 10 };

  function host() {
    if (el) return el;
    el = document.createElement('section');
    el.className = 'screen quiz-screen';
    el.id = 'quiz';
    el.hidden = true;
    document.body.insertBefore(el, document.getElementById('modal-back'));
    el.addEventListener('click', onClick);
    el.addEventListener('error', (e) => {
      // offline: statt der Flagge das Länderkürzel zeigen
      const img = e.target;
      if (img?.dataset?.flag) img.parentElement.innerHTML = `<b class="qz-cc">${esc(img.dataset.flag)}</b>`;
    }, true);
    return el;
  }
  function show(html) {
    host().innerHTML = html;
    for (const s of document.querySelectorAll('.screen')) s.hidden = s !== el;
    el.scrollTop = 0;
  }
  function leave() {
    run = null;
    map = null;
    H().menu();
  }
  const head = (title, back = 'menu') => `<div class="qz-head"><button class="btn small ghost" data-qz="${back}">← ${esc(t('back'))}</button><h2>${esc(title)}</h2></div>`;

  /* ---------------- Fragen bauen */
  function makeQuestion(c, pool, kind) {
    const kinds = ['flag', 'cap', 'capOf', 'map', 'cont'];
    const k = kind === 'mixed' ? kinds[Math.floor(Math.random() * (pool.length >= 4 ? 4 : 5))] : kind === 'flags' ? 'flag' : kind === 'capitals' ? (Math.random() < 0.5 ? 'cap' : 'capOf') : kind === 'map' ? 'map' : 'cont';
    if (k === 'cont') {
      const opts = shuffle(Object.keys(CONT)).filter((x) => x !== c.cont).slice(0, 3);
      return { k, c, answer: c.cont, options: shuffle([c.cont, ...opts]).map((id) => ({ id, label: CONT[id][lang()] || CONT[id].de })) };
    }
    // bevorzugt Länder vom selben Kontinent als falsche Antworten – das macht es knifflig
    const same = shuffle(pool.filter((x) => x.cc !== c.cc && x.cont === c.cont));
    const other = shuffle(ALL.filter((x) => x.cc !== c.cc && !same.includes(x)));
    const wrong = [...same, ...other].slice(0, 3);
    const options = shuffle([c, ...wrong]).map((x) => ({ id: x.cc, label: k === 'capOf' ? x.capital : name(x.cc) }));
    return { k, c, answer: c.cc, options };
  }

  function startQuiz({ pool, kind, count, lesson = null }) {
    const picks = [];
    const order = shuffle(pool);
    while (picks.length < count) picks.push(order[picks.length % order.length]);
    run = { qs: picks.map((c) => makeQuestion(c, pool, kind)), i: 0, ok: 0, streak: 0, bestStreak: 0, answered: null, lesson, kind, region: setup.region };
    renderQuestion();
  }

  function renderQuestion() {
    const q = run.qs[run.i];
    const prompt = q.k === 'flag' ? t('qFlag') : q.k === 'cap' ? t('qCap', { x: q.c.capital }) : q.k === 'capOf' ? t('qCapOf', { x: name(q.c.cc) }) : q.k === 'cont' ? t('qCont', { x: name(q.c.cc) }) : t('qMap');
    const a = run.answered;
    show(`<div class="qz-wrap">
      <div class="qz-top"><button class="btn small ghost" data-qz="${run.lesson ? 'path' : 'quiz'}">✕</button><div class="qz-bar"><i style="width:${((run.i + (a ? 1 : 0)) / run.qs.length) * 100}%"></i></div><span class="qz-count">${run.i + 1}/${run.qs.length}</span>${run.streak >= 2 ? `<span class="qz-streak">🔥 ${run.streak}</span>` : ''}</div>
      <div class="qz-card">
        <h3>${esc(prompt)}</h3>
        ${q.k === 'flag' ? flag(q.c.cc, 'big') : q.k === 'map' ? '<div class="qz-map" id="qz-map"><i class="qz-pin"></i></div>' : q.k === 'cont' || q.k === 'capOf' ? flag(q.c.cc, 'mid') : ''}
        <div class="qz-opts">${q.options.map((o) => `<button class="qz-opt ${a ? (o.id === q.answer ? 'ok' : o.id === a ? 'bad' : 'dim') : ''}" data-ans="${esc(o.id)}" ${a ? 'disabled' : ''}>${esc(o.label)}</button>`).join('')}</div>
        ${a ? `<div class="qz-fb ${a === q.answer ? 'ok' : 'bad'}"><b>${esc(a === q.answer ? t('right') : `${t('wrong')} ${q.options.find((o) => o.id === q.answer).label}`)}</b><span>${esc(name(q.c.cc))} · ${esc(t('capital'))}: ${esc(q.c.capital)} · ${esc(CONT[q.c.cont][lang()] || CONT[q.c.cont].de)}</span><button class="btn primary" data-qz="next">${esc(run.i + 1 >= run.qs.length ? t('done') : t('next'))}</button></div>` : ''}
      </div></div>`);
    if (q.k === 'map' && window.GeoMap) {
      map = new window.GeoMap(document.getElementById('qz-map'), {});
      map.setView(q.c.lat, q.c.lng, 4);
    }
  }

  function answer(id) {
    if (!run || run.answered) return;
    const q = run.qs[run.i];
    run.answered = id;
    if (id === q.answer) {
      run.ok += 1;
      run.streak += 1;
      run.bestStreak = Math.max(run.bestStreak, run.streak);
    } else run.streak = 0;
    renderQuestion();
  }

  function finish() {
    const n = run.ok, m = run.qs.length, pct = n / m;
    const st = state();
    let stars = 0, pts = 0;
    if (run.lesson) {
      stars = pct >= 0.95 ? 3 : pct >= 0.8 ? 2 : pct >= 0.6 ? 1 : 0;
      const before = st.learn[run.lesson.id] || 0;
      if (stars > before) {
        pts = (stars - before) * 12;
        st.learn[run.lesson.id] = stars;
      }
    } else {
      const key = `${run.kind}|${run.region}|${m}`;
      st.best[key] = Math.max(st.best[key] || 0, n);
      pts = Math.round(n * 1.5 + run.bestStreak);
    }
    pts = H().earn(pts);
    H().save();
    const again = run.lesson ? `data-unit="${run.lesson.id}"` : 'data-qz="again"';
    const lesson = run.lesson;
    show(`<div class="qz-wrap"><div class="qz-card qz-end">
      <div class="qz-ring" style="--p:${Math.round(pct * 100)}"><b>${Math.round(pct * 100)}%</b></div>
      <h2>${esc(pct >= 0.95 ? t('perfect') : pct >= 0.6 ? t('good') : t('tryAgain'))}</h2>
      <p class="muted">${esc(t('result', { n, m }))}${run.bestStreak >= 3 ? ` · 🔥 ${run.bestStreak}` : ''}</p>
      ${lesson ? `<div class="qz-stars">${[1, 2, 3].map((k) => `<i class="${stars >= k ? 'on' : ''}">★</i>`).join('')}</div>${stars ? '' : `<small class="muted">${esc(t('needed'))}</small>`}` : ''}
      ${pts ? `<div class="qz-pts">◆ ${esc(t('points', { n: pts }))}</div>` : ''}
      <div class="btns"><button class="btn" data-qz="${lesson ? 'path' : 'quiz'}">${esc(t('back'))}</button><button class="btn primary" ${again}>${esc(t('again'))}</button></div>
    </div></div>`);
    run = null;
  }

  /* ---------------- Quiz-Auswahl */
  function quizMenu() {
    const st = state();
    const best = st.best[`${setup.kind}|${setup.region}|${setup.count}`];
    const chips = (key, list) => `<div class="chips">${list.map(([v, n]) => `<button class="chipbtn ${String(setup[key]) === String(v) ? 'on' : ''}" data-set="${key}" data-v="${esc(v)}">${esc(n)}</button>`).join('')}</div>`;
    show(`<div class="qz-wrap">${head(t('quiz'))}
      <div class="qz-card">
        <div class="field"><label>${esc(t('kind'))}</label>${chips('kind', [['mixed', t('mixed')], ['flags', t('flags')], ['capitals', t('capitals')], ['map', t('map')], ['conts', t('conts')]])}</div>
        <div class="field"><label>${esc(t('region'))}</label>${chips('region', [['world', t('world')], ...Object.entries(CONT).map(([id, n]) => [id, n[lang()] || n.de])])}</div>
        <div class="field"><label>${esc(t('count'))}</label>${chips('count', [[10, '10'], [20, '20'], [40, '40']])}</div>
        <div class="qz-go"><button class="btn primary" data-qz="go">${esc(t('start'))}</button>${best != null ? `<span class="muted">${esc(t('best'))}: ${best}/${setup.count}</span>` : ''}</div>
      </div></div>`);
  }

  /* ---------------- Lernpfad */
  function pathMenu() {
    const st = state();
    let open = true;
    const total = UNITS.reduce((s, u) => s + (st.learn[u.id] || 0), 0);
    show(`<div class="qz-wrap">${head(t('learn'))}
      <p class="muted" style="margin:-6px 0 0">${total} / ${UNITS.length * 3} ${esc(t('stars'))} · ${esc(t('learnD'))}</p>
      <div class="qz-path">${UNITS.map((u, i) => {
        const stars = st.learn[u.id] || 0;
        const locked = !open;
        if (!stars) open = false;
        return `<button class="qz-node ${locked ? 'locked' : ''} ${stars ? 'done' : ''}" data-unit="${u.id}" style="--c:${u.color};--x:${[0, 46, 70, 46, 0, -46, -70, -46][i % 8]}px">
          <span class="qz-orb">${locked ? '🔒' : stars ? '★' : i + 1}</span>
          <span class="qz-ninfo"><b>${esc(u.t[lang()] || u.t.de)}</b><small>${u.cc.length} · ${[1, 2, 3].map((k) => (stars >= k ? '★' : '☆')).join('')}</small></span></button>`;
      }).join('')}</div></div>`);
  }
  function unitIntro(u) {
    show(`<div class="qz-wrap">${head(u.t[lang()] || u.t.de, 'path')}
      <p class="muted" style="margin:-6px 0 0">${esc(t('learnIntro'))}</p>
      <div class="qz-learn">${u.cc.map((cc, i) => `<div class="qz-lcard" style="animation-delay:${i * 45}ms">${flag(cc, 'mid')}<b>${esc(name(cc))}</b><small>${esc(t('capital'))}: ${esc(BY[cc].capital)}</small></div>`).join('')}</div>
      <div class="qz-go"><button class="btn primary" data-startunit="${u.id}">${esc(t('gotIt'))}</button></div></div>`);
  }

  function onClick(e) {
    const ans = e.target.closest('[data-ans]');
    if (ans) return answer(ans.dataset.ans);
    const set = e.target.closest('[data-set]');
    if (set) {
      setup[set.dataset.set] = /^\d+$/.test(set.dataset.v) ? Number(set.dataset.v) : set.dataset.v;
      return quizMenu();
    }
    const su = e.target.closest('[data-startunit]');
    if (su) {
      const u = UNITS.find((x) => x.id === su.dataset.startunit);
      return startQuiz({ pool: u.cc.map((cc) => BY[cc]), kind: 'mixed', count: Math.max(8, u.cc.length + 2), lesson: u });
    }
    const unit = e.target.closest('[data-unit]');
    if (unit) {
      if (unit.classList.contains('locked')) return H().toast(t('locked'));
      return unitIntro(UNITS.find((x) => x.id === unit.dataset.unit));
    }
    const a = e.target.closest('[data-qz]')?.dataset.qz;
    if (!a) return;
    if (a === 'menu') return leave();
    if (a === 'quiz') return quizMenu();
    if (a === 'path') return pathMenu();
    if (a === 'go' || a === 'again') return startQuiz({ pool: setup.region === 'world' ? ALL : ALL.filter((c) => c.cont === setup.region), kind: setup.kind, count: setup.count });
    if (a === 'next') {
      run.answered = null;
      run.i += 1;
      if (run.i >= run.qs.length) return finish();
      return renderQuestion();
    }
  }
  document.addEventListener('keydown', (e) => {
    if (!el || el.hidden || !run) return;
    if (run.answered && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault();
      el.querySelector('[data-qz="next"]')?.click();
    } else if (!run.answered && /^[1-4]$/.test(e.key)) el.querySelectorAll('[data-ans]')[Number(e.key) - 1]?.click();
  });

  window.GeoQuiz = {
    openQuiz: quizMenu,
    openPath: pathMenu,
    cards: () => [
      ['worldmap', '🗺', lang() === 'en' ? 'Country quiz (map)' : lang() === 'es' ? 'Quiz de países (mapa)' : 'Länder-Quiz (Karte)', lang() === 'en' ? 'Click a country on the world map and type its name.' : lang() === 'es' ? 'Haz clic en un país y escribe su nombre.' : 'Klick ein Land auf der Weltkarte an und schreib seinen Namen.'],
      ['learn', '✎', t('learn'), lang() === 'en' ? 'Learn every country in the world, continent by continent.' : lang() === 'es' ? 'Aprende todos los países, continente por continente.' : 'Lerne alle Länder der Welt – Kontinent für Kontinent, mit Sternen.'],
      ['quiz', '⚐', lang() === 'en' ? 'Flags & capitals' : lang() === 'es' ? 'Banderas y capitales' : 'Flaggen & Hauptstädte', t('quizD')],
    ],
    stars: () => UNITS.reduce((s, u) => s + ((H()?.profile()?.quiz?.learn || {})[u.id] || 0), 0),
    total: UNITS.length * 3,
  };
})();
