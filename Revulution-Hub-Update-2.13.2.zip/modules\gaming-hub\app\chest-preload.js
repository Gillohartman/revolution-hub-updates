const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('chests', {
  onState: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('chests:state', handler);
    return () => ipcRenderer.removeListener('chests:state', handler);
  },
});
