import fs from "node:fs";
import fsp from "node:fs/promises";
import { ensureDir } from "./paths.mjs";

export async function readJson(file, fallback = null) {
  try {
    return JSON.parse(await fsp.readFile(file, "utf8"));
  } catch {
    return fallback;
  }
}

export function readJsonSync(file, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

/** Atomic write: never leaves a half-written JSON file behind. */
export async function writeJson(file, value) {
  ensureDir(file.replace(/[\\/][^\\/]+$/, ""));
  const tmp = `${file}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(value, null, 2), "utf8");
  await fsp.rename(tmp, file);
  return value;
}

export function writeJsonSync(file, value) {
  ensureDir(file.replace(/[\\/][^\\/]+$/, ""));
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), "utf8");
  fs.renameSync(tmp, file);
  return value;
}

export const DEFAULT_SETTINGS = {
  language: "en_US",
  theme: "dark",
  accent: "violet",
  maxMemoryMb: 4096,
  minMemoryMb: 512,
  jvmArgs: "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=40",
  // Fast start and the large-view-distance defaults live in perf.mjs; these are the switches.
  fastStart: true,
  performanceMods: true,
  // Live wallpaper from the browser's shader set; "meteors" and "none" are the still options.
  liveWallpaper: "nebula",
  renderDistance: 32,
  simulationDistance: 12,
  gameArgs: "",
  javaPath: "",
  javaAutoDownload: true,
  autoUpdate: true,
  updateFeedUrl: "",
  showConsoleOnLaunch: true,
  closeLauncherOnLaunch: false,
  consoleMaxLines: 2000,
  concurrentDownloads: 12,
  microsoftClientId: "",
  selectedInstance: "",
  selectedAccount: "",
};

export function mergeSettings(base, patch) {
  return { ...DEFAULT_SETTINGS, ...base, ...patch };
}
