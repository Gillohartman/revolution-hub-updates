"use strict";

const { contextBridge, ipcRenderer } = require("electron");

/** Unwrap the { ok, data, error } envelope returned by every main-process handler. */
async function invoke(channel, ...args) {
  const result = await ipcRenderer.invoke(channel, ...args);
  if (result && typeof result === "object" && "ok" in result) {
    if (!result.ok) {
      const error = new Error(result.error || "Unknown error");
      error.code = result.code;
      throw error;
    }
    return result.data;
  }
  return result;
}

function on(channel, handler) {
  const listener = (_event, payload) => handler(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

const api = {
  app: {
    info: () => invoke("app:info"),
  },
  window: {
    minimize: () => invoke("window:minimize"),
    maximize: () => invoke("window:maximize"),
    close: () => invoke("window:close"),
  },
  shell: {
    openExternal: (url) => invoke("shell:openExternal", url),
    openPath: (target) => invoke("shell:openPath", target),
    showItemInFolder: (target) => invoke("shell:showItem", target),
  },
  dialog: {
    openFile: (options) => invoke("dialog:openFile", options),
    saveFile: (options) => invoke("dialog:saveFile", options),
    openDirectory: (options) => invoke("dialog:openDirectory", options),
  },
  settings: {
    get: () => invoke("settings:get"),
    update: (patch) => invoke("settings:update", patch),
  },
  updates: {
    state: () => invoke("updates:state"),
    check: () => invoke("updates:check"),
    download: () => invoke("updates:download"),
    install: () => invoke("updates:install"),
  },
  instances: {
    list: () => invoke("instances:list"),
    get: (id) => invoke("instances:get", id),
    create: (patch) => invoke("instances:create", patch),
    update: (id, patch) => invoke("instances:update", id, patch),
    remove: (id) => invoke("instances:delete", id),
    duplicate: (id, options) => invoke("instances:duplicate", id, options),
    size: (id) => invoke("instances:size", id),
    openFolder: (id, sub) => invoke("instances:openFolder", id, sub),
    untracked: (id) => invoke("instances:untracked", id),
    export: (id, destFile, options) => invoke("instances:export", id, destFile, options),
    import: (file, options) => invoke("instances:import", file, options),
  },
  versions: {
    list: (options) => invoke("versions:list", options),
    manifest: (options) => invoke("versions:manifest", options),
    get: (id) => invoke("versions:json", id),
    verify: (versionId) => invoke("versions:verify", versionId),
    install: (versionId, options) => invoke("versions:install", versionId, options),
  },
  java: {
    list: () => invoke("java:list"),
    install: (major, options) => invoke("java:install", major, options),
    test: (binary) => invoke("java:test", binary),
  },
  loaders: {
    list: () => invoke("loaders:list"),
    versions: (type, mcVersion) => invoke("loaders:versions", type, mcVersion),
    install: (payload) => invoke("loaders:install", payload),
    installJar: (payload) => invoke("loaders:installJar", payload),
  },
  accounts: {
    list: () => invoke("accounts:list"),
    addOffline: (name) => invoke("accounts:addOffline", name),
    remove: (id) => invoke("accounts:remove", id),
    setActive: (id) => invoke("accounts:setActive", id),
    deviceCode: (options) => invoke("accounts:deviceCode", options),
    loginMicrosoft: (payload) => invoke("accounts:loginMicrosoft", payload),
    cancelLogin: () => invoke("accounts:cancelLogin"),
    refresh: (id) => invoke("accounts:refresh", id),
  },
  perf: {
    boost: (payload) => invoke("perf:boost", payload),
  },
  servers: {
    list: () => invoke("servers:list"),
    add: (payload) => invoke("servers:add", payload),
    update: (id, patch) => invoke("servers:update", id, patch),
    remove: (id) => invoke("servers:remove", id),
    ping: (targets) => invoke("servers:ping", targets),
    lan: (options) => invoke("servers:lan", options),
    join: (payload) => invoke("servers:join", payload),
  },
  game: {
    preview: (instanceId, accountId) => invoke("game:preview", instanceId, accountId),
    launch: (instanceId, accountId) => invoke("game:launch", instanceId, accountId),
    kill: (instanceId) => invoke("game:kill", instanceId),
    status: () => invoke("game:status"),
    logs: (instanceId) => invoke("game:logs", instanceId),
    listLogs: () => invoke("game:listLogs"),
    readLog: (file) => invoke("game:readLog", file),
  },
  content: {
    search: (params) => invoke("content:search", params),
    popular: (params) => invoke("content:popular", params),
    project: (slug) => invoke("content:project", slug),
    versions: (slug, options) => invoke("content:versions", slug, options),
    list: (instanceId, options) => invoke("content:list", instanceId, options),
    install: (payload) => invoke("content:install", payload),
    toggle: (instanceId, entryId, enabled) => invoke("content:toggle", instanceId, entryId, enabled),
    remove: (instanceId, entryId, options) => invoke("content:remove", instanceId, entryId, options),
    installModpack: (payload) => invoke("content:installModpack", payload),
    exportModpack: (payload) => invoke("content:exportModpack", payload),
  },
  events: {
    onProgress: (handler) => on("progress", handler),
    onLaunchLog: (handler) => on("launch:log", handler),
    onLaunchStarted: (handler) => on("launch:started", handler),
    onLaunchExit: (handler) => on("launch:exit", handler),
    onLaunchFailed: (handler) => on("launch:failed", handler),
    onAccountsChanged: (handler) => on("accounts:changed", handler),
    onShowConsole: (handler) => on("console:show", handler),
    onUpdate: (handler) => on("updates:changed", handler),
  },
};

contextBridge.exposeInMainWorld("revolution", api);
