'use strict';
/*
 * Das Dock als eigene, durchsichtige Ebene über den Apps (die Apps laufen dahinter weiter).
 * Der Hub schickt das Modell (Apps, Punkte, Badges); hier: Zeichnen, weiche Vergrößerung,
 * Namen, Ziehen zum Umsortieren, Rechtsklick-Menü. Die Ebene meldet ihre nötige Größe.
 */
(() => {
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const MAX = 1.42; // grösste Vergrösserung
  let model = null;
  let hover = false, menuOpen = false, drag = null;
  let shown = false; // Dock sichtbar (nach der Einfahr-Animation)
  let open = false; // eingeklappt = kleine Glas-Kapsel, offen = ganzes Dock
  const keepOpen = () => open && (hover || menuOpen || drag);
  const fx = { cur: new Map(), target: new Map(), raf: 0, mouse: null };

  const vertical = () => model && (model.pos === 'left' || model.pos === 'right');

  function tileHtml(it) {
    return `<button class="dock-item ${it.active ? 'active' : ''}" data-id="${esc(it.id)}" ${it.special ? `data-special="${esc(it.special)}"` : 'draggable="true"'} data-tip="${esc(it.tip)}">${window.appArt(it.art || it.id, 'dock-ic')}${it.dot ? '<i class="dock-dot"></i>' : ''}${it.badge ? `<b class="app-badge">${it.badge > 99 ? '99+' : it.badge}</b>` : ''}</button>`;
  }
  function render() {
    if (!model) return;
    const el = $('#dock');
    document.body.dataset.dock = model.pos;
    document.body.dataset.dockSize = model.size;
    el.className = `dock dock-${model.pos} size-${model.size} ${model.magnify ? 'magnify' : ''} ${hover ? 'live' : ''}`;
    el.style.setProperty('--tile', `${model.tile}px`);
    el.innerHTML = `<div class="dock-bar">${model.items.map(tileHtml).join('')}<span class="dock-sep"></span>${model.fixed.map(tileHtml).join('')}</div>`;
    el.classList.toggle('shown', shown);
    const badges = model.items.reduce((n, it) => n + (it.badge || 0), 0);
    $('#dock-pill').className = `dock-pill pill-${model.pos} ${open ? 'away' : ''}`;
    $('#dock-pill').innerHTML = `<svg viewBox="0 0 18 10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8 9 2.5 16 8"/></svg>${badges ? `<b class="app-badge">${badges > 99 ? '99+' : badges}</b>` : ''}`;
    if (open && glass.url) applyGlass();
    fx.cur.clear();
    if (fx.mouse) magnify(fx.mouse);
    report();
  }

  /* ---------------- Grösse der Ebene melden (knapp, beim Darüberfahren grösser) */
  let lastSent = '';
  function report() {
    const bar = $('.dock-bar');
    if (!bar || !model) return;
    const t = model.tile;
    const v = vertical();
    // natürliche Länge des Docks (ohne Vergrösserung)
    const n = model.items.length + model.fixed.length;
    const length = n * (t + 4) + 13 + 4 + 24;
    const thick = t + 17;
    let w, h;
    if (!open) {
      // nur die kleine Kapsel
      w = v ? 34 : 104;
      h = v ? 104 : 34;
    } else if (v) {
      w = thick + 14 + Math.round(t * (MAX - 1)) + 200;
      h = length + 16 + Math.round(t * 1.6);
    } else {
      w = length + 16 + Math.round(t * 1.6);
      h = thick + 14 + Math.round(t * (MAX - 1)) + 56;
    }
    const big = open;
    if (menuOpen) {
      w = Math.max(w, v ? 420 : w);
      h = Math.max(h, v ? h : 260);
    }
    // Platz für das Update-Popup über dem Dock
    if (up && !up.hidden) {
      w = Math.max(w, 460);
      h += v ? 0 : 66;
    }
    const key = `${w}x${h}`;
    if (key === lastSent) return;
    lastSent = key;
    window.hub.dockSize?.({ w, h, expanded: big }).catch(() => {});
  }

  /* ---------------- Weiche Vergrösserung (Feder statt Sprung) */
  function magnify(e) {
    fx.mouse = e;
    const bar = $('.dock-bar');
    if (!bar || !model) return;
    const items = [...bar.querySelectorAll('.dock-item')];
    const r = bar.getBoundingClientRect();
    const v = vertical();
    const t = model.tile;
    // Mittelpunkte in Ruhelage (ohne Vergrösserung) berechnen
    const kids = [...bar.children];
    const sizes = kids.map((k) => (k.classList.contains('dock-sep') ? 13 : t));
    const total = sizes.reduce((a, b) => a + b, 0) + 4 * (kids.length - 1);
    let at = -total / 2;
    const centers = new Map();
    kids.forEach((k, i) => {
      centers.set(k, at + sizes[i] / 2);
      at += sizes[i] + 4;
    });
    const p = v ? e.clientY - (r.top + r.height / 2) : e.clientX - (r.left + r.width / 2);
    const range = t * 3;
    let hot = null, hotS = 0;
    for (const k of items) {
      const d = Math.abs(p - centers.get(k));
      const s = model.magnify && d < range ? 1 + (MAX - 1) * Math.pow((Math.cos((Math.PI * d) / range) + 1) / 2, 1.4) : 1;
      fx.target.set(k, s);
      if (d < t * 0.62 && s >= hotS) {
        hot = k;
        hotS = s;
      }
    }
    tip(hot);
    animate();
  }
  function calm() {
    fx.mouse = null;
    for (const k of fx.target.keys()) fx.target.set(k, 1);
    tip(null);
    animate();
  }
  function animate() {
    if (fx.raf) return;
    const step = () => {
      fx.raf = 0;
      let moving = false;
      for (const [k, target] of fx.target) {
        if (!k.isConnected) {
          fx.target.delete(k);
          continue;
        }
        const cur = fx.cur.get(k) ?? 1;
        const next = cur + (target - cur) * 0.24; // weiches Nachziehen
        const done = Math.abs(next - target) < 0.002;
        const val = done ? target : next;
        fx.cur.set(k, val);
        k.style.setProperty('--s', val.toFixed(4));
        if (!done) moving = true;
      }
      if (moving) fx.raf = requestAnimationFrame(step);
    };
    fx.raf = requestAnimationFrame(step);
  }
  function tip(item) {
    const el = $('#dock-label');
    if (!item || drag || menuOpen) {
      el.hidden = true;
      return;
    }
    el.textContent = item.dataset.tip || '';
    el.hidden = false;
    requestAnimationFrame(() => {
      if (el.hidden) return;
      const pos = model.pos, r = item.getBoundingClientRect(), t = el.getBoundingClientRect();
      el.dataset.pos = pos;
      const cx = Math.max(6, Math.min(window.innerWidth - t.width - 6, r.left + r.width / 2 - t.width / 2));
      el.style.left = `${pos === 'left' ? r.right + 12 : pos === 'right' ? r.left - t.width - 12 : cx}px`;
      el.style.top = `${pos === 'bottom' ? r.top - t.height - 12 : pos === 'top' ? r.bottom + 12 : r.top + r.height / 2 - t.height / 2}px`;
    });
  }

  let leaveT = null, closeT = null;
  function openDock() {
    clearTimeout(closeT);
    if (open) return;
    open = true;
    report(); // Ebene einmal gross machen …
    captureGlass();
    setTimeout(() => {
      // … dann das Dock hereinfedern lassen
      render();
      requestAnimationFrame(() => {
        shown = true;
        $('#dock')?.classList.add('shown');
      });
    }, 40);
  }
  function closeDock() {
    if (!open || menuOpen || drag) return;
    shown = false;
    $('#dock')?.classList.remove('shown', 'live');
    $('#dock-pill')?.classList.remove('away');
    tip(null);
    closeT = setTimeout(() => {
      open = false;
      hover = false;
      fx.mouse = null;
      report(); // erst nach der Animation wieder klein
      if (up && !up.hidden) renderUp();
    }, 330);
  }
  document.addEventListener('mousemove', (e) => {
    clearTimeout(leaveT);
    hover = true;
    if (!open) {
      if (e.target.closest?.('#dock-pill')) openDock();
      return;
    }
    $('#dock')?.classList.add('live');
    if (e.target.closest?.('.dock-bar')) magnify(e);
    else calm();
  });
  document.addEventListener('mouseleave', () => {
    calm();
    hover = false;
    clearTimeout(leaveT);
    leaveT = setTimeout(closeDock, 420);
  });
  window.addEventListener('blur', calm);

  /* ---------------- Klicks */
  document.addEventListener('click', (e) => {
    const m = e.target.closest('[data-menu]');
    if (m) return menuAction(m.dataset.menu, m.dataset.id);
    const b = e.target.closest('.dock-item');
    if (!b) return;
    if (b.dataset.special) return window.hub.dockSpecial(b.dataset.special).catch(() => {});
    b.classList.add('launching');
    setTimeout(() => b.classList.remove('launching'), 800);
    window.hub.open(b.dataset.id).catch(() => {});
  });

  /* ---------------- Rechtsklick-Menü */
  function closeMenu() {
    menuOpen = false;
    $('#dock-menu').hidden = true;
    report();
  }
  document.addEventListener('contextmenu', (e) => {
    const b = e.target.closest('.dock-item[data-id]:not([data-special])');
    e.preventDefault();
    if (!b) return;
    const it = model.items.find((x) => x.id === b.dataset.id);
    if (!it) return;
    menuOpen = true;
    report();
    const menu = $('#dock-menu');
    menu.innerHTML = `<b>${esc(it.tip)}</b><button data-menu="open" data-id="${esc(it.id)}">Öffnen</button>${it.canQuit ? `<button data-menu="quit" data-id="${esc(it.id)}">${esc(it.quitLabel || 'App beenden')}</button>` : ''}${it.id !== 'home' ? `<button data-menu="remove" data-id="${esc(it.id)}">Aus dem Dock entfernen</button>` : ''}<button data-menu="launcher">Alle Apps …</button>`;
    menu.hidden = false;
    // nach dem Vergrössern der Ebene platzieren
    setTimeout(() => {
      const r = menu.getBoundingClientRect();
      menu.style.left = `${Math.max(6, Math.min(e.clientX, window.innerWidth - r.width - 8))}px`;
      menu.style.top = `${Math.max(6, Math.min(e.clientY - r.height - 6, window.innerHeight - r.height - 8))}px`;
    }, 60);
  });
  document.addEventListener('mousedown', (e) => {
    if (menuOpen && !e.target.closest('#dock-menu')) closeMenu();
  });
  function menuAction(a, id) {
    closeMenu();
    if (a === 'open') window.hub.open(id);
    if (a === 'launcher') window.hub.dockSpecial('launcher');
    if (a === 'remove') window.hub.setSettings({ dock: { items: model.items.map((x) => x.id).filter((x) => x !== id) } });
    if (a === 'quit') {
      const it = model.items.find((x) => x.id === id);
      if (it?.module) window.hub.closeModule(id).catch(() => {});
      else window.hub.open('home');
    }
  }

  /* ---------------- Ziehen zum Umsortieren */
  document.addEventListener('dragstart', (e) => {
    const b = e.target.closest('.dock-item[draggable="true"]');
    if (!b) return;
    drag = b.dataset.id;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', drag);
    b.classList.add('dragging');
    tip(null);
  });
  document.addEventListener('dragover', (e) => {
    if (!drag) return;
    e.preventDefault();
    document.querySelectorAll('.drop-before').forEach((x) => x.classList.remove('drop-before'));
    const over = e.target.closest('.dock-item[draggable="true"]');
    if (over && over.dataset.id !== drag) over.classList.add('drop-before');
  });
  document.addEventListener('drop', (e) => {
    if (!drag) return;
    e.preventDefault();
    const before = e.target.closest('.dock-item[draggable="true"]')?.dataset.id;
    const items = model.items.map((x) => x.id).filter((x) => x !== drag);
    const at = before ? items.indexOf(before) : -1;
    if (at >= 0) items.splice(at, 0, drag);
    else items.push(drag);
    window.hub.setSettings({ dock: { items } }).catch(() => {});
  });
  document.addEventListener('dragend', () => {
    drag = null;
    document.querySelectorAll('.dragging, .drop-before').forEach((x) => x.classList.remove('dragging', 'drop-before'));
    report();
  });

  /* ---------------- Liquid Glass: Hintergrund hinter dem Dock, am Rand verzerrt */
  const glass = { url: '', map: '', w: 0, h: 0, timer: 0 };
  async function captureGlass() {
    clearInterval(glass.timer);
    const grab = async () => {
      if (!open) return clearInterval(glass.timer);
      try {
        const url = await window.hub.dockCapture?.();
        if (url) {
          glass.url = url;
          applyGlass();
        }
      } catch {
        /* ohne Glas */
      }
    };
    await grab();
    glass.timer = setInterval(grab, 700);
  }
  function lensMap(w, h) {
    // Verschiebungskarte: am Rand wird das Bild zur Mitte gezogen (wie der Rand eines Wassertropfens)
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const g = c.getContext('2d');
    const img = g.createImageData(w, h);
    const edge = Math.min(22, h / 2);
    for (let y = 0; y < h; y += 1)
      for (let x = 0; x < w; x += 1) {
        const dl = x, dr = w - 1 - x, dt = y, db = h - 1 - y;
        const dx = dl < edge ? 1 - dl / edge : dr < edge ? -(1 - dr / edge) : 0;
        const dy = dt < edge ? 1 - dt / edge : db < edge ? -(1 - db / edge) : 0;
        const i = (y * w + x) * 4;
        img.data[i] = 128 + Math.sign(dx) * Math.pow(Math.abs(dx), 2) * 127;
        img.data[i + 1] = 128 + Math.sign(dy) * Math.pow(Math.abs(dy), 2) * 127;
        img.data[i + 2] = 128;
        img.data[i + 3] = 255;
      }
    g.putImageData(img, 0, 0);
    return c.toDataURL();
  }
  function applyGlass() {
    const bar = $('.dock-bar');
    if (!bar || !glass.url) return;
    const r = bar.getBoundingClientRect();
    const w = Math.round(r.width), h = Math.round(r.height);
    if (w < 10 || h < 10) return;
    if (w !== glass.w || h !== glass.h) {
      glass.w = w;
      glass.h = h;
      glass.map = lensMap(w, h);
      const fe = document.getElementById('lens-map');
      fe.setAttribute('href', glass.map);
      fe.setAttribute('width', w);
      fe.setAttribute('height', h);
    }
    bar.style.setProperty('--cap', `url("${glass.url}")`);
    bar.style.setProperty('--cap-x', `${-r.left}px`);
    bar.style.setProperty('--cap-y', `${-r.top}px`);
    bar.style.setProperty('--cap-w', `${window.innerWidth}px`);
    bar.style.setProperty('--cap-h', `${window.innerHeight}px`);
    bar.classList.add('has-glass');
  }

  /* ---------------- Update-Popup */
  let up = null;
  const UPSTEP = { download: 'Wird geladen', unpack: 'Wird entpackt', install: 'Wird eingespielt', restart: 'Startet neu …' };
  function renderUp(msg = '') {
    const el = $('#up-pop');
    const show = up && !up.hidden;
    el.hidden = !show;
    if (show) {
      el.innerHTML = `<span class="ic">↑</span><div><b>Update ${esc(up.version)} ist da</b><small>${esc(msg || 'Neue Funktionen und Fehlerbehebungen')}</small></div>${up.busy ? '<button class="no" data-up="hide">Ausblenden</button>' : '<button class="go" data-up="go">Aktualisieren</button><button class="no" data-up="no">Später</button>'}`;
      el.style.bottom = open ? '' : '36px';
      if (model?.pos !== 'bottom') {
        el.style.bottom = 'auto';
        el.style.top = '12px';
      }
    }
    lastSent = '';
    report();
  }
  const showUpdate = (u) => {
    if (!u || u.dismissed) return;
    up = { version: u.version, hidden: false };
    renderUp();
  };
  window.hub.onUpdateAvailable?.(showUpdate);
  window.hub.update?.pending().then(showUpdate).catch(() => {});
  window.hub.onUpdate?.((p) => {
    if (!up) return;
    up.busy = true;
    renderUp(`${UPSTEP[p.step] || ''}${p.step === 'download' && p.pct ? ` · ${p.pct} %` : ''}`);
  });
  document.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-up]')?.dataset.up;
    if (!a || !up) return;
    if (a === 'hide') {
      up.hidden = true; // läuft im Hintergrund weiter, der Hub startet danach neu
      return renderUp();
    }
    if (a === 'no') {
      window.hub.update.dismiss(up.version).catch(() => {});
      up.hidden = true;
      return renderUp();
    }
    up.busy = true;
    renderUp('Wird vorbereitet …');
    try {
      await window.hub.update.check();
      await window.hub.update.install();
    } catch (error) {
      up.busy = false;
      renderUp(String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''));
    }
  });

  window.hub.onDockModel?.((m) => {
    model = m;
    render();
  });
  window.hub.dockReady?.().then((m) => {
    if (m && !model) {
      model = m;
      render();
    }
  }).catch(() => {});
})();
