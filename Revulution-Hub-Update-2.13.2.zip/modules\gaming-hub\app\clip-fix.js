'use strict';

/**
 * Zeitachse von Clips auf 0 setzen.
 *
 * Ein Clip ist ein Ausschnitt aus einer laufenden Aufnahme: Header + die
 * letzten Sekunden. Die Zeitstempel darin zählen aber ab Aufnahmestart – ein
 * Clip nach 5 Minuten beginnt bei 5:00. Player zeigen dann eine falsche Länge
 * und das Spulen springt ins Leere. Hier werden alle Zeitstempel so verschoben,
 * dass der Clip bei 0 beginnt. Die Dateigröße bleibt gleich, nichts verrutscht.
 */

/* ---------------- MP4 (fragmentiert, aus MediaRecorder) ---------------- */

function readBox(buffer, offset, end) {
  if (offset + 8 > end) return null;
  let size = buffer.readUInt32BE(offset);
  const type = buffer.toString('latin1', offset + 4, offset + 8);
  let header = 8;
  if (size === 1) {
    if (offset + 16 > end) return null;
    size = Number(buffer.readBigUInt64BE(offset + 8));
    header = 16;
  } else if (size === 0) {
    size = end - offset;
  }
  if (size < header || offset + size > end) return null;
  return { type, offset, size, body: offset + header, end: offset + size };
}

function* children(buffer, start, end) {
  let offset = start;
  while (offset < end) {
    const box = readBox(buffer, offset, end);
    if (!box) return;
    yield box;
    offset = box.end;
  }
}

/** Alle tfdt-Felder (Track-ID, Position, Version) der Datei. */
function mp4Decode(buffer) {
  const list = [];
  for (const top of children(buffer, 0, buffer.length)) {
    if (top.type !== 'moof') continue;
    for (const traf of children(buffer, top.body, top.end)) {
      if (traf.type !== 'traf') continue;
      let track = null;
      let tfdt = null;
      for (const box of children(buffer, traf.body, traf.end)) {
        if (box.type === 'tfhd') track = buffer.readUInt32BE(box.body + 4);
        if (box.type === 'tfdt') tfdt = box;
      }
      if (track === null || !tfdt) continue;
      const version = buffer[tfdt.body];
      const at = tfdt.body + 4;
      const value = version === 1 ? buffer.readBigUInt64BE(at) : BigInt(buffer.readUInt32BE(at));
      list.push({ track, at, version, value });
    }
  }
  return list;
}

function rebaseMp4(buffer) {
  const entries = mp4Decode(buffer);
  if (entries.length === 0) return false;
  const first = new Map();
  for (const entry of entries) {
    const known = first.get(entry.track);
    if (known === undefined || entry.value < known) first.set(entry.track, entry.value);
  }
  let changed = false;
  for (const entry of entries) {
    const base = first.get(entry.track) || 0n;
    if (base === 0n) continue;
    const next = entry.value - base;
    if (entry.version === 1) buffer.writeBigUInt64BE(next, entry.at);
    else buffer.writeUInt32BE(Number(next), entry.at);
    changed = true;
  }
  return changed;
}

/* ---------------- WebM ---------------- */

const CLUSTER = [0x1f, 0x43, 0xb6, 0x75];

/** EBML-Zahl variabler Länge: { length, value } oder null. */
function readVint(buffer, offset) {
  const first = buffer[offset];
  if (first === undefined || first === 0) return null;
  let length = 1;
  let mask = 0x80;
  while (length <= 8 && !(first & mask)) {
    mask >>= 1;
    length += 1;
  }
  if (length > 8 || offset + length > buffer.length) return null;
  let value = BigInt(first & (mask - 1));
  for (let i = 1; i < length; i += 1) value = (value << 8n) | BigInt(buffer[offset + i]);
  return { length, value };
}

/** Cluster-Zeitstempel (Element 0xE7) finden. */
function webmClusters(buffer) {
  const list = [];
  let offset = 0;
  while (offset < buffer.length - 8) {
    const index = buffer.indexOf(Buffer.from(CLUSTER), offset);
    if (index < 0) break;
    offset = index + 4;
    const size = readVint(buffer, offset);
    if (!size) continue;
    const timecodeAt = offset + size.length;
    if (buffer[timecodeAt] !== 0xe7) continue;
    const len = readVint(buffer, timecodeAt + 1);
    if (!len || len.value < 1n || len.value > 8n) continue;
    const at = timecodeAt + 1 + len.length;
    const bytes = Number(len.value);
    if (at + bytes > buffer.length) continue;
    let value = 0n;
    for (let i = 0; i < bytes; i += 1) value = (value << 8n) | BigInt(buffer[at + i]);
    list.push({ at, bytes, value });
  }
  return list;
}

function rebaseWebm(buffer) {
  const clusters = webmClusters(buffer);
  if (clusters.length === 0) return false;
  const base = clusters.reduce((min, entry) => (entry.value < min ? entry.value : min), clusters[0].value);
  if (base === 0n) return false;
  for (const entry of clusters) {
    let next = entry.value - base;
    for (let i = entry.bytes - 1; i >= 0; i -= 1) {
      buffer[entry.at + i] = Number(next & 0xffn);
      next >>= 8n;
    }
  }
  return true;
}

function rebaseClip(buffer, ext) {
  try {
    return ext === 'mp4' ? rebaseMp4(buffer) : rebaseWebm(buffer);
  } catch (error) {
    console.log('[clip] Zeitachse nicht angepasst:', error.message);
    return false;
  }
}

module.exports = { rebaseClip, rebaseMp4, rebaseWebm, mp4Decode, webmClusters };
