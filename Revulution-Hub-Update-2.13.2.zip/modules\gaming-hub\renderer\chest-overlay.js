'use strict';

/* Truhen-Overlay: Rundenzahl + Gesamtzahl, Animation bei jeder Truhe und am Rundenende. */
(() => {
  const $ = (id) => document.getElementById(id);
  const card = $('card');
  const wrap = $('chest-wrap');
  $('chest').innerHTML = window.CHEST_ART('ov');

  let settings = {};

  /* ---------------------------------------------------------- Zahl rollen */
  function roll(id, value, direction = 'up') {
    const host = $(id);
    const current = host.querySelector('b:not(.out)');
    if (current && current.textContent === String(value)) return;
    const next = document.createElement('b');
    next.textContent = String(value);
    next.className = 'from-below';
    if (direction === 'down') next.style.transform = 'translateY(-100%)';
    host.appendChild(next);
    if (current) {
      current.classList.add('out');
      if (direction === 'down') current.style.transform = 'translateY(100%)';
      setTimeout(() => current.remove(), 400);
    }
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        next.classList.remove('from-below');
        next.style.transform = '';
      }),
    );
  }

  let shown = 0;
  function setTotal(value) {
    roll('total', value, value < shown ? 'down' : 'up');
    shown = value;
  }

  /* --------------------------------------------------------- Effekte */
  function burst(count = 12) {
    const host = $('sparks');
    for (let i = 0; i < count; i += 1) {
      const spark = document.createElement('i');
      spark.className = 'spark';
      const angle = (-Math.PI / 2) + (Math.random() - 0.5) * Math.PI * 1.4;
      const dist = 26 + Math.random() * 26;
      spark.style.setProperty('--dx', `${Math.cos(angle) * dist}px`);
      spark.style.setProperty('--dy', `${Math.sin(angle) * dist}px`);
      spark.style.animationDelay = `${Math.random() * 120}ms`;
      host.appendChild(spark);
      setTimeout(() => spark.remove(), 1100);
    }
  }

  function restart(el, cls) {
    el.classList.remove(cls);
    void el.offsetWidth;
    el.classList.add(cls);
  }

  let glowTimer = null;
  function glow(ms = 900) {
    card.classList.add('glow');
    clearTimeout(glowTimer);
    glowTimer = setTimeout(() => card.classList.remove('glow'), ms);
  }

  let audio = null;
  function chime() {
    if (!settings.sound) return;
    try {
      audio = audio || new AudioContext();
      const now = audio.currentTime;
      [880, 1320, 1760].forEach((freq, i) => {
        const osc = audio.createOscillator();
        const gain = audio.createGain();
        osc.type = 'triangle';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0, now + i * 0.06);
        gain.gain.linearRampToValueAtTime(0.06, now + i * 0.06 + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.06 + 0.35);
        osc.connect(gain).connect(audio.destination);
        osc.start(now + i * 0.06);
        osc.stop(now + i * 0.06 + 0.4);
      });
    } catch {
      /* ohne Ton */
    }
  }

  function playOpen(total) {
    restart(wrap, 'open');
    restart($('plus'), 'go');
    restart($('total-box'), 'bump');
    burst(14);
    glow();
    chime();
    setTimeout(() => setTotal(total), 120);
  }

  /* --------------------------------------------------------- Zustand */
  function applySettings(next) {
    settings = next || {};
    document.body.className = settings.preset || 'tl';
    const scale = Number(settings.scale) || 1;
    $('stage').style.transform = `scale(${scale})`;
    $('stage').style.width = `${100 / scale}%`;
    $('stage').style.height = `${100 / scale}%`;
  }

  function handle(state) {
    if (!state) return;
    applySettings(state.settings);
    card.classList.add('in');
    if (state.event?.type === 'open') playOpen(state.allTime);
    else if (state.event?.type !== 'prompt') setTotal(state.allTime);
  }

  window.chests?.onState(handle);
})();
