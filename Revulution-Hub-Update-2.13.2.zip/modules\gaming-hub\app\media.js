const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

/**
 * Liest die Windows-Mediensitzung (Spotify, Browser, Player) über ein
 * PowerShell-Helferskript. Electron selbst hat dafür keine API – SMTC ist die
 * einzige Quelle für Cover, Titel und Abspielposition.
 */

let child = null;
let buffer = '';
let callback = null;
let stopping = false;

function scriptPath() {
  const packaged = process.resourcesPath ? path.join(process.resourcesPath, 'media-session.ps1') : '';
  const local = path.join(__dirname, '..', 'build', 'media-session.ps1');
  if (packaged && fs.existsSync(packaged)) return packaged;
  return local;
}

function handleLine(line) {
  const text = line.trim();
  if (!text || text[0] !== '{') return;
  let parsed = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    return;
  }
  if (!parsed || typeof parsed !== 'object') return;
  try {
    callback?.(parsed);
  } catch {
    /* Empfängerfehler dürfen die Abfrage nicht beenden */
  }
}

function start(onUpdate) {
  callback = typeof onUpdate === 'function' ? onUpdate : callback;
  if (child) return true;

  const file = scriptPath();
  if (!fs.existsSync(file)) return false;

  stopping = false;
  buffer = '';

  try {
    child = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file],
      { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] },
    );
  } catch {
    child = null;
    return false;
  }

  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    buffer += chunk;
    const parts = buffer.split(/\r?\n/);
    buffer = parts.pop() || '';
    for (const line of parts) handleLine(line);
    if (buffer.length > 4 * 1024 * 1024) buffer = '';
  });

  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk) => {
    const text = String(chunk).trim();
    if (text) console.log('[media]', text.slice(0, 200));
  });

  child.on('exit', () => {
    child = null;
    if (!stopping) callback?.({ playing: false, stopped: true });
  });

  return true;
}

function stop() {
  stopping = true;
  callback = null;
  if (!child) return;
  try {
    child.kill();
  } catch {
    /* egal */
  }
  child = null;
}

module.exports = { start, stop, scriptPath };
