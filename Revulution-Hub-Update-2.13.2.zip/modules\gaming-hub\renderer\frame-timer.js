'use strict';
// Gleichmäßiger Takt für die Aufnahme: Worker-Timer werden im Hintergrund nicht gedrosselt.
let timer = null;
onmessage = (event) => {
  clearInterval(timer);
  if (event.data > 0) timer = setInterval(() => postMessage(0), event.data);
};
