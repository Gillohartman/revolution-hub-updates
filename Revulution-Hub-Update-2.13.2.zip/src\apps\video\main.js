'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const { boot } = require('../shared/boot');

const ctx = boot('video', __dirname);
const { app, ipcMain, dialog, shell } = ctx.electron;
const hub = ctx.hub;

const VIDEO_EXT = ['mp4', 'mov', 'mkv', 'webm', 'avi', 'm4v', 'wmv', 'flv', 'mpg', 'mpeg', 'ts', 'mts', '3gp'];
const AUDIO_EXT = ['mp3', 'wav', 'm4a', 'aac', 'ogg', 'opus', 'flac', 'wma'];
const IMAGE_EXT = ['png', 'jpg', 'jpeg', 'webp', 'bmp', 'gif'];

const dataDir = () => app.getPath('userData');

function ffmpegPath() {
  const exe = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  const candidates = [path.join(process.resourcesPath || '', 'ffmpeg', exe), path.join(app.getAppPath(), 'vendor', 'ffmpeg', exe)];
  return candidates.find((file) => fs.existsSync(file)) || exe;
}

function run(args, { onLine, cwd } = {}) {
  const child = spawn(ffmpegPath(), ['-hide_banner', ...args], { windowsHide: true, cwd });
  let stderr = '';
  const done = new Promise((resolve, reject) => {
    child.stderr.on('data', (chunk) => {
      const text = chunk.toString();
      stderr += text;
      if (stderr.length > 200000) stderr = stderr.slice(-100000);
      if (onLine) text.split(/\r|\n/).forEach(onLine);
    });
    child.on('error', (error) => reject(new Error(`ffmpeg konnte nicht gestartet werden: ${error.message}`)));
    child.on('close', (code) => (code === 0 ? resolve(stderr) : code === null ? reject(Object.assign(new Error('Abgebrochen'), { stderr })) : reject(Object.assign(new Error(lastError(stderr) || `ffmpeg wurde mit Code ${code} beendet.`), { code, stderr }))));
  });
  return { child, done };
}

function lastError(stderr) {
  const lines = stderr.trim().split(/\r?\n/).filter((l) => /error|invalid|not|fail|unable/i.test(l));
  return lines.pop()?.trim();
}

const toSeconds = (h, m, s) => Number(h) * 3600 + Number(m) * 60 + Number(s);
const kindOf = (file) => {
  const ext = path.extname(file).slice(1).toLowerCase();
  if (IMAGE_EXT.includes(ext)) return 'image';
  if (AUDIO_EXT.includes(ext)) return 'audio';
  return 'video';
};

/** Duration and streams, read from ffmpeg's own banner (no ffprobe needed). */
async function probe(file) {
  const { done } = run(['-i', file]);
  const out = await done.catch((error) => error.stderr || '');
  const kind = kindOf(file);
  const duration = /Duration: (\d+):(\d+):([\d.]+)/.exec(out);
  const video = /Stream #\S+.*?Video: (\w+)[^\n]*?, (\d{2,5})x(\d{2,5})[^\n]*?(?:, ([\d.]+) fps)?/.exec(out);
  const audio = /Stream #\S+.*?Audio: (\w+)/.exec(out);
  if (kind === 'image') {
    if (!video) throw new Error('Dieses Bild kann nicht gelesen werden.');
    return { file, name: path.basename(file), kind, size: fs.statSync(file).size, duration: 5, video: { codec: video[1], width: Number(video[2]), height: Number(video[3]), fps: 30 }, audio: null };
  }
  if (!duration) throw new Error(`„${path.basename(file)}“ kann nicht gelesen werden.`);
  return {
    file,
    name: path.basename(file),
    kind: video && kind !== 'audio' ? 'video' : 'audio',
    size: fs.statSync(file).size,
    duration: toSeconds(duration[1], duration[2], duration[3]),
    video: video && kind !== 'audio' ? { codec: video[1], width: Number(video[2]), height: Number(video[3]), fps: Number(video[4]) || 30 } : null,
    audio: audio ? { codec: audio[1] } : null,
  };
}

/* ------------------------------------------------------------ gaming clips */

const thumbJobs = new Set();
/** Clips without a preview picture get one (cached); the next refresh shows it. */
function thumbFor(file, stat) {
  const dir = path.join(dataDir(), 'Vorschau');
  const name = `${require('crypto').createHash('sha1').update(`${file}|${stat.size}|${stat.mtimeMs}`).digest('hex').slice(0, 16)}.jpg`;
  const out = path.join(dir, name);
  if (fs.existsSync(out)) return out;
  if (!thumbJobs.has(out) && thumbJobs.size < 3) {
    thumbJobs.add(out);
    fs.mkdirSync(dir, { recursive: true });
    run(['-y', '-ss', '1', '-i', file, '-frames:v', '1', '-vf', 'scale=320:-2', out]).done.catch(() => {}).finally(() => thumbJobs.delete(out));
  }
  return '';
}

/** Clips saved by the Gaming Hub (instant replay, kills, wins), newest first. */
function gamingClips() {
  const roots = [hub.moduleDataDir?.('gaming'), path.join(app.getPath('appData'), 'Revolution Gaming Hub'), path.join(app.getPath('appData'), 'Revolution Crosshair')].filter(Boolean);
  const seen = new Set();
  const list = [];
  for (const root of roots) {
    const dir = path.join(root, 'clips');
    if (seen.has(dir.toLowerCase())) continue;
    seen.add(dir.toLowerCase());
    let names = [];
    try {
      names = fs.readdirSync(dir);
    } catch {
      continue;
    }
    const all = new Set(names);
    for (const name of names) {
      if (!/\.(mp4|webm)$/i.test(name)) continue;
      const file = path.join(dir, name);
      let meta = {};
      try {
        if (all.has(`${name}.json`)) meta = JSON.parse(fs.readFileSync(path.join(dir, `${name}.json`), 'utf8')) || {};
      } catch {
        /* clip without metadata */
      }
      let stat;
      try {
        stat = fs.statSync(file);
      } catch {
        continue;
      }
      const category = ['win', 'kill', 'manual'].includes(meta.category) ? meta.category : /^(sieg|win)/i.test(name) ? 'win' : /^kill/i.test(name) ? 'kill' : 'manual';
      list.push({
        file,
        name,
        title: typeof meta.title === 'string' && meta.title ? meta.title : '',
        category,
        kills: Number(meta.kills) || 0,
        favorite: meta.favorite === true,
        time: Number(meta.createdAt) || stat.mtimeMs,
        bytes: stat.size,
        thumb: all.has(`${name}.jpg`) ? path.join(dir, `${name}.jpg`) : thumbFor(file, stat),
      });
    }
  }
  return list.sort((a, b) => b.time - a.time).slice(0, 60);
}

/* ----------------------------------------------------------------------- IPC */

ipcMain.handle('open', async () => {
  const result = await dialog.showOpenDialog(hub.window, {
    title: 'Medien hinzufügen',
    properties: ['openFile', 'multiSelections'],
    filters: [
      { name: 'Videos, Musik & Bilder', extensions: [...VIDEO_EXT, ...AUDIO_EXT, ...IMAGE_EXT] },
      { name: 'Videos', extensions: VIDEO_EXT },
      { name: 'Musik & Ton', extensions: AUDIO_EXT },
      { name: 'Bilder', extensions: IMAGE_EXT },
    ],
  });
  if (result.canceled) return [];
  const out = [];
  for (const file of result.filePaths) {
    try {
      out.push(await probe(file));
    } catch (error) {
      ctx.send('progress', { phase: 'warn', message: error.message });
    }
  }
  return out;
});

ipcMain.handle('probe', (_event, file) => probe(file));
ipcMain.handle('clips', () => gamingClips());
// Welche Dateien gibt es noch? (gelöschte Medien verschwinden aus dem Projekt)
ipcMain.handle('exists', (_event, files) => (Array.isArray(files) ? files.map((f) => Boolean(f) && fs.existsSync(f)) : []));
// Gaming-Clip: Facecam und Tasten (wie im Gaming Hub) mit ins Projekt übernehmen
ipcMain.handle('clipMeta', (_event, file) => {
  try {
    const meta = JSON.parse(fs.readFileSync(`${file}.json`, 'utf8')) || {};
    const dir = path.dirname(file);
    const camFile = meta.cam?.file ? path.join(dir, path.basename(meta.cam.file)) : '';
    return {
      keys: Array.isArray(meta.keys) ? meta.keys : [],
      keysSpan: Number(meta.keysSpan) || 0,
      keysPos: meta.keysPos || null,
      keysScale: Number(meta.keysScale) || 1,
      showKeys: meta.showKeys !== false && !meta.burned,
      cam: camFile && fs.existsSync(camFile) ? { file: camFile, offsetMs: Number(meta.cam.offsetMs) || 0, x: meta.cam.x ?? 0.74, y: meta.cam.y ?? 0.06, w: meta.cam.w ?? 0.24, visible: meta.cam.visible !== false, round: meta.cam.round === true } : null,
    };
  } catch {
    return null;
  }
});
// Tasten-Overlay für den Export: fertige PNG-Bilder je Tastenzustand
ipcMain.handle('keyFrames', (_event, frames) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'revolution-keys-'));
  const list = [];
  frames.forEach((f, i) => {
    const name = `k${i}.png`;
    fs.writeFileSync(path.join(dir, name), Buffer.from(String(f.png).split(',')[1] || '', 'base64'));
    list.push(`file '${name}'`, `duration ${Math.max(0.02, Number(f.d) || 0.04).toFixed(3)}`);
  });
  if (frames.length) list.push(`file 'k${frames.length - 1}.png'`);
  fs.writeFileSync(path.join(dir, 'list.txt'), list.join('\n'));
  return path.join(dir, 'list.txt');
});

/** Peaks for the waveform: mono 2 kHz PCM, reduced to `buckets` maxima. */
ipcMain.handle('waveform', async (_event, file, buckets = 2400) => {
  const child = spawn(ffmpegPath(), ['-hide_banner', '-loglevel', 'error', '-i', file, '-vn', '-ac', '1', '-ar', '2000', '-f', 's16le', '-'], { windowsHide: true });
  const chunks = [];
  child.stdout.on('data', (chunk) => chunks.push(chunk));
  await new Promise((resolve) => child.on('close', resolve));
  const buffer = Buffer.concat(chunks);
  const samples = Math.floor(buffer.length / 2);
  if (!samples) return { peaks: [], seconds: 0 };
  const per = Math.max(1, Math.floor(samples / buckets));
  const peaks = [];
  for (let i = 0; i < samples; i += per) {
    let max = 0;
    for (let j = i; j < Math.min(samples, i + per); j += 1) max = Math.max(max, Math.abs(buffer.readInt16LE(j * 2)));
    peaks.push(max / 32768);
  }
  return { peaks, seconds: samples / 2000 };
});

const proxies = new Map();
/** Formats Chromium cannot play (e.g. some MKV/AVI/HEVC) get a small preview copy. */
ipcMain.handle('proxy', async (_event, info) => {
  if (proxies.has(info.file) && fs.existsSync(proxies.get(info.file))) return proxies.get(info.file);
  const audioOnly = !info.video;
  const out = path.join(os.tmpdir(), `revolution-proxy-${Date.now()}.${audioOnly ? 'm4a' : 'mp4'}`);
  const codec = audioOnly ? ['-vn'] : ['-vf', 'scale=-2:540', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '30'];
  const job = run(['-y', '-i', info.file, ...codec, '-c:a', 'aac', '-b:a', '128k', out], {
    onLine: (line) => {
      const t = /time=(\d+):(\d+):([\d.]+)/.exec(line);
      if (t) ctx.send('progress', { phase: 'proxy', value: Math.min(1, toSeconds(t[1], t[2], t[3]) / info.duration) });
    },
  });
  jobs.add(job);
  try {
    await job.done;
  } finally {
    jobs.delete(job);
  }
  proxies.set(info.file, out);
  return out;
});

/** A voice-over recorded in the editor (webm/opus from MediaRecorder). */
ipcMain.handle('recording', async (_event, bytes) => {
  const dir = path.join(dataDir(), 'Aufnahmen');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toLocaleString('sv-SE').replace(' ', '_').replace(/:/g, '-');
  const file = path.join(dir, `Sprachaufnahme_${stamp}.webm`);
  fs.writeFileSync(file, Buffer.from(bytes));
  const info = await probe(file).catch(() => null);
  // MediaRecorder leaves the duration empty; a quick remux writes it into the file.
  if (!info || !info.duration) {
    const fixed = file.replace(/\.webm$/, '.ogg');
    await run(['-y', '-i', file, '-c:a', 'copy', fixed]).done;
    fs.rmSync(file, { force: true });
    return probe(fixed);
  }
  return info;
});

/** Kamera-Aufnahme (Webcam + Mikrofon) speichern; Umpacken schreibt die Länge in die Datei. */
ipcMain.handle('camrecording', async (_event, bytes) => {
  const dir = path.join(dataDir(), 'Aufnahmen');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toLocaleString('sv-SE').replace(' ', '_').replace(/:/g, '-');
  const raw = path.join(dir, `Kamera_${stamp}.raw.webm`);
  const file = path.join(dir, `Kamera_${stamp}.webm`);
  fs.writeFileSync(raw, Buffer.from(bytes));
  try {
    await run(['-y', '-i', raw, '-c', 'copy', file]).done;
    fs.rmSync(raw, { force: true });
  } catch {
    fs.renameSync(raw, file);
  }
  return probe(file);
});

/* ------------------------------------------------------------- project file */

const projectFile = () => path.join(dataDir(), 'projekt.json');
ipcMain.handle('project:load', () => {
  try {
    return JSON.parse(fs.readFileSync(projectFile(), 'utf8'));
  } catch {
    return null;
  }
});
ipcMain.handle('project:save', (_event, project) => {
  fs.mkdirSync(dataDir(), { recursive: true });
  fs.writeFileSync(`${projectFile()}.tmp`, JSON.stringify(project));
  fs.renameSync(`${projectFile()}.tmp`, projectFile());
  return true;
});

/* ------------------------------------------------------------------ export */

const jobs = new Set();

function fontFile() {
  const candidates =
    process.platform === 'win32'
      ? ['segoeuib.ttf', 'segoeui.ttf', 'arialbd.ttf', 'arial.ttf'].map((name) => path.join(process.env.WINDIR || 'C:\\Windows', 'Fonts', name))
      : ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'];
  return candidates.find((file) => fs.existsSync(file)) || '';
}

const num = (value) => Number(Number(value).toFixed(3));
const colorHex = (value) => (/^#[0-9a-f]{6}$/i.test(value || '') ? `0x${value.slice(1)}` : 'white');

/**
 * Builds one ffmpeg run for the whole timeline: a black canvas, every video/image clip
 * scaled and overlaid in track order (Video 1 below Video 2), titles drawn on top, and all
 * sound (clip audio, music, voice-over) delayed to its place and mixed.
 */
function buildExport(project, { format, quality, height, fps, codec, encoder, bitrate, audioBitrate, range }, tmp) {
  const media = project.media || {};
  const trackById = Object.fromEntries((project.tracks || []).map((t) => [t.id, t]));
  const clips = (project.clips || []).filter((c) => trackById[c.track] && !trackById[c.track].hidden);
  const speedOf = (c) => Math.min(8, Math.max(0.1, Number(c.speed) || 1));
  const length = (c) => (c.kind === 'text' ? c.duration : (c.out - c.in) / speedOf(c));
  const total = Math.max(0.1, ...clips.map((c) => c.start + length(c)));

  const H = Math.max(144, Math.round((Number(height) || 1080) / 2) * 2);
  const W = Math.round((H * 16) / 9 / 2) * 2;
  const FPS = Math.min(120, Math.max(10, Number(fps) || 30));

  const args = ['-y'];
  const inputIndex = new Map();
  const extraInputs = []; // Facecam/Tasten-Eingänge, zählen bei den Indizes mit
  const inputFor = (mediaId) => {
    if (inputIndex.has(mediaId)) return inputIndex.get(mediaId);
    const m = media[mediaId];
    if (!m || !fs.existsSync(m.file)) throw new Error(`Die Datei „${m?.name || mediaId}“ fehlt.`);
    if (m.kind === 'image') args.push('-loop', '1', '-framerate', String(FPS), '-t', String(num(total + 1)), '-i', m.file);
    else args.push('-i', m.file);
    inputIndex.set(mediaId, inputIndex.size + extraInputs.length);
    return inputIndex.get(mediaId);
  };

  const order = (project.tracks || []).map((t) => t.id);
  // Tracks are listed top to bottom like in the editor: the lowest video track is the base layer.
  const visual = clips.filter((c) => trackById[c.track].kind === 'video').sort((a, b) => order.indexOf(b.track) - order.indexOf(a.track) || a.start - b.start);
  const texts = clips.filter((c) => trackById[c.track].kind === 'text').sort((a, b) => a.start - b.start);
  const sounds = clips.filter((c) => {
    const track = trackById[c.track];
    if (track.muted || c.kind === 'text') return false;
    const m = media[c.media];
    return m && m.audio && !c.muted && (c.volume ?? 1) > 0.001;
  });

  const filters = [];
  const withVideo = format !== 'mp3';
  const withAudio = format !== 'gif' && (sounds.length > 0 || format === 'mp3');

  if (withVideo) {
    filters.push(`color=c=black:s=${W}x${H}:r=${FPS}:d=${num(total)},format=yuv420p[base]`);
    let last = 'base';
    visual.forEach((c, i) => {
      const index = inputFor(c.media);
      const sp = speedOf(c);
      const len = length(c);
      const end = c.start + len;
      const pip = c.layout === 'pip';
      const sc = Math.min(4, Math.max(0.05, Number(c.scale) || 1)) * (pip ? 0.34 : 1);
      const w = Math.max(2, Math.round((W * sc) / 2) * 2);
      const h = Math.max(2, Math.round((H * sc) / 2) * 2);
      // Farbe, Effekte, Spiegeln, Drehen, Deckkraft, Ein-/Ausblenden
      const fx = [];
      const br = Number(c.brightness) || 0, ct = Number(c.contrast ?? 1), sa = Number(c.saturation ?? 1), ga = Number(c.gamma ?? 1);
      if (br || ct !== 1 || sa !== 1 || ga !== 1) fx.push(`eq=brightness=${num(br)}:contrast=${num(ct)}:saturation=${num(sa)}:gamma=${num(ga)}`);
      if (Number(c.hue)) fx.push(`hue=h=${num(c.hue)}`);
      if (Number(c.blur) > 0) fx.push(`gblur=sigma=${num(Number(c.blur) * (H / 1080) * 1.5)}`);
      if (Number(c.sharpen) > 0) fx.push(`unsharp=5:5:${num(Number(c.sharpen) * 1.5)}`);
      if (c.effect === 'bw') fx.push('hue=s=0');
      if (c.effect === 'sepia') fx.push('colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131');
      if (c.effect === 'negative') fx.push('negate');
      if (c.effect === 'vintage') fx.push('curves=preset=vintage');
      if (c.effect === 'vignette') fx.push('vignette=PI/4');
      if (c.effect === 'grain') fx.push('noise=alls=18:allf=t');
      if (c.effect === 'pixel') fx.push(`scale=iw/16:ih/16,scale=iw*16:ih*16:flags=neighbor`);
      if (c.effect === 'glitch') fx.push('rgbashift=rh=6:bh=-6,noise=alls=10:allf=t');
      if (c.effect === 'edge') fx.push('edgedetect=mode=colormix:high=0.2:low=0.05');
      if (c.effect === 'posterize') fx.push("lutrgb=r='floor(val/64)*64+32':g='floor(val/64)*64+32':b='floor(val/64)*64+32'");
      if (c.effect === 'thermal') fx.push('format=gbrp,pseudocolor=p=heat');
      if (c.effect === 'cyber') fx.push('colorbalance=rs=0.25:gs=-0.15:bs=0.3:rh=0.15:bh=0.2');
      if (c.effect === 'sunset') fx.push('colorbalance=rs=0.2:gs=0.05:bs=-0.2:rm=0.15:bm=-0.1');
      if (c.effect === 'dream') fx.push('gblur=sigma=2,eq=brightness=0.04:saturation=1.1');
      if (c.effect === 'crush') fx.push('curves=preset=strong_contrast'); 
      if (c.flipH) fx.push('hflip');
      if (c.flipV) fx.push('vflip');
      const fxs = fx.length ? `${fx.join(',')},` : '';
      const rot = Number(c.rotation) || 0;
      const rotF = rot ? `,rotate=${num((rot * Math.PI) / 180)}:c=none:ow=rotw(${num((rot * Math.PI) / 180)}):oh=roth(${num((rot * Math.PI) / 180)})` : '';
      const op = Math.min(1, Math.max(0, Number(c.opacity ?? 1)));
      const opF = op < 1 ? `,colorchannelmixer=aa=${num(op)}` : '';
      const fi = Number(c.fadeIn) || 0, fo = Number(c.fadeOut) || 0;
      const fadeF = (fi ? `,fade=t=in:st=0:d=${num(fi)}:alpha=1` : '') + (fo ? `,fade=t=out:st=${num(Math.max(0, len - fo))}:d=${num(fo)}:alpha=1` : '');
      filters.push(
        `[${index}:v]trim=start=${num(c.in)}:end=${num(c.out)},setpts=(PTS-STARTPTS)/${num(sp)},fps=${FPS},${fxs}format=yuva420p,` +
          `scale=${w}:${h}:force_original_aspect_ratio=decrease,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=black@0,setsar=1,` +
          `format=yuva420p${rotF}${opF}${fadeF},setpts=PTS+${num(c.start)}/TB[v${i}]`,
      );
      const px = Number(c.x) || 0, py = Number(c.y) || 0; // Versatz in Prozent der Bildgröße
      const x = pip ? `main_w-overlay_w-${Math.round(W * 0.025)}+${Math.round(W * px)}` : `(main_w-overlay_w)/2+${Math.round(W * px)}`;
      const y = pip ? `main_h-overlay_h-${Math.round(H * 0.04)}+${Math.round(H * py)}` : `(main_h-overlay_h)/2+${Math.round(H * py)}`;
      filters.push(`[${last}][v${i}]overlay=x=${x}:y=${y}:eof_action=pass:enable='between(t,${num(c.start)},${num(end)})'[o${i}]`);
      last = `o${i}`;

      // Facecam aus dem Gaming-Clip
      const cam = c.gaming?.cam;
      if (cam?.on && cam.file && fs.existsSync(cam.file)) {
        args.push('-i', cam.file);
        const ci = inputIndex.size + extraInputs.length;
        extraInputs.push(cam.file);
        const camStart = Math.max(0, c.in - (Number(cam.offsetMs) || 0) / 1000);
        const lead = Math.max(0, (Number(cam.offsetMs) || 0) / 1000 - c.in) / sp;
        const cw = Math.max(16, Math.round((W * (Number(cam.w) || 0.24)) / 2) * 2);
        const round = cam.round ? `,format=yuva420p,geq=lum='p(X,Y)':cb='p(X,Y)':cr='p(X,Y)':a='if(gt(hypot(X-W/2,Y-H/2),min(W,H)/2),0,255)'` : ',format=yuva420p';
        const crop = cam.round ? `,crop='min(iw,ih)':'min(iw,ih)'` : '';
        filters.push(`[${ci}:v]trim=start=${num(camStart)}:end=${num(camStart + (c.out - c.in))},setpts=(PTS-STARTPTS)/${num(sp)},fps=${FPS}${crop},scale=${cw}:-2${round},setpts=PTS+${num(c.start + lead)}/TB[cam${i}]`);
        filters.push(`[${last}][cam${i}]overlay=x=${Math.round(W * (Number(cam.x) || 0))}:y=${Math.round(H * (Number(cam.y) || 0))}:eof_action=pass:enable='between(t,${num(c.start)},${num(end)})'[oc${i}]`);
        last = `oc${i}`;
      }
      // Tasten-Overlay (vorher als PNG-Folge erzeugt)
      if (c.gaming?.keysList && fs.existsSync(c.gaming.keysList)) {
        args.push('-f', 'concat', '-safe', '0', '-i', c.gaming.keysList);
        const ki = inputIndex.size + extraInputs.length;
        extraInputs.push(c.gaming.keysList);
        filters.push(`[${ki}:v]fps=${FPS},scale=${W}:${H},format=yuva420p,setpts=PTS-STARTPTS+${num(c.start)}/TB[keys${i}]`);
        filters.push(`[${last}][keys${i}]overlay=0:0:eof_action=pass:enable='between(t,${num(c.start)},${num(end)})'[ok${i}]`);
        last = `ok${i}`;
      }
    });

    const font = fontFile();
    if (texts.length && font) fs.copyFileSync(font, path.join(tmp, 'font.ttf'));
    texts.forEach((c, i) => {
      if (!font || !String(c.text || '').trim()) return;
      fs.writeFileSync(path.join(tmp, `t${i}.txt`), String(c.text));
      const s = num(c.start);
      const e = num(c.start + c.duration);
      const size = Math.round(((Number(c.size) || 64) * H) / 1080);
      const margin = Math.round(H * 0.08);
      const y = c.position === 'top' ? `${margin}` : c.position === 'center' ? '(h-text_h)/2' : `h-text_h-${margin}`;
      const fade = Math.min(0.35, (e - s) / 3);
      const alpha = `if(lt(t,${s}+${num(fade)}),(t-${s})/${num(fade)},if(gt(t,${e}-${num(fade)}),(${e}-t)/${num(fade)},1))`;
      const box = c.box !== false ? `:box=1:boxcolor=black@0.5:boxborderw=${Math.round(size * 0.35)}` : ':shadowcolor=black@0.7:shadowx=2:shadowy=2';
      filters.push(
        `[${last}]drawtext=fontfile=font.ttf:textfile=t${i}.txt:expansion=none:fontcolor=${colorHex(c.color)}:fontsize=${size}:line_spacing=${Math.round(size * 0.2)}` +
          `:x=(w-text_w)/2:y=${y}${box}:alpha='${alpha}':enable='between(t,${s},${e})'[x${i}]`,
      );
      last = `x${i}`;
    });

    if (format === 'gif') {
      const gw = Math.min(W, 960);
      filters.push(`[${last}]fps=15,scale=${gw}:-1:flags=lanczos,split[g1][g2];[g1]palettegen=stats_mode=diff[p];[g2][p]paletteuse=dither=sierra2_4a[vout]`);
    } else filters.push(`[${last}]format=yuv420p[vout]`);
  }

  if (withAudio) {
    const labels = [];
    sounds.forEach((c, i) => {
      const index = inputFor(c.media);
      const delay = Math.round(c.start * 1000);
      const volume = num(Math.max(0, (c.volume ?? 1) * (trackById[c.track].volume ?? 1)));
      // Tempo: atempo kann nur 0,5–2 → bei Bedarf mehrfach
      let sp = speedOf(c);
      const tempo = [];
      while (sp > 2) {
        tempo.push('atempo=2');
        sp /= 2;
      }
      while (sp < 0.5) {
        tempo.push('atempo=0.5');
        sp /= 0.5;
      }
      if (Math.abs(sp - 1) > 0.001) tempo.push(`atempo=${num(sp)}`);
      const len = length(c);
      const fi = Number(c.fadeIn) || 0, fo = Number(c.fadeOut) || 0;
      const fades = (fi ? `,afade=t=in:st=0:d=${num(fi)}` : '') + (fo ? `,afade=t=out:st=${num(Math.max(0, len - fo))}:d=${num(fo)}` : '');
      const pan = Number(c.pan) || 0;
      const panF = pan ? `,stereotools=balance_out=${num(pan)}` : '';
      const eqF = (Number(c.bass) ? `,bass=g=${num(c.bass)}` : '') + (Number(c.treble) ? `,treble=g=${num(c.treble)}` : '') + (c.echo ? ',aecho=0.8:0.7:60:0.3' : '') + (c.denoise ? ',afftdn' : '');
      filters.push(`[${index}:a]atrim=start=${num(c.in)}:end=${num(c.out)},asetpts=PTS-STARTPTS,aresample=48000${tempo.length ? `,${tempo.join(',')}` : ''}${eqF}${fades}${panF},volume=${volume},adelay=${delay}:all=1[a${i}]`);
      labels.push(`[a${i}]`);
    });
    if (labels.length === 0) filters.push(`anullsrc=r=48000:cl=stereo,atrim=0:${num(total)}[aout]`);
    else if (labels.length === 1) filters.push(`${labels[0]}apad,atrim=0:${num(total)}[aout]`);
    else filters.push(`${labels.join('')}amix=inputs=${labels.length}:duration=longest:normalize=0,apad,atrim=0:${num(total)}[aout]`);
  }

  if (filters.length === 0) throw new Error('Die Zeitleiste ist leer.');
  if (inputIndex.size === 0) args.push('-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo');
  args.push('-filter_complex', filters.join(';'));
  if (withVideo) args.push('-map', '[vout]');
  if (withAudio) args.push('-map', '[aout]');

  if (format === 'gif') args.push('-loop', '0');
  else if (format === 'mp3') args.push('-c:a', 'libmp3lame', '-q:a', '2');
  else if (format === 'webm') {
    const crf = { high: 24, medium: 32, small: 40 }[quality] || 32;
    args.push('-c:v', 'libvpx-vp9', '-crf', String(crf), '-b:v', '0', '-row-mt', '1', '-pix_fmt', 'yuv420p', '-r', String(FPS));
    if (withAudio) args.push('-c:a', 'libopus', '-b:a', '160k');
  } else {
    const crf = { high: 18, medium: 22, small: 28 }[quality] || 22;
    const enc = encoder || (codec === 'h265' ? 'libx265' : 'libx264');
    if (/nvenc/.test(enc)) args.push('-c:v', enc, '-preset', 'p5', '-cq', String(crf + 2));
    else if (/qsv/.test(enc)) args.push('-c:v', enc, '-global_quality', String(crf + 2));
    else if (/amf/.test(enc)) args.push('-c:v', enc, '-quality', 'quality', '-qp_i', String(crf), '-qp_p', String(crf + 2));
    else args.push('-c:v', enc, '-preset', 'medium', '-crf', String(crf));
    if (bitrate) args.push('-b:v', `${bitrate}k`, '-maxrate', `${Math.round(bitrate * 1.5)}k`, '-bufsize', `${bitrate * 2}k`);
    args.push('-pix_fmt', 'yuv420p', '-r', String(FPS));
    if (/265|hevc/.test(enc) && format !== 'mkv') args.push('-tag:v', 'hvc1');
    if (withAudio) args.push('-c:a', 'aac', '-b:a', `${audioBitrate || 192}k`);
    if (format === 'mp4' || format === 'mov') args.push('-movflags', '+faststart');
  }
  if (range && Number.isFinite(range.from) && Number.isFinite(range.to) && range.to > range.from) {
    args.push('-ss', String(num(range.from)), '-t', String(num(range.to - range.from)));
    return { args, total: range.to - range.from };
  }
  args.push('-t', String(num(total)));
  return { args, total };
}

ipcMain.handle('export', async (_event, { project, format = 'mp4', quality = 'medium', height = 1080, fps = 30, target, codec = 'h264', hw = false, bitrate = 0, audioBitrate = 192, range = null }) => {
  const ext = ['gif', 'mp3', 'mov', 'mkv', 'webm', 'avi'].includes(format) ? format : 'mp4';
  let out = target;
  if (!out) {
    const firstClip = (project.clips || []).find((c) => project.media?.[c.media]);
    const base = (project.name || project.media?.[firstClip?.media]?.name || 'Video').replace(/\.[^.]+$/, '');
    const result = await dialog.showSaveDialog(hub.window, {
      title: 'Video exportieren',
      defaultPath: path.join(app.getPath('videos'), `${base}_schnitt.${ext}`),
      filters: [{ name: ext.toUpperCase(), extensions: [ext] }],
    });
    if (result.canceled || !result.filePath) return null;
    out = result.filePath;
  }
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'revolution-export-'));
  try {
    // Hardware-Encoder (NVIDIA → Intel → AMD) versuchen, sonst Software
    const h265 = codec === 'h265';
    const encoders = hw && !['gif', 'mp3', 'webm'].includes(format) ? (h265 ? ['hevc_nvenc', 'hevc_qsv', 'hevc_amf'] : ['h264_nvenc', 'h264_qsv', 'h264_amf']) : [];
    encoders.push(null);
    let lastError = null;
    for (const encoder of encoders) {
      try {
        const { args, total } = buildExport(project, { format, quality, height, fps, codec, encoder, bitrate: Number(bitrate) || 0, audioBitrate: Number(audioBitrate) || 192, range }, tmp);
        args.push(out);
        const job = run(args, {
          cwd: tmp,
          onLine: (line) => {
            const t = /time=(\d+):(\d+):([\d.]+)/.exec(line);
            if (t) ctx.send('progress', { phase: 'export', value: Math.min(1, toSeconds(t[1], t[2], t[3]) / total), encoder: encoder || 'cpu' });
          },
        });
        jobs.add(job);
        try {
          await job.done;
        } finally {
          jobs.delete(job);
        }
        lastError = null;
        break;
      } catch (error) {
        lastError = error;
        if (/abgebrochen|killed|SIGTERM/i.test(String(error?.message))) break;
      }
    }
    if (lastError) throw lastError;
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  hub.notify('Export fertig', path.basename(out), { app: 'Video-Schnitt', open: out });
  return out;
});

// Einzelnes Bild an der Abspielposition als PNG/JPG speichern
ipcMain.handle('frame', async (_event, { project, time, height = 1080 }) => {
  const result = await dialog.showSaveDialog(hub.window, { title: 'Frame speichern', defaultPath: path.join(app.getPath('pictures'), `frame_${Math.round(time * 1000)}.png`), filters: [{ name: 'PNG', extensions: ['png'] }, { name: 'JPG', extensions: ['jpg'] }] });
  if (result.canceled || !result.filePath) return null;
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'revolution-frame-'));
  try {
    const { args } = buildExport(project, { format: 'mp4', quality: 'high', height, fps: 30 }, tmp);
    // Video-Ausgabeoptionen weglassen: nur ein Bild
    const map = args.indexOf('-map');
    const head = args.slice(0, map);
    head.push('-map', '[vout]', '-ss', String(Math.max(0, Number(time) || 0)), '-frames:v', '1', result.filePath);
    const job = run(head, { cwd: tmp });
    await job.done;
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  return result.filePath;
});

ipcMain.handle('cancel', () => {
  for (const job of jobs) job.child.kill();
  return true;
});

ipcMain.handle('reveal', (_event, file) => shell.showItemInFolder(file));

app.on('will-quit', () => {
  for (const job of jobs) job.child.kill();
});

module.exports = { buildExport, probe };
