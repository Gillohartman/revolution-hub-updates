const stack = document.getElementById('stack');
const crosshairCanvas = document.getElementById('crosshair');
const noticeNode = document.getElementById('notice');
const noticeTitle = document.getElementById('notice-title');
const noticeText = document.getElementById('notice-text');
const VISIBLE_MS = 3600;
const GAP_MS = 260;
const MAX_QUEUE = 12;

const queue = [];
let pumping = false;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const el = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
};

function renderCard(card) {
  const state = card.state === 'down' ? 'down' : 'dead';
  const root = el('div', `kill-card ${state}`);
  root.appendChild(el('div', 'accent'));

  const body = el('div', 'body');
  const kicker = el('p', 'kicker', state === 'down' ? 'Down · lebt noch' : 'Eliminiert');
  if (card.recognized) kicker.appendChild(el('span', 'badge known', 'Bekannt'));
  else if (card.bot) kicker.appendChild(el('span', 'badge', 'Bot'));
  body.appendChild(kicker);

  body.appendChild(el('h1', 'name', card.name || 'Unbekannt'));

  const meta = el('p', 'meta');
  const parts = [];
  if (card.times) parts.push(['Erledigt', card.times + '×']);
  if (card.kills !== null && card.kills !== undefined) parts.push(['Kills', String(card.kills)]);
  if (card.level) parts.push(['Level', String(card.level)]);
  if (card.placement) parts.push(['Platz', '#' + card.placement]);
  if (card.damage) parts.push(['Schaden', '≈ ' + card.damage]);

  parts.forEach(([label, value], index) => {
    if (index > 0) meta.appendChild(el('span', 'dot', '·'));
    const span = el('span');
    span.appendChild(el('span', '', label + ': '));
    span.appendChild(el('b', '', value));
    meta.appendChild(span);
  });
  body.appendChild(meta);

  const weaponText = [card.weapon, card.distance ? Math.round(card.distance) + ' m' : '']
    .filter(Boolean)
    .join(' · ');
  if (weaponText) body.appendChild(el('p', 'weapon', weaponText));

  root.appendChild(body);
  return root;
}

// Fuer Screenshot-/Vorschau-Skripte.
window.__renderCard = renderCard;

async function pump() {
  if (pumping) return;
  pumping = true;

  while (queue.length > 0) {
    const node = renderCard(queue.shift());
    stack.replaceChildren(node);
    requestAnimationFrame(() => node.classList.add('in'));
    await sleep(VISIBLE_MS);
    node.classList.remove('in');
    await sleep(GAP_MS);
    if (stack.firstChild === node) node.remove();
  }

  pumping = false;
  stack.replaceChildren();
  // Crosshair bleibt ggf. stehen – das Hauptfenster entscheidet, ob versteckt wird.
  if (window.killOverlay) window.killOverlay.idle();
}

/* ---------------- Crosshair ---------------- */

function drawCrosshair(canvas, crosshair) {
  const size = crosshair.pixels.length;
  const px = Math.max(1, Math.round(Number(crosshair.pixelSize) || 4));
  const border = crosshair.outline ? 1 : 0;
  const total = size * px + border * 2;
  const dpr = Math.max(1, window.devicePixelRatio || 1);

  canvas.width = Math.round(total * dpr);
  canvas.height = Math.round(total * dpr);
  canvas.style.width = `${total}px`;
  canvas.style.height = `${total}px`;
  canvas.style.opacity = String(Number(crosshair.opacity) || 1);

  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Erst die schwarze Kontur als Silhouette, dann die Farben darüber –
  // so bleiben die Arme durchgehend und nur der Rand wird abgesetzt.
  if (border) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
    for (let y = 0; y < size; y += 1) {
      for (let x = 0; x < size; x += 1) {
        if (!crosshair.pixels[y][x]) continue;
        ctx.fillRect(x * px * dpr, y * px * dpr, (px + 2) * dpr, (px + 2) * dpr);
      }
    }
  }

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const color = crosshair.pixels[y][x];
      if (!color) continue;
      ctx.fillStyle = color;
      ctx.fillRect((x * px + border) * dpr, (y * px + border) * dpr, px * dpr, px * dpr);
    }
  }
}

function applyCrosshair(payload) {
  const crosshair = payload?.crosshair;
  if (!crosshair || !crosshair.enabled || !payload.visible) {
    crosshairCanvas.hidden = true;
    return;
  }
  drawCrosshair(crosshairCanvas, crosshair);
  crosshairCanvas.hidden = false;
}

/* ---------------- Hinweis („Tracker aktiv“) ---------------- */

let noticeTimer = null;

function showNotice(payload) {
  if (!payload) return;
  noticeTitle.textContent = payload.title || '';
  noticeText.textContent = payload.text || '';
  noticeNode.hidden = false;
  noticeNode.classList.remove('in');
  void noticeNode.offsetWidth;
  noticeNode.classList.add('in');
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => {
    noticeNode.classList.remove('in');
    setTimeout(() => {
      if (!noticeNode.classList.contains('in')) noticeNode.hidden = true;
    }, 350);
  }, Math.min(15000, Math.max(1500, Number(payload.ms) || 6000)));
}

function enqueue(cards) {
  if (!Array.isArray(cards) || cards.length === 0) return;
  for (const card of cards.slice(0, MAX_QUEUE)) {
    queue.push(card);
  }
  pump();
}

if (window.killOverlay) {
  window.killOverlay.onCards(enqueue);
  window.killOverlay.onConfig(applyCrosshair);
  window.killOverlay.onNotice(showNotice);
} else {
  // Nur fuer die Vorschau im Browser: Beispieldaten im Dauerbetrieb.
  document.body.classList.add('demo');
  const mid = 7;
  const demoPixels = Array.from({ length: 15 }, (_, y) =>
    Array.from({ length: 15 }, (_, x) => {
      if (Math.abs(x - mid) <= 2 && Math.abs(y - mid) <= 2) return '';
      return x === mid || y === mid ? '#9df7c8' : '';
    }),
  );
  applyCrosshair({
    crosshair: { enabled: true, pixelSize: 4, opacity: 0.95, outline: true, pixels: demoPixels },
    visible: true,
  });
  showNotice({
    title: 'Revolution Tracker aktiv',
    text: 'Kill-Feed wird gelesen · Knock gelb, Kill rot',
    ms: 600000,
  });
  const demo = [
    { name: 'Sharkboy61', state: 'down', recognized: true, times: 3, damage: 87, kills: 1, level: 33, placement: 23, weapon: 'Heavy-Sturmgewehr', distance: 46 },
    { name: 'Famous_king_31', state: 'dead', damage: 120, kills: 3, level: 31, placement: 39, weapon: 'Sturmgewehr', distance: 24 },
    { name: 'Bot_Waechter', state: 'dead', bot: true, damage: 45, weapon: 'Schrotflinte', distance: 6 },
  ];
  enqueue(demo);
  setInterval(() => enqueue(demo), 6000);
}

// Screenshot-Modus: dunkler Spielhintergrund statt Transparenz.
if (new URLSearchParams(location.search).has('shot')) document.body.classList.add('shot');
