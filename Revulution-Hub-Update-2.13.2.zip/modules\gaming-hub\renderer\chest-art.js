'use strict';

/* Eigene Truhen-Grafik (SVG, 64×64): Holz, Goldbeschläge, Schloss. Der Deckel ist
 * eine eigene Gruppe, damit er sich beim Öffnen anheben kann. */
window.CHEST_ART = (id = 'c') => `
  <defs>
    <linearGradient id="${id}-wood" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#d9973f"/><stop offset="0.55" stop-color="#b06a26"/><stop offset="1" stop-color="#7c4417"/>
    </linearGradient>
    <linearGradient id="${id}-lid" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#e9ad55"/><stop offset="1" stop-color="#a8622a"/>
    </linearGradient>
    <linearGradient id="${id}-gold" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#fff0b0"/><stop offset="0.45" stop-color="#f3c34c"/><stop offset="1" stop-color="#b9821c"/>
    </linearGradient>
    <radialGradient id="${id}-glow" cx="0.5" cy="1" r="0.8">
      <stop offset="0" stop-color="#fff6c8"/><stop offset="0.5" stop-color="#ffcf4d" stop-opacity="0.85"/><stop offset="1" stop-color="#ffb020" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect class="inner" x="10" y="20" width="44" height="12" rx="3" fill="url(#${id}-glow)"/>
  <g class="body">
    <rect x="8" y="29" width="48" height="26" rx="4" fill="url(#${id}-wood)" stroke="#5a300f" stroke-width="1.6"/>
    <path d="M10 38h44M10 46h44" stroke="#8a4c1b" stroke-width="1.2" opacity=".55"/>
    <rect x="14" y="29" width="6" height="26" fill="url(#${id}-gold)" stroke="#8a5d12" stroke-width=".8"/>
    <rect x="44" y="29" width="6" height="26" fill="url(#${id}-gold)" stroke="#8a5d12" stroke-width=".8"/>
    <rect x="26" y="30" width="12" height="13" rx="2.2" fill="url(#${id}-gold)" stroke="#8a5d12" stroke-width=".9"/>
    <circle cx="32" cy="35.3" r="1.9" fill="#3b220b"/>
    <path d="M31.1 36.5h1.8l.6 3.6h-3z" fill="#3b220b"/>
  </g>
  <g class="lid">
    <path d="M8 30v-6c0-8 9-12.5 24-12.5S56 16 56 24v6z" fill="url(#${id}-lid)" stroke="#5a300f" stroke-width="1.6" stroke-linejoin="round"/>
    <path d="M11 21.5c4-4.5 11-6.5 21-6.5s17 2 21 6.5" stroke="#fff3c9" stroke-width="1.2" fill="none" opacity=".45"/>
    <path d="M14 30v-7.5c0-3.2 1-5.4 3-6.8l3-1v15.3z" fill="url(#${id}-gold)" stroke="#8a5d12" stroke-width=".8"/>
    <path d="M50 30v-7.5c0-3.2-1-5.4-3-6.8l-3-1v15.3z" fill="url(#${id}-gold)" stroke="#8a5d12" stroke-width=".8"/>
    <rect x="7" y="28" width="50" height="3.4" rx="1.6" fill="url(#${id}-gold)" stroke="#8a5d12" stroke-width=".8"/>
  </g>`;
