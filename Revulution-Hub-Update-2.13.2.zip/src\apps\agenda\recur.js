'use strict';

/*
 * Termin-Logik, geteilt von Hauptprozess (Erinnerungen) und Oberfläche.
 * Das Format entspricht 1:1 der calendar.json der Orbit Island, damit beide dieselben
 * Termine sehen und bearbeiten.
 */
(function (root) {
  const DAY = 86400000;

  /** Exklusives Ende ganztägiger Termine → letzter Tag. */
  function lastDay(start, end, allDay) {
    const e = new Date(end);
    if (allDay && e.getHours() === 0 && e.getMinutes() === 0 && e > start) return new Date(e.getTime() - 1);
    return e;
  }

  /** Alle Vorkommen eines Termins zwischen from und to (Date). */
  function occurrences(evt, from, to, max = 400) {
    const start = new Date(evt.Start);
    const end = new Date(evt.End);
    let dur = end - start;
    if (!(dur >= 0)) dur = 30 * 60000;
    const out = [];
    const freq = evt.Frequency || 'None';
    if (freq === 'None') {
      if (end >= from && start <= to) out.push({ evt, start, end });
      return out;
    }
    const interval = Math.max(1, Number(evt.Interval) || 1);
    const until = evt.Until ? new Date(evt.Until) : null;
    const count = Number(evt.Count) || 0;
    let n = 0;
    for (let i = 0; i < 5000 && out.length < max; i += 1) {
      const s = new Date(start);
      if (freq === 'Daily') s.setDate(s.getDate() + i * interval);
      else if (freq === 'Weekly') s.setDate(s.getDate() + i * 7 * interval);
      else if (freq === 'Monthly') s.setMonth(s.getMonth() + i * interval);
      else if (freq === 'Yearly') s.setFullYear(s.getFullYear() + i * interval);
      else break;
      if (until && s > until) break;
      n += 1;
      if (count && n > count) break;
      const e = new Date(s.getTime() + dur);
      if (s > to) break;
      if (e >= from) out.push({ evt, start: s, end: e });
    }
    return out;
  }

  function agenda(events, from, to) {
    const list = [];
    for (const evt of events) list.push(...occurrences(evt, from, to));
    return list.sort((a, b) => a.start - b.start);
  }

  /** Lokale Zeit mit Zeitzonen-Versatz, wie .NET sie schreibt: 2026-11-10T21:00:00+01:00 */
  function isoLocal(date) {
    const d = new Date(date);
    const pad = (v) => String(Math.floor(Math.abs(v))).padStart(2, '0');
    const off = -d.getTimezoneOffset();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}${off >= 0 ? '+' : '-'}${pad(off / 60)}:${pad(off % 60)}`;
  }

  /** Fällige Erinnerungen (gleiche Regeln wie in der Island). */
  function dueReminders(events, now, fired) {
    const due = [];
    for (const occ of agenda(events, new Date(now - DAY), new Date(now + 8 * DAY))) {
      const evt = occ.evt;
      const leads = [];
      if (evt.Reminder) leads.push(Number(evt.ReminderMinutes) >= 0 ? Number(evt.ReminderMinutes) : 10);
      if (Number(evt.ReminderMinutes2) >= 0 && evt.ReminderMinutes2 !== null && evt.ReminderMinutes2 !== undefined) leads.push(Number(evt.ReminderMinutes2));
      let best = null;
      for (let lead of [...new Set(leads)]) {
        let anchor = occ.start;
        if (evt.AllDay) {
          anchor = new Date(occ.start);
          anchor.setHours(8, 0, 0, 0);
          if (lead < 1440) lead = 0;
        }
        const at = anchor.getTime() - lead * 60000;
        if (now < at || now > anchor.getTime() + 60000) continue;
        const key = `${evt.Id}|${occ.start.getTime()}|${lead}`;
        if (fired.has(key)) continue;
        fired.add(key);
        if (!best || lead < best.lead) best = { occ, lead };
      }
      if (best) due.push(best);
    }
    return due;
  }

  const api = { occurrences, agenda, isoLocal, dueReminders, lastDay, DAY };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Recur = api;
})(typeof window !== 'undefined' ? window : globalThis);
