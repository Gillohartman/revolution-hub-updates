'use strict';

/*
 * Updates über das Internet.
 * Der Hub liest eine kleine Datei „update.json“ von einer Adresse, die du in den Optionen
 * einträgst (z. B. aus einem GitHub-Repository):
 *   { "version": "2.6.0", "url": "https://…/Revolution-Hub-Update-2.6.0.zip", "sha256": "…", "notes": "…" }
 * Ist die Version neuer, lädt er das Paket, prüft die Prüfsumme, ersetzt die App-Dateien
 * und startet neu. Erstellt wird beides mit scripts\publish-update.ps1.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { app, net } = require('electron');

const newer = (a, b) => {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0), pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i += 1) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
};
const httpsUrl = (value) => {
  try {
    const u = new URL(String(value || '').trim());
    return u.protocol === 'https:' ? u.toString() : '';
  } catch {
    return '';
  }
};

class Updater {
  constructor({ getUrl, onProgress, beforeIsland }) {
    this.beforeIsland = beforeIsland;
    this.getUrl = getUrl;
    this.onProgress = onProgress || (() => {});
    this.found = null;
    this.busy = false;
  }

  /** Nachsehen, ob es eine neuere Version gibt. */
  async check() {
    const url = httpsUrl(this.getUrl());
    const current = app.getVersion();
    if (!url) return { ok: false, current, error: 'Noch keine Update-Adresse eingetragen.' };
    try {
      const res = await net.fetch(`${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`, { headers: { 'User-Agent': 'Revolution-Hub', 'Cache-Control': 'no-cache' } });
      if (!res.ok) throw new Error(`Adresse nicht erreichbar (${res.status})`);
      const m = await res.json();
      const version = String(m.version || '').trim();
      const zip = httpsUrl(new URL(String(m.url || ''), url).toString());
      if (!/^\d+\.\d+\.\d+$/.test(version) || !zip) throw new Error('Die Update-Datei ist unvollständig (version/url fehlen).');
      const available = newer(version, current);
      this.found = available ? { version, url: zip, sha256: String(m.sha256 || '').toLowerCase(), notes: String(m.notes || '').slice(0, 600) } : null;
      return { ok: true, current, available, version, notes: this.found?.notes || '' };
    } catch (error) {
      return { ok: false, current, error: String(error?.message || error) };
    }
  }

  /** Paket laden, prüfen, entpacken und neu starten. */
  async install() {
    if (this.busy) throw new Error('Ein Update läuft bereits.');
    if (!this.found) throw new Error('Kein Update gefunden – bitte zuerst suchen.');
    if (!app.isPackaged) throw new Error('Updates gibt es nur in der installierten App (nicht im Entwicklungsmodus).');
    this.busy = true;
    const f = this.found;
    const tmp = path.join(os.tmpdir(), `revhub-update-${Date.now()}`);
    try {
      this.onProgress({ step: 'download', pct: 0 });
      const res = await net.fetch(f.url, { headers: { 'User-Agent': 'Revolution-Hub' } });
      if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
      const total = Number(res.headers.get('content-length')) || 0;
      const chunks = [];
      let got = 0;
      const reader = res.body.getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(Buffer.from(value));
        got += value.length;
        if (got > 400 * 1024 * 1024) throw new Error('Das Paket ist zu groß.');
        this.onProgress({ step: 'download', pct: total ? Math.round((got / total) * 100) : 0 });
      }
      const data = Buffer.concat(chunks);
      const hash = crypto.createHash('sha256').update(data).digest('hex');
      if (f.sha256 && f.sha256 !== hash) throw new Error('Die Prüfsumme stimmt nicht – das Paket wurde nicht eingespielt.');
      fs.mkdirSync(tmp, { recursive: true });
      const zip = path.join(tmp, 'update.zip');
      const out = path.join(tmp, 'app');
      fs.writeFileSync(zip, data);
      this.onProgress({ step: 'unpack', pct: 100 });
      await new Promise((resolve, reject) => {
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${out.replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 120000 }, (error) => (error ? reject(new Error('Entpacken fehlgeschlagen.')) : resolve()));
      });
      // Nur einspielen, wenn das Paket wirklich wie die App aussieht
      const pkgFile = path.join(out, 'package.json');
      if (!fs.existsSync(path.join(out, 'src', 'main', 'main.js')) || !fs.existsSync(pkgFile)) throw new Error('Das Paket enthält keine gültige App.');
      const pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf8'));
      if (pkg.name !== 'revolution-hub' || pkg.version !== f.version) throw new Error('Das Paket passt nicht zur angekündigten Version.');
      const appDir = path.join(process.resourcesPath, 'app');
      const backup = path.join(appDir, `src.old-${Date.now()}`);
      this.onProgress({ step: 'install', pct: 100 });
      fs.renameSync(path.join(appDir, 'src'), backup);
      try {
        fs.cpSync(path.join(out, 'src'), path.join(appDir, 'src'), { recursive: true });
        fs.copyFileSync(pkgFile, path.join(appDir, 'package.json'));
        if (fs.existsSync(path.join(out, 'modules'))) fs.cpSync(path.join(out, 'modules'), path.join(appDir, 'modules'), { recursive: true, force: true });
      } catch (error) {
        // zurück zum alten Stand
        fs.rmSync(path.join(appDir, 'src'), { recursive: true, force: true });
        fs.renameSync(backup, path.join(appDir, 'src'));
        throw error;
      }
      fs.rmSync(backup, { recursive: true, force: true });
      // Island (eigene Windows-App) mitliefern, wenn das Paket sie enthält
      if (fs.existsSync(path.join(out, 'orbit', 'OrbitIsland.exe'))) {
        try {
          await this.beforeIsland?.();
          await new Promise((r) => setTimeout(r, 1200));
          fs.cpSync(path.join(out, 'orbit'), path.join(process.resourcesPath, 'orbit'), { recursive: true, force: true });
        } catch (error) {
          console.error('[update] Island nicht ersetzt:', error.message);
        }
      }
      fs.rmSync(tmp, { recursive: true, force: true });
      this.onProgress({ step: 'restart', pct: 100 });
      setTimeout(() => {
        app.relaunch();
        app.exit(0);
      }, 900);
      return { ok: true, version: f.version };
    } catch (error) {
      try {
        fs.rmSync(tmp, { recursive: true, force: true });
      } catch {
        /* egal */
      }
      throw error;
    } finally {
      this.busy = false;
    }
  }
}

module.exports = { Updater, newer, httpsUrl };
