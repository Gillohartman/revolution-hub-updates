'use strict';

/*
 * Handy spiegeln (Android) mit scrcpy (Apache-2.0): Bild übertragen und per Maus und Tastatur
 * bedienen. scrcpy (mit adb) wird beim ersten Mal einmal heruntergeladen (~11 MB).
 * iPhone: Apple erlaubt kein Steuern vom PC aus; Spiegeln ginge nur über AirPlay (nicht eingebaut).
 */
const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');
const { net } = require('electron');

const ZIP = 'https://github.com/Genymobile/scrcpy/releases/download/v5.0.1/scrcpy-win64-v5.0.1.zip';

class Phone {
  constructor({ dir, onChange }) {
    this.dir = path.join(dir, 'scrcpy');
    this.onChange = onChange || (() => {});
    this.proc = null;
    this.installing = 0;
    this.error = '';
  }

  find(name) {
    const walk = (d) => {
      try {
        for (const e of fs.readdirSync(d, { withFileTypes: true })) {
          const f = path.join(d, e.name);
          if (e.isDirectory()) {
            const r = walk(f);
            if (r) return r;
          } else if (e.name.toLowerCase() === name) return f;
        }
      } catch {
        /* fehlt */
      }
      return '';
    };
    return walk(this.dir);
  }

  async install() {
    if (this.find('scrcpy.exe')) return this.status();
    if (this.installing) return this.status();
    this.installing = 0.01;
    this.error = '';
    this.onChange(await this.status());
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      const res = await net.fetch(ZIP);
      if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
      const total = Number(res.headers.get('content-length')) || 11e6;
      const reader = res.body.getReader();
      const chunks = [];
      let got = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(Buffer.from(value));
        got += value.length;
        this.installing = Math.min(0.95, got / total);
      }
      const zip = path.join(this.dir, 'scrcpy.zip');
      fs.writeFileSync(zip, Buffer.concat(chunks));
      await new Promise((resolve, reject) =>
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${this.dir.replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 120000 }, (e) => (e ? reject(new Error('Entpacken fehlgeschlagen')) : resolve())),
      );
      fs.rmSync(zip, { force: true });
    } catch (error) {
      this.error = error.message || String(error);
    }
    this.installing = 0;
    const st = await this.status();
    this.onChange(st);
    return st;
  }

  /** Angeschlossene Android-Geräte (adb). */
  devices() {
    const adb = this.find('adb.exe');
    if (!adb) return Promise.resolve([]);
    return new Promise((resolve) => {
      execFile(adb, ['devices', '-l'], { windowsHide: true, timeout: 8000 }, (_e, out) => {
        const list = String(out || '')
          .split(/\r?\n/)
          .slice(1)
          .map((l) => l.trim())
          .filter(Boolean)
          .map((l) => {
            const [serial, state] = l.split(/\s+/);
            const model = /model:(\S+)/.exec(l)?.[1]?.replace(/_/g, ' ') || serial;
            return { serial, state, model };
          });
        resolve(list);
      });
    });
  }

  async status() {
    return { installed: Boolean(this.find('scrcpy.exe')), installing: this.installing, error: this.error, running: Boolean(this.proc), devices: await this.devices() };
  }

  async start({ serial = '', control = true, stayAwake = true, audio = true } = {}) {
    const exe = this.find('scrcpy.exe');
    if (!exe) throw new Error('Erst die Spiegelung einrichten');
    if (this.proc) return this.status();
    const args = ['--window-title', 'Revulution Phone', '--max-fps', '60', '--video-bit-rate', '8M'];
    if (serial) args.push('-s', serial);
    if (!control) args.push('--no-control');
    if (stayAwake) args.push('--stay-awake');
    if (!audio) args.push('--no-audio');
    this.error = '';
    this.proc = spawn(exe, args, { cwd: path.dirname(exe), windowsHide: true });
    let err = '';
    this.proc.stderr.on('data', (d) => (err += d));
    this.proc.on('exit', (code) => {
      this.proc = null;
      if (code && code !== 0) this.error = (err.split('\n').find((l) => /ERROR/.test(l)) || 'Verbindung beendet').replace(/^ERROR:\s*/, '').trim();
      this.status().then(this.onChange);
    });
    return this.status();
  }

  stop() {
    try {
      this.proc?.kill();
    } catch {
      /* egal */
    }
    this.proc = null;
    return this.status();
  }
}

module.exports = { Phone };
