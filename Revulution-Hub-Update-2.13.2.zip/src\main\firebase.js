'use strict';

/*
 * Kleine Firebase-Anbindung ohne SDK (REST): Firestore lesen/schreiben, Anmeldung mit
 * E-Mail + Passwort und Zwei-Faktor-Anmeldung (TOTP, Authenticator-App).
 *   – KELPI: Projekt der Website (Schematics).
 *   – Konten: eigenes Projekt aus firebase-config.json (sonst ebenfalls KELPI).
 */
const fs = require('fs');
const path = require('path');
const { net } = require('electron');

const KELPI = { apiKey: 'AIzaSyBtm6F0yrIaA05leBSrcTYcvy-JLsngcX8', projectId: 'kelp-1e11a' };
function accountConfig() {
  try {
    const c = JSON.parse(fs.readFileSync(path.join(__dirname, 'firebase-config.json'), 'utf8'));
    if (c.apiKey && c.projectId) return { apiKey: c.apiKey, projectId: c.projectId };
  } catch {
    /* keine eigene Konfiguration */
  }
  return KELPI;
}

/** Firestore-Werte ({ stringValue: … }) in normale JS-Werte umwandeln. */
function fromValue(v) {
  if (!v || typeof v !== 'object') return null;
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('booleanValue' in v) return v.booleanValue;
  if ('timestampValue' in v) return Date.parse(v.timestampValue);
  if ('nullValue' in v) return null;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(fromValue);
  if ('mapValue' in v) return fromFields(v.mapValue.fields || {});
  return null;
}
const fromFields = (fields) => Object.fromEntries(Object.entries(fields || {}).map(([k, v]) => [k, fromValue(v)]));
function toValue(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (typeof v === 'string') return { stringValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(toValue) } };
  return { mapValue: { fields: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, toValue(x)])) } };
}

async function request(url, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await net.fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  if (!res.ok) {
    const code = json?.error?.message || json?.error?.status || `HTTP ${res.status}`;
    const err = new Error(code);
    err.code = code;
    err.status = res.status;
    throw err;
  }
  return json;
}

const MESSAGES = {
  EMAIL_EXISTS: 'Diese E-Mail ist schon registriert – melde dich an.',
  EMAIL_NOT_FOUND: 'Kein Konto mit dieser E-Mail.',
  INVALID_PASSWORD: 'Falsches Passwort.',
  INVALID_LOGIN_CREDENTIALS: 'E-Mail oder Passwort stimmt nicht.',
  USER_DISABLED: 'Dieses Konto ist gesperrt.',
  WEAK_PASSWORD: 'Das Passwort braucht mindestens 6 Zeichen.',
  INVALID_EMAIL: 'Das ist keine gültige E-Mail-Adresse.',
  OPERATION_NOT_ALLOWED: 'Diese Anmeldeart ist in Firebase noch nicht eingeschaltet.',
  TOO_MANY_ATTEMPTS_TRY_LATER: 'Zu viele Versuche – bitte kurz warten.',
  PERMISSION_DENIED: 'Die Datenbank erlaubt das noch nicht (Firestore-Regeln für „revhub_accounts“ fehlen).',
  INVALID_MFA_PENDING_CREDENTIAL: 'Die Anmeldung ist abgelaufen – bitte noch einmal anmelden.',
  INVALID_VERIFICATION_CODE: 'Der Code stimmt nicht. Nimm den aktuellen Code aus deiner Authenticator-App.',
  UNVERIFIED_EMAIL: 'Bestätige zuerst deine E-Mail-Adresse (Link in deinem Postfach), dann kannst du 2FA einschalten.',
  MFA_ENROLLMENT_NOT_FOUND: '2FA ist für dieses Konto nicht eingerichtet.',
  CREDENTIAL_TOO_OLD_LOGIN_AGAIN: 'Bitte melde dich kurz neu an und versuch es dann noch einmal.',
  CONFIGURATION_NOT_FOUND: 'Firebase-Anmeldung ist für dieses Projekt noch nicht eingerichtet.',
};
const friendly = (error) => {
  const raw = String(error?.code || error?.message || '');
  if (/TOTP|MFA.*not.*enabled|mfa.*disabled/i.test(raw)) return new Error('2FA mit Authenticator-App ist im Firebase-Projekt noch nicht eingeschaltet.');
  const key = Object.keys(MESSAGES).find((k) => raw.startsWith(k));
  return new Error(key ? MESSAGES[key] : raw);
};

/** Firebase-Zugriff für ein Projekt. */
function client(cfg) {
  const DOCS = `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents`;
  const AUTH = 'https://identitytoolkit.googleapis.com';
  const key = `key=${cfg.apiKey}`;
  const session = (j) => ({ uid: j.localId || j.user_id, email: j.email, idToken: j.idToken || j.id_token, refreshToken: j.refreshToken || j.refresh_token, expires: Date.now() + (Number(j.expiresIn || j.expires_in || 3600) - 60) * 1000 });
  return {
    cfg,
    async getDoc(docPath, token, mask = null) {
      try {
        const m = Array.isArray(mask) && mask.length ? mask.map((f) => `&mask.fieldPaths=${encodeURIComponent(f)}`).join('') : '';
        const j = await request(`${DOCS}/${docPath}?${key}${m}`, { token });
        return j ? { id: j.name.split('/').pop(), ...fromFields(j.fields) } : null;
      } catch (error) {
        if (error.status === 404) return null;
        throw error;
      }
    },
    async setDoc(docPath, data, token) {
      const fields = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, toValue(v)]));
      return request(`${DOCS}/${docPath}?${key}`, { method: 'PATCH', body: { fields }, token });
    },
    /** Neues Dokument mit zufälliger ID. */
    async addDoc(collection, data, token) {
      const fields = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, toValue(v)]));
      const j = await request(`${DOCS}/${collection}?${key}`, { method: 'POST', body: { fields }, token });
      return j.name.split('/').pop();
    },
    async delDoc(docPath, token) {
      return request(`${DOCS}/${docPath}?${key}`, { method: 'DELETE', token });
    },
    /** Alle Dokumente einer Sammlung mit feld == wert. */
    async query(collection, field, value, token, limit = 300) {
      const body = { structuredQuery: { from: [{ collectionId: collection }], where: { fieldFilter: { field: { fieldPath: field }, op: 'EQUAL', value: toValue(value) } }, limit } };
      const rows = await request(`${DOCS}:runQuery?${key}`, { method: 'POST', body, token });
      return (rows || []).filter((r) => r.document).map((r) => ({ id: r.document.name.split('/').pop(), ...fromFields(r.document.fields) }));
    },
    /** Anmelden oder registrieren. Mit 2FA kommt stattdessen { mfa: { pending, enrollmentId } } zurück. */
    async signIn(email, password, create = false) {
      try {
        const j = await request(`${AUTH}/v1/accounts:${create ? 'signUp' : 'signInWithPassword'}?${key}`, { method: 'POST', body: { email, password, returnSecureToken: true } });
        if (j.mfaPendingCredential) {
          const f = (j.mfaInfo || []).find((x) => x.totpInfo) || (j.mfaInfo || [])[0];
          return { mfa: { pending: j.mfaPendingCredential, enrollmentId: f?.mfaEnrollmentId, email: j.email || email } };
        }
        return session(j);
      } catch (error) {
        throw friendly(error);
      }
    },
    /** Zweiter Schritt der Anmeldung: 6-stelliger Code aus der Authenticator-App. */
    async finishMfa(pending, enrollmentId, code) {
      try {
        const j = await request(`${AUTH}/v2/accounts/mfaSignIn:finalize?${key}`, { method: 'POST', body: { mfaPendingCredential: pending, mfaEnrollmentId: enrollmentId, totpVerificationInfo: { verificationCode: String(code).replace(/\s/g, '') } } });
        return session(j);
      } catch (error) {
        throw friendly(error);
      }
    },
    async refresh(refreshToken) {
      const res = await net.fetch(`https://securetoken.googleapis.com/v1/token?${key}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}` });
      const j = await res.json();
      if (!res.ok) throw friendly(new Error(j?.error?.message || 'Anmeldung abgelaufen'));
      return session(j);
    },
    async lookup(idToken) {
      const j = await request(`${AUTH}/v1/accounts:lookup?${key}`, { method: 'POST', body: { idToken } });
      const u = j?.users?.[0] || {};
      return { emailVerified: Boolean(u.emailVerified), mfa: (u.mfaInfo || []).map((m) => ({ id: m.mfaEnrollmentId, name: m.displayName || 'Authenticator', totp: Boolean(m.totpInfo) })) };
    },
    async sendVerify(idToken) {
      try {
        await request(`${AUTH}/v1/accounts:sendOobCode?${key}`, { method: 'POST', body: { requestType: 'VERIFY_EMAIL', idToken } });
        return true;
      } catch (error) {
        throw friendly(error);
      }
    },
    async resetPassword(email) {
      try {
        await request(`${AUTH}/v1/accounts:sendOobCode?${key}`, { method: 'POST', body: { requestType: 'PASSWORD_RESET', email } });
        return true;
      } catch (error) {
        throw friendly(error);
      }
    },
    /** 2FA einrichten, Schritt 1: geheimer Schlüssel für die Authenticator-App. */
    async startTotp(idToken) {
      try {
        const j = await request(`${AUTH}/v2/accounts/mfaEnrollment:start?${key}`, { method: 'POST', body: { idToken, totpEnrollmentInfo: {} } });
        const t = j.totpSessionInfo || {};
        return { secret: t.sharedSecretKey, session: t.sessionInfo, digits: t.verificationCodeLength || 6, period: t.periodSec || 30, algorithm: t.hashingAlgorithm || 'SHA1' };
      } catch (error) {
        throw friendly(error);
      }
    },
    /** 2FA einrichten, Schritt 2: ersten Code bestätigen. Gibt neue Anmelde-Daten zurück. */
    async finishTotp(idToken, sessionInfo, code) {
      try {
        const j = await request(`${AUTH}/v2/accounts/mfaEnrollment:finalize?${key}`, { method: 'POST', body: { idToken, displayName: 'Authenticator-App', totpVerificationInfo: { sessionInfo, verificationCode: String(code).replace(/\s/g, '') } } });
        return { idToken: j.idToken, refreshToken: j.refreshToken };
      } catch (error) {
        throw friendly(error);
      }
    },
    async removeMfa(idToken, enrollmentId) {
      try {
        const j = await request(`${AUTH}/v2/accounts/mfaEnrollment:withdraw?${key}`, { method: 'POST', body: { idToken, mfaEnrollmentId: enrollmentId } });
        return { idToken: j.idToken, refreshToken: j.refreshToken };
      } catch (error) {
        throw friendly(error);
      }
    },
  };
}

const kelpi = client(KELPI);
module.exports = { client, kelpi, accountConfig, KELPI, friendly, fromFields, getDoc: kelpi.getDoc, setDoc: kelpi.setDoc };
