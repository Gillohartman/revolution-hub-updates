import fs from "node:fs";
import path from "node:path";
import { cacheDir, gameDir, ensureDir, slug } from "./paths.mjs";
import { getInstance, updateInstance } from "./instances.mjs";
import { getProject, getProjectVersions, installContent, listContent } from "./content.mjs";

/* ------------------------------------------------------------- fast start */

/**
 * Garbage-collector and start-up flags that are safe on every modern runtime.
 * They are added before the user's own arguments, so anything set in Settings or on
 * the instance overrides them.
 */
export const FAST_START_GC_FLAGS = [
  // This has to come first: G1NewSizePercent, G1MaxNewSizePercent and
  // G1RSetUpdatingPauseTimePercent are experimental options, and the JVM refuses to start
  // ("Improperly specified VM option") when the unlock switch follows them.
  "-XX:+UnlockExperimentalVMOptions",
  "-XX:+UseG1GC",
  "-XX:+ParallelRefProcEnabled",
  "-XX:MaxGCPauseMillis=40",
  "-XX:G1NewSizePercent=30",
  "-XX:G1MaxNewSizePercent=40",
  "-XX:G1HeapRegionSize=8M",
  "-XX:G1ReservePercent=20",
  "-XX:G1HeapWastePercent=5",
  "-XX:G1MixedGCCountTarget=4",
  "-XX:InitiatingHeapOccupancyPercent=15",
  "-XX:G1MixedGCLiveThresholdPercent=90",
  "-XX:G1RSetUpdatingPauseTimePercent=5",
  "-XX:SurvivorRatio=6",
  "-XX:MaxTenuringThreshold=1",
  // Deliberately no -XX:+PerfDisableSharedMem: the class-data-sharing dump needs the perf
  // memory file, and without it the JVM aborts the archive with "(No such process)" and
  // the game dies on exit (0xC0000409).
  "-XX:+DisableExplicitGC",
];

/**
 * Java 8 accepted only a handful of these and aborts on anything it does not know, so older
 * runtimes get the three flags that every G1 build understands.
 */
export const LEGACY_GC_FLAGS = [
  "-XX:+UseG1GC",
  "-XX:+ParallelRefProcEnabled",
  "-XX:MaxGCPauseMillis=40",
];

/** Flags that only exist from a given major version on. */
const MIN_MAJOR = {
  "-XX:+AutoCreateSharedArchive": 19,
  "-XX:+UseZGC": 15,
};

/** Where the class-data-sharing archive for a version lives. */
export function sharedArchivePath(versionId) {
  return path.join(cacheDir(), "cds", `${slug(versionId || "minecraft")}.jsa`);
}

/**
 * JVM arguments that make Minecraft start noticeably faster.
 *
 * The two real wins are class-data sharing (the JVM maps a pre-parsed archive instead of
 * reading thousands of class files on every launch) and skipping the full re-verification
 * of the game files, which happens in install.mjs.
 */
export function fastStartFlags({ javaMajor = 21, versionId = "", loaderType = "vanilla", enable = true } = {}) {
  if (!enable) return [];
  const flags = javaMajor && javaMajor < 11 ? [...LEGACY_GC_FLAGS] : [...FAST_START_GC_FLAGS];
  if (loaderType === "forge" || loaderType === "neoforge") {
    // Forge re-checks every jar signature on start-up; these are its own, documented switches.
    flags.push("-Dfml.ignoreInvalidMinecraftCertificates=true", "-Dfml.ignorePatchDiscrepancies=true");
  }
  // Class-data sharing is deliberately not used: -XX:+AutoCreateSharedArchive hung the JVM for
  // one to two minutes on every start when the archive (or its directory) was missing, and the
  // dump failed on exit with 0xC0000409. Measured cost of leaving it out: none in practice,
  // because the archive was never created in the first place.
  return flags;
}

/* -------------------------------------------------------- graphics profile */

/**
 * `options.txt` keys the launcher owns. Everything else in the file is preserved
 * verbatim, so in-game settings the player changed by hand are never lost.
 */
export const DEFAULT_GRAPHICS_PROFILE = {
  renderDistance: 32,
  simulationDistance: 12,
  maxFps: 260,
  enableVsync: false,
  entityShadows: false,
  particles: 1,
};

function formatOption(value) {
  if (typeof value === "boolean") return value ? "true" : "false";
  return String(value);
}

/**
 * Merge the launcher's view-distance / frame-rate profile into an instance's options.txt.
 * Idempotent: running it on every launch only rewrites the keys it owns.
 */
export function applyGraphicsProfile(gameDirectory, profile = {}) {
  const wanted = new Map();
  for (const [key, value] of Object.entries({ ...DEFAULT_GRAPHICS_PROFILE, ...profile })) {
    if (value === undefined || value === null || value === "") continue;
    wanted.set(key, formatOption(value));
  }

  const file = path.join(gameDirectory, "options.txt");
  let lines = [];
  try {
    lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  } catch {
    lines = [];
  }

  const seen = new Set();
  const out = [];
  for (const line of lines) {
    if (!line) continue;
    const separator = line.indexOf(":");
    if (separator < 0) {
      out.push(line);
      continue;
    }
    const key = line.slice(0, separator);
    if (!wanted.has(key)) {
      out.push(line);
      continue;
    }
    seen.add(key);
    out.push(`${key}:${wanted.get(key)}`);
  }
  for (const [key, value] of wanted) {
    if (!seen.has(key)) out.push(`${key}:${value}`);
  }

  ensureDir(gameDirectory);
  fs.writeFileSync(file, `${out.join("\n")}\n`, "utf8");
  return { file, applied: [...wanted.keys()] };
}

/* ------------------------------------------------------------ Bobby config */

/**
 * Bobby's own config keys. `view-distance-overwrite` is the one that matters in singleplayer:
 * at 0 Bobby stays passive, so a world never gets the large view distance the launcher promises.
 * Comments and every other line in the file are left untouched.
 */
export function applyBobbyConfig(gameDirectory, { renderDistance = DEFAULT_GRAPHICS_PROFILE.renderDistance } = {}) {
  const view = Math.max(2, Math.min(32, Number(renderDistance) || DEFAULT_GRAPHICS_PROFILE.renderDistance));
  const wanted = new Map([
    ["enabled", "true"],
    ["max-render-distance", "32"],
    ["no-block-entities", "true"],
    ["taint-fake-chunks", "false"],
    ["unload-delay-secs", "60"],
    ["delete-unused-regions-after-days", "-1"],
    ["view-distance-overwrite", String(view)],
  ]);

  const dir = path.join(gameDirectory, "config");
  const file = path.join(dir, "bobby.conf");
  let lines = [];
  try {
    lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  } catch {
    lines = [];
  }

  const seen = new Set();
  const out = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      out.push(line);
      continue;
    }
    const separator = trimmed.indexOf("=");
    if (separator < 0) {
      out.push(line);
      continue;
    }
    const key = trimmed.slice(0, separator).trim();
    if (!wanted.has(key)) {
      out.push(line);
      continue;
    }
    seen.add(key);
    out.push(`${key}=${wanted.get(key)}`);
  }
  for (const [key, value] of wanted) {
    if (!seen.has(key)) out.push(`${key}=${value}`);
  }

  ensureDir(dir);
  fs.writeFileSync(file, `${out.join("\n")}\n`, "utf8");
  return { file, viewDistance: view };
}

/* ---------------------------------------------------------- optimisation mods */

/**
 * What each loader can actually use. Bobby is Fabric-only, so vanilla, Forge and
 * NeoForge instances get the optimisation half but no unlimited view distance.
 */
export const PERFORMANCE_MODS = {
  fabric: [
    { slug: "fabric-api", label: "Fabric API" },
    { slug: "sodium", label: "Sodium" },
    { slug: "lithium", label: "Lithium" },
    { slug: "ferrite-core", label: "FerriteCore" },
    { slug: "bobby", label: "Bobby" },
  ],
  quilt: [
    { slug: "fabric-api", label: "Fabric API" },
    { slug: "sodium", label: "Sodium" },
    { slug: "lithium", label: "Lithium" },
    { slug: "ferrite-core", label: "FerriteCore" },
    { slug: "bobby", label: "Bobby" },
  ],
  neoforge: [
    { slug: "sodium", label: "Sodium" },
    { slug: "lithium", label: "Lithium" },
    { slug: "ferrite-core", label: "FerriteCore" },
  ],
  forge: [
    { slug: "ferrite-core", label: "FerriteCore" },
  ],
  vanilla: [],
};

export function performanceModsFor(loaderType) {
  return PERFORMANCE_MODS[loaderType || "vanilla"] || [];
}

/**
 * Install the optimisation mods that fit this instance, skipping anything already
 * present. Returns what was added and what was skipped, so the UI can say so.
 */
export async function ensurePerformanceMods({ instanceId, mcVersion, loader, onProgress = () => {} }) {
  const specs = performanceModsFor(loader);
  if (!specs.length) {
    return { installed: [], skipped: [], unsupported: true };
  }

  const existing = await listContent(instanceId, { type: "mod" });
  const installed = [];
  const skipped = [];

  for (const spec of specs) {
    try {
      // Already tracked by slug: skip without touching the network. This runs on every
      // launch, and five Modrinth round trips were a real part of the slow start.
      if (existing.some((entry) => entry.slug === spec.slug)) {
        skipped.push(spec.label);
        continue;
      }
      const project = await getProject(spec.slug);
      if (existing.some((entry) => entry.projectId === project.id)) {
        skipped.push(spec.label);
        continue;
      }
      const versions = await getProjectVersions(spec.slug, { mcVersion, loader });
      if (!versions.length) {
        skipped.push(`${spec.label} (no ${mcVersion} build)`);
        continue;
      }
      const version = versions.find((entry) => entry.version_type === "release") || versions[0];
      onProgress({ phase: "mods", message: `Installing ${spec.label} for ${mcVersion}` });
      await installContent({ instanceId, project, version, onProgress });
      installed.push(spec.label);
    } catch (err) {
      skipped.push(`${spec.label} (${err.message})`);
    }
  }

  return { installed, skipped, unsupported: false };
}

/**
 * Everything that makes an instance start fast and hold a large view distance.
 * Called right before a launch, so it also repairs an instance whose options were reset.
 */
export async function preparePerformance({ instance, settings = {}, onProgress = () => {} }) {
  const renderDistance = Number(settings.renderDistance) || DEFAULT_GRAPHICS_PROFILE.renderDistance;
  const profile = applyGraphicsProfile(gameDir(instance.id), {
    renderDistance,
    simulationDistance: settings.simulationDistance,
  });

  // Bobby reads its view distance from bobby.conf, not from options.txt, so the file is
  // written on every launch for the loaders that can run it.
  const loader = instance.loader?.type || "vanilla";
  let bobbyConfig = null;
  if (loader === "fabric" || loader === "quilt") {
    try {
      bobbyConfig = applyBobbyConfig(gameDir(instance.id), { renderDistance });
    } catch { /* a read-only game directory must not block a launch */ }
  }

  let mods = { installed: [], skipped: [], unsupported: false };
  if (settings.performanceMods !== false) {
    try {
      mods = await ensurePerformanceMods({
        instanceId: instance.id,
        mcVersion: instance.mcVersion || instance.versionId,
        loader,
        onProgress,
      });
    } catch (err) {
      mods = { installed: [], skipped: [`optimisation mods: ${err.message}`], unsupported: false };
    }
  }

  const perf = {
    appliedAt: Date.now(),
    renderDistance: Number(settings.renderDistance) || DEFAULT_GRAPHICS_PROFILE.renderDistance,
    simulationDistance: Number(settings.simulationDistance) || DEFAULT_GRAPHICS_PROFILE.simulationDistance,
    mods: mods.installed,
    skipped: mods.skipped,
    bobby: Boolean(mods.installed.includes("Bobby")) || undefined,
  };

  try {
    await updateInstance(instance.id, { perf });
  } catch { /* a deleted instance must not block a launch */ }

  onProgress({
    phase: "perf",
    message: mods.installed.length
      ? `Performance ready — added ${mods.installed.join(", ")}`
      : `Performance ready — ${perf.renderDistance} chunks render distance`,
    done: 1,
    total: 1,
  });

  return { ...perf, optionsFile: profile.file, options: profile.applied, bobbyConfig: bobbyConfig?.file || null };
}

/** Human-readable summary used by the renderer's toast. */
export function describePerformance(result = {}) {
  const parts = [`${result.renderDistance ?? DEFAULT_GRAPHICS_PROFILE.renderDistance} chunks`];
  if (result.mods?.length) parts.push(`added ${result.mods.join(", ")}`);
  if (result.skipped?.length) parts.push(`skipped ${result.skipped.join(", ")}`);
  return parts.join(" · ");
}

export { getInstance };
