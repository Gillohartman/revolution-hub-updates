﻿# Revolution Crosshair - Eingabe-Leser
# Gibt bei jeder Aenderung eine Zeile  {"keys":"W,A,pad-A"}  aus.
# Nur lesen: es wird nichts gesendet und nichts veraendert.

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -Namespace Hook -Name Native -MemberDefinition @'
[DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);
[DllImport("xinput1_4.dll")] public static extern int XInputGetState(int index, ref XINPUT_STATE state);
[StructLayout(LayoutKind.Sequential)] public struct XINPUT_STATE { public uint packet; public XINPUT_GAMEPAD pad; }
[StructLayout(LayoutKind.Sequential)] public struct XINPUT_GAMEPAD {
  public ushort buttons;
  public byte leftTrigger;
  public byte rightTrigger;
  public short leftX;
  public short leftY;
  public short rightX;
  public short rightY;
}
'@

# Mausrad: GetAsyncKeyState kennt kein Scrollen. Ein Low-Level-Maus-Hook (nur
# lesen) zaehlt die Rastungen; jede Rastung erscheint kurz als WheelUp/WheelDown.
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Threading;
namespace Hook {
  public static class Wheel {
    public static int Up;
    public static int Down;
    delegate IntPtr LowLevelProc(int code, IntPtr wParam, IntPtr lParam);
    static readonly LowLevelProc Proc = Callback;
    static IntPtr handle = IntPtr.Zero;
    [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }
    [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int id, LowLevelProc fn, IntPtr module, uint thread);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] static extern int GetMessage(out MSG msg, IntPtr hwnd, uint min, uint max);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
    public static void Start() {
      var thread = new Thread(() => {
        handle = SetWindowsHookEx(14, Proc, GetModuleHandle(null), 0);
        MSG msg;
        while (GetMessage(out msg, IntPtr.Zero, 0, 0) > 0) { }
      });
      thread.IsBackground = true;
      thread.Start();
    }
    static IntPtr Callback(int code, IntPtr wParam, IntPtr lParam) {
      if (code >= 0 && wParam.ToInt32() == 0x020A) {
        int data = Marshal.ReadInt32(lParam, 8);
        short delta = (short)((data >> 16) & 0xFFFF);
        if (delta < 0) Interlocked.Increment(ref Down); else Interlocked.Increment(ref Up);
      }
      return CallNextHookEx(handle, code, wParam, lParam);
    }
  }
}
'@
try { [Hook.Wheel]::Start() } catch { }
$wheelUp = 0
$wheelDown = 0

$keys = [ordered]@{
  'W' = 0x57; 'A' = 0x41; 'S' = 0x53; 'D' = 0x44;
  'Space' = 0x20; 'Shift' = 0xA0; 'Ctrl' = 0xA2; 'Alt' = 0xA4;
  'E' = 0x45; 'R' = 0x52; 'Q' = 0x51; 'F' = 0x46; 'G' = 0x47; 'C' = 0x43; 'V' = 0x56;
  'T' = 0x54; 'Y' = 0x59; 'X' = 0x58; 'B' = 0x42; 'Caps' = 0x14;
  'Tab' = 0x09; 'Esc' = 0x1B;
  '1' = 0x31; '2' = 0x32; '3' = 0x33; '4' = 0x34; '5' = 0x35; '6' = 0x36;
  'M1' = 0x01; 'M2' = 0x02; 'M3' = 0x04; 'M4' = 0x05; 'M5' = 0x06
}

$padButtons = [ordered]@{
  'pad-A' = 0x1000; 'pad-B' = 0x2000; 'pad-X' = 0x4000; 'pad-Y' = 0x8000;
  'pad-LB' = 0x0100; 'pad-RB' = 0x0200;
  'pad-Up' = 0x0001; 'pad-Down' = 0x0002; 'pad-Left' = 0x0004; 'pad-Right' = 0x0008;
  'pad-LS' = 0x0040; 'pad-RS' = 0x0080;
  'pad-Start' = 0x0010; 'pad-Back' = 0x0020
}

$padNames = @($padButtons.Keys)
$keyNames = @($keys.Keys)
$previous = ''

while ($true) {
  $active = New-Object System.Collections.Generic.List[string]

  foreach ($name in $keyNames) {
    $state = [Hook.Native]::GetAsyncKeyState([int]$keys[$name])
    if (($state -band 0x8000) -ne 0) { $active.Add($name) }
  }

  try {
    # Alle vier XInput-Plätze prüfen – der Controller hängt nicht immer auf Platz 0
    $padState = New-Object Hook.Native+XINPUT_STATE
    $found = $false
    for ($slot = 0; $slot -lt 4 -and -not $found; $slot++) {
      if ([Hook.Native]::XInputGetState($slot, [ref]$padState) -eq 0) { $found = $true }
    }
    if ($found) {
      $buttons = [int]$padState.pad.buttons
      foreach ($name in $padNames) {
        if (($buttons -band [int]$padButtons[$name]) -ne 0) { $active.Add($name) }
      }
      if ($padState.pad.leftTrigger -gt 60) { $active.Add('pad-LT') }
      if ($padState.pad.rightTrigger -gt 60) { $active.Add('pad-RT') }
      if ([Math]::Abs([int]$padState.pad.leftX) -gt 16000 -or [Math]::Abs([int]$padState.pad.leftY) -gt 16000) {
        $active.Add('pad-StickL')
      }
      if ([Math]::Abs([int]$padState.pad.rightX) -gt 16000 -or [Math]::Abs([int]$padState.pad.rightY) -gt 16000) {
        $active.Add('pad-StickR')
      }
    }
  } catch {
    # Kein Controller angeschlossen: einfach weiter.
  }

  $up = [Hook.Wheel]::Up
  $down = [Hook.Wheel]::Down
  if ($up -ne $wheelUp) { $wheelUp = $up; $active.Add('WheelUp') }
  if ($down -ne $wheelDown) { $wheelDown = $down; $active.Add('WheelDown') }

  $line = ($active -join ',')
  if ($line -ne $previous) {
    $previous = $line
    $escaped = $line -replace '\\', '\\\\' -replace '"', '\"'
    [Console]::Out.WriteLine('{"keys":"' + $escaped + '"}')
    [Console]::Out.Flush()
  }

  Start-Sleep -Milliseconds 40
}
