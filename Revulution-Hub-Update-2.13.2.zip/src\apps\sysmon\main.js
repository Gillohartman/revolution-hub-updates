'use strict';

const os = require('os');
const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');
const { boot, powershell, psQuote } = require('../shared/boot');

const ctx = boot('sysmon', __dirname, {
  onView: (view) => {
    view.on('hub-visibility', (shown) => (shown ? start() : stop()));
    if (global.__revolutionHub.hub.visible.get('sysmon')) start();
  },
});
const { ipcMain, shell, app } = ctx.electron;
const WINDOWS = process.platform === 'win32';
const procFlag = path.join(os.tmpdir(), `revolution-hub-sysmon-${process.pid}.procs`);

/* ------------------------------------------------------------------ sampling */

let timer = null;
let sampler = null;
let lastCpu = os.cpus();
let latest = {};

function cpuUsage() {
  const now = os.cpus();
  const cores = now.map((cpu, i) => {
    const before = lastCpu[i] || cpu;
    const total = Object.values(cpu.times).reduce((a, b) => a + b, 0) - Object.values(before.times).reduce((a, b) => a + b, 0);
    const idle = cpu.times.idle - before.times.idle;
    return total > 0 ? Math.max(0, Math.min(100, Math.round((1 - idle / total) * 100))) : 0;
  });
  lastCpu = now;
  const speed = Math.round(now.reduce((a, c) => a + c.speed, 0) / Math.max(1, now.length));
  return { total: Math.round(cores.reduce((a, b) => a + b, 0) / Math.max(1, cores.length)), cores, speed };
}

function startSampler() {
  if (!WINDOWS || sampler) return;
  const script = path.join(__dirname, 'sampler.ps1');
  sampler = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, procFlag], { windowsHide: true });
  let buffer = '';
  sampler.stdout.on('data', (chunk) => {
    buffer += chunk.toString('utf8');
    let index;
    while ((index = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (!line.startsWith('{')) continue;
      try {
        const data = JSON.parse(line);
        if (data.procs && !Array.isArray(data.procs)) data.procs = [data.procs];
        latest = { ...latest, ...data };
        if (data.procs) ctx.send('procs', data.procs);
      } catch {
        /* partial line */
      }
    }
  });
  sampler.on('exit', () => {
    sampler = null;
  });
}

function start() {
  if (timer) return;
  lastCpu = os.cpus();
  startSampler();
  const tick = () => {
    const total = os.totalmem();
    const free = os.freemem();
    ctx.send('sample', {
      cpu: cpuUsage(),
      ram: { used: total - free, total },
      gpu: latest.gpu ?? null,
      gpuName: latest.gpuName || '',
      net: { down: latest.down ?? null, up: latest.up ?? null },
      disk: { busy: latest.diskBusy ?? null, read: latest.diskRead ?? null, write: latest.diskWrite ?? null },
      uptime: os.uptime(),
    });
  };
  tick();
  timer = setInterval(tick, 1000);
}

function stop() {
  clearInterval(timer);
  timer = null;
  if (sampler) {
    sampler.kill();
    sampler = null;
  }
}

app.on('will-quit', () => {
  stop();
  fs.rmSync(procFlag, { force: true });
});

/* ----------------------------------------------------------------------- IPC */

ipcMain.handle('info', () => {
  const cpus = os.cpus();
  return {
    cpuModel: (cpus[0]?.model || '').replace(/\s+/g, ' ').trim(),
    cores: cpus.length,
    ram: os.totalmem(),
    host: os.hostname(),
    os: `${os.version?.() || os.type()} (${os.release()})`,
    arch: os.arch(),
    windows: WINDOWS,
  };
});

ipcMain.handle('disks', async () => {
  const letters = WINDOWS ? 'CDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((l) => `${l}:\\`) : ['/'];
  const out = [];
  for (const root of letters) {
    try {
      const stat = await fs.promises.statfs(root);
      const total = stat.blocks * stat.bsize;
      if (!total) continue;
      out.push({ root, total, free: stat.bavail * stat.bsize });
    } catch {
      /* no drive */
    }
  }
  return out;
});

ipcMain.handle('procs:watch', (_event, on) => {
  if (on) fs.writeFileSync(procFlag, '1');
  else fs.rmSync(procFlag, { force: true });
  if (on && !WINDOWS) sendFallbackProcs();
  return true;
});

/** Outside Windows (development) a simple `ps` listing stands in for the WMI data. */
function sendFallbackProcs() {
  execFile('ps', ['-eo', 'pid,comm,%cpu,rss', '--no-headers'], (error, stdout) => {
    if (error) return;
    const procs = stdout
      .trim()
      .split('\n')
      .map((line) => line.trim().split(/\s+/))
      .map(([pid, name, cpu, rss]) => ({ pid: Number(pid), name, cpu: Number(cpu), mem: Number(rss) * 1024 }));
    ctx.send('procs', procs);
  });
}

ipcMain.handle('kill', (_event, pid) => {
  pid = Number(pid);
  if (!Number.isInteger(pid) || pid <= 4 || pid === process.pid) throw new Error('Dieser Prozess kann nicht beendet werden.');
  return new Promise((resolve, reject) => {
    if (!WINDOWS) {
      try {
        process.kill(pid);
        return resolve(true);
      } catch (error) {
        return reject(error);
      }
    }
    execFile('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }, (error, _out, stderr) => {
      if (error) reject(new Error((stderr || error.message).trim() || 'Beenden fehlgeschlagen (evtl. Administratorrechte nötig).'));
      else resolve(true);
    });
  });
});

ipcMain.handle('proc:locate', async (_event, pid) => {
  if (!WINDOWS) return false;
  const out = await powershell(`(Get-Process -Id ${Number(pid)} -ErrorAction Stop).Path`);
  const file = out.trim();
  if (!file) throw new Error('Speicherort nicht verfügbar (Systemprozess).');
  shell.showItemInFolder(file);
  return true;
});

/* ------------------------------------------------------------------ autostart */

const APPROVED = {
  HKCU: 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run',
  HKLM: 'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run',
  HKLM32: 'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32',
  Folder: 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder',
  FolderAll: 'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder',
};

ipcMain.handle('startup:list', async () => {
  if (!WINDOWS) return [];
  const script = `
$items = @()
$runs = @(@{s='HKCU';p='HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'},@{s='HKLM';p='HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'},@{s='HKLM32';p='HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run'})
foreach ($r in $runs) {
  $props = Get-ItemProperty -Path $r.p -ErrorAction SilentlyContinue
  if ($props) { foreach ($x in $props.PSObject.Properties) { if ($x.Name -notlike 'PS*') { $items += [pscustomobject]@{ source=$r.s; name=$x.Name; command=[string]$x.Value } } } }
}
foreach ($f in @(@{s='Folder';p=[Environment]::GetFolderPath('Startup')},@{s='FolderAll';p=[Environment]::GetFolderPath('CommonStartup')})) {
  Get-ChildItem -LiteralPath $f.p -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'desktop.ini' } | ForEach-Object { $items += [pscustomobject]@{ source=$f.s; name=$_.Name; command=$_.FullName } }
}
$keys = @{ ${Object.entries(APPROVED).map(([k, v]) => `'${k}'='${v}'`).join(';')} }
foreach ($i in $items) {
  $v = (Get-ItemProperty -Path $keys[$i.source] -Name $i.name -ErrorAction SilentlyContinue).($i.name)
  $on = $true
  if ($v -and $v.Length -gt 0) { $on = (($v[0] % 2) -eq 0) }
  $i | Add-Member -NotePropertyName enabled -NotePropertyValue $on
}
ConvertTo-Json -InputObject @($items) -Compress`;
  const out = await powershell(script);
  const list = JSON.parse(out.trim() || '[]');
  return Array.isArray(list) ? list : [list];
});

ipcMain.handle('startup:set', async (_event, { source, name, enabled }) => {
  if (!WINDOWS) return false;
  const key = APPROVED[source];
  if (!key) throw new Error('Unbekannte Quelle.');
  const bytes = enabled ? '2,0,0,0,0,0,0,0,0,0,0,0' : '3,0,0,0,0,0,0,0,0,0,0,0';
  try {
    await powershell(`
if (-not (Test-Path ${psQuote(key)})) { New-Item -Path ${psQuote(key)} -Force | Out-Null }
Set-ItemProperty -Path ${psQuote(key)} -Name ${psQuote(name)} -Value ([byte[]](${bytes})) -Type Binary -ErrorAction Stop`);
  } catch (error) {
    if (source !== 'HKCU' && source !== 'Folder') throw new Error('Dieser Eintrag gilt für alle Benutzer – dafür braucht es Administratorrechte.');
    throw error;
  }
  return true;
});

ipcMain.handle('startup:reveal', (_event, entry) => {
  if (entry.source === 'Folder' || entry.source === 'FolderAll') shell.showItemInFolder(entry.command);
  else {
    const exe = /^"([^"]+)"/.exec(entry.command)?.[1] || entry.command.split(/\s+-|\s+\//)[0];
    if (exe && fs.existsSync(exe)) shell.showItemInFolder(exe);
    else throw new Error('Datei nicht gefunden.');
  }
  return true;
});

ipcMain.handle('taskmgr', () => {
  if (WINDOWS) spawn('taskmgr.exe', [], { detached: true, stdio: 'ignore' }).unref();
});
