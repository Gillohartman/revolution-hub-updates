'use strict';

const $ = (selector) => document.querySelector(selector);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
const api = window.sysmon;

const HISTORY = 60;
const history = { cpu: [], gpu: [], ram: [], down: [], up: [] };
let info = null;
let disks = [];
let tab = 'overview';
let sample = null;
let processes = [];
let procSort = { key: 'cpu', dir: -1 };
let procQuery = '';
let startup = null;

/* ------------------------------------------------------------------ helpers */
function bytes(value, digits = 1) {
  if (value == null || !Number.isFinite(value)) return '–';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${value.toFixed(i === 0 ? 0 : digits)} ${units[i]}`;
}

const rate = (value) => (value == null ? '–' : `${bytes(value)}/s`);

function duration(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return d ? `${d} T ${h} Std` : h ? `${h} Std ${m} Min` : `${m} Min`;
}

function toast(message, kind = '') {
  document.querySelector('.toast')?.remove();
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = String(message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  document.body.appendChild(el);
  setTimeout(() => el.remove(), kind === 'error' ? 6000 : 3200);
}

function push(list, value) {
  list.push(value);
  if (list.length > HISTORY) list.shift();
}

/* ------------------------------------------------------------------- charts */
function drawChart(canvas, series, colors, max = 100) {
  if (!canvas) return;
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  if (canvas.width !== width * ratio) {
    canvas.width = width * ratio;
    canvas.height = height * ratio;
  }
  const g = canvas.getContext('2d');
  g.setTransform(ratio, 0, 0, ratio, 0, 0);
  g.clearRect(0, 0, width, height);
  const top = Math.max(max, ...series.flat().filter(Number.isFinite), 1);
  series.forEach((data, index) => {
    if (!data.length) return;
    const color = colors[index];
    const step = width / (HISTORY - 1);
    const offset = (HISTORY - data.length) * step;
    const y = (v) => height - 2 - ((Number.isFinite(v) ? v : 0) / top) * (height - 6);
    g.beginPath();
    data.forEach((v, i) => (i ? g.lineTo(offset + i * step, y(v)) : g.moveTo(offset, y(v))));
    g.strokeStyle = color;
    g.lineWidth = 2;
    g.lineJoin = 'round';
    g.stroke();
    if (index === 0) {
      g.lineTo(offset + (data.length - 1) * step, height);
      g.lineTo(offset, height);
      g.closePath();
      const fill = g.createLinearGradient(0, 0, 0, height);
      fill.addColorStop(0, `${color}55`);
      fill.addColorStop(1, `${color}00`);
      g.fillStyle = fill;
      g.fill();
    }
  });
}

/* ----------------------------------------------------------------- overview */
function overviewHtml() {
  const metric = (id, title, iconName, tint) => `
    <div class="glass metric" style="--tint:${tint}">
      <div class="metric-head"><span>${title}</span>${icon(iconName, 17)}</div>
      <div class="metric-value" id="${id}-value">–</div>
      <div class="metric-sub" id="${id}-sub"></div>
      <canvas id="${id}-chart"></canvas>
    </div>`;
  return `
    <div class="metrics">
      ${metric('cpu', 'PROZESSOR', 'cpu', '#a58bff')}
      ${metric('gpu', 'GRAFIKKARTE', 'gauge', '#38bdf8')}
      ${metric('ram', 'ARBEITSSPEICHER', 'grid', '#3ddc97')}
      ${metric('net', 'NETZWERK', 'download', '#ffb547')}
    </div>
    <div class="row2">
      <div class="glass card"><h3>Prozessorkerne</h3><div class="cores" id="cores"></div></div>
      <div class="glass card"><h3>Laufwerke</h3><div id="disks"></div></div>
    </div>
    <div class="row2">
      <div class="glass card"><h3>System</h3><div class="info" id="info"></div></div>
      <div class="glass card"><h3>Datenträger-Aktivität</h3><div class="info" id="diskio"></div></div>
    </div>`;
}

function renderDisks() {
  const el = $('#disks');
  if (!el) return;
  el.innerHTML = disks.length
    ? disks
        .map((d) => {
          const used = d.total - d.free;
          const pct = Math.round((used / d.total) * 100);
          return `<div class="disk"><div class="disk-top"><b>${esc(d.root.replace(/\\$/, ''))}</b><span class="muted tabular">${bytes(d.free)} frei von ${bytes(d.total)}</span></div>
            <div class="bar"><i class="${pct > 90 ? 'bad' : pct > 75 ? 'warn' : ''}" style="width:${pct}%"></i></div></div>`;
        })
        .join('')
    : '<div class="muted">Keine Laufwerke gefunden.</div>';
}

function renderInfo() {
  const el = $('#info');
  if (!el || !info) return;
  el.innerHTML = `
    <span>Prozessor</span><b title="${esc(info.cpuModel)}">${esc(info.cpuModel)}</b>
    <span>Kerne / Threads</span><b>${info.cores}</b>
    <span>Grafikkarte</span><b>${esc(sample?.gpuName || '–')}</b>
    <span>Arbeitsspeicher</span><b>${bytes(info.ram)}</b>
    <span>System</span><b title="${esc(info.os)}">${esc(info.os)}</b>
    <span>Computername</span><b>${esc(info.host)}</b>
    <span>Laufzeit</span><b id="uptime">${sample ? duration(sample.uptime) : '–'}</b>`;
}

function updateOverview() {
  if (!sample || tab !== 'overview') return;
  const s = sample;
  $('#cpu-value').innerHTML = `${s.cpu.total}<small>%</small>`;
  $('#cpu-sub').textContent = `${(s.cpu.speed / 1000).toFixed(2)} GHz · ${s.cpu.cores.length} Threads`;
  $('#gpu-value').innerHTML = s.gpu == null ? '–' : `${s.gpu}<small>%</small>`;
  $('#gpu-sub').textContent = s.gpuName || (info?.windows ? 'wird ermittelt …' : 'nur unter Windows');
  const ramPct = Math.round((s.ram.used / s.ram.total) * 100);
  $('#ram-value').innerHTML = `${ramPct}<small>%</small>`;
  $('#ram-sub').textContent = `${bytes(s.ram.used)} von ${bytes(s.ram.total)}`;
  $('#net-value').innerHTML = s.net.down == null ? '–' : `${bytes(s.net.down)}<small>/s</small>`;
  $('#net-sub').textContent = s.net.up == null ? 'nur unter Windows' : `↓ ${rate(s.net.down)}   ↑ ${rate(s.net.up)}`;
  drawChart($('#cpu-chart'), [history.cpu], ['#a58bff']);
  drawChart($('#gpu-chart'), [history.gpu], ['#38bdf8']);
  drawChart($('#ram-chart'), [history.ram], ['#3ddc97']);
  drawChart($('#net-chart'), [history.down, history.up], ['#ffb547', '#ff5d8f'], 1024);
  $('#cores').innerHTML = s.cpu.cores.map((v, i) => `<div class="core"><div class="core-bar"><i style="height:${v}%"></i></div>${v}%<span class="faint">#${i + 1}</span></div>`).join('');
  const uptime = $('#uptime');
  if (uptime) uptime.textContent = duration(s.uptime);
  $('#diskio').innerHTML = `
    <span>Auslastung</span><b>${s.disk.busy == null ? '–' : `${Math.round(s.disk.busy)} %`}</b>
    <span>Lesen</span><b>${rate(s.disk.read)}</b>
    <span>Schreiben</span><b>${rate(s.disk.write)}</b>
    <span>Netzwerk ↓</span><b>${rate(s.net.down)}</b>
    <span>Netzwerk ↑</span><b>${rate(s.net.up)}</b>`;
}

/* ---------------------------------------------------------------- processes */
function processesHtml() {
  return `<div class="glass table-wrap"><div style="max-height:calc(100vh - 120px);overflow:auto" id="proc-scroll"><table>
    <thead><tr>
      ${[['name', 'Name', ''], ['pid', 'PID', 'num'], ['cpu', 'CPU', 'num'], ['mem', 'Arbeitsspeicher', 'num']]
        .map(([key, label, cls]) => `<th class="${cls} ${procSort.key === key ? 'sorted' : ''}" data-sort="${key}">${label}${procSort.key === key ? (procSort.dir < 0 ? ' ↓' : ' ↑') : ''}</th>`)
        .join('')}
      <th></th></tr></thead><tbody id="proc-body"><tr><td colspan="5" class="empty">Prozesse werden geladen …</td></tr></tbody></table></div></div>`;
}

function renderProcesses() {
  const body = $('#proc-body');
  if (!body || !processes.length) return;
  // Group by name like the Task-Manager's "Apps" view would be too lossy; show each process.
  const q = procQuery.trim().toLowerCase();
  const list = processes
    .filter((p) => !q || p.name.toLowerCase().includes(q) || String(p.pid).includes(q))
    .sort((a, b) => {
      const k = procSort.key;
      const v = typeof a[k] === 'string' ? a[k].localeCompare(b[k]) : a[k] - b[k];
      return v * procSort.dir;
    })
    .slice(0, 300);
  body.innerHTML = list
    .map(
      (p) => `<tr><td><b>${esc(p.name)}</b></td><td class="num faint">${p.pid}</td>
      <td class="num ${p.cpu >= 20 ? 'cpu-hot' : ''}">${p.cpu.toFixed(1)} %</td><td class="num">${bytes(p.mem)}</td>
      <td><div class="actions"><button class="btn small ghost" data-locate="${p.pid}" title="Speicherort öffnen">${icon('folder', 14)}</button>
      <button class="btn small danger" data-kill="${p.pid}" data-name="${esc(p.name)}">Beenden</button></div></td></tr>`,
    )
    .join('');
  const total = $('#proc-count');
  if (total) total.textContent = `${processes.length} Prozesse`;
}

/* ------------------------------------------------------------------ startup */
const SOURCE_NAMES = { HKCU: 'Benutzer', HKLM: 'Alle Benutzer', HKLM32: 'Alle Benutzer (32-Bit)', Folder: 'Autostart-Ordner', FolderAll: 'Autostart-Ordner (alle)' };

function startupHtml() {
  if (!info?.windows) return '<div class="glass empty">Autostart-Programme gibt es nur unter Windows.</div>';
  if (!startup) return '<div class="glass empty">Autostart-Programme werden gelesen …</div>';
  if (!startup.length) return '<div class="glass empty">Keine Autostart-Programme gefunden.</div>';
  return `<div class="glass">${startup
    .map(
      (e, i) => `<div class="startup-row">
      <button class="switch ${e.enabled ? 'on' : ''}" data-startup="${i}" title="${e.enabled ? 'Deaktivieren' : 'Aktivieren'}"></button>
      <div class="grow"><strong>${esc(e.name.replace(/\.lnk$/i, ''))}</strong><small title="${esc(e.command)}">${esc(e.command)}</small></div>
      <span class="tag">${esc(SOURCE_NAMES[e.source] || e.source)}</span>
      <button class="btn small ghost" data-reveal="${i}" title="Im Explorer zeigen">${icon('folder', 14)}</button></div>`,
    )
    .join('')}</div>`;
}

/* ------------------------------------------------------------------- render */
function render() {
  document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  const side = $('#head-side');
  if (tab === 'overview') {
    side.innerHTML = info?.windows ? `<button class="btn small" id="taskmgr">${icon('external', 14)} Task-Manager</button>` : '';
    $('#view').innerHTML = overviewHtml();
    renderDisks();
    renderInfo();
    updateOverview();
  } else if (tab === 'processes') {
    side.innerHTML = `<span id="proc-count" class="tabular"></span><input class="input" id="proc-search" placeholder="Prozess suchen …" value="${esc(procQuery)}" style="width:240px" />`;
    $('#view').innerHTML = processesHtml();
    renderProcesses();
  } else {
    side.innerHTML = `<button class="btn small" id="startup-refresh">${icon('refresh', 14)} Aktualisieren</button>`;
    $('#view').innerHTML = startupHtml();
  }
  api.watchProcesses(tab === 'processes');
}

async function loadStartup() {
  try {
    startup = await api.startup();
  } catch (error) {
    startup = [];
    toast(error.message || error, 'error');
  }
  if (tab === 'startup') render();
}

/* ------------------------------------------------------------------- events */
document.addEventListener('click', async (event) => {
  const el = event.target.closest('button, th');
  if (!el) return;
  if (el.dataset.tab) {
    tab = el.dataset.tab;
    if (tab === 'startup' && !startup) loadStartup();
    render();
  } else if (el.dataset.sort) {
    procSort = { key: el.dataset.sort, dir: procSort.key === el.dataset.sort ? -procSort.dir : el.dataset.sort === 'name' ? 1 : -1 };
    render();
  } else if (el.dataset.kill) {
    if (!confirm(`„${el.dataset.name}“ (PID ${el.dataset.kill}) wirklich beenden? Nicht gespeicherte Daten gehen verloren.`)) return;
    try {
      await api.kill(Number(el.dataset.kill));
      processes = processes.filter((p) => p.pid !== Number(el.dataset.kill));
      renderProcesses();
      toast(`${el.dataset.name} wurde beendet.`);
    } catch (error) {
      toast(error.message || error, 'error');
    }
  } else if (el.dataset.locate) {
    api.locate(Number(el.dataset.locate)).catch((error) => toast(error.message || error, 'error'));
  } else if (el.dataset.startup) {
    const entry = startup[Number(el.dataset.startup)];
    try {
      await api.setStartup({ source: entry.source, name: entry.name, enabled: !entry.enabled });
      entry.enabled = !entry.enabled;
      el.classList.toggle('on', entry.enabled);
      toast(`${entry.name.replace(/\.lnk$/i, '')} startet ${entry.enabled ? 'wieder' : 'nicht mehr'} mit Windows.`);
    } catch (error) {
      toast(error.message || error, 'error');
    }
  } else if (el.dataset.reveal) {
    api.revealStartup(startup[Number(el.dataset.reveal)]).catch((error) => toast(error.message || error, 'error'));
  } else if (el.id === 'startup-refresh') {
    startup = null;
    render();
    loadStartup();
  } else if (el.id === 'taskmgr') api.taskManager();
});

document.addEventListener('input', (event) => {
  if (event.target.id !== 'proc-search') return;
  procQuery = event.target.value;
  renderProcesses();
});

api.onSample((next) => {
  sample = next;
  push(history.cpu, next.cpu.total);
  push(history.gpu, next.gpu ?? 0);
  push(history.ram, (next.ram.used / next.ram.total) * 100);
  push(history.down, next.net.down ?? 0);
  push(history.up, next.net.up ?? 0);
  if (next.gpuName && $('#info') && !$('#info').textContent.includes(next.gpuName)) renderInfo();
  updateOverview();
});

api.onProcesses((list) => {
  processes = list;
  if (tab === 'processes') renderProcesses();
});

api.onVisibility((shown) => {
  if (shown) {
    api.disks().then((list) => {
      disks = list;
      renderDisks();
    });
    api.watchProcesses(tab === 'processes');
  } else api.watchProcesses(false);
});

window.addEventListener('resize', () => updateOverview());

(async () => {
  info = await api.info();
  disks = await api.disks();
  render();
})();
