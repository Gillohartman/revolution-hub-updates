'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { boot } = require('../shared/boot');

const ctx = boot('docs', __dirname);
const { app, ipcMain, dialog, shell } = ctx.electron;
const hub = ctx.hub;

/* ----------------------------------------------------------------------- zip */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buffer) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buffer) >>> 0;
  let c = 0xffffffff;
  for (const byte of buffer) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function zip(files) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  const now = new Date();
  const time = (now.getHours() << 11) | (now.getMinutes() << 5) | Math.floor(now.getSeconds() / 2);
  const date = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
  for (const [name, content] of files) {
    const data = Buffer.isBuffer(content) ? content : Buffer.from(content, 'utf8');
    const packed = zlib.deflateRawSync(data, { level: 9 });
    const nameBuf = Buffer.from(name, 'utf8');
    const crc = crc32(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(8, 8);
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(packed.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    locals.push(local, nameBuf, packed);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(8, 10);
    central.writeUInt16LE(time, 12);
    central.writeUInt16LE(date, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(packed.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(nameBuf.length, 28);
    central.writeUInt32LE(offset, 42);
    centrals.push(central, nameBuf);
    offset += 30 + nameBuf.length + packed.length;
  }
  const centralSize = centrals.reduce((sum, b) => sum + b.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, ...centrals, end]);
}

function unzip(buffer) {
  let eocd = buffer.length - 22;
  while (eocd >= 0 && buffer.readUInt32LE(eocd) !== 0x06054b50) eocd -= 1;
  if (eocd < 0) throw new Error('Keine gültige .docx-Datei.');
  const count = buffer.readUInt16LE(eocd + 10);
  let ptr = buffer.readUInt32LE(eocd + 16);
  const files = {};
  for (let i = 0; i < count; i += 1) {
    const method = buffer.readUInt16LE(ptr + 10);
    const csize = buffer.readUInt32LE(ptr + 20);
    const nameLen = buffer.readUInt16LE(ptr + 28);
    const extraLen = buffer.readUInt16LE(ptr + 30);
    const commentLen = buffer.readUInt16LE(ptr + 32);
    const local = buffer.readUInt32LE(ptr + 42);
    const name = buffer.toString('utf8', ptr + 46, ptr + 46 + nameLen);
    const start = local + 30 + buffer.readUInt16LE(local + 26) + buffer.readUInt16LE(local + 28);
    const raw = buffer.subarray(start, start + csize);
    files[name] = method === 8 ? zlib.inflateRawSync(raw) : Buffer.from(raw);
    ptr += 46 + nameLen + extraLen + commentLen;
  }
  return files;
}

/* ------------------------------------------------------------------- recents */

const recentFile = () => path.join(app.getPath('userData'), 'recent.json');
function recents() {
  try {
    return JSON.parse(fs.readFileSync(recentFile(), 'utf8')).filter((r) => fs.existsSync(r.file));
  } catch {
    return [];
  }
}
function remember(file) {
  const list = [{ file, name: path.basename(file), time: Date.now() }, ...recents().filter((r) => r.file !== file)].slice(0, 20);
  fs.mkdirSync(path.dirname(recentFile()), { recursive: true });
  fs.writeFileSync(recentFile(), JSON.stringify(list, null, 2));
}

/* ---------------------------------------------------------------------- read */

const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', webp: 'image/webp', svg: 'image/svg+xml', emf: 'image/x-emf', wmf: 'image/x-wmf' };

function readDocument(file) {
  const ext = path.extname(file).toLowerCase();
  if (ext === '.docx') {
    const files = unzip(fs.readFileSync(file));
    if (!files['word/document.xml']) throw new Error('Keine gültige .docx-Datei.');
    const media = {};
    for (const [name, data] of Object.entries(files)) {
      if (!name.startsWith('word/media/')) continue;
      const type = MIME[path.extname(name).slice(1).toLowerCase()] || 'application/octet-stream';
      media[name.slice('word/'.length)] = `data:${type};base64,${data.toString('base64')}`;
    }
    return {
      kind: 'docx',
      document: files['word/document.xml'].toString('utf8'),
      rels: files['word/_rels/document.xml.rels']?.toString('utf8') || '',
      numbering: files['word/numbering.xml']?.toString('utf8') || '',
      styles: files['word/styles.xml']?.toString('utf8') || '',
      media,
    };
  }
  const text = fs.readFileSync(file, 'utf8');
  if (ext === '.html' || ext === '.htm' || ext === '.rdoc') return { kind: 'html', html: text };
  if (ext === '.md') return { kind: 'markdown', text };
  return { kind: 'text', text };
}

/* ----------------------------------------------------------------------- IPC */

const FILTERS = [
  { name: 'Word-Dokument', extensions: ['docx'] },
  { name: 'Webseite', extensions: ['html'] },
  { name: 'Text', extensions: ['txt'] },
];

ipcMain.handle('recents', () => recents());

ipcMain.handle('open', async (_event, file) => {
  if (!file) {
    const result = await dialog.showOpenDialog(hub.window, {
      title: 'Dokument öffnen',
      properties: ['openFile'],
      filters: [{ name: 'Dokumente', extensions: ['docx', 'html', 'htm', 'txt', 'md', 'rdoc'] }, { name: 'Alle Dateien', extensions: ['*'] }],
    });
    if (result.canceled || !result.filePaths[0]) return null;
    file = result.filePaths[0];
  }
  const doc = readDocument(file);
  remember(file);
  return { file, name: path.basename(file), ...doc };
});

ipcMain.handle('saveAs', async (_event, { name, format }) => {
  const ext = format || 'docx';
  const result = await dialog.showSaveDialog(hub.window, {
    title: 'Speichern unter',
    defaultPath: path.join(app.getPath('documents'), `${(name || 'Dokument').replace(/\.[^.]+$/, '')}.${ext}`),
    filters: [...FILTERS.filter((f) => f.extensions[0] === ext), ...FILTERS.filter((f) => f.extensions[0] !== ext)],
  });
  return result.canceled ? null : result.filePath;
});

ipcMain.handle('write', (_event, { file, docx, html, text }) => {
  const ext = path.extname(file).toLowerCase();
  if (ext === '.docx') {
    const parts = docx.parts.map(([name, content, base64]) => [name, base64 ? Buffer.from(content, 'base64') : content]);
    fs.writeFileSync(file, zip(parts));
  } else if (ext === '.html' || ext === '.htm') fs.writeFileSync(file, html, 'utf8');
  else fs.writeFileSync(file, text, 'utf8');
  remember(file);
  return { file, name: path.basename(file) };
});

ipcMain.handle('pdf', async (_event, name) => {
  const result = await dialog.showSaveDialog(hub.window, {
    title: 'Als PDF exportieren',
    defaultPath: path.join(app.getPath('documents'), `${(name || 'Dokument').replace(/\.[^.]+$/, '')}.pdf`),
    filters: [{ name: 'PDF', extensions: ['pdf'] }],
  });
  if (result.canceled || !result.filePath) return null;
  const data = await ctx.view.webContents.printToPDF({ pageSize: 'A4', printBackground: true, margins: { marginType: 'none' }, preferCSSPageSize: true });
  fs.writeFileSync(result.filePath, data);
  shell.openPath(result.filePath);
  return result.filePath;
});

ipcMain.handle('print', () => {
  ctx.view.webContents.print({ printBackground: true });
  return true;
});

ipcMain.handle('image', async () => {
  const result = await dialog.showOpenDialog(hub.window, {
    title: 'Bild einfügen',
    properties: ['openFile'],
    filters: [{ name: 'Bilder', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'] }],
  });
  if (result.canceled || !result.filePaths[0]) return null;
  const file = result.filePaths[0];
  const type = MIME[path.extname(file).slice(1).toLowerCase()] || 'image/png';
  return `data:${type};base64,${fs.readFileSync(file).toString('base64')}`;
});

/** Newest screenshots of the hub's screenshot tool (its own folder setting is respected). */
function screenshotFolder() {
  try {
    const settings = JSON.parse(fs.readFileSync(path.join(hub.moduleDataDir('screenshot'), 'settings.json'), 'utf8'));
    if (settings.folder) return settings.folder;
  } catch {
    /* default folder */
  }
  return path.join(app.getPath('pictures'), 'Screenshots', 'Revolution');
}

ipcMain.handle('screenshots', () => {
  const dir = screenshotFolder();
  try {
    return fs
      .readdirSync(dir)
      .filter((name) => /\.(png|jpe?g)$/i.test(name))
      .map((name) => ({ file: path.join(dir, name), time: fs.statSync(path.join(dir, name)).mtimeMs }))
      .sort((a, b) => b.time - a.time)
      .slice(0, 12);
  } catch {
    return [];
  }
});

ipcMain.handle('screenshot:data', (_event, file) => {
  if (!path.resolve(file).startsWith(path.resolve(screenshotFolder()))) throw new Error('Unbekannte Datei.');
  const type = MIME[path.extname(file).slice(1).toLowerCase()] || 'image/png';
  return `data:${type};base64,${fs.readFileSync(file).toString('base64')}`;
});

ipcMain.handle('reveal', (_event, file) => shell.showItemInFolder(file));

const draftFile = () => path.join(app.getPath('userData'), 'autosave.json');
ipcMain.handle('draft:save', (_event, draft) => {
  fs.mkdirSync(path.dirname(draftFile()), { recursive: true });
  if (draft) fs.writeFileSync(draftFile(), JSON.stringify(draft));
  else fs.rmSync(draftFile(), { force: true });
  return true;
});
ipcMain.handle('draft:load', () => {
  try {
    return JSON.parse(fs.readFileSync(draftFile(), 'utf8'));
  } catch {
    return null;
  }
});

module.exports = { zip, unzip };
