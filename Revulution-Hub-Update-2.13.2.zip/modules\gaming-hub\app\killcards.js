/**
 * Baut aus einem Match die Karten fuer das Kill-Popup.
 * Reine Funktion ohne Electron-Abhaengigkeit, damit sie testbar bleibt.
 */
function buildKillCards(match, options = {}) {
  if (!match || !match.me) return [];
  const limit = Math.max(1, Number(options.limit) || 12);
  const meId = match.me.id;

  return (match.kills || [])
    .filter((kill) => kill && !kill.selfElim && kill.killerId && kill.killerId === meId)
    .sort((a, b) => (a.timeSec || 0) - (b.timeSec || 0))
    .slice(0, limit)
    .map((kill) => ({
      name: kill.victimName || 'Unbekannt',
      bot: Boolean(kill.victimBot),
      kills: typeof kill.victimKills === 'number' ? kill.victimKills : null,
      level: typeof kill.victimLevel === 'number' ? kill.victimLevel : null,
      placement: typeof kill.victimPlacement === 'number' ? kill.victimPlacement : null,
      weapon: kill.weapon && kill.weapon !== 'Unbekannt' ? kill.weapon : '',
      rarity: kill.rarity || '',
      distance: Number(kill.distance) || 0,
      timeSec: Math.round(Number(kill.timeSec) || 0),
    }));
}

module.exports = { buildKillCards };