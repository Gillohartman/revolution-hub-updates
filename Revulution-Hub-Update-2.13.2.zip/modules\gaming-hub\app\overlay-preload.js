const { contextBridge, ipcRenderer } = require('electron');

const listen = (channel, callback) => {
  const handler = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};

contextBridge.exposeInMainWorld('xhOverlay', {
  onConfig: (callback) => listen('xh:config', callback),
  onAim: (callback) => listen('xh:aim', callback),
  ready: () => ipcRenderer.send('xh:overlayReady'),
  hide: () => ipcRenderer.send('xh:overlayHide'),
});
