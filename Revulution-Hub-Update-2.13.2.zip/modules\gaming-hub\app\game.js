const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

// Fortnite startet je nach Build als "FortniteClient-Win64-Shipping.exe" oder
// (mit Easy Anti-Cheat/EOS) als "FortniteClient-Win64-Shipping_EAC_EOS.exe".
// Deshalb ueber das Praefix erkennen und nicht ueber den exakten Dateinamen.
const PROCESS_NAME = 'FortniteClient-Win64-Shipping.exe';
const PROCESS_PREFIX = 'fortniteclient';

/** Bildnamen aus der tasklist-CSV-Ausgabe, die zu Fortnite gehoeren. */
function fortniteImages(stdout) {
  return String(stdout || '')
    .split(/\r?\n/)
    .map((line) => line.split(',')[0].replace(/"/g, '').trim().toLowerCase())
    .filter((name) => name.startsWith(PROCESS_PREFIX));
}

/** Laeuft der Fortnite-Client gerade? Reine Prozessliste, kein Spielzugriff. */
function isFortniteRunning() {
  return new Promise((resolve) => {
    execFile(
      'tasklist',
      ['/FO', 'CSV', '/NH'],
      { windowsHide: true, timeout: 5000, maxBuffer: 4 * 1024 * 1024 },
      (error, stdout) => {
        if (error) return resolve(false);
        resolve(fortniteImages(stdout).length > 0);
      },
    );
  });
}

/** Neueste .replay-Datei im Ordner (mtime), oder null. */
function newestReplay(dir) {
  try {
    let newest = null;
    for (const name of fs.readdirSync(dir)) {
      if (!name.toLowerCase().endsWith('.replay')) continue;
      try {
        const stat = fs.statSync(path.join(dir, name));
        if (!newest || stat.mtimeMs > newest.mtime) {
          newest = { name, mtime: stat.mtimeMs, bytes: stat.size };
        }
      } catch {
        /* Datei verschwunden */
      }
    }
    return newest;
  } catch {
    return null;
  }
}

/**
 * Beobachtet Fortnite-Prozess und Replay-Ordner.
 * onStatus(running, previous) bei Wechsel, onNewReplay(file, previous) bei neuer Datei.
 */
function startWatch({ getDir, onStatus, onNewReplay, intervalMs = 6000 } = {}) {
  let running = null;
  let lastReplay = newestReplay(getDir ? getDir() : '');
  let ticks = 0;
  let stopped = false;

  const run = async () => {
    if (stopped) return;
    ticks += 1;

    const nowRunning = await isFortniteRunning();
    if (stopped) return;
    if (nowRunning !== running) {
      const previous = running;
      running = nowRunning;
      try {
        onStatus?.(nowRunning, previous);
      } catch {
        /* Callback-Fehler ignorieren */
      }
    }

    if (ticks % 3 === 0) {
      const next = newestReplay(getDir ? getDir() : '');
      if (next && (!lastReplay || next.name !== lastReplay.name || next.mtime > lastReplay.mtime)) {
        const previous = lastReplay;
        lastReplay = next;
        try {
          onNewReplay?.(next, previous);
        } catch {
          /* Callback-Fehler ignorieren */
        }
      }
    }
  };

  run();
  const timer = setInterval(run, Math.max(2000, intervalMs));

  return {
    stop() {
      stopped = true;
      clearInterval(timer);
    },
    isRunning: () => running === true,
  };
}

module.exports = {
  isFortniteRunning,
  newestReplay,
  startWatch,
  fortniteImages,
  PROCESS_NAME,
  PROCESS_PREFIX,
};