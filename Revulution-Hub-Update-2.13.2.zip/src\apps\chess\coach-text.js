'use strict';

/* Satzbausteine des Coaches in Deutsch, Englisch und Spanisch. */
(function (root) {
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  const list = (items, and) => (items.length < 2 ? items.join('') : `${items.slice(0, -1).join(', ')} ${and} ${items[items.length - 1]}`);

  const DE_NOM = ['', 'Bauer', 'Springer', 'Läufer', 'Turm', 'Dame', 'König'];
  const DE_ACC = ['', 'Bauern', 'Springer', 'Läufer', 'Turm', 'Dame', 'König'];
  const EN = ['', 'pawn', 'knight', 'bishop', 'rook', 'queen', 'king'];
  const ES = ['', 'peón', 'caballo', 'alfil', 'torre', 'dama', 'rey'];
  const ES_FEM = [0, 0, 0, 0, 1, 1, 0];
  const Q = 5, K = 6;

  const de = {
    own: (t, c = 'nom') => (t === Q ? (c === 'dat' ? 'deiner Dame' : 'deine Dame') : c === 'nom' ? `dein ${DE_NOM[t]}` : c === 'dat' ? `deinem ${DE_ACC[t]}` : `deinen ${DE_ACC[t]}`),
    enemy: (t, c = 'nom') => (t === Q ? (c === 'dat' ? 'der gegnerischen Dame' : 'die gegnerische Dame') : c === 'nom' ? `der gegnerische ${DE_NOM[t]}` : c === 'dat' ? `dem gegnerischen ${DE_ACC[t]}` : `den gegnerischen ${DE_ACC[t]}`),
    pron: (t) => (t === Q ? 'sie' : 'ihn'),
    pts: (n) => (n === 1 ? '1 Punkt' : `${n} Punkte`),
    on: (sq) => `auf ${sq}`,
    and: 'und',
    mate1: (p, r) => `Nach ${p} kann der Gegner dich <b>sofort mattsetzen</b>: ${r}.`,
    mateN: (p, n, l) => `Nach ${p} hat der Gegner ein <b>erzwungenes Matt in ${n} Zügen</b>: ${l}.`,
    missMate1: (b) => `Du hattest <b>Matt in 1</b>: ${b}!`,
    missMateN: (n, l) => `Du hattest ein <b>Matt in ${n}</b>: ${l}.`,
    hangs: (t, sq, defended, reply, lost) => `${cap(de.own(t))} auf ${sq} ist dort ${defended ? 'nicht ausreichend gedeckt' : '<b>völlig ungedeckt</b>'}.${reply ? ` ${reply} schlägt ${de.pron(t)}${lost ? ` und du verlierst ${de.pts(lost)} Material` : ''}.` : ''}`,
    hungBefore: (t, sq, reply) => `${cap(de.own(t))} auf ${sq} <b>hing schon vorher</b> und ist immer noch nicht sicher – ${reply ? `${reply} schlägt ${de.pron(t)}. ` : ''}Du hättest ${de.pron(t)} wegziehen oder decken müssen.`,
    leftUnprot: (t, sq, mover, from, reply) => `Dein Zug lässt ${de.own(t, 'acc')} auf ${sq} <b>ungeschützt</b>${mover ? ` – ${de.own(mover)} hat ${de.pron(t)} vorher von ${from} aus gedeckt` : ''}.${reply ? ` ${reply} schlägt ${de.pron(t)}.` : ''}`,
    fork: (r, at, targets) => `<b>Gabel!</b> Mit ${r} greift ${de.enemy(at)} gleichzeitig ${list(targets.map(([t, sq]) => `${de.own(t, 'acc')} auf ${sq}`), 'und')} an – beides kannst du nicht retten.`,
    pin: (r, ft, fsq, bt) => `<b>Fesselung:</b> Nach ${r} steht ${de.own(ft)} auf ${fsq} vor ${bt === K ? 'deinem König' : de.own(bt, 'dat')} und darf ${bt === K ? 'nicht' : 'kaum'} wegziehen.`,
    skewer: (r, ft, fsq, bt) => `<b>Spieß:</b> ${r} greift ${de.own(ft, 'acc')} auf ${fsq} an – zieht ${ft === Q ? 'sie' : 'er'} weg, fällt ${de.own(bt)} dahinter.`,
    disc: (r) => `<b>Abzugsschach:</b> ${r} öffnet eine Linie auf deinen König und greift dabei noch etwas an.`,
    lost: (l, n) => `Nach der besten Antwort ${l} hast du <b>${de.pts(n)} weniger Material</b>.`,
    missFree: (t, sq, b) => `<b>Verpasst:</b> ${cap(de.enemy(t))} auf ${sq} war <b>ungedeckt</b> – mit ${b} hättest du ${de.pron(t)} gratis geschlagen.`,
    missGain: (b, n, l) => `<b>Verpasst:</b> Mit ${b} hättest du ${de.pts(n)} Material gewonnen: ${l}.`,
    tipQueen: 'Die Dame so früh herauszubringen ist riskant: Der Gegner entwickelt seine Figuren und greift sie dabei mit Tempo an.',
    tipKing: 'Mit diesem Königszug verlierst du das Recht zur <b>Rochade</b> – dein König bleibt in der Mitte angreifbar.',
    tipRim: '„Springer am Rand bringt Kummer und Schand“: Am Rand kontrolliert der Springer nur halb so viele Felder.',
    tipPawns: 'Bauernzüge vor dem eigenen König schwächen deine Königsstellung – oft öffnen sich dadurch Diagonalen zum König.',
    tipTwice: (n) => `Du ziehst dieselbe Figur mehrmals, während ${n} Leichtfiguren noch auf der Grundreihe stehen. Entwickle erst alle Figuren.`,
    tipCastle: (b) => `Besser war die <b>Rochade</b> (${b}): Bring deinen König in Sicherheit, bevor du angreifst.`,
    tipDevelop: (b) => `${b} bringt eine neue Figur ins Spiel – in der Eröffnung zählt jedes Tempo.`,
    whyCheck: 'gibt Schach',
    whyCapture: (t) => `schlägt ${de.enemy(t, 'acc')}`,
    whyFork: (items) => `gabelt ${list(items.map(([t, sq]) => `${de.enemy(t, 'acc')} (${sq})`), 'und')}`,
    whyAttack: (t, sq) => `greift ${de.enemy(t, 'acc')} auf ${sq} an`,
    whySave: (t) => `rettet ${de.own(t, 'acc')}, ${t === Q ? 'die' : 'der'} angegriffen war`,
    whyCastle: 'bringt den König in Sicherheit',
    stronger: (b, e1, e2) => `${b} ist hier stärker. Nach deinem Zug wird deine Stellung schwächer: Die Bewertung fällt von ${e1} auf ${e2}.`,
    idea: (l) => `Die Idee hinter dem besseren Zug: ${l}.`,
    titles: { blunder: 'Oh, wait a minute…', mistake: 'Oh, wait a minute…', miss: 'Oh, wait a minute… da war mehr drin!', inaccuracy: 'Hmm, wait a minute…', good: 'Fast! Es gibt noch etwas Besseres', other: 'Kurz nachgedacht…' },
    brilliant: (san, t, sq, l) => `${san}: Du lässt ${t ? `${de.own(t, 'acc')} auf ${sq}` : 'Material'} absichtlich stehen – nimmt der Gegner das Opfer an, steht er schlechter. Erwartete Folge: ${l}. Stark gesehen!`,
    great: (san) => `${san} war der <b>einzige</b> wirklich gute Zug in dieser Stellung.`,
  };

  const en = {
    own: (t) => `your ${EN[t]}`,
    enemy: (t) => `the enemy ${EN[t]}`,
    pron: () => 'it',
    pts: (n) => (n === 1 ? '1 point' : `${n} points`),
    and: 'and',
    mate1: (p, r) => `After ${p} the opponent can <b>checkmate you right away</b>: ${r}.`,
    mateN: (p, n, l) => `After ${p} the opponent has a <b>forced mate in ${n}</b>: ${l}.`,
    missMate1: (b) => `You had <b>mate in 1</b>: ${b}!`,
    missMateN: (n, l) => `You had a <b>mate in ${n}</b>: ${l}.`,
    hangs: (t, sq, defended, reply, lost) => `${cap(en.own(t))} on ${sq} is ${defended ? 'not defended well enough' : '<b>completely undefended</b>'} there.${reply ? ` ${reply} takes it${lost ? ` and you lose ${en.pts(lost)} of material` : ''}.` : ''}`,
    hungBefore: (t, sq, reply) => `${cap(en.own(t))} on ${sq} <b>was already hanging</b> and still isn’t safe – ${reply ? `${reply} takes it. ` : ''}You should have moved or defended it.`,
    leftUnprot: (t, sq, mover, from, reply) => `Your move leaves ${en.own(t)} on ${sq} <b>unprotected</b>${mover ? ` – ${en.own(mover)} was guarding it from ${from}` : ''}.${reply ? ` ${reply} takes it.` : ''}`,
    fork: (r, at, targets) => `<b>Fork!</b> With ${r} ${en.enemy(at)} attacks ${list(targets.map(([t, sq]) => `${en.own(t)} on ${sq}`), 'and')} at the same time – you can’t save both.`,
    pin: (r, ft, fsq, bt) => `<b>Pin:</b> after ${r}, ${en.own(ft)} on ${fsq} stands in front of ${en.own(bt)} and ${bt === K ? 'cannot' : 'can hardly'} move.`,
    skewer: (r, ft, fsq, bt) => `<b>Skewer:</b> ${r} attacks ${en.own(ft)} on ${fsq} – if it moves away, ${en.own(bt)} behind it falls.`,
    disc: (r) => `<b>Discovered check:</b> ${r} opens a line to your king and attacks something else at the same time.`,
    lost: (l, n) => `After the best reply ${l} you have <b>${en.pts(n)} less material</b>.`,
    missFree: (t, sq, b) => `<b>Missed:</b> ${en.enemy(t)} on ${sq} was <b>undefended</b> – ${b} would have won it for free.`,
    missGain: (b, n, l) => `<b>Missed:</b> ${b} would have won ${en.pts(n)} of material: ${l}.`,
    tipQueen: 'Bringing the queen out this early is risky: the opponent develops pieces while attacking her and gains time.',
    tipKing: 'This king move costs you the right to <b>castle</b> – your king stays exposed in the center.',
    tipRim: '“A knight on the rim is dim”: on the edge a knight controls only half as many squares.',
    tipPawns: 'Pawn moves in front of your own king weaken your king’s shelter – diagonals towards the king often open up.',
    tipTwice: (n) => `You move the same piece again while ${n} minor pieces are still on the back rank. Develop all your pieces first.`,
    tipCastle: (b) => `<b>Castling</b> (${b}) was better: get your king to safety before you attack.`,
    tipDevelop: (b) => `${b} brings a new piece into play – in the opening every tempo counts.`,
    whyCheck: 'gives check',
    whyCapture: (t) => `captures ${en.enemy(t)}`,
    whyFork: (items) => `forks ${list(items.map(([t, sq]) => `${en.enemy(t)} (${sq})`), 'and')}`,
    whyAttack: (t, sq) => `attacks ${en.enemy(t)} on ${sq}`,
    whySave: (t) => `saves ${en.own(t)}, which was under attack`,
    whyCastle: 'brings the king to safety',
    stronger: (b, e1, e2) => `${b} is stronger here. After your move your position gets worse: the evaluation drops from ${e1} to ${e2}.`,
    idea: (l) => `The idea behind the better move: ${l}.`,
    titles: { blunder: 'Oh, wait a minute…', mistake: 'Oh, wait a minute…', miss: 'Oh, wait a minute… there was more!', inaccuracy: 'Hmm, wait a minute…', good: 'Close! There’s something better', other: 'Let’s think for a second…' },
    brilliant: (san, t, sq, l) => `${san}: you leave ${t ? `${en.own(t)} on ${sq}` : 'material'} hanging on purpose – if the opponent takes the bait, they end up worse. Expected line: ${l}. Great vision!`,
    great: (san) => `${san} was the <b>only</b> really good move in this position.`,
  };

  const esArt = (t, own) => (own ? `tu ${ES[t]}` : `${ES_FEM[t] ? 'la' : 'el'} ${ES[t]} rival`);
  const es = {
    own: (t) => esArt(t, true),
    enemy: (t) => esArt(t, false),
    pron: (t) => (ES_FEM[t] ? 'la' : 'lo'),
    pts: (n) => (n === 1 ? '1 punto' : `${n} puntos`),
    and: 'y',
    mate1: (p, r) => `Tras ${p} el rival puede <b>darte mate enseguida</b>: ${r}.`,
    mateN: (p, n, l) => `Tras ${p} el rival tiene un <b>mate forzado en ${n}</b>: ${l}.`,
    missMate1: (b) => `¡Tenías <b>mate en 1</b>: ${b}!`,
    missMateN: (n, l) => `Tenías un <b>mate en ${n}</b>: ${l}.`,
    hangs: (t, sq, defended, reply, lost) => `${cap(es.own(t))} en ${sq} ${defended ? 'no está bien defendid' + (ES_FEM[t] ? 'a' : 'o') : `está <b>completamente indefens${ES_FEM[t] ? 'a' : 'o'}</b>`}.${reply ? ` ${reply} ${es.pron(t)} captura${lost ? ` y pierdes ${es.pts(lost)} de material` : ''}.` : ''}`,
    hungBefore: (t, sq, reply) => `${cap(es.own(t))} en ${sq} <b>ya estaba colgad${ES_FEM[t] ? 'a' : 'o'}</b> y sigue sin estar a salvo – ${reply ? `${reply} ${es.pron(t)} captura. ` : ''}Tenías que moverl${ES_FEM[t] ? 'a' : 'o'} o defenderl${ES_FEM[t] ? 'a' : 'o'}.`,
    leftUnprot: (t, sq, mover, from, reply) => `Tu jugada deja ${es.own(t)} en ${sq} <b>sin protección</b>${mover ? ` – ${es.own(mover)} ${es.pron(t)} defendía desde ${from}` : ''}.${reply ? ` ${reply} ${es.pron(t)} captura.` : ''}`,
    fork: (r, at, targets) => `<b>¡Ataque doble!</b> Con ${r} ${es.enemy(at)} ataca a la vez ${list(targets.map(([t, sq]) => `${es.own(t)} en ${sq}`), 'y')} – no puedes salvar ambas piezas.`,
    pin: (r, ft, fsq, bt) => `<b>Clavada:</b> tras ${r}, ${es.own(ft)} en ${fsq} está delante de ${es.own(bt)} y ${bt === K ? 'no puede' : 'apenas puede'} moverse.`,
    skewer: (r, ft, fsq, bt) => `<b>Pincho:</b> ${r} ataca ${es.own(ft)} en ${fsq} – si se aparta, cae ${es.own(bt)} que está detrás.`,
    disc: (r) => `<b>Jaque a la descubierta:</b> ${r} abre una línea hacia tu rey y además ataca otra pieza.`,
    lost: (l, n) => `Tras la mejor respuesta ${l} tienes <b>${es.pts(n)} menos de material</b>.`,
    missFree: (t, sq, b) => `<b>Perdiste la ocasión:</b> ${es.enemy(t)} en ${sq} estaba <b>indefens${ES_FEM[t] ? 'a' : 'o'}</b> – con ${b} ${es.pron(t)} ganabas gratis.`,
    missGain: (b, n, l) => `<b>Perdiste la ocasión:</b> con ${b} ganabas ${es.pts(n)} de material: ${l}.`,
    tipQueen: 'Sacar la dama tan pronto es arriesgado: el rival desarrolla sus piezas atacándola y gana tiempos.',
    tipKing: 'Con esta jugada de rey pierdes el derecho a <b>enrocar</b> – tu rey queda expuesto en el centro.',
    tipRim: '«Caballo en el borde, caballo que se pierde»: en la banda controla la mitad de casillas.',
    tipPawns: 'Mover los peones delante de tu rey debilita su refugio – suelen abrirse diagonales hacia el rey.',
    tipTwice: (n) => `Mueves la misma pieza otra vez mientras ${n} piezas menores siguen en la primera fila. Desarrolla primero todas tus piezas.`,
    tipCastle: (b) => `Era mejor <b>enrocar</b> (${b}): pon tu rey a salvo antes de atacar.`,
    tipDevelop: (b) => `${b} saca una pieza nueva – en la apertura cada tiempo cuenta.`,
    whyCheck: 'da jaque',
    whyCapture: (t) => `captura ${es.enemy(t)}`,
    whyFork: (items) => `ataca a la vez ${list(items.map(([t, sq]) => `${es.enemy(t)} (${sq})`), 'y')}`,
    whyAttack: (t, sq) => `ataca ${es.enemy(t)} en ${sq}`,
    whySave: (t) => `salva ${es.own(t)}, que estaba atacad${ES_FEM[t] ? 'a' : 'o'}`,
    whyCastle: 'pone al rey a salvo',
    stronger: (b, e1, e2) => `${b} es más fuerte aquí. Tras tu jugada tu posición empeora: la valoración baja de ${e1} a ${e2}.`,
    idea: (l) => `La idea de la mejor jugada: ${l}.`,
    titles: { blunder: 'Oh, wait a minute…', mistake: 'Oh, wait a minute…', miss: 'Oh, wait a minute… ¡había más!', inaccuracy: 'Hmm, wait a minute…', good: '¡Casi! Hay algo mejor', other: 'Pensemos un momento…' },
    brilliant: (san, t, sq, l) => `${san}: dejas ${t ? `${es.own(t)} en ${sq}` : 'material'} a propósito – si el rival acepta el sacrificio, queda peor. Línea esperada: ${l}. ¡Muy bien visto!`,
    great: (san) => `${san} era la <b>única</b> jugada realmente buena en esta posición.`,
  };

  root.ChessCoachText = { de, en, es };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.ChessCoachText;
})(typeof self !== 'undefined' ? self : globalThis);
