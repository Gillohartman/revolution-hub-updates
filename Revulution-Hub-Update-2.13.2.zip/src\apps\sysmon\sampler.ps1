# System-Monitor sampler: one JSON line per second.
# Uses language-neutral WMI performance classes so it works on German Windows too.
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [System.Text.Encoding]::UTF8

$flag = $args[0]
$cores = [Environment]::ProcessorCount
$gpuName = (Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notlike '*Basic*' } | Select-Object -First 1).Name
$tick = 0

while ($true) {
  $gpu = 0
  $engines = Get-CimInstance -ClassName Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine
  if ($engines) {
    $used = ($engines | Where-Object { $_.Name -like '*engtype_3D*' } | Measure-Object -Property UtilizationPercentage -Sum).Sum
    if ($null -ne $used) { $gpu = [math]::Min(100, [math]::Round([double]$used, 0)) }
  }

  $down = 0; $up = 0
  $nics = Get-CimInstance -ClassName Win32_PerfFormattedData_Tcpip_NetworkInterface
  if ($nics) {
    $down = ($nics | Measure-Object -Property BytesReceivedPersec -Sum).Sum
    $up = ($nics | Measure-Object -Property BytesSentPersec -Sum).Sum
  }

  $diskBusy = 0; $diskRead = 0; $diskWrite = 0
  $disk = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfDisk_PhysicalDisk | Where-Object { $_.Name -eq '_Total' } | Select-Object -First 1
  if ($disk) {
    $diskBusy = [math]::Min(100, [double]$disk.PercentDiskTime)
    $diskRead = [double]$disk.DiskReadBytesPersec
    $diskWrite = [double]$disk.DiskWriteBytesPersec
  }

  $procs = $null
  if ($flag -and (Test-Path $flag) -and ($tick % 2 -eq 0)) {
    $procs = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfProc_Process |
      Where-Object { $_.Name -ne '_Total' -and $_.Name -ne 'Idle' -and $_.IDProcess -ne 0 } |
      ForEach-Object {
        [ordered]@{
          pid  = [int]$_.IDProcess
          name = ($_.Name -replace '#\d+$', '')
          cpu  = [math]::Round([double]$_.PercentProcessorTime / $cores, 1)
          mem  = [double]$_.WorkingSetPrivate
        }
      }
  }
  $tick += 1

  [ordered]@{
    gpu       = $gpu
    gpuName   = $gpuName
    down      = $down
    up        = $up
    diskBusy  = $diskBusy
    diskRead  = $diskRead
    diskWrite = $diskWrite
    procs     = $procs
  } | ConvertTo-Json -Compress -Depth 4

  Start-Sleep -Milliseconds 900
}
