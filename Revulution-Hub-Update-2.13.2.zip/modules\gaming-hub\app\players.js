// Spieler-Buch: sammelt alle Gegner, die du erledigt hast, dauerhaft in einer
// JSON-Datei im App-Ordner. Damit erkennt das Panel beim naechsten Kill in einer
// anderen Runde, ob du den Spieler schon kennst.
const fs = require('fs');
const path = require('path');

function normalizeName(name) {
  return String(name || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

class PlayerBook {
  constructor(file) {
    this.file = file;
    this.data = { version: 1, players: {}, updatedAt: null };
    this.timer = null;
  }

  load() {
    try {
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      const players = parsed && typeof parsed.players === 'object' && parsed.players ? parsed.players : {};
      this.data = { version: 1, players, updatedAt: parsed?.updatedAt || null };
    } catch {
      this.data = { version: 1, players: {}, updatedAt: null };
    }
    return this.data;
  }

  save() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.flush(), 400);
  }

  flush() {
    clearTimeout(this.timer);
    this.timer = null;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = `${this.file}.tmp`;
      this.data.updatedAt = new Date().toISOString();
      fs.writeFileSync(tmp, JSON.stringify(this.data), 'utf8');
      fs.renameSync(tmp, this.file);
    } catch (error) {
      console.error('Spieler-Datei konnte nicht geschrieben werden:', error.message);
    }
  }

  key(name) {
    return normalizeName(name);
  }

  /** Stand vor dem naechsten Eintrag (ohne etwas zu veraendern). */
  stat(name) {
    const key = this.key(name);
    const entry = key ? this.data.players[key] : null;
    if (!entry) {
      return { name: String(name || ''), kills: 0, downs: 0, encounters: 0, level: null, theirKills: null, placement: null, known: false };
    }
    return {
      name: entry.name,
      kills: Number(entry.kills) || 0,
      downs: Number(entry.downs) || 0,
      encounters: (Number(entry.kills) || 0) + (Number(entry.downs) || 0),
      level: entry.level ?? null,
      theirKills: entry.theirKills ?? null,
      placement: entry.placement ?? null,
      known: true,
    };
  }

  /**
   * Traegt einen Gegner ein.
   * state: 'down' (nur geknockt) oder 'dead' (eliminiert)
   * counted=false -> nur Daten anreichern, keinen Kill zaehlen (Replay-Nachtrag).
   */
  record({ name, state = 'dead', level, theirKills, placement, bot, matchDate, counted = true } = {}) {
    const key = this.key(name);
    if (!key) return null;

    const now = new Date().toISOString();
    const existing = this.data.players[key] || {
      name: String(name),
      firstSeen: now,
      kills: 0,
      downs: 0,
    };

    if (name) existing.name = String(name).slice(0, 40);
    existing.lastSeen = now;
    if (matchDate) existing.lastMatch = String(matchDate);
    if (typeof level === 'number' && level > 0) existing.level = level;
    if (typeof theirKills === 'number' && theirKills >= 0) existing.theirKills = theirKills;
    if (typeof placement === 'number' && placement > 0) existing.placement = placement;
    if (typeof bot === 'boolean') existing.bot = bot;

    if (counted) {
      if (state === 'down') existing.downs = (Number(existing.downs) || 0) + 1;
      else existing.kills = (Number(existing.kills) || 0) + 1;
    }

    this.data.players[key] = existing;
    this.save();
    return existing;
  }

  all(limit = 400) {
    return Object.entries(this.data.players)
      .map(([key, entry]) => ({
        key,
        name: entry.name || key,
        kills: Number(entry.kills) || 0,
        downs: Number(entry.downs) || 0,
        bot: Boolean(entry.bot),
        level: entry.level ?? null,
        theirKills: entry.theirKills ?? null,
        placement: entry.placement ?? null,
        lastSeen: entry.lastSeen || null,
        firstSeen: entry.firstSeen || null,
      }))
      .sort((a, b) => b.kills + b.downs - (a.kills + a.downs) || String(b.lastSeen).localeCompare(String(a.lastSeen)))
      .slice(0, limit);
  }

  count() {
    return Object.keys(this.data.players).length;
  }

  clear() {
    this.data.players = {};
    this.flush();
  }
}

module.exports = { PlayerBook, normalizeName };
