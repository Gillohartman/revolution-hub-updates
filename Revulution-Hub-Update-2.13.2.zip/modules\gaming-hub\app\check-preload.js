const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('clipCheck', {
  onFlash: (callback) => {
    ipcRenderer.on('check:flash', () => callback());
  },
});
