'use strict';

/*
 * Übersetzt die Oberfläche zur Laufzeit (Deutsch → Englisch/Spanisch) anhand eines
 * Wörterbuchs. Beobachtet Änderungen, damit auch neu gezeichnete Teile übersetzt werden.
 * Eingabefelder und bearbeitbare Bereiche (z. B. Dokumente) bleiben unangetastet.
 */
(function () {
  if (window.RevTranslate) return;
  const DICT = window.__REV_DICT || {};
  const norm = (s) => s.replace(/\s+/g, ' ').trim();
  const LOWER = new Map(Object.entries(DICT).map(([k, v]) => [k.toLowerCase(), v]));
  const ATTRS = ['placeholder', 'title', 'aria-label'];
  let lang = 'de';
  const texts = new Map(); // Textknoten → { base, out }
  const attrs = new WeakMap(); // Element → { attr: { base, out } }

  function lookup(base) {
    const k = norm(base);
    if (!k) return null;
    const e = DICT[k];
    if (e) return lang === 'en' ? e[0] : e[1];
    // GROSSGESCHRIEBENE Überschriften ohne eigenen Eintrag
    const low = LOWER.get(k.toLowerCase());
    if (low) {
      const out = lang === 'en' ? low[0] : low[1];
      return k === k.toUpperCase() ? out.toUpperCase() : out;
    }
    // „Text:“ oder „Text …“ → Wörterbuch ohne Satzzeichen am Ende
    const m = /^(.*?)([:…]|\s…)$/.exec(k);
    if (m && DICT[m[1].trim()]) return (lang === 'en' ? DICT[m[1].trim()][0] : DICT[m[1].trim()][1]) + m[2];
    return null;
  }

  function skip(node) {
    const el = node.nodeType === 1 ? node : node.parentElement;
    if (!el) return true;
    return Boolean(el.closest('script,style,textarea,input,[contenteditable="true"],[contenteditable=""],.paper,.no-translate,code,pre'));
  }

  function doText(node) {
    if (skip(node)) return;
    let rec = texts.get(node);
    const now = node.nodeValue;
    if (!rec || (now !== rec.out && now !== rec.base)) {
      rec = { base: now, out: now };
      texts.set(node, rec);
    }
    let want = rec.base;
    if (lang !== 'de') {
      const t = lookup(rec.base);
      if (t) {
        const lead = /^\s*/.exec(rec.base)[0], tail = /\s*$/.exec(rec.base)[0];
        want = lead + t + tail;
      }
    }
    if (node.nodeValue !== want) {
      rec.out = want;
      node.nodeValue = want;
    } else rec.out = want;
  }

  function doAttrs(el) {
    if (skip(el) && el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA') return;
    let map = attrs.get(el);
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      map = map || {};
      const now = el.getAttribute(a);
      let rec = map[a];
      if (!rec || (now !== rec.out && now !== rec.base)) rec = map[a] = { base: now, out: now };
      const want = lang === 'de' ? rec.base : lookup(rec.base) || rec.base;
      rec.out = want;
      if (now !== want) el.setAttribute(a, want);
    }
    if (map) attrs.set(el, map);
  }

  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    if (root.nodeType === 1) doAttrs(root);
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let n;
    while ((n = tw.nextNode())) {
      if (n.nodeType === 3) {
        if (n.nodeValue.trim()) doText(n);
      } else doAttrs(n);
    }
  }

  let observer = null;
  function observe() {
    if (observer || !document.body) return;
    observer = new MutationObserver((list) => {
      for (const m of list) {
        if (m.type === 'characterData') {
          const rec = texts.get(m.target);
          if (rec && m.target.nodeValue === rec.out) continue;
          doText(m.target);
        } else if (m.type === 'attributes') {
          doAttrs(m.target);
        } else for (const n of m.addedNodes) walk(n);
      }
    });
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  window.RevTranslate = {
    set(next) {
      lang = ['de', 'en', 'es'].includes(next) ? next : 'de';
      document.documentElement.lang = lang;
      walk(document.body);
      observe();
    },
    get lang() {
      return lang;
    },
  };
})();
