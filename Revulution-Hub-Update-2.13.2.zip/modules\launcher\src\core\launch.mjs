import path from "node:path";
import fs from "node:fs";
import { spawn } from "node:child_process";
import {
  assetsDir, librariesDir, nativesDir, versionsDir, logsDir, gameDir, ensureDir, objectsDir,
} from "./paths.mjs";
import { resolveVersion, collectLibraries, rulesAllow, LAUNCHER_NAME, LAUNCHER_VERSION, currentOsName } from "./mojang.mjs";
import { fastStartFlags } from "./perf.mjs";

const PLACEHOLDER_RE = /\$\{([^}]+)\}/g;

/** Substitute ${placeholders} in a launch argument. Unknown keys are left as-is. */
export function substitute(value, map) {
  return String(value).replace(PLACEHOLDER_RE, (match, key) => (key in map ? String(map[key]) : match));
}

/** Keep arguments whose rules pass, and collect their (possibly multi-part) values. */
export function filterArguments(list, features, map) {
  const out = [];
  for (const entry of list || []) {
    if (typeof entry === "string") {
      out.push(substitute(entry, map));
      continue;
    }
    if (!entry || typeof entry !== "object") continue;
    if (entry.rules && !rulesAllow(entry.rules, features)) continue;
    const value = entry.value;
    if (Array.isArray(value)) for (const item of value) out.push(substitute(item, map));
    else if (typeof value === "string") out.push(substitute(value, map));
  }
  return out;
}

/** Build the classpath from a resolved version's libraries plus its client jar. */
export function buildClasspath(version, { extraJars = [] } = {}) {
  const { classpath } = collectLibraries(version);
  const entries = [];
  for (const library of classpath) {
    const full = path.join(librariesDir(), library.path || "");
    if (fs.existsSync(full)) entries.push(full);
  }
  const clientJar = path.join(versionsDir(), version.id, `${version.id}.jar`);
  if (fs.existsSync(clientJar)) entries.push(clientJar);
  for (const jar of extraJars) if (fs.existsSync(jar)) entries.push(jar);
  return entries;
}

export function buildPlaceholders({ version, instance, account, settings, javaMajor }) {
  const tokens = {
    auth_player_name: account?.name || "Player",
    auth_uuid: (account?.uuid || "").replace(/-/g, ""),
    auth_access_token: account?.accessToken || "0",
    auth_session: `token:${account?.accessToken || "0"}:${account?.uuid || ""}`,
    auth_xuid: account?.xuid || "0",
    user_type: account?.type === "msa" ? "msa" : "legacy",
    user_properties: "{}",
    clientid: settings?.microsoftClientId || "",
    version_name: version.id,
    version_type: version.type || "release",
    game_directory: gameDir(instance.id),
    assets_root: assetsDir(),
    game_assets: path.join(objectsDir(), "..", "virtual", version.assetIndex?.id || "legacy"),
    assets_index_name: version.assetIndex?.id || "legacy",
    natives_directory: nativesDir(version.id),
    library_directory: librariesDir(),
    classpath_separator: path.delimiter,
    classpath: buildClasspath(version).join(path.delimiter),
    launcher_name: LAUNCHER_NAME,
    launcher_version: LAUNCHER_VERSION,
    resolution_width: instance.resolution?.width || 1280,
    resolution_height: instance.resolution?.height || 720,
    quickPlayPath: path.join(logsDir(), "quickPlay", "quickPlayLog.json"),
    quickPlaySingleplayer: instance.quickPlay?.world || "",
    quickPlayMultiplayer: instance.server?.autoConnect
      ? `${instance.server.ip}:${instance.server.port || 25565}`
      : instance.quickPlay?.server || "",
    javaMajor: javaMajor || 17,
  };
  return tokens;
}

function featureFlags(instance) {
  return {
    is_demo_user: false,
    has_custom_resolution: Boolean(instance.resolution && (instance.resolution.width !== 1280 || instance.resolution.height !== 720)),
    has_quick_plays_support: true,
    is_quick_play_singleplayer: Boolean(instance.quickPlay?.enabled && instance.quickPlay?.world),
    is_quick_play_multiplayer: Boolean((instance.quickPlay?.enabled && instance.quickPlay?.server) || instance.server?.autoConnect),
    is_quick_play_realms: false,
  };
}

const LEGACY_JVM_ARGS = ["-Djava.library.path=${natives_directory}", "-cp", "${classpath}"];

/**
 * Assemble the full java command line for an instance.
 * Returns a plain object so it can be shown in the UI ("preview command").
 */
export function buildLaunchCommand({ version, instance, account, settings, javaPath, javaMajor }) {
  const placeholders = buildPlaceholders({ version, instance, account, settings, javaMajor });
  const features = featureFlags(instance);

  const memoryMax = instance.java?.memoryMaxMb || settings.maxMemoryMb || 4096;
  // With fast start the heap is reserved up front: growing from 512 MB to 4 GB during the
  // first minute of play costs several full GCs and resizes, which is exactly the stutter
  // people notice. An explicit per-instance minimum still wins.
  // A minimum above the 512 MB default is a deliberate choice and is kept; the default is
  // replaced by the maximum so the heap never has to grow while the world loads.
  const explicitMin = instance.java?.memoryMinMb;
  const memoryMin = settings.fastStart === false
    ? (explicitMin || settings.minMemoryMb || 512)
    : (explicitMin && explicitMin > 512 ? explicitMin : memoryMax);

  const jvmTemplate = version.arguments?.jvm?.length ? version.arguments.jvm : LEGACY_JVM_ARGS;
  const jvmArgs = filterArguments(jvmTemplate, features, placeholders);

  const prefix = [`-Xms${memoryMin}M`, `-Xmx${memoryMax}M`];
  // Fast start: tuned G1 flags plus a class-data-sharing archive. Inserted before the
  // user's own arguments so anything configured for this instance still wins.
  if (settings.fastStart !== false) {
    prefix.push(...fastStartFlags({
      javaMajor,
      versionId: version.id,
      loaderType: instance.loader?.type,
    }));
  }
  const userJvm = [
    instance.java?.jvmArgs,
    settings.jvmArgs,
  ].filter(Boolean).join(" ").trim();
  if (userJvm) prefix.push(...userJvm.split(/\s+/).filter(Boolean));

  prefix.push(`-Dminecraft.launcher.brand=${LAUNCHER_NAME}`);
  prefix.push(`-Dminecraft.launcher.version=${LAUNCHER_VERSION}`);
  if (currentOsName() === "osx" && !jvmArgs.includes("-XstartOnFirstThread")) prefix.push("-XstartOnFirstThread");

  const gameTemplate = version.arguments?.game?.length
    ? version.arguments.game
    : String(version.minecraftArguments || "").split(" ").filter(Boolean);
  const gameArgs = filterArguments(gameTemplate, features, placeholders);

  // Custom resolution / fullscreen are not part of the argument template.
  if (instance.resolution?.fullscreen) gameArgs.push("--fullscreen");
  if (instance.resolution && (instance.resolution.width !== 1280 || instance.resolution.height !== 720)) {
    gameArgs.push("--width", String(instance.resolution.width || 1280), "--height", String(instance.resolution.height || 720));
  }
  if (instance.server?.autoConnect && instance.server?.ip) {
    gameArgs.push("--server", instance.server.ip, "--port", String(instance.server.port || 25565));
  }
  const userGame = [instance.java?.gameArgs, settings.gameArgs].filter(Boolean).join(" ").trim();
  if (userGame) gameArgs.push(...userGame.split(/\s+/).filter(Boolean));

  const args = [...prefix, ...jvmArgs, version.mainClass, ...gameArgs];
  return {
    javaPath,
    args,
    mainClass: version.mainClass,
    classpath: buildClasspath(version),
    cwd: gameDir(instance.id),
    jvmArgs: prefix,
    gameArgs,
    command: `"${javaPath}" ${args.map(quoteArg).join(" ")}`,
  };
}

function quoteArg(arg) {
  return /[\s"]/.test(arg) ? `"${arg.replace(/"/g, '\\"')}"` : arg;
}

export function launchLogFile(instanceId) {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return path.join(logsDir(), `${instanceId}-${stamp}.log`);
}

/**
 * Start Minecraft. `onLog(line, stream)` is called for every line of output and
 * `onExit({code, playTimeMs})` when the game closes.
 */
export function spawnGame({ command, instance, onLog = () => {}, onExit = () => {}, hidden = true }) {
  ensureDir(gameDir(instance.id));
  const logFile = launchLogFile(instance.id);
  const stream = fs.createWriteStream(logFile, { flags: "a" });
  const startedAt = Date.now();

  stream.write(`# Revolution ${LAUNCHER_VERSION} launch of ${instance.name} (${instance.versionId})\n`);
  stream.write(`# ${new Date().toISOString()}\n# ${command.command}\n\n`);

  const child = spawn(command.javaPath, command.args, {
    cwd: command.cwd,
    env: { ...process.env },
    windowsHide: hidden,
    stdio: ["ignore", "pipe", "pipe"],
  });

  const emit = (streamName) => (chunk) => {
    const text = chunk.toString("utf8");
    stream.write(text);
    for (const line of text.split(/\r?\n|\r/)) {
      if (line.trim().length) onLog(line, streamName);
    }
  };
  child.stdout.on("data", emit("stdout"));
  child.stderr.on("data", emit("stderr"));

  child.on("error", (err) => {
    stream.write(`\n# launch error: ${err.message}\n`);
    stream.end();
    onExit({ code: -1, error: err.message, logFile, playTimeMs: Date.now() - startedAt });
  });

  child.on("close", (code) => {
    const playTimeMs = Date.now() - startedAt;
    stream.write(`\n# process exited with code ${code} after ${Math.round(playTimeMs / 1000)}s\n`);
    stream.end();
    onExit({ code, playTimeMs, logFile });
  });

  return { child, pid: child.pid, logFile, startedAt };
}

/** Resolve everything needed to launch, without starting the process. */
export async function prepareLaunch({ instance, version: versionJson }) {
  const version = await resolveVersion(versionJson);
  const { classpath, natives } = collectLibraries(version, featureFlags(instance));
  return { version, classpath, natives };
}

export { versionsDir };
