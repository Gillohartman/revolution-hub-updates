import crypto from "node:crypto";
import { request, fetchJson } from "./http.mjs";

const MSA_DEVICE_CODE_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
const MSA_TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
const XBL_AUTH_URL = "https://user.auth.xboxlive.com/user/authenticate";
const XSTS_AUTH_URL = "https://xsts.auth.xboxlive.com/xsts/authorize";
const MC_AUTH_URL = "https://api.minecraftservices.com/authentication/login_with_xbox";
const MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile";
const MC_ENTITLEMENTS_URL = "https://api.minecraftservices.com/entitlements/mcstore";

const SCOPES = "XboxLive.signin offline_access";

/**
 * Auth endpoints must not be retried (a replayed token request is pointless and hides the real
 * reason), and their error bodies are the useful part. This returns the response for 4xx/5xx
 * too, so the caller can read Microsoft's error_description instead of "HTTP 400".
 */
async function authFetch(url, options, { timeout = 30000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    throw new AuthError(`Could not reach Microsoft (${error.message}). Check your connection and try again.`, "NETWORK");
  } finally {
    clearTimeout(timer);
  }
}

/** Responses on auth endpoints are JSON on success and usually JSON on failure too. */
async function readAuthJson(res) {
  const text = await res.text();
  try {
    return { data: JSON.parse(text), text };
  } catch {
    return { data: {}, text };
  }
}

/** XSTS error codes mapped to actionable messages. */
const XSTS_ERRORS = {
  2148916227: "This Microsoft account has been banned from Xbox Live.",
  2148916233: "This Microsoft account has no Xbox Live profile. Sign in to xbox.com once to create one, then retry.",
  2148916235: "Xbox Live is not available in this account's country or region.",
  2148916236: "This account needs adult verification. Complete the Xbox Live verification page and retry.",
  2148916237: "This account needs adult verification. Complete the Xbox Live verification page and retry.",
  2148916238: "This account is under 18 and must be added to a Microsoft family group by an adult first.",
};

export class AuthError extends Error {
  constructor(message, code) {
    super(message);
    this.name = "AuthError";
    this.code = code;
  }
}

export function deviceCodeUrl() {
  return MSA_DEVICE_CODE_URL;
}

/**
 * Microsoft reports a refused app registration with an AADSTS code. A raw code is useless to
 * a player, so map the ones a launcher owner can actually fix to what to click.
 */
function describeMsaError(data, status) {
  const text = data?.error_description || data?.error || `HTTP ${status}`;
  const code = Array.isArray(data?.error_codes) ? data.error_codes[0] : undefined;
  const hints = {
    700016: "Microsoft does not know this client ID. Copy the Application (client) ID from the app registration's Overview page.",
    700038: "Microsoft does not know this client ID. Copy the Application (client) ID from the app registration's Overview page.",
    7000218: "This app registration does not allow public clients. Entra portal -> Authentication -> Advanced settings -> Allow public client flows: Yes.",
    50059: "This app registration only accepts work or school accounts. Set Supported account types to 'Personal Microsoft accounts only'.",
    90002: "This app registration only accepts work or school accounts. Set Supported account types to 'Personal Microsoft accounts only'.",
  };
  const hint = hints[code];
  return hint ? `${hint} (Microsoft: ${text})` : `Microsoft refused the sign-in request: ${text}`;
}

/** Step 1: ask Microsoft for a device + user code the player enters in a browser. */
export async function startDeviceCode({ clientId }) {
  if (!clientId) throw new AuthError("A Microsoft client ID is required for online accounts. Add one under Accounts.", "NO_CLIENT_ID");
  const res = await authFetch(MSA_DEVICE_CODE_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: clientId, scope: SCOPES }).toString(),
  });
  const { data } = await readAuthJson(res);
  // Without this check a rejected registration produced a dialog with an empty code and a
  // spinner that failed minutes later - the actual reason was never shown.
  if (!res.ok || !data.device_code) {
    throw new AuthError(describeMsaError(data, res.status), data?.error || "DEVICE_CODE");
  }
  return {
    deviceCode: data.device_code,
    userCode: data.user_code,
    verificationUri: data.verification_uri,
    verificationUriComplete: data.verification_uri_complete || data.verification_uri,
    expiresIn: data.expires_in || 900,
    interval: data.interval || 5,
    message: data.message,
  };
}

/** Step 2: poll until the player finishes signing in. */
/** Waiting has to end the moment the dialog is dismissed; a plain timeout would keep the
 * process alive for the whole polling interval and still fire one more request afterwards. */
function waitFor(ms, signal) {
  const cancelled = () => new AuthError("Sign-in was cancelled.", "CANCELLED");
  if (signal?.aborted) return Promise.reject(cancelled());
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { cleanup(); resolve(); }, ms);
    const onAbort = () => { cleanup(); reject(cancelled()); };
    const cleanup = () => { clearTimeout(timer); signal?.removeEventListener("abort", onAbort); };
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

export async function pollDeviceCode({ clientId, deviceCode, interval = 5, expiresIn = 900, onTick = () => {}, signal }) {
  const deadline = Date.now() + expiresIn * 1000;
  let wait = Math.max(1, interval) * 1000;
  while (Date.now() < deadline) {
    if (signal?.aborted) throw new AuthError("Sign-in was cancelled.", "CANCELLED");
    await waitFor(wait, signal);
    const res = await fetch(MSA_TOKEN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        grant_type: "urn:ietf:params:oauth:grant-type:device_code",
        device_code: deviceCode,
      }).toString(),
    });
    const data = await res.json();
    if (res.ok) return data;
    if (data.error === "authorization_pending") {
      onTick({ status: "pending", remaining: Math.round((deadline - Date.now()) / 1000) });
      continue;
    }
    if (data.error === "slow_down") {
      wait += 2000;
      continue;
    }
    if (data.error === "authorization_declined") throw new AuthError("Sign-in was declined in the browser.", "DECLINED");
    if (data.error === "expired_token") throw new AuthError("The sign-in code expired. Start again.", "EXPIRED");
    throw new AuthError(data.error_description || data.error || "Microsoft sign-in failed.", data.error);
  }
  throw new AuthError("Timed out waiting for sign-in.", "TIMEOUT");
}

export async function refreshMicrosoftToken({ clientId, refreshToken }) {
  const res = await authFetch(MSA_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: clientId,
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      scope: SCOPES,
    }).toString(),
  });
  const { data } = await readAuthJson(res);
  if (!res.ok || !data.access_token) {
    // invalid_grant means the stored refresh token is dead (password change, revoked consent).
    const reason = data.error === "invalid_grant"
      ? "the stored Microsoft session is no longer valid - sign in again"
      : describeMsaError(data, res.status);
    throw new AuthError(`Could not refresh the Microsoft session: ${reason}`, data.error || "REFRESH");
  }
  return data;
}

/** Microsoft access token -> Xbox Live user token. */
export async function authenticateXboxLive(microsoftAccessToken) {
  if (!microsoftAccessToken) {
    throw new AuthError("Microsoft did not return an access token. Sign in again.", "NO_MS_TOKEN");
  }
  const res = await authFetch(XBL_AUTH_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      Properties: { AuthMethod: "RPS", SiteName: "user.auth.xboxlive.com", RpsTicket: `d=${microsoftAccessToken}` },
      RelyingParty: "http://auth.xboxlive.com",
      TokenType: "JWT",
    }),
  });
  // Xbox Live answers XML on failures, so parse defensively and report the HTTP status.
  const text = await res.text();
  let data = {};
  try {
    data = JSON.parse(text);
  } catch { /* not JSON: fall through to the text branch below */ }
  if (!res.ok || !data.Token) {
    const detail = (data.Message || data.error
      || text.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim()).slice(0, 240);
    throw new AuthError(`Xbox Live sign-in failed (HTTP ${res.status})${detail ? `: ${detail}` : "."}`, "XBL");
  }
  return { token: data.Token, userHash: data.DisplayClaims?.xui?.[0]?.uhs };
}

/** Xbox Live token -> XSTS token with the user's XUID. */
export async function authorizeXsts(xboxToken) {
  const res = await fetch(XSTS_AUTH_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      Properties: { SandboxId: "RETAIL", UserTokens: [xboxToken] },
      RelyingParty: "rp://api.minecraftservices.com/",
      TokenType: "JWT",
    }),
  });
  const data = await res.json();
  if (!res.ok) {
    const message = XSTS_ERRORS[data.XErr] || `Xbox Live authorization failed (XErr ${data.XErr || res.status}).`;
    throw new AuthError(message, String(data.XErr || res.status));
  }
  const claims = data.DisplayClaims?.xui?.[0] || {};
  return { token: data.Token, userHash: claims.uhs, xuid: claims.xid };
}

/** XSTS token -> Minecraft services access token. */
export async function authenticateMinecraft({ xstsToken, userHash }) {
  const res = await fetch(MC_AUTH_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ identityToken: `XBL3.0 x=${userHash};${xstsToken}` }),
  });
  const data = await res.json();
  if (!res.ok || !data.access_token) {
    throw new AuthError(data.errorMessage || "Minecraft authentication failed.", "MC_AUTH");
  }
  return {
    accessToken: data.access_token,
    expiresIn: data.expires_in || 86400,
    expiresAt: Date.now() + (data.expires_in || 86400) * 1000,
  };
}

/** Fetch the player's Minecraft profile (name + uuid), verifying ownership. */
export async function fetchMinecraftProfile(accessToken) {
  const res = await fetch(MC_PROFILE_URL, { headers: { Authorization: `Bearer ${accessToken}` } });
  if (res.status === 404) {
    throw new AuthError("This Microsoft account does not own Minecraft: Java Edition.", "NO_OWNERSHIP");
  }
  if (!res.ok) throw new AuthError(`Could not load the Minecraft profile (HTTP ${res.status}).`, "PROFILE");
  const data = await res.json();
  return { id: data.id, name: data.name, skins: data.skins || [], capes: data.capes || [] };
}

export async function checkEntitlements(accessToken) {
  try {
    const res = await fetch(MC_ENTITLEMENTS_URL, { headers: { Authorization: `Bearer ${accessToken}` } });
    if (!res.ok) return { owns: false, items: [] };
    const data = await res.json();
    const items = (data.items || []).map((i) => i.name);
    return { owns: items.some((name) => /minecraft|game/i.test(name)) || items.length > 0, items };
  } catch {
    return { owns: false, items: [] };
  }
}

/** Full chain: Microsoft account -> launchable Minecraft session. */
export async function completeMinecraftLogin(tokenResponse, { onProgress = () => {} } = {}) {
  onProgress({ phase: "xbox", message: "Signing in to Xbox Live" });
  const xbl = await authenticateXboxLive(tokenResponse.access_token);
  onProgress({ phase: "xsts", message: "Authorizing with Xbox Live" });
  const xsts = await authorizeXsts(xbl.token);
  onProgress({ phase: "minecraft", message: "Signing in to Minecraft" });
  const minecraft = await authenticateMinecraft({ xstsToken: xsts.token, userHash: xsts.userHash });
  onProgress({ phase: "profile", message: "Loading your Minecraft profile" });
  const profile = await fetchMinecraftProfile(minecraft.accessToken);
  return {
    msAccessToken: tokenResponse.access_token,
    msRefreshToken: tokenResponse.refresh_token,
    minecraft,
    xsts,
    profile,
  };
}

export function toAccount(login, { previous } = {}) {
  return {
    id: previous?.id || crypto.randomUUID(),
    type: "msa",
    name: login.profile.name,
    uuid: login.profile.id,
    xuid: login.xsts.xuid,
    accessToken: login.minecraft.accessToken,
    expiresAt: login.minecraft.expiresAt,
    refreshToken: login.msRefreshToken || previous?.refreshToken,
    msAccessToken: login.msAccessToken,
    skins: login.profile.skins,
    capes: login.profile.capes,
    addedAt: previous?.addedAt || Date.now(),
    lastUsed: Date.now(),
  };
}

/** Refresh an expired Minecraft token using the stored Microsoft refresh token. */
export async function refreshAccount(account, clientId) {
  if (!account.refreshToken) throw new AuthError("This account must be signed in again.", "NO_REFRESH_TOKEN");
  const tokens = await refreshMicrosoftToken({ clientId, refreshToken: account.refreshToken });
  const login = await completeMinecraftLogin(tokens);
  return toAccount(login, { previous: account });
}

/** Offline (single-player / LAN) accounts use the classic UUID v3 derivation. */
export function offlineUuid(name) {
  const hash = crypto.createHash("md5").update(`OfflinePlayer:${name}`, "utf8").digest();
  hash[6] = (hash[6] & 0x0f) | 0x30;
  hash[8] = (hash[8] & 0x3f) | 0x80;
  const hex = hash.toString("hex");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export function offlineAccount(name) {
  const clean = String(name || "").trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(clean)) {
    throw new AuthError("Offline usernames must be 3-16 characters: letters, numbers or underscore.", "BAD_USERNAME");
  }
  return {
    id: crypto.randomUUID(),
    type: "offline",
    name: clean,
    uuid: offlineUuid(clean),
    xuid: "0",
    accessToken: "revolution-offline",
    expiresAt: Number.MAX_SAFE_INTEGER,
    addedAt: Date.now(),
    lastUsed: Date.now(),
  };
}

/** True when the stored Minecraft token is missing or within 5 minutes of expiry. */
export function accountNeedsRefresh(account) {
  return account?.type === "msa" && (!account.expiresAt || account.expiresAt - Date.now() < 5 * 60 * 1000);
}

export { fetchJson };
