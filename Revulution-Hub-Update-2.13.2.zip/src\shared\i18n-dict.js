'use strict';
/* Automatisch aus i18n-dict-*.tsv erzeugt: Deutsch → [Englisch, Spanisch] */
window.__REV_DICT = {
"1. Design wählen": [
"1. Choose a design",
"1. Elige un diseño"
],
"1:1 Verhältnis": [
"1:1 ratio",
"Proporción 1:1"
],
"1:1 im Spiel": [
"1:1 in game",
"1:1 en el juego"
],
"3. F8 drücken": [
"3. Press F8",
"3. Pulsa F8"
],
"Abbrechen": [
"Cancel",
"Cancelar"
],
"Aktiv": [
"Active",
"Activo"
],
"Aktiv im Hintergrund": [
"Active in the background",
"Activo en segundo plano"
],
"Aktuelle Zeile läuft mit": [
"Current line follows along",
"La línea actual se sincroniza"
],
"Aktuelle Zeile läuft mit und füllt sich beim Singen": [
"Current line follows along and fills while singing",
"La línea actual avanza y se llena al cantar"
],
"Alle Clips löschen": [
"Delete all clips",
"Borrar todos los clips"
],
"Alle auswählen": [
"Select all",
"Seleccionar todo"
],
"Alle deine Revulution-Apps und Werkzeuge in einem Fenster. Crosshair, Screenshot-Hotkey und Orbit Island arbeiten im Hintergrund weiter.": [
"All your Revulution apps and tools in one window. Crosshair, screenshot hotkey and Orbit Island keep running in the background.",
"Todas tus apps y herramientas Revulution en una ventana. Crosshair, atajo de captura y Orbit Island siguen en segundo plano."
],
"Alle wählen": [
"Select all",
"Elegir todo"
],
"Alles löschen": [
"Delete everything",
"Borrar todo"
],
"Als abwesend gilt nach": [
"Counts as away after",
"Ausente después de"
],
"Am besten das Fortnite-Fenster wählen – Vollbild-Spiele werden automatisch über den passenden Monitor aufgenommen.": [
"Best pick the Fortnite window – fullscreen games are recorded via the matching monitor automatically.",
"Mejor elige la ventana de Fortnite – los juegos a pantalla completa se graban por el monitor correcto."
],
"Am besten ein quadratisches Bild mit transparentem Hintergrund. GIFs laufen im Overlay animiert weiter. Alles bleibt lokal.": [
"Ideally a square image with a transparent background. GIFs stay animated in the overlay. Everything stays local.",
"Mejor una imagen cuadrada con fondo transparente. Los GIF siguen animados. Todo queda en local."
],
"An Clip-Kanten und Abspielkopf einrasten": [
"Snap to clip edges and playhead",
"Ajustar a bordes de clips y al cabezal"
],
"Animationsstärke": [
"Animation strength",
"Intensidad de animación"
],
"Anpassen": [
"Adjust",
"Ajustar"
],
"Ans Ende anfügen": [
"Append to end",
"Añadir al final"
],
"Arbeitsspeicher": [
"Memory",
"Memoria"
],
"Auch für Orbit Island": [
"Also for Orbit Island",
"También para Orbit Island"
],
"Auch für Orbit Island verwenden": [
"Also use for Orbit Island",
"Usar también en Orbit Island"
],
"Auflösung": [
"Resolution",
"Resolución"
],
"Aufnahme": [
"Recording",
"Grabación"
],
"Aufnahme aus": [
"Recording off",
"Grabación apagada"
],
"Aufnahme beendet – verbinde neu": [
"Recording ended – reconnecting",
"Grabación terminada – reconectando"
],
"Aufnahme gespeichert – liegt unter „Aufnahmen“.": [
"Recording saved – find it under “Recordings”.",
"Grabación guardada – está en «Grabaciones»."
],
"Aufnahme gestartet – Kills und Siege werden automatisch gespeichert.": [
"Recording started – kills and wins are saved automatically.",
"Grabación iniciada – kills y victorias se guardan solas."
],
"Aufnahme läuft": [
"Recording",
"Grabando"
],
"Aufnahme läuft nicht – starte sie im Clips-Tab.": [
"Not recording – start it in the Clips tab.",
"No se está grabando – iníciala en la pestaña Clips."
],
"Aufnahme läuft über den Monitor – Vollbild-Spiele liefern als Fenster oft nur ein schwarzes Bild.": [
"Recording the monitor – fullscreen games often give only a black image as a window.",
"Se graba el monitor – los juegos a pantalla completa a menudo dan imagen negra como ventana."
],
"Aufnahme mit neuen Ton-Einstellungen neu gestartet.": [
"Recording restarted with new audio settings.",
"Grabación reiniciada con nuevos ajustes de sonido."
],
"Aufnahme starten": [
"Start recording",
"Iniciar grabación"
],
"Aufnahme stoppen": [
"Stop recording",
"Detener grabación"
],
"Aufnahme wird gespeichert …": [
"Saving recording …",
"Guardando grabación …"
],
"Aufnehmen wie mit Medal: Puffer, Kills, Siege und Tasten.": [
"Record like Medal: buffer, kills, wins and keys.",
"Graba como Medal: búfer, kills, victorias y teclas."
],
"Aufräumen": [
"Clean up",
"Limpiar"
],
"Aufzählung": [
"Bullet list",
"Viñetas"
],
"Aus": [
"Off",
"Apagado"
],
"Ausgewählten Clip am Abspielkopf teilen (S)": [
"Split selected clip at playhead (S)",
"Dividir el clip en el cabezal (S)"
],
"Ausgewählten Clip entfernen (Entf)": [
"Remove selected clip (Del)",
"Quitar el clip seleccionado (Supr)"
],
"Ausrichtung": [
"Alignment",
"Alineación"
],
"Auswählen": [
"Select",
"Seleccionar"
],
"Autostart-Ordner": [
"Startup folder",
"Carpeta de inicio"
],
"Autostart-Ordner (alle)": [
"Startup folder (all users)",
"Carpeta de inicio (todos)"
],
"Autostart-Programme werden gelesen …": [
"Reading startup programs …",
"Leyendo programas de inicio …"
],
"Balken mit Lauf- und Restzeit": [
"Bar with elapsed and remaining time",
"Barra con tiempo transcurrido y restante"
],
"Balken mit Laufzeit und Restzeit": [
"Bar with elapsed and remaining time",
"Barra con tiempo transcurrido y restante"
],
"Beenden": [
"Quit",
"Cerrar"
],
"Beenden bestätigen": [
"Confirm quit",
"Confirmar cierre"
],
"Beenden fehlgeschlagen (evtl. Administratorrechte nötig).": [
"Couldn’t end it (admin rights may be needed).",
"No se pudo cerrar (quizá requiere administrador)."
],
"Bei Rückkehr begrüßen": [
"Greet on return",
"Saludar al volver"
],
"Beim Darüberfahren anzeigen": [
"Show on hover",
"Mostrar al pasar el ratón"
],
"Beim Darüberfahren aufklappen": [
"Expand on hover",
"Abrir al pasar el ratón"
],
"Beim Darüberfahren – Breite": [
"On hover – width",
"Al pasar – ancho"
],
"Beim Darüberfahren – Höhe": [
"On hover – height",
"Al pasar – alto"
],
"Beim Schließen im Infobereich bleiben": [
"Stay in the tray when closed",
"Quedarse en la bandeja al cerrar"
],
"Belegter Arbeitsspeicher und Gesamtgröße": [
"Used memory and total size",
"Memoria usada y tamaño total"
],
"Benachrichtigung – Höhe": [
"Notification – height",
"Notificación – alto"
],
"Bereich oder Bildschirm per Hotkey aufnehmen, mit Pfeilen, Text, Markern und Verpixeln bearbeiten, kopieren oder speichern.": [
"Capture an area or the screen with a hotkey, annotate with arrows, text, markers and pixelation, copy or save.",
"Captura un área o la pantalla con un atajo, anota con flechas, texto, marcadores y pixelado, copia o guarda."
],
"Bild": [
"Image",
"Imagen"
],
"Bild / GIF": [
"Image / GIF",
"Imagen / GIF"
],
"Bild als Crosshair übernommen": [
"Image set as crosshair",
"Imagen usada como crosshair"
],
"Bild einfügen": [
"Insert image",
"Insertar imagen"
],
"Bild entfernt": [
"Image removed",
"Imagen quitada"
],
"Bild konnte nicht geöffnet werden.": [
"Couldn’t open the image.",
"No se pudo abrir la imagen."
],
"Bild oder GIF": [
"Image or GIF",
"Imagen o GIF"
],
"Bild-in-Bild": [
"Picture-in-picture",
"Imagen en imagen"
],
"Bilder": [
"Images",
"Imágenes"
],
"Bildrate deines Monitors samt Frame-Zeit": [
"Your monitor’s frame rate with frame time",
"Tasa de fotogramas de tu monitor con tiempo de frame"
],
"Bildrate im Leerlauf": [
"Frame rate when idle",
"Fotogramas en reposo"
],
"Bildschirm": [
"Screen",
"Pantalla"
],
"Bildschirmzeit": [
"Screen time",
"Tiempo de pantalla"
],
"Bildschirmzeit ist gerade nicht verfügbar.": [
"Screen time isn’t available right now.",
"El tiempo de pantalla no está disponible ahora."
],
"Bitte zuerst ein Fenster als Quelle wählen.": [
"Please choose a window as source first.",
"Elige primero una ventana como fuente."
],
"Blendet die Karte ein, sobald Musik läuft": [
"Shows the card as soon as music plays",
"Muestra la tarjeta en cuanto suena música"
],
"Blendet die Karte ein, sobald auf dem PC Musik läuft": [
"Shows the card as soon as music plays on the PC",
"Muestra la tarjeta cuando suena música en el PC"
],
"CPU, Grafikkarte, RAM, Laufwerke und Netzwerk live. Prozesse beenden und Autostart-Programme ein- und ausschalten.": [
"CPU, GPU, RAM, drives and network live. End processes and toggle startup programs.",
"CPU, GPU, RAM, discos y red en vivo. Cierra procesos y activa o desactiva programas de inicio."
],
"Callouts, Builds, Ideen – alles an einer Stelle": [
"Callouts, builds, ideas – all in one place",
"Callouts, builds, ideas – todo en un sitio"
],
"Clip gelöscht.": [
"Clip deleted.",
"Clip borrado."
],
"Clip konnte nicht gespeichert werden.": [
"Couldn’t save the clip.",
"No se pudo guardar el clip."
],
"Clip nicht lesbar": [
"Clip not readable",
"Clip ilegible"
],
"Clip übernehmen": [
"Use clip",
"Usar clip"
],
"Clip-Ordner konnte nicht geöffnet werden.": [
"Couldn’t open the clip folder.",
"No se pudo abrir la carpeta de clips."
],
"Clip-Ränder ziehen zum Kürzen, Clip ziehen zum Verschieben – auch auf eine andere Spur.": [
"Drag clip edges to trim, drag a clip to move it – also to another track.",
"Arrastra los bordes para recortar y el clip para moverlo – también a otra pista."
],
"Clips aus dem Gaming Hub": [
"Clips from the Gaming Hub",
"Clips del Gaming Hub"
],
"Config-Ordner:": [
"Config folder:",
"Carpeta de configuración:"
],
"Cover dreht sich wie eine Schallplatte": [
"Cover spins like a record",
"La portada gira como un disco"
],
"Cover dreht statt als Kachel wie eine Schallplatte": [
"Cover spins like a record instead of a tile",
"La portada gira como un disco en vez de una tarjeta"
],
"Cover, Restzeit und Songtext als kleines Overlay.": [
"Cover, remaining time and lyrics as a small overlay.",
"Portada, tiempo restante y letra como pequeño overlay."
],
"Cover, Restzeit und Songtext oben am Bildschirm": [
"Cover, remaining time and lyrics at the top of the screen",
"Portada, tiempo restante y letra arriba en la pantalla"
],
"Crosshair an": [
"Crosshair on",
"Crosshair activado"
],
"Crosshair an / aus": [
"Crosshair on / off",
"Crosshair sí / no"
],
"Crosshair aus": [
"Crosshair off",
"Crosshair desactivado"
],
"Crosshair bleibt an, auch wenn Fortnite nicht läuft (F8 schaltet genau das)": [
"Crosshair stays on even without Fortnite (F8 toggles exactly this)",
"El crosshair sigue activo sin Fortnite (F8 lo cambia)"
],
"Crosshair für Fortnite, direkt auf dem richtigen Monitor.": [
"Crosshair for Fortnite, right on the correct monitor.",
"Crosshair para Fortnite, directamente en el monitor correcto."
],
"Crosshair ist an – bleibt an": [
"Crosshair is on – stays on",
"El crosshair está activo – sigue activo"
],
"Crosshair ist aus": [
"Crosshair is off",
"El crosshair está desactivado"
],
"Crosshair ist nach dem Anmelden sofort bereit": [
"Crosshair is ready right after sign-in",
"El crosshair está listo tras iniciar sesión"
],
"Crosshair wird 8 Sekunden im Overlay gezeigt": [
"Crosshair is shown in the overlay for 8 seconds",
"El crosshair se muestra 8 segundos"
],
"Crosshair, Overlays, Screenshot-Hotkey und Orbit Island bleiben aktiv. Beenden über das Symbol im Infobereich.": [
"Crosshair, overlays, screenshot hotkey and Orbit Island stay active. Quit via the tray icon.",
"Crosshair, overlays, atajo de captura y Orbit Island siguen activos. Cierra desde el icono de la bandeja."
],
"Crosshair-Overlay für Fortnite, Clips, Musik- und Leistungs-Overlay, Audio-Mixer, Statistiken und Bildschirmzeit.": [
"Crosshair overlay for Fortnite, clips, music and performance overlay, audio mixer, stats and screen time.",
"Overlay de crosshair para Fortnite, clips, overlay de música y rendimiento, mezclador, estadísticas y tiempo de pantalla."
],
"Das Crosshair sitzt mittig auf dem Spielmonitor, ohne Popups und ohne Eingriff ins Spiel.": [
"The crosshair sits centered on the game monitor, no popups and no game tampering.",
"El crosshair queda centrado en el monitor del juego, sin popups ni tocar el juego."
],
"Das Einlernen braucht die Kamera-Vorschau der Island. Alles bleibt auf deinem PC.": [
"Enrollment needs the island’s camera preview. Everything stays on your PC.",
"El registro necesita la vista de cámara de la isla. Todo queda en tu PC."
],
"Das Fenster verschwindet, Overlays, Hotkeys und Island laufen weiter. Beenden über das Tray-Symbol.": [
"The window hides, overlays, hotkeys and island keep running. Quit via the tray icon.",
"La ventana se oculta, overlays, atajos e isla siguen. Cierra desde la bandeja."
],
"Datei": [
"File",
"Archivo"
],
"Datei auswählen …": [
"Choose file …",
"Elegir archivo …"
],
"Datei fehlt": [
"File missing",
"Falta el archivo"
],
"Datei hier ablegen oder klicken": [
"Drop a file here or click",
"Suelta un archivo aquí o haz clic"
],
"Datei ist nicht lesbar": [
"File isn’t readable",
"El archivo no se puede leer"
],
"Datei nicht gefunden.": [
"File not found.",
"Archivo no encontrado."
],
"Datei wählen": [
"Choose file",
"Elegir archivo"
],
"Dateien": [
"Files",
"Archivos"
],
"Dateien geprüft": [
"Files checked",
"Archivos revisados"
],
"Dateien im Archiv": [
"Files in archive",
"Archivos en el archivo"
],
"Dateimanager mit Dual Pane, Tabs, Vorschau, Suche, ZIP, Aufräum-Assistent, Duplikat-Suche und „Pfad kopieren“.": [
"File manager with dual pane, tabs, preview, search, ZIP, cleanup assistant, duplicate finder and “copy path”.",
"Explorador con doble panel, pestañas, vista previa, búsqueda, ZIP, limpieza, duplicados y «copiar ruta»."
],
"Datenträger-Aktivität": [
"Disk activity",
"Actividad de disco"
],
"Datum einfügen": [
"Insert date",
"Insertar fecha"
],
"Davon im Spiel": [
"Of which in game",
"De ello en juego"
],
"Dein Rang · gilt für alle Modi": [
"Your rank · applies to all modes",
"Tu rango · para todos los modos"
],
"Dein eigenes Fadenkreuz, Pixel für Pixel.": [
"Your own crosshair, pixel by pixel.",
"Tu propio crosshair, píxel a píxel."
],
"Deine Dynamic Island – hier steuerst du sie komplett: Design, Größe, Musik, Kalender, Benachrichtigungen, Widgets und mehr.": [
"Your Dynamic Island – control everything here: design, size, music, calendar, notifications, widgets and more.",
"Tu Dynamic Island – contrólala aquí: diseño, tamaño, música, calendario, notificaciones, widgets y más."
],
"Der Abspielkopf muss innerhalb des Clips stehen.": [
"The playhead must be inside the clip.",
"El cabezal debe estar dentro del clip."
],
"Der Bildschirm konnte nicht aufgenommen werden.": [
"Couldn’t capture the screen.",
"No se pudo capturar la pantalla."
],
"Der Hub startet unsichtbar im Infobereich – Crosshair, Screenshot-Hotkey und Orbit Island sind sofort da.": [
"The hub starts hidden in the tray – crosshair, screenshot hotkey and Orbit Island are ready right away.",
"El hub arranca oculto en la bandeja – crosshair, atajo de captura y Orbit Island listos al instante."
],
"Der Musik-Player ist gerade nicht verfügbar.": [
"The music player isn’t available right now.",
"El reproductor no está disponible ahora."
],
"Die App läuft im Infobereich weiter, bis du sie dort beendest": [
"The app keeps running in the tray until you quit it there",
"La app sigue en la bandeja hasta que la cierres allí"
],
"Die Aufnahme war zu kurz.": [
"The recording was too short.",
"La grabación fue demasiado corta."
],
"Die Desktop-Bridge ist nicht verfügbar.": [
"The desktop bridge isn’t available.",
"El puente de escritorio no está disponible."
],
"Die Dynamic Island am oberen Bildschirmrand – mit allen Einstellungen direkt hier im Hub.": [
"The Dynamic Island at the top of the screen – with all settings right here in the hub.",
"La Dynamic Island arriba en la pantalla – con todos los ajustes aquí en el hub."
],
"Die Elemente werden in den Windows-Papierkorb verschoben und können wiederhergestellt werden.": [
"The items go to the Windows Recycle Bin and can be restored.",
"Los elementos van a la papelera de Windows y se pueden restaurar."
],
"Die Island zeigt denselben Live-Hintergrund wie der Hub.": [
"The island shows the same live background as the hub.",
"La isla muestra el mismo fondo animado que el hub."
],
"Die Vorschau läuft stumm mit. Stopp mit der Leertaste.": [
"The preview plays muted. Stop with the space bar.",
"La vista previa va sin sonido. Para con la barra espaciadora."
],
"Die Zeitleiste ist leer.": [
"The timeline is empty.",
"La línea de tiempo está vacía."
],
"Diese Elemente werden ohne Umweg über den Papierkorb gelöscht. Das kann nicht rückgängig gemacht werden.": [
"These items are deleted without the Recycle Bin. This can’t be undone.",
"Estos elementos se borran sin pasar por la papelera. No se puede deshacer."
],
"Dieser Eintrag gilt für alle Benutzer – dafür braucht es Administratorrechte.": [
"This entry applies to all users – admin rights are needed.",
"Esta entrada es para todos los usuarios – requiere administrador."
],
"Dieser Prozess kann nicht beendet werden.": [
"This process can’t be ended.",
"Este proceso no se puede cerrar."
],
"Dieses Bild kann nicht gelesen werden.": [
"This image can’t be read.",
"Esta imagen no se puede leer."
],
"Dieses Tastenkürzel ist schon belegt.": [
"This shortcut is already taken.",
"Este atajo ya está en uso."
],
"Dokument": [
"Document",
"Documento"
],
"Doppelte unterdrücken": [
"Suppress duplicates",
"Suprimir duplicados"
],
"Drücke": [
"Press",
"Pulsa"
],
"Drückst du die Taste im Spiel, wechselt das Overlay sofort das Crosshair mit.": [
"Press the key in game and the overlay switches the crosshair instantly.",
"Si pulsas la tecla en el juego, el overlay cambia el crosshair al instante."
],
"Dynamic Island für Windows": [
"Dynamic Island for Windows",
"Dynamic Island para Windows"
],
"Ecken geöffnet": [
"Corners when open",
"Esquinas abierta"
],
"Eigene Bilder und GIFs findest du unter": [
"You’ll find your own images and GIFs under",
"Tus imágenes y GIF están en"
],
"Eigene Datei": [
"Own file",
"Archivo propio"
],
"Eigenes Bild oder GIF": [
"Own image or GIF",
"Imagen o GIF propio"
],
"Eigenes PNG, WebP oder animiertes GIF als Crosshair.": [
"Your own PNG, WebP or animated GIF as crosshair.",
"Tu PNG, WebP o GIF animado como crosshair."
],
"Eigenes Symbol im Infobereich": [
"Own icon in the tray",
"Icono propio en la bandeja"
],
"Eigenständig mit Windows starten": [
"Start on its own with Windows",
"Iniciar con Windows por sí solo"
],
"Ein dezenter Klick bei Knöpfen und Schaltern – in allen Bereichen gleich.": [
"A subtle click on buttons and switches – the same everywhere.",
"Un clic suave en botones e interruptores – igual en todas partes."
],
"Einen Clip unter dem Abspielkopf auswählen.": [
"Select a clip under the playhead.",
"Selecciona un clip bajo el cabezal."
],
"Einfügen": [
"Paste",
"Pegar"
],
"Eingebaute Designs bleiben immer erhalten. Eigene Designs und Bilder kannst du löschen.": [
"Built-in designs always stay. You can delete your own designs and images.",
"Los diseños incluidos siempre se quedan. Puedes borrar los tuyos."
],
"Eingeklappt – Höhe": [
"Collapsed – height",
"Cerrada – alto"
],
"Einstellungen": [
"Settings",
"Ajustes"
],
"Einstellungen und Daten bleiben beim Aktualisieren erhalten.": [
"Settings and data are kept when updating.",
"Ajustes y datos se conservan al actualizar."
],
"Einstellungen werden geladen …": [
"Loading settings …",
"Cargando ajustes …"
],
"Einstellungen zurückgesetzt": [
"Settings reset",
"Ajustes restablecidos"
],
"Einstellungsfenster in den Infobereich schließen": [
"Close settings window to the tray",
"Cerrar ajustes a la bandeja"
],
"Einzelne und mehrtägige Termine mit Erinnerung. Sie erscheinen in der Island und melden sich dort rechtzeitig.": [
"Single and multi-day events with reminders. They appear in the island and notify you in time.",
"Eventos de uno o varios días con recordatorio. Aparecen en la isla y avisan a tiempo."
],
"Einzug vergrößern": [
"Increase indent",
"Aumentar sangría"
],
"Endgültig löschen": [
"Delete permanently",
"Borrar definitivamente"
],
"Entfernen": [
"Remove",
"Quitar"
],
"Erkennt den Truhen-Hinweis neben dem Fadenkreuz und deine Interaktionstaste": [
"Detects the chest prompt next to the crosshair and your interact key",
"Detecta el aviso del cofre junto al crosshair y tu tecla de interacción"
],
"Erkennung läuft": [
"Detection running",
"Detección activa"
],
"Erkennung läuft …": [
"Detecting …",
"Detectando …"
],
"Erstellt eine Kopie mit fest eingebrannten Tasten und Facecam": [
"Creates a copy with burned-in keys and facecam",
"Crea una copia con teclas y facecam incrustadas"
],
"Export abgebrochen": [
"Export canceled",
"Exportación cancelada"
],
"Export fertig": [
"Export done",
"Exportación lista"
],
"Export wird vorbereitet …": [
"Preparing export …",
"Preparando exportación …"
],
"Exportieren": [
"Export",
"Exportar"
],
"FPS, Ping, CPU, GPU und RAM als Overlay – jeden Wert einzeln.": [
"FPS, ping, CPU, GPU and RAM as an overlay – each value separately.",
"FPS, ping, CPU, GPU y RAM como overlay – cada valor por separado."
],
"FPS, Ping, CPU, GPU und RAM – jeder Wert lässt sich einzeln ausschalten": [
"FPS, ping, CPU, GPU and RAM – each value can be turned off",
"FPS, ping, CPU, GPU y RAM – cada valor se puede desactivar"
],
"Facecam aus": [
"Facecam off",
"Facecam apagada"
],
"Farbe": [
"Color",
"Color"
],
"Favorit (wird nie automatisch gelöscht)": [
"Favorite (never deleted automatically)",
"Favorito (nunca se borra solo)"
],
"Fehler": [
"Error",
"Error"
],
"Fenster schließen lässt Crosshair an": [
"Closing the window keeps the crosshair on",
"Cerrar la ventana deja el crosshair activo"
],
"Fertig": [
"Done",
"Listo"
],
"Fertige Designs – ein Klick, und es ist dein Crosshair.": [
"Ready-made designs – one click and it’s your crosshair.",
"Diseños listos – un clic y es tu crosshair."
],
"Fokus an": [
"Focus on",
"Enfoque activado"
],
"Fokus-Modus aktiv – Hinweise und Windows-Benachrichtigungen sind stumm": [
"Focus mode on – hints and Windows notifications are muted",
"Modo enfoque activo – avisos y notificaciones silenciados"
],
"Fokus-Modus an – keine Hinweise, Windows-Benachrichtigungen stumm": [
"Focus mode on – no hints, Windows notifications muted",
"Modo enfoque – sin avisos, notificaciones silenciadas"
],
"Fokus-Modus aus – Hinweise wieder aktiv": [
"Focus mode off – hints active again",
"Modo enfoque apagado – avisos activos"
],
"Fokus-Modus: Hinweise und Benachrichtigungen stumm schalten": [
"Focus mode: mute hints and notifications",
"Modo enfoque: silenciar avisos y notificaciones"
],
"Formatierung löschen": [
"Clear formatting",
"Borrar formato"
],
"Fortnite: nicht erkannt": [
"Fortnite: not detected",
"Fortnite: no detectado"
],
"Frei verschieben – Karte im Feld ziehen": [
"Move freely – drag the card in the field",
"Mover libremente – arrastra la tarjeta"
],
"Funktionieren auch, während Fortnite im Vordergrund ist": [
"Also work while Fortnite is in the foreground",
"Funcionan aunque Fortnite esté en primer plano"
],
"Für Kill-Clips braucht die Erkennung deinen Fortnite-Namen – trag ihn unten bei „Automatik“ ein.": [
"For kill clips the detection needs your Fortnite name – enter it below under “Automatic”.",
"Para clips de kills se necesita tu nombre de Fortnite – escríbelo abajo en «Automático»."
],
"Ganztägige Termine": [
"All-day events",
"Eventos de todo el día"
],
"Gemessen, solange Revulution Gaming Hub läuft": [
"Measured while Revulution Gaming Hub runs",
"Medido mientras Revulution Gaming Hub funciona"
],
"Gerade läuft keine Musik.": [
"No music playing right now.",
"No suena música ahora."
],
"Gerade läuft nichts": [
"Nothing playing right now",
"No suena nada"
],
"Gerade spielt keine App Ton ab.": [
"No app is playing sound right now.",
"Ninguna app reproduce sonido ahora."
],
"Geräte-Anzeige (Kopfhörer, USB …)": [
"Device indicator (headphones, USB …)",
"Indicador de dispositivos (auriculares, USB …)"
],
"Gesamt": [
"Total",
"Total"
],
"Gesamt um 1 erhöhen": [
"Increase total by 1",
"Sumar 1 al total"
],
"Gesamtgröße": [
"Total size",
"Tamaño total"
],
"Gesamtzähler zurücksetzen": [
"Reset total counter",
"Reiniciar contador total"
],
"Gestern": [
"Yesterday",
"Ayer"
],
"Geändert": [
"Modified",
"Modificado"
],
"Geöffnet – Breite": [
"Open – width",
"Abierta – ancho"
],
"Geöffnet – Höhe": [
"Open – height",
"Abierta – alto"
],
"Gib einen Suchbegriff ein.": [
"Enter a search term.",
"Escribe un término de búsqueda."
],
"Gilt direkt für das aktive Design": [
"Applies directly to the active design",
"Se aplica al diseño activo"
],
"Gilt für alle Klicksounds im Hub.": [
"Applies to all click sounds in the hub.",
"Se aplica a todos los clics del hub."
],
"Grafikkarte": [
"Graphics card",
"Tarjeta gráfica"
],
"Grafikkarte-Auslastung über die 3D-Engine": [
"GPU usage via the 3D engine",
"Uso de GPU por el motor 3D"
],
"Größe": [
"Size",
"Tamaño"
],
"Größe & Form": [
"Size & shape",
"Tamaño y forma"
],
"Größe (gesamt)": [
"Size (total)",
"Tamaño (total)"
],
"Größe wählen": [
"Choose size",
"Elegir tamaño"
],
"Größe, Länge, Dicke, Lücke, Farbe und Kontur – die Vorschau zeigt sofort das Ergebnis.": [
"Size, length, thickness, gap, color and outline – the preview shows the result right away.",
"Tamaño, largo, grosor, hueco, color y contorno – la vista previa lo muestra al instante."
],
"Größe:": [
"Size:",
"Tamaño:"
],
"Größen": [
"Sizes",
"Tamaños"
],
"Größer": [
"Larger",
"Más grande"
],
"Größte zuerst": [
"Largest first",
"Más grandes primero"
],
"Gut zu wissen": [
"Good to know",
"Bueno saber"
],
"Heute": [
"Today",
"Hoy"
],
"Hier zum Bearbeiten öffnen": [
"Open here to edit",
"Abrir aquí para editar"
],
"Hintergrund": [
"Background",
"Fondo"
],
"Hintergrund 2 (Verlauf)": [
"Background 2 (gradient)",
"Fondo 2 (degradado)"
],
"Hintergrund für die ganze App": [
"Background for the whole app",
"Fondo para toda la app"
],
"Hintergrund gesetzt": [
"Background set",
"Fondo aplicado"
],
"Hotkey für Aufnahme": [
"Recording hotkey",
"Atajo de grabación"
],
"Höhe": [
"Height",
"Alto"
],
"Im Gaming Hub gespeicherte Clips (Kills, Siege, Sofort-Clip) erscheinen hier automatisch.": [
"Clips saved in the Gaming Hub (kills, wins, instant clip) appear here automatically.",
"Los clips guardados en el Gaming Hub (kills, victorias, clip instantáneo) aparecen aquí."
],
"Im Ordner zeigen": [
"Show in folder",
"Mostrar en la carpeta"
],
"Im Terminal öffnen": [
"Open in terminal",
"Abrir en terminal"
],
"Importieren": [
"Import",
"Importar"
],
"In der App öffnen": [
"Open in the app",
"Abrir en la app"
],
"In der Island anzeigen": [
"Show in the island",
"Mostrar en la isla"
],
"In der Zwischenablage · Klick öffnet die Datei": [
"In clipboard · click opens the file",
"En el portapapeles · clic abre el archivo"
],
"In die Zeitleiste": [
"To timeline",
"A la línea de tiempo"
],
"In die Zwischenablage kopieren": [
"Copy to clipboard",
"Copiar al portapapeles"
],
"In die Zwischenablage kopiert.": [
"Copied to clipboard.",
"Copiado al portapapeles."
],
"Ins Feld klicken und Tastenkombination drücken, z. B.": [
"Click the field and press a key combination, e.g.",
"Haz clic en el campo y pulsa una combinación, p. ej."
],
"Installationsdateien, die älter als 90 Tage sind": [
"Installer files older than 90 days",
"Instaladores de más de 90 días"
],
"Island ein/aus": [
"Island on/off",
"Isla sí/no"
],
"Jede geöffnete Truhe zählt sofort mit": [
"Every opened chest counts instantly",
"Cada cofre abierto cuenta al instante"
],
"Kamera der Gesichtserkennung nicht anzeigen": [
"Don’t show the face recognition camera",
"No mostrar la cámara del reconocimiento facial"
],
"Karte erscheint über dem Spiel – mit deinem Live-Hintergrund": [
"Card appears over the game – with your live background",
"La tarjeta aparece sobre el juego – con tu fondo animado"
],
"Kein Bildschirm gefunden.": [
"No screen found.",
"No se encontró pantalla."
],
"Kein Fenster gefunden – starte Fortnite": [
"No window found – start Fortnite",
"No hay ventana – inicia Fortnite"
],
"Kein Laufwerk erkannt": [
"No drive detected",
"No se detectó disco"
],
"Kein Zugriff auf das Mikrofon. In Windows unter Datenschutz › Mikrofon erlauben.": [
"No microphone access. Allow it in Windows under Privacy › Microphone.",
"Sin acceso al micrófono. Permítelo en Windows en Privacidad › Micrófono."
],
"Kein „Durchsuchen“ im Blick": [
"No “Search” prompt in view",
"Ningún «Buscar» a la vista"
],
"Keine Aufnahmequellen gefunden. Prüfe die Windows-Bildschirmaufnahme-Einstellungen.": [
"No capture sources found. Check Windows screen capture settings.",
"No hay fuentes de captura. Revisa los ajustes de captura de Windows."
],
"Keine Autostart-Programme gefunden.": [
"No startup programs found.",
"No hay programas de inicio."
],
"Keine Clips passen zu Suche oder Datum.": [
"No clips match the search or date.",
"Ningún clip coincide con la búsqueda o fecha."
],
"Keine Dateien": [
"No files",
"Sin archivos"
],
"Keine Einträge in dieser Kategorie.": [
"No entries in this category.",
"No hay entradas en esta categoría."
],
"Keine Hintergründe gefunden.": [
"No backgrounds found.",
"No hay fondos."
],
"Keine Kills in diesem Match – das Replay ist trotzdem im Archiv.": [
"No kills this match – the replay is still in the archive.",
"Sin kills en esta partida – la repetición sigue en el archivo."
],
"Keine Laufwerke gefunden.": [
"No drives found.",
"No hay discos."
],
"Keine Matches in diesem Zeitraum. Mit „Replays scannen“ holst du sie hierher.": [
"No matches in this period. “Scan replays” brings them here.",
"No hay partidas en este periodo. «Escanear repeticiones» las trae aquí."
],
"Kill-Feed wird gelesen · Knock gelb, Kill rot": [
"Reading kill feed · knock yellow, kill red",
"Leyendo kill feed · derribo amarillo, kill rojo"
],
"Klein in der eingeklappten Island": [
"Small in the collapsed island",
"Pequeño en la isla cerrada"
],
"Kleine Karte mit Truhe und Gesamtzahl – blendet sich mit Fortnite ein": [
"Small card with chest and total – appears with Fortnite",
"Tarjeta pequeña con cofre y total – aparece con Fortnite"
],
"Klicken und neue Tasten drücken": [
"Click and press new keys",
"Haz clic y pulsa nuevas teclas"
],
"Knistern-Lautstärke": [
"Crackle volume",
"Volumen del crujido"
],
"Knistern-Lautstärke:": [
"Crackle volume:",
"Volumen del crujido:"
],
"Kopieren": [
"Copy",
"Copiar"
],
"Kopiert": [
"Copied",
"Copiado"
],
"Kurze Notizen, sofort festgehalten – lokal auf deinem PC.": [
"Quick notes, saved instantly – locally on your PC.",
"Notas rápidas, guardadas al instante – en tu PC."
],
"Kurzer Glitzer-Ton bei jeder Truhe": [
"Short sparkle sound for every chest",
"Breve sonido brillante en cada cofre"
],
"Kurzer Ton beim Bedienen der App": [
"Short sound when using the app",
"Sonido corto al usar la app"
],
"Körnung": [
"Grain",
"Grano"
],
"Kürzel entfernt": [
"Shortcut removed",
"Atajo quitado"
],
"Kürzel gespeichert": [
"Shortcut saved",
"Atajo guardado"
],
"Latenz zum Internet (1.1.1.1), im Spiel ist sie meist etwas niedriger": [
"Latency to the internet (1.1.1.1), usually a bit lower in game",
"Latencia a internet (1.1.1.1), en el juego suele ser algo menor"
],
"Laufwerke": [
"Drives",
"Discos"
],
"Lautstärke": [
"Volume",
"Volumen"
],
"Lautstärke des Knisterns": [
"Crackle volume",
"Volumen del crujido"
],
"Lautstärke-Anzeige": [
"Volume display",
"Indicador de volumen"
],
"Leere Ordner": [
"Empty folders",
"Carpetas vacías"
],
"Leises Vinyl-Knistern, solange Musik läuft": [
"Quiet vinyl crackle while music plays",
"Leve crujido de vinilo mientras suena música"
],
"Leistung": [
"Performance",
"Rendimiento"
],
"Leistungs-Overlay nicht erreichbar": [
"Performance overlay not reachable",
"Overlay de rendimiento no disponible"
],
"Lernen gegen die KI": [
"Learn against the AI",
"Aprende contra la IA"
],
"Leuchtstärke": [
"Glow strength",
"Intensidad del brillo"
],
"Link einfügen (Strg+K)": [
"Insert link (Ctrl+K)",
"Insertar enlace (Ctrl+K)"
],
"Links": [
"Left",
"Izquierda"
],
"Linksbündig": [
"Align left",
"Alinear a la izquierda"
],
"Linksklick malt, Rechtsklick radiert. Die Mitte und die Achsen sind leicht grau markiert. „Spiegeln“ malt auf Wunsch die Gegenseite mit.": [
"Left-click paints, right-click erases. The center and axes are marked light grey. “Mirror” paints the opposite side too.",
"Clic izquierdo pinta, derecho borra. El centro y los ejes están en gris claro. «Espejo» pinta también el lado opuesto."
],
"Live-Erkennung aus": [
"Live detection off",
"Detección en vivo apagada"
],
"Live-Hintergrund": [
"Live background",
"Fondo animado"
],
"Live-Hintergrund (Effekt)": [
"Live background (effect)",
"Fondo animado (efecto)"
],
"Länge": [
"Length",
"Largo"
],
"Länge (Hotkey/Sieg)": [
"Length (hotkey/win)",
"Duración (atajo/victoria)"
],
"Länge, Dicke, Lücke, Farbe, Kontur und Drehung.": [
"Length, thickness, gap, color, outline and rotation.",
"Largo, grosor, hueco, color, contorno y rotación."
],
"Läuft": [
"Running",
"En marcha"
],
"Läuft durchgehend hinter allen Bereichen – überall derselbe.": [
"Runs behind every section – the same everywhere.",
"Corre detrás de todas las secciones – igual en todas."
],
"Löschen": [
"Delete",
"Borrar"
],
"Lücke": [
"Gap",
"Hueco"
],
"MP3 (nur Ton)": [
"MP3 (audio only)",
"MP3 (solo audio)"
],
"MP4, MOV, MKV, WebM, MP3, WAV, Bilder … oder links einen Gaming-Clip wählen.": [
"MP4, MOV, MKV, WebM, MP3, WAV, images … or pick a gaming clip on the left.",
"MP4, MOV, MKV, WebM, MP3, WAV, imágenes … o elige un clip a la izquierda."
],
"Medal, OBS und Bildschirmaufnahmen filmen das Crosshair mit": [
"Medal, OBS and screen recordings capture the crosshair too",
"Medal, OBS y grabaciones de pantalla graban el crosshair"
],
"Medien hinzufügen": [
"Add media",
"Añadir medios"
],
"Mikro nicht erreichbar": [
"Mic not reachable",
"Micrófono no disponible"
],
"Mikrofon konnte nicht geöffnet werden – Clip wird ohne Mikro aufgenommen.": [
"Couldn’t open the mic – recording the clip without it.",
"No se pudo abrir el micrófono – el clip se graba sin él."
],
"Mit allen Formatierungen und Bildern": [
"With all formatting and images",
"Con todo el formato e imágenes"
],
"Mitte": [
"Center",
"Centro"
],
"Mixer nicht erreichbar": [
"Mixer not reachable",
"Mezclador no disponible"
],
"Monitor, Position, Hintergründe, Verhalten und Hilfe.": [
"Monitor, position, backgrounds, behavior and help.",
"Monitor, posición, fondos, comportamiento y ayuda."
],
"Musik": [
"Music",
"Música"
],
"Musik & Ton": [
"Music & sound",
"Música y sonido"
],
"Musik in der Island": [
"Music in the island",
"Música en la isla"
],
"Musik-Overlay": [
"Music overlay",
"Overlay de música"
],
"Musik-Overlay nicht erreichbar": [
"Music overlay not reachable",
"Overlay de música no disponible"
],
"Musik-Player an / aus": [
"Music player on / off",
"Reproductor sí / no"
],
"Musik-Player an/aus.": [
"Music player on/off.",
"Reproductor sí/no."
],
"Musik-Player – eigenes Overlay mit Cover, Songtext und Schallplatte": [
"Music player – own overlay with cover, lyrics and record",
"Reproductor – overlay propio con portada, letra y disco"
],
"Nach der Aufnahme": [
"After capture",
"Tras la captura"
],
"Nadel liegt auf der Platte und wandert mit dem Song nach innen": [
"Needle rests on the record and moves inward with the song",
"La aguja va sobre el disco y avanza con la canción"
],
"Nadel wandert mit dem Song nach innen": [
"Needle moves inward with the song",
"La aguja avanza con la canción"
],
"Name": [
"Name",
"Nombre"
],
"Netzwerk": [
"Network",
"Red"
],
"Neue Clips aus dem Gaming Hub": [
"New clips from the Gaming Hub",
"Nuevos clips del Gaming Hub"
],
"Neuer Ordner": [
"New folder",
"Nueva carpeta"
],
"Neues Projekt beginnen? Das aktuelle wird verworfen.": [
"Start a new project? The current one will be discarded.",
"¿Nuevo proyecto? El actual se descartará."
],
"Nicht stören": [
"Do not disturb",
"No molestar"
],
"Nicht verfügbar": [
"Not available",
"No disponible"
],
"Nicht zurückgesetzt": [
"Not reset",
"No restablecido"
],
"Nichts läuft": [
"Nothing playing",
"No suena nada"
],
"Nichts zu tun – es wurden keine alten oder temporären Dateien gefunden.": [
"Nothing to do – no old or temporary files found.",
"Nada que hacer – no hay archivos viejos ni temporales."
],
"Noch kein Kill-Clip. Eigene Eliminierungen werden automatisch gespeichert.": [
"No kill clip yet. Your eliminations are saved automatically.",
"Aún no hay clips de kills. Tus eliminaciones se guardan solas."
],
"Noch kein Sieg-Clip. Bei „Victory Royale“ wird automatisch gespeichert.": [
"No win clip yet. “Victory Royale” saves automatically.",
"Aún no hay clips de victoria. «Victory Royale» se guarda sola."
],
"Noch keine Aufnahme. Oben auf „● Aufnehmen“ klicken – läuft, bis du stoppst.": [
"No recording yet. Click “● Record” at the top – it runs until you stop.",
"Aún no hay grabaciones. Pulsa «● Grabar» arriba – sigue hasta que pares."
],
"Noch keine Clips.": [
"No clips yet.",
"Aún no hay clips."
],
"Noch keine Favoriten. Stern auf einem Clip antippen – Favoriten werden nie automatisch gelöscht.": [
"No favorites yet. Tap the star on a clip – favorites are never deleted automatically.",
"Aún no hay favoritos. Pulsa la estrella de un clip – nunca se borran solos."
],
"Noch keine Notiz. Leg oben eine an.": [
"No note yet. Create one at the top.",
"Aún no hay notas. Crea una arriba."
],
"Noch keine Screenshots. Aufnehmen mit Strg+Umschalt+X.": [
"No screenshots yet. Capture with Ctrl+Shift+X.",
"Aún no hay capturas. Captura con Ctrl+Mayús+X."
],
"Noch keine eigenen Bilder. Lade ein PNG oder GIF hoch.": [
"No own images yet. Upload a PNG or GIF.",
"Aún no hay imágenes propias. Sube un PNG o GIF."
],
"Noch keine eigenen Clips. Hotkey drücken, um die letzten Sekunden zu sichern.": [
"No own clips yet. Press the hotkey to save the last seconds.",
"Aún no hay clips propios. Pulsa el atajo para guardar los últimos segundos."
],
"Notizen": [
"Notes",
"Notas"
],
"Nur der runde Kreis – ohne Karte, Text und Balken": [
"Only the round disc – no card, text or bar",
"Solo el círculo – sin tarjeta, texto ni barra"
],
"Nur in der Island anzeigen (Windows-Banner aus)": [
"Show only in the island (Windows banners off)",
"Mostrar solo en la isla (banners de Windows apagados)"
],
"Nur mein Gesicht zählt": [
"Only my face counts",
"Solo cuenta mi cara"
],
"Nur mit Platten-Knistern": [
"Only with record crackle",
"Solo con crujido de disco"
],
"Nächsten Termin zeigen": [
"Show next event",
"Mostrar el próximo evento"
],
"Nächster (Alt+→)": [
"Next (Alt+→)",
"Siguiente (Alt+→)"
],
"Nächster Titel": [
"Next track",
"Siguiente pista"
],
"Nächstes Design": [
"Next design",
"Siguiente diseño"
],
"Oben": [
"Top",
"Arriba"
],
"Orbit Island ist aus": [
"Orbit Island is off",
"Orbit Island está apagada"
],
"Orbit Island ist nur unter Windows mit dieser Installation verfügbar.": [
"Orbit Island is only available on Windows with this installation.",
"Orbit Island solo está disponible en Windows con esta instalación."
],
"Orbit Island läuft": [
"Orbit Island is running",
"Orbit Island está activa"
],
"Orbit Island wird gestartet …": [
"Starting Orbit Island …",
"Iniciando Orbit Island …"
],
"Ordner": [
"Folder",
"Carpeta"
],
"Ordner für eigene Dateien": [
"Folder for your own files",
"Carpeta para tus archivos"
],
"Ordner konnte nicht erstellt werden": [
"Couldn’t create the folder",
"No se pudo crear la carpeta"
],
"Ordner werden analysiert…": [
"Analyzing folders…",
"Analizando carpetas…"
],
"Ordner öffnen": [
"Open folder",
"Abrir carpeta"
],
"Ordner-Info": [
"Folder info",
"Info de carpeta"
],
"Overlay im Spiel": [
"Overlay in game",
"Overlay en el juego"
],
"PDF konnte nicht geladen werden": [
"Couldn’t load the PDF",
"No se pudo cargar el PDF"
],
"PNG, JPG, WebP, SVG oder animiertes GIF": [
"PNG, JPG, WebP, SVG or animated GIF",
"PNG, JPG, WebP, SVG o GIF animado"
],
"Pfad der Auswahl kopieren – ohne Auswahl den Pfad des Ordners (Strg+Umschalt+C)": [
"Copy path of the selection – without a selection the folder path (Ctrl+Shift+C)",
"Copiar ruta de la selección – sin selección la de la carpeta (Ctrl+Mayús+C)"
],
"Pfeil": [
"Arrow",
"Flecha"
],
"Pixel-Größe": [
"Pixel size",
"Tamaño de píxel"
],
"Pixeln": [
"Pixel art",
"Píxeles"
],
"Position": [
"Position",
"Posición"
],
"Position gespeichert": [
"Position saved",
"Posición guardada"
],
"Position im Spiel": [
"Position in game",
"Posición en el juego"
],
"Position und Größe zurücksetzen": [
"Reset position and size",
"Restablecer posición y tamaño"
],
"Position – Ecke wählen oder unten frei ziehen": [
"Position – pick a corner or drag freely below",
"Posición – elige una esquina o arrastra abajo"
],
"Priorität Kalender": [
"Calendar priority",
"Prioridad calendario"
],
"Priorität Musik": [
"Music priority",
"Prioridad música"
],
"Priorität Timer": [
"Timer priority",
"Prioridad temporizador"
],
"Profil gelöscht": [
"Profile deleted",
"Perfil borrado"
],
"Profile": [
"Profiles",
"Perfiles"
],
"Prozesse": [
"Processes",
"Procesos"
],
"Prozesse werden geladen …": [
"Loading processes …",
"Cargando procesos …"
],
"Prozessor-Auslastung, mit Temperatur wenn das Board sie liefert": [
"CPU usage, with temperature if the board reports it",
"Uso de CPU, con temperatura si la placa la da"
],
"Präsentation": [
"Presentation",
"Presentación"
],
"Prüfintervall": [
"Check interval",
"Intervalo de comprobación"
],
"Puffer noch leer – ein paar Sekunden warten.": [
"Buffer still empty – wait a few seconds.",
"Búfer vacío – espera unos segundos."
],
"Punkt Weiß": [
"White dot",
"Punto blanco"
],
"Qualität": [
"Quality",
"Calidad"
],
"Quellen werden geladen …": [
"Loading sources …",
"Cargando fuentes …"
],
"Randstärke": [
"Border width",
"Grosor del borde"
],
"Rang-Crosshair ist aktiv": [
"Rank crosshair is active",
"Crosshair de rango activo"
],
"Rang-Crosshair nicht gefunden": [
"Rank crosshair not found",
"Crosshair de rango no encontrado"
],
"Rang-Erkennung an – Lobby wird gelesen": [
"Rank detection on – reading lobby",
"Detección de rango activa – leyendo lobby"
],
"Rang-Erkennung aus": [
"Rank detection off",
"Detección de rango apagada"
],
"Reagiert auf den Ton": [
"Reacts to sound",
"Reacciona al sonido"
],
"Rechts": [
"Right",
"Derecha"
],
"Rechtsbündig": [
"Align right",
"Alinear a la derecha"
],
"Recorder konnte nicht geladen werden.": [
"Couldn’t load the recorder.",
"No se pudo cargar el grabador."
],
"Replays werden gelesen …": [
"Reading replays …",
"Leyendo repeticiones …"
],
"Revulution Hub läuft weiter": [
"Revulution Hub keeps running",
"Revulution Hub sigue en marcha"
],
"Revulution Hub öffnen": [
"Open Revulution Hub",
"Abrir Revulution Hub"
],
"Ruhezeit ab": [
"Quiet hours from",
"Horas de silencio desde"
],
"Ruhezeit bis": [
"Quiet hours until",
"Horas de silencio hasta"
],
"Rückgängig (Strg+Z)": [
"Undo (Ctrl+Z)",
"Deshacer (Ctrl+Z)"
],
"Rückruf-Port": [
"Callback port",
"Puerto de retorno"
],
"Schaden pro Gegner erscheint, sobald die Aufnahme während des Matches lief.": [
"Damage per opponent appears once recording ran during the match.",
"El daño por rival aparece si se grabó durante la partida."
],
"Schaden pro Gegner ist eine OCR-Schätzung vom Bildschirm – Gesamtschaden oben ist exakt aus dem Replay.": [
"Damage per opponent is an OCR estimate – total damage above is exact from the replay.",
"El daño por rival es una estimación OCR – el total arriba es exacto de la repetición."
],
"Schließen": [
"Close",
"Cerrar"
],
"Schließen (Esc)": [
"Close (Esc)",
"Cerrar (Esc)"
],
"Schnellwahl (Minuten, mit Komma getrennt)": [
"Quick picks (minutes, comma separated)",
"Accesos rápidos (minutos, separados por comas)"
],
"Schreiben wie in Word: Formatvorlagen, Tabellen, Bilder, Seitenansicht. Öffnet und speichert .docx, exportiert PDF.": [
"Write like in Word: styles, tables, images, page view. Opens and saves .docx, exports PDF.",
"Escribe como en Word: estilos, tablas, imágenes, vista de página. Abre y guarda .docx, exporta PDF."
],
"Schriftgröße": [
"Font size",
"Tamaño de fuente"
],
"Schriftstärke": [
"Font weight",
"Grosor de fuente"
],
"Screenshot einfügen": [
"Insert screenshot",
"Insertar captura"
],
"Seit über einem Jahr nicht mehr geändert (ab 256 KB)": [
"Not changed for over a year (from 256 KB)",
"Sin cambios desde hace más de un año (desde 256 KB)"
],
"Sets für verschiedene Spiele oder Stimmungen.": [
"Sets for different games or moods.",
"Sets para distintos juegos o estados de ánimo."
],
"Setzt Gesamt und Heute auf 0. Zur Sicherheit mit deinem Fortnite-Namen bestätigen.": [
"Resets total and today to 0. Confirm with your Fortnite name to be safe.",
"Pone total y hoy a 0. Confirma con tu nombre de Fortnite."
],
"So erkannt aus Fortnite – nicht manuell änderbar": [
"Detected from Fortnite – can’t be changed manually",
"Detectado de Fortnite – no se puede cambiar a mano"
],
"So sieht der Revulution Hub aus und so verhält er sich. Die Einstellungen der einzelnen Apps findest du in ihrem jeweiligen Bereich.": [
"How Revulution Hub looks and behaves. Each app’s own settings are in its section.",
"Así se ve y funciona Revulution Hub. Los ajustes de cada app están en su sección."
],
"So sieht es im Spiel aus": [
"This is how it looks in game",
"Así se ve en el juego"
],
"Solange das aus ist, belegt die App keine globalen Tasten – F8 und F9 bleiben dann für andere Programme frei.": [
"While off, the app uses no global keys – F8 and F9 stay free for other programs.",
"Mientras esté apagado, la app no usa teclas globales – F8 y F9 quedan libres."
],
"Songname und Künstler": [
"Song title and artist",
"Canción y artista"
],
"Songname und Künstler unter dem Cover": [
"Song title and artist below the cover",
"Canción y artista bajo la portada"
],
"Spalte löschen": [
"Delete column",
"Borrar columna"
],
"Spalte rechts einfügen": [
"Insert column right",
"Insertar columna a la derecha"
],
"Speicher": [
"Storage",
"Almacenamiento"
],
"Speichern": [
"Save",
"Guardar"
],
"Speichern unter …": [
"Save as …",
"Guardar como …"
],
"Speichern unter … (Strg+Umschalt+S)": [
"Save as … (Ctrl+Shift+S)",
"Guardar como … (Ctrl+Mayús+S)"
],
"Speicherordner für Screenshots": [
"Screenshot save folder",
"Carpeta de capturas"
],
"Speicherort nicht verfügbar (Systemprozess).": [
"Location not available (system process).",
"Ubicación no disponible (proceso del sistema)."
],
"Speicherort öffnen": [
"Open location",
"Abrir ubicación"
],
"Spiegeln: an": [
"Mirror: on",
"Espejo: sí"
],
"Spiegeln: aus": [
"Mirror: off",
"Espejo: no"
],
"Spiel gegen die KI (bis unschlagbar) oder online gegen Freunde. Der Coach bewertet jeden Zug, erklärt Fehler und analysiert ganze Partien.": [
"Play the AI (up to unbeatable) or friends online. The coach rates every move, explains mistakes and analyzes whole games.",
"Juega contra la IA (hasta imbatible) o con amigos online. El entrenador valora cada jugada, explica errores y analiza partidas."
],
"Spielsound und Mikrofon landen zusammen in einer Tonspur. Änderungen gelten sofort – eine laufende Aufnahme startet dafür kurz neu.": [
"Game sound and mic go into one audio track. Changes apply instantly – a running recording restarts briefly.",
"Sonido del juego y micrófono van en una pista. Los cambios se aplican al instante – la grabación se reinicia un momento."
],
"Sprachaufnahme liegt auf der Spur „Sprache“.": [
"The voice recording is on the “Voice” track.",
"La grabación de voz está en la pista «Voz»."
],
"Sprachaufnahme über das Video legen": [
"Record voice over the video",
"Grabar voz sobre el vídeo"
],
"Start & Hintergrund": [
"Startup & background",
"Inicio y segundo plano"
],
"Start, Ton und Verhalten der App": [
"Startup, sound and behavior of the app",
"Inicio, sonido y comportamiento de la app"
],
"Starte Musik in Spotify oder im Browser": [
"Start music in Spotify or the browser",
"Pon música en Spotify o en el navegador"
],
"Startet automatisch mit Fortnite – oder hier von Hand": [
"Starts automatically with Fortnite – or manually here",
"Se inicia con Fortnite – o a mano aquí"
],
"Startet automatisch, sobald auf dem PC Musik läuft (Spotify, Browser, …).": [
"Starts automatically when music plays on the PC (Spotify, browser, …).",
"Se inicia solo cuando suena música en el PC (Spotify, navegador, …)."
],
"Startet die Dynamic Island zusammen mit dem Hub.": [
"Starts the Dynamic Island together with the hub.",
"Inicia la Dynamic Island junto con el hub."
],
"Statistiken": [
"Stats",
"Estadísticas"
],
"Status in der Island": [
"Status in the island",
"Estado en la isla"
],
"Steuerung im Spiel, ohne das Fenster zu öffnen.": [
"Control in game without opening the window.",
"Control en el juego sin abrir la ventana."
],
"Steuerung über Spotify": [
"Control via Spotify",
"Control con Spotify"
],
"Street View erraten wie bei GeoGuessr: Klassisch, Tägliche Challenge, Länder-Streak und online Duell oder Party mit Freunden.": [
"Guess Street View like GeoGuessr: classic, daily challenge, country streak and online duel or party with friends.",
"Adivina Street View como en GeoGuessr: clásico, reto diario, racha de países y duelo o fiesta online."
],
"Strichstärke": [
"Stroke width",
"Grosor del trazo"
],
"Stumm": [
"Muted",
"Silenciado"
],
"Stumm-Symbol, wenn das Mikrofon stumm ist oder nichts ankommt": [
"Mute icon when the mic is muted or silent",
"Icono de silencio si el micro está mudo o sin señal"
],
"Stärke": [
"Strength",
"Intensidad"
],
"Suche": [
"Search",
"Búsqueda"
],
"Suche Fortnite-Fenster …": [
"Looking for Fortnite window …",
"Buscando ventana de Fortnite …"
],
"Suchen": [
"Search",
"Buscar"
],
"Systemlautstärke und jede App einzeln regeln.": [
"Control system volume and each app separately.",
"Controla el volumen del sistema y de cada app."
],
"Systemlautstärke und jede App einzeln – direkt aus Windows": [
"System volume and each app separately – straight from Windows",
"Volumen del sistema y de cada app – directo de Windows"
],
"Tabelle": [
"Table",
"Tabla"
],
"Tabelle einfügen": [
"Insert table",
"Insertar tabla"
],
"Tag": [
"Day",
"Día"
],
"Tage": [
"Days",
"Días"
],
"Tage vorausschauen": [
"Days ahead",
"Días por delante"
],
"Taste 1–5 wechselt das Design – z. B. Gewehr, Schrot, SMG, Sniper": [
"Key 1–5 switches the design – e.g. rifle, shotgun, SMG, sniper",
"Tecla 1–5 cambia el diseño – p. ej. rifle, escopeta, SMG, francotirador"
],
"Tasten sind eingebrannt": [
"Keys are burned in",
"Teclas incrustadas"
],
"Tastenkürzel": [
"Shortcuts",
"Atajos"
],
"Tastenkürzel aktiv": [
"Shortcuts active",
"Atajos activos"
],
"Tastenkürzel aus": [
"Shortcuts off",
"Atajos desactivados"
],
"Tastenkürzel:": [
"Shortcuts:",
"Atajos:"
],
"Temp-/Cache-Dateien, die seit mindestens einem Tag unangetastet sind": [
"Temp/cache files untouched for at least a day",
"Archivos temporales/caché sin usar al menos un día"
],
"Temporär": [
"Temporary",
"Temporal"
],
"Terminliste in der Island": [
"Event list in the island",
"Lista de eventos en la isla"
],
"Text": [
"Text",
"Texto"
],
"Titel an die Quelle senden": [
"Send title to the source",
"Enviar título a la fuente"
],
"Titel oder Untertitel am Abspielkopf einfügen": [
"Insert a title or subtitle at the playhead",
"Insertar título o subtítulo en el cabezal"
],
"Ton": [
"Sound",
"Sonido"
],
"Ton 1": [
"Audio 1",
"Audio 1"
],
"Ton aus": [
"Sound off",
"Sonido apagado"
],
"Ton, wenn ein Timer endet": [
"Sound when a timer ends",
"Sonido al terminar un temporizador"
],
"Truhe im Blick": [
"Chest in view",
"Cofre a la vista"
],
"Truhen": [
"Chests",
"Cofres"
],
"Truhen insgesamt": [
"Chests in total",
"Cofres en total"
],
"Truhen zählen": [
"Count chests",
"Contar cofres"
],
"Truhen-Zähler nicht erreichbar": [
"Chest counter not reachable",
"Contador de cofres no disponible"
],
"Truhen-Zähler zurückgesetzt": [
"Chest counter reset",
"Contador de cofres reiniciado"
],
"Umbenennen": [
"Rename",
"Renombrar"
],
"Umbenennen fehlgeschlagen": [
"Rename failed",
"No se pudo renombrar"
],
"Unbekannte Datei.": [
"Unknown file.",
"Archivo desconocido."
],
"Ungespeicherte Änderungen": [
"Unsaved changes",
"Cambios sin guardar"
],
"Ungespeicherte Änderungen verwerfen?": [
"Discard unsaved changes?",
"¿Descartar cambios sin guardar?"
],
"Unschärfe": [
"Blur",
"Desenfoque"
],
"Unten": [
"Bottom",
"Abajo"
],
"Verpixeln": [
"Pixelate",
"Pixelar"
],
"Verzögerung beim Darüberfahren": [
"Hover delay",
"Retardo al pasar el ratón"
],
"Verzögerung beim Zuklappen": [
"Collapse delay",
"Retardo al cerrar"
],
"Video 2 liegt über Video 1 – als Vollbild oder Bild-in-Bild. Ton, Musik und Sprache werden gemischt.": [
"Video 2 sits on top of video 1 – fullscreen or picture-in-picture. Sound, music and voice are mixed.",
"El vídeo 2 va sobre el 1 – a pantalla completa o imagen en imagen. Sonido, música y voz se mezclan."
],
"Video auch auf dem Desktop abspielen": [
"Also play the video on the desktop",
"Reproducir el vídeo también en el escritorio"
],
"Videos zuschneiden, teilen und Stücke entfernen. Export als MP4, GIF oder MP3 – auch blitzschnell ohne Neukodierung.": [
"Trim and split videos, remove parts. Export as MP4, GIF or MP3 – even lightning-fast without re-encoding.",
"Recorta y divide vídeos, quita partes. Exporta a MP4, GIF o MP3 – incluso al instante sin recodificar."
],
"Videos, Clips oder Musik hier ablegen": [
"Drop videos, clips or music here",
"Suelta aquí vídeos, clips o música"
],
"Videos, Musik oder Bilder hinzufügen": [
"Add videos, music or images",
"Añadir vídeos, música o imágenes"
],
"Vorgänge": [
"Operations",
"Operaciones"
],
"Vorgänge & Zwischenablage": [
"Operations & clipboard",
"Operaciones y portapapeles"
],
"Vorschau": [
"Preview",
"Vista previa"
],
"Vorschau 2,4× · im Spiel 1:1": [
"Preview 2.4× · in game 1:1",
"Vista previa 2,4× · en juego 1:1"
],
"Vorschau läuft – Musik-Overlay sollte oben erscheinen": [
"Preview running – the music overlay should appear at the top",
"Vista previa – el overlay de música debería aparecer arriba"
],
"Vorschau zeigen": [
"Show preview",
"Mostrar vista previa"
],
"Vorwärts (Alt+→)": [
"Forward (Alt+→)",
"Adelante (Alt+→)"
],
"Wartet auf „Durchsuchen“ neben dem Fadenkreuz …": [
"Waiting for “Search” next to the crosshair …",
"Esperando «Buscar» junto al crosshair …"
],
"Was beim Öffnen des Hubs angezeigt wird.": [
"What shows when the hub opens.",
"Qué se muestra al abrir el hub."
],
"Weiß": [
"White",
"Blanco"
],
"Wenn ein Timer endet aufklappen": [
"Expand when a timer ends",
"Abrir al terminar un temporizador"
],
"Wie groß der Player am Bildschirm ist": [
"How big the player is on screen",
"Qué tamaño tiene el reproductor"
],
"Wie lange du heute und in der Woche am PC warst.": [
"How long you were at the PC today and this week.",
"Cuánto tiempo estuviste en el PC hoy y esta semana."
],
"Wie stark der Hintergrund abgedunkelt wird, damit Text gut lesbar bleibt.": [
"How much the background is dimmed so text stays readable.",
"Cuánto se oscurece el fondo para que el texto se lea bien."
],
"Wiedergabegerät anzeigen": [
"Show playback device",
"Mostrar dispositivo de salida"
],
"Wiederhergestellt – noch nicht gespeichert": [
"Restored – not saved yet",
"Restaurado – aún sin guardar"
],
"Windows-Benachrichtigungen in der Island": [
"Windows notifications in the island",
"Notificaciones de Windows en la isla"
],
"Wird automatisch erkannt, sobald du mit Rang in der Lobby stehst": [
"Detected automatically once you’re in the lobby with a rank",
"Se detecta solo cuando estás en el lobby con rango"
],
"Wird automatisch gespeichert und bleibt lokal auf deinem PC.": [
"Saved automatically and stays local on your PC.",
"Se guarda solo y queda en tu PC."
],
"Wirklich alle Clips löschen?": [
"Really delete all clips?",
"¿Borrar de verdad todos los clips?"
],
"Wo auf der Welt bist du?": [
"Where in the world are you?",
"¿Dónde del mundo estás?"
],
"Wo und wie das Crosshair erscheint": [
"Where and how the crosshair appears",
"Dónde y cómo aparece el crosshair"
],
"Zeigt ausschließlich den runden Kreis – ohne Karte, Text und Balken": [
"Shows only the round disc – no card, text or bar",
"Muestra solo el círculo – sin tarjeta, texto ni barra"
],
"Zeile darunter einfügen": [
"Insert row below",
"Insertar fila debajo"
],
"Zeile löschen": [
"Delete row",
"Borrar fila"
],
"Ziehen zum Verschieben, Ecke ziehen für die Größe": [
"Drag to move, drag the corner to resize",
"Arrastra para mover, la esquina para cambiar el tamaño"
],
"Zielordner konnte nicht geöffnet werden": [
"Couldn’t open the target folder",
"No se pudo abrir la carpeta de destino"
],
"Zu Favoriten hinzugefügt": [
"Added to favorites",
"Añadido a favoritos"
],
"Zuletzt geöffnet": [
"Last opened",
"Último abierto"
],
"Zuletzt in der Lobby erkannt:": [
"Last detected in the lobby:",
"Último detectado en el lobby:"
],
"Zurück (Alt+←)": [
"Back (Alt+←)",
"Atrás (Alt+←)"
],
"Zurück zu den Dateien": [
"Back to files",
"Volver a los archivos"
],
"Zurücksetzen": [
"Reset",
"Restablecer"
],
"Zwei Fenster (Ctrl+Shift+D)": [
"Two panes (Ctrl+Shift+D)",
"Dos paneles (Ctrl+Mayús+D)"
],
"Zweites Fenster anzeigen": [
"Show second pane",
"Mostrar segundo panel"
],
"Zähler & Overlay": [
"Counter & overlay",
"Contador y overlay"
],
"Zählt jede geöffnete Truhe – insgesamt, für immer.": [
"Counts every opened chest – in total, forever.",
"Cuenta cada cofre abierto – en total, para siempre."
],
"Älteste zuerst": [
"Oldest first",
"Más antiguos primero"
],
"Änderungen gelten sofort – ohne Neustart.": [
"Changes apply instantly – no restart.",
"Los cambios se aplican al instante – sin reiniciar."
],
"Änderungen sind sofort im Overlay": [
"Changes show in the overlay right away",
"Los cambios aparecen al instante en el overlay"
],
"Änderungen werden beim nächsten Start übernommen.": [
"Changes apply on the next start.",
"Los cambios se aplican en el próximo inicio."
],
"Öffnen": [
"Open",
"Abrir"
],
"Öffnet in Word, LibreOffice und Google Docs": [
"Opens in Word, LibreOffice and Google Docs",
"Se abre en Word, LibreOffice y Google Docs"
],
"Über": [
"About",
"Acerca de"
],
"Über „Hinzufügen“ oder per Drag & Drop.": [
"Via “Add” or drag & drop.",
"Con «Añadir» o arrastrando."
],
"Überblenden": [
"Crossfade",
"Fundido"
],
"Übergeordneter Ordner (Alt+↑)": [
"Parent folder (Alt+↑)",
"Carpeta superior (Alt+↑)"
],
"Überschrift 1": [
"Heading 1",
"Título 1"
],
"Überschrift 2": [
"Heading 2",
"Título 2"
],
"Überschrift 3": [
"Heading 3",
"Título 3"
],
"Übersicht": [
"Overview",
"Resumen"
],
"Abdunklung": [
"Dimming",
"Oscurecimiento"
],
"Abgebrochen": [
"Canceled",
"Cancelado"
],
"Abgeschlossen": [
"Completed",
"Completado"
],
"Abstand oben": [
"Top margin",
"Margen superior"
],
"Akku": [
"Battery",
"Batería"
],
"Aktion fehlgeschlagen": [
"Action failed",
"La acción falló"
],
"Aktivieren": [
"Activate",
"Activar"
],
"Aktualisieren": [
"Refresh",
"Actualizar"
],
"Aktuelles duplizieren": [
"Duplicate current",
"Duplicar actual"
],
"Akzent": [
"Accent",
"Acento"
],
"Albumcover": [
"Album cover",
"Portada"
],
"Alle": [
"All",
"Todo"
],
"Alle Benutzer": [
"All users",
"Todos los usuarios"
],
"Alle ersetzen": [
"Replace all",
"Reemplazar todo"
],
"Alles anpassen": [
"Adjust everything",
"Ajustar todo"
],
"Allgemein": [
"General",
"General"
],
"Analysieren": [
"Analyze",
"Analizar"
],
"Anwesenheit": [
"Presence",
"Presencia"
],
"Anzeige": [
"Display",
"Pantalla"
],
"Anzeigedauer": [
"Display duration",
"Duración en pantalla"
],
"Anzeigen": [
"Show",
"Mostrar"
],
"Archiv": [
"Archive",
"Archivo"
],
"Archiv entpacken": [
"Extract archive",
"Extraer archivo"
],
"Archivname": [
"Archive name",
"Nombre del archivo"
],
"Aufklappen": [
"Expand",
"Desplegar"
],
"Aufnahmen": [
"Recordings",
"Grabaciones"
],
"Auslastung": [
"Usage",
"Uso"
],
"Ausschneiden": [
"Cut",
"Cortar"
],
"Auswahl entfernen": [
"Clear selection",
"Quitar selección"
],
"Auswertung": [
"Analysis",
"Análisis"
],
"Automatik": [
"Automatic",
"Automático"
],
"Automatisch ausblenden": [
"Hide automatically",
"Ocultar automáticamente"
],
"Bedienung": [
"Controls",
"Controles"
],
"Bekannt": [
"Known",
"Conocido"
],
"Benachrichtigungen": [
"Notifications",
"Notificaciones"
],
"Benutzer": [
"User",
"Usuario"
],
"Bereit": [
"Ready",
"Listo"
],
"Bewegung": [
"Motion",
"Movimiento"
],
"Bewegung reduzieren": [
"Reduce motion",
"Reducir movimiento"
],
"Bildrate": [
"Frame rate",
"Tasa de fotogramas"
],
"Bildweise": [
"Frame by frame",
"Fotograma a fotograma"
],
"Blocksatz": [
"Justify",
"Justificar"
],
"Breit": [
"Wide",
"Ancho"
],
"Champion": [
"Champion",
"Campeón"
],
"Clip gespeichert": [
"Clip saved",
"Clip guardado"
],
"Clipper aktiv": [
"Clipper active",
"Clipper activo"
],
"Clipper bereit": [
"Clipper ready",
"Clipper listo"
],
"Computername": [
"Computer name",
"Nombre del equipo"
],
"Countdown anzeigen": [
"Show countdown",
"Mostrar cuenta atrás"
],
"Darstellung": [
"Appearance",
"Apariencia"
],
"Dateisuche": [
"File search",
"Búsqueda de archivos"
],
"Daten": [
"Data",
"Datos"
],
"Datum": [
"Date",
"Fecha"
],
"Dauer": [
"Duration",
"Duración"
],
"Deckkraft": [
"Opacity",
"Opacidad"
],
"Desktop-Widgets anzeigen": [
"Show desktop widgets",
"Mostrar widgets de escritorio"
],
"Diamant": [
"Diamond",
"Diamante"
],
"Dick": [
"Thick",
"Grueso"
],
"Dicke": [
"Thickness",
"Grosor"
],
"Distanz": [
"Distance",
"Distancia"
],
"Dokumente": [
"Documents",
"Documentos"
],
"Drehung": [
"Rotation",
"Rotación"
],
"Dreieck": [
"Triangle",
"Triángulo"
],
"Duplikate suchen": [
"Find duplicates",
"Buscar duplicados"
],
"Duplizieren": [
"Duplicate",
"Duplicar"
],
"Durchgestrichen": [
"Strikethrough",
"Tachado"
],
"Durchsuchen": [
"Browse",
"Examinar"
],
"Ecken eingeklappt": [
"Corners when collapsed",
"Esquinas cerrada"
],
"Ecken mitanimieren": [
"Animate corners",
"Animar esquinas"
],
"Eckig": [
"Square",
"Cuadrado"
],
"Eigene": [
"Own",
"Propio"
],
"Eigener Clip": [
"Own clip",
"Clip propio"
],
"Eigenschaften": [
"Properties",
"Propiedades"
],
"Einblendungen": [
"Overlays",
"Superposiciones"
],
"Eingeklappt durchklickbar": [
"Click-through when collapsed",
"Atravesable cerrada"
],
"Einzug verkleinern": [
"Decrease indent",
"Reducir sangría"
],
"Elemente": [
"Items",
"Elementos"
],
"Entf": [
"Del",
"Supr"
],
"Erinnerung vorher": [
"Reminder before",
"Recordatorio antes"
],
"Erinnerungston": [
"Reminder sound",
"Sonido de recordatorio"
],
"Erkennung": [
"Detection",
"Detección"
],
"Erkennungsschwelle": [
"Detection threshold",
"Umbral de detección"
],
"Erledigt": [
"Done",
"Hecho"
],
"Ersetzen": [
"Replace",
"Reemplazar"
],
"Ersetzen durch": [
"Replace with",
"Reemplazar por"
],
"Erstellen": [
"Create",
"Crear"
],
"Extras": [
"Extras",
"Extras"
],
"Farben": [
"Colors",
"Colores"
],
"Favorit entfernen": [
"Remove favorite",
"Quitar favorito"
],
"Federung": [
"Springiness",
"Elasticidad"
],
"Feinabstimmung": [
"Fine-tuning",
"Ajuste fino"
],
"Fokus": [
"Focus",
"Enfoque"
],
"Form": [
"Shape",
"Forma"
],
"Formatvorlage": [
"Style",
"Estilo"
],
"Fortschritt": [
"Progress",
"Progreso"
],
"Fortschrittsbalken": [
"Progress bar",
"Barra de progreso"
],
"Funken": [
"Sparks",
"Chispas"
],
"Galerie": [
"Gallery",
"Galería"
],
"Gegner": [
"Opponent",
"Rival"
],
"Gesichtserkennung": [
"Face recognition",
"Reconocimiento facial"
],
"Hoch": [
"High",
"Alto"
],
"Hochgestellt": [
"Superscript",
"Superíndice"
],
"Im Overlay zeigen": [
"Show in overlay",
"Mostrar en overlay"
],
"Immer sichtbar": [
"Always visible",
"Siempre visible"
],
"Inhalt": [
"Content",
"Contenido"
],
"Inhalt automatisch wechseln": [
"Switch content automatically",
"Cambiar contenido automáticamente"
],
"Inhaltswechsel": [
"Content switch",
"Cambio de contenido"
],
"Jetzt scannen": [
"Scan now",
"Escanear ahora"
],
"Kalender": [
"Calendar",
"Calendario"
],
"Kamera": [
"Camera",
"Cámara"
],
"Kein Design": [
"No design",
"Sin diseño"
],
"Kein Rang": [
"No rank",
"Sin rango"
],
"Keine": [
"None",
"Ninguno"
],
"Keine Tasten aufgezeichnet": [
"No keys recorded",
"No se grabaron teclas"
],
"Kill-Clip gespeichert": [
"Kill clip saved",
"Clip de kill guardado"
],
"Klammern": [
"Brackets",
"Corchetes"
],
"Klassisch": [
"Classic",
"Clásico"
],
"Klein": [
"Small",
"Pequeño"
],
"Kleiner": [
"Smaller",
"Más pequeño"
],
"Klick": [
"Click",
"Clic"
],
"Klick bewirkt": [
"Click does",
"El clic hace"
],
"Klicksounds": [
"Click sounds",
"Sonidos de clic"
],
"Komet": [
"Comet",
"Cometa"
],
"Kompakt": [
"Compact",
"Compacto"
],
"Komprimieren": [
"Compress",
"Comprimir"
],
"Konfiguration exportieren": [
"Export configuration",
"Exportar configuración"
],
"Konfiguration geladen": [
"Configuration loaded",
"Configuración cargada"
],
"Konfiguration gespeichert": [
"Configuration saved",
"Configuración guardada"
],
"Kontur": [
"Outline",
"Contorno"
],
"Kreis": [
"Circle",
"Círculo"
],
"Kreuz": [
"Cross",
"Cruz"
],
"Lange unbenutzt": [
"Long unused",
"Sin usar hace tiempo"
],
"Laufzeit": [
"Runtime",
"Duración"
],
"Leertaste": [
"Space bar",
"Barra espaciadora"
],
"Lesen": [
"Read",
"Leer"
],
"Leuchten": [
"Glow",
"Brillo"
],
"Limette": [
"Lime",
"Lima"
],
"Maus": [
"Mouse",
"Ratón"
],
"Maximieren": [
"Maximize",
"Maximizar"
],
"Medien": [
"Media",
"Medios"
],
"Meine Clips": [
"My clips",
"Mis clips"
],
"Mikrofon": [
"Microphone",
"Micrófono"
],
"Minimieren": [
"Minimize",
"Minimizar"
],
"Mittel": [
"Medium",
"Medio"
],
"Musikwechsel": [
"Track change",
"Cambio de canción"
],
"Nebentext": [
"Secondary text",
"Texto secundario"
],
"Neueste zuerst": [
"Newest first",
"Más recientes primero"
],
"Nicht gespeichert": [
"Not saved",
"Sin guardar"
],
"Nummer": [
"Number",
"Número"
],
"Nummerierung": [
"Numbering",
"Numeración"
],
"Nutzen": [
"Use",
"Usar"
],
"Ohne": [
"None",
"Ninguno"
],
"Optionen": [
"Options",
"Opciones"
],
"Overlay anzeigen": [
"Show overlay",
"Mostrar overlay"
],
"Overlay zeigen": [
"Show overlay",
"Mostrar overlay"
],
"Partikel": [
"Particles",
"Partículas"
],
"Pfad": [
"Path",
"Ruta"
],
"Pfad kopieren": [
"Copy path",
"Copiar ruta"
],
"Pfade kopiert": [
"Paths copied",
"Rutas copiadas"
],
"Pfeile": [
"Arrows",
"Flechas"
],
"Platin": [
"Platinum",
"Platino"
],
"Plattenspieler": [
"Record player",
"Tocadiscos"
],
"Platz": [
"Place",
"Puesto"
],
"Platzierung": [
"Placement",
"Posición"
],
"Player anzeigen": [
"Show player",
"Mostrar reproductor"
],
"Projekt": [
"Project",
"Proyecto"
],
"Prozessor": [
"Processor",
"Procesador"
],
"Prozessorkerne": [
"CPU cores",
"Núcleos"
],
"Punkt": [
"Dot",
"Punto"
],
"Quadrat": [
"Square",
"Cuadrado"
],
"Quelle": [
"Source",
"Fuente"
],
"Quellen": [
"Sources",
"Fuentes"
],
"Rand": [
"Border",
"Borde"
],
"Raster": [
"Grid",
"Cuadrícula"
],
"Rechteck": [
"Rectangle",
"Rectángulo"
],
"Regenbogen": [
"Rainbow",
"Arcoíris"
],
"Replays scannen": [
"Scan replays",
"Escanear repeticiones"
],
"Rot": [
"Red",
"Rojo"
],
"Ruhezeiten beachten": [
"Respect quiet hours",
"Respetar horas de silencio"
],
"Rund": [
"Round",
"Redondo"
],
"Scan fehlgeschlagen": [
"Scan failed",
"Escaneo fallido"
],
"Scan fertig": [
"Scan done",
"Escaneo listo"
],
"Schach": [
"Chess",
"Ajedrez"
],
"Schaden": [
"Damage",
"Daño"
],
"Schaden genommen": [
"Damage taken",
"Daño recibido"
],
"Schatten anzeigen": [
"Show shadow",
"Mostrar sombra"
],
"Schlummern": [
"Snooze",
"Posponer"
],
"Schnell anpassen": [
"Quick adjust",
"Ajuste rápido"
],
"Schnellzugriff": [
"Quick access",
"Acceso rápido"
],
"Schreiben": [
"Write",
"Escribir"
],
"Schriftart": [
"Font",
"Fuente"
],
"Schriftfarbe": [
"Font color",
"Color de fuente"
],
"Schrotflinte": [
"Shotgun",
"Escopeta"
],
"Screenshot aufnehmen": [
"Take screenshot",
"Hacer captura"
],
"Screenshot fehlgeschlagen": [
"Screenshot failed",
"Captura fallida"
],
"Screenshot gespeichert": [
"Screenshot saved",
"Captura guardada"
],
"Screenshot speichern": [
"Save screenshot",
"Guardar captura"
],
"Sekunden": [
"Seconds",
"Segundos"
],
"Sieg": [
"Win",
"Victoria"
],
"Sieg-Clip gespeichert": [
"Win clip saved",
"Clip de victoria guardado"
],
"Siege": [
"Wins",
"Victorias"
],
"Silber": [
"Silver",
"Plata"
],
"So funktioniert es": [
"How it works",
"Cómo funciona"
],
"Songtext": [
"Lyrics",
"Letra"
],
"Songtexte": [
"Lyrics",
"Letras"
],
"Sortieren": [
"Sort",
"Ordenar"
],
"Sortierung": [
"Sorting",
"Orden"
],
"Speicherordner": [
"Save folder",
"Carpeta de guardado"
],
"Speicherplatz verstehen": [
"Understand storage",
"Entender el espacio"
],
"Sperren": [
"Lock",
"Bloquear"
],
"Spiegelung": [
"Reflection",
"Reflejo"
],
"Spieler": [
"Player",
"Jugador"
],
"Spotify bevorzugen": [
"Prefer Spotify",
"Preferir Spotify"
],
"Sprachaufnahme": [
"Voice recording",
"Grabación de voz"
],
"Sprache": [
"Language",
"Idioma"
],
"Start fehlgeschlagen": [
"Start failed",
"Inicio fallido"
],
"Startseite": [
"Start page",
"Página de inicio"
],
"Stift": [
"Pen",
"Lápiz"
],
"Stil": [
"Style",
"Estilo"
],
"Stopp": [
"Stop",
"Parar"
],
"Strg": [
"Ctrl",
"Ctrl"
],
"Stromsparmodus": [
"Power saving",
"Ahorro de energía"
],
"Sturmgewehr": [
"Assault rifle",
"Fusil de asalto"
],
"Tempo": [
"Speed",
"Velocidad"
],
"Termine": [
"Events",
"Eventos"
],
"Textausrichtung": [
"Text alignment",
"Alineación del texto"
],
"Texthervorhebung": [
"Text highlight",
"Resaltado de texto"
],
"Textmarker": [
"Highlighter",
"Marcador"
],
"Textverarbeitung": [
"Word processing",
"Procesador de textos"
],
"Tiefgestellt": [
"Subscript",
"Subíndice"
],
"Titel": [
"Title",
"Título"
],
"Tonarm": [
"Tonearm",
"Brazo"
],
"Transparenz verringern": [
"Reduce transparency",
"Reducir transparencia"
],
"Treffer": [
"Hits",
"Impactos"
],
"Trefferquote": [
"Accuracy",
"Precisión"
],
"Trennlinie": [
"Divider",
"Separador"
],
"Truhe testen": [
"Test chest",
"Probar cofre"
],
"Typ": [
"Type",
"Tipo"
],
"Uhr": [
"Clock",
"Reloj"
],
"Uhr anzeigen": [
"Show clock",
"Mostrar reloj"
],
"Umbenannt": [
"Renamed",
"Renombrado"
],
"Unbekannt": [
"Unknown",
"Desconocido"
],
"Verhalten": [
"Behavior",
"Comportamiento"
],
"Verlauf": [
"History",
"Historial"
],
"Verlauf geleert": [
"History cleared",
"Historial borrado"
],
"Verlauf leeren": [
"Clear history",
"Borrar historial"
],
"Verwerfen": [
"Discard",
"Descartar"
],
"Video exportieren": [
"Export video",
"Exportar vídeo"
],
"Violett": [
"Violet",
"Violeta"
],
"Visualizer anzeigen": [
"Show visualizer",
"Mostrar visualizador"
],
"Visualizer eingeklappt pausieren": [
"Pause visualizer when collapsed",
"Pausar visualizador cerrada"
],
"Vollbild": [
"Fullscreen",
"Pantalla completa"
],
"Vorgang": [
"Operation",
"Operación"
],
"Vorgang abgeschlossen": [
"Operation completed",
"Operación completada"
],
"Vorgang fehlgeschlagen": [
"Operation failed",
"Operación fallida"
],
"Warteschlange": [
"Queue",
"Cola"
],
"Wartet": [
"Waiting",
"Esperando"
],
"Weitersuchen": [
"Find next",
"Buscar siguiente"
],
"Weltuhren": [
"World clocks",
"Relojes del mundo"
],
"Wichtige aufklappen": [
"Expand important ones",
"Abrir importantes"
],
"Wiedergabe": [
"Playback",
"Reproducción"
],
"Wiederherstellen": [
"Restore",
"Restaurar"
],
"Zeilenabstand": [
"Line spacing",
"Interlineado"
],
"Zeitversatz": [
"Time offset",
"Desfase"
],
"Zentriert": [
"Centered",
"Centrado"
],
"Ziehen": [
"Drag",
"Arrastrar"
],
"Zitat": [
"Quote",
"Cita"
],
"Zuklappen": [
"Collapse",
"Plegar"
],
"Zuletzt": [
"Recent",
"Reciente"
],
"Zuletzt verwendet": [
"Recently used",
"Usado recientemente"
],
"Zuschneiden": [
"Crop",
"Recortar"
],
"Start": [
"Home",
"Inicio"
],
"Gaming": [
"Gaming",
"Gaming"
],
"System": [
"System",
"Sistema"
],
"Video": [
"Video",
"Vídeo"
],
"Geo": [
"Geo",
"Geo"
],
"Design": [
"Design",
"Diseño"
],
"Designs": [
"Designs",
"Diseños"
],
"Audio": [
"Audio",
"Audio"
],
"Clips": [
"Clips",
"Clips"
],
"Animation": [
"Animation",
"Animación"
],
"Uhr & Kalender": [
"Clock & calendar",
"Reloj y calendario"
],
"Timer": [
"Timers",
"Temporizadores"
],
"Desktop-Widgets": [
"Desktop widgets",
"Widgets de escritorio"
],
"Separater Player": [
"Separate player",
"Reproductor aparte"
],
"Einstellung suchen …": [
"Search settings …",
"Buscar ajuste …"
],
"Übernommen": [
"Applied",
"Aplicado"
],
"Mit dem Hub starten": [
"Start with the hub",
"Iniciar con el hub"
],
"Guten Morgen": [
"Good morning",
"Buenos días"
],
"Guten Tag": [
"Good afternoon",
"Buenas tardes"
],
"Guten Abend": [
"Good evening",
"Buenas noches"
],
"Gute Nacht": [
"Good night",
"Buenas noches"
],
"Mit Windows starten": [
"Start with Windows",
"Iniciar con Windows"
],
"Orbit Island mitstarten": [
"Start Orbit Island too",
"Iniciar también Orbit Island"
],
"Bearbeiten": [
"Edit",
"Editar"
],
"Ansicht": [
"View",
"Vista"
],
"Format": [
"Format",
"Formato"
],
"Neu": [
"New",
"Nuevo"
],
"Drucken": [
"Print",
"Imprimir"
],
"Rückgängig": [
"Undo",
"Deshacer"
],
"Wiederholen": [
"Redo",
"Rehacer"
],
"Fett": [
"Bold",
"Negrita"
],
"Kursiv": [
"Italic",
"Cursiva"
],
"Unterstrichen": [
"Underline",
"Subrayado"
],
"Neuer Screenshot": [
"New screenshot",
"Nueva captura"
],
"Bereich": [
"Area",
"Área"
],
"Fenster": [
"Window",
"Ventana"
],
"Markieren": [
"Highlight",
"Resaltar"
],
"Teilen": [
"Split",
"Dividir"
],
"Schneiden": [
"Cut",
"Cortar"
],
"Prozess beenden": [
"End process",
"Finalizar proceso"
],
"Spur": [
"Track",
"Pista"
],
"Zeitleiste": [
"Timeline",
"Línea de tiempo"
],
"Wird geladen …": [
"Loading …",
"Cargando …"
],
"nur unter Windows": [
"Windows only",
"solo en Windows"
],
"Netzwerk ↓": [
"Network ↓",
"Red ↓"
],
"Netzwerk ↑": [
"Network ↑",
"Red ↑"
],
"Autostart-Programme gibt es nur unter Windows.": [
"Startup programs are only available on Windows.",
"Los programas de inicio solo existen en Windows."
],
"Dynamic Island": [
"Dynamic Island",
"Dynamic Island"
],
"Orbit Island by Revulution": [
"Orbit Island by Revulution",
"Orbit Island by Revulution"
],
"Agenda": [
"Agenda",
"Agenda"
],
"Termine & Erinnerungen": [
"Events & reminders",
"Eventos y recordatorios"
],
"Verbunden mit der Island": [
"Connected to the Island",
"Conectada con la Isla"
],
"＋ Neuer Termin": [
"＋ New event",
"＋ Nuevo evento"
],
"Neuer Termin": [
"New event",
"Nuevo evento"
],
"Termin bearbeiten": [
"Edit event",
"Editar evento"
],
"Termin (abonniert)": [
"Event (subscribed)",
"Evento (suscrito)"
],
"Morgen": [
"Tomorrow",
"Mañana"
],
"Liste": [
"List",
"Lista"
],
"Woche": [
"Week",
"Semana"
],
"Monat": [
"Month",
"Mes"
],
"Als Nächstes": [
"Up next",
"A continuación"
],
"Nichts geplant": [
"Nothing planned",
"Nada planeado"
],
"Lege mit „Neuer Termin“ los.": [
"Start with “New event”.",
"Empieza con «Nuevo evento»."
],
"Ganztägig": [
"All day",
"Todo el día"
],
"Beginn": [
"Start",
"Inicio"
],
"Von": [
"From",
"Desde"
],
"Bis": [
"To",
"Hasta"
],
"Ende (Tag)": [
"End (day)",
"Fin (día)"
],
"Erinnerung": [
"Reminder",
"Recordatorio"
],
"Zweite Erinnerung": [
"Second reminder",
"Segundo recordatorio"
],
"Ort": [
"Location",
"Lugar"
],
"Beim Beginn": [
"At start",
"Al empezar"
],
"5 Minuten vorher": [
"5 minutes before",
"5 minutos antes"
],
"10 Minuten vorher": [
"10 minutes before",
"10 minutos antes"
],
"15 Minuten vorher": [
"15 minutes before",
"15 minutos antes"
],
"30 Minuten vorher": [
"30 minutes before",
"30 minutos antes"
],
"1 Stunde vorher": [
"1 hour before",
"1 hora antes"
],
"2 Stunden vorher": [
"2 hours before",
"2 horas antes"
],
"1 Tag vorher": [
"1 day before",
"1 día antes"
],
"2 Tage vorher": [
"2 days before",
"2 días antes"
],
"1 Woche vorher": [
"1 week before",
"1 semana antes"
],
"Nie": [
"Never",
"Nunca"
],
"Täglich": [
"Daily",
"Diario"
],
"Wöchentlich": [
"Weekly",
"Semanal"
],
"Monatlich": [
"Monthly",
"Mensual"
],
"Jährlich": [
"Yearly",
"Anual"
],
"Nächste Termine": [
"Upcoming events",
"Próximos eventos"
],
"Keine Termine in den nächsten Wochen": [
"No events in the coming weeks",
"Sin eventos en las próximas semanas"
],
"Neue Termine erscheinen hier und in der Island.": [
"New events appear here and in the Island.",
"Los eventos nuevos aparecen aquí y en la Isla."
],
"＋ Termin anlegen": [
"＋ Add event",
"＋ Añadir evento"
],
"Termine sind mit der Orbit Island synchron. Erinnerungen kommen als Benachrichtigung – auch einen Tag vorher.": [
"Events are synced with Orbit Island. Reminders arrive as notifications – even a day before.",
"Los eventos se sincronizan con Orbit Island. Los recordatorios llegan como notificación, incluso un día antes."
],
"Termine als Liste, Woche oder Monat – verbunden mit der Orbit Island. Erinnert dich rechtzeitig, auf Wunsch auch einen Tag vorher.": [
"Events as list, week or month – connected to Orbit Island. Reminds you in time, even a day before if you like.",
"Eventos en lista, semana o mes, conectados con Orbit Island. Te avisa a tiempo, incluso un día antes."
],
"Kein Hotkey": [
"No hotkey",
"Sin atajo"
],
"Aus dem Projekt entfernen": [
"Remove from project",
"Quitar del proyecto"
],
"Standbild": [
"Still frame",
"Fotograma"
],
"Marker": [
"Marker",
"Marcador"
],
"Transformieren": [
"Transform",
"Transformar"
],
"Farbe & Effekte": [
"Color & effects",
"Color y efectos"
],
"Ein- & Ausblenden": [
"Fade in & out",
"Fundido de entrada y salida"
],
"Ton-Effekte": [
"Audio effects",
"Efectos de audio"
],
"Gaming – Facecam & Tasten": [
"Gaming – facecam & keys",
"Gaming – facecam y teclas"
],
"Standbild speichern": [
"Save still frame",
"Guardar fotograma"
],
"Facecam zeigen": [
"Show facecam",
"Mostrar facecam"
],
"Tasten anzeigen": [
"Show keys",
"Mostrar teclas"
],
"Geschwindigkeit": [
"Speed",
"Velocidad"
],
"Helligkeit": [
"Brightness",
"Brillo"
],
"Kontrast": [
"Contrast",
"Contraste"
],
"Sättigung": [
"Saturation",
"Saturación"
],
"Farbton": [
"Hue",
"Tono"
],
"Weichzeichner": [
"Blur",
"Desenfoque"
],
"Schärfen": [
"Sharpen",
"Enfocar"
],
"Effekt": [
"Effect",
"Efecto"
],
"Einblenden": [
"Fade in",
"Fundido de entrada"
],
"Ausblenden": [
"Fade out",
"Fundido de salida"
],
"Bass": [
"Bass",
"Graves"
],
"Höhen": [
"Treble",
"Agudos"
],
"Echo": [
"Echo",
"Eco"
],
"Rauschen entfernen": [
"Remove noise",
"Eliminar ruido"
],
"Codec": [
"Codec",
"Códec"
],
"Bitrate": [
"Bitrate",
"Tasa de bits"
],
"Ton-Bitrate": [
"Audio bitrate",
"Bitrate de audio"
],
"Ganzes Projekt": [
"Whole project",
"Proyecto completo"
],
"Nur ausgewählter Clip": [
"Selected clip only",
"Solo el clip seleccionado"
],
"Automatisch (Qualität)": [
"Automatic (quality)",
"Automático (calidad)"
]
};
