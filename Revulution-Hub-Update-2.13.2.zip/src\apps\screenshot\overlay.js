'use strict';

const params = new URLSearchParams(location.search);
const id = params.get('id');
const shot = document.getElementById('shot');
const sel = document.getElementById('sel');
const size = document.getElementById('size');
const dim = document.getElementById('dim');
const lx = document.getElementById('lx');
const ly = document.getElementById('ly');
const hint = document.getElementById('hint');

const fileUrl = (p) => 'file:///' + p.replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:');
shot.src = fileUrl(params.get('image'));

let start = null;
let rect = null;
let finished = false;

function finish(result) {
  if (finished) return;
  finished = true;
  window.overlay.done({ id, ...result });
}

function draw() {
  if (!rect) return;
  dim.style.display = 'none';
  sel.style.display = 'block';
  Object.assign(sel.style, { left: `${rect.x}px`, top: `${rect.y}px`, width: `${rect.width}px`, height: `${rect.height}px` });
  sel.style.backgroundImage = `url("${shot.src}")`;
  sel.style.backgroundSize = `${innerWidth}px ${innerHeight}px`;
  sel.style.backgroundPosition = `${-rect.x}px ${-rect.y}px`;
  size.style.display = 'block';
  size.textContent = `${Math.round(rect.width * devicePixelRatio)} × ${Math.round(rect.height * devicePixelRatio)}`;
  const below = rect.y + rect.height + 30 < innerHeight;
  size.style.left = `${rect.x}px`;
  size.style.top = `${below ? rect.y + rect.height + 8 : rect.y - 30}px`;
}

addEventListener('mousemove', (event) => {
  lx.style.top = `${event.clientY}px`;
  ly.style.left = `${event.clientX}px`;
  if (!start) return;
  hint.style.display = 'none';
  const x = Math.min(start.x, event.clientX);
  const y = Math.min(start.y, event.clientY);
  rect = { x, y, width: Math.abs(event.clientX - start.x), height: Math.abs(event.clientY - start.y) };
  draw();
});

addEventListener('mousedown', (event) => {
  if (event.button === 2) return finish({ cancel: true });
  start = { x: event.clientX, y: event.clientY };
});

addEventListener('mouseup', () => {
  if (!start) return;
  start = null;
  if (!rect || rect.width < 4 || rect.height < 4) return finish({ rect: null });
  finish({ rect });
});

addEventListener('keydown', (event) => {
  if (event.key === 'Escape') finish({ cancel: true });
  if (event.key === 'Enter') finish({ rect: rect && rect.width > 3 ? rect : null });
});

addEventListener('contextmenu', (event) => event.preventDefault());
