'use strict';

/* Word (.docx) import and export for the Dokumente app. */
(function () {
  const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  const xmlEsc = (value) => String(value).replace(/[<>&"]/g, (ch) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[ch]);
  const htmlEsc = (value) => String(value).replace(/[<>&"]/g, (ch) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[ch]);

  /* ============================================================== EXPORT */

  function rgbToHex(color) {
    const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(color || '');
    if (!m) return null;
    if (m[4] !== undefined && Number(m[4]) === 0) return null;
    return [m[1], m[2], m[3]].map((n) => Number(n).toString(16).padStart(2, '0')).join('').toUpperCase();
  }

  const BLOCKS = new Set(['P', 'DIV', 'H1', 'H2', 'H3', 'H4', 'BLOCKQUOTE', 'PRE', 'UL', 'OL', 'LI', 'TABLE', 'HR', 'SECTION', 'ARTICLE']);
  const STYLE_FOR = { H1: 'Heading1', H2: 'Heading2', H3: 'Heading3', H4: 'Heading4', BLOCKQUOTE: 'Quote', PRE: 'Code' };

  function exportDocx(root) {
    const rels = [];
    const media = [];
    const nums = [];
    let relId = 10;

    function runProps(el) {
      const cs = getComputedStyle(el);
      const props = [];
      const family = cs.fontFamily.split(',')[0].replace(/["']/g, '').trim();
      if (family && family !== 'Calibri') props.push(`<w:rFonts w:ascii="${xmlEsc(family)}" w:hAnsi="${xmlEsc(family)}" w:cs="${xmlEsc(family)}"/>`);
      if (Number(cs.fontWeight) >= 600) props.push('<w:b/>');
      if (cs.fontStyle === 'italic') props.push('<w:i/>');
      if (cs.textDecorationLine.includes('line-through')) props.push('<w:strike/>');
      const color = rgbToHex(cs.color);
      if (color && !['000000', '1D1D24', '1F1F2E'].includes(color)) props.push(`<w:color w:val="${color}"/>`);
      const size = Math.round((parseFloat(cs.fontSize) * 0.75) * 2);
      const block = el.closest('h1, h2, h3, h4, pre');
      if (size && size !== 22 && !block) props.push(`<w:sz w:val="${size}"/><w:szCs w:val="${size}"/>`);
      // Highlight: background of the nearest inline element.
      let node = el;
      while (node && node !== root && !BLOCKS.has(node.tagName)) {
        const bg = rgbToHex(getComputedStyle(node).backgroundColor);
        if (bg) {
          props.push(`<w:shd w:val="clear" w:color="auto" w:fill="${bg}"/>`);
          break;
        }
        node = node.parentElement;
      }
      if (cs.textDecorationLine.includes('underline') || el.closest('u')) props.push('<w:u w:val="single"/>');
      if (cs.verticalAlign === 'super' || el.closest('sup')) props.push('<w:vertAlign w:val="superscript"/>');
      if (cs.verticalAlign === 'sub' || el.closest('sub')) props.push('<w:vertAlign w:val="subscript"/>');
      return props.length ? `<w:rPr>${props.join('')}</w:rPr>` : '';
    }

    function imageXml(img) {
      const src = img.getAttribute('src') || '';
      const m = /^data:(image\/(\w+));base64,(.*)$/.exec(src);
      if (!m) return '';
      const ext = m[2] === 'jpeg' ? 'jpg' : m[2];
      const index = media.length + 1;
      const name = `media/image${index}.${ext}`;
      media.push([`word/${name}`, m[3], true, ext]);
      const id = `rId${relId++}`;
      rels.push(`<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${name}"/>`);
      const width = Math.round((img.width || img.naturalWidth || 300) * 9525);
      const height = Math.round((img.height || img.naturalHeight || 200) * 9525);
      return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${width}" cy="${height}"/><wp:docPr id="${index}" name="Bild ${index}"/>
<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
<pic:nvPicPr><pic:cNvPr id="${index}" name="image${index}.${ext}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${id}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${width}" cy="${height}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`;
    }

    function runs(node) {
      let out = '';
      for (const child of node.childNodes) {
        if (child.nodeType === Node.TEXT_NODE) {
          const text = child.textContent.replace(/ /g, ' ');
          if (!text) continue;
          const parts = text.split('\t');
          const props = runProps(child.parentElement);
          parts.forEach((part, i) => {
            if (i) out += `<w:r>${props}<w:tab/></w:r>`;
            if (part) out += `<w:r>${props}<w:t xml:space="preserve">${xmlEsc(part)}</w:t></w:r>`;
          });
        } else if (child.nodeType === Node.ELEMENT_NODE) {
          if (child.tagName === 'BR') out += '<w:r><w:br/></w:r>';
          else if (child.tagName === 'IMG') out += imageXml(child);
          else if (child.tagName === 'A' && child.getAttribute('href')) {
            const id = `rId${relId++}`;
            rels.push(`<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${xmlEsc(child.getAttribute('href'))}" TargetMode="External"/>`);
            out += `<w:hyperlink r:id="${id}">${runs(child)}</w:hyperlink>`;
          } else if (!BLOCKS.has(child.tagName)) out += runs(child);
        }
      }
      return out;
    }

    function paraProps(el, extra = '') {
      const cs = getComputedStyle(el);
      const props = [];
      const style = el.dataset.style === 'title' ? 'Title' : STYLE_FOR[el.tagName] || null;
      if (style) props.push(`<w:pStyle w:val="${style}"/>`);
      props.push(extra);
      const align = { center: 'center', right: 'right', end: 'right', justify: 'both' }[cs.textAlign];
      const margin = parseFloat(cs.marginLeft) || 0;
      const lineHeight = parseFloat(cs.lineHeight);
      const fontSize = parseFloat(cs.fontSize);
      if (!extra) {
        const spacing = [];
        if (lineHeight && fontSize) spacing.push(`w:line="${Math.round((lineHeight / fontSize / 1.15) * 240)}" w:lineRule="auto"`);
        spacing.push(`w:after="${Math.round((parseFloat(cs.marginBottom) || 0) * 15)}"`);
        props.push(`<w:spacing ${spacing.join(' ')}/>`);
      }
      if (margin && !extra) props.push(`<w:ind w:left="${Math.round(margin * 15)}"/>`);
      if (align) props.push(`<w:jc w:val="${align}"/>`);
      return `<w:pPr>${props.join('')}</w:pPr>`;
    }

    function list(el, level, out) {
      const ordered = el.tagName === 'OL';
      const numId = nums.length + 1;
      nums.push(ordered ? 2 : 1);
      for (const li of el.children) {
        if (li.tagName !== 'LI') continue;
        const nested = [...li.children].filter((c) => c.tagName === 'UL' || c.tagName === 'OL');
        out.push(`<w:p>${paraProps(li, `<w:numPr><w:ilvl w:val="${Math.min(8, level)}"/><w:numId w:val="${numId}"/></w:numPr>`)}${runs(li)}</w:p>`);
        nested.forEach((n) => list(n, level + 1, out));
      }
    }

    function table(el, out) {
      const rows = [...el.querySelectorAll(':scope > tbody > tr, :scope > thead > tr, :scope > tr')];
      const cols = Math.max(1, ...rows.map((r) => r.children.length));
      const width = 9000;
      const grid = Array.from({ length: cols }, () => `<w:gridCol w:w="${Math.round(width / cols)}"/>`).join('');
      const border = '<w:top w:val="single" w:sz="4" w:color="BFBFBF"/><w:left w:val="single" w:sz="4" w:color="BFBFBF"/><w:bottom w:val="single" w:sz="4" w:color="BFBFBF"/><w:right w:val="single" w:sz="4" w:color="BFBFBF"/><w:insideH w:val="single" w:sz="4" w:color="BFBFBF"/><w:insideV w:val="single" w:sz="4" w:color="BFBFBF"/>';
      out.push(`<w:tbl><w:tblPr><w:tblW w:w="${width}" w:type="dxa"/><w:tblBorders>${border}</w:tblBorders></w:tblPr><w:tblGrid>${grid}</w:tblGrid>`);
      for (const row of rows) {
        out.push('<w:tr>');
        for (const cell of row.children) {
          const bg = rgbToHex(getComputedStyle(cell).backgroundColor);
          const inner = [];
          blocks(cell, inner);
          if (!inner.length) inner.push(`<w:p>${runs(cell)}</w:p>`);
          out.push(`<w:tc><w:tcPr><w:tcW w:w="${Math.round(width / cols)}" w:type="dxa"/>${bg ? `<w:shd w:val="clear" w:color="auto" w:fill="${bg}"/>` : ''}</w:tcPr>${inner.join('')}</w:tc>`);
        }
        out.push('</w:tr>');
      }
      out.push('</w:tbl><w:p/>');
    }

    function blocks(container, out) {
      let inline = null;
      const flush = () => {
        if (inline) out.push(`<w:p>${paraProps(container)}${inline}</w:p>`);
        inline = null;
      };
      for (const child of container.childNodes) {
        if (child.nodeType === Node.ELEMENT_NODE && BLOCKS.has(child.tagName)) {
          flush();
          if (child.tagName === 'UL' || child.tagName === 'OL') list(child, 0, out);
          else if (child.tagName === 'TABLE') table(child, out);
          else if (child.tagName === 'HR') out.push('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="BFBFBF"/></w:pBdr></w:pPr></w:p>');
          else if (child.classList.contains('page-break')) out.push('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
          else if ([...child.children].some((c) => BLOCKS.has(c.tagName) && c.tagName !== 'LI')) blocks(child, out);
          else out.push(`<w:p>${paraProps(child)}${runs(child)}</w:p>`);
        } else {
          const piece = child.nodeType === Node.TEXT_NODE ? (child.textContent.trim() ? runs({ childNodes: [child] }) : '') : runs({ childNodes: [child] });
          if (piece) inline = (inline || '') + piece;
        }
      }
      flush();
    }

    const body = [];
    blocks(root, body);

    const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="${W}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
<w:body>${body.join('\n')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1417" w:bottom="1134" w:left="1417" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`;

    const lvl = (ordered) =>
      Array.from({ length: 9 }, (_, i) =>
        ordered
          ? `<w:lvl w:ilvl="${i}"><w:start w:val="1"/><w:numFmt w:val="${['decimal', 'lowerLetter', 'lowerRoman'][i % 3]}"/><w:lvlText w:val="%${i + 1}."/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${720 * (i + 1)}" w:hanging="360"/></w:pPr></w:lvl>`
          : `<w:lvl w:ilvl="${i}"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="${['•', '◦', '▪'][i % 3]}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${720 * (i + 1)}" w:hanging="360"/></w:pPr></w:lvl>`,
      ).join('');
    const numberingXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:numbering xmlns:w="${W}"><w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>${lvl(false)}</w:abstractNum><w:abstractNum w:abstractNumId="2"><w:multiLevelType w:val="hybridMultilevel"/>${lvl(true)}</w:abstractNum>
${nums.map((abs, i) => `<w:num w:numId="${i + 1}"><w:abstractNumId w:val="${abs}"/>${abs === 2 ? '<w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride>' : ''}</w:num>`).join('')}</w:numbering>`;

    const heading = (id, name, size, color = '1F1F2E') =>
      `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${name}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/><w:outlineLvl w:val="${Number(id.slice(-1)) - 1 || 0}"/></w:pPr><w:rPr><w:b/><w:color w:val="${color}"/><w:sz w:val="${size}"/><w:szCs w:val="${size}"/></w:rPr></w:style>`;
    const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="${W}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="de-DE"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="160" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:qFormat/><w:rPr><w:b/><w:sz w:val="56"/><w:szCs w:val="56"/></w:rPr></w:style>
${heading('Heading1', 'heading 1', 36)}${heading('Heading2', 'heading 2', 30)}${heading('Heading3', 'heading 3', 26)}${heading('Heading4', 'heading 4', 24)}
<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:left="720"/><w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="8B6CFF"/></w:pBdr></w:pPr><w:rPr><w:i/><w:color w:val="555566"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F2F2F5"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/><w:sz w:val="20"/></w:rPr></w:style>
</w:styles>`;

    const types = [...new Set(media.map((m) => m[3]))]
      .map((ext) => `<Default Extension="${ext}" ContentType="image/${ext === 'jpg' ? 'jpeg' : ext}"/>`)
      .join('');
    return {
      parts: [
        ['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${types}<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>`],
        ['_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`],
        ['docProps/core.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>Revulution Hub</dc:creator><dcterms:modified xsi:type="dcterms:W3CDTF">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</dcterms:modified></cp:coreProperties>`],
        ['word/_rels/document.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>${rels.join('')}</Relationships>`],
        ['word/document.xml', documentXml],
        ['word/styles.xml', stylesXml],
        ['word/numbering.xml', numberingXml],
        ...media.map(([name, data]) => [name, data, true]),
      ],
    };
  }

  /* ============================================================== IMPORT */

  const HIGHLIGHT = { yellow: '#ffff00', green: '#00ff00', cyan: '#00ffff', magenta: '#ff00ff', blue: '#0000ff', red: '#ff0000', darkBlue: '#000080', darkCyan: '#008080', darkGreen: '#008000', darkMagenta: '#800080', darkRed: '#800000', darkYellow: '#808000', darkGray: '#808080', lightGray: '#c0c0c0', black: '#000000' };

  function importDocx(doc) {
    const parser = new DOMParser();
    const xml = parser.parseFromString(doc.document, 'application/xml');
    const rels = {};
    if (doc.rels) {
      for (const rel of parser.parseFromString(doc.rels, 'application/xml').getElementsByTagName('Relationship')) {
        rels[rel.getAttribute('Id')] = rel.getAttribute('Target');
      }
    }
    const numFormats = {};
    if (doc.numbering) {
      const num = parser.parseFromString(doc.numbering, 'application/xml');
      const abstracts = {};
      for (const a of num.getElementsByTagNameNS(W, 'abstractNum')) {
        const fmt = a.getElementsByTagNameNS(W, 'numFmt')[0]?.getAttributeNS(W, 'val');
        abstracts[a.getAttributeNS(W, 'abstractNumId')] = fmt;
      }
      for (const n of num.getElementsByTagNameNS(W, 'num')) {
        const abs = n.getElementsByTagNameNS(W, 'abstractNumId')[0]?.getAttributeNS(W, 'val');
        numFormats[n.getAttributeNS(W, 'numId')] = abstracts[abs] === 'bullet' ? 'ul' : 'ol';
      }
    }
    const styleNames = {};
    if (doc.styles) {
      for (const s of parser.parseFromString(doc.styles, 'application/xml').getElementsByTagNameNS(W, 'style')) {
        const name = s.getElementsByTagNameNS(W, 'name')[0]?.getAttributeNS(W, 'val') || '';
        styleNames[s.getAttributeNS(W, 'styleId')] = name.toLowerCase();
      }
    }

    const child = (el, name) => [...el.childNodes].find((n) => n.localName === name);
    const val = (el, name) => {
      const c = el && child(el, name);
      return c ? c.getAttributeNS(W, 'val') ?? '' : null;
    };

    function run(r) {
      const props = child(r, 'rPr');
      const css = [];
      let open = '';
      let close = '';
      if (props) {
        const on = (name) => {
          const v = val(props, name);
          return v !== null && v !== '0' && v !== 'false';
        };
        if (on('b')) css.push('font-weight:700');
        if (on('i')) css.push('font-style:italic');
        const deco = [];
        if (val(props, 'u') !== null && val(props, 'u') !== 'none') deco.push('underline');
        if (on('strike')) deco.push('line-through');
        if (deco.length) css.push(`text-decoration:${deco.join(' ')}`);
        const color = val(props, 'color');
        if (color && color !== 'auto') css.push(`color:#${color}`);
        const size = val(props, 'sz');
        if (size) css.push(`font-size:${Number(size) / 2}pt`);
        const fonts = child(props, 'rFonts');
        const font = fonts?.getAttributeNS(W, 'ascii');
        if (font) css.push(`font-family:'${font}'`);
        const hl = val(props, 'highlight');
        if (hl && HIGHLIGHT[hl]) css.push(`background:${HIGHLIGHT[hl]}`);
        const shd = child(props, 'shd')?.getAttributeNS(W, 'fill');
        if (shd && shd !== 'auto') css.push(`background:#${shd}`);
        const va = val(props, 'vertAlign');
        if (va === 'superscript') (open = '<sup>'), (close = '</sup>');
        if (va === 'subscript') (open = '<sub>'), (close = '</sub>');
      }
      let html = '';
      for (const node of r.childNodes) {
        if (node.localName === 't') html += htmlEsc(node.textContent);
        else if (node.localName === 'tab') html += '\t';
        else if (node.localName === 'br') html += node.getAttributeNS(W, 'type') === 'page' ? '</p><div class="page-break" contenteditable="false"></div><p>' : '<br>';
        else if (node.localName === 'drawing' || node.localName === 'pict') {
          const blip = node.getElementsByTagNameNS('http://schemas.openxmlformats.org/drawingml/2006/main', 'blip')[0];
          const id = blip?.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'embed');
          const extent = node.getElementsByTagNameNS('http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing', 'extent')[0];
          const src = id && doc.media[rels[id]];
          if (src) {
            const w = extent ? Math.round(Number(extent.getAttribute('cx')) / 9525) : '';
            html += `<img src="${src}" ${w ? `width="${w}"` : ''} alt="">`;
          }
        }
      }
      if (!html) return '';
      return css.length ? `${open}<span style="${css.join(';')}">${html}</span>${close}` : `${open}${html}${close}`;
    }

    function inline(p) {
      let html = '';
      for (const node of p.childNodes) {
        if (node.localName === 'r') html += run(node);
        else if (node.localName === 'hyperlink') {
          const href = rels[node.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id')] || '#';
          html += `<a href="${htmlEsc(href)}">${inline(node)}</a>`;
        } else if (node.localName === 'ins' || node.localName === 'smartTag' || node.localName === 'sdt' || node.localName === 'sdtContent') html += inline(node);
      }
      return html;
    }

    function paragraph(p) {
      const props = child(p, 'pPr');
      const style = (val(props, 'pStyle') || '').toString();
      const name = styleNames[style] || style.toLowerCase();
      const jc = val(props, 'jc');
      const align = { center: 'center', right: 'right', end: 'right', both: 'justify', distribute: 'justify' }[jc];
      const body = inline(p) || '<br>';
      const attr = align ? ` style="text-align:${align}"` : '';
      const level = /heading (\d)|berschrift(\d)|^heading(\d)$/.exec(name);
      if (name === 'title' || name === 'titel') return `<h1 data-style="title"${attr}>${body}</h1>`;
      if (level) return `<h${Math.min(3, Number(level[1] || level[2] || level[3]))}${attr}>${body}</h${Math.min(3, Number(level[1] || level[2] || level[3]))}>`;
      if (/quote|zitat/.test(name)) return `<blockquote${attr}>${body}</blockquote>`;
      return `<p${attr}>${body}</p>`;
    }

    function table(tbl) {
      let html = '<table><tbody>';
      for (const tr of tbl.childNodes) {
        if (tr.localName !== 'tr') continue;
        html += '<tr>';
        for (const tc of tr.childNodes) {
          if (tc.localName !== 'tc') continue;
          const fill = child(child(tc, 'tcPr') || tc, 'shd')?.getAttributeNS(W, 'fill');
          html += `<td${fill && fill !== 'auto' ? ` style="background:#${fill}"` : ''}>${body(tc)}</td>`;
        }
        html += '</tr>';
      }
      return `${html}</tbody></table>`;
    }

    function body(container) {
      let html = '';
      let listStack = [];
      const closeLists = (depth = 0) => {
        while (listStack.length > depth) html += `</${listStack.pop()}>`;
      };
      for (const node of container.childNodes) {
        if (node.localName === 'p') {
          const numPr = child(child(node, 'pPr') || node, 'numPr');
          if (numPr) {
            const level = Number(val(numPr, 'ilvl') || 0);
            const tag = numFormats[val(numPr, 'numId')] || 'ul';
            while (listStack.length > level + 1) html += `</${listStack.pop()}>`;
            if (listStack.length === level + 1 && listStack[level] !== tag) html += `</${listStack.pop()}>`;
            while (listStack.length < level + 1) {
              html += `<${tag}>`;
              listStack.push(tag);
            }
            html += `<li>${inline(node) || '<br>'}</li>`;
            continue;
          }
          closeLists();
          html += paragraph(node);
        } else if (node.localName === 'tbl') {
          closeLists();
          html += table(node);
        } else if (node.localName === 'sdt') {
          const content = child(node, 'sdtContent');
          if (content) html += body(content);
        }
      }
      closeLists();
      return html;
    }

    const bodyEl = xml.getElementsByTagNameNS(W, 'body')[0];
    return bodyEl ? body(bodyEl) : '<p><br></p>';
  }

  window.Docx = { exportDocx, importDocx };
})();
