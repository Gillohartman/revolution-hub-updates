import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import AdmZip from "adm-zip";
import { fetchJson, download } from "./http.mjs";
import { gameDir, ensureDir } from "./paths.mjs";
import { getInstance, updateInstance, ensureInstanceDirs } from "./instances.mjs";
import { installLoader } from "./loaders.mjs";

const API = "https://api.modrinth.com/v2";

/** Where each content type lives inside an instance. */
export const CONTENT_FOLDERS = {
  mod: "mods",
  resourcepack: "resourcepacks",
  shader: "shaderpacks",
  datapack: "datapacks",
  world: "saves",
  modpack: "modpacks",
};

const LOADER_FACETS = {
  fabric: ["fabric"],
  quilt: ["quilt"],
  forge: ["forge"],
  neoforge: ["neoforge"],
};

function buildFacets({ projectType, mcVersion, loader, categories } = {}) {
  const facets = [];
  if (projectType) facets.push([`project_type:${projectType}`]);
  if (mcVersion) facets.push([`versions:${mcVersion}`]);
  // The search API exposes mod loaders as categories, not as bare facet values.
  const loaders = LOADER_FACETS[loader] || (loader && loader !== "vanilla" ? [loader] : []);
  if (loaders.length) facets.push(loaders.map((entry) => `categories:${entry}`));
  if (categories?.length) facets.push(categories.map((c) => `categories:${c}`));
  return facets;
}

export async function searchProjects({ query = "", projectType = "mod", mcVersion, loader, categories, limit = 24, offset = 0, sort = "relevance" } = {}) {
  const params = new URLSearchParams();
  params.set("query", query);
  params.set("limit", String(Math.min(100, limit)));
  params.set("offset", String(offset));
  params.set("index", sort);
  const facets = buildFacets({ projectType, mcVersion, loader, categories });
  if (facets.length) params.set("facets", JSON.stringify(facets));
  const data = await fetchJson(`${API}/search?${params.toString()}`);
  return {
    hits: (data.hits || []).map((hit) => ({
      id: hit.project_id,
      slug: hit.slug,
      title: hit.title,
      description: hit.description,
      author: hit.author,
      downloads: hit.downloads,
      followers: hit.followers,
      iconUrl: hit.icon_url,
      categories: hit.categories || [],
      versions: hit.versions || [],
      projectType: hit.project_type,
      updated: hit.date_modified,
      license: hit.license,
    })),
    total: data.total_hits || 0,
    offset: data.offset || 0,
  };
}

/** Featured/popular projects used to fill the browse page before a search. */
export async function listPopular({ projectType = "mod", mcVersion, loader, limit = 24 } = {}) {
  return searchProjects({ projectType, mcVersion, loader, limit, sort: "downloads" });
}

export async function getProject(slugOrId) {
  return fetchJson(`${API}/project/${encodeURIComponent(slugOrId)}`);
}

export async function getProjectVersions(slugOrId, { mcVersion, loader } = {}) {
  const params = new URLSearchParams();
  if (mcVersion) params.set("game_versions", JSON.stringify([mcVersion]));
  const data = await fetchJson(`${API}/project/${encodeURIComponent(slugOrId)}/version?${params.toString()}`);
  if (!loader) return data;
  const wanted = LOADER_FACETS[loader] || [loader];
  return data.filter((version) => (version.loaders || []).some((l) => wanted.includes(l)));
}

export function pickPrimaryFile(version) {
  const files = version?.files || [];
  return files.find((f) => f.primary) || files[0] || null;
}

export function contentFolderFor(projectType) {
  return CONTENT_FOLDERS[projectType] || "mods";
}

function contentKey(entry) {
  return entry.projectId || entry.id || entry.fileName || entry.name;
}

/** Read the instance's recorded content list, refreshing it from disk. */
export async function listContent(instanceId, { type } = {}) {
  const instance = await getInstance(instanceId);
  const root = gameDir(instanceId);
  const entries = [];
  for (const entry of instance.content || []) {
    if (type && entry.type !== type) continue;
    const folder = contentFolderFor(entry.type);
    const file = path.join(root, folder, entry.fileName);
    const disabledFile = `${file}.disabled`;
    const enabled = fs.existsSync(file);
    const exists = enabled || fs.existsSync(disabledFile);
    entries.push({ ...entry, enabled, exists, size: exists ? safeSize(enabled ? file : disabledFile) : 0 });
  }
  return entries;
}

function safeSize(file) {
  try {
    return fs.statSync(file).size;
  } catch {
    return 0;
  }
}

/** Scan the instance folders for files the launcher did not install (manual drops). */
export async function scanUntracked(instanceId) {
  const instance = await getInstance(instanceId);
  const root = gameDir(instanceId);
  const tracked = new Set((instance.content || []).map((entry) => `${entry.type}:${entry.fileName}`));
  const found = [];
  for (const [type, folder] of Object.entries(CONTENT_FOLDERS)) {
    if (type === "modpack") continue;
    const dir = path.join(root, folder);
    let files = [];
    try {
      files = await fsp.readdir(dir);
    } catch {
      continue;
    }
    for (const file of files) {
      const base = file.replace(/\.disabled$/, "");
      if (tracked.has(`${type}:${base}`)) continue;
      if (!/\.(jar|zip|mcpack|mcaddon)$/i.test(base)) continue;
      found.push({ type, fileName: base, enabled: !file.endsWith(".disabled"), size: safeSize(path.join(dir, file)), manual: true, name: base.replace(/\.(jar|zip)$/i, "") });
    }
  }
  return found;
}

/**
 * Install a Modrinth project version into an instance.
 * `version` is either a version object from getProjectVersions or its id.
 */
export async function installContent({ instanceId, project, version, onProgress = () => {} }) {
  const type = project?.project_type || project?.projectType || "mod";
  const folder = contentFolderFor(type);
  let versionData = version;
  if (typeof version === "string") {
    versionData = await fetchJson(`${API}/version/${encodeURIComponent(version)}`);
  }
  const file = pickPrimaryFile(versionData);
  if (!file) throw new Error("This version has no downloadable files.");

  const instance = await getInstance(instanceId);
  const targetDir = ensureDir(path.join(gameDir(instanceId), folder));
  const fileName = path.basename(file.filename);
  const dest = path.join(targetDir, fileName);

  onProgress({ phase: "content", message: `Downloading ${fileName}`, done: 0, total: 1 });
  await download(file.url, dest, { expectedSha1: file.hashes?.sha1, size: file.size });
  onProgress({ phase: "content", message: `Installed ${fileName}`, done: 1, total: 1 });

  const entry = {
    id: `${versionData.id}`,
    projectId: versionData.project_id || project?.id || project?.project_id,
    versionId: versionData.id,
    name: project?.title || versionData.name || fileName,
    slug: project?.slug,
    type,
    fileName,
    versionNumber: versionData.version_number,
    gameVersions: versionData.game_versions || [],
    loaders: versionData.loaders || [],
    dependencies: versionData.dependencies || [],
    installedAt: Date.now(),
    source: "modrinth",
    iconUrl: project?.icon_url || project?.iconUrl || "",
  };

  const content = [...(instance.content || []).filter((item) => contentKey(item) !== contentKey(entry)), entry];
  await updateInstance(instanceId, { content });

  // Fabric/Quilt mods frequently need Fabric API; surface it rather than silently adding it.
  return { entry, instance: await getInstance(instanceId) };
}

export async function setContentEnabled(instanceId, entryId, enabled) {
  const instance = await getInstance(instanceId);
  const entry = (instance.content || []).find((item) => contentKey(item) === entryId);
  if (!entry) throw new Error("Content entry not found");
  const folder = path.join(gameDir(instanceId), contentFolderFor(entry.type));
  const active = path.join(folder, entry.fileName);
  const disabled = `${active}.disabled`;
  if (enabled && fs.existsSync(disabled)) await fsp.rename(disabled, active);
  if (!enabled && fs.existsSync(active)) await fsp.rename(active, disabled);
  return listContent(instanceId);
}

export async function removeContent(instanceId, entryId, { deleteFile = true } = {}) {
  const instance = await getInstance(instanceId);
  const entry = (instance.content || []).find((item) => contentKey(item) === entryId);
  if (!entry) throw new Error("Content entry not found");
  if (deleteFile) {
    const base = path.join(gameDir(instanceId), contentFolderFor(entry.type), entry.fileName);
    fs.rmSync(base, { force: true });
    fs.rmSync(`${base}.disabled`, { force: true });
  }
  const content = (instance.content || []).filter((item) => contentKey(item) !== entryId);
  await updateInstance(instanceId, { content });
  return listContent(instanceId);
}

export { contentKey };

/* --------------------------------------------------------------- modpacks */

/**
 * Install a Modrinth `.mrpack` into a brand new instance: resolves the loader,
 * downloads every required file, and unpacks the bundled overrides.
 */
export async function installModpack({ mrpackPath, name, onProgress = () => {}, javaPath }) {
  const zip = new AdmZip(mrpackPath);
  const indexEntry = zip.getEntry("modrinth.index.json");
  if (!indexEntry) throw new Error("This file is not a Modrinth modpack (.mrpack).");
  const index = JSON.parse(indexEntry.getData().toString("utf8"));

  const mcVersion = index.dependencies?.minecraft;
  const loaderType = index.dependencies?.fabric-loader ? "fabric"
    : index.dependencies?.quilt-loader ? "quilt"
    : index.dependencies?.neoforge ? "neoforge"
    : index.dependencies?.forge ? "forge"
    : "vanilla";
  const loaderVersion = index.dependencies?.[`${loaderType}-loader`] || index.dependencies?.[loaderType] || "";

  onProgress({ phase: "modpack", message: `Installing ${index.name || name}`, done: 0, total: index.files?.length || 0 });

  const { createInstance, updateInstance: patchInstance } = await import("./instances.mjs");
  const instance = await createInstance({
    name: name || index.name || "Modpack",
    mcVersion,
    versionId: mcVersion,
    loader: { type: loaderType, version: loaderVersion },
    icon: "📦",
  });

  if (loaderType !== "vanilla" && loaderVersion) {
    const result = await installLoader({ mcVersion, type: loaderType, loaderVersion, javaPath, onProgress });
    await patchInstance(instance.id, { versionId: result.versionId });
  }

  const root = await ensureInstanceDirs(instance.id);
  const content = [];
  const files = (index.files || []).filter((file) => file.env?.client !== "unsupported");
  let done = 0;
  for (const file of files) {
    const relative = String(file.path || "").replace(/\\/g, "/");
    if (relative.includes("..")) continue;
    const dest = path.join(root, relative);
    if (!dest.startsWith(root)) continue;
    const url = (file.downloads || [])[0];
    if (!url) continue;
    try {
      await download(url, dest, { expectedSha1: file.hashes?.sha1, size: file.fileSize });
      content.push({
        id: path.basename(relative),
        projectId: null,
        versionId: null,
        name: path.basename(relative).replace(/\.(jar|zip)$/i, ""),
        type: relative.startsWith("shaderpacks/") ? "shader"
          : relative.startsWith("resourcepacks/") ? "resourcepack"
          : relative.startsWith("datapacks/") ? "datapack"
          : relative.startsWith("saves/") ? "world"
          : "mod",
        fileName: path.basename(relative),
        source: "modpack",
        installedAt: Date.now(),
      });
    } catch (err) {
      onProgress({ phase: "modpack", message: `Skipped ${path.basename(relative)}: ${err.message}`, done, total: files.length });
    }
    done++;
    onProgress({ phase: "modpack", message: `Downloaded ${done}/${files.length} files`, done, total: files.length });
  }

  // overrides/ (and the legacy client-overrides/) replace files in the game dir.
  for (const prefix of ["overrides", "client-overrides"]) {
    for (const entry of zip.getEntries()) {
      const name_ = entry.entryName.replace(/\\/g, "/");
      if (!name_.startsWith(`${prefix}/`) || entry.isDirectory) continue;
      const rel = name_.slice(prefix.length + 1);
      const dest = path.join(root, rel);
      if (!dest.startsWith(root)) continue;
      ensureDir(path.dirname(dest));
      await fsp.writeFile(dest, entry.getData());
    }
  }

  await patchInstance(instance.id, { content });
  onProgress({ phase: "done", message: `${index.name || name} is ready`, done: done, total: files.length });
  return getInstance(instance.id);
}

/** Export an instance as a shareable Modrinth-style `.mrpack`. */
export async function exportModpack({ instanceId, destFile, onProgress = () => {} }) {
  const instance = await getInstance(instanceId);
  const zip = new AdmZip();
  const dependencies = { minecraft: instance.mcVersion };
  if (instance.loader?.type === "fabric") dependencies["fabric-loader"] = instance.loader.version;
  if (instance.loader?.type === "quilt") dependencies["quilt-loader"] = instance.loader.version;
  if (instance.loader?.type === "forge") dependencies.forge = instance.loader.version;
  if (instance.loader?.type === "neoforge") dependencies.neoforge = instance.loader.version;

  const files = [];
  for (const entry of instance.content || []) {
    if (entry.source !== "modrinth" || !entry.versionId) continue;
    try {
      const version = await fetchJson(`${API}/version/${entry.versionId}`);
      const file = pickPrimaryFile(version);
      if (!file) continue;
      files.push({
        path: `${contentFolderFor(entry.type)}/${file.filename}`,
        hashes: { sha1: file.hashes.sha1, sha512: file.hashes.sha512 },
        env: { client: "required", server: "optional" },
        downloads: [file.url],
        fileSize: file.size,
      });
    } catch { /* skip unresolvable entries */ }
  }

  zip.addFile("modrinth.index.json", Buffer.from(JSON.stringify({
    formatVersion: 1,
    game: "minecraft",
    versionId: "1.0.0",
    name: instance.name,
    summary: instance.notes || `Exported from Revolution`,
    files,
    dependencies,
  }, null, 2)));

  const root = gameDir(instanceId);
  const tracked = new Set(files.map((f) => f.path.split("/").pop()));
  for (const [type, folder] of Object.entries(CONTENT_FOLDERS)) {
    if (type === "modpack") continue;
    const dir = path.join(root, folder);
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      if (entry.isDirectory()) continue;
      if (tracked.has(entry.name.replace(/\.disabled$/, ""))) continue;
      if (!/\.(jar|zip)$/i.test(entry.name)) continue;
      zip.addFile(`overrides/${folder}/${entry.name}`, fs.readFileSync(path.join(dir, entry.name)));
    }
  }
  zip.addFile("overrides/instance-notes.txt", Buffer.from(`${instance.name}\nExported by Revolution on ${new Date().toISOString()}\n`, "utf8"));
  await zip.writeZipPromise(destFile);
  onProgress({ phase: "done", message: "Modpack exported", done: 1, total: 1 });
  return { file: destFile, files: files.length };
}
