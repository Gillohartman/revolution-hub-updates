'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('docs', {
  recents: () => ipcRenderer.invoke('recents'),
  open: (file) => ipcRenderer.invoke('open', file),
  saveAs: (name, format) => ipcRenderer.invoke('saveAs', { name, format }),
  write: (payload) => ipcRenderer.invoke('write', payload),
  pdf: (name) => ipcRenderer.invoke('pdf', name),
  print: () => ipcRenderer.invoke('print'),
  image: () => ipcRenderer.invoke('image'),
  screenshots: () => ipcRenderer.invoke('screenshots'),
  screenshotData: (file) => ipcRenderer.invoke('screenshot:data', file),
  reveal: (file) => ipcRenderer.invoke('reveal', file),
  saveDraft: (draft) => ipcRenderer.invoke('draft:save', draft),
  loadDraft: () => ipcRenderer.invoke('draft:load'),
});
