'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const on = (channel, callback) => {
  const listener = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
};

contextBridge.exposeInMainWorld('sysmon', {
  info: () => ipcRenderer.invoke('info'),
  disks: () => ipcRenderer.invoke('disks'),
  watchProcesses: (on) => ipcRenderer.invoke('procs:watch', on),
  kill: (pid) => ipcRenderer.invoke('kill', pid),
  locate: (pid) => ipcRenderer.invoke('proc:locate', pid),
  startup: () => ipcRenderer.invoke('startup:list'),
  setStartup: (entry) => ipcRenderer.invoke('startup:set', entry),
  revealStartup: (entry) => ipcRenderer.invoke('startup:reveal', entry),
  taskManager: () => ipcRenderer.invoke('taskmgr'),
  onSample: (callback) => on('sample', callback),
  onProcesses: (callback) => on('procs', callback),
  onVisibility: (callback) => on('hub:visibility', callback),
});
