'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('aiApp', {
  status: () => ipcRenderer.invoke('status'),
  download: () => ipcRenderer.invoke('download'),
  start: () => ipcRenderer.invoke('start'),
  pull: (m) => ipcRenderer.invoke('pull', m),
  chat: (q) => ipcRenderer.invoke('chat', q),
  stop: () => ipcRenderer.invoke('stop'),
  load: () => ipcRenderer.invoke('load'),
  save: (d) => ipcRenderer.invoke('save', d),
  on: (ch, cb) => ipcRenderer.on(ch, (_e, v) => cb(v)),
});
