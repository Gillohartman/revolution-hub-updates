'use strict';

/*
 * Video-Schnitt: a small multi-track editor.
 *
 * Model
 *   media  – imported files (probe info), keyed by id
 *   tracks – top to bottom: Text, Video 2 (overlay), Video 1, Ton 1, Ton 2, Sprache
 *   clips  – { id, track, media, start, in, out, volume, muted, layout } or text clips
 *            { id, track, kind: 'text', start, duration, text, size, color, position, box }
 * Times are seconds; `start` is the position on the timeline, in/out the range of the source.
 * Clips on one track never overlap: inserting or moving pushes later clips back.
 */

const $ = (selector) => document.querySelector(selector);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
const api = window.cutter;
const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
const uid = () => Math.random().toString(36).slice(2, 10);
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const IMAGE_MAX = 3600;

const DEFAULT_TRACKS = () => [
  { id: 't1', kind: 'text', name: 'Text' },
  { id: 'v2', kind: 'video', name: 'Video 2' },
  { id: 'v1', kind: 'video', name: 'Video 1' },
  { id: 'a1', kind: 'audio', name: 'Ton 1' },
  { id: 'a2', kind: 'audio', name: 'Musik' },
  { id: 'mic', kind: 'audio', name: 'Sprache' },
];
const TRACK_COLOR = { t1: '#d79b2b', v2: '#8b6cff', v1: '#6a5cff', a1: '#2fb38f', a2: '#38bdf8', mic: '#ff5d6c' };

const state = {
  project: { name: '', media: {}, tracks: DEFAULT_TRACKS(), clips: [] },
  selected: null,
  time: 0,
  playing: false,
  pps: 40, // pixels per second
  snap: true,
  history: [],
  future: [],
  recording: null,
  rate: 1, // Vorschau-Tempo (J/L)
};
const runtime = {
  thumbs: new Map(), // mediaId → [dataUrl…]
  peaks: new Map(), // mediaId → { peaks, seconds }
  urls: new Map(), // mediaId → playable URL (file or proxy)
  gaming: [],
};

/* ------------------------------------------------------------------ helpers */

function toast(message, kind = '', action) {
  document.querySelector('.toast')?.remove();
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = String(message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  if (action) {
    const button = document.createElement('button');
    button.className = 'btn small';
    button.style.marginLeft = '12px';
    button.textContent = action.label;
    button.onclick = () => {
      action.run();
      el.remove();
    };
    el.appendChild(button);
  }
  document.body.appendChild(el);
  setTimeout(() => el.remove(), kind === 'error' ? 7000 : action ? 6000 : 3200);
}

function clock(seconds, fine = true) {
  if (!Number.isFinite(seconds)) seconds = 0;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  const sec = fine ? s.toFixed(2).padStart(5, '0') : String(Math.floor(s)).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${sec}` : `${m}:${sec}`;
}

const P = () => state.project;
const trackOf = (id) => P().tracks.find((t) => t.id === id);
const clipById = (id) => P().clips.find((c) => c.id === id);
const mediaOf = (clip) => P().media[clip?.media];
const speedOf = (c) => clamp(Number(c?.speed) || 1, 0.1, 8);
const lengthOf = (c) => (c.kind === 'text' ? c.duration : (c.out - c.in) / speedOf(c));
const endOf = (c) => c.start + lengthOf(c);
const total = () => P().clips.reduce((max, c) => Math.max(max, endOf(c)), 0);
const maxOut = (c) => (mediaOf(c)?.kind === 'image' ? IMAGE_MAX : mediaOf(c)?.duration ?? 0);

function busy(text) {
  $('#busy').hidden = !text;
  $('#busy-text').textContent = text || '';
}

/* ------------------------------------------------------------ history/save */

function snapshot() {
  state.history.push(JSON.stringify({ tracks: P().tracks, clips: P().clips }));
  if (state.history.length > 150) state.history.shift();
  state.future = [];
}

function restore(from, to) {
  const json = from.pop();
  if (!json) return;
  to.push(JSON.stringify({ tracks: P().tracks, clips: P().clips }));
  const data = JSON.parse(json);
  P().tracks = data.tracks;
  P().clips = data.clips;
  if (state.selected && !clipById(state.selected)) state.selected = null;
  changed();
}

let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => api.saveProject(P()).catch(() => {}), 700);
}

/** Every edit ends here: redraw, persist, keep the preview in sync. */
function changed({ keepInspector = false } = {}) {
  renderTimeline();
  if (!keepInspector) renderInspector();
  renderBin();
  updateChrome();
  sync(true);
  save();
}

/* --------------------------------------------------------------- media in */

const PLAYABLE_VIDEO = ['h264', 'vp8', 'vp9', 'av1'];
const PLAYABLE_AUDIO = ['aac', 'mp3', 'opus', 'vorbis', 'flac', 'pcm_s16le', 'pcm_s24le', 'pcm_f32le', 'mp3float'];

async function playableUrl(id) {
  if (runtime.urls.has(id)) return runtime.urls.get(id);
  const m = P().media[id];
  let url = fileUrl(m.file);
  const ext = m.file.split('.').pop().toLowerCase();
  const videoOk = !m.video || m.kind === 'image' || (PLAYABLE_VIDEO.includes(m.video.codec) && ['mp4', 'm4v', 'mov', 'webm', 'mkv'].includes(ext));
  const audioOk = !m.audio || PLAYABLE_AUDIO.some((c) => m.audio.codec.startsWith(c)) || m.kind === 'video';
  if (!videoOk || !audioOk) {
    busy(`Vorschau wird vorbereitet … ${m.name}`);
    try {
      url = fileUrl(await api.proxy(m));
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      busy('');
    }
  }
  runtime.urls.set(id, url);
  return url;
}

/** Adds a probed file to the media list (deduplicated by path) and returns its id. */
function addMedia(info) {
  const existing = Object.entries(P().media).find(([, m]) => m.file === info.file);
  if (existing) return existing[0];
  const id = uid();
  P().media[id] = info;
  prepareMedia(id);
  return id;
}

function prepareMedia(id) {
  const m = P().media[id];
  if (!m) return;
  if (m.audio && !runtime.peaks.has(id)) {
    runtime.peaks.set(id, { peaks: [], seconds: 0 });
    api.waveform(m.file).then((data) => {
      runtime.peaks.set(id, data);
      renderTimeline();
    });
  }
  if (!runtime.thumbs.has(id)) {
    runtime.thumbs.set(id, []);
    if (m.kind === 'image') runtime.thumbs.set(id, [fileUrl(m.file)]);
    else if (m.kind === 'video') makeThumbs(id);
  }
}

/** Ten frames per video for the clip filmstrip, grabbed from a hidden video element. */
async function makeThumbs(id) {
  const m = P().media[id];
  const gaming = runtime.gaming.find((g) => g.file === m.file);
  if (gaming?.thumb) runtime.thumbs.set(id, [fileUrl(gaming.thumb)]);
  const url = await playableUrl(id);
  const probe = document.createElement('video');
  probe.muted = true;
  probe.preload = 'auto';
  probe.src = url;
  try {
    await new Promise((resolve, reject) => {
      probe.onloadeddata = resolve;
      probe.onerror = reject;
      setTimeout(reject, 15000);
    });
    const canvas = document.createElement('canvas');
    canvas.height = 54;
    canvas.width = Math.round((54 * (probe.videoWidth || 16)) / (probe.videoHeight || 9));
    const g = canvas.getContext('2d');
    const list = [];
    for (let i = 0; i < 10; i += 1) {
      probe.currentTime = Math.min(m.duration - 0.05, (m.duration * (i + 0.5)) / 10);
      await new Promise((resolve) => {
        probe.onseeked = resolve;
        setTimeout(resolve, 2500);
      });
      g.drawImage(probe, 0, 0, canvas.width, canvas.height);
      list.push(canvas.toDataURL('image/jpeg', 0.7));
    }
    runtime.thumbs.set(id, list);
    renderTimeline();
    renderBin();
  } catch {
    /* no thumbnails for this file */
  } finally {
    probe.removeAttribute('src');
    probe.load();
  }
}

async function importFiles(paths, { at, track, gaming } = {}) {
  const ids = [];
  for (const file of paths) {
    try {
      busy(`Wird gelesen … ${file.split(/[\\/]/).pop()}`);
      ids.push(addMedia(await api.probe(file)));
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      busy('');
    }
  }
  if (!ids.length) return;
  snapshot();
  let cursor = at;
  for (const id of ids) {
    const clip = placeMedia(id, { at: cursor, track });
    cursor = endOf(clip);
    // Gaming-Clip? Facecam + Tasten übernehmen (liegt als .json daneben)
    if (P().media[id].kind === 'video') await attachGaming(clip, P().media[id].file);
  }
  changed();
  if (P().clips.some((c) => c.gaming && ids.includes(c.media))) toast('Gaming-Clip: Facecam und Tasten sind dabei – in der Vorschau ziehen/scrollen zum Anpassen.');
}

/** Puts media on the timeline: videos/images on Video 1, sound on Ton 1 (unless told otherwise). */
function placeMedia(id, { at, track } = {}) {
  const m = P().media[id];
  const kind = m.kind === 'audio' ? 'audio' : 'video';
  const target = track && trackOf(track)?.kind === kind ? track : kind === 'audio' ? 'a1' : 'v1';
  const start = at ?? P().clips.filter((c) => c.track === target).reduce((max, c) => Math.max(max, endOf(c)), 0);
  const clip = { id: uid(), track: target, media: id, start, in: 0, out: m.duration, volume: 1, muted: false, layout: 'full' };
  P().clips.push(clip);
  resolveOverlaps(clip);
  state.selected = clip.id;
  return clip;
}

/* ------------------------------------------------------------- edit model */

/** Keeps a track free of overlaps: clips after `clip` are pushed back to make room. */
function resolveOverlaps(clip) {
  const same = P().clips.filter((c) => c.track === clip.track && c.id !== clip.id).sort((a, b) => a.start - b.start);
  // A clip that lands inside another starts after it.
  for (const other of same) {
    if (clip.start > other.start && clip.start < endOf(other) - 0.001) clip.start = endOf(other);
  }
  let edge = endOf(clip);
  for (const other of same) {
    if (endOf(other) <= clip.start + 0.001) continue;
    if (other.start < edge - 0.001) {
      other.start = edge;
      edge = endOf(other);
    }
  }
}

function split() {
  const clip = clipById(state.selected) || P().clips.find((c) => c.start < state.time && endOf(c) > state.time && trackOf(c.track).kind === 'video');
  if (!clip) return toast('Einen Clip unter dem Abspielkopf auswählen.');
  const t = state.time;
  if (t <= clip.start + 0.05 || t >= endOf(clip) - 0.05) return toast('Der Abspielkopf muss innerhalb des Clips stehen.');
  snapshot();
  const second = { ...clip, id: uid(), start: t };
  if (clip.kind === 'text') {
    second.duration = endOf(clip) - t;
    clip.duration = t - clip.start;
  } else {
    const cut = clip.in + (t - clip.start) * speedOf(clip);
    second.in = cut;
    clip.out = cut;
  }
  P().clips.push(second);
  state.selected = second.id;
  changed();
}

function removeSelected() {
  const clip = clipById(state.selected);
  if (!clip) return;
  snapshot();
  P().clips = P().clips.filter((c) => c.id !== clip.id);
  state.selected = null;
  changed();
}

function duplicateSelected() {
  const clip = clipById(state.selected);
  if (!clip) return;
  snapshot();
  const copy = JSON.parse(JSON.stringify(clip));
  copy.id = uid();
  copy.start = endOf(clip);
  P().clips.push(copy);
  resolveOverlaps(copy);
  state.selected = copy.id;
  changed();
}

let clipboard = null;
function copySelected() {
  const clip = clipById(state.selected);
  if (!clip) return;
  clipboard = JSON.parse(JSON.stringify(clip));
  toast('Clip kopiert – mit Strg+V am Abspielkopf einfügen.');
}
function pasteClip() {
  if (!clipboard) return;
  snapshot();
  const copy = { ...JSON.parse(JSON.stringify(clipboard)), id: uid(), start: state.time };
  P().clips.push(copy);
  resolveOverlaps(copy);
  state.selected = copy.id;
  changed();
}

/** Entfernen und die Lücke schließen: alles danach auf der Spur rückt nach. */
function rippleDelete() {
  const clip = clipById(state.selected);
  if (!clip) return;
  snapshot();
  const gap = lengthOf(clip);
  const end = endOf(clip);
  P().clips = P().clips.filter((c) => c.id !== clip.id);
  for (const c of P().clips) if (c.track === clip.track && c.start >= end - 0.001) c.start = Math.max(0, c.start - gap);
  state.selected = null;
  changed();
}

function toggleMarker() {
  snapshot();
  const list = (P().markers ||= []);
  const near = list.findIndex((m) => Math.abs(m - state.time) < 0.15);
  if (near >= 0) list.splice(near, 1);
  else list.push(Math.round(state.time * 100) / 100);
  list.sort((a, b) => a - b);
  changed();
}
function jumpMarker(dir) {
  const list = P().markers || [];
  const next = dir > 0 ? list.find((m) => m > state.time + 0.02) : [...list].reverse().find((m) => m < state.time - 0.02);
  if (next !== undefined) seek(next);
}

async function exportFrame() {
  if (!P().clips.length) return;
  pause();
  busy('Standbild wird gespeichert …');
  try {
    const project = await withKeyFrames(P(), Number($('#height')?.value) || 1080, 30);
    const out = await api.frame({ project, time: state.time, height: 1080 });
    if (out) toast('Standbild gespeichert.', '', { label: 'Im Ordner zeigen', run: () => api.reveal(out) });
  } catch (error) {
    toast(error.message, 'error');
  } finally {
    busy('');
  }
}

/**
 * Tasten-Overlay für den Export: je Gaming-Clip eine Folge von PNG-Bildern
 * (nur bei Änderungen ein neues Bild) → ffmpeg legt sie über das Video.
 */
async function withKeyFrames(project, height, fps) {
  const copy = JSON.parse(JSON.stringify(project));
  const H = Math.min(1080, height);
  const W = Math.round((H * 16) / 9);
  const cv = document.createElement('canvas');
  cv.width = W;
  cv.height = H;
  const ctx = cv.getContext('2d');
  for (const c of copy.clips) {
    const g = c.gaming;
    if (!g) continue;
    if (g.cam && !g.cam.on) g.cam = null;
    if (!g.showKeys || !g.keys?.length || !window.KeysOverlay) continue;
    const real = clipById(c.id) || c;
    const len = lengthOf(real);
    const step = 1 / Math.min(30, fps);
    const frames = [];
    let lastKey = null;
    for (let t = 0; t < len; t += step) {
      const offset = keysOffsetAt(real, real.start + t);
      const lit = offset >= 0 ? window.KeysOverlay.stateAt(g.keys, offset) : null;
      const key = lit ? [...lit].sort().join(',') : '-';
      if (key === lastKey) {
        frames[frames.length - 1].d += step;
        continue;
      }
      lastKey = key;
      ctx.clearRect(0, 0, W, H);
      if (lit) window.KeysOverlay.draw(ctx, W, H, lit, { controller: g.controller !== false, scale: g.keysScale || 1, position: g.keysPos || null });
      frames.push({ png: cv.toDataURL('image/png'), d: step });
    }
    if (frames.length) g.keysList = await api.keyFrames(frames);
  }
  return copy;
}

function addText() {
  snapshot();
  const clip = { id: uid(), track: 't1', kind: 'text', start: state.time, duration: 3, text: 'Dein Titel', size: 72, color: '#ffffff', position: 'bottom', box: true };
  P().clips.push(clip);
  resolveOverlaps(clip);
  state.selected = clip.id;
  changed();
  setTimeout(() => $('#prop-text')?.select(), 30);
}

/* ---------------------------------------------------------------- preview */

const els = {
  v1: { video: $('#vid-v1'), img: $('#img-v1') },
  v2: { video: $('#vid-v2'), img: $('#img-v2') },
};
const audioEls = {};
for (const t of ['a1', 'a2', 'mic']) {
  const el = document.createElement('audio');
  el.preload = 'auto';
  document.body.appendChild(el);
  audioEls[t] = el;
}

const activeAt = (trackId, t) => P().clips.find((c) => c.track === trackId && t >= c.start && t < endOf(c));

/** Points a media element at the right file and position; seeks only when it drifted. */
async function drive(el, clip, t, force) {
  const url = await playableUrl(clip.media);
  const wanted = clip.in + (t - clip.start) * speedOf(clip);
  const rate = speedOf(clip) * (state.rate || 1);
  if (Math.abs(el.playbackRate - rate) > 0.001) el.playbackRate = clamp(rate, 0.0625, 16);
  if (el.dataset.src !== url) {
    el.dataset.src = url;
    el.src = url;
    await new Promise((resolve) => {
      el.onloadedmetadata = resolve;
      el.onerror = resolve;
      setTimeout(resolve, 4000);
    });
    el.currentTime = wanted;
  } else if (force || Math.abs(el.currentTime - wanted) > (state.playing ? 0.3 : 0.04)) {
    el.currentTime = wanted;
  }
  if (state.playing && el.paused) el.play().catch(() => {});
  if (!state.playing && !el.paused) el.pause();
}

function stopEl(el) {
  if (!el.paused) el.pause();
}

function sync(force = false) {
  const t = state.time;
  const recordingMute = Boolean(state.recording);
  for (const id of ['v1', 'v2']) {
    const track = trackOf(id);
    const { video, img } = els[id];
    const clip = track.hidden ? null : activeAt(id, t);
    const m = mediaOf(clip);
    const pip = clip?.layout === 'pip';
    video.classList.toggle('pip', pip);
    img.classList.toggle('pip', pip);
    if (clip && m.kind === 'image') {
      stopEl(video);
      video.classList.remove('on');
      const src = fileUrl(m.file);
      if (img.dataset.src !== src) {
        img.dataset.src = src;
        img.src = src;
      }
      img.hidden = false;
      img.classList.add('on');
      applyLook(img, clip, t);
    } else if (clip) {
      applyLook(video, clip, t);
      img.classList.remove('on');
      video.classList.add('on');
      video.muted = recordingMute || track.muted || clip.muted;
      video.volume = clamp((clip.volume ?? 1) * (opacityAt(clip, t) > 0 ? Math.min(1, opacityAt(clip, t) / clamp(Number(clip.opacity ?? 1), 0.01, 1)) : 0), 0, 1);
      drive(video, clip, t, force);
    } else {
      video.classList.remove('on');
      img.classList.remove('on');
      stopEl(video);
    }
  }
  for (const id of ['a1', 'a2', 'mic']) {
    const track = trackOf(id);
    const el = audioEls[id];
    const clip = activeAt(id, t);
    if (!clip || track.muted) {
      stopEl(el);
      continue;
    }
    el.muted = recordingMute || clip.muted;
    el.volume = clamp((clip.volume ?? 1) * opacityAt(clip, t), 0, 1);
    drive(el, clip, t, force);
  }
  renderTitles(t);
  renderGaming(t);
  positionPlayhead();
}

/* ------------------------------------------------- look: transform & effects */

const EFFECTS = [['', 'Keiner'], ['bw', 'S/W'], ['sepia', 'Sepia'], ['negative', 'Negativ'], ['vintage', 'Vintage'], ['vignette', 'Vignette'], ['grain', 'Körnung'], ['pixel', 'Pixel'], ['glitch', 'Glitch'], ['edge', 'Kanten / Comic'], ['posterize', 'Poster'], ['thermal', 'Wärmebild'], ['cyber', 'Cyberpunk'], ['sunset', 'Sonnenuntergang'], ['dream', 'Traum (weich)'], ['crush', 'Hart & dunkel']];
const PRESETS = {
  none: {},
  cinema: { contrast: 1.15, saturation: 0.85, effect: 'vignette' },
  vivid: { contrast: 1.1, saturation: 1.45, brightness: 0.03 },
  warm: { hue: -12, saturation: 1.15, brightness: 0.02 },
  cold: { hue: 14, saturation: 0.9 },
  noir: { contrast: 1.35, effect: 'bw' },
  retro: { effect: 'vintage', saturation: 0.8 },
  cyber: { effect: 'cyber', contrast: 1.12, saturation: 1.25 },
  sunset: { effect: 'sunset', saturation: 1.1 },
  faded: { contrast: 0.85, saturation: 0.7, brightness: 0.05, gamma: 1.1 },
  dream: { effect: 'dream', brightness: 0.04 },
  action: { effect: 'crush', sharpen: 1, saturation: 1.15 },
};
const LOOK_KEYS = ['brightness', 'contrast', 'saturation', 'gamma', 'hue', 'blur', 'sharpen', 'effect'];

/** Deckkraft mit Ein-/Ausblenden zur Zeit t. */
function opacityAt(clip, t) {
  const len = lengthOf(clip);
  let a = clamp(Number(clip.opacity ?? 1), 0, 1);
  const fi = Number(clip.fadeIn) || 0;
  const fo = Number(clip.fadeOut) || 0;
  if (fi > 0) a *= clamp((t - clip.start) / fi, 0, 1);
  if (fo > 0) a *= clamp((clip.start + len - t) / fo, 0, 1);
  return a;
}

function applyLook(el, clip, t) {
  const sc = Number(clip.scale) || 1;
  const tr = [];
  if (clip.x || clip.y) tr.push(`translate(${(Number(clip.x) || 0) * 100}%, ${(Number(clip.y) || 0) * 100}%)`);
  if (sc !== 1) tr.push(`scale(${sc})`);
  if (clip.rotation) tr.push(`rotate(${clip.rotation}deg)`);
  if (clip.flipH || clip.flipV) tr.push(`scale(${clip.flipH ? -1 : 1}, ${clip.flipV ? -1 : 1})`);
  el.style.transform = tr.join(' ');
  const f = [];
  if (clip.brightness) f.push(`brightness(${1 + Number(clip.brightness)})`);
  if ((clip.contrast ?? 1) !== 1) f.push(`contrast(${clip.contrast})`);
  if ((clip.saturation ?? 1) !== 1) f.push(`saturate(${clip.saturation})`);
  if (clip.hue) f.push(`hue-rotate(${clip.hue}deg)`);
  if (clip.blur) f.push(`blur(${Number(clip.blur) * 0.15}cqh)`);
  const fx = { bw: 'grayscale(1)', sepia: 'sepia(1)', negative: 'invert(1)', vintage: 'sepia(.45) contrast(1.1) saturate(.8)', grain: 'contrast(1.08)', glitch: 'saturate(1.6) hue-rotate(8deg)', pixel: 'contrast(1.05)', edge: 'grayscale(1) contrast(3) invert(1)', posterize: 'contrast(1.6) saturate(1.5)', thermal: 'grayscale(1) sepia(1) saturate(6) hue-rotate(-40deg) contrast(1.3)', cyber: 'hue-rotate(-25deg) saturate(1.6) contrast(1.15)', sunset: 'sepia(.35) saturate(1.5) hue-rotate(-12deg)', dream: 'blur(1.2px) brightness(1.08) saturate(1.1)', crush: 'contrast(1.4) brightness(.9)' }[clip.effect];
  if (fx) f.push(fx);
  el.style.filter = f.join(' ');
  el.style.opacity = String(opacityAt(clip, t));
  el.classList.toggle('vignette', clip.effect === 'vignette');
  el.classList.toggle('pixel', clip.effect === 'pixel');
}

/* ------------------------------------------ gaming: facecam & keystrokes */

const camEl = $('#vid-cam');
const keysCv = $('#keys-cv');

/** Der oberste Gaming-Clip an der Stelle t (Video 2 vor Video 1). */
function gamingAt(t) {
  for (const id of ['v2', 'v1']) {
    if (trackOf(id).hidden) continue;
    const c = activeAt(id, t);
    if (c?.gaming) return c;
  }
  return null;
}

/** Quellzeit im Clip + Tasten-Offset (wie im Gaming Hub). */
function keysOffsetAt(clip, t) {
  const src = clip.in + (t - clip.start) * speedOf(clip);
  const dur = mediaOf(clip)?.duration || clip.out;
  return (clip.gaming.keysSpan || 0) - (dur - src) * 1000;
}

function drawKeys(ctx, w, h, clip, t) {
  const g = clip.gaming;
  if (!g.showKeys || !g.keys?.length || !window.KeysOverlay) return null;
  const offset = keysOffsetAt(clip, t);
  if (offset < 0) return null;
  return window.KeysOverlay.draw(ctx, w, h, window.KeysOverlay.stateAt(g.keys, offset), { controller: g.controller !== false, scale: g.keysScale || 1, position: g.keysPos || null });
}

function renderGaming(t) {
  const clip = gamingAt(t);
  const cam = clip?.gaming?.cam;
  const screen = $('#screen');
  // Facecam
  if (cam?.on) {
    const camTime = clip.in + (t - clip.start) * speedOf(clip) - (Number(cam.offsetMs) || 0) / 1000;
    const url = fileUrl(cam.file);
    if (camEl.dataset.src !== url) {
      camEl.dataset.src = url;
      camEl.src = url;
    }
    const visible = camTime >= 0;
    camEl.classList.toggle('on', visible);
    camEl.classList.toggle('round', Boolean(cam.round));
    camEl.style.left = `${(Number(cam.x) || 0) * 100}%`;
    camEl.style.top = `${(Number(cam.y) || 0) * 100}%`;
    camEl.style.width = `${(Number(cam.w) || 0.24) * 100}%`;
    const camRate = clamp(speedOf(clip) * (state.rate || 1), 0.0625, 16);
    if (Math.abs(camEl.playbackRate - camRate) > 0.001) camEl.playbackRate = camRate;
    if (visible && (Math.abs(camEl.currentTime - camTime) > (state.playing ? 0.3 : 0.04))) camEl.currentTime = camTime;
    if (state.playing && visible && camEl.paused) camEl.play().catch(() => {});
    if (!state.playing && !camEl.paused) camEl.pause();
  } else {
    camEl.classList.remove('on');
    if (!camEl.paused) camEl.pause();
  }
  // Tasten
  const rect = screen.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  const w = Math.max(2, Math.round(rect.width * ratio));
  const h = Math.max(2, Math.round(rect.height * ratio));
  if (keysCv.width !== w || keysCv.height !== h) {
    keysCv.width = w;
    keysCv.height = h;
  }
  const ctx = keysCv.getContext('2d');
  ctx.clearRect(0, 0, w, h);
  runtime.keysBounds = clip ? drawKeys(ctx, w, h, clip, t) : null;
  runtime.keysClip = runtime.keysBounds ? clip.id : null;
}

/** Facecam und Tasten in der Vorschau verschieben (Ziehen) und skalieren (Mausrad) – wie im Gaming Hub. */
(() => {
  const screen = $('#screen');
  let drag = null;
  const rel = (e) => {
    const r = screen.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height, r };
  };
  const hitKeys = (p) => {
    const b = runtime.keysBounds;
    if (!b) return false;
    const ratio = window.devicePixelRatio || 1;
    const px = p.x * p.r.width * ratio, py = p.y * p.r.height * ratio;
    return px >= b.left && px <= b.left + b.width && py >= b.top && py <= b.top + b.height;
  };
  screen.addEventListener('pointerdown', (e) => {
    const p = rel(e);
    const clip = gamingAt(state.time);
    if (!clip) return;
    if (e.target === camEl && clip.gaming.cam?.on) {
      snapshot();
      drag = { kind: 'cam', clip, dx: p.x - clip.gaming.cam.x, dy: p.y - clip.gaming.cam.y };
    } else if (hitKeys(p)) {
      snapshot();
      const b = runtime.keysBounds;
      const ratio = window.devicePixelRatio || 1;
      drag = { kind: 'keys', clip, bw: b.width / (p.r.width * ratio), bh: b.height / (p.r.height * ratio), dx: p.x - b.left / (p.r.width * ratio), dy: p.y - b.top / (p.r.height * ratio) };
    } else return;
    screen.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  screen.addEventListener('pointermove', (e) => {
    const p = rel(e);
    if (!drag) {
      screen.classList.toggle('over-keys', hitKeys(p));
      return;
    }
    const g = drag.clip.gaming;
    if (drag.kind === 'cam') {
      const camH = camEl.getBoundingClientRect().height / p.r.height;
      g.cam.x = clamp(p.x - drag.dx, 0, 1 - (g.cam.w || 0.24));
      g.cam.y = clamp(p.y - drag.dy, 0, Math.max(0, 1 - camH));
    } else {
      const left = clamp(p.x - drag.dx, 0, 1 - drag.bw);
      const top = clamp(p.y - drag.dy, 0, 1 - drag.bh);
      g.keysPos = { x: drag.bw < 1 ? left / (1 - drag.bw) : 0, y: drag.bh < 1 ? top / (1 - drag.bh) : 0 };
    }
    renderGaming(state.time);
  });
  const end = () => {
    if (!drag) return;
    drag = null;
    save();
    if (state.selected) renderInspector();
  };
  screen.addEventListener('pointerup', end);
  screen.addEventListener('pointercancel', end);
  screen.addEventListener('wheel', (e) => {
    const clip = gamingAt(state.time);
    if (!clip) return;
    const p = rel(e);
    const k = e.deltaY < 0 ? 1.08 : 0.92;
    if (e.target === camEl && clip.gaming.cam?.on) clip.gaming.cam.w = clamp((clip.gaming.cam.w || 0.24) * k, 0.08, 0.6);
    else if (hitKeys(p)) clip.gaming.keysScale = clamp((clip.gaming.keysScale || 1) * k, 0.4, 2.5);
    else return;
    e.preventDefault();
    renderGaming(state.time);
    save();
  }, { passive: false });
})();

/** Facecam und Tasten aus der .json neben dem Gaming-Clip übernehmen. */
async function attachGaming(clip, file) {
  const meta = await api.clipMeta(file).catch(() => null);
  if (!meta || (!meta.keys.length && !meta.cam)) return;
  clip.gaming = {
    keys: meta.keys,
    keysSpan: meta.keysSpan,
    keysPos: meta.keysPos,
    keysScale: meta.keysScale,
    showKeys: meta.keys.length > 0 && meta.showKeys,
    controller: true,
    cam: meta.cam ? { ...meta.cam, on: meta.cam.visible !== false } : null,
  };
}

function renderTitles(t) {
  const host = $('#titles');
  const track = trackOf('t1');
  const clips = track.hidden ? [] : P().clips.filter((c) => c.kind === 'text' && t >= c.start && t < endOf(c));
  const key = clips.map((c) => `${c.id}|${c.text}|${c.size}|${c.color}|${c.position}|${c.box}`).join('#');
  if (host.dataset.key !== key) {
    host.dataset.key = key;
    host.innerHTML = clips
      .map((c) => `<div class="title-box ${c.position || 'bottom'} ${c.box !== false ? 'boxed' : ''}" data-id="${c.id}" style="font-size:${((c.size || 72) / 1080) * 100}cqh;color:${esc(c.color)}">${esc(c.text)}</div>`)
      .join('');
  }
  for (const box of host.children) {
    const c = clipById(box.dataset.id);
    if (!c) continue;
    const fade = Math.min(0.35, c.duration / 3);
    box.style.opacity = String(clamp(Math.min((t - c.start) / fade, (endOf(c) - t) / fade), 0, 1));
  }
}

let playFrom = 0;
let playClock = 0;
function play() {
  if (state.playing) return pause();
  if (!P().clips.length) return;
  if (state.time >= total() - 0.02) state.time = 0;
  state.playing = true;
  playFrom = state.time;
  playClock = performance.now();
  sync(true);
  requestAnimationFrame(tick);
  updateChrome();
}

function pause() {
  state.playing = false;
  for (const el of [els.v1.video, els.v2.video, ...Object.values(audioEls)]) stopEl(el);
  if (state.recording) stopRecording();
  updateChrome();
}

function tick() {
  if (!state.playing) return;
  state.time = playFrom + ((performance.now() - playClock) / 1000) * state.rate;
  const end = total();
  if (state.time >= end && !state.recording) {
    state.time = end;
    pause();
    sync(true);
    return;
  }
  sync();
  followPlayhead();
  requestAnimationFrame(tick);
}

function setRate(rate) {
  if (state.playing) {
    playFrom = state.time;
    playClock = performance.now();
  }
  state.rate = rate;
  toast(`Vorschau-Tempo ${String(rate).replace('.', ',')}×`);
  sync(true);
}

function seek(t) {
  state.time = clamp(t, 0, Math.max(total(), 0));
  if (state.playing) {
    playFrom = state.time;
    playClock = performance.now();
  }
  sync(true);
  updateChrome();
}

/* --------------------------------------------------------------- timeline */

const lanesEl = $('#lanes');
const innerEl = $('#inner');
const scrollEl = $('#scroll');

function renderTimeline() {
  const length = Math.max(total() + 10, scrollEl.clientWidth / state.pps);
  innerEl.style.width = `${Math.ceil(length * state.pps)}px`;

  // Ruler: a label every 1/2/5/10/30/60 s depending on zoom.
  const steps = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300];
  const major = steps.find((s) => s * state.pps >= 70) || 600;
  const minor = major / 5;
  let ruler = '';
  for (let i = 0; i * minor <= length; i += 1) {
    const t = Math.round(i * minor * 1000) / 1000;
    const isMajor = i % 5 === 0;
    ruler += isMajor ? `<span style="left:${t * state.pps}px">${clock(t, false)}</span>` : `<span class="minor" style="left:${t * state.pps}px"></span>`;
  }
  for (const m of P().markers || []) ruler += `<i class="marker" style="left:${m * state.pps}px" title="Marker ${clock(m)}"></i>`;
  $('#ruler').innerHTML = ruler;

  // Track heads
  const heads = P()
    .tracks.map((t) => {
      const soundless = t.kind === 'text';
      const toggle = t.kind === 'audio'
        ? `<button class="btn icon ghost ${t.muted ? 'off' : ''}" data-track-mute="${t.id}" title="${t.muted ? 'Ton an' : 'Stumm'}">${icon(t.muted ? 'mute' : 'volume', 15)}</button>`
        : `<button class="btn icon ghost ${t.hidden ? 'off' : ''}" data-track-hide="${t.id}" title="${t.hidden ? 'Einblenden' : 'Ausblenden'}">${icon('eye', 15)}</button>`;
      const mute = t.kind === 'video' ? `<button class="btn icon ghost ${t.muted ? 'off' : ''}" data-track-mute="${t.id}" title="${t.muted ? 'Ton an' : 'Ton der Spur aus'}">${icon(t.muted ? 'mute' : 'volume', 15)}</button>` : '';
      return `<div class="head"><i class="k" style="background:${TRACK_COLOR[t.id]}"></i><span>${esc(t.name)}</span>${soundless ? '' : mute}${toggle}</div>`;
    })
    .join('');
  $('#heads').innerHTML = `<div class="ruler-head"></div>${heads}`;

  // Lanes and clips
  lanesEl.innerHTML = P()
    .tracks.map((t) => `<div class="lane" data-track="${t.id}">${P().clips.filter((c) => c.track === t.id).map(clipHtml).join('')}</div>`)
    .join('');
  for (const canvas of lanesEl.querySelectorAll('canvas[data-wave]')) drawWave(canvas);
  positionPlayhead();
}

function clipHtml(c) {
  const track = trackOf(c.track);
  const left = c.start * state.pps;
  const width = Math.max(6, lengthOf(c) * state.pps);
  const kind = c.kind === 'text' ? 'text' : c.track === 'mic' ? 'mic' : track.kind;
  const m = mediaOf(c);
  let label = c.kind === 'text' ? c.text.split('\n')[0] : m?.name || 'Fehlt';
  if (c.layout === 'pip') label = `◱ ${label}`;
  let bg = '';
  if (kind === 'video') {
    const thumbs = runtime.thumbs.get(c.media) || [];
    if (thumbs.length) {
      // Pick the thumbnail nearest to the clip's in-point.
      const index = m.kind === 'image' ? 0 : clamp(Math.floor((c.in / Math.max(0.01, m.duration)) * thumbs.length), 0, thumbs.length - 1);
      bg = `style="left:${left}px;width:${width}px;background-image:url('${thumbs[index]}')"`;
    }
  }
  const style = bg || `style="left:${left}px;width:${width}px"`;
  const wave = m?.audio && kind !== 'text' ? `<canvas data-wave="${c.id}"></canvas>` : '';
  return `<div class="clip ${kind} ${c.id === state.selected ? 'sel' : ''} ${c.muted ? 'muted' : ''}" data-clip="${c.id}" ${style}>
    ${wave}<label>${esc(label)}</label><div class="h l"></div><div class="h r"></div></div>`;
}

function drawWave(canvas) {
  const c = clipById(canvas.dataset.wave);
  const data = runtime.peaks.get(c?.media);
  if (!c || !data?.peaks.length) return;
  const rect = canvas.parentElement.getBoundingClientRect();
  canvas.width = Math.max(1, Math.round(rect.width));
  canvas.height = Math.max(1, Math.round(rect.height));
  const g = canvas.getContext('2d');
  const isVideo = trackOf(c.track).kind === 'video';
  g.fillStyle = isVideo ? 'rgba(255,255,255,0.28)' : 'rgba(255,255,255,0.6)';
  const perSecond = data.peaks.length / Math.max(0.01, data.seconds || mediaOf(c).duration);
  const top = isVideo ? canvas.height * 0.62 : canvas.height * 0.32;
  const height = canvas.height - top - 2;
  const mid = top + height / 2;
  for (let x = 0; x < canvas.width; x += 2) {
    const seconds = c.in + x / state.pps;
    const peak = data.peaks[Math.floor(seconds * perSecond)] || 0;
    const h = Math.max(1, peak * height * (c.volume ?? 1));
    g.fillRect(x, mid - h / 2, 1.4, h);
  }
}

function positionPlayhead() {
  $('#playhead').style.left = `${state.time * state.pps}px`;
  $('#time').textContent = clock(state.time);
}

function followPlayhead() {
  const x = state.time * state.pps;
  if (x > scrollEl.scrollLeft + scrollEl.clientWidth - 40) scrollEl.scrollLeft = x - 80;
  if (x < scrollEl.scrollLeft) scrollEl.scrollLeft = Math.max(0, x - 80);
}

const timeAt = (clientX) => (clientX - innerEl.getBoundingClientRect().left) / state.pps;

/** Edges a dragged clip snaps to: other clips, the playhead and zero. */
function snapTargets(exceptId) {
  const list = [0, state.time];
  for (const c of P().clips) if (c.id !== exceptId) list.push(c.start, endOf(c));
  return list;
}

function snapValue(value, targets) {
  if (!state.snap) return { value, line: null };
  const limit = 8 / state.pps;
  let best = null;
  for (const t of targets) if (Math.abs(t - value) < limit && (best === null || Math.abs(t - value) < Math.abs(best - value))) best = t;
  return best === null ? { value, line: null } : { value: best, line: best };
}

function showSnap(line) {
  const el = $('#snapline');
  el.hidden = line === null;
  if (line !== null) el.style.left = `${line * state.pps}px`;
}

lanesEl.addEventListener('pointerdown', (event) => {
  const clipEl = event.target.closest('.clip');
  if (!clipEl) {
    state.selected = null;
    seek(timeAt(event.clientX));
    renderTimeline();
    renderInspector();
    scrub(event);
    return;
  }
  const clip = clipById(clipEl.dataset.clip);
  state.selected = clip.id;
  const mode = event.target.classList.contains('l') ? 'left' : event.target.classList.contains('r') ? 'right' : 'move';
  const origin = { ...clip };
  const startX = event.clientX;
  const targets = snapTargets(clip.id);
  let moved = false;
  snapshot();
  clipEl.setPointerCapture(event.pointerId);
  for (const el of lanesEl.querySelectorAll('.clip.sel')) el.classList.remove('sel');
  clipEl.classList.add('sel');
  renderInspector();

  const onMove = (e) => {
    const delta = (e.clientX - startX) / state.pps;
    if (!moved && Math.abs(e.clientX - startX) < 3) return;
    moved = true;
    let line = null;
    if (mode === 'move') {
      let start = Math.max(0, origin.start + delta);
      const a = snapValue(start, targets);
      const b = snapValue(start + lengthOf(origin), targets);
      if (a.line !== null) ({ value: start, line } = a);
      else if (b.line !== null) {
        start = b.value - lengthOf(origin);
        line = b.line;
      }
      clip.start = Math.max(0, start);
      // Move between tracks of the same kind (Video 1 ↔ Video 2, Ton ↔ Musik ↔ Sprache).
      const lane = document.elementsFromPoint(e.clientX, e.clientY).find((el) => el.classList?.contains('lane'));
      const target = lane && trackOf(lane.dataset.track);
      if (target && target.kind === trackOf(origin.track).kind && clip.kind !== 'text') clip.track = target.id;
    } else if (mode === 'left') {
      if (clip.kind === 'text') {
        const s = snapValue(clamp(origin.start + delta, 0, endOf(origin) - 0.2), targets);
        clip.start = s.value;
        clip.duration = endOf(origin) - clip.start;
        line = s.line;
      } else {
        const s = snapValue(origin.start + delta, targets);
        const shift = clamp(s.value - origin.start, -origin.in, origin.out - origin.in - 0.1);
        clip.in = origin.in + shift;
        clip.start = Math.max(0, origin.start + shift);
        line = s.line;
      }
    } else {
      const s = snapValue(endOf(origin) + delta, targets);
      if (clip.kind === 'text') clip.duration = Math.max(0.2, s.value - origin.start);
      else clip.out = clamp(origin.in + (s.value - origin.start), origin.in + 0.1, maxOut(clip));
      line = s.line;
    }
    showSnap(line);
    clipEl.style.left = `${clip.start * state.pps}px`;
    clipEl.style.width = `${Math.max(6, lengthOf(clip) * state.pps)}px`;
    const lane = lanesEl.querySelector(`.lane[data-track="${clip.track}"]`);
    if (lane && clipEl.parentElement !== lane) lane.appendChild(clipEl);
  };
  const onUp = () => {
    clipEl.removeEventListener('pointermove', onMove);
    clipEl.removeEventListener('pointerup', onUp);
    showSnap(null);
    if (!moved) {
      state.history.pop();
      renderTimeline();
      return;
    }
    resolveOverlaps(clip);
    changed();
  };
  clipEl.addEventListener('pointermove', onMove);
  clipEl.addEventListener('pointerup', onUp);
});

function scrub(event) {
  const move = (e) => seek(timeAt(e.clientX));
  const up = () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
}

$('#ruler').addEventListener('pointerdown', (event) => {
  seek(timeAt(event.clientX));
  scrub(event);
});

$('#heads').addEventListener('click', (event) => {
  const mute = event.target.closest('[data-track-mute]');
  const hide = event.target.closest('[data-track-hide]');
  if (!mute && !hide) return;
  snapshot();
  const track = trackOf((mute || hide).dataset.trackMute || (mute || hide).dataset.trackHide);
  if (mute) track.muted = !track.muted;
  else track.hidden = !track.hidden;
  changed({ keepInspector: true });
});

lanesEl.addEventListener('dblclick', (event) => {
  const clipEl = event.target.closest('.clip');
  if (clipEl && clipById(clipEl.dataset.clip)?.kind === 'text') $('#prop-text')?.focus();
});

/* ------------------------------------------------------------- drag & drop */

let dragMedia = null;
const stage = $('#stage');
const laneAt = (x, y) => document.elementsFromPoint(x, y).find((el) => el.classList?.contains('lane'));

for (const target of [stage, lanesEl]) {
  target.addEventListener('dragover', (event) => {
    event.preventDefault();
    stage.classList.toggle('dragging', target === stage);
    for (const l of lanesEl.querySelectorAll('.drop-target')) l.classList.remove('drop-target');
    laneAt(event.clientX, event.clientY)?.classList.add('drop-target');
  });
  target.addEventListener('dragleave', () => stage.classList.remove('dragging'));
  target.addEventListener('drop', async (event) => {
    event.preventDefault();
    stage.classList.remove('dragging');
    for (const l of lanesEl.querySelectorAll('.drop-target')) l.classList.remove('drop-target');
    const lane = laneAt(event.clientX, event.clientY);
    const at = lane ? Math.max(0, timeAt(event.clientX)) : undefined;
    const track = lane?.dataset.track;
    if (dragMedia) {
      const item = dragMedia;
      dragMedia = null;
      await addFromBin(item, { at, track });
      return;
    }
    const files = [...event.dataTransfer.files].map((f) => api.pathFor(f)).filter(Boolean);
    if (files.length) importFiles(files, { at, track });
  });
}

/* ------------------------------------------------------------------- bin */

let binTab = 'media';
const seenClips = new Set(JSON.parse(localStorage.getItem('seenClips') || '[]'));

function renderBin() {
  const media = Object.entries(P().media);
  const used = new Set(P().clips.map((c) => c.media));
  $('#bin-media').innerHTML = media.length
    ? media
        .map(([id, m]) => {
          const thumb = runtime.thumbs.get(id)?.[0];
          const sym = m.kind === 'audio' ? icon(id && m.file.includes('Sprachaufnahme') ? 'mic' : 'music', 18) : m.kind === 'image' ? icon('image', 18) : '';
          return `<div class="item" draggable="true" data-media="${id}">
            <div class="thumb" style="${thumb ? `background-image:url('${thumb}')` : ''}">${thumb ? '' : sym}<span class="dur">${m.kind === 'image' ? 'Bild' : clock(m.duration, false)}</span></div>
            <div><b title="${esc(m.file)}">${esc(m.name)}</b><small>${used.has(id) ? 'in der Zeitleiste' : 'nicht verwendet'}</small></div>
            <div class="item-acts"><button class="btn icon ghost" data-add-media="${id}" title="Ans Ende anfügen">${icon('plus', 15)}</button><button class="btn icon ghost" data-remove-media="${id}" title="Aus dem Projekt entfernen">${icon('trash', 14)}</button></div></div>`;
        })
        .join('')
    : `<div class="bin-empty">Noch keine Medien.<br />Über „Hinzufügen“ oder per Drag & Drop.</div>`;

  const clips = runtime.gaming;
  $('#bin-clips').innerHTML = clips.length
    ? clips
        .map((g, i) => {
          const isNew = !seenClips.has(g.file) && Date.now() - g.time < 3 * 86400000;
          const label = g.title || ({ win: 'Sieg', kill: g.kills > 1 ? `${g.kills}× Kill` : 'Kill', manual: 'Clip' }[g.category] || 'Clip');
          return `<div class="item" draggable="true" data-gaming="${i}">
            <div class="thumb" style="${g.thumb ? `background-image:url('${fileUrl(g.thumb)}')` : ''}">${g.thumb ? '' : icon('film', 18)}</div>
            <div><b>${esc(label)}</b><small>${isNew ? '<span class="new">Neu · </span>' : ''}${new Date(g.time).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })} · ${(g.bytes / 1048576).toFixed(0)} MB</small></div>
            <button class="btn icon ghost" data-add-gaming="${i}" title="In die Zeitleiste">${icon('plus', 15)}</button></div>`;
        })
        .join('')
    : `<div class="bin-empty">Keine Clips gefunden.<br />Im Gaming Hub gespeicherte Clips (Kills, Siege, Sofort-Clip) erscheinen hier automatisch.</div>`;

  const fresh = clips.filter((g) => !seenClips.has(g.file) && Date.now() - g.time < 3 * 86400000);
  $('#clip-badge').hidden = !fresh.length;
  $('#clip-badge').textContent = String(fresh.length);

  // Empty project: suggest the newest clips right in the preview.
  const suggest = !P().clips.length && fresh.length > 0;
  $('#suggest').hidden = !suggest;
  if (suggest) {
    $('#suggest-row').innerHTML = fresh
      .slice(0, 3)
      .map((g) => `<button class="suggest-card" data-suggest="${clips.indexOf(g)}"><div class="thumb" style="${g.thumb ? `background-image:url('${fileUrl(g.thumb)}')` : ''}">${g.thumb ? '' : icon('film', 22)}</div><span>${esc(g.title || (g.category === 'win' ? 'Sieg' : g.category === 'kill' ? 'Kill' : 'Clip'))}</span></button>`)
      .join('');
    $('#suggest-all').textContent = fresh.length > 1 ? `Alle ${Math.min(fresh.length, 10)} neuen Clips übernehmen` : 'Clip übernehmen';
  }
}

async function addFromBin(item, place = {}) {
  if (item.media) {
    snapshot();
    placeMedia(item.media, place);
    changed();
  } else if (item.gaming !== undefined) {
    const g = runtime.gaming[item.gaming];
    seenClips.add(g.file);
    localStorage.setItem('seenClips', JSON.stringify([...seenClips]));
    await importFiles([g.file], { ...place, gaming: true });
  }
}

$('#bin-tabs').addEventListener('click', (event) => {
  const button = event.target.closest('[data-tab]');
  if (!button) return;
  binTab = button.dataset.tab;
  for (const b of $('#bin-tabs').children) b.classList.toggle('on', b === button);
  $('#bin-media').hidden = binTab !== 'media';
  $('#bin-clips').hidden = binTab !== 'clips';
  if (binTab === 'clips') refreshGaming();
});

for (const list of [$('#bin-media'), $('#bin-clips')]) {
  list.addEventListener('click', (event) => {
    const removeBtn = event.target.closest('[data-remove-media]');
    if (removeBtn) return removeMedia(removeBtn.dataset.removeMedia);
    const addMediaBtn = event.target.closest('[data-add-media]');
    const addGaming = event.target.closest('[data-add-gaming]');
    if (addMediaBtn) addFromBin({ media: addMediaBtn.dataset.addMedia });
    if (addGaming) addFromBin({ gaming: Number(addGaming.dataset.addGaming) });
  });
  list.addEventListener('dblclick', (event) => {
    const item = event.target.closest('.item');
    if (!item) return;
    addFromBin(item.dataset.media ? { media: item.dataset.media } : { gaming: Number(item.dataset.gaming) });
  });
  list.addEventListener('dragstart', (event) => {
    const item = event.target.closest('.item');
    if (!item) return;
    dragMedia = item.dataset.media ? { media: item.dataset.media } : { gaming: Number(item.dataset.gaming) };
    event.dataTransfer.effectAllowed = 'copy';
    event.dataTransfer.setData('text/plain', 'clip');
  });
  list.addEventListener('dragend', () => {
    setTimeout(() => (dragMedia = null), 50);
  });
}

$('#suggest-row').addEventListener('click', (event) => {
  const card = event.target.closest('[data-suggest]');
  if (card) addFromBin({ gaming: Number(card.dataset.suggest) });
});

$('#suggest-all').addEventListener('click', async () => {
  const fresh = runtime.gaming.filter((g) => !seenClips.has(g.file) && Date.now() - g.time < 3 * 86400000).slice(0, 10).reverse();
  for (const g of fresh) seenClips.add(g.file);
  localStorage.setItem('seenClips', JSON.stringify([...seenClips]));
  await importFiles(fresh.map((g) => g.file), { gaming: true });
});

async function refreshGaming() {
  runtime.gaming = await api.clips().catch(() => []);
  await pruneMissing();
  renderBin();
}

/** Medien, deren Datei gelöscht wurde, samt ihren Clips aus dem Projekt nehmen. */
async function pruneMissing() {
  const entries = Object.entries(P().media);
  if (!entries.length || !api.exists) return;
  const alive = await api.exists(entries.map(([, m]) => m.file)).catch(() => null);
  if (!alive) return;
  const gone = entries.filter((_, i) => !alive[i]).map(([id]) => id);
  if (!gone.length) return;
  for (const id of gone) {
    delete P().media[id];
    runtime.thumbs.delete(id);
    runtime.peaks.delete(id);
    runtime.urls.delete(id);
  }
  const before = P().clips.length;
  P().clips = P().clips.filter((c) => c.kind === 'text' || P().media[c.media]);
  if (state.selected && !clipById(state.selected)) state.selected = null;
  toast(gone.length === 1 ? 'Eine gelöschte Datei wurde entfernt.' : `${gone.length} gelöschte Dateien wurden entfernt.`);
  if (before !== P().clips.length) changed();
  else save();
}

function removeMedia(id) {
  snapshot();
  delete P().media[id];
  P().clips = P().clips.filter((c) => c.kind === 'text' || c.media !== id);
  if (state.selected && !clipById(state.selected)) state.selected = null;
  changed();
}

/* --------------------------------------------------------------- inspector */

const COLORS = ['#ffffff', '#ffd60a', '#ff9f0a', '#ff5d6c', '#f06bc0', '#b39dff', '#38bdf8', '#3ddc97', '#000000'];

function renderInspector() {
  const host = $('#inspector');
  const clip = clipById(state.selected);
  if (!clip) {
    const length = total();
    host.innerHTML = `<h3>Projekt</h3>
      <div class="name">${P().clips.length ? `${P().clips.length} Clips · ${clock(length, false)}` : 'Leeres Projekt'}</div>
      <div class="tips">
        <p><b>Spuren:</b> Video 2 liegt über Video 1 – als Vollbild oder Bild-in-Bild. Ton, Musik und Sprache werden gemischt.</p>
        <p><kbd>Leertaste</kbd> Abspielen · <kbd>S</kbd> Teilen · <kbd>Entf</kbd> Entfernen · <kbd>Strg</kbd>+<kbd>Z</kbd> Rückgängig · <kbd>←</kbd>/<kbd>→</kbd> Bildweise</p>
        <p>Clip-Ränder ziehen zum Kürzen, Clip ziehen zum Verschieben – auch auf eine andere Spur.</p>
        <p><kbd>Strg</kbd>+<kbd>D</kbd> Duplizieren · <kbd>Strg</kbd>+<kbd>C</kbd>/<kbd>V</kbd>/<kbd>X</kbd> Kopieren/Einfügen/Ausschneiden · <kbd>Umschalt</kbd>+<kbd>Entf</kbd> Lücke schließen · <kbd>M</kbd> Marker · <kbd>↑</kbd>/<kbd>↓</kbd> Marker springen · <kbd>J</kbd>/<kbd>L</kbd> Vorschau-Tempo</p>
        <p><b>Gaming-Clips</b> bringen Facecam und Tasten mit – in der Vorschau verschieben und per Mausrad skalieren.</p>
      </div>`;
    return;
  }
  const track = trackOf(clip.track);
  const m = mediaOf(clip);
  const actions = `<div class="actions-row"><button class="btn small" data-insp="split">${icon('scissors', 14)} Teilen</button><button class="btn small danger" data-insp="delete">${icon('trash', 14)} Entfernen</button></div>`;
  if (clip.kind === 'text') {
    host.innerHTML = `<h3>Text</h3>
      <div class="prop"><label>Inhalt</label><textarea class="input" id="prop-text">${esc(clip.text)}</textarea></div>
      <div class="prop"><label>Größe <span>${clip.size}</span></label><input type="range" class="range" data-prop="size" min="24" max="180" step="2" value="${clip.size}" /></div>
      <div class="prop"><label>Farbe</label><div class="swatches">${COLORS.map((c) => `<button data-color="${c}" class="${c === clip.color ? 'on' : ''}" style="background:${c}"></button>`).join('')}</div></div>
      <div class="prop"><label>Position</label><div class="seg" data-seg="position">${[['top', 'Oben'], ['center', 'Mitte'], ['bottom', 'Unten']].map(([v, l]) => `<button data-v="${v}" class="${clip.position === v ? 'on' : ''}">${l}</button>`).join('')}</div></div>
      <div class="prop row"><label>Hintergrund</label><button class="switch ${clip.box !== false ? 'on' : ''}" data-toggle="box"></button></div>
      <div class="prop"><label>Dauer <span>${clip.duration.toFixed(1)} s</span></label><input type="range" class="range" data-prop="duration" min="0.5" max="30" step="0.1" value="${clip.duration}" /></div>
      ${actions}`;
    return;
  }
  const isVideoTrack = track.kind === 'video';
  host.innerHTML = `<h3>${isVideoTrack ? (m?.kind === 'image' ? 'Bild' : 'Video') : clip.track === 'mic' ? 'Sprachaufnahme' : 'Ton'}</h3>
    <div class="name">${esc(m?.name || 'Datei fehlt')}</div>
    <div class="prop"><label>Länge <span>${clock(lengthOf(clip))}</span></label>
      <small class="muted">Quelle ${clock(clip.in)} – ${clock(clip.out)}</small></div>
    ${m?.audio ? `<div class="prop"><label>Lautstärke <span>${Math.round((clip.volume ?? 1) * 100)} %</span></label><input type="range" class="range" data-prop="volume" min="0" max="2" step="0.05" value="${clip.volume ?? 1}" /></div>
    <div class="prop row"><label>Ton aus</label><button class="switch ${clip.muted ? 'on' : ''}" data-toggle="muted"></button></div>` : ''}
    ${isVideoTrack ? `<div class="prop"><label>Darstellung</label><div class="seg" data-seg="layout"><button data-v="full" class="${clip.layout !== 'pip' ? 'on' : ''}">Vollbild</button><button data-v="pip" class="${clip.layout === 'pip' ? 'on' : ''}">Bild-in-Bild</button></div></div>` : ''}
    ${m?.kind === 'image' ? `<div class="prop"><label>Dauer <span>${lengthOf(clip).toFixed(1)} s</span></label><input type="range" class="range" data-prop="imageDuration" min="0.5" max="60" step="0.5" value="${lengthOf(clip)}" /></div>` : ''}
    ${m?.kind !== 'image' ? section('speed', 'Tempo', `${slider('speed', 'Geschwindigkeit', clip.speed ?? 1, 0.25, 4, 0.05, 'x')}
      <div class="chips-row">${[0.25, 0.5, 1, 1.5, 2, 4].map((v) => `<button class="btn small ${speedOf(clip) === v ? 'on' : ''}" data-set="speed" data-v="${v}">${String(v).replace('.', ',')}×</button>`).join('')}</div>`) : ''}
    ${isVideoTrack ? section('transform', 'Transformieren', `${slider('scale', 'Größe', clip.scale ?? 1, 0.1, 3, 0.01, '%')}
      ${slider('x', 'Position X', clip.x ?? 0, -1, 1, 0.01, '%')}${slider('y', 'Position Y', clip.y ?? 0, -1, 1, 0.01, '%')}
      ${slider('rotation', 'Drehung', clip.rotation ?? 0, -180, 180, 1, '°')}
      <div class="prop row"><label>Horizontal spiegeln</label><button class="switch ${clip.flipH ? 'on' : ''}" data-toggle="flipH"></button></div>
      <div class="prop row"><label>Vertikal spiegeln</label><button class="switch ${clip.flipV ? 'on' : ''}" data-toggle="flipV"></button></div>
      ${slider('opacity', 'Deckkraft', clip.opacity ?? 1, 0, 1, 0.01, '%')}
      <button class="btn small ghost" data-insp="reset-transform">Zurücksetzen</button>`) : ''}
    ${isVideoTrack ? section('look', 'Farbe & Effekte', `<div class="chips-row">${Object.keys(PRESETS).map((k) => `<button class="btn small" data-preset="${k}">${{ none: 'Neutral', cinema: 'Kino', vivid: 'Kräftig', warm: 'Warm', cold: 'Kalt', noir: 'Noir', retro: 'Retro', cyber: 'Cyber', sunset: 'Sunset', faded: 'Verblasst', dream: 'Traum', action: 'Action' }[k]}</button>`).join('')}</div>
      ${slider('brightness', 'Helligkeit', clip.brightness ?? 0, -0.5, 0.5, 0.01, '±')}${slider('contrast', 'Kontrast', clip.contrast ?? 1, 0.3, 2, 0.01, '%')}
      ${slider('saturation', 'Sättigung', clip.saturation ?? 1, 0, 3, 0.01, '%')}${slider('gamma', 'Gamma', clip.gamma ?? 1, 0.3, 2.5, 0.01, 'x')}
      ${slider('hue', 'Farbton', clip.hue ?? 0, -180, 180, 1, '°')}${slider('blur', 'Weichzeichner', clip.blur ?? 0, 0, 20, 0.5, '')}${slider('sharpen', 'Schärfen', clip.sharpen ?? 0, 0, 3, 0.1, '')}
      <div class="prop"><label>Effekt</label><select class="select" data-select="effect">${EFFECTS.map(([v, l]) => `<option value="${v}" ${(clip.effect || '') === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>`) : ''}
    ${section('fade', 'Ein- & Ausblenden', `${slider('fadeIn', 'Einblenden', clip.fadeIn ?? 0, 0, Math.min(5, lengthOf(clip) / 2), 0.1, 's')}${slider('fadeOut', 'Ausblenden', clip.fadeOut ?? 0, 0, Math.min(5, lengthOf(clip) / 2), 0.1, 's')}`)}
    ${m?.audio ? section('audio', 'Ton-Effekte', `${slider('bass', 'Bass', clip.bass ?? 0, -15, 15, 1, 'dB')}${slider('treble', 'Höhen', clip.treble ?? 0, -15, 15, 1, 'dB')}${slider('pan', 'Balance L/R', clip.pan ?? 0, -1, 1, 0.05, '±')}
      <div class="prop row"><label>Echo</label><button class="switch ${clip.echo ? 'on' : ''}" data-toggle="echo"></button></div>
      <div class="prop row"><label>Rauschen entfernen</label><button class="switch ${clip.denoise ? 'on' : ''}" data-toggle="denoise"></button></div>
      <small class="muted">Bass, Höhen, Echo und Entrauschen wirken im Export.</small>`) : ''}
    ${clip.gaming ? section('gaming', 'Gaming – Facecam & Tasten', gamingHtml(clip), true) : ''}
    <div class="actions-row"><button class="btn small" data-insp="duplicate" title="Strg+D">Duplizieren</button><button class="btn small" data-insp="frame">Standbild speichern</button></div>
    ${actions}`;
}

const openSections = new Set(['gaming', 'speed']);
function section(id, title, body, open) {
  const isOpen = openSections.has(id) || (open && !openSections.has(`-${id}`));
  return `<details class="sec" data-sec="${id}" ${isOpen ? 'open' : ''}><summary>${title}</summary><div class="sec-body">${body}</div></details>`;
}
function fmtProp(key, v, unit) {
  if (unit === '%') return `${Math.round(v * 100)} %`;
  if (unit === 'x') return `${v.toFixed(2).replace('.', ',')}×`;
  if (unit === '°') return `${Math.round(v)}°`;
  if (unit === 's') return `${v.toFixed(1).replace('.', ',')} s`;
  if (unit === 'ms') return `${v > 0 ? '+' : ''}${Math.round(v)} ms`;
  if (unit === 'dB') return `${v > 0 ? '+' : ''}${v} dB`;
  if (unit === '±') return `${v > 0 ? '+' : ''}${Math.round(v * 100)}`;
  return String(Math.round(v * 10) / 10).replace('.', ',');
}
function slider(prop, label, value, min, max, step, unit, attr = 'prop') {
  return `<div class="prop"><label>${label} <span>${fmtProp(prop, Number(value), unit)}</span></label><input type="range" class="range" data-${attr}="${prop}" data-unit="${unit || '-'}" min="${min}" max="${max}" step="${step}" value="${value}" /></div>`;
}
function gamingHtml(clip) {
  const g = clip.gaming;
  const cam = g.cam;
  return `${cam ? `<div class="prop row"><label>Facecam zeigen</label><button class="switch ${cam.on ? 'on' : ''}" data-gtoggle="cam.on"></button></div>
      ${cam.on ? `<div class="prop row"><label>Rund</label><button class="switch ${cam.round ? 'on' : ''}" data-gtoggle="cam.round"></button></div>
      ${slider('w', 'Facecam-Größe', cam.w ?? 0.24, 0.08, 0.6, 0.01, '%', 'cam')}
      <div class="chips-row">${[['tl', 'Oben links'], ['tr', 'Oben rechts'], ['bl', 'Unten links'], ['br', 'Unten rechts']].map(([v, l]) => `<button class="btn small" data-campos="${v}">${l}</button>`).join('')}</div>
      ${slider('offsetMs', 'Versatz Facecam', cam.offsetMs ?? 0, -3000, 3000, 10, 'ms', 'cam')}` : ''}` : '<small class="muted">Zu diesem Clip gibt es keine Facecam.</small>'}
    ${g.keys?.length ? `<div class="prop row"><label>Tasten anzeigen</label><button class="switch ${g.showKeys ? 'on' : ''}" data-gtoggle="showKeys"></button></div>
      ${g.showKeys ? `${slider('keysScale', 'Tasten-Größe', g.keysScale ?? 1, 0.4, 2.5, 0.05, '%', 'keys')}
      <div class="prop row"><label>Controller-Tasten</label><button class="switch ${g.controller !== false ? 'on' : ''}" data-gtoggle="controller"></button></div>
      <div class="chips-row">${[['bl', 'Unten links'], ['br', 'Unten rechts'], ['tl', 'Oben links'], ['tr', 'Oben rechts']].map(([v, l]) => `<button class="btn small" data-keypos="${v}">${l}</button>`).join('')}</div>` : ''}` : '<small class="muted">Für diesen Clip wurden keine Tasten aufgezeichnet.</small>'}
    <small class="muted">Tipp: Facecam und Tasten direkt in der Vorschau ziehen, mit dem Mausrad skalieren. Beides wird mit exportiert.</small>`;
}

let propSnapshotTaken = false;
const inspector = $('#inspector');
inspector.addEventListener('pointerdown', () => {
  propSnapshotTaken = false;
});
function propSnapshot() {
  if (propSnapshotTaken) return;
  snapshot();
  propSnapshotTaken = true;
}

inspector.addEventListener('input', (event) => {
  const clip = clipById(state.selected);
  if (!clip) return;
  const el = event.target;
  propSnapshot();
  if (el.id === 'prop-text') clip.text = el.value;
  else if (el.dataset.prop === 'imageDuration') clip.out = clip.in + Number(el.value) * speedOf(clip);
  else if (el.dataset.cam) clip.gaming.cam[el.dataset.cam] = Number(el.value);
  else if (el.dataset.keys) clip.gaming[el.dataset.keys] = Number(el.value);
  else if (el.dataset.prop) clip[el.dataset.prop] = Number(el.value);
  const label = el.parentElement.querySelector('label span');
  if (label && el.dataset.prop === 'volume') label.textContent = `${Math.round(clip.volume * 100)} %`;
  else if (label && el.dataset.prop === 'size') label.textContent = String(clip.size);
  else if (label && (el.dataset.prop === 'duration' || el.dataset.prop === 'imageDuration')) label.textContent = `${lengthOf(clip).toFixed(1)} s`;
  if (label && el.dataset.unit) label.textContent = fmtProp(el.dataset.prop || el.dataset.cam || el.dataset.keys, Number(el.value), el.dataset.unit);
  if (el.dataset.prop === 'duration' || el.dataset.prop === 'imageDuration' || el.dataset.prop === 'speed') {
    resolveOverlaps(clip);
    renderTimeline();
  }
  sync(true);
  changed({ keepInspector: true });
});

inspector.addEventListener('change', (event) => {
  const clip = clipById(state.selected);
  const sel = event.target.closest('[data-select]');
  if (!clip || !sel) return;
  snapshot();
  clip[sel.dataset.select] = sel.value;
  changed({ keepInspector: true });
});
inspector.addEventListener('toggle', (event) => {
  const d = event.target.closest?.('details[data-sec]');
  if (!d) return;
  const id = d.dataset.sec;
  if (d.open) {
    openSections.add(id);
    openSections.delete(`-${id}`);
  } else {
    openSections.delete(id);
    openSections.add(`-${id}`);
  }
}, true);

inspector.addEventListener('focusout', () => {
  propSnapshotTaken = false;
});

inspector.addEventListener('click', (event) => {
  const clip = clipById(state.selected);
  if (!clip) return;
  const color = event.target.closest('[data-color]');
  const seg = event.target.closest('[data-seg] button');
  const toggle = event.target.closest('[data-toggle]');
  const action = event.target.closest('[data-insp]');
  if (action) {
    const a = action.dataset.insp;
    if (a === 'split') return split();
    if (a === 'delete') return removeSelected();
    if (a === 'duplicate') return duplicateSelected();
    if (a === 'frame') return exportFrame();
    if (a === 'reset-transform') {
      snapshot();
      for (const k of ['scale', 'x', 'y', 'rotation', 'flipH', 'flipV', 'opacity']) delete clip[k];
      return changed();
    }
  }
  const set = event.target.closest('[data-set]');
  const preset = event.target.closest('[data-preset]');
  const gtoggle = event.target.closest('[data-gtoggle]');
  const campos = event.target.closest('[data-campos]');
  const keypos = event.target.closest('[data-keypos]');
  if (set || preset || gtoggle || campos || keypos) {
    snapshot();
    if (set) {
      clip[set.dataset.set] = Number(set.dataset.v);
      resolveOverlaps(clip);
    }
    if (preset) {
      for (const k of LOOK_KEYS) delete clip[k];
      Object.assign(clip, PRESETS[preset.dataset.preset]);
    }
    if (gtoggle) {
      const [a, b] = gtoggle.dataset.gtoggle.split('.');
      const obj = b ? clip.gaming[a] : clip.gaming;
      const key = b || a;
      obj[key] = key === 'controller' ? obj[key] === false : !obj[key];
    }
    if (campos) {
      const cam = clip.gaming.cam;
      const w = cam.w || 0.24;
      const h = (w * 16) / 9 * (cam.round ? 1 : 0.5625);
      cam.x = campos.dataset.campos.includes('l') ? 0.02 : 0.98 - w;
      cam.y = campos.dataset.campos.includes('t') ? 0.04 : Math.max(0, 0.96 - h);
    }
    if (keypos) {
      const v = keypos.dataset.keypos;
      clip.gaming.keysPos = { x: v.includes('l') ? 0.02 : 0.98, y: v.includes('t') ? 0.03 : 0.97 };
    }
    return changed();
  }
  if (!color && !seg && !toggle) return;
  snapshot();
  if (color) clip.color = color.dataset.color;
  if (seg) clip[seg.parentElement.dataset.seg] = seg.dataset.v;
  if (toggle) clip[toggle.dataset.toggle] = clip[toggle.dataset.toggle] === undefined ? toggle.dataset.toggle !== 'box' : !clip[toggle.dataset.toggle];
  changed();
});

/* ------------------------------------------------------------ voice-over */

async function startRecording() {
  if (state.recording) return stopRecording();
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  } catch {
    return toast('Kein Zugriff auf das Mikrofon. In Windows unter Datenschutz › Mikrofon erlauben.', 'error');
  }
  const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' });
  const chunks = [];
  recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const audioCtx = new AudioContext();
  const analyser = audioCtx.createAnalyser();
  analyser.fftSize = 512;
  audioCtx.createMediaStreamSource(stream).connect(analyser);
  const buffer = new Uint8Array(analyser.fftSize);
  const startedAt = state.time;
  state.recording = { recorder, stream, audioCtx, startedAt, began: performance.now() };
  $('#rec').hidden = false;
  $('#rec-title').textContent = `Sprachaufnahme ab ${clock(startedAt, false)}`;
  const meter = () => {
    if (!state.recording) return;
    analyser.getByteTimeDomainData(buffer);
    let peak = 0;
    for (const v of buffer) peak = Math.max(peak, Math.abs(v - 128) / 128);
    $('#rec-level').style.width = `${Math.min(100, peak * 140)}%`;
    $('#rec-time').textContent = clock((performance.now() - state.recording.began) / 1000, false);
    requestAnimationFrame(meter);
  };
  recorder.onstop = async () => {
    stream.getTracks().forEach((t) => t.stop());
    audioCtx.close();
    $('#rec').hidden = true;
    const blob = new Blob(chunks, { type: 'audio/webm' });
    if (blob.size < 2000) return toast('Die Aufnahme war zu kurz.');
    busy('Aufnahme wird gespeichert …');
    try {
      const info = await api.recording(await blob.arrayBuffer());
      const id = addMedia(info);
      snapshot();
      const clip = { id: uid(), track: 'mic', media: id, start: startedAt, in: 0, out: info.duration, volume: 1, muted: false };
      P().clips.push(clip);
      resolveOverlaps(clip);
      state.selected = clip.id;
      changed();
      toast('Sprachaufnahme liegt auf der Spur „Sprache“.');
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      busy('');
    }
  };
  recorder.start(250);
  meter();
  if (!state.playing) play();
  sync(true);
}

function stopRecording() {
  const rec = state.recording;
  if (!rec) return;
  state.recording = null;
  rec.recorder.stop();
  if (state.playing) pause();
  sync(true);
}

$('#rec-stop').addEventListener('click', stopRecording);

/* ----------------------------------------------------------------- export */

let exportFormat = 'mp4';
let exportQuality = 'medium';
let exporting = false;

function exportSummary() {
  const sounds = P().clips.filter((c) => mediaOf(c)?.audio && !c.muted).length;
  const texts = P().clips.filter((c) => c.kind === 'text').length;
  $('#export-summary').textContent = `${clock(total(), false)} · ${P().clips.length - texts} Clips${texts ? ` · ${texts} Texte` : ''}${sounds ? ` · ${sounds} Tonquellen gemischt` : ''}`;
  $('#f-quality').hidden = exportFormat === 'gif' || exportFormat === 'mp3';
  $('#f-size').hidden = exportFormat === 'mp3';
  $('#f-codec').hidden = ['gif', 'mp3', 'webm'].includes(exportFormat);
  const gaming = P().clips.filter((c) => c.gaming && ((c.gaming.cam?.on) || c.gaming.showKeys)).length;
  if (gaming) $('#export-summary').textContent += ` · ${gaming} Gaming-Clips mit Facecam/Tasten`;
}

function openExport() {
  if (!P().clips.length) return;
  pause();
  $('#modal').hidden = false;
  $('#progress').hidden = true;
  $('#go').disabled = false;
  exportSummary();
}

$('#fmt').addEventListener('click', (event) => {
  const button = event.target.closest('[data-fmt]');
  if (!button) return;
  exportFormat = button.dataset.fmt;
  for (const b of $('#fmt').children) b.classList.toggle('on', b === button);
  exportSummary();
});
$('#quality').addEventListener('click', (event) => {
  const button = event.target.closest('[data-q]');
  if (!button) return;
  exportQuality = button.dataset.q;
  for (const b of $('#quality').children) b.classList.toggle('on', b === button);
});

$('#hw').addEventListener('click', () => $('#hw').classList.toggle('on'));
$('#cancel').addEventListener('click', () => {
  if (exporting) api.cancel();
  else $('#modal').hidden = true;
});

$('#go').addEventListener('click', async () => {
  exporting = true;
  $('#go').disabled = true;
  $('#progress').hidden = false;
  $('#pbar').style.width = '0%';
  $('#ptext').textContent = '0 %';
  try {
    const height = Number($('#height').value);
    const fps = Number($('#fps').value);
    $('#ptext').textContent = 'Overlays werden vorbereitet …';
    const project = await withKeyFrames(P(), height, fps);
    const sel = clipById(state.selected);
    const range = $('#range').value === 'clip' && sel ? { from: sel.start, to: endOf(sel) } : null;
    const out = await api.export({ project, format: exportFormat, quality: exportQuality, height, fps, codec: $('#codec').value, hw: $('#hw').classList.contains('on'), bitrate: Number($('#bitrate').value) || 0, audioBitrate: Number($('#abitrate').value) || 192, range });
    $('#modal').hidden = true;
    if (out) toast('Export fertig.', '', { label: 'Im Ordner zeigen', run: () => api.reveal(out) });
  } catch (error) {
    if (!/Abgebrochen/.test(error.message)) toast(error.message, 'error');
    else toast('Export abgebrochen.');
    $('#modal').hidden = true;
  } finally {
    exporting = false;
    $('#go').disabled = false;
  }
});

api.onProgress((p) => {
  if (p.phase === 'export') {
    const pct = Math.round(p.value * 100);
    $('#pbar').style.width = `${pct}%`;
    $('#ptext').textContent = `${pct} %${p.encoder && p.encoder !== 'cpu' ? ` · ${p.encoder.replace(/_/g, ' ').toUpperCase()}` : ''}`;
  } else if (p.phase === 'proxy') $('#busy-text').textContent = `Vorschau wird vorbereitet … ${Math.round(p.value * 100)} %`;
  else if (p.phase === 'warn') toast(p.message, 'error');
});

/* ------------------------------------------------------------------ chrome */

function updateChrome() {
  const has = P().clips.length > 0;
  $('#drop').hidden = has;
  $('#export').disabled = !has;
  $('#length').textContent = has ? `Länge ${clock(total(), false)}` : '';
  $('#play').innerHTML = icon(state.playing ? 'pause' : 'play', 17);
  $('#record').classList.toggle('on', Boolean(state.recording));
  $('[data-act="undo"]').disabled = !state.history.length;
  $('[data-act="redo"]').disabled = !state.future.length;
  $('[data-act="delete"]').disabled = !state.selected;
  $('#snap').classList.toggle('on', state.snap);
}

document.querySelector('.transport').addEventListener('click', (event) => {
  const button = event.target.closest('[data-act]');
  if (!button) return;
  const act = button.dataset.act;
  if (act === 'play') play();
  else if (act === 'start') seek(0);
  else if (act === 'split') split();
  else if (act === 'delete') removeSelected();
  else if (act === 'undo') restore(state.history, state.future);
  else if (act === 'redo') restore(state.future, state.history);
  else if (act === 'marker') toggleMarker();
  else if (act === 'frame') exportFrame();
  else if (act === 'fullscreen') $('#screen').requestFullscreen?.();
  else if (act === 'snap') {
    state.snap = !state.snap;
    updateChrome();
  }
});

$('#zoom').addEventListener('input', (event) => {
  const centre = (scrollEl.scrollLeft + scrollEl.clientWidth / 2) / state.pps;
  state.pps = Number(event.target.value);
  renderTimeline();
  scrollEl.scrollLeft = centre * state.pps - scrollEl.clientWidth / 2;
});

scrollEl.addEventListener('wheel', (event) => {
  if (!event.ctrlKey) {
    if (Math.abs(event.deltaY) > Math.abs(event.deltaX)) {
      scrollEl.scrollLeft += event.deltaY;
      event.preventDefault();
    }
    return;
  }
  event.preventDefault();
  const zoom = $('#zoom');
  zoom.value = String(clamp(state.pps * (event.deltaY < 0 ? 1.15 : 0.87), 4, 240));
  zoom.dispatchEvent(new Event('input'));
}, { passive: false });

$('#add').addEventListener('click', async () => {
  const list = await api.open();
  if (!list.length) return;
  snapshot();
  let cursor;
  for (const info of list) {
    const clip = placeMedia(addMedia(info), { at: cursor });
    if (clip.track === 'v1') cursor = endOf(clip);
  }
  changed();
});
$('#add-text').addEventListener('click', addText);
$('#record').addEventListener('click', startRecording);
$('#export').addEventListener('click', openExport);
$('#new').addEventListener('click', () => {
  if (P().clips.length && !confirm('Neues Projekt beginnen? Das aktuelle wird verworfen.')) return;
  pause();
  state.project = { name: '', media: {}, tracks: DEFAULT_TRACKS(), clips: [] };
  state.history = [];
  state.future = [];
  state.selected = null;
  state.time = 0;
  changed();
});

document.addEventListener('keydown', (event) => {
  if (event.target.closest('input, textarea, select')) return;
  const key = event.key.toLowerCase();
  if (event.code === 'Space') {
    event.preventDefault();
    if (state.recording) stopRecording();
    else play();
  } else if (key === 's' && !event.ctrlKey) split();
  else if ((key === 'delete' || key === 'backspace') && event.shiftKey) rippleDelete();
  else if (key === 'delete' || key === 'backspace') removeSelected();
  else if (key === 'd' && event.ctrlKey) duplicateSelected();
  else if (key === 'c' && event.ctrlKey) copySelected();
  else if (key === 'v' && event.ctrlKey) pasteClip();
  else if (key === 'x' && event.ctrlKey) {
    copySelected();
    removeSelected();
  } else if (key === 'm' && !event.ctrlKey) toggleMarker();
  else if (key === ',' ) seek(state.time - 1 / 30);
  else if (key === '.') seek(state.time + 1 / 30);
  else if (key === 'arrowup') jumpMarker(-1);
  else if (key === 'arrowdown') jumpMarker(1);
  else if (key === 'l' && !event.ctrlKey) setRate(state.rate >= 1 ? Math.min(4, state.rate * 2) : 1);
  else if (key === 'j' && !event.ctrlKey) setRate(state.rate > 1 ? 1 : Math.max(0.25, state.rate / 2));
  else if (key === 'z' && event.ctrlKey) restore(state.history, state.future);
  else if ((key === 'y' && event.ctrlKey) || (key === 'z' && event.ctrlKey && event.shiftKey)) restore(state.future, state.history);
  else if (key === 'arrowleft') seek(state.time - (event.shiftKey ? 1 : 1 / 30));
  else if (key === 'arrowright') seek(state.time + (event.shiftKey ? 1 : 1 / 30));
  else if (key === 'home') seek(0);
  else if (key === 'end') seek(total());
  else if (key === 't' && !event.ctrlKey) addText();
  else return;
  event.preventDefault();
});

window.addEventListener('resize', () => renderTimeline());

/* -------------------------------------------------------------------- boot */

$('#add').innerHTML = `${icon('plus', 16)} Hinzufügen`;
$('#add-text').innerHTML = `${icon('text', 16)} Text`;
$('#record').innerHTML = `${icon('mic', 16)} Sprachaufnahme`;
$('#new').innerHTML = `${icon('doc', 16)} Neu`;
$('#export').innerHTML = `${icon('download', 16)} Exportieren`;
$('#drop-icon').innerHTML = icon('scissors', 34);
document.querySelector('[data-act="split"]').innerHTML = `${icon('scissors', 15)} Teilen`;
document.querySelector('[data-act="delete"]').innerHTML = `${icon('trash', 15)} Entfernen`;
document.querySelector('[data-act="undo"]').innerHTML = icon('undo', 16);
document.querySelector('[data-act="redo"]').innerHTML = `<span style="display:inline-flex;transform:scaleX(-1)">${icon('undo', 16)}</span>`;
document.querySelector('[data-act="start"]').innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 5v14"/><path d="M18 6 9 12l9 6Z"/></svg>';

(async () => {
  const saved = await api.loadProject().catch(() => null);
  if (saved?.clips) {
    const defaults = DEFAULT_TRACKS();
    state.project = { name: saved.name || '', media: saved.media || {}, tracks: defaults.map((t) => ({ ...t, ...(saved.tracks || []).find((s) => s.id === t.id), name: t.name })), clips: saved.clips };
  }
  await refreshGaming();
  for (const id of Object.keys(P().media)) prepareMedia(id);
  changed();
  // New Gaming Hub clips show up while the editor is open.
  window.addEventListener('focus', () => refreshGaming());
  setInterval(() => {
    if (!document.hidden) refreshGaming();
  }, 30000);
})();
