'use strict';

const fs = require('fs');
const path = require('path');
const { boot } = require('../shared/boot');
const Recur = require('./recur');

const ctx = boot('agenda', __dirname);
const { app, ipcMain, Notification } = ctx.electron;
const hub = ctx.hub;

/** Dieselbe Datei wie die Orbit Island → Termine sind in Hub und Island verbunden. */
function calendarFile() {
  const base = process.env.APPDATA ? path.join(process.env.APPDATA, 'PulseIsland') : path.join(app.getPath('userData'));
  return path.join(base, 'calendar.json');
}
const firedFile = () => path.join(app.getPath('userData'), 'reminders-fired.json');

let events = [];
let lastOwnWrite = 0;
// Gelöschte Termine: falls die Island kurz danach ihre alte Liste zurückschreibt, bleiben sie trotzdem weg.
const tombstones = new Map(); // id → bis wann
// Abonnierte (schreibgeschützte) Termine kann man nur ausblenden
const hiddenFile = () => path.join(app.getPath('userData'), 'hidden-events.json');
let hidden = new Set();
try {
  hidden = new Set(JSON.parse(fs.readFileSync(hiddenFile(), 'utf8')));
} catch {
  hidden = new Set();
}

function load() {
  try {
    const list = JSON.parse(fs.readFileSync(calendarFile(), 'utf8').replace(/^﻿/, ''));
    events = Array.isArray(list) ? list : [];
  } catch {
    events = [];
  }
  const now = Date.now();
  for (const [id, until] of tombstones) if (until < now) tombstones.delete(id);
  if (tombstones.size && events.some((e) => tombstones.has(e.Id))) {
    events = events.filter((e) => !tombstones.has(e.Id));
    setTimeout(save, 50);
  }
  return visible();
}
const visible = () => events.filter((e) => !hidden.has(e.Id));

function save() {
  const file = calendarFile();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  lastOwnWrite = Date.now();
  fs.writeFileSync(`${file}.tmp`, JSON.stringify(events, null, 2));
  fs.renameSync(`${file}.tmp`, file);
  lastOwnWrite = Date.now();
}

function pushUpdate() {
  ctx.send('changed', visible());
  try {
    hub.pushState();
  } catch {
    /* Hub noch nicht bereit */
  }
}

/* --------------------------------------------------------------- Datei beobachten */
function watch() {
  const file = calendarFile();
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    let timer = null;
    fs.watch(path.dirname(file), (_type, name) => {
      if (name && name !== path.basename(file)) return;
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (Date.now() - lastOwnWrite < 1500) return;
        load();
        pushUpdate();
      }, 250);
    });
  } catch {
    /* ohne Beobachter: beim Öffnen wird neu geladen */
  }
}

/* ------------------------------------------------------------------ Erinnerungen */
let fired = new Set();
try {
  fired = new Set(JSON.parse(fs.readFileSync(firedFile(), 'utf8')));
} catch {
  /* neu */
}

function describe(occ, lead) {
  const time = occ.start.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const today = new Date();
  const tomorrow = new Date(today.getTime() + Recur.DAY);
  const sameDay = (a, b) => a.toDateString() === b.toDateString();
  let when;
  if (occ.evt.AllDay) when = sameDay(occ.start, today) ? 'Heute, ganztägig' : sameDay(occ.start, tomorrow) ? 'Morgen, ganztägig' : occ.start.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
  else if (lead === 0) when = `Beginnt jetzt · ${time}`;
  else if (sameDay(occ.start, today)) {
    const min = Math.max(1, Math.round((occ.start - Date.now()) / 60000));
    when = min < 90 ? `In ${min} Min. · ${time}` : `Heute um ${time}`;
  } else if (sameDay(occ.start, tomorrow)) when = `Morgen um ${time}`;
  else when = `${occ.start.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' })} um ${time}`;
  return occ.evt.Location ? `${when} · ${occ.evt.Location}` : when;
}

function checkReminders() {
  // Läuft die Island, erinnert sie selbst (gleiche Datei, gleiche Regeln) – sonst der Hub.
  const islandRuns = typeof hub.islandRunning === 'function' && hub.islandRunning();
  const due = Recur.dueReminders(events, Date.now(), fired);
  if (!due.length) return;
  try {
    const cutoff = Date.now() - 3 * Recur.DAY;
    fs.writeFileSync(firedFile(), JSON.stringify([...fired].filter((k) => Number(k.split('|')[1]) > cutoff)));
  } catch {
    /* egal */
  }
  if (islandRuns) return;
  for (const { occ, lead } of due) {
    const body = describe(occ, lead);
    if (Notification.isSupported()) {
      const note = new Notification({ title: `📅 ${occ.evt.Title}`, body, silent: false });
      note.on('click', () => {
        hub.showWindow();
        hub.open('agenda');
      });
      note.show();
    }
  }
}

/* ------------------------------------------------------------------------- IPC */
ipcMain.handle('list', () => load());
ipcMain.handle('save', (_event, evt) => {
  if (!evt || !evt.Id) return events;
  const now = new Date().toISOString();
  const i = events.findIndex((e) => e.Id === evt.Id);
  const clean = { ...evt, ModifiedUtc: now };
  if (i >= 0) {
    if (events[i].ReadOnly) return events;
    events[i] = { ...events[i], ...clean };
  } else events.push({ CalendarId: 'local', Source: 'local', ReadOnly: false, CreatedUtc: now, Interval: 1, ByDay: '', Count: 0, Until: null, ...clean });
  // Nach einer Änderung darf die Erinnerung für den neuen Zeitpunkt wieder klingeln.
  fired = new Set([...fired].filter((k) => !k.startsWith(`${evt.Id}|`)));
  save();
  pushUpdate();
  return visible();
});
ipcMain.handle('delete', (_event, id) => {
  const evt = events.find((e) => e.Id === id);
  if (!evt) return visible();
  if (evt.ReadOnly) {
    // aus einem Abo: nur hier ausblenden
    hidden.add(id);
    try {
      fs.writeFileSync(hiddenFile(), JSON.stringify([...hidden].slice(-500)));
    } catch {
      /* egal */
    }
  } else {
    tombstones.set(id, Date.now() + 60000);
    events = events.filter((e) => e.Id !== id);
    save();
  }
  pushUpdate();
  return visible();
});

/** Für die Startseite des Hubs: die nächsten Termine. */
global.__revolutionHub.agenda = {
  upcoming(limit = 4) {
    const now = new Date();
    return Recur.agenda(visible(), now, new Date(now.getTime() + 14 * Recur.DAY))
      .slice(0, limit)
      .map((o) => ({ id: o.evt.Id, title: o.evt.Title, start: o.start.toISOString(), allDay: Boolean(o.evt.AllDay), color: o.evt.ColorHex || '#8b6cff', location: o.evt.Location || '' }));
  },
};

app.whenReady().then(() => {
  load();
  watch();
  setTimeout(() => hub.pushState?.(), 1500);
  setInterval(checkReminders, 20000);
  setTimeout(checkReminders, 5000);
});
