import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { ensureDir } from "./paths.mjs";

const USER_AGENT = "RevolutionLauncher/1.0.0 (clean-room Minecraft launcher)";

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

export class DownloadError extends Error {
  constructor(message, url, status) {
    super(message);
    this.name = "DownloadError";
    this.url = url;
    this.status = status;
  }
}

/** fetch() with retries and a descriptive error. */
export async function request(url, { method = "GET", headers = {}, body, retries = 3, timeout = 60000 } = {}) {
  // Fail loudly instead of letting fetch() report "Failed to parse URL from undefined".
  if (typeof url !== "string" || url.length === 0) {
    throw new DownloadError("A download was attempted without a URL: the version metadata is missing that file's location.", String(url));
  }
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(url, {
        method,
        headers: { "User-Agent": USER_AGENT, ...headers },
        body,
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (!res.ok) {
        // Retry only on transient server errors.
        if (res.status >= 500 && attempt < retries) {
          lastError = new DownloadError(`HTTP ${res.status} for ${url}`, url, res.status);
          await sleep(500 * (attempt + 1));
          continue;
        }
        throw new DownloadError(`HTTP ${res.status} ${res.statusText} for ${url}`, url, res.status);
      }
      return res;
    } catch (err) {
      clearTimeout(timer);
      if (err instanceof DownloadError && err.status && err.status < 500) throw err;
      lastError = err;
      if (attempt >= retries) break;
      await sleep(500 * (attempt + 1));
    }
  }
  throw new DownloadError(`Request failed: ${url} (${lastError?.message || lastError})`, url);
}

export async function fetchJson(url, options) {
  const res = await request(url, options);
  return res.json();
}

export function sha1(buffer) {
  return crypto.createHash("sha1").update(buffer).digest("hex");
}

export async function sha1File(file) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("sha1");
    const stream = fs.createReadStream(file);
    stream.on("error", reject);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("end", () => resolve(hash.digest("hex")));
  });
}

/**
 * Download `url` to `dest` unless the existing file already matches `sha1`.
 * Writes to a temp file first so a failed download can never leave a corrupt cache entry.
 */
export async function download(url, dest, { expectedSha1, size, progress } = {}) {
  if (fs.existsSync(dest)) {
    const stat = fs.statSync(dest);
    if (expectedSha1) {
      if (await sha1File(dest) === expectedSha1.toLowerCase()) return { path: dest, skipped: true };
    } else if (stat.size > 0 && (!size || stat.size === size)) {
      return { path: dest, skipped: true };
    }
  }
  ensureDir(path.dirname(dest));
  const res = await request(url);
  const buffer = Buffer.from(await res.arrayBuffer());
  if (expectedSha1 && sha1(buffer) !== expectedSha1.toLowerCase()) {
    throw new DownloadError(`Checksum mismatch for ${path.basename(dest)}`, url);
  }
  const tmp = `${dest}.part`;
  await fsp.writeFile(tmp, buffer);
  await fsp.rename(tmp, dest);
  if (progress) progress({ url, path: dest, bytes: buffer.length });
  return { path: dest, skipped: false, bytes: buffer.length };
}

/** Run `worker` over `items` with a bounded number of concurrent tasks. */
export async function pool(items, limit, worker) {
  const list = Array.from(items);
  const results = new Array(list.length);
  let cursor = 0;
  let failed = 0;
  const runners = new Array(Math.max(1, Math.min(limit, list.length))).fill(0).map(async () => {
    while (true) {
      const index = cursor++;
      if (index >= list.length) return;
      try {
        results[index] = await worker(list[index], index);
      } catch (err) {
        failed++;
        throw err;
      }
    }
  });
  await Promise.all(runners);
  return { results, failed };
}

/** Download many files with concurrency and aggregated progress. */
export async function downloadAll(tasks, { concurrency = 12, onProgress } = {}) {
  const total = tasks.length;
  let done = 0;
  const result = await pool(tasks, concurrency, async (task) => {
    const out = await download(task.url, task.path, { expectedSha1: task.sha1, size: task.size });
    done++;
    if (onProgress) onProgress({ phase: task.phase || "download", done, total, label: task.label || path.basename(task.path) });
    return out;
  });
  return { done, total, results: result.results };
}
