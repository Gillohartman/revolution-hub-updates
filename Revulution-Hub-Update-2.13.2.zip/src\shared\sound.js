'use strict';

/**
 * Clean, synthesized UI clicks (no audio files): a short soft "tick" for buttons and a
 * two-note blip for switches. Used by the hub and by every app inside it.
 */
(function (root) {
  function createClickSound() {
    let ctx = null;
    let enabled = true;
    let volume = 0.5;
    let last = 0;
    let style = 'classic';
    let clip = null;
    let clipRaw = '';

    function loadClip(b64) {
      if (!b64 || b64 === clipRaw) return;
      clipRaw = b64;
      try {
        const bin = atob(b64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
        audio().decodeAudioData(bytes.buffer).then((b) => (clip = b)).catch(() => {});
      } catch {
        /* optional */
      }
    }

    function audio() {
      if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      return ctx;
    }

    function tone(ac, start, from, to, length, gain) {
      const osc = ac.createOscillator();
      const amp = ac.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(from, start);
      osc.frequency.exponentialRampToValueAtTime(to, start + length);
      amp.gain.setValueAtTime(0.0001, start);
      amp.gain.exponentialRampToValueAtTime(gain, start + 0.004);
      amp.gain.exponentialRampToValueAtTime(0.0001, start + length);
      osc.connect(amp).connect(ac.destination);
      osc.start(start);
      osc.stop(start + length + 0.02);
    }

    function tick(ac, start, gain) {
      const length = 0.012;
      const buffer = ac.createBuffer(1, Math.ceil(ac.sampleRate * length), ac.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i += 1) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 3);
      const src = ac.createBufferSource();
      src.buffer = buffer;
      const band = ac.createBiquadFilter();
      band.type = 'bandpass';
      band.frequency.value = 3400;
      band.Q.value = 0.9;
      const amp = ac.createGain();
      amp.gain.value = gain;
      src.connect(band).connect(amp).connect(ac.destination);
      src.start(start);
    }

    function play(kind = 'tap') {
      if (!enabled || volume <= 0) return;
      const now = performance.now();
      if (now - last < (style === 'kq' ? 90 : 35)) return;
      last = now;
      try {
        const ac = audio();
        const t = ac.currentTime + 0.001;
        const v = Math.min(1, Math.max(0, volume));
        if (style === 'kq' && clip) {
          const src = ac.createBufferSource();
          src.buffer = clip;
          const amp = ac.createGain();
          amp.gain.value = 0.8 * v;
          src.connect(amp).connect(ac.destination);
          src.start(t);
          return;
        }
        if (kind === 'toggle') {
          tone(ac, t, 880, 860, 0.05, 0.09 * v);
          tone(ac, t + 0.045, 1320, 1300, 0.06, 0.08 * v);
        } else {
          tick(ac, t, 0.55 * v);
          tone(ac, t, 1500, 820, 0.035, 0.07 * v);
        }
      } catch {
        /* sound is optional */
      }
    }

    const CLICKABLE = 'button, [role="button"], [role="tab"], [role="menuitem"], [role="option"], a[href], select, summary, input[type="checkbox"], input[type="radio"], .nav-item, [data-file-item]';

    function attach(doc) {
      doc.addEventListener(
        'pointerdown',
        (event) => {
          if (event.button !== 0) return;
          const target = event.target && event.target.closest ? event.target.closest(CLICKABLE) : null;
          if (!target || target.disabled || target.getAttribute('aria-disabled') === 'true') return;
          const toggle = target.matches('input[type="checkbox"], input[type="radio"], [role="switch"], .switch, .toggle') || target.getAttribute('aria-pressed') !== null;
          play(toggle ? 'toggle' : 'tap');
        },
        true,
      );
    }

    return {
      play,
      attach,
      configure(options = {}) {
        if (typeof options.enabled === 'boolean') enabled = options.enabled;
        if (typeof options.volume === 'number') volume = options.volume;
        if (typeof options.style === 'string') style = options.style;
        if (typeof options.clip === 'string') loadClip(options.clip);
      },
    };
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = { createClickSound };
  else root.createClickSound = createClickSound;
})(typeof window !== 'undefined' ? window : globalThis);
