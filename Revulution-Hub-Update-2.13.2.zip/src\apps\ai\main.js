'use strict';

/*
 * KI-Chat mit Ollama (läuft lokal auf dem PC). Bewusst nur kleine Modelle und kurze
 * Antworten, damit der PC nicht ausgelastet wird. Der Hub prüft vorher, ob der PC das schafft.
 */
const fs = require('fs');
const path = require('path');
const { boot } = require('../shared/boot');
const pcinfo = require('../../main/pcinfo');

const ctx = boot('ai', __dirname);
const { app, ipcMain, shell } = ctx.electron;
const HOST = 'http://127.0.0.1:11434';
const file = () => path.join(app.getPath('userData'), 'ai.json');

async function status() {
  const pc = await pcinfo.info();
  let running = false;
  let models = [];
  try {
    const res = await fetch(`${HOST}/api/tags`, { signal: AbortSignal.timeout(2500) });
    if (res.ok) {
      running = true;
      models = ((await res.json()).models || []).map((m) => ({ name: m.name, size: m.size }));
    }
  } catch {
    running = false;
  }
  let installed = running;
  if (!installed && process.platform === 'win32') {
    const local = process.env.LOCALAPPDATA || '';
    installed = [path.join(local, 'Programs', 'Ollama', 'ollama.exe'), path.join(local, 'Ollama', 'ollama.exe')].some((f) => fs.existsSync(f));
  }
  return { pc, running, installed, models };
}

ipcMain.handle('status', () => status());
ipcMain.handle('download', () => shell.openExternal('https://ollama.com/download'));
ipcMain.handle('start', async () => {
  // Ollama-App starten, falls installiert aber nicht aktiv
  const local = process.env.LOCALAPPDATA || '';
  for (const f of [path.join(local, 'Programs', 'Ollama', 'ollama app.exe'), path.join(local, 'Programs', 'Ollama', 'ollama.exe')]) {
    if (fs.existsSync(f)) {
      require('child_process').spawn(f, f.endsWith('ollama.exe') ? ['serve'] : [], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
      return true;
    }
  }
  return false;
});

ipcMain.handle('pull', async (_e, model) => {
  if (!/^[a-z0-9._:-]{2,40}$/i.test(model)) throw new Error('Ungültiges Modell');
  const res = await fetch(`${HOST}/api/pull`, { method: 'POST', body: JSON.stringify({ name: model, stream: true }) });
  if (!res.ok || !res.body) throw new Error(`Ollama: ${res.status}`);
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      try {
        const j = JSON.parse(line);
        if (j.error) throw new Error(j.error);
        ctx.send('pull', { status: j.status, total: j.total, done: j.completed });
      } catch (error) {
        if (error.message && !/JSON/.test(error.message)) throw error;
      }
    }
  }
  return true;
});

let current = null;
ipcMain.handle('chat', async (_e, { model, messages }) => {
  const pc = await pcinfo.info();
  current?.abort();
  const ctrl = new AbortController();
  current = ctrl;
  const body = {
    model,
    stream: true,
    keep_alive: '3m', // Speicher schnell wieder freigeben
    messages: [
      { role: 'system', content: 'Du bist ein freundlicher Assistent im Revulution Hub. Antworte kurz und einfach (höchstens 5 Sätze) in der Sprache der Frage. Bei komplizierten Aufgaben sag ehrlich, dass du nur für einfache Fragen gedacht bist.' },
      ...messages.slice(-8).map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: String(m.content).slice(0, 1200) })),
    ],
    options: { num_ctx: 2048, num_predict: 320, num_thread: pc.threads, temperature: 0.6 },
  };
  const res = await fetch(`${HOST}/api/chat`, { method: 'POST', body: JSON.stringify(body), signal: ctrl.signal });
  if (!res.ok || !res.body) throw new Error(`Ollama antwortet nicht (${res.status}).`);
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  let text = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      try {
        const j = JSON.parse(line);
        if (j.error) throw new Error(j.error);
        if (j.message?.content) {
          text += j.message.content;
          ctx.send('token', j.message.content);
        }
      } catch (error) {
        if (error.message && !/JSON/.test(error.message)) throw error;
      }
    }
  }
  current = null;
  return text;
});
ipcMain.handle('stop', () => {
  current?.abort();
  current = null;
  return true;
});
ipcMain.handle('load', () => {
  try {
    return JSON.parse(fs.readFileSync(file(), 'utf8'));
  } catch {
    return null;
  }
});
ipcMain.handle('save', (_e, d) => {
  fs.mkdirSync(path.dirname(file()), { recursive: true });
  fs.writeFileSync(file(), JSON.stringify(d));
  return true;
});
