'use strict';

(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const api = window.aiApp;
  const MAX = 300; // Zeichen pro Frage – nur einfache Fragen
  const ic = (n, s = 24) => (window.icon ? window.icon(n, s) : '');

  let st = null;
  let data = { messages: [], model: '' };
  let busy = false;
  let pulling = null;

  const save = () => api.save(data);

  async function refresh() {
    st = await api.status().catch(() => null);
    render();
  }

  function setupHtml() {
    const pc = st?.pc;
    const ai = pc?.ai || {};
    const has = st?.models?.some((m) => m.name.startsWith(ai.model));
    const step = (n, ok, title, text, extra = '') => `<div class="step"><span class="num ${ok === true ? 'ok' : ok === false ? 'bad' : ''}">${ok === true ? '✓' : ok === false ? '!' : n}</span><div><b>${title}</b><p>${text}</p>${extra}</div></div>`;
    return `<div class="setup">
      <div class="card hero"><div class="logo">${ic('spark', 28)}</div><div><h1>Lokale KI für einfache Fragen</h1><p>Lade dir <b>Ollama</b> herunter, um eine KI direkt auf deinem PC zu haben – ohne Cloud. Sie ist nur für <b>einfache Fragen</b> gedacht, damit dein PC nicht ausgelastet wird.</p></div></div>
      <div class="card">
        ${step(1, pc ? ai.ok : null, 'Kann dein PC das?', pc ? `PC-Stärke <b>${pc.level}/10</b> (${esc(pc.label)}) · ${String(pc.ram).replace('.', ',')} GB RAM · ${esc(pc.gpu?.name || 'keine Grafikkarte erkannt')}<br>${esc(ai.reason || '')}` : 'Wird gemessen …')}
        ${step(2, st?.installed ? true : null, 'Ollama installieren', st?.installed ? (st.running ? 'Ollama ist installiert und läuft.' : 'Ollama ist installiert, läuft aber gerade nicht.') : 'Ollama ist ein kostenloses Programm, das KI-Modelle lokal ausführt. Lade es von der offiziellen Seite herunter und installiere es.', st?.installed ? (st.running ? '' : '<button class="btn" data-a="start">Ollama starten</button>') : '<button class="btn primary" data-a="download">Ollama herunterladen (ollama.com)</button> <button class="btn ghost" data-a="check">Ich habe es installiert</button>')}
        ${step(3, has ? true : null, `Kleines Modell laden${ai.model ? `: ${esc(ai.model)}` : ''}`, ai.ok === false ? 'Für deinen PC nicht empfohlen. Du kannst es trotzdem versuchen – es kann dann sehr langsam werden.' : `Passend zu deinem PC ${esc(ai.size || '')}. Wird einmalig heruntergeladen.`, st?.running && !has ? `<button class="btn primary" data-a="pull" ${pulling ? 'disabled' : ''}>Modell laden</button><div class="bar"><i id="pull-bar"></i></div><p id="pull-text"></p>` : '')}
      </div>
      <div class="note">Hinweis: Die KI läuft komplett auf deinem PC. Sie kann sich irren – prüfe wichtige Antworten selbst. Für lange Texte, Code oder komplexe Aufgaben ist sie nicht gedacht.</div>
    </div>`;
  }

  function chatHtml() {
    const msgs = data.messages;
    return `<div class="card chat">
      <div class="chat-head"><div class="logo" style="width:36px;height:36px;border-radius:11px">${ic('spark', 18)}</div><div class="grow"><b>KI-Chat</b><br><small>${esc(data.model)} · lokal auf deinem PC · nur einfache Fragen</small></div><button class="btn small ghost" data-a="clear">Neuer Chat</button></div>
      <div class="msgs" id="msgs">${msgs.length ? msgs.map((m) => `<div class="msg ${m.role}">${esc(m.content)}</div>`).join('') : `<div class="empty">${ic('spark', 34)}<p>Stell eine kurze, einfache Frage.</p><div class="chips">${['Was ist die Hauptstadt von Kanada?', 'Erklär mir kurz, was RAM ist.', 'Gib mir 3 Ideen für ein Abendessen.', 'Wie viele Tage hat ein Schaltjahr?'].map((q) => `<button data-q="${esc(q)}">${esc(q)}</button>`).join('')}</div></div>`}</div>
      <form class="compose" id="form"><input class="input" id="q" maxlength="${MAX}" placeholder="Einfache Frage stellen …" autocomplete="off" ${busy ? 'disabled' : ''} /><span class="count" id="count">0/${MAX}</span>${busy ? '<button class="btn" type="button" data-a="stop">Stopp</button>' : '<button class="btn primary" type="submit">Fragen</button>'}</form>
    </div>`;
  }

  function render() {
    const ready = st?.running && data.model && st.models.some((m) => m.name === data.model);
    if (!ready && st?.running) {
      const want = st.pc?.ai?.model;
      const have = st.models.find((m) => want && m.name.startsWith(want)) || st.models.find((m) => /0\.5b|1b|3b|mini|tiny/i.test(m.name));
      if (have) {
        data.model = have.name;
        save();
        return render();
      }
    }
    $('wrap').innerHTML = ready ? chatHtml() : setupHtml();
    const m = $('msgs');
    if (m) m.scrollTop = m.scrollHeight;
    $('q')?.focus();
  }

  async function ask(text) {
    text = text.trim().slice(0, MAX);
    if (!text || busy) return;
    data.messages.push({ role: 'user', content: text });
    data.messages.push({ role: 'assistant', content: '' });
    busy = true;
    render();
    const out = $('msgs').lastElementChild;
    out.classList.add('typing');
    try {
      const answer = await api.chat({ model: data.model, messages: data.messages.slice(0, -1) });
      data.messages[data.messages.length - 1].content = answer || '…';
    } catch (error) {
      data.messages[data.messages.length - 1].content = /abort/i.test(error.message) ? '(abgebrochen)' : `Fehler: ${String(error.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')}`;
    }
    data.messages = data.messages.slice(-30);
    busy = false;
    save();
    render();
  }

  api.on('token', (tok) => {
    const last = data.messages[data.messages.length - 1];
    if (!busy || !last || last.role !== 'assistant') return;
    last.content += tok;
    const el = $('msgs')?.lastElementChild;
    if (el) {
      el.textContent = last.content;
      $('msgs').scrollTop = $('msgs').scrollHeight;
    }
  });
  api.on('pull', (p) => {
    const pct = p.total ? Math.round(((p.done || 0) / p.total) * 100) : 0;
    if ($('pull-bar')) $('pull-bar').style.width = `${pct}%`;
    if ($('pull-text')) $('pull-text').textContent = `${p.status || ''}${p.total ? ` · ${pct} %` : ''}`;
  });

  document.addEventListener('click', async (e) => {
    const q = e.target.closest('[data-q]');
    if (q) return ask(q.dataset.q);
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (!a) return;
    if (a === 'download') {
      api.download();
      return;
    }
    if (a === 'check') return refresh();
    if (a === 'start') {
      await api.start();
      setTimeout(refresh, 3500);
      return;
    }
    if (a === 'pull') {
      pulling = st.pc.ai.model;
      render();
      try {
        await api.pull(pulling);
        data.model = pulling;
        save();
      } catch (error) {
        if ($('pull-text')) $('pull-text').textContent = `Fehler: ${error.message}`;
      }
      pulling = null;
      refresh();
      return;
    }
    if (a === 'stop') return api.stop();
    if (a === 'clear') {
      data.messages = [];
      save();
      render();
    }
  });
  document.addEventListener('submit', (e) => {
    if (e.target.id !== 'form') return;
    e.preventDefault();
    ask($('q').value);
  });
  document.addEventListener('input', (e) => {
    if (e.target.id === 'q') $('count').textContent = `${e.target.value.length}/${MAX}`;
  });

  (async () => {
    data = { ...data, ...((await api.load().catch(() => null)) || {}) };
    $('wrap').innerHTML = '<div class="setup"><div class="card">Prüfe deinen PC und Ollama …</div></div>';
    await refresh();
    // Status regelmäßig prüfen, solange noch nicht alles bereit ist
    setInterval(() => {
      if (!busy && !pulling && !(st?.running && st.models.some((m) => m.name === data.model))) refresh();
    }, 8000);
  })();
})();
