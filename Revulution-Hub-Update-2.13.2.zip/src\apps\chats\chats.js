'use strict';

/*
 * Chats im Discord-Stil über öffentliche MQTT-Server (dieselben wie die Online-Spiele).
 * Server-Leiste (Lobby, Räume), Direktnachrichten und Freunde, Emojis, Bilder, Einstellungen.
 * WICHTIG: nicht verschlüsselt – jeder, der den Raum-Namen/Code kennt, kann mitlesen.
 */
(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const api = window.chatApp;
  const C = window.RevCos;
  const HP = window.hubProfile;
  const COLORS = ['#34d399', '#38bdf8', '#a78bfa', '#f472b6', '#fbbf24', '#fb7185', '#4ade80', '#60a5fa'];
  const newCode = () => Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 32]).join('');
  const roomCode = (s) => String(s).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 24);
  const hm = (t) => new Date(t).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const dayOf = (t) => new Date(t).toLocaleDateString('de-DE', { weekday: 'long', day: '2-digit', month: 'long' });
  const isCode = (c) => /^[A-Z0-9]{8}$/.test(String(c || ''));

  const DEFAULT_SETTINGS = { allowGameDMs: true, allowFriendReq: true, notify: true, images: true };
  let data = { me: null, chats: [], active: 'lobby', friends: [], requests: [], blocked: [], settings: { ...DEFAULT_SETTINGS } };
  const rooms = new Map(); // chatId → { room, failed }
  const seen = new Set();
  let myCos = {};

  const save = () => api.save(data);
  const put = (id, html) => (window.RevMorph ? window.RevMorph.morph($(id), html) : ($(id).innerHTML = html));
  const chatById = (id) => data.chats.find((c) => c.id === id);
  const avatar = (name, color, size = 38) => `<span class="av" style="width:${size}px;height:${size}px;background:${esc(color)};font-size:${Math.round(size * 0.42)}px">${esc((name || '?').slice(0, 1).toUpperCase())}</span>`;
  const COS_KEYS = ['avatar', 'color', 'frame', 'name', 'title'];
  const cleanCos = (c) => {
    if (!c || typeof c !== 'object') return null;
    const out = {};
    for (const k of COS_KEYS) if (typeof c[k] === 'string' && c[k].length < 24) out[k] = c[k];
    return out;
  };
  const cosAvatar = (cos, name, color, size = 38) => (cos && C ? C.avatarHtml(cos, size) : avatar(name, color, size));
  const nameAttr = (cos, color) => (cos && C ? C.nameStyle(cos) : `style="color:${esc(color || '#fff')}"`);
  const ICON = {
    home: '<svg viewBox="0 0 24 24"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.9A8 8 0 1 1 21 12Z"/></svg>',
    globe: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></svg>',
    users: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.3-6 6.5-6s5.9 2.4 6.5 6M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2 .7 3.2 2.8 3.5 6"/></svg>',
  };

  /* ------------------------------------------------------------ Hilfen */
  function toast(text) {
    const el = $('toast');
    el.textContent = text;
    el.hidden = false;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (el.hidden = true), 2800);
  }
  const unreadTotal = () => data.chats.reduce((a, c) => a + (c.unread || 0), 0) + (data.requests?.length || 0);
  function pushUnread() {
    api.unread?.(unreadTotal()).catch(() => {});
  }
  function pushIdentity() {
    api.identity?.({ code: data.me.code, name: data.me.name, allowGameDMs: data.settings.allowGameDMs, allowFriendReq: data.settings.allowFriendReq }).catch(() => {});
  }
  const homeActive = () => data.active === 'friends' || chatById(data.active)?.kind === 'dm';

  /* ------------------------------------------------------------ Verbindung */
  async function connect(chat) {
    if (rooms.has(chat.id)) return;
    const entry = { room: null, failed: false };
    rooms.set(chat.id, entry);
    const code = chat.kind === 'public' ? 'LOBBY' : chat.kind === 'dm' ? `DM-${[data.me.code, chat.peer].sort().join('-')}` : `R-${chat.key}`;
    const room = new window.RevNet.Room({ app: 'chat', code, name: data.me.name });
    const refresh = () => {
      if (chat.id === data.active) {
        renderHead();
        renderMembers();
      }
    };
    room.on('peer', refresh);
    room.on('left', refresh);
    room.on('msg', (m) => onMsg(chat, m));
    try {
      await room.join();
      entry.room = room;
    } catch {
      entry.failed = true;
    }
    refresh();
  }

  /** Persönlicher Posteingang: neue Direktnachrichten und Freundschaftsanfragen. */
  function inboxSend(code, type, extra = {}) {
    const r = new window.RevNet.Room({ app: 'chat', code: `IN-${code}`, name: data.me.name });
    return r
      .join()
      .then(() => {
        r.send(type, { code: data.me.code, color: data.me.color, cos: cleanCos(myCos), ...extra });
        setTimeout(() => r.leave(), 3000);
      })
      .catch(() => {});
  }
  async function connectInbox() {
    const room = new window.RevNet.Room({ app: 'chat', code: `IN-${data.me.code}`, name: data.me.name });
    room.on('msg', (m) => {
      if (!isCode(m.code) || m.code === data.me.code || data.blocked.includes(m.code)) return;
      const name = String(m.name || 'Spieler').slice(0, 24);
      if (m.t === 'dm-hello') {
        if (m.src === 'game' && !data.settings.allowGameDMs && !isFriend(m.code)) return;
        ensureDm({ code: m.code, name, color: m.color, cos: cleanCos(m.cos) });
        if (data.settings.notify) api.notify({ title: 'Neuer Chat', body: `${name} möchte mit dir schreiben.` });
      } else if (m.t === 'friend-req') {
        if (!data.settings.allowFriendReq || isFriend(m.code) || data.requests.some((r) => r.code === m.code)) return;
        data.requests.push({ code: m.code, name, cos: cleanCos(m.cos), color: m.color || COLORS[2], game: String(m.game || '').slice(0, 20), at: Date.now() });
        if (data.settings.notify) api.notify({ title: 'Freundschaftsanfrage', body: `${name} möchte dein Freund sein${m.game ? ` (aus ${m.game})` : ''}.` });
      } else if (m.t === 'friend-ok') {
        addFriend({ code: m.code, name, cos: cleanCos(m.cos), color: m.color });
        if (data.settings.notify) api.notify({ title: 'Neuer Freund', body: `${name} hat deine Anfrage angenommen.` });
      } else return;
      save();
      renderAll();
    });
    try {
      await room.join();
    } catch {
      /* offline */
    }
  }

  const isFriend = (code) => data.friends.some((f) => f.code === code);
  function ensureDm({ code, name, color, cos }) {
    let chat = data.chats.find((c) => c.kind === 'dm' && c.peer === code);
    if (!chat) {
      chat = { id: `dm-${code}`, kind: 'dm', name: name || `Spieler ${code.slice(0, 4)}`, peer: code, color: color || COLORS[2], cos: cos || null, msgs: [], unread: 0 };
      data.chats.push(chat);
      connect(chat);
    } else if (name && chat.name.startsWith('Freund ')) chat.name = name;
    return chat;
  }
  function addFriend(f) {
    if (!isFriend(f.code)) data.friends.push({ code: f.code, name: f.name, cos: f.cos || null, color: f.color || COLORS[3], since: Date.now() });
    data.requests = data.requests.filter((r) => r.code !== f.code);
    ensureDm(f);
  }

  /* ------------------------------------------------------------ Nachrichten */
  function onMsg(chat, m) {
    if (m.t !== 'msg' || !m.id || seen.has(m.id)) return;
    if (typeof m.text !== 'string' && typeof m.img !== 'string') return;
    if (isCode(m.code) && data.blocked.includes(m.code)) return;
    seen.add(m.id);
    const img = typeof m.img === 'string' && /^data:image\/(jpeg|png|webp|gif);base64,/.test(m.img) && m.img.length < 400000 ? m.img : '';
    const msg = { id: m.id, text: String(m.text || '').slice(0, 800), img, from: String(m.nm || m.name || '?').slice(0, 24), code: m.code, color: m.color || COLORS[1], cos: cleanCos(m.cos), at: Date.now() };
    chat.msgs.push(msg);
    chat.msgs = chat.msgs.slice(-300);
    if (chat.kind === 'dm') {
      if (msg.cos) chat.cos = msg.cos;
      if (msg.from && msg.from !== '?') chat.name = msg.from;
    }
    const visible = chat.id === data.active && !document.hidden;
    if (!visible) chat.unread = (chat.unread || 0) + 1;
    // Der Hub entscheidet: Chats offen → nichts, sonst Dynamic Island (bzw. Windows)
    if (data.settings.notify) api.notify({ title: chat.kind === 'dm' ? msg.from : `${msg.from} · ${chat.name}`, body: msg.text || '📷 Bild' });
    save();
    renderRail();
    renderList();
    if (chat.id === data.active) renderMsgs(true);
    pushUnread();
  }

  function send(text, img = '') {
    const chat = chatById(data.active);
    const entry = rooms.get(data.active);
    if (!chat || (!text.trim() && !img)) return;
    if (!entry?.room) return sys('Keine Verbindung zum Chat-Server – Nachricht nicht gesendet.');
    const msg = { id: newCode() + Date.now().toString(36), text: text.trim().slice(0, 800), code: data.me.code, color: data.me.color, nm: data.me.name, cos: cleanCos(myCos) };
    if (img) msg.img = img;
    seen.add(msg.id);
    entry.room.send('msg', msg);
    chat.msgs.push({ ...msg, from: data.me.name, me: true, at: Date.now() });
    chat.msgs = chat.msgs.slice(-300);
    save();
    renderList();
    renderMsgs(true);
  }
  function sys(text) {
    const el = document.createElement('div');
    el.className = 'sys';
    el.textContent = text;
    $('msgs').appendChild(el);
    $('msgs').scrollTop = $('msgs').scrollHeight;
  }

  /** Bild verkleinern (max. 960 px, JPEG), damit es durch den Chat-Server passt. */
  function shrink(file) {
    return new Promise((resolve, reject) => {
      if (!file || !/^image\//.test(file.type)) return reject(new Error('Kein Bild'));
      const url = URL.createObjectURL(file);
      const im = new Image();
      im.onload = () => {
        let max = 960, q = 0.78, out = '';
        for (let i = 0; i < 6; i += 1) {
          const k = Math.min(1, max / Math.max(im.width, im.height));
          const cv = document.createElement('canvas');
          cv.width = Math.max(1, Math.round(im.width * k));
          cv.height = Math.max(1, Math.round(im.height * k));
          cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
          out = cv.toDataURL('image/jpeg', q);
          if (out.length < 180000) break;
          max *= 0.78;
          q = Math.max(0.5, q - 0.06);
        }
        URL.revokeObjectURL(url);
        resolve(out);
      };
      im.onerror = () => reject(new Error('Bild konnte nicht gelesen werden'));
      im.src = url;
    });
  }
  async function sendImage(file) {
    try {
      const img = await shrink(file);
      send($('text').value, img);
      $('text').value = '';
    } catch (e) {
      toast(e.message);
    }
  }

  /* ---------------------------------------------------------------- Anzeige */
  function renderRail() {
    const rooms = data.chats.filter((c) => c.kind === 'room');
    const dmUnread = data.chats.filter((c) => c.kind === 'dm').reduce((a, c) => a + (c.unread || 0), 0) + data.requests.length;
    const lobby = chatById('lobby');
    const srv = (id, label, inner, cls, unread) => `<button class="srv ${cls} ${unread ? 'unread' : ''}" data-srv="${esc(id)}" data-tip="${esc(label)}">${inner}${unread ? `<span class="pip">${unread > 99 ? '99+' : unread}</span>` : ''}</button>`;
    put(
      'rail',
      srv('home', 'Direktnachrichten & Freunde', ICON.home, `home ${homeActive() ? 'on' : ''}`, dmUnread) +
        '<i class="sep"></i>' +
        srv('lobby', 'Hub-Lobby', ICON.globe, data.active === 'lobby' ? 'on' : '', lobby?.unread || 0) +
        rooms.map((c) => srv(c.id, c.name, esc(c.name.slice(0, 2).toUpperCase()), data.active === c.id ? 'on' : '', c.unread || 0)).join('') +
        srv('add', 'Raum erstellen oder beitreten', ICON.plus, 'add', 0) +
        '<i class="grow"></i>' +
        srv('settings', 'Chat-Einstellungen', ICON.gear, '', 0),
    );
  }

  function renderMe() {
    put('me', `${C ? C.avatarHtml(myCos, 34) : avatar(data.me.name, data.me.color, 34)}<div class="grow"><b ${C ? C.nameStyle(myCos) : ''}>${esc(data.me.name)}</b><small>Code <span class="code">${data.me.code}</span></small></div><button id="open-settings" title="Einstellungen">${ICON.gear}</button>`);
  }

  function lastLine(c) {
    const last = c.msgs[c.msgs.length - 1];
    return last ? `${last.me ? 'Du: ' : ''}${last.text || '📷 Bild'}` : 'Noch keine Nachrichten';
  }

  function renderList() {
    if (homeActive()) {
      const dms = data.chats.filter((c) => c.kind === 'dm').sort((a, b) => (b.msgs.at(-1)?.at || 0) - (a.msgs.at(-1)?.at || 0));
      put('side-top', '<b>Direktnachrichten</b><small>Freunde und Gegner aus Spielen</small>');
      put(
        'list',
        `<button class="item ${data.active === 'friends' ? 'on' : ''}" data-chat="friends"><span class="hash">${ICON.users}</span><div class="grow"><b>Freunde</b></div>${data.requests.length ? `<span class="badge">${data.requests.length}</span>` : ''}</button>
        <div class="cat">Direktnachrichten<button data-act="add-dm" title="Neue Nachricht">＋</button></div>` +
          (dms.length
            ? dms.map((c) => `<button class="item ${c.id === data.active ? 'on' : ''} ${c.unread ? 'unread' : ''}" data-chat="${esc(c.id)}">${cosAvatar(c.cos, c.name, c.color, 32)}<div class="grow"><b>${esc(c.name)}</b><small>${esc(lastLine(c))}</small></div>${c.unread ? `<span class="badge">${c.unread}</span>` : ''}</button>`).join('')
            : '<p class="hint" style="padding:0 8px">Noch keine Direktnachrichten. Füge einen Freund per Code hinzu oder schreib einem Gegner direkt aus dem Spiel.</p>'),
      );
      return;
    }
    const c = chatById(data.active);
    if (!c) return;
    put('side-top', `<b>${esc(c.name)}</b><small>${c.kind === 'public' ? 'Öffentlich für alle Hub-Nutzer' : `Raum „${esc(c.key)}“`}</small>`);
    put('list', `<div class="cat">Textkanäle</div><button class="item on ${c.unread ? 'unread' : ''}" data-chat="${esc(c.id)}"><span class="hash">#</span><div class="grow"><b>allgemein</b></div></button>${c.kind === 'room' ? '<div class="cat">Raum</div><button class="item" data-act="leave-room"><span class="hash">⎋</span><div class="grow"><b>Raum verlassen</b></div></button>' : ''}`);
  }

  function renderHead() {
    if (data.active === 'friends') {
      put('head', `<span class="hash">${ICON.users}</span><div class="grow"><b>Freunde</b><small>${data.friends.length} Freund${data.friends.length === 1 ? '' : 'e'}</small></div>`);
      return;
    }
    const c = chatById(data.active);
    if (!c) return;
    const e = rooms.get(c.id);
    const peers = e?.room?.peers.size || 0;
    const status = e?.failed ? '<span class="online">offline</span>' : c.kind === 'dm' ? `<span class="online ${peers ? 'on' : ''}"><i></i>${peers ? 'online' : 'nicht online'}</span>` : `<span class="online ${peers ? 'on' : ''}"><i></i>${peers + 1} online</span>`;
    const title = c.kind === 'dm' ? `${cosAvatar(c.cos, c.name, c.color, 26)}<b>${esc(c.name)}</b><small>Code ${esc(c.peer)}</small>` : `<span class="hash">#</span><b>allgemein</b><small>${esc(c.name)}</small>`;
    const tools = c.kind === 'dm' ? `${isFriend(c.peer) ? '' : '<button class="btn small" data-act="befriend">Freund hinzufügen</button>'}<button class="btn small ghost" data-act="remove-dm">Entfernen</button>` : '';
    put('head', `<div class="grow" style="display:flex;align-items:center;gap:8px">${title}</div>${status}${tools}`);
  }

  function renderMembers() {
    const dc = document.querySelector('.dc');
    const c = chatById(data.active);
    const show = c && c.kind !== 'dm';
    dc.classList.toggle('no-members', !show);
    if (!show) return;
    const peers = [...(rooms.get(c.id)?.room?.peers.values() || [])];
    put('members', `<div class="cat">Online – ${peers.length + 1}</div>
      <div class="mem"><span class="dotw">${C ? C.avatarHtml(myCos, 30) : avatar(data.me.name, data.me.color, 30)}</span><b ${C ? C.nameStyle(myCos) : ''}>${esc(data.me.name)}</b></div>
      ${peers.map((p) => `<div class="mem"><span class="dotw">${avatar(p.name, COLORS[(p.name || '').length % COLORS.length], 30)}</span><b>${esc(p.name)}</b></div>`).join('')}`);
  }

  const onlyEmoji = (t) => t && t.length <= 12 && /^(\p{Extended_Pictographic}|\p{Emoji_Component}|\s)+$/u.test(t);
  function renderMsgs(scroll) {
    if (data.active === 'friends') return renderFriends();
    const c = chatById(data.active);
    if (!c) return;
    if (c.unread) {
      c.unread = 0;
      pushUnread();
      renderRail();
    }
    if (!c.msgs.length) {
      put('msgs', `<div class="empty"><h2 style="margin:0 0 6px">${c.kind === 'dm' ? `Das ist der Anfang deines Chats mit ${esc(c.name)}` : `Willkommen in #allgemein`}</h2>${c.kind === 'public' ? 'Sag Hallo! Alle, die gerade im Hub-Chat sind, sehen das.' : 'Noch keine Nachrichten.'}<br><br><small>Nachrichten werden nur auf den Geräten gespeichert, die gerade verbunden sind.</small></div>`);
      return;
    }
    let html = '', prev = null, lastDay = '';
    for (const m of c.msgs) {
      const day = dayOf(m.at);
      if (day !== lastDay) {
        html += `<div class="day">${esc(day)}</div>`;
        lastDay = day;
        prev = null;
      }
      const cont = prev && prev.code === m.code && Boolean(prev.me) === Boolean(m.me) && m.at - prev.at < 5 * 60000;
      const cos = m.me ? myCos : m.cos;
      const body = `${m.text ? `<div class="txt ${onlyEmoji(m.text) ? 'big' : ''}">${esc(m.text)}</div>` : ''}${m.img ? (data.settings.images || m.me ? `<img class="att" src="${m.img}" alt="Bild" data-zoom="1" />` : '<button class="btn small ghost" data-show-img="1">Bild anzeigen</button>') : ''}`;
      if (cont) html += `<div class="line" data-id="${esc(m.id)}"><time>${hm(m.at)}</time>${body}</div>`;
      else html += `<div class="grp" data-id="${esc(m.id)}"><div class="avc">${cosAvatar(cos, m.from, m.color, 40)}</div><div><div class="hd"><b ${nameAttr(cos, m.color)}>${esc(m.me ? data.me.name : m.from)}</b>${cos && C ? C.titleHtml(cos) : ''}<time>${hm(m.at)}</time></div><div class="line">${body}</div></div></div>`;
      prev = m;
    }
    put('msgs', html);
    if (scroll) $('msgs').scrollTop = $('msgs').scrollHeight;
  }

  function renderFriends() {
    const req = data.requests.map((r) => `<div class="frow">${cosAvatar(r.cos, r.name, r.color, 36)}<div class="grow"><b>${esc(r.name)}</b><small>Möchte dein Freund sein${r.game ? ` · aus ${esc(r.game)}` : ''}</small></div><button class="btn small primary" data-req-ok="${esc(r.code)}">Annehmen</button><button class="btn small ghost" data-req-no="${esc(r.code)}">Ablehnen</button></div>`).join('');
    const fr = data.friends.map((f) => `<div class="frow">${cosAvatar(f.cos, f.name, f.color, 36)}<div class="grow"><b>${esc(f.name)}</b><small>Code ${esc(f.code)}</small></div><button class="btn small" data-friend-dm="${esc(f.code)}">Nachricht</button><button class="btn small ghost" data-friend-del="${esc(f.code)}">Entfernen</button></div>`).join('');
    put('msgs', `<div class="friends">
      <h3>Freund hinzufügen</h3>
      <div class="add-box"><input class="input" id="friend-code" maxlength="8" placeholder="8-stelliger Code deines Freundes" /><button class="btn primary" data-act="friend-add">Anfrage senden</button></div>
      <p class="hint" style="margin-top:-8px">Dein Code: <span class="code">${data.me.code}</span> – gib ihn deinem Freund. Im Spiel geht es noch einfacher: „Freund hinzufügen“ beim Gegner.</p>
      ${req ? `<h3>Anfragen – ${data.requests.length}</h3>${req}` : ''}
      <h3>Freunde – ${data.friends.length}</h3>${fr || '<p class="hint">Noch keine Freunde.</p>'}</div>`);
  }

  function renderAll() {
    renderRail();
    renderMe();
    renderList();
    renderHead();
    renderMembers();
    renderMsgs(true);
    $('compose').hidden = data.active === 'friends';
    pushUnread();
  }

  function open(id) {
    if (id !== 'friends' && !chatById(id)) id = 'lobby';
    data.active = id;
    save();
    renderAll();
    if (id !== 'friends') $('text').focus();
  }

  /* ---------------------------------------------------------------- Emojis */
  const EMOJI = {
    Häufig: '😀 😂 🤣 😊 😍 🥰 😎 🤔 😅 😭 😡 🥳 👍 👎 👏 🙏 🔥 💯 ❤️ 💀 👀 🎉 ✨ 😴',
    Gesichter: '😁 😆 😉 😋 😜 🤪 🤩 😏 😬 🙄 😮 😱 🤯 🥶 🥵 🤗 🤫 🤐 😇 🤡 👻 😈 🤖 👽',
    Gesten: '👋 🤝 ✌️ 🤞 🤟 🤘 👌 🤌 👈 👉 👆 👇 💪 🫡 🫶 🙌',
    Spiele: '🎮 🕹️ ♟️ 🎯 🏆 🥇 🥈 🥉 🎲 🧩 ⚽ 🏀 🎾 🏓 ⛏️ 🧱 🗺️ 🌍',
    Dinge: '💬 📷 🎵 🎧 📱 💻 ⌚ 🔔 💡 📌 ⏰ 💎 🍕 🍔 🍟 🍩 ☕ 🥤',
    Herzen: '❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 ❣️ 💕 💖',
  };
  function renderEmoji() {
    $('emoji-pop').innerHTML = Object.entries(EMOJI).map(([k, v]) => `<h6>${k}</h6><div class="grid">${v.split(' ').map((e) => `<button type="button" data-emo="${e}">${e}</button>`).join('')}</div>`).join('');
  }
  function insertAtCursor(t) {
    const el = $('text');
    const a = el.selectionStart ?? el.value.length, b = el.selectionEnd ?? el.value.length;
    el.value = el.value.slice(0, a) + t + el.value.slice(b);
    el.focus();
    el.selectionStart = el.selectionEnd = a + t.length;
  }

  /* ---------------------------------------------------------------- Dialoge */
  function modal(html, onClick, cls = '') {
    $('modal').className = `modal glass ${cls}`;
    $('modal').innerHTML = html;
    $('modal-back').hidden = false;
    $('modal').onclick = onClick || null;
  }
  const close = () => ($('modal-back').hidden = true);

  function nameModal() {
    modal(
      `<h2>Willkommen bei den Chats</h2>
       <div class="field"><label>Anzeigename (gilt für den ganzen Hub)</label><input class="input" id="nm" maxlength="16" value="${esc(data.me?.name || '')}" /></div>
       <p class="hint">Chats sind nicht verschlüsselt. Nutze keinen echten vollen Namen, wenn du das nicht möchtest.</p>
       <div class="err" id="nm-err"></div><div class="btns"><button class="btn primary" data-ok="1">Los geht’s</button></div>`,
      (e) => {
        if (!e.target.closest('[data-ok]')) return;
        const v = $('nm').value.trim();
        if (v.length < 2) return ($('nm-err').textContent = 'Mindestens 2 Zeichen.');
        data.me.name = v;
        HP?.name(v).catch(() => {});
        save();
        close();
        start();
      },
    );
  }

  function settingsModal() {
    const s = data.settings;
    const row = (k, t, d) => `<div class="set-row"><div class="grow"><b>${t}</b><small>${d}</small></div><button class="switch ${s[k] ? 'on' : ''}" data-set="${k}"></button></div>`;
    modal(
      `<h2>Chat-Einstellungen</h2>
       <div class="field"><label>Name</label><div style="display:flex;gap:8px"><input class="input" id="set-name" maxlength="16" value="${esc(data.me.name)}" style="flex:1" /><button class="btn" data-set-act="name">Speichern</button></div><span class="hint">Derselbe Name wie im ganzen Hub, in Schach und Geo.</span></div>
       <div class="field"><label>Dein Code</label><span class="code" style="font-size:16px">${data.me.code}</span> <button class="btn small ghost" data-set-act="copy">Kopieren</button></div>
       ${row('allowGameDMs', 'Gegner aus Spielen dürfen mir schreiben', 'In Schach, Geo usw. sehen andere den Knopf „Nachricht“. Aus = nur Freunde können dir schreiben.')}
       ${row('allowFriendReq', 'Freundschaftsanfragen aus Spielen', 'Gegner können dich direkt im Spiel als Freund hinzufügen.')}
       ${row('notify', 'Benachrichtigungen', 'Neue Nachrichten in der Dynamic Island und roter Punkt am App-Symbol.')}
       ${row('images', 'Bilder automatisch anzeigen', 'Aus = Bilder erst auf Klick zeigen.')}
       <div class="set-row"><div class="grow"><b>Verlauf löschen</b><small>Löscht alle Nachrichten auf diesem PC.</small></div><button class="btn small ghost" data-set-act="clear">Löschen</button></div>
       <div class="btns"><button class="btn primary" data-set-act="close">Fertig</button></div>`,
      (e) => {
        const t = e.target.closest('[data-set]');
        if (t) {
          s[t.dataset.set] = !s[t.dataset.set];
          t.classList.toggle('on', s[t.dataset.set]);
          save();
          pushIdentity();
          return;
        }
        const a = e.target.closest('[data-set-act]')?.dataset.setAct;
        if (a === 'close') return close();
        if (a === 'copy') {
          navigator.clipboard?.writeText(data.me.code);
          return toast('Code kopiert.');
        }
        if (a === 'name') {
          const v = $('set-name').value.trim();
          if (v.length < 2) return toast('Mindestens 2 Zeichen.');
          data.me.name = v;
          HP?.name(v).catch(() => {});
          save();
          pushIdentity();
          renderAll();
          return toast('Name gespeichert – gilt im ganzen Hub.');
        }
        if (a === 'clear') {
          for (const c of data.chats) c.msgs = [];
          save();
          renderAll();
          return toast('Verlauf gelöscht.');
        }
      },
    );
  }

  function roomModal() {
    modal(
      `<h2>Raum erstellen oder beitreten</h2>
       <div class="field"><label>Raumname</label><input class="input" id="rm" maxlength="24" placeholder="z. B. FortniteSquad" /><span class="hint">Jeder, der denselben Raumnamen eingibt, ist im selben Raum. Wähle einen ungewöhnlichen Namen.</span></div>
       <div class="err" id="add-err"></div><div class="btns"><button class="btn ghost" data-add="close">Abbrechen</button><button class="btn primary" data-add="room">Beitreten</button></div>`,
      (e) => {
        const a = e.target.closest('[data-add]')?.dataset.add;
        if (a === 'close') return close();
        if (a !== 'room') return;
        const key = roomCode($('rm').value);
        if (key.length < 3) return ($('add-err').textContent = 'Mindestens 3 Buchstaben oder Zahlen.');
        let chat = data.chats.find((c) => c.kind === 'room' && c.key === key);
        if (!chat) {
          chat = { id: `room-${key}`, kind: 'room', name: $('rm').value.trim().slice(0, 24), key, msgs: [], unread: 0 };
          data.chats.push(chat);
          connect(chat);
        }
        close();
        open(chat.id);
      },
    );
    setTimeout(() => $('rm')?.focus(), 40);
  }

  function friendRequest(code, game = '') {
    code = String(code || '').trim().toUpperCase();
    if (!isCode(code)) return toast('Der Code hat 8 Zeichen.');
    if (code === data.me.code) return toast('Das ist dein eigener Code.');
    if (isFriend(code)) return toast('Ihr seid schon Freunde.');
    inboxSend(code, 'friend-req', { game });
    toast('Freundschaftsanfrage gesendet.');
  }

  /** Aus einem Spiel: Nachricht an den Gegner oder Freundschaftsanfrage. */
  function onGameRequest(item) {
    if (!item || !isCode(item.code) || item.code === data.me.code) return;
    if (item.kind === 'friend') return friendRequest(item.code, item.game);
    const chat = ensureDm({ code: item.code, name: item.name, cos: cleanCos(item.cos) });
    inboxSend(item.code, 'dm-hello', { src: 'game', game: item.game });
    save();
    open(chat.id);
  }

  /* ----------------------------------------------------------------- Events */
  document.addEventListener('click', (e) => {
    const t = e.target;
    const srv = t.closest('[data-srv]')?.dataset.srv;
    if (srv) {
      if (srv === 'home') return open(data.chats.find((c) => c.kind === 'dm' && c.unread)?.id || (homeActive() ? data.active : 'friends'));
      if (srv === 'add') return roomModal();
      if (srv === 'settings') return settingsModal();
      return open(srv);
    }
    if (t.closest('#open-settings')) return settingsModal();
    const ch = t.closest('[data-chat]')?.dataset.chat;
    if (ch) return open(ch);
    const act = t.closest('[data-act]')?.dataset.act;
    if (act === 'add-dm') return open('friends');
    if (act === 'friend-add') return friendRequest($('friend-code')?.value);
    if (act === 'leave-room' || act === 'remove-dm') {
      const id = data.active;
      rooms.get(id)?.room?.leave();
      rooms.delete(id);
      data.chats = data.chats.filter((c) => c.id !== id);
      return open(act === 'remove-dm' ? 'friends' : 'lobby');
    }
    if (act === 'befriend') return friendRequest(chatById(data.active)?.peer);
    const ok = t.closest('[data-req-ok]')?.dataset.reqOk;
    if (ok) {
      const r = data.requests.find((x) => x.code === ok);
      if (r) {
        addFriend(r);
        inboxSend(ok, 'friend-ok');
        save();
        renderAll();
        toast(`${r.name} ist jetzt dein Freund.`);
      }
      return;
    }
    const no = t.closest('[data-req-no]')?.dataset.reqNo;
    if (no) {
      data.requests = data.requests.filter((x) => x.code !== no);
      save();
      return renderAll();
    }
    const fdm = t.closest('[data-friend-dm]')?.dataset.friendDm;
    if (fdm) {
      const f = data.friends.find((x) => x.code === fdm);
      return open(ensureDm(f).id);
    }
    const fdel = t.closest('[data-friend-del]')?.dataset.friendDel;
    if (fdel) {
      data.friends = data.friends.filter((x) => x.code !== fdel);
      save();
      return renderAll();
    }
    if (t.closest('[data-zoom]')) return modal(`<img src="${t.src}" alt="" />`, () => close(), 'img');
    if (t.closest('[data-show-img]')) {
      data.settings.images = true;
      return renderMsgs(false);
    }
    const emo = t.closest('[data-emo]')?.dataset.emo;
    if (emo) return insertAtCursor(emo);
    if (t.closest('#pick-emoji')) {
      if (!$('emoji-pop').innerHTML) renderEmoji();
      $('emoji-pop').hidden = !$('emoji-pop').hidden;
      return;
    }
    if (!t.closest('#emoji-pop')) $('emoji-pop').hidden = true;
    if (t.closest('#pick-img')) return $('file').click();
  });
  $('file').addEventListener('change', () => {
    const f = $('file').files[0];
    $('file').value = '';
    if (f) sendImage(f);
  });
  $('text').addEventListener('paste', (e) => {
    const f = [...(e.clipboardData?.files || [])].find((x) => /^image\//.test(x.type));
    if (f) {
      e.preventDefault();
      sendImage(f);
    }
  });
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => {
    e.preventDefault();
    const f = [...(e.dataTransfer?.files || [])].find((x) => /^image\//.test(x.type));
    if (f && data.active !== 'friends') sendImage(f);
  });
  $('compose').addEventListener('submit', (e) => {
    e.preventDefault();
    const now = Date.now();
    if (now - (send.last || 0) < 600) return; // kleiner Spam-Schutz
    send.last = now;
    send($('text').value);
    $('text').value = '';
    $('emoji-pop').hidden = true;
  });
  $('modal-back').addEventListener('mousedown', (e) => {
    if (e.target === $('modal-back') && data.me?.name) close();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('modal-back').hidden && data.me?.name) close();
    if (e.key === 'Enter' && e.target.id === 'friend-code') friendRequest(e.target.value);
  });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && data.active !== 'friends') renderMsgs(false);
  });

  function applyHub(hp) {
    if (!hp || !data.me) return;
    myCos = hp.cos?.eq || {};
    if (hp.name && hp.name !== data.me.name) {
      data.me.name = hp.name;
      save();
      pushIdentity();
    }
    renderMe();
    renderMembers();
    if (data.active !== 'friends') renderMsgs(false);
  }
  window.addEventListener('hub-profile', (e) => applyHub(e.detail));

  let started = false;
  function start() {
    if (started) return;
    started = true;
    if (!data.chats.some((c) => c.id === 'lobby')) data.chats.unshift({ id: 'lobby', kind: 'public', name: 'Hub-Lobby', msgs: [], unread: 0 });
    for (const c of data.chats) for (const m of c.msgs) seen.add(m.id);
    pushIdentity();
    open(data.active || 'lobby');
    for (const c of data.chats) connect(c);
    connectInbox();
    api.onGameRequest?.(onGameRequest);
    api.pending?.().then((list) => (list || []).forEach(onGameRequest)).catch(() => {});
  }

  (async () => {
    const saved = await api.load().catch(() => null);
    if (saved?.me) data = { ...data, ...saved };
    data.settings = { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
    for (const k of ['friends', 'requests', 'blocked']) if (!Array.isArray(data[k])) data[k] = [];
    if (!data.me) data.me = { name: '', code: newCode(), color: COLORS[Math.floor(Math.random() * COLORS.length)] };
    // Ein Name für den ganzen Hub
    const hp = await HP?.get().catch(() => null);
    if (hp) {
      myCos = hp.cos?.eq || {};
      if (hp.name) data.me.name = hp.name;
      else if (data.me.name) HP.name(data.me.name).catch(() => {});
    }
    if (!data.me.name) nameModal();
    else start();
  })();

  window.ChatUI = { state: () => data, rooms, send, open, onGameRequest };
})();
