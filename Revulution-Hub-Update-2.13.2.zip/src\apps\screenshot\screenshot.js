'use strict';

const $ = (selector) => document.querySelector(selector);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
const api = window.shots;
const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}?v=${Date.now()}`;

const TOOLS = [
  ['arrow', 'Pfeil', '<path d="M5 19 19 5M9 5h10v10"/>'],
  ['rect', 'Rechteck', '<rect x="4" y="6" width="16" height="12" rx="2"/>'],
  ['ellipse', 'Kreis', '<ellipse cx="12" cy="12" rx="8.5" ry="6.5"/>'],
  ['pen', 'Stift', '<path d="M4 20l4-1L19 8l-3-3L5 16Z"/>'],
  ['marker', 'Textmarker', '<path d="M9 15l-3 5h7l1-2M9 15l6-11 4 2-6 11Z"/>'],
  ['text', 'Text', '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>'],
  ['step', 'Nummer', '<circle cx="12" cy="12" r="8.5"/><path d="M11 9l2-1v8"/>'],
  ['blur', 'Verpixeln', '<path d="M4 4h4v4H4zM12 4h4v4h-4zM8 8h4v4H8zM16 8h4v4h-4zM4 12h4v4H4zM12 12h4v4h-4zM8 16h4v4H8zM16 16h4v4h-4z"/>'],
  ['crop', 'Zuschneiden', '<path d="M6 2v14a2 2 0 0 0 2 2h14M18 22V8a2 2 0 0 0-2-2H2"/>'],
];
const COLORS = ['#ff4d5e', '#ffb547', '#3ddc97', '#38bdf8', '#8b6cff', '#ffffff', '#111111'];
const svg = (inner, size = 18) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;

const canvas = $('#canvas');
const g = canvas.getContext('2d');
const editor = {
  file: null,
  base: null, // HTMLImageElement or canvas
  shapes: [],
  undo: [],
  redo: [],
  tool: 'arrow',
  color: COLORS[0],
  width: 4,
  draft: null,
  dirty: false,
};
let settings = null;
let list = [];

/* ------------------------------------------------------------------ helpers */
function toast(message, kind = '') {
  document.querySelector('.toast')?.remove();
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = String(message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  document.body.appendChild(el);
  setTimeout(() => el.remove(), kind === 'error' ? 6000 : 2800);
}

const pretty = (accel) => String(accel || '–').replace('CommandOrControl', 'Strg').replace('Shift', 'Umschalt').replace(/\+/g, ' + ');

/* ------------------------------------------------------------------ drawing */
function arrowHead(ctx, x1, y1, x2, y2, size) {
  const angle = Math.atan2(y2 - y1, x2 - x1);
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - size * Math.cos(angle - Math.PI / 7), y2 - size * Math.sin(angle - Math.PI / 7));
  ctx.lineTo(x2 - size * Math.cos(angle + Math.PI / 7), y2 - size * Math.sin(angle + Math.PI / 7));
  ctx.closePath();
  ctx.fill();
}

function pixelate(ctx, source, r) {
  const x = Math.round(Math.min(r.x1, r.x2));
  const y = Math.round(Math.min(r.y1, r.y2));
  const w = Math.round(Math.abs(r.x2 - r.x1));
  const h = Math.round(Math.abs(r.y2 - r.y1));
  if (w < 2 || h < 2) return;
  const block = Math.max(6, Math.round(Math.min(source.width, source.height) / 80));
  const small = document.createElement('canvas');
  small.width = Math.max(1, Math.ceil(w / block));
  small.height = Math.max(1, Math.ceil(h / block));
  const sg = small.getContext('2d');
  sg.drawImage(source, x, y, w, h, 0, 0, small.width, small.height);
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(small, 0, 0, small.width, small.height, x, y, w, h);
  ctx.restore();
}

function drawShape(ctx, s, source) {
  ctx.save();
  ctx.strokeStyle = s.color;
  ctx.fillStyle = s.color;
  ctx.lineWidth = s.width;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (s.type === 'arrow') {
    ctx.beginPath();
    ctx.moveTo(s.x1, s.y1);
    ctx.lineTo(s.x2, s.y2);
    ctx.stroke();
    arrowHead(ctx, s.x1, s.y1, s.x2, s.y2, Math.max(12, s.width * 4));
  } else if (s.type === 'rect') {
    ctx.strokeRect(Math.min(s.x1, s.x2), Math.min(s.y1, s.y2), Math.abs(s.x2 - s.x1), Math.abs(s.y2 - s.y1));
  } else if (s.type === 'ellipse') {
    ctx.beginPath();
    ctx.ellipse((s.x1 + s.x2) / 2, (s.y1 + s.y2) / 2, Math.abs(s.x2 - s.x1) / 2, Math.abs(s.y2 - s.y1) / 2, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (s.type === 'pen' || s.type === 'marker') {
    if (s.type === 'marker') {
      ctx.globalAlpha = 0.38;
      ctx.lineWidth = s.width * 4;
      ctx.lineCap = 'square';
    }
    ctx.beginPath();
    s.points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.stroke();
  } else if (s.type === 'text') {
    ctx.font = `700 ${s.size}px "Segoe UI", sans-serif`;
    ctx.textBaseline = 'top';
    ctx.lineWidth = Math.max(3, s.size / 7);
    ctx.strokeStyle = s.color === '#111111' ? 'rgba(255,255,255,.85)' : 'rgba(0,0,0,.55)';
    ctx.strokeText(s.text, s.x, s.y);
    ctx.fillText(s.text, s.x, s.y);
  } else if (s.type === 'step') {
    const r = Math.max(14, s.width * 4);
    ctx.beginPath();
    ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = s.color === '#ffffff' ? '#111' : '#fff';
    ctx.font = `800 ${Math.round(r * 1.1)}px "Segoe UI", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(s.n), s.x, s.y + 1);
  } else if (s.type === 'blur') {
    pixelate(ctx, source, s);
  } else if (s.type === 'crop') {
    ctx.setLineDash([8, 6]);
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#fff';
    ctx.strokeRect(Math.min(s.x1, s.x2), Math.min(s.y1, s.y2), Math.abs(s.x2 - s.x1), Math.abs(s.y2 - s.y1));
  }
  ctx.restore();
}

/** Composite: base image plus every shape (pixelation reads from the image below it). */
function composite(target, includeDraft) {
  const ctx = target.getContext('2d');
  ctx.clearRect(0, 0, target.width, target.height);
  ctx.drawImage(editor.base, 0, 0);
  const shapes = includeDraft && editor.draft ? [...editor.shapes, editor.draft] : editor.shapes;
  for (const s of shapes) drawShape(ctx, s, target);
}

function render() {
  if (!editor.base) return;
  composite(canvas, true);
}

function exportUrl() {
  const out = document.createElement('canvas');
  out.width = editor.base.width;
  out.height = editor.base.height;
  composite(out, false);
  return out.toDataURL('image/png');
}

/* ---------------------------------------------------------------- open file */
async function open(file) {
  let src;
  try {
    src = await api.read(file);
  } catch (error) {
    return toast(error.message || error, 'error');
  }
  const img = new Image();
  img.onload = () => {
    editor.file = file;
    editor.base = img;
    editor.shapes = [];
    editor.undo = [];
    editor.redo = [];
    editor.dirty = false;
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    canvas.hidden = false;
    $('#placeholder').hidden = true;
    render();
    renderToolbar();
    renderGallery();
  };
  img.onerror = () => toast('Bild konnte nicht geöffnet werden.', 'error');
  img.src = src;
}

/* -------------------------------------------------------------------- input */
function point(event) {
  const r = canvas.getBoundingClientRect();
  return [((event.clientX - r.left) / r.width) * canvas.width, ((event.clientY - r.top) / r.height) * canvas.height];
}

const scaleFactor = () => canvas.width / canvas.getBoundingClientRect().width;

function commit(shape) {
  editor.undo.push({ base: editor.base, shapes: editor.shapes.slice() });
  editor.redo = [];
  editor.shapes = [...editor.shapes, shape];
  editor.dirty = true;
  renderToolbar();
}

canvas.addEventListener('pointerdown', (event) => {
  if (!editor.base || event.button !== 0) return;
  const [x, y] = point(event);
  const width = editor.width * scaleFactor();
  if (editor.tool === 'text') return startText(event, x, y);
  if (editor.tool === 'step') {
    const n = editor.shapes.filter((s) => s.type === 'step').length + 1;
    commit({ type: 'step', x, y, n, color: editor.color, width });
    return render();
  }
  canvas.setPointerCapture(event.pointerId);
  editor.draft = editor.tool === 'pen' || editor.tool === 'marker'
    ? { type: editor.tool, points: [[x, y]], color: editor.color, width }
    : { type: editor.tool, x1: x, y1: y, x2: x, y2: y, color: editor.color, width };
});

canvas.addEventListener('pointermove', (event) => {
  if (!editor.draft) return;
  const [x, y] = point(event);
  if (editor.draft.points) editor.draft.points.push([x, y]);
  else {
    editor.draft.x2 = x;
    editor.draft.y2 = y;
    if (event.shiftKey && (editor.draft.type === 'rect' || editor.draft.type === 'ellipse')) {
      const d = Math.max(Math.abs(x - editor.draft.x1), Math.abs(y - editor.draft.y1));
      editor.draft.x2 = editor.draft.x1 + Math.sign(x - editor.draft.x1 || 1) * d;
      editor.draft.y2 = editor.draft.y1 + Math.sign(y - editor.draft.y1 || 1) * d;
    }
  }
  render();
});

canvas.addEventListener('pointerup', () => {
  const draft = editor.draft;
  editor.draft = null;
  if (!draft) return;
  const tiny = draft.points ? draft.points.length < 2 : Math.abs(draft.x2 - draft.x1) < 3 && Math.abs(draft.y2 - draft.y1) < 3;
  if (tiny) return render();
  if (draft.type === 'crop') return applyCrop(draft);
  commit(draft);
  render();
});

function applyCrop(r) {
  const x = Math.round(Math.min(r.x1, r.x2));
  const y = Math.round(Math.min(r.y1, r.y2));
  const w = Math.round(Math.abs(r.x2 - r.x1));
  const h = Math.round(Math.abs(r.y2 - r.y1));
  const full = document.createElement('canvas');
  full.width = editor.base.width;
  full.height = editor.base.height;
  composite(full, false);
  const cropped = document.createElement('canvas');
  cropped.width = w;
  cropped.height = h;
  cropped.getContext('2d').drawImage(full, x, y, w, h, 0, 0, w, h);
  editor.undo.push({ base: editor.base, shapes: editor.shapes.slice() });
  editor.redo = [];
  editor.base = cropped;
  editor.shapes = [];
  editor.dirty = true;
  canvas.width = w;
  canvas.height = h;
  editor.tool = 'arrow';
  render();
  renderToolbar();
}

function restore(snapshot) {
  editor.base = snapshot.base;
  editor.shapes = snapshot.shapes;
  canvas.width = editor.base.width || editor.base.naturalWidth;
  canvas.height = editor.base.height || editor.base.naturalHeight;
  render();
  renderToolbar();
}

function undo() {
  if (!editor.undo.length) return;
  editor.redo.push({ base: editor.base, shapes: editor.shapes.slice() });
  restore(editor.undo.pop());
  editor.dirty = true;
}

function redo() {
  if (!editor.redo.length) return;
  editor.undo.push({ base: editor.base, shapes: editor.shapes.slice() });
  restore(editor.redo.pop());
}

function startText(event, x, y) {
  const input = $('#text-input');
  const stage = $('#stage').getBoundingClientRect();
  input.hidden = false;
  input.value = '';
  input.style.left = `${event.clientX - stage.left}px`;
  input.style.top = `${event.clientY - stage.top - 16}px`;
  input.style.color = editor.color;
  input.focus();
  const done = (keep) => {
    input.hidden = true;
    input.onkeydown = null;
    input.onblur = null;
    if (keep && input.value.trim()) {
      commit({ type: 'text', x, y, text: input.value, color: editor.color, size: Math.round((14 + editor.width * 3) * scaleFactor()) });
      render();
    }
  };
  input.onkeydown = (e) => {
    if (e.key === 'Enter') done(true);
    if (e.key === 'Escape') done(false);
  };
  input.onblur = () => done(true);
}

/* ------------------------------------------------------------------ toolbar */
function renderToolbar() {
  const has = Boolean(editor.base);
  $('#toolbar').innerHTML = `
    ${TOOLS.map(([id, label, path]) => `<button class="btn icon ghost ${editor.tool === id ? 'on' : ''}" data-tool="${id}" title="${label}" ${has ? '' : 'disabled'}>${svg(path)}</button>`).join('')}
    <span class="sep"></span>
    ${COLORS.map((c) => `<button class="swatch ${editor.color === c ? 'on' : ''}" data-color="${c}" style="background:${c}" title="Farbe"></button>`).join('')}
    <span class="sep"></span>
    <select class="select" id="width" title="Strichstärke" style="width:96px">${[2, 4, 6, 10].map((w) => `<option value="${w}" ${editor.width === w ? 'selected' : ''}>${w === 2 ? 'Fein' : w === 4 ? 'Mittel' : w === 6 ? 'Kräftig' : 'Dick'}</option>`).join('')}</select>
    <span class="sep"></span>
    <button class="btn icon ghost" data-action="undo" title="Rückgängig (Strg+Z)" ${editor.undo.length ? '' : 'disabled'}>${icon('undo', 17)}</button>
    <button class="btn icon ghost" data-action="redo" title="Wiederholen (Strg+Y)" ${editor.redo.length ? '' : 'disabled'} style="transform:scaleX(-1)">${icon('undo', 17)}</button>
    <span class="spacer"></span>
    <button class="btn small" data-action="copy" ${has ? '' : 'disabled'}>Kopieren</button>
    <button class="btn small" data-action="save" ${has ? '' : 'disabled'}>Speichern</button>
    <button class="btn icon ghost" data-action="saveas" title="Speichern unter … (Strg+Umschalt+S)" ${has ? '' : 'disabled'}>${icon('download', 16)}</button>
    <button class="btn icon ghost" data-action="reveal" title="Im Ordner zeigen" ${has ? '' : 'disabled'}>${icon('folder', 16)}</button>
    <button class="btn icon ghost danger" data-action="delete" title="Löschen" ${has ? '' : 'disabled'}>${icon('trash', 16)}</button>`;
}

function renderGallery() {
  $('#gallery').innerHTML = list.length
    ? list.map((item) => `<button class="thumb ${item.file === editor.file ? 'on' : ''}" data-open="${esc(item.file)}" title="${esc(item.name)}"><img src="${fileUrl(item.file)}" alt="" loading="lazy" draggable="false" /></button>`).join('')
    : '<div class="muted" style="grid-column:1/-1">Noch keine Screenshots.</div>';
}

function renderSettings() {
  $('#opt-copy').classList.toggle('on', settings.autoCopy);
  $('#opt-editor').classList.toggle('on', settings.openEditor);
  $('#hotkey').textContent = settings.hotkey ? pretty(settings.hotkey) + (settings.registered ? '' : '  (belegt!)') : 'Kein Tastenkürzel';
  $('#folder').textContent = settings.folder;
  $('#folder').title = settings.folder;
  $('#ph-key').textContent = pretty(settings.hotkey);
}

async function refreshList() {
  list = await api.list();
  renderGallery();
}

/* ------------------------------------------------------------------ actions */
async function action(name) {
  try {
    if (name === 'capture') return api.capture();
    if (name === 'reveal-folder') return api.reveal(null);
    if (!editor.base) return;
    if (name === 'undo') return undo();
    if (name === 'redo') return redo();
    if (name === 'copy') {
      await api.copy(exportUrl());
      return toast('In die Zwischenablage kopiert.');
    }
    if (name === 'save') {
      await api.save(editor.file, exportUrl());
      editor.dirty = false;
      await refreshList();
      return toast('Gespeichert.');
    }
    if (name === 'saveas') {
      const target = await api.saveAs(editor.file.split(/[\\/]/).pop(), exportUrl());
      if (target) toast(`Gespeichert: ${target}`);
      return;
    }
    if (name === 'reveal') return api.reveal(editor.file);
    if (name === 'delete') {
      if (!confirm('Diesen Screenshot in den Papierkorb verschieben?')) return;
      await api.remove(editor.file);
      editor.base = null;
      editor.file = null;
      canvas.hidden = true;
      $('#placeholder').hidden = false;
      renderToolbar();
      await refreshList();
    }
  } catch (error) {
    toast(error.message || error, 'error');
  }
}

let recording = false;
function keyName(event) {
  const parts = [];
  if (event.ctrlKey) parts.push('CommandOrControl');
  if (event.altKey) parts.push('Alt');
  if (event.shiftKey) parts.push('Shift');
  const key = event.key.length === 1 ? event.key.toUpperCase() : event.key;
  if (['Control', 'Shift', 'Alt', 'Meta'].includes(key)) return null;
  if (!parts.length && !/^F\d+$|^PrintScreen$/.test(key)) return null;
  parts.push(key === ' ' ? 'Space' : key);
  return parts.join('+');
}

document.addEventListener('keydown', async (event) => {
  if (recording) {
    event.preventDefault();
    if (event.key === 'Escape') {
      recording = false;
      $('#hotkey').classList.remove('recording');
      return renderSettings();
    }
    const accel = keyName(event);
    if (!accel) return;
    recording = false;
    $('#hotkey').classList.remove('recording');
    settings = await api.setSettings({ hotkey: accel });
    renderSettings();
    toast(settings.hotkeyOk ? `Neues Tastenkürzel: ${pretty(accel)}` : 'Dieses Tastenkürzel ist schon belegt.', settings.hotkeyOk ? '' : 'error');
    return;
  }
  if (event.target.tagName === 'INPUT' || event.target.tagName === 'SELECT') return;
  if (event.ctrlKey && event.key.toLowerCase() === 'z') action('undo');
  else if (event.ctrlKey && event.key.toLowerCase() === 'y') action('redo');
  else if (event.ctrlKey && event.key.toLowerCase() === 'c') action('copy');
  else if (event.ctrlKey && event.key.toLowerCase() === 's') action(event.shiftKey ? 'saveas' : 'save');
});

document.addEventListener('click', async (event) => {
  const el = event.target.closest('button');
  if (!el) return;
  if (el.dataset.tool) {
    editor.tool = el.dataset.tool;
    renderToolbar();
  } else if (el.dataset.color) {
    editor.color = el.dataset.color;
    renderToolbar();
  } else if (el.dataset.action) action(el.dataset.action);
  else if (el.dataset.open) {
    if (editor.dirty && !confirm('Ungespeicherte Änderungen verwerfen?')) return;
    open(el.dataset.open);
  } else if (el.id === 'opt-copy') {
    settings = await api.setSettings({ autoCopy: !settings.autoCopy });
    renderSettings();
  } else if (el.id === 'opt-editor') {
    settings = await api.setSettings({ openEditor: !settings.openEditor });
    renderSettings();
  } else if (el.id === 'hotkey') {
    recording = true;
    el.classList.add('recording');
    el.textContent = 'Tasten drücken … (Esc = abbrechen)';
  } else if (el.id === 'folder') {
    settings = await api.chooseFolder();
    renderSettings();
    refreshList();
  }
});

document.addEventListener('change', (event) => {
  if (event.target.id === 'width') editor.width = Number(event.target.value);
});

api.onCaptured(async ({ file }) => {
  await refreshList();
  if (!editor.dirty) open(file);
});

api.onVisibility(async (shown) => {
  if (!shown) return;
  const file = await api.pending();
  await refreshList();
  if (file && file !== editor.file && !editor.dirty) open(file);
});

(async () => {
  $('#capture-btn').innerHTML = `${icon('camera', 18)} Neuer Screenshot`;
  $('#ph-capture').innerHTML = `${icon('camera', 17)} Neuer Screenshot`;
  $('#ph-icon').innerHTML = icon('camera', 34);
  $('#open-folder').innerHTML = icon('folder', 15);
  settings = await api.settings();
  renderSettings();
  renderToolbar();
  await refreshList();
  const file = await api.pending();
  if (file) open(file);
})();
