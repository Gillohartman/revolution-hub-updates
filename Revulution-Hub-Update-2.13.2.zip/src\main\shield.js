'use strict';

/*
 * Schutz: Tracker-Erkennung und Virenschutz.
 *   – Tracker: liest die offenen Verbindungen aller Programme, gleicht sie mit den Servern
 *     bekannter Tracker ab und ortet die Gegenstellen (für die Weltkarte). Neue Tracker
 *     werden als Meldung angezeigt.
 *   – Viren: nutzt den eingebauten Microsoft Defender (Status, Schnell-/Datei-Scan, Signaturen).
 */
const { execFile } = require('child_process');
const { net } = require('electron');

// Domain-Endung → [Firma, Art]
const TRACKERS = {
  'doubleclick.net': ['Google', 'Werbung'], 'googlesyndication.com': ['Google', 'Werbung'], 'googleadservices.com': ['Google', 'Werbung'], 'google-analytics.com': ['Google', 'Analyse'],
  'googletagmanager.com': ['Google', 'Analyse'], 'app-measurement.com': ['Google', 'Analyse'], 'crashlytics.com': ['Google', 'Telemetrie'],
  'facebook.net': ['Meta', 'Werbung'], 'pixel.facebook.com': ['Meta', 'Werbung'],
  'telemetry.microsoft.com': ['Microsoft', 'Telemetrie'], 'events.data.microsoft.com': ['Microsoft', 'Telemetrie'], 'vortex.data.microsoft.com': ['Microsoft', 'Telemetrie'], 'pipe.aria.microsoft.com': ['Microsoft', 'Telemetrie'],
  'bat.bing.com': ['Microsoft', 'Werbung'], 'clarity.ms': ['Microsoft', 'Analyse'], 'ads.linkedin.com': ['LinkedIn', 'Werbung'],
  'amazon-adsystem.com': ['Amazon', 'Werbung'], 'adnxs.com': ['Xandr', 'Werbung'], 'criteo.com': ['Criteo', 'Werbung'], 'criteo.net': ['Criteo', 'Werbung'], 'taboola.com': ['Taboola', 'Werbung'], 'outbrain.com': ['Outbrain', 'Werbung'],
  'rubiconproject.com': ['Magnite', 'Werbung'], 'pubmatic.com': ['PubMatic', 'Werbung'], 'openx.net': ['OpenX', 'Werbung'], 'casalemedia.com': ['Index Exchange', 'Werbung'], 'moatads.com': ['Oracle', 'Werbung'],
  'scorecardresearch.com': ['Comscore', 'Analyse'], 'quantserve.com': ['Quantcast', 'Analyse'], 'hotjar.com': ['Hotjar', 'Analyse'], 'mixpanel.com': ['Mixpanel', 'Analyse'], 'segment.io': ['Twilio Segment', 'Analyse'],
  'segment.com': ['Twilio Segment', 'Analyse'], 'amplitude.com': ['Amplitude', 'Analyse'], 'optimizely.com': ['Optimizely', 'Analyse'], 'chartbeat.net': ['Chartbeat', 'Analyse'],
  'branch.io': ['Branch', 'Analyse'], 'appsflyer.com': ['AppsFlyer', 'Analyse'], 'adjust.com': ['Adjust', 'Analyse'], 'demdex.net': ['Adobe', 'Werbung'],
  'newrelic.com': ['New Relic', 'Telemetrie'], 'nr-data.net': ['New Relic', 'Telemetrie'], 'sentry.io': ['Sentry', 'Telemetrie'], 'bugsnag.com': ['Bugsnag', 'Telemetrie'], 'datadoghq.com': ['Datadog', 'Telemetrie'],
  'analytics.tiktok.com': ['TikTok', 'Analyse'], 'ads.tiktok.com': ['TikTok', 'Werbung'], 'analytics.twitter.com': ['X', 'Analyse'], 'ads-twitter.com': ['X', 'Werbung'], 'mc.yandex.ru': ['Yandex', 'Analyse'],
  'analytics.cloud.unity3d.com': ['Unity', 'Analyse'], 'unityads.unity3d.com': ['Unity', 'Werbung'], 'datarouter.ol.epicgames.com': ['Epic Games', 'Telemetrie'], 'events.gfe.nvidia.com': ['NVIDIA', 'Telemetrie'],
  'gfwsl.geforce.com': ['NVIDIA', 'Telemetrie'], 'statcounter.com': ['StatCounter', 'Analyse'], 'adsrvr.org': ['The Trade Desk', 'Werbung'], 'bidswitch.net': ['BidSwitch', 'Werbung'], 'adform.net': ['Adform', 'Werbung'],
  'bluekai.com': ['Oracle', 'Werbung'], 'krxd.net': ['Salesforce', 'Werbung'], 'exelator.com': ['Nielsen', 'Werbung'],
};

// Konkrete Server bekannter Tracker (werden aufgelöst und mit den offenen Verbindungen verglichen)
const HOSTS = ['stats.g.doubleclick.net', 'ad.doubleclick.net', 'googleads.g.doubleclick.net', 'pagead2.googlesyndication.com', 'www.googleadservices.com', 'www.google-analytics.com', 'www.googletagmanager.com', 'app-measurement.com',
  'connect.facebook.net', 'pixel.facebook.com', 'v10.events.data.microsoft.com', 'vortex.data.microsoft.com', 'mobile.events.data.microsoft.com', 'browser.pipe.aria.microsoft.com', 'bat.bing.com', 'www.clarity.ms', 'px.ads.linkedin.com',
  'aax.amazon-adsystem.com', 'c.amazon-adsystem.com', 'ib.adnxs.com', 'secure.adnxs.com', 'static.criteo.net', 'bidder.criteo.com', 'dis.criteo.com', 'trc.taboola.com', 'cdn.taboola.com', 'widgets.outbrain.com', 'log.outbrain.com',
  'fastlane.rubiconproject.com', 'ads.pubmatic.com', 'hbopenbid.pubmatic.com', 'rtb.openx.net', 'htlb.casalemedia.com', 'z.moatads.com', 'sb.scorecardresearch.com', 'pixel.quantserve.com', 'script.hotjar.com', 'in.hotjar.com',
  'api.mixpanel.com', 'api.segment.io', 'cdn.segment.com', 'api.amplitude.com', 'api2.amplitude.com', 'logx.optimizely.com', 'ping.chartbeat.net', 'api2.branch.io', 't.appsflyer.com', 'app.adjust.com', 'dpm.demdex.net',
  'bam.nr-data.net', 'js-agent.newrelic.com', 'o1.ingest.sentry.io', 'sessions.bugsnag.com', 'browser-intake-datadoghq.com', 'analytics.tiktok.com', 'ads.tiktok.com', 'analytics.twitter.com', 'static.ads-twitter.com', 'mc.yandex.ru',
  'analytics.cloud.unity3d.com', 'unityads.unity3d.com', 'datarouter.ol.epicgames.com', 'events.gfe.nvidia.com', 'gfwsl.geforce.com', 'match.adsrvr.org', 'insight.adsrvr.org', 'x.bidswitch.net', 'track.adform.net', 'tags.bluekai.com',
  'beacon.krxd.net', 'loadm.exelator.com', 'c.statcounter.com'];
const ADTECH = /criteo|taboola|outbrain|xandr|appnexus|trade desk|pubmatic|rubicon|magnite|openx|index exchange|quantcast|comscore|hotjar|mixpanel|amplitude|appsflyer|adjust gmbh|new relic|adform|bidswitch|iponweb|smart adserver|equativ|moat/i;
const PLATFORM = /google|meta platforms|facebook|microsoft|amazon|bytedance|tiktok|apple|twitter|linkedin/i;
// Diese Firmen teilen sich ihre Server mit normalen Diensten – ein Treffer ist dort nur „möglich“.
const SHARED = /^(google|meta|microsoft|amazon|linkedin|tiktok|x|nvidia|epic games|unity|adobe)$/i;

function match(domain) {
  const d = String(domain || '').toLowerCase().replace(/\.$/, '');
  if (!d) return null;
  for (const key of Object.keys(TRACKERS)) if (d === key || d.endsWith(`.${key}`)) return { key, company: TRACKERS[key][0], kind: TRACKERS[key][1] };
  return null;
}

function ps(script, timeout = 20000) {
  const encoded = Buffer.from(`$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.Encoding]::UTF8;${script}`, 'utf16le').toString('base64');
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve('');
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, timeout, maxBuffer: 8 * 1024 * 1024 }, (error, stdout) => resolve(error ? '' : String(stdout).trim()));
  });
}
const json = (text, fallback) => {
  try {
    const v = JSON.parse(text);
    return v == null ? fallback : v;
  } catch {
    return fallback;
  }
};
const list = (v) => (Array.isArray(v) ? v : v ? [v] : []);
const isPublic = (ip) => /^\d+\.\d+\.\d+\.\d+$/.test(ip) && !/^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|22[4-9]\.|2[3-5]\d\.)/.test(ip);

class Shield {
  constructor({ notify, getSettings }) {
    this.notify = notify;
    this.getSettings = getSettings;
    this.geo = new Map(); // ip → { lat, lon, country, city, org }
    this.seen = new Set(); // schon gemeldete Tracker (pro Sitzung)
    this.last = null;
    this.scanning = null;
    this.timer = null;
    this.busy = false;
    this.ipMap = null;
    this.ipAt = 0;
  }

  /** Hintergrund-Wache: alle paar Minuten prüfen und neue Tracker melden. */
  watch() {
    clearInterval(this.timer);
    this.timer = setInterval(() => {
      if (this.getSettings()?.watch === false) return;
      this.trackers({ quiet: false }).catch(() => {});
    }, 4 * 60 * 1000);
    setTimeout(() => this.getSettings()?.watch !== false && this.trackers({ quiet: false, first: true }).catch(() => {}), 60000);
  }

  async locate(ips) {
    const todo = ips.filter((ip) => !this.geo.has(ip)).slice(0, 40);
    await Promise.all(
      todo.map(async (ip) => {
        try {
          const res = await net.fetch(`https://ipwho.is/${ip}?fields=success,latitude,longitude,country,city,country_code,connection`, { headers: { 'User-Agent': 'Revolution-Hub' } });
          const j = await res.json();
          this.geo.set(ip, j && j.success ? { lat: j.latitude, lon: j.longitude, country: j.country || '', city: j.city || '', cc: j.country_code || '', org: j.connection?.org || j.connection?.isp || '' } : null);
        } catch {
          /* beim nächsten Mal erneut versuchen */
        }
      }),
    );
  }

  /** Adressen bekannter Tracker auflösen (alle 20 Minuten neu) – so erkennen wir sie an der Verbindung. */
  async trackerIps() {
    if (this.ipMap && Date.now() - this.ipAt < 20 * 60 * 1000) return this.ipMap;
    const dns = require('dns').promises;
    const map = new Map();
    await Promise.all(
      HOSTS.map(async (host) => {
        try {
          for (const ip of await dns.resolve4(host)) if (!map.has(ip)) map.set(ip, host);
        } catch {
          /* gibt es gerade nicht */
        }
      }),
    );
    this.ipMap = map;
    this.ipAt = Date.now();
    return map;
  }

  /** Tracker suchen: offene Verbindungen der Programme mit bekannten Trackern abgleichen und orten. */
  async trackers({ quiet = true, first = false } = {}) {
    if (this.busy) return this.last || { at: 0, items: [], links: [], connections: 0 };
    this.busy = true;
    try {
      const [out, ipMap] = await Promise.all([
        ps(
          `$dns = @(Get-DnsClientCache -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 1 } | Select-Object Entry, Data);` +
            `$con = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object { $_.RemoteAddress -notmatch ':' } | Select-Object RemoteAddress, OwningProcess);` +
            `$names = @{}; Get-Process | ForEach-Object { $names[[string]$_.Id] = $_.ProcessName };` +
            `@{ dns = $dns; con = @($con | ForEach-Object { @{ ip = $_.RemoteAddress; app = $names[[string]$_.OwningProcess] } }) } | ConvertTo-Json -Depth 4 -Compress`,
          25000,
        ),
        this.trackerIps(),
      ]);
      const data = json(out, { dns: [], con: [] });
      const dnsName = new Map();
      for (const row of list(data.dns)) if (row?.Data && row.Entry) dnsName.set(String(row.Data), String(row.Entry).toLowerCase());
      const byIp = new Map();
      for (const c of list(data.con)) {
        if (!c?.ip || !isPublic(c.ip)) continue;
        if (!byIp.has(c.ip)) byIp.set(c.ip, new Set());
        if (c.app) byIp.get(c.ip).add(c.app);
      }
      const ips = [...byIp.keys()];
      if (this.getSettings()?.locate !== false) await this.locate(ips);
      const links = [];
      const found = new Map();
      for (const ip of ips) {
        const g = this.geo.get(ip);
        const apps = [...byIp.get(ip)];
        const host = dnsName.get(ip) || ipMap.get(ip) || '';
        let hit = match(host);
        const org = g?.org || '';
        if (!hit && ADTECH.test(org)) hit = { key: org, company: org.replace(/,? (inc|llc|ltd|sa|gmbh)\.?$/i, ''), kind: 'Werbung' };
        const shared = Boolean(hit && SHARED.test(hit.company));
        const level = hit ? (shared ? 'platform' : 'tracker') : PLATFORM.test(org) ? 'platform' : 'normal';
        links.push({ ip, apps: apps.slice(0, 4), org, level, company: hit?.company || '', lat: g?.lat ?? null, lon: g?.lon ?? null, country: g?.country || '', city: g?.city || '', cc: g?.cc || '' });
        if (!hit) continue;
        const key = `${hit.company}|${hit.kind}`;
        const item = found.get(key) || { domain: hit.key, company: hit.company, kind: hit.kind, sure: !shared, apps: new Set(), places: [], hosts: new Set() };
        for (const a of apps) item.apps.add(a);
        if (host) item.hosts.add(host);
        if (g && item.places.length < 3 && !item.places.some((p) => p.city === g.city)) item.places.push({ country: g.country, city: g.city });
        found.set(key, item);
      }
      const items = [...found.values()]
        .map((x) => ({ ...x, apps: [...x.apps].slice(0, 6), hosts: [...x.hosts].slice(0, 4) }))
        .sort((a, b) => Number(b.sure) - Number(a.sure) || a.company.localeCompare(b.company));
      const sure = items.filter((x) => x.sure);
      const fresh = sure.filter((x) => !this.seen.has(x.company));
      for (const x of sure) this.seen.add(x.company);
      this.last = { at: Date.now(), items, links, connections: list(data.con).length };
      if (!quiet && fresh.length) {
        const names = fresh.map((x) => x.company).slice(0, 3).join(', ');
        this.notify('Tracker gefunden – Karte öffnen', `${first || fresh.length > 1 ? `${fresh.length} Tracker aktiv` : 'Neuer Tracker'}: ${names}${fresh[0].apps[0] ? ` (über ${fresh[0].apps[0]})` : ''}`);
      }
      return this.last;
    } finally {
      this.busy = false;
    }
  }

  /** Zustand des Microsoft Defender. */
  async defender() {
    const out = await ps(
      `$s = Get-MpComputerStatus -ErrorAction SilentlyContinue; $t = @(Get-MpThreatDetection -ErrorAction SilentlyContinue | Sort-Object InitialDetectionTime -Descending | Select-Object -First 8);` +
        `$n = @{}; Get-MpThreat -ErrorAction SilentlyContinue | ForEach-Object { $n[[string]$_.ThreatID] = $_.ThreatName };` +
        `@{ ok = [bool]$s; av = $s.AntivirusEnabled; rt = $s.RealTimeProtectionEnabled; sig = if ($s.AntivirusSignatureLastUpdated) { $s.AntivirusSignatureLastUpdated.ToString('o') } else { '' };` +
        ` quick = if ($s.QuickScanEndTime) { $s.QuickScanEndTime.ToString('o') } else { '' }; full = if ($s.FullScanEndTime) { $s.FullScanEndTime.ToString('o') } else { '' };` +
        ` tamper = $s.IsTamperProtected; threats = @($t | ForEach-Object { @{ name = $n[[string]$_.ThreatID]; at = $_.InitialDetectionTime.ToString('o'); file = [string]($_.Resources | Select-Object -First 1); ok = $_.ActionSuccess } }) } | ConvertTo-Json -Depth 4 -Compress`,
      25000,
    );
    const d = json(out, { ok: false });
    return { ...d, threats: list(d.threats), scanning: this.scanning };
  }

  /** Scan starten (schnell, oder eine Datei/einen Ordner). Meldet sich, wenn er fertig ist. */
  scan(kind = 'quick', target = '') {
    if (this.scanning) return this.scanning;
    const safe = String(target).replace(/'/g, "''");
    const cmd = kind === 'path' && safe ? `Start-MpScan -ScanType CustomScan -ScanPath '${safe}'` : 'Start-MpScan -ScanType QuickScan';
    this.scanning = { kind, target: kind === 'path' ? String(target) : '', since: Date.now() };
    ps(`${cmd}; 'done'`, 45 * 60 * 1000).then(async (out) => {
      this.scanning = null;
      const d = await this.defender().catch(() => null);
      const recent = (d?.threats || []).filter((t) => Date.now() - new Date(t.at).getTime() < 60 * 60 * 1000);
      if (!out.endsWith('done')) this.notify('Virenscan nicht möglich', 'Der Microsoft Defender hat den Scan nicht gestartet (ist er ausgeschaltet?).');
      else if (recent.length) this.notify('⚠️ Bedrohung gefunden', `${recent.length} Fund(e): ${recent[0].name || 'unbekannt'}. Details stehen in der Schutz-App.`);
      else this.notify('Virenscan fertig', 'Keine Bedrohungen gefunden.');
    });
    return this.scanning;
  }

  updateSignatures() {
    return ps('Update-MpSignature -ErrorAction SilentlyContinue; "ok"', 5 * 60 * 1000).then((o) => o.endsWith('ok'));
  }

  shutdown() {
    clearInterval(this.timer);
  }
}

module.exports = { Shield, match };
