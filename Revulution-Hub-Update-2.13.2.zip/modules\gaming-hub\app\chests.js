'use strict';

/*
 * Truhen-Zähler für Fortnite (nur Gesamtzahl).
 *
 * Erkennung, aus echten Spielbildern abgeleitet:
 *   1. Neben einer anvisierten Truhe steht „DURCHSUCHEN“ (bzw. „SEARCH“) – das liest
 *      die Texterkennung samt Position.
 *   2. Links neben dem Hinweis muss viel Truhen-Gold sein. Munitionskisten und
 *      andere Behälter haben denselben Hinweis, aber kein Gold.
 *   3. Die Interaktionstaste (auch Mausrad) wird gedrückt, während der Hinweis steht.
 *   4. Der Hinweis verschwindet (die Truhe ist offen) → +1.
 */

const fs = require('fs');
const path = require('path');

// OCR liest „DURCHSUCHEN“ auch mal als „DURGHSUGHEN“ – C/G und U/V sind austauschbar.
const SEARCH_RE = /d[uv]r[cg]h?s[uv][cg]h|s[uv][cg]hen\b|search/i;
const GOLD_MIN = 0.025;
// XP-Popup nach dem Öffnen (OCR-tolerant): „BEHÄLTER GEÖFFNET“, „CONTAINER OPENED“, „TRUHE GEÖFFNET“
const XP_RE = /beh[äa]?lter|ge[öo0]?ffnet|container|chest opened|truhe/i; // Anteil Gold-Pixel links vom Hinweis (Truhe: ~10 %, Munitionskiste: ~0)

const PROMPT_GONE_MS = 450; // so lange darf der Hinweis fehlen, bevor er als weg gilt
const KEY_WINDOW_MS = 4000; // Taste gedrückt → spätestens dann ist die Truhe offen
const MIN_GAP_MS = 700; // zwei Truhen kann man nicht schneller öffnen

const KEYS = ['E', 'F', 'R', 'Q', 'G', 'C', 'V', 'T', 'X', 'B', 'WheelDown', 'WheelUp', 'M3', 'M4', 'M5', 'pad-X', 'pad-A', 'pad-B', 'pad-Y'];
const WHEEL = ['M3', 'WheelDown', 'WheelUp'];

const DEFAULTS = {
  enabled: true,
  overlay: false, // Truhen-Widget standardmäßig aus
  sound: false,
  key: 'WheelDown',
  pad: 'pad-X',
  preset: 'tl',
  scale: 1,
};

class ChestCounter {
  constructor(file, { onChange, log } = {}) {
    this.file = file;
    this.onChange = onChange || (() => {});
    this.log = log || null;
    this.data = { settings: { ...DEFAULTS }, allTime: 0, today: { day: '', count: 0 }, lastOpenAt: 0 };
    this.prompt = { visible: false, firstSeen: 0, lastSeen: 0, gold: 0 };
    this.keyAt = 0;
    this.lastKeys = [];
    this.lastCountAt = 0;
    this.load();
    this.timer = setInterval(() => this.tick(), 80);
    this.timer.unref?.();
  }

  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      // Ältere Stände mit Runden: die offene Runde zählt noch zum Gesamt.
      const allTime = (Number(raw.allTime) || 0) + (Number(raw.round) || 0);
      this.data = {
        ...this.data,
        allTime,
        today: raw.today && typeof raw.today === 'object' ? raw.today : this.data.today,
        lastOpenAt: Number(raw.lastOpenAt) || 0,
        settings: { ...DEFAULTS, ...(raw.settings || {}) },
      };
      // einmalig: Widget aus (neuer Standard ab Hub 2.10)
      if (!this.data.settings.defaultsV3) this.data.settings = { ...this.data.settings, overlay: false, defaultsV3: true };
    } catch {
      /* erster Start */
    }
  }

  save() {
    clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      try {
        fs.mkdirSync(path.dirname(this.file), { recursive: true });
        fs.writeFileSync(`${this.file}.tmp`, JSON.stringify(this.data, null, 1));
        fs.renameSync(`${this.file}.tmp`, this.file);
      } catch (error) {
        console.log('[chests] nicht gespeichert:', error.message);
      }
    }, 250);
  }

  get settings() {
    return this.data.settings;
  }

  todayCount() {
    const day = new Date().toLocaleDateString('sv-SE');
    return this.data.today?.day === day ? this.data.today.count : 0;
  }

  snapshot(event = null) {
    return {
      settings: { ...this.data.settings },
      allTime: this.data.allTime,
      today: this.todayCount(),
      lastOpenAt: this.data.lastOpenAt,
      promptVisible: this.prompt.visible,
      keys: KEYS,
      event,
    };
  }

  emit(event) {
    this.onChange(this.snapshot(event));
  }

  setSettings(patch = {}) {
    const next = { ...this.data.settings };
    for (const key of ['enabled', 'overlay', 'sound']) if (typeof patch[key] === 'boolean') next[key] = patch[key];
    if (KEYS.includes(patch.key) && !String(patch.key).startsWith('pad-')) next.key = patch.key;
    if (KEYS.includes(patch.pad) && String(patch.pad).startsWith('pad-')) next.pad = patch.pad;
    if (['tl', 'tc', 'tr', 'ml', 'mr', 'bl', 'bc', 'br'].includes(patch.preset)) next.preset = patch.preset;
    if (Number.isFinite(Number(patch.scale))) next.scale = Math.min(2, Math.max(0.6, Number(patch.scale)));
    this.data.settings = next;
    this.save();
    this.emit();
    return this.snapshot();
  }

  /* ------------------------------------------------------------ Signale */

  /**
   * Ergebnis der Texterkennung neben dem Fadenkreuz.
   * words: [{ text, bbox:{x0,y0,x1,y1} }] im Bild des Ausschnitts,
   * gold: { cols, rows, w, h, cells:[Anteil Gold je Zelle] } desselben Ausschnitts.
   */
  feedPrompt(words, gold) {
    if (!this.data.settings.enabled) return { chest: false };
    const hit = (words || []).find((word) => SEARCH_RE.test(word.text || ''));
    if (!hit) return { chest: false, search: false };
    const share = goldLeftOf(hit.bbox, gold);
    const now = Date.now();
    if (share < GOLD_MIN) return { chest: false, search: true, gold: share };
    if (now - this.lastCountAt < MIN_GAP_MS) return { chest: true, gold: share };
    if (!this.prompt.visible) {
      this.prompt = { visible: true, firstSeen: now, lastSeen: now, gold: share };
      this.log?.(`Truhe im Blick (Gold ${(share * 100).toFixed(1)} %)`);
      this.emit({ type: 'prompt', visible: true });
    }
    this.prompt.lastSeen = now;
    this.lastChestSeen = now;
    return { chest: true, search: true, gold: share };
  }

  /**
   * Zweites Signal: das XP-Popup „+150 BEHÄLTER GEÖFFNET“ rechts neben dem Fadenkreuz.
   * Zählt nur, wenn kurz vorher eine (goldene) Truhe im Blick war und nicht schon gezählt wurde.
   */
  feedXp(text) {
    if (!this.data.settings.enabled) return false;
    if (!XP_RE.test(String(text || ''))) return false;
    const now = Date.now();
    if (!this.lastChestSeen || now - this.lastChestSeen > 6000) return false;
    if (now - this.lastCountAt < 3000) return false; // schon über den Hinweis gezählt
    this.log?.('XP-Popup „Behälter geöffnet“ → +1');
    this.prompt.visible = false;
    this.keyAt = 0;
    this.count(1, 'xp');
    return true;
  }

  /** Gedrückte Tasten (vom globalen Eingabe-Hook). */
  feedKeys(keys) {
    const list = Array.isArray(keys) ? keys : [];
    const { key, pad } = this.data.settings;
    const pressed = (name) => list.includes(name) && !this.lastKeys.includes(name);
    // Mausrad: Scrollen in beide Richtungen und Rad-Klick gelten gemeinsam.
    const watch = WHEEL.includes(key) ? WHEEL : [key];
    if (watch.some(pressed) || pressed(pad)) {
      this.keyAt = Date.now();
      if (this.prompt.visible) this.log?.(`Taste ${list.join('+')} · Truhe im Blick`);
    }
    this.lastKeys = list;
  }

  tick() {
    if (!this.prompt.visible) return;
    const now = Date.now();
    if (now - this.prompt.lastSeen < PROMPT_GONE_MS) return;
    const pressed = this.keyAt >= this.prompt.firstSeen - 300 && this.keyAt <= this.prompt.lastSeen + 300 && now - this.keyAt < KEY_WINDOW_MS;
    this.prompt.visible = false;
    this.log?.(`Hinweis weg · ${pressed ? 'geöffnet → +1' : 'ohne Taste, nicht gezählt'}`);
    if (pressed) this.count();
    else this.emit({ type: 'prompt', visible: false });
    this.keyAt = 0;
  }

  /* ------------------------------------------------------------ Zählen */

  count(amount = 1, source = 'auto') {
    const now = Date.now();
    if (source === 'auto' && now - this.lastCountAt < MIN_GAP_MS) return this.snapshot();
    this.lastCountAt = now;
    this.data.allTime = Math.max(0, this.data.allTime + amount);
    const day = new Date().toLocaleDateString('sv-SE');
    const today = this.data.today?.day === day ? this.data.today.count : 0;
    this.data.today = { day, count: Math.max(0, today + amount) };
    if (amount > 0) this.data.lastOpenAt = now;
    this.save();
    this.emit({ type: amount > 0 ? 'open' : 'adjust', amount });
    return this.snapshot();
  }

  /** Gesamtzähler auf 0 – nur mit dem eigenen Spielernamen bestätigt. */
  reset(ign, ownNames) {
    const typed = String(ign || '').trim().toLowerCase();
    const names = (ownNames || []).map((n) => String(n).trim().toLowerCase()).filter(Boolean);
    if (!names.length) return { ok: false, reason: 'Kein Spielername hinterlegt. Trage ihn unter Clips › Automatik ein.' };
    if (!typed || !names.includes(typed)) return { ok: false, reason: 'Der Name stimmt nicht mit deinem Fortnite-Namen überein.' };
    this.data.allTime = 0;
    this.data.today = { day: '', count: 0 };
    this.save();
    this.emit({ type: 'reset' });
    return { ok: true, ...this.snapshot() };
  }

  stop() {
    clearInterval(this.timer);
  }
}

/** Gold-Anteil im Bereich links neben dem Wort (dort steht die Truhe). */
function goldLeftOf(bbox, gold) {
  if (!bbox || !gold?.cells?.length) return 0;
  const width = bbox.x1 - bbox.x0;
  const height = Math.max(8, bbox.y1 - bbox.y0);
  const x0 = Math.max(0, bbox.x0 - width * 1.6);
  const x1 = bbox.x0;
  const y0 = Math.max(0, bbox.y0 - height * 4);
  const y1 = Math.min(gold.h, bbox.y1 + height * 4);
  const cw = gold.w / gold.cols;
  const ch = gold.h / gold.rows;
  let sum = 0;
  let cells = 0;
  for (let row = Math.floor(y0 / ch); row <= Math.min(gold.rows - 1, Math.floor(y1 / ch)); row += 1) {
    for (let col = Math.floor(x0 / cw); col <= Math.min(gold.cols - 1, Math.floor(x1 / cw)); col += 1) {
      sum += gold.cells[row * gold.cols + col] || 0;
      cells += 1;
    }
  }
  return cells ? sum / cells : 0;
}

module.exports = { ChestCounter, SEARCH_RE, KEYS, goldLeftOf };
