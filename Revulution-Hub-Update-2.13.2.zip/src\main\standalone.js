'use strict';

/**
 * Die Apps im Hub gab es früher einzeln (Orbit Island, Gaming Hub, Dropzone). Laufen
 * diese alten Einzel-Installationen noch, übernehmen sie Hotkeys, Overlays und – bei der
 * Island – sogar die Einzel-Instanz-Sperre: Dann startet nicht die Island aus dem Hub,
 * sondern die alte. Hier werden solche fremden Prozesse beendet und ihr eigener Autostart
 * entfernt, damit alles aus derselben App läuft.
 */

const { app } = require('electron');
const { execFile } = require('child_process');
const path = require('path');

const STANDALONE = ['OrbitIsland', 'Orbit Island', 'Revolution Gaming Hub', 'Revolution Crosshair', 'Dropzone by Revolution'];

const psQuote = (value) => `'${String(value).replace(/'/g, "''")}'`;

/**
 * @param {{ islandExe?: string }} options
 * @returns {Promise<{ killed: string[], autostart: string[] }>}
 */
function takeOverStandalone({ islandExe = '' } = {}) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32' || !app.isPackaged) return resolve({ killed: [], autostart: [] });
    const hubDir = path.dirname(process.execPath) + path.sep;
    const script = `
$ErrorActionPreference = 'SilentlyContinue'
$hub = ${psQuote(hubDir)}
$island = ${psQuote(islandExe)}
$names = @(${STANDALONE.map(psQuote).join(',')})
Get-CimInstance Win32_Process | Where-Object {
  $_.ExecutablePath -and ($names -contains [IO.Path]::GetFileNameWithoutExtension($_.Name)) -and
  -not $_.ExecutablePath.StartsWith($hub, [StringComparison]::OrdinalIgnoreCase)
} | ForEach-Object {
  Stop-Process -Id $_.ProcessId -Force
  "killed|" + $_.ExecutablePath
}
$key = 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'
$props = Get-ItemProperty -Path $key
if ($props) {
  foreach ($p in $props.PSObject.Properties) {
    if (@('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') -contains $p.Name) { continue }
    $cmd = [string]$p.Value
    if ($cmd.IndexOf($hub, [StringComparison]::OrdinalIgnoreCase) -ge 0) { continue }
    $hit = $false
    foreach ($n in $names) { if ($cmd.IndexOf($n + '.exe', [StringComparison]::OrdinalIgnoreCase) -ge 0) { $hit = $true } }
    if (-not $hit) { continue }
    # Die Island startet der Hub selbst mit – kein eigener Autostart mehr daneben.
    Remove-ItemProperty -Path $key -Name $p.Name
    "autostart|" + $p.Name + " entfernt"
  }
}
`;
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')],
      { windowsHide: true, timeout: 20000 },
      (_error, stdout) => {
        const lines = String(stdout || '').split(/\r?\n/).filter(Boolean);
        const result = {
          killed: lines.filter((l) => l.startsWith('killed|')).map((l) => l.slice(7)),
          autostart: lines.filter((l) => l.startsWith('autostart|')).map((l) => l.slice(10)),
        };
        if (result.killed.length || result.autostart.length) console.log('[hub] Einzel-Apps übernommen', result);
        resolve(result);
      },
    );
  });
}

module.exports = { takeOverStandalone };
