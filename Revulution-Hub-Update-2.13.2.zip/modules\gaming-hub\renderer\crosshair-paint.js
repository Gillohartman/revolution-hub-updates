/*
 * Zeichnet Crosshairs (Vektor-Designs und Bilder/GIFs).
 * Wird im Overlay, in der Vorschau, in der Galerie und im Clip-Recorder verwendet.
 */
(function () {
  const TAU = Math.PI * 2;
  /** Alle Crosshairs starten eine Spur kleiner als die Rohwerte. */
  const SIZE = 0.85;

  /** Fortnite-Ränge: Farbe und Animation der Rang-Crosshairs. */
  const RANKS = [
    { id: 'bronze', name: 'Bronze', color: '#c8813f', animation: 'pulse' },
    { id: 'silver', name: 'Silber', color: '#c3ccd8', animation: 'spark' },
    { id: 'gold', name: 'Gold', color: '#ffca3a', animation: 'pulse' },
    { id: 'platinum', name: 'Platin', color: '#5ad2e6', animation: 'comet' },
    { id: 'diamond', name: 'Diamant', color: '#7aa8ff', animation: 'spark' },
    { id: 'elite', name: 'Elite', color: '#a97bff', animation: 'neon' },
    { id: 'champion', name: 'Champion', color: '#ff6b9d', animation: 'glitch' },
    { id: 'unreal', name: 'Unreal', color: '#ff9ff3', animation: 'rainbow' },
  ];

  /** Wie weit reicht das Design vom Mittelpunkt? */
  function extent(profile) {
    const thin = profile.thickness / 2;
    const reach = profile.gap + profile.length;
    switch (profile.kind) {
      case 'dot':
        return Math.max(profile.dot || profile.thickness, thin);
      case 'circle':
      case 'circleDot':
        return Math.max(profile.ring, profile.dot) + thin;
      case 'x':
        return reach * Math.SQRT1_2 + thin;
      case 'pixels': {
        const size = (profile.pixels && profile.pixels.length) || 15;
        return (size / 2) * (profile.pixelSize || 4);
      }
      default:
        return reach + thin;
    }
  }

  function boxSize(profile) {
    const half = extent(profile) + profile.outline + 2;
    return Math.ceil(half * 2);
  }

  /** Animationen brauchen Rand, sonst werden Glow und schwebende Punkte abgeschnitten. */
  function animationPadding(animation) {
    switch (animation) {
      case 'neon':
      case 'orbit':
      case 'comet':
        return 40;
      case 'spark':
        return 26;
      case 'flame':
        return 28;
      default:
        return 0;
    }
  }

  function trace(ctx, p) {
    const reach = p.gap + p.length;
    const line = (x1, y1, x2, y2) => {
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
    };
    ctx.beginPath();

    switch (p.kind) {
      case 'cross':
      case 't': {
        line(0, -p.gap, 0, -reach);
        line(-p.gap, 0, -reach, 0);
        line(p.gap, 0, reach, 0);
        if (p.kind === 'cross') line(0, p.gap, 0, reach);
        break;
      }
      case 'x': {
        const g = p.gap * Math.SQRT1_2;
        const r = reach * Math.SQRT1_2;
        line(-g, -g, -r, -r);
        line(g, -g, r, -r);
        line(-g, g, -r, r);
        line(g, g, r, r);
        break;
      }
      case 'brackets': {
        const s = reach;
        const arm = Math.max(4, Math.round(s * 0.42));
        for (const sx of [-1, 1]) {
          for (const sy of [-1, 1]) {
            line(sx * s, sy * s, sx * (s - arm), sy * s);
            line(sx * s, sy * s, sx * s, sy * (s - arm));
          }
        }
        break;
      }
      case 'chevron': {
        const s = reach;
        const arm = Math.max(4, Math.round(s * 0.5));
        ctx.moveTo(-arm, -s);
        ctx.lineTo(0, -s + arm);
        ctx.lineTo(arm, -s);
        ctx.moveTo(-arm, s);
        ctx.lineTo(0, s - arm);
        ctx.lineTo(arm, s);
        ctx.moveTo(-s, -arm);
        ctx.lineTo(-s + arm, 0);
        ctx.lineTo(-s, arm);
        ctx.moveTo(s, -arm);
        ctx.lineTo(s - arm, 0);
        ctx.lineTo(s, arm);
        break;
      }
      case 'triangle': {
        const s = reach;
        ctx.moveTo(0, -s);
        ctx.lineTo(s * 0.9, s * 0.55);
        ctx.lineTo(-s * 0.9, s * 0.55);
        ctx.closePath();
        break;
      }
      case 'square': {
        const s = reach;
        ctx.rect(-s, -s, s * 2, s * 2);
        break;
      }
      case 'dot': {
        ctx.arc(0, 0, Math.max(1, p.dot || p.thickness), 0, TAU);
        break;
      }
      case 'circle':
      case 'circleDot': {
        ctx.arc(0, 0, Math.max(2, p.ring), 0, TAU);
        break;
      }
      default: {
        line(0, -p.gap, 0, -reach);
        line(0, p.gap, 0, reach);
        line(-p.gap, 0, -reach, 0);
        line(p.gap, 0, reach, 0);
      }
    }
  }

  /** Zeichnet das Design in ein Canvas, dessen Mittelpunkt (0,0) ist. */
  function paint(ctx, p) {
    if (p.kind === 'pixels') {
      const grid = p.pixels || [];
      const size = grid.length || 15;
      const px = Math.max(1, p.pixelSize || 4);
      const half = (size / 2) * px;
      for (let y = 0; y < size; y += 1) {
        for (let x = 0; x < size; x += 1) {
          const color = grid[y] && grid[y][x];
          if (!color) continue;
          ctx.fillStyle = color;
          ctx.fillRect(Math.round(x * px - half), Math.round(y * px - half), px, px);
        }
      }
      return;
    }

    const filled = p.kind === 'dot' || p.kind === 'triangle';
    ctx.lineCap = filled ? 'round' : 'butt';
    ctx.lineJoin = 'miter';

    if (p.outline > 0) {
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.88)';
      ctx.fillStyle = 'rgba(0, 0, 0, 0.88)';
      ctx.lineWidth = p.thickness + p.outline * 2;
      trace(ctx, p);
      if (filled) ctx.fill();
      ctx.stroke();
    }

    ctx.strokeStyle = p.color;
    ctx.fillStyle = p.color;
    ctx.lineWidth = p.thickness;
    if (p.kind === 'circleDot') {
      trace(ctx, p);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, Math.max(1, p.dot || 2), 0, TAU);
      ctx.fill();
      return;
    }
    trace(ctx, p);
    if (filled) ctx.fill();
    ctx.stroke();
  }

  /** Flammen rund ums Crosshair. */
  function drawFlames(ctx, profile, t) {
    const radius = extent(profile) + 4;
    for (let i = 0; i < 12; i += 1) {
      const angle = (i / 12) * TAU + t * 1.1;
      const flicker = (Math.sin(t * 9 + i * 2.3) + 1) / 2;
      const distance = radius + flicker * 7;
      const x = Math.cos(angle) * distance;
      const y = Math.sin(angle) * distance;
      const size = (2 + flicker * 3.4) * Math.max(1, profile.thickness * 0.8);
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, size * 2);
      gradient.addColorStop(0, 'rgba(255,246,180,0.95)');
      gradient.addColorStop(0.4, 'rgba(255,150,40,0.72)');
      gradient.addColorStop(1, 'rgba(255,60,0,0)');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, size * 2, 0, TAU);
      ctx.fill();
    }
  }

  /** Elektrische Funken um das Crosshair. */
  function drawSparks(ctx, profile, t) {
    const radius = extent(profile) + 6;
    const frame = Math.floor(t * 14);
    const random = (seed) => {
      const value = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
      return value - Math.floor(value);
    };
    for (let i = 0; i < 5; i += 1) {
      const start = random(frame + i * 13) * TAU;
      const span = 0.45 + random(frame * 3 + i) * 0.7;
      ctx.beginPath();
      ctx.strokeStyle = i % 2 === 0 ? '#bfe9ff' : '#8fd4ff';
      ctx.lineWidth = Math.max(1, profile.thickness * 0.35);
      const steps = 4;
      for (let step = 0; step <= steps; step += 1) {
        const angle = start + (span * step) / steps;
        // Kein Zittern: fester Radius, nur die Position wandert weiter.
        const distance = radius + Math.sin(t * 5 + i * 1.7 + step * 0.7) * 1.4;
        const x = Math.cos(angle) * distance;
        const y = Math.sin(angle) * distance;
        if (step === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }

  /** Leuchtspur, die um das Crosshair kreist. */
  function drawComet(ctx, profile, angle) {
    const radius = extent(profile) + 9;
    for (let tail = 0; tail < 6; tail += 1) {
      const a = angle - tail * 0.16;
      const x = Math.cos(a) * radius;
      const y = Math.sin(a) * radius;
      ctx.globalAlpha = 0.9 - tail * 0.14;
      ctx.beginPath();
      ctx.arc(x, y, Math.max(1, profile.thickness * (0.9 - tail * 0.12)), 0, TAU);
      ctx.fillStyle = tail === 0 ? '#ffffff' : profile.color;
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  /** Zustand einer Animation zum Zeitpunkt t (Sekunden). */
  function frameState(profile, t) {
    switch (profile.animation) {
      case 'pulse':
        return { scale: 1 + Math.sin(t * 3.2) * 0.07 };
      case 'breathe':
        return { alpha: 0.55 + (Math.sin(t * 2) + 1) * 0.22 };
      case 'rainbow':
        return { hue: (t * 70) % 360 };
      case 'glitch': {
        // Nur Helligkeit flackert – kein Drehen oder Zittern.
        const n = Math.sin(t * 19) + Math.sin(t * 7.3);
        return { alpha: n > 1.4 ? 0.72 : 1 };
      }
      case 'orbit':
        return { orbit: t * 2.2 };
      case 'spin':
        return { rotate: t * 1.4 };
      case 'flame':
        return { flame: 1 };
      case 'spark':
        return { spark: 1 };
      case 'neon':
        return { neon: 0.55 + (Math.sin(t * 3.1) + 1) * 0.22 };
      case 'comet':
        return { comet: t * 2.1 };
      default:
        return {};
    }
  }

  /** Ein Frame auf ein Canvas zeichnen (Mittelpunkt = Bildmitte). */
  function drawFrame(canvas, profile, opts = {}, time = 0) {
    const ctx = canvas.getContext('2d');
    const dpr = Number(canvas.dataset.dpr) || 1;
    const size = Number(canvas.dataset.size) || 64;
    const state = frameState(profile, time);

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.translate(size / 2, size / 2);

    const scale = (opts.scale || 1) * (state.scale || 1);
    ctx.scale(scale, scale);
    if (state.rotate) ctx.rotate((state.rotate * Math.PI) / 180);
    ctx.globalAlpha = state.alpha ?? 1;
    if (state.hue) ctx.filter = `hue-rotate(${Math.round(state.hue)}deg)`;

    if (state.orbit) {
      const radius = extent(profile) + 10;
      const angle = state.orbit;
      ctx.beginPath();
      ctx.arc(Math.cos(angle) * radius, Math.sin(angle) * radius, Math.max(1.5, profile.thickness * 0.9), 0, TAU);
      ctx.fillStyle = profile.color;
      ctx.fill();
    }

    if (state.flame) drawFlames(ctx, profile, time);
    if (state.spark) drawSparks(ctx, profile, time);
    if (state.comet) drawComet(ctx, profile, state.comet);

    if (state.neon) {
      ctx.shadowColor = profile.color;
      ctx.shadowBlur = 8 + state.neon * 8;
    }

    paint(ctx, profile);

    ctx.shadowBlur = 0;
    ctx.filter = 'none';
    ctx.globalAlpha = 1;
  }

  /** Abzeichen-Bilder leicht animieren (Puls, Glow, Drehung, Regenbogen). */
  function animateImage(host, img, profile) {
    if (!profile.animation || profile.animation === 'none') return;
    const color = profile.color || '#ffffff';
    // Abzeichen bleiben aufrecht und ruhig: nur Helligkeit und ein Hauch Größe.
    const step = (now) => {
      if (!img.isConnected) return;
      const t = now / 1000;
      let scale = 1;
      let glow = 10 + (Math.sin(t * 2.4) + 1) * 3;
      let alpha = 1;

      switch (profile.animation) {
        case 'pulse':
          scale = 1 + Math.sin(t * 3.2) * 0.035;
          glow = 12 + (Math.sin(t * 3.2) + 1) * 6;
          break;
        case 'breathe':
          alpha = 0.78 + (Math.sin(t * 1.9) + 1) * 0.11;
          break;
        case 'flame':
          glow = 15 + Math.sin(t * 9.5) * 5;
          break;
        case 'spark':
          glow = 13 + Math.abs(Math.sin(t * 5)) * 8;
          break;
        case 'neon':
          glow = 14 + (Math.sin(t * 3) + 1) * 7;
          break;
        case 'glitch': {
          const n = Math.sin(t * 19) + Math.sin(t * 7.3);
          glow = 16 + n * 4;
          break;
        }
        default:
          break;
      }

      img.style.opacity = String(alpha);
      img.style.transform = `scale(${scale.toFixed(3)})`;
      img.style.filter = `drop-shadow(0 0 ${glow.toFixed(1)}px ${color})`;
      img._xhRaf = requestAnimationFrame(step);
    };
    host._xhStop = () => cancelAnimationFrame(img._xhRaf);
    img._xhRaf = requestAnimationFrame(step);
  }

  function makeCanvas(size, dpr) {
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(size * dpr);
    canvas.height = Math.round(size * dpr);
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;
    canvas.dataset.dpr = String(dpr);
    canvas.dataset.size = String(size);
    return canvas;
  }

  function loop(canvas, profile, opts) {
    const step = (now) => {
      if (!canvas.isConnected) return;
      drawFrame(canvas, profile, opts, now / 1000);
      canvas._xhRaf = requestAnimationFrame(step);
    };
    canvas._xhRaf = requestAnimationFrame(step);
  }

  /**
   * Baut das Crosshair-Element für einen Host.
   * opts: { scale, pixelRatio, mediaUrl(imageFile) }
   */
  function render(host, profile, opts = {}) {
    if (!host || !profile) return null;
    if (typeof host._xhStop === 'function') {
      host._xhStop();
      host._xhStop = null;
    }
    host.replaceChildren();

    if (profile.kind === 'image') {
      if (!profile.image) return null;
      const base = 140 * (profile.imageScale || 1) * (opts.scale || 1) * SIZE;
      const img = document.createElement('img');
      img.src = opts.mediaUrl ? opts.mediaUrl(profile.image) : profile.image;
      img.alt = '';
      img.draggable = false;
      img.style.width = `${base}px`;
      img.style.height = 'auto';
      img.style.maxWidth = 'none';
      img.style.mixBlendMode = profile.blend === 'screen' ? 'screen' : 'normal';
      img.style.imageRendering = 'auto';
      img.style.transformOrigin = '50% 50%';
      host.appendChild(img);
      animateImage(host, img, profile);
      return img;
    }

    const drawOpts = { ...opts, scale: (opts.scale || 1) * SIZE };
    const size = Math.max(
      4,
      Math.round((boxSize(profile) + animationPadding(profile.animation)) * drawOpts.scale),
    );
    const dpr = Math.max(1, opts.pixelRatio || window.devicePixelRatio || 1);
    const canvas = makeCanvas(size, dpr);
    canvas.style.imageRendering = 'auto';

    if (profile.animation && profile.animation !== 'none') {
      host._xhStop = () => cancelAnimationFrame(canvas._xhRaf);
      loop(canvas, profile, drawOpts);
    } else {
      drawFrame(canvas, profile, drawOpts, 0);
    }

    host.appendChild(canvas);
    return canvas;
  }

  /** Für die Galerie: kleines Vorschaubild, animierte Designs laufen weiter. */
  function thumbnail(profile, size = 104) {
    if (profile.kind === 'image') return null;

    const dpr = Math.max(1, window.devicePixelRatio || 1);
    const canvas = makeCanvas(size, dpr);
    const extentPx = extent(profile) + profile.outline + animationPadding(profile.animation) / 2;
    const fit = (size * 0.36) / Math.max(1, extentPx);
    const opts = { scale: Math.min(2.2, Math.max(0.5, fit)) };

    if (profile.animation && profile.animation !== 'none') loop(canvas, profile, opts);
    else drawFrame(canvas, profile, opts, 0);
    return canvas;
  }

  /** Design-Katalog für die Galerie: Ränge zuerst, dann die Klassiker. */
  function catalog() {
    const base = {
      kind: 'cross',
      builtin: true,
      rank: '',
      autoRank: false,
      animation: 'none',
      color: '#3ce88f',
      length: 14,
      thickness: 3,
      gap: 5,
      dot: 0,
      ring: 12,
      outline: 1.5,
      opacity: 1,
      rotation: 0,
      aimTighten: true,
      blend: 'normal',
      image: '',
      imageScale: 1,
      pixelSize: 4,
    };

    const list = [
      ['c-classic', 'Klassisch', { color: '#3ce88f' }],
      ['c-white', 'Weiß', { color: '#ffffff', length: 10, thickness: 2 }],
      ['c-pink', 'Pink', { color: '#ff3ba7', length: 12, gap: 6 }],
      ['c-cyan', 'Cyan', { color: '#22d3ee', length: 12, gap: 6 }],
      ['c-violet', 'Violett', { color: '#a855f7', length: 12, gap: 6 }],
      ['c-red', 'Rot', { color: '#ff2d55', length: 12, gap: 6 }],
      ['c-lime', 'Limette', { color: '#a3e635', length: 15, gap: 5 }],
      ['c-x-cyan', 'X Cyan', { kind: 'x', color: '#22d3ee', length: 12 }],
      ['c-x-pink', 'X Pink', { kind: 'x', color: '#ff3ba7', length: 12 }],
      ['c-x-white', 'X Weiß', { kind: 'x', color: '#ffffff', length: 11, thickness: 2 }],
      ['c-dot-red', 'Punkt Rot', { kind: 'dot', color: '#ff2d55', dot: 3.5 }],
      ['c-dot-white', 'Punkt Weiß', { kind: 'dot', color: '#ffffff', dot: 3 }],
      ['c-dot-cyan', 'Punkt Cyan', { kind: 'dot', color: '#22d3ee', dot: 3 }],
      ['c-ring-violet', 'Ring Violett', { kind: 'circle', color: '#a855f7', ring: 14, thickness: 2 }],
      ['c-ringd-cyan', 'Ring + Punkt', { kind: 'circleDot', color: '#22d3ee', ring: 13, dot: 2 }],
      ['c-brackets', 'Klammern', { kind: 'brackets', color: '#22e06a', length: 10, gap: 6 }],
      ['c-chevron', 'Pfeile', { kind: 'chevron', color: '#f59e0b', length: 11 }],
      ['c-triangle', 'Dreieck', { kind: 'triangle', color: '#38bdf8', length: 13 }],
      ['c-square', 'Quadrat', { kind: 'square', color: '#f472b6', length: 11 }],
      ['c-t', 'T-Form', { kind: 't', color: '#c084fc', length: 13 }],
      ['c-fat', 'Dick', { color: '#ffffff', thickness: 5, length: 13, gap: 6, outline: 1 }],
      ['c-tiny', 'Mini', { color: '#3ce88f', thickness: 2, length: 7, gap: 3, outline: 1 }],
      ['c-wide', 'Breit', { color: '#fbbf24', thickness: 3, length: 20, gap: 9 }],
      ['c-cross-dot', 'Kreuz + Punkt', { color: '#3ce88f', length: 15, gap: 6, dot: 2 }],
      ['c-neon-pulse', 'Neon Puls', { color: '#41f7c7', length: 14, gap: 6, animation: 'pulse' }],
      ['c-spark', 'Funken', { color: '#7fd8ff', length: 14, gap: 6, animation: 'spark' }],
      ['c-comet', 'Komet', { color: '#b98cff', length: 14, gap: 6, animation: 'comet' }],
      ['c-neon', 'Neon Leucht', { color: '#3ce88f', length: 14, gap: 6, animation: 'neon' }],
      ['c-rainbow', 'Regenbogen', { color: '#ff4d9d', length: 15, gap: 6, animation: 'rainbow' }],
      ['c-orbit', 'Orbit', { kind: 'circleDot', color: '#22d3ee', ring: 14, dot: 2, animation: 'orbit' }],
    ];

    const autoRow = {
      ...base,
      id: 'rank-auto',
      name: 'Auto (Rangfarbe)',
      autoRank: true,
      color: '#3ce88f',
      animation: 'pulse',
      length: 15,
      thickness: 3.5,
      gap: 6,
      outline: 2,
    };

    return [autoRow, ...list.map(([id, name, extra]) => ({ ...base, id, name, ...extra }))];
  }

  window.XH = { RANKS, boxSize, catalog, drawFrame, extent, paint, render, thumbnail };
})();
