'use strict';

/* Agenda des Revolution Hubs – dieselben Termine wie in der Orbit Island. */

const $ = (s) => document.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const api = window.agendaApp;
const DAY = Recur.DAY;
const COLORS = ['#C9A7FF', '#7C8CFF', '#38BDF8', '#3DDC97', '#FFD60A', '#FF9F0A', '#FF5D6C', '#F06BC0'];
const REMINDERS = [[-1, 'Keine'], [0, 'Beim Beginn'], [5, '5 Minuten vorher'], [10, '10 Minuten vorher'], [15, '15 Minuten vorher'], [30, '30 Minuten vorher'], [60, '1 Stunde vorher'], [120, '2 Stunden vorher'], [1440, '1 Tag vorher'], [2880, '2 Tage vorher'], [10080, '1 Woche vorher']];
const REPEATS = [['None', 'Nie'], ['Daily', 'Täglich'], ['Weekly', 'Wöchentlich'], ['Monthly', 'Monatlich'], ['Yearly', 'Jährlich']];
const de = (d, o) => d.toLocaleDateString('de-DE', o);
const hm = (d) => d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
const startOfDay = (d) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
const sameDay = (a, b) => a.toDateString() === b.toDateString();

const state = { events: [], view: 'month', cursor: startOfDay(new Date()), mini: startOfDay(new Date()) };

function toast(text) {
  const el = $('#toast');
  el.textContent = text;
  el.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (el.hidden = true), 2600);
}

function relative(occ, now = new Date()) {
  const diff = occ.start - now;
  if (diff <= 0 && now < occ.end) return 'läuft gerade';
  if (diff <= 0) return 'vorbei';
  const min = Math.round(diff / 60000);
  if (min < 60) return `in ${min} Min.`;
  if (sameDay(occ.start, now)) return `in ${Math.floor(min / 60)} Std. ${String(min % 60).padStart(2, '0')} Min.`;
  const days = Math.round((startOfDay(occ.start) - startOfDay(now)) / DAY);
  if (days === 1) return 'morgen';
  return `in ${days} Tagen`;
}

function dayLabel(d) {
  const today = startOfDay(new Date());
  const diff = Math.round((startOfDay(d) - today) / DAY);
  if (diff === 0) return 'Heute';
  if (diff === 1) return 'Morgen';
  if (diff === -1) return 'Gestern';
  return de(d, { weekday: 'long' });
}

function reminderText(evt) {
  const list = [];
  if (evt.Reminder) list.push(Number(evt.ReminderMinutes));
  if (Number(evt.ReminderMinutes2) >= 0 && evt.ReminderMinutes2 !== null && evt.ReminderMinutes2 !== undefined) list.push(Number(evt.ReminderMinutes2));
  return list.map((m) => (m === 0 ? 'Beginn' : m >= 1440 ? `${m / 1440} T` : m >= 60 ? `${m / 60} Std` : `${m} Min`)).join(' + ');
}

/* ---------------------------------------------------------------- Seitenleiste */
function renderMini() {
  const m = state.mini;
  const first = new Date(m.getFullYear(), m.getMonth(), 1);
  const offset = (first.getDay() + 6) % 7;
  const start = new Date(first.getTime() - offset * DAY);
  const occ = Recur.agenda(state.events, start, new Date(start.getTime() + 42 * DAY));
  const busy = new Set(occ.map((o) => o.start.toDateString()));
  const today = new Date();
  let cells = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((d) => `<span class="wd">${d}</span>`).join('');
  for (let i = 0; i < 42; i += 1) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const cls = [d.getMonth() !== m.getMonth() ? 'out' : '', sameDay(d, today) ? 'today' : '', sameDay(d, state.cursor) ? 'sel' : ''].join(' ');
    cells += `<button class="${cls}" data-day="${d.toISOString()}">${d.getDate()}${busy.has(d.toDateString()) ? '<i></i>' : ''}</button>`;
  }
  $('#mini').innerHTML = `<div class="mini-head"><button data-mini="-1">‹</button><span>${de(m, { month: 'long', year: 'numeric' })}</span><button data-mini="1">›</button></div><div class="mini-grid">${cells}</div>`;
}

function renderNext() {
  const now = new Date();
  const next = Recur.agenda(state.events, now, new Date(now.getTime() + 60 * DAY)).find((o) => o.end > now);
  const week = Recur.agenda(state.events, now, new Date(now.getTime() + 7 * DAY)).length;
  $('#next').innerHTML = next
    ? `<h3>Als Nächstes</h3><div class="next-card" data-edit="${esc(next.evt.Id)}"><b>${esc(next.evt.Title)}</b><span class="when">${dayLabel(next.start)}${next.evt.AllDay ? ', ganztägig' : `, ${hm(next.start)}`}</span><div class="count">${relative(next)}</div></div><p class="muted" style="font-size:12px;margin:10px 2px 0">${week} Termin${week === 1 ? '' : 'e'} in den nächsten 7 Tagen</p>`
    : `<h3>Als Nächstes</h3><div class="next-card"><b>Nichts geplant</b><span class="when">Lege mit „Neuer Termin“ los.</span></div>`;
}

/* ----------------------------------------------------------------- Ansichten */
function evRow(o) {
  const now = new Date();
  const cls = o.end < now ? 'past' : o.start <= now && now < o.end ? 'now' : '';
  const time = o.evt.AllDay ? '<span class="t">Ganztägig</span>' : `<span class="t">${hm(o.start)}<small>${hm(o.end)}</small></span>`;
  const rem = reminderText(o.evt);
  return `<div class="ev ${cls}" data-edit="${esc(o.evt.Id)}">${time}<i class="bar" style="background:${esc(o.evt.ColorHex || '#8b6cff')}"></i>
    <div class="info"><b>${esc(o.evt.Title)}</b><span>${esc(o.evt.Location || '')}${o.evt.Location ? ' · ' : ''}${relative(o)}</span></div>
    <div class="tags">${o.evt.Frequency && o.evt.Frequency !== 'None' ? '<span>↻</span>' : ''}${rem ? `<span>🔔 ${rem}</span>` : ''}${o.evt.ReadOnly ? '<span>Abo</span>' : ''}</div><button class="ev-del" data-del="${esc(o.evt.Id)}" title="${o.evt.ReadOnly ? 'Ausblenden' : 'Löschen'}">✕</button></div>`;
}

function renderList() {
  const from = startOfDay(state.cursor);
  const to = new Date(from.getTime() + 45 * DAY);
  const occ = Recur.agenda(state.events, from, to);
  $('#title').textContent = `Ab ${de(from, { day: 'numeric', month: 'long' })}`;
  if (!occ.length) {
    $('#body').innerHTML = `<div class="empty"><div><div class="big">🗓️</div><b>Keine Termine in den nächsten Wochen</b><p>Neue Termine erscheinen hier und in der Island.</p><button class="btn primary" data-new="1">＋ Termin anlegen</button></div></div>`;
    return;
  }
  const groups = new Map();
  for (const o of occ) {
    const k = startOfDay(o.start).getTime();
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(o);
  }
  let html = '';
  let i = 0;
  for (const [k, list] of groups) {
    const d = new Date(k);
    html += `<section class="day" style="animation-delay:${Math.min(i++, 8) * 40}ms"><div class="day-head ${sameDay(d, new Date()) ? 'is-today' : ''}"><b>${dayLabel(d)}</b><span>${de(d, { day: 'numeric', month: 'long', year: 'numeric' })}</span></div>${list.map(evRow).join('')}</section>`;
  }
  $('#body').innerHTML = html;
}

function renderWeek() {
  const c = state.cursor;
  const monday = new Date(startOfDay(c).getTime() - ((c.getDay() + 6) % 7) * DAY);
  const occ = Recur.agenda(state.events, monday, new Date(monday.getTime() + 7 * DAY));
  $('#title').textContent = `${de(monday, { day: 'numeric', month: 'short' })} – ${de(new Date(monday.getTime() + 6 * DAY), { day: 'numeric', month: 'short', year: 'numeric' })}`;
  let html = '';
  for (let i = 0; i < 7; i += 1) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const list = occ.filter((o) => sameDay(o.start, d));
    html += `<div class="wcol ${sameDay(d, new Date()) ? 'today' : ''}" data-day="${d.toISOString()}"><h4>${de(d, { weekday: 'short' })}<b>${d.getDate()}</b></h4>${list
      .map((o) => `<div class="wev" data-edit="${esc(o.evt.Id)}" style="background:${esc(o.evt.ColorHex || '#8b6cff')}cc">${esc(o.evt.Title)}<small>${o.evt.AllDay ? 'Ganztägig' : `${hm(o.start)} – ${hm(o.end)}`}</small></div>`)
      .join('')}</div>`;
  }
  $('#body').innerHTML = `<div class="week">${html}</div>`;
}

function renderMonth() {
  const c = state.cursor;
  const first = new Date(c.getFullYear(), c.getMonth(), 1);
  const start = new Date(first.getTime() - ((first.getDay() + 6) % 7) * DAY);
  const occ = Recur.agenda(state.events, start, new Date(start.getTime() + 42 * DAY));
  $('#title').textContent = de(first, { month: 'long', year: 'numeric' });
  let html = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((d) => `<div class="wd">${d}</div>`).join('');
  for (let i = 0; i < 42; i += 1) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const list = occ.filter((o) => sameDay(o.start, d));
    html += `<div class="cell ${d.getMonth() !== c.getMonth() ? 'out' : ''} ${sameDay(d, new Date()) ? 'today' : ''}" data-day="${d.toISOString()}"><span class="n">${d.getDate()}</span>${list
      .slice(0, 3)
      .map((o) => `<div class="chipev" data-edit="${esc(o.evt.Id)}" style="background:${esc(o.evt.ColorHex || '#8b6cff')}bb">${o.evt.AllDay ? '' : `${hm(o.start)} `}${esc(o.evt.Title)}</div>`)
      .join('')}${list.length > 3 ? `<small class="muted">+${list.length - 3} weitere</small>` : ''}</div>`;
  }
  $('#body').innerHTML = `<div class="month">${html}</div>`;
}

function render() {
  renderMini();
  renderNext();
  if (state.view === 'week') renderWeek();
  else if (state.view === 'month') renderMonth();
  else renderList();
}

/* ------------------------------------------------------------------- Editor */
const pad = (n) => String(n).padStart(2, '0');
const dateVal = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const timeVal = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;

function openEditor(evt, day) {
  const isNew = !evt;
  const base = day ? new Date(day) : new Date();
  if (isNew) {
    const s = new Date(base);
    const now = new Date();
    s.setHours(sameDay(base, now) ? now.getHours() + 1 : 9, 0, 0, 0);
    evt = { Id: crypto.randomUUID().replace(/-/g, ''), Title: '', Location: '', Notes: '', Start: s.toISOString(), End: new Date(s.getTime() + 3600000).toISOString(), AllDay: false, ColorHex: COLORS[0], Reminder: true, ReminderMinutes: 10, ReminderMinutes2: 1440, Frequency: 'None', Interval: 1 };
  }
  const s = new Date(evt.Start);
  let e = new Date(evt.End);
  if (evt.AllDay && e.getHours() === 0 && e > s) e = new Date(e.getTime() - DAY);
  const ro = Boolean(evt.ReadOnly);
  const r1 = evt.Reminder ? Number(evt.ReminderMinutes) : -1;
  const r2 = evt.ReminderMinutes2 === undefined || evt.ReminderMinutes2 === null ? -1 : Number(evt.ReminderMinutes2);
  const opts = (sel) => REMINDERS.map(([v, l]) => `<option value="${v}" ${v === sel ? 'selected' : ''}>${l}</option>`).join('');
  $('#modal').innerHTML = `<h2>${isNew ? 'Neuer Termin' : ro ? 'Termin (abonniert)' : 'Termin bearbeiten'}</h2>
    <div class="field"><label>Titel</label><input class="input" id="f-title" value="${esc(evt.Title)}" placeholder="Was steht an?" ${ro ? 'disabled' : ''} /></div>
    <div class="field inline"><button class="switch ${evt.AllDay ? 'on' : ''}" id="f-allday" ${ro ? 'disabled' : ''}></button><span>Ganztägig</span></div>
    <div class="row3"><div class="field"><label>Beginn</label><input type="date" class="input" id="f-sd" value="${dateVal(s)}" /></div><div class="field t-only"><label>Von</label><input type="time" class="input" id="f-st" value="${timeVal(s)}" /></div><div class="field t-only"><label>Bis</label><input type="time" class="input" id="f-et" value="${timeVal(new Date(evt.End))}" /></div></div>
    <div class="field"><label>Ende (Tag)</label><input type="date" class="input" id="f-ed" value="${dateVal(e)}" /></div>
    <div class="row2"><div class="field"><label>Erinnerung</label><select class="select" id="f-r1">${opts(r1)}</select></div><div class="field"><label>Zweite Erinnerung</label><select class="select" id="f-r2">${opts(r2)}</select></div></div>
    <div class="row2"><div class="field"><label>Wiederholen</label><select class="select" id="f-rep">${REPEATS.map(([v, l]) => `<option value="${v}" ${v === (evt.Frequency || 'None') ? 'selected' : ''}>${l}</option>`).join('')}</select></div><div class="field"><label>Ort</label><input class="input" id="f-loc" value="${esc(evt.Location)}" placeholder="optional" /></div></div>
    <div class="field"><label>Farbe</label><div class="swatches" id="f-col">${COLORS.map((c) => `<button data-col="${c}" class="${c.toLowerCase() === String(evt.ColorHex).toLowerCase() ? 'on' : ''}" style="background:${c}"></button>`).join('')}</div></div>
    <div class="field"><label>Notizen</label><textarea class="input" id="f-notes">${esc(evt.Notes)}</textarea></div>
    <div class="err" id="f-err"></div>
    <div class="actions"><div>${!isNew ? `<button class="btn danger" id="f-del">${ro ? 'Ausblenden' : 'Löschen'}</button>` : ''}</div><div><button class="btn" id="f-cancel">Abbrechen</button>${ro ? '' : '<button class="btn primary" id="f-save">Speichern</button>'}</div></div>`;
  $('#modal-back').hidden = false;
  let color = evt.ColorHex || COLORS[0];
  const allday = $('#f-allday');
  const syncAllDay = () => document.querySelectorAll('.t-only').forEach((x) => (x.style.visibility = allday.classList.contains('on') ? 'hidden' : 'visible'));
  syncAllDay();
  allday.onclick = () => {
    allday.classList.toggle('on');
    syncAllDay();
  };
  $('#f-sd').onchange = () => {
    if ($('#f-ed').value < $('#f-sd').value) $('#f-ed').value = $('#f-sd').value;
  };
  $('#f-col').onclick = (ev) => {
    const b = ev.target.closest('[data-col]');
    if (!b) return;
    color = b.dataset.col;
    for (const x of $('#f-col').children) x.classList.toggle('on', x === b);
  };
  $('#f-cancel').onclick = close;
  if ($('#f-del'))
    $('#f-del').onclick = async () => {
      state.events = await api.remove(evt.Id);
      close();
      render();
      toast('Termin gelöscht.');
    };
  if ($('#f-save'))
    $('#f-save').onclick = async () => {
      const title = $('#f-title').value.trim();
      if (!title) return ($('#f-err').textContent = 'Bitte einen Titel eingeben.');
      const ad = allday.classList.contains('on');
      const [sy, sm, sd] = $('#f-sd').value.split('-').map(Number);
      const [ey, em, ed] = $('#f-ed').value.split('-').map(Number);
      const [sh, smin] = ($('#f-st').value || '09:00').split(':').map(Number);
      const [eh, emin] = ($('#f-et').value || '10:00').split(':').map(Number);
      let start = new Date(sy, sm - 1, sd, ad ? 0 : sh, ad ? 0 : smin);
      let end = ad ? new Date(ey, em - 1, ed + 1, 0, 0) : new Date(ey, em - 1, ed, eh, emin);
      if (!ad && end <= start && sameDay(start, end)) end = new Date(start.getTime() + 3600000);
      if (end <= start) return ($('#f-err').textContent = 'Das Ende muss nach dem Beginn liegen.');
      const v1 = Number($('#f-r1').value);
      const v2 = Number($('#f-r2').value);
      const saved = {
        ...evt,
        Title: title,
        Location: $('#f-loc').value.trim(),
        Notes: $('#f-notes').value.trim(),
        AllDay: ad,
        Start: Recur.isoLocal(start),
        End: Recur.isoLocal(end),
        ColorHex: color,
        Reminder: v1 >= 0,
        ReminderMinutes: Math.max(0, v1),
        ReminderMinutes2: v2 === v1 ? -1 : v2,
        Frequency: $('#f-rep').value,
        Interval: 1,
      };
      state.events = await api.save(saved);
      close();
      state.cursor = startOfDay(start);
      render();
      toast(isNew ? 'Termin angelegt – auch in der Island sichtbar.' : 'Termin gespeichert.');
    };
  setTimeout(() => $('#f-title')?.focus(), 30);
}

function close() {
  $('#modal-back').hidden = true;
}

/* -------------------------------------------------------------------- Events */
document.addEventListener('click', (ev) => {
  const del = ev.target.closest('[data-del]');
  if (del) {
    ev.stopPropagation();
    if (del.dataset.armed !== '1') {
      // erst nachfragen: zweiter Klick löscht
      del.dataset.armed = '1';
      del.textContent = 'Löschen?';
      del.classList.add('armed');
      setTimeout(() => {
        if (!del.isConnected) return;
        del.dataset.armed = '';
        del.textContent = '✕';
        del.classList.remove('armed');
      }, 2500);
      return;
    }
    api.remove(del.dataset.del).then((list) => {
      state.events = list;
      render();
      toast('Termin gelöscht.');
    });
    return;
  }
  const edit = ev.target.closest('[data-edit]');
  if (edit) {
    const evt = state.events.find((x) => x.Id === edit.dataset.edit);
    if (evt) return openEditor(evt);
  }
  if (ev.target.closest('[data-new]')) return openEditor(null, state.cursor);
  const mini = ev.target.closest('[data-mini]');
  if (mini) {
    state.mini = new Date(state.mini.getFullYear(), state.mini.getMonth() + Number(mini.dataset.mini), 1);
    return renderMini();
  }
  const day = ev.target.closest('[data-day]');
  if (day) {
    const d = new Date(day.dataset.day);
    if (day.closest('#mini')) {
      state.cursor = startOfDay(d);
      return render();
    }
    return openEditor(null, d);
  }
  const view = ev.target.closest('[data-view]');
  if (view) {
    state.view = view.dataset.view;
    for (const b of $('#views').children) b.classList.toggle('on', b === view);
    render();
  }
});
$('#modal-back').addEventListener('mousedown', (ev) => {
  if (ev.target === $('#modal-back')) close();
});
document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape') close();
  if (ev.key === 'n' && !ev.target.closest('input, textarea, select') && $('#modal-back').hidden) openEditor(null, state.cursor);
});
$('#new').onclick = () => openEditor(null, state.cursor);
$('#today').onclick = () => {
  state.cursor = startOfDay(new Date());
  state.mini = startOfDay(new Date());
  render();
};
const step = (dir) => {
  const c = new Date(state.cursor);
  if (state.view === 'month') c.setMonth(c.getMonth() + dir, 1);
  else c.setDate(c.getDate() + dir * 7);
  state.cursor = startOfDay(c);
  state.mini = new Date(c.getFullYear(), c.getMonth(), 1);
  render();
};
$('#prev').onclick = () => step(-1);
$('#fwd').onclick = () => step(1);
$('#brand-ic').innerHTML = window.icon ? window.icon('calendar', 22) : '';

api.onChanged((list) => {
  state.events = list;
  render();
});
(async () => {
  state.events = await api.list();
  render();
  setInterval(renderNext, 30000);
})();
