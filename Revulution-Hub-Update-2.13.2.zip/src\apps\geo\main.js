'use strict';

const fs = require('fs');
const path = require('path');
const { boot, bindHubProfile, bindChat } = require('../shared/boot');

const ctx = boot('geo', __dirname);
const { app, ipcMain } = ctx.electron;
bindHubProfile(ipcMain);
bindChat(ipcMain);
const file = () => path.join(app.getPath('userData'), 'profile.json');

ipcMain.handle('load', () => {
  try {
    return JSON.parse(fs.readFileSync(file(), 'utf8'));
  } catch {
    return null;
  }
});
ipcMain.handle('save', (_event, profile) => {
  fs.mkdirSync(path.dirname(file()), { recursive: true });
  fs.writeFileSync(`${file()}.tmp`, JSON.stringify(profile));
  fs.renameSync(`${file()}.tmp`, file());
  return true;
});

/* ------------------------------------------------------------------ Street-View-Suche */
// Sucht das nächste offizielle Google-Street-View-Panorama (Straße, keine Nutzerfotos)
// in der Nähe eines Punktes. Braucht keinen API-Schlüssel.
async function findPano(lat, lng, radius) {
  const { net } = ctx.electron;
  const url =
    'https://maps.googleapis.com/maps/api/js/GeoPhotoService.SingleImageSearch?pb=' +
    `!1m5!1sapiv3!5sUS!11m2!1m1!1b0!2m4!1m2!3d${lat}!4d${lng}!2d${radius}` +
    '!3m18!2m2!1sen!2sUS!9m1!1e2!11m12!1m3!1e2!2b1!3e2!1m3!1e3!2b1!3e2!1m3!1e10!2b1!3e2!4m6!1e1!1e2!1e3!1e4!1e8!1e6&callback=_xdc_._v2mub5';
  const res = await (net?.fetch ? net.fetch(url) : fetch(url));
  const text = await res.text();
  const id = /\[2,"([A-Za-z0-9_-]{22})"\]/.exec(text);
  const pos = /\[\[null,null,(-?\d+\.\d+),(-?\d+\.\d+)\]/.exec(text);
  if (!id || !pos) return null;
  return { pano: id[1], lat: Number(pos[1]), lng: Number(pos[2]) };
}

ipcMain.handle('pano:find', async (_event, { lat, lng, radii = [800, 4000, 20000] }) => {
  for (const r of radii) {
    try {
      const hit = await findPano(lat, lng, r);
      if (hit) return hit;
    } catch {
      return null; // offline oder gesperrt → Spiel nutzt die einfache Ansicht
    }
  }
  return null;
});
