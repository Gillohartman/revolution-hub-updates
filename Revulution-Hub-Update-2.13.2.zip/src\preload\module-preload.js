'use strict';

/**
 * Preload wrapper for every module window/view inside Revolution Hub.
 * It prefixes outgoing IPC channels with the module id (matching src/main/shim.js),
 * adds the hub's click sounds to the main views and then runs the module's own preload.
 */
const { ipcRenderer } = require('electron');
const path = require('path');

function arg(name) {
  const hit = process.argv.find((value) => value.startsWith(`--${name}=`));
  return hit ? hit.slice(name.length + 3) : '';
}

const moduleId = arg('hub-module');
const original = arg('hub-preload');
const isMainView = process.argv.includes('--hub-view');

// Captured before the prefixing below: hub channels are not module channels.
const hubInvoke = ipcRenderer.invoke.bind(ipcRenderer);

if (moduleId) {
  const prefix = `${moduleId}:`;
  for (const method of ['invoke', 'send', 'sendSync']) {
    const call = ipcRenderer[method].bind(ipcRenderer);
    ipcRenderer[method] = (channel, ...args) => call(prefix + channel, ...args);
  }
}

if (isMainView) {
  const { createClickSound } = require(path.join(__dirname, '..', 'shared', 'sound.js'));
  const sound = createClickSound();
  ipcRenderer.on('hub:appearance', (_event, appearance) => sound.configure({ enabled: appearance.sounds, volume: appearance.volume, style: appearance.clickSound, clip: appearance.clickClip }));
  window.addEventListener('DOMContentLoaded', () => {
    sound.attach(document);
    hubInvoke('hub-view:appearance').then((appearance) => sound.configure({ enabled: appearance.sounds, volume: appearance.volume, style: appearance.clickSound, clip: appearance.clickClip })).catch(() => {});
  });
}

if (original) require(original);
