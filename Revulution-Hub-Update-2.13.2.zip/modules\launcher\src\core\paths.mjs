import os from "node:os";
import path from "node:path";
import fs from "node:fs";

/** Root data directory for all Revolution user data. */
export function dataDir() {
  const override = process.env.REVOLUTION_DATA_DIR;
  if (override) return path.resolve(override);
  if (process.platform === "win32") {
    return path.join(process.env.APPDATA || path.join(os.homedir(), "AppData", "Roaming"), "Revolution");
  }
  if (process.platform === "darwin") {
    return path.join(os.homedir(), "Library", "Application Support", "Revolution");
  }
  return path.join(process.env.XDG_DATA_HOME || path.join(os.homedir(), ".local", "share"), "Revolution");
}

export function metaDir() {
  return path.join(dataDir(), "meta");
}
export function librariesDir() {
  return path.join(metaDir(), "libraries");
}
export function assetsDir() {
  return path.join(metaDir(), "assets");
}
export function indexesDir() {
  return path.join(assetsDir(), "indexes");
}
export function objectsDir() {
  return path.join(assetsDir(), "objects");
}
export function versionsDir() {
  return path.join(metaDir(), "versions");
}
export function instancesDir() {
  return path.join(dataDir(), "instances");
}
export function javaDir() {
  return path.join(dataDir(), "java");
}
export function logsDir() {
  return path.join(dataDir(), "logs");
}
export function cacheDir() {
  return path.join(dataDir(), "cache");
}
export function nativesDir(instanceId) {
  return path.join(cacheDir(), "natives", instanceId);
}
export function settingsFile() {
  return path.join(dataDir(), "settings.json");
}
export function accountsFile() {
  return path.join(dataDir(), "accounts.json");
}
export function instanceDir(id) {
  return path.join(instancesDir(), id);
}
export function instanceFile(id) {
  return path.join(instanceDir(id), "instance.json");
}
/** Per-instance game directory ("--gameDir"). */
export function gameDir(id) {
  return path.join(instanceDir(id), ".minecraft");
}

const DIRS = [dataDir, metaDir, librariesDir, assetsDir, indexesDir, objectsDir, versionsDir, instancesDir, javaDir, logsDir, cacheDir];

export function ensureDirs() {
  for (const dir of DIRS) fs.mkdirSync(dir(), { recursive: true });
}

export function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/** Sanitize an arbitrary string into a safe folder/id segment. */
export function slug(value, fallback = "unnamed") {
  const cleaned = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return cleaned || fallback;
}
