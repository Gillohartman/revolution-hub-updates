'use strict';
/*
 * Gegner aus einem Online-Spiel anschreiben oder als Freund hinzufügen.
 * GameChat.mine() → eigene Chat-Angaben (für die Setup-Nachricht an den Gegner).
 * GameChat.buttons(peer) → HTML mit den Knöpfen, die der Gegner erlaubt.
 */
(function () {
  let me = null;
  const load = () => window.hubChat?.identity().then((x) => (me = x)).catch(() => null);
  load();
  setInterval(load, 30000);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const peers = new Map();
  window.GameChat = {
    mine() {
      return me ? { code: me.code, dm: me.allowGameDMs, fr: me.allowFriendReq } : null;
    },
    buttons(peer, name, game, cos) {
      if (!peer || !/^[A-Z0-9]{8}$/.test(String(peer.code || '')) || peer.code === me?.code) return '';
      peers.set(peer.code, { code: peer.code, name, game, cos });
      const b = [];
      if (peer.dm !== false) b.push(`<button class="btn small ghost gc-btn" data-gc-dm="${esc(peer.code)}">Nachricht</button>`);
      if (peer.fr !== false) b.push(`<button class="btn small ghost gc-btn" data-gc-friend="${esc(peer.code)}">Freund hinzufügen</button>`);
      return b.join(' ');
    },
  };
  document.addEventListener('click', (e) => {
    const dm = e.target.closest?.('[data-gc-dm]')?.dataset.gcDm;
    const fr = e.target.closest?.('[data-gc-friend]')?.dataset.gcFriend;
    const code = dm || fr;
    if (!code) return;
    const p = peers.get(code) || { code };
    if (dm) window.hubChat?.dm(p).catch(() => {});
    else {
      window.hubChat?.friend(p).catch(() => {});
      e.target.closest('button').textContent = 'Anfrage gesendet';
      e.target.closest('button').disabled = true;
    }
  });
})();
