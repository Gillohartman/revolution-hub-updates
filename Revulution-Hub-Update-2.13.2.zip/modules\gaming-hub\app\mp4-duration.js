'use strict';

/**
 * MediaRecorder schreibt fragmentierte MP4s ohne Gesamtdauer: mvhd.duration
 * bleibt 0 und mdhd.duration enthält nur das erste Fragment. Player zeigen
 * dadurch eine falsche (oft viel zu lange) Länge an.
 *
 * Hier wird die Dauer aus den Fragmenten (tfhd/trun) gelesen und in mvhd und
 * mdhd geschrieben. Die Box-Größen bleiben gleich, es verschiebt sich nichts.
 */

const DESCEND = new Set(['moov', 'trak', 'mdia', 'mvex', 'moof', 'traf']);

function readBoxes(buffer, start, end, parent) {
  const list = [];
  let offset = start;
  while (offset + 8 <= end) {
    let size = buffer.readUInt32BE(offset);
    const type = buffer.toString('latin1', offset + 4, offset + 8);
    let header = 8;
    if (size === 1) {
      if (offset + 16 > end) break;
      size = Number(buffer.readBigUInt64BE(offset + 8));
      header = 16;
    } else if (size === 0) {
      size = end - offset;
    }
    if (size < header || offset + size > end) break;
    list.push({ type, offset, size, header, body: offset + header, end: offset + size, parent });
    offset += size;
  }
  return list;
}

function collect(buffer) {
  const all = [];
  const visit = (start, end, parent) => {
    for (const box of readBoxes(buffer, start, end, parent)) {
      all.push(box);
      if (DESCEND.has(box.type)) visit(box.body, box.end, box.type);
    }
  };
  visit(0, buffer.length, null);
  return all;
}

/** Summierte Dauer je Track-ID, in der Zeiteinheit des jeweiligen Tracks. */
function fragmentDurations(buffer, boxes) {
  const totals = new Map();
  for (const traf of boxes.filter((box) => box.type === 'traf')) {
    const scope = boxes.filter(
      (box) => box.parent === 'traf' && box.offset >= traf.body && box.end <= traf.end,
    );
    const tfhd = scope.find((box) => box.type === 'tfhd');
    const trun = scope.find((box) => box.type === 'trun');
    if (!tfhd || !trun) continue;

    const tfhdFlags = buffer.readUInt32BE(tfhd.body) & 0xffffff;
    const trackId = buffer.readUInt32BE(tfhd.body + 4);
    let position = tfhd.body + 8;
    if (tfhdFlags & 0x01) position += 8;
    if (tfhdFlags & 0x02) position += 4;
    const defaultDuration = tfhdFlags & 0x08 ? buffer.readUInt32BE(position) : 0;

    const trunFlags = buffer.readUInt32BE(trun.body) & 0xffffff;
    const count = buffer.readUInt32BE(trun.body + 4);
    let cursor = trun.body + 8;
    if (trunFlags & 0x01) cursor += 4;
    if (trunFlags & 0x04) cursor += 4;

    let duration = 0;
    for (let index = 0; index < count; index += 1) {
      let sampleDuration = defaultDuration;
      if (trunFlags & 0x100) {
        if (cursor + 4 > trun.end) break;
        sampleDuration = buffer.readUInt32BE(cursor);
        cursor += 4;
      }
      if (trunFlags & 0x200) cursor += 4;
      if (trunFlags & 0x400) cursor += 4;
      if (trunFlags & 0x800) cursor += 4;
      duration += sampleDuration;
    }

    const entry = totals.get(trackId) || { duration: 0, samples: 0 };
    entry.duration += duration;
    entry.samples += count;
    totals.set(trackId, entry);
  }
  return totals;
}

/** Version 0 = 32 Bit, Version 1 = 64 Bit. */
function writeUnits(buffer, offset, end, version, units) {
  const value = Math.max(0, Math.round(units));
  if (version === 1) {
    if (offset + 8 <= end) buffer.writeBigUInt64BE(BigInt(value), offset);
  } else if (offset + 4 <= end) {
    buffer.writeUInt32BE(Math.min(value, 0xffffffff), offset);
  }
}

/**
 * Header-Dauer eines MP4-Clips korrigieren (gibt immer einen Buffer zurück).
 * Mit `inPlace` wird direkt im übergebenen Buffer gearbeitet – eine Kopie des
 * kompletten Clips (bei 60 s schnell 100 MB) kostet sonst unnötig Speicher.
 */
function patchMp4Duration(input, options = {}) {
  try {
    const buffer = options.inPlace ? input : Buffer.from(input);
    const boxes = collect(buffer);

    const moov = boxes.find((box) => box.type === 'moov');
    if (!moov) return input;

    const totals = fragmentDurations(buffer, boxes);
    if (totals.size === 0) return input;

    const mvhd = boxes.find((box) => box.type === 'mvhd' && box.parent === 'moov');
    let movieMs = 0;

    for (const trak of boxes.filter((box) => box.type === 'trak' && box.parent === 'moov')) {
      const inside = boxes.filter((box) => box.offset > trak.offset && box.end <= trak.end);
      const tkhd = inside.find((box) => box.type === 'tkhd');
      const mdhd = inside.find((box) => box.type === 'mdhd');
      if (!tkhd || !mdhd) continue;

      const tkhdVersion = buffer[tkhd.body];
      const trackId = buffer.readUInt32BE(tkhd.body + (tkhdVersion === 1 ? 20 : 12));
      const entry = totals.get(trackId);
      if (!entry || entry.duration <= 0) continue;

      const version = buffer[mdhd.body];
      const timescale = buffer.readUInt32BE(mdhd.body + (version === 1 ? 20 : 12));
      if (!timescale) continue;

      writeUnits(buffer, mdhd.body + (version === 1 ? 24 : 16), mdhd.end, version, entry.duration);
      movieMs = Math.max(movieMs, (entry.duration / timescale) * 1000);
    }

    if (mvhd && movieMs > 0) {
      const version = buffer[mvhd.body];
      const timescale = buffer.readUInt32BE(mvhd.body + (version === 1 ? 20 : 12));
      if (timescale) {
        writeUnits(buffer, mvhd.body + (version === 1 ? 24 : 16), mvhd.end, version, (movieMs / 1000) * timescale);
      }
    }

    return buffer;
  } catch {
    return input;
  }
}

module.exports = { patchMp4Duration };
