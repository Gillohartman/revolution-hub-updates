'use strict';

const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('cutter', {
  open: () => ipcRenderer.invoke('open'),
  probe: (file) => ipcRenderer.invoke('probe', file),
  clips: () => ipcRenderer.invoke('clips'),
  exists: (files) => ipcRenderer.invoke('exists', files),
  clipMeta: (file) => ipcRenderer.invoke('clipMeta', file),
  keyFrames: (frames) => ipcRenderer.invoke('keyFrames', frames),
  frame: (job) => ipcRenderer.invoke('frame', job),
  waveform: (file) => ipcRenderer.invoke('waveform', file),
  proxy: (info) => ipcRenderer.invoke('proxy', info),
  recording: (bytes) => ipcRenderer.invoke('recording', bytes),
  camRecording: (bytes) => ipcRenderer.invoke('camrecording', bytes),
  loadProject: () => ipcRenderer.invoke('project:load'),
  saveProject: (project) => ipcRenderer.invoke('project:save', project),
  export: (job) => ipcRenderer.invoke('export', job),
  cancel: () => ipcRenderer.invoke('cancel'),
  reveal: (file) => ipcRenderer.invoke('reveal', file),
  pathFor: (file) => webUtils.getPathForFile(file),
  onProgress: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('progress', listener);
    return () => ipcRenderer.removeListener('progress', listener);
  },
});
