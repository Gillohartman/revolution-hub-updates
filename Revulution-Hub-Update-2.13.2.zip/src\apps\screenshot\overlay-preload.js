'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('overlay', {
  done: (result) => ipcRenderer.send('overlay:done', result),
});
