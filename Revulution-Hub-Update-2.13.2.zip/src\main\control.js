'use strict';

/*
 * Kontrollzentrum & Mini-Apps (Hauptprozess):
 * Lautstärke, Medientasten, Helligkeit, Energiemodus, PC sperren und eine kleine,
 * abgesicherte „fetch“-Brücke für Übersetzer, Wetter und Währungen.
 *
 * Lautstärke und Medientasten laufen über eine kleine C#-Hilfs-DLL, die PowerShell beim
 * ersten Mal einmalig kompiliert (danach schnell).
 */
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { app, clipboard, shell } = require('electron');

function ps(script, timeout = 15000) {
  const encoded = Buffer.from(`$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.Encoding]::UTF8;${script}`, 'utf16le').toString('base64');
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve('');
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, timeout, maxBuffer: 1024 * 1024 }, (error, stdout) => resolve(error ? '' : String(stdout).trim()));
  });
}

const AUDIO_CS = `
using System;
using System.Runtime.InteropServices;
namespace RevHub {
  [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IAudioEndpointVolume {
    int f(); int g(); int h(); int i();
    int SetMasterVolumeLevelScalar(float fLevel, Guid pguidEventContext);
    int j();
    int GetMasterVolumeLevelScalar(out float pfLevel);
    int k(); int l(); int m(); int n();
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, Guid pguidEventContext);
    int GetMute(out bool pbMute);
  }
  [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDevice { int Activate(ref Guid id, int clsCtx, int activationParams, out IAudioEndpointVolume aev); }
  [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDeviceEnumerator { int f(); int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint); }
  [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorComObject { }
  public static class Audio {
    static IAudioEndpointVolume Vol() {
      var enumerator = new MMDeviceEnumeratorComObject() as IMMDeviceEnumerator;
      IMMDevice dev = null;
      Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(0, 1, out dev));
      IAudioEndpointVolume epv = null;
      var epvid = typeof(IAudioEndpointVolume).GUID;
      Marshal.ThrowExceptionForHR(dev.Activate(ref epvid, 23, 0, out epv));
      return epv;
    }
    public static float Get() { float v = -1; Marshal.ThrowExceptionForHR(Vol().GetMasterVolumeLevelScalar(out v)); return v; }
    public static void Set(float v) { Marshal.ThrowExceptionForHR(Vol().SetMasterVolumeLevelScalar(v, Guid.Empty)); }
    public static bool Muted() { bool m; Marshal.ThrowExceptionForHR(Vol().GetMute(out m)); return m; }
    public static void Mute(bool m) { Marshal.ThrowExceptionForHR(Vol().SetMute(m, Guid.Empty)); }
    [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    public static void Key(byte vk) { keybd_event(vk, 0, 0, UIntPtr.Zero); keybd_event(vk, 0, 2, UIntPtr.Zero); }
  }
}`;

function dll() {
  return path.join(app.getPath('userData'), 'tools', 'revhub-audio.dll');
}

/** Lädt (oder baut einmalig) die Hilfs-DLL und führt dann den Befehl aus. */
async function audio(cmd) {
  const file = dll();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const src = AUDIO_CS.replace(/'/g, "''");
  const load = fs.existsSync(file) ? `Add-Type -Path '${file}'` : `Add-Type -TypeDefinition '${src}' -OutputAssembly '${file}' -OutputType Library; Add-Type -Path '${file}'`;
  return ps(`${load}; ${cmd}`);
}

const VK = { playpause: 0xb3, next: 0xb0, prev: 0xb1, mute: 0xad };

async function getVolume() {
  const out = await audio('"$([RevHub.Audio]::Get())|$([RevHub.Audio]::Muted())"');
  const [v, m] = out.split('|');
  const level = Number(String(v).replace(',', '.'));
  return Number.isFinite(level) && level >= 0 ? { level: Math.round(level * 100), muted: /true/i.test(m) } : null;
}

async function setVolume(level) {
  const v = Math.max(0, Math.min(100, Number(level) || 0)) / 100;
  await audio(`[RevHub.Audio]::Mute($false); [RevHub.Audio]::Set([single]${v.toFixed(2)})`);
  return getVolume();
}

async function media(key) {
  if (!VK[key]) return false;
  await audio(`[RevHub.Audio]::Key(${VK[key]})`);
  return true;
}

async function getBrightness() {
  const out = await ps('(Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -ErrorAction SilentlyContinue | Select-Object -First 1).CurrentBrightness');
  const n = parseInt(out, 10);
  return Number.isFinite(n) ? n : null;
}

let brightTimer = null;
function setBrightness(level) {
  const n = Math.max(5, Math.min(100, Math.round(Number(level) || 0)));
  clearTimeout(brightTimer);
  brightTimer = setTimeout(() => ps(`Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods | Invoke-CimMethod -MethodName WmiSetBrightness -Arguments @{Timeout=1;Brightness=${n}} | Out-Null`), 150);
  return n;
}

const PLANS = { balanced: '381b4222-f694-41f0-9685-ff5bb260df2e', performance: '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c', saver: 'a1841308-3541-4fab-bc81-f71556f20b4a' };

function powercfg(args) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve('');
    execFile('powercfg', args, { windowsHide: true, timeout: 8000, encoding: 'latin1' }, (e, out) => resolve(e ? '' : String(out)));
  });
}

async function getPower() {
  const out = await powercfg(['/getactivescheme']);
  const id = /([0-9a-f]{8}-[0-9a-f-]{27})/i.exec(out)?.[1]?.toLowerCase() || '';
  const mode = Object.entries(PLANS).find(([, g]) => g === id)?.[0] || (id ? 'custom' : '');
  return { mode, name: /\((.+)\)/.exec(out)?.[1] || '' };
}

async function setPower(mode) {
  if (!PLANS[mode]) return getPower();
  await powercfg(['/setactive', PLANS[mode]]);
  return getPower();
}

function lockPc() {
  if (process.platform === 'win32') execFile('rundll32.exe', ['user32.dll,LockWorkStation'], { windowsHide: true }, () => {});
  return true;
}

function screenshot() {
  shell.openExternal('ms-screenclip:').catch(() => {});
  return true;
}

/* ------------------------------------------------------------------ fetch-Brücke */
const ALLOWED = ['api.mymemory.translated.net', 'api.frankfurter.app', 'api.frankfurter.dev', 'api.open-meteo.com', 'geocoding-api.open-meteo.com'];

async function toolFetch(url) {
  let u;
  try {
    u = new URL(String(url));
  } catch {
    throw new Error('Ungültige Adresse');
  }
  if (u.protocol !== 'https:' || !ALLOWED.includes(u.hostname)) throw new Error('Diese Adresse ist nicht erlaubt');
  const { net } = require('electron');
  const res = await net.fetch(u.toString(), { headers: { 'User-Agent': 'Revolution-Hub' } });
  if (!res.ok) throw new Error(`Dienst nicht erreichbar (${res.status})`);
  return res.json();
}

/* ------------------------------------------------------------------ Zwischenablage-Verlauf */
const clip = { list: [], last: '', timer: null };
function startClipboard() {
  if (clip.timer) return;
  // readText liefert je nach Electron-Version einen Text oder ein Promise – beides abfangen.
  const read = async () => {
    try {
      const t = await clipboard.readText();
      return typeof t === 'string' ? t : '';
    } catch {
      return '';
    }
  };
  read().then((t) => (clip.last = clip.last || t));
  clip.timer = setInterval(async () => {
    const text = await read();
    if (!text || text === clip.last) return;
    clip.last = text;
    clip.list = [{ text: text.slice(0, 4000), at: Date.now() }, ...clip.list.filter((x) => x.text !== text)].slice(0, 30);
  }, 1500);
}
function clipboardApi(action, value) {
  startClipboard();
  if (action === 'copy' && typeof value === 'string') {
    clipboard.writeText(value);
    clip.last = value;
  }
  if (action === 'clear') clip.list = [];
  if (action === 'remove') clip.list = clip.list.filter((_, i) => i !== Number(value));
  return clip.list;
}

module.exports = { getVolume, setVolume, media, getBrightness, setBrightness, getPower, setPower, lockPc, screenshot, toolFetch, clipboardApi, startClipboard };
