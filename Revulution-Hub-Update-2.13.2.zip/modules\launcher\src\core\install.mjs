import path from "node:path";
import fs from "node:fs";
import AdmZip from "adm-zip";
import { download, downloadAll, fetchJson } from "./http.mjs";
import { ensureDir, librariesDir, objectsDir, indexesDir, nativesDir, versionsDir, cacheDir } from "./paths.mjs";
import { getAssetIndex, resolveVersion, collectLibraries, versionJsonPath, downloadAssetObject } from "./mojang.mjs";
import { writeJson } from "./store.mjs";

/**
 * Install everything a vanilla version needs into the shared meta directory:
 * client jar, all rule-matching libraries, native jars (extracted), and assets.
 */
export async function installVersion(versionId, { onProgress = () => {}, features = {}, skipAssets = false, concurrency = 12, verify = "auto" } = {}) {
  // Warm installs are trusted without re-hashing every asset: that hashing was the slowest
  // part of starting the game. `verify: "full"` (or the Verify files action) still hashes.
  if (verify === "auto") {
    const cached = cachedInstall(versionId);
    if (cached) {
      onProgress({ phase: "done", message: `Minecraft ${versionId} is ready`, done: 1, total: 1 });
      return cached;
    }
  }

  onProgress({ phase: "resolve", message: `Resolving Minecraft ${versionId}` });
  const raw = await loadAnyVersionJson(versionId);
  const version = await resolveVersion(raw);

  const tasks = [];

  // Client jar
  const client = version.downloads?.client;
  if (!client?.url) throw new Error(`Version ${versionId} has no client download`);
  const jarPath = path.join(versionsDir(), version.id, `${version.id}.jar`);
  tasks.push({ url: client.url, path: jarPath, sha1: client.sha1, size: client.size, phase: "client", label: `${version.id} client.jar` });

  // Libraries. Entries without a URL are produced by a loader installer; they must
  // already exist locally, which is checked after the downloads finish.
  const { classpath, natives } = collectLibraries(version, features);
  const localOnly = [];
  for (const lib of classpath) {
    const dest = path.join(librariesDir(), lib.path || `${lib.name.replace(/[:]/g, "/")}.jar`);
    if (!lib.url) {
      localOnly.push({ name: lib.name, dest });
      continue;
    }
    tasks.push({ url: lib.url, path: dest, sha1: lib.sha1, size: lib.size, phase: "libraries", label: path.basename(dest) });
  }
  for (const native of natives) {
    const dest = path.join(librariesDir(), native.path || `${native.name.replace(/[:]/g, "/")}-${native.classifier}.jar`);
    if (!native.url) continue;
    tasks.push({ url: native.url, path: dest, sha1: native.sha1, size: native.size, phase: "natives", label: path.basename(dest) });
  }

  onProgress({ phase: "libraries", message: `Downloading ${tasks.length} files`, done: 0, total: tasks.length });
  await downloadAll(tasks, { concurrency, onProgress: (p) => onProgress(p) });

  const missingLocal = localOnly.filter(({ dest }) => !fs.existsSync(dest));
  if (missingLocal.length) {
    const names = missingLocal.map(({ name }) => name);
    throw new Error(
      `These mod-loader files are missing and the launcher cannot download them: ${names.slice(0, 3).join(", ")}` +
      `${names.length > 3 ? ` (+${names.length - 3} more)` : ""}. Reinstall the loader for this instance.`,
    );
  }

  // Extract natives into a private directory for this instance/version.
  const extracted = extractNatives(natives, version.id, features);
  onProgress({ phase: "natives", message: `Extracted ${extracted.count} native libraries`, done: 1, total: 1 });

  // Assets
  let assetCount = 0;
  if (!skipAssets) {
    const index = await getAssetIndex(version, { onProgress });
    const objects = Object.values(index.objects || {});
    onProgress({ phase: "assets", done: 0, total: objects.length, message: `Downloading ${objects.length} assets` });
    const assetTasks = [];
    for (const object of objects) {
      const dest = path.join(objectsDir(), object.hash.slice(0, 2), object.hash);
      assetTasks.push({
        url: `https://resources.download.minecraft.net/${object.hash.slice(0, 2)}/${object.hash}`,
        path: dest,
        sha1: object.hash,
        size: object.size,
        phase: "assets",
        label: object.hash,
      });
    }
    await downloadAll(assetTasks, { concurrency, onProgress: (p) => onProgress(p) });
    assetCount = assetTasks.length;
    // Virtual/legacy asset layouts used by versions before 1.7.
    if (index.map_to_resources || index.virtual) {
      await buildVirtualAssets(version, index, onProgress);
    }
  }

  const installed = {
    versionId: version.id,
    jar: jarPath,
    classpath,
    natives,
    nativesDir: nativesDir(version.id),
    assetIndexId: version.assetIndex?.id,
    assetCount,
    installedAt: Date.now(),
  };
  await writeJson(path.join(cacheDir(), "installed", `${version.id}.json`), installed);
  onProgress({ phase: "done", message: `Minecraft ${version.id} is ready`, done: 1, total: 1 });
  return { version, ...installed };
}

/**
 * Cheap "already installed" test: one read of the install record plus one existsSync per
 * classpath entry, instead of three thousand SHA-1 hashes over the asset cache.
 */
function cachedInstall(versionId) {
  let record;
  try {
    record = JSON.parse(fs.readFileSync(path.join(cacheDir(), "installed", `${versionId}.json`), "utf8"));
  } catch {
    return null;
  }
  if (!record?.jar || !fs.existsSync(record.jar)) return null;
  for (const entry of record.classpath || []) {
    if (entry?.path && !fs.existsSync(path.join(librariesDir(), entry.path))) return null;
  }
  if (record.nativesDir && fs.existsSync(record.nativesDir)) {
    try {
      if (!fs.readdirSync(record.nativesDir).length) return null;
    } catch {
      return null;
    }
  }
  return { ...record, cached: true, version: null };
}

/** Load a version json from the meta dir if present, otherwise from Mojang. */
async function loadAnyVersionJson(versionId) {
  const local = versionJsonPath(versionId);
  if (fs.existsSync(local)) {
    const data = JSON.parse(fs.readFileSync(local, "utf8"));
    if (data?.id) return data;
  }
  // Import lazily to avoid a circular import at module load time.
  const { getVersionJson } = await import("./mojang.mjs");
  return getVersionJson(versionId);
}

function extractNatives(natives, versionId, features) {
  const target = ensureDir(nativesDir(versionId));
  let count = 0;
  for (const native of natives) {
    const source = path.join(librariesDir(), native.path || `${native.name.replace(/[:]/g, "/")}-${native.classifier}.jar`);
    if (!fs.existsSync(source)) continue;
    try {
      const zip = new AdmZip(source);
      const exclude = new Set(native.extract?.exclude || ["META-INF/"]);
      for (const entry of zip.getEntries()) {
        if (entry.isDirectory) continue;
        if (entry.entryName.startsWith("META-INF/")) continue;
        if ([...exclude].some((pattern) => entry.entryName.startsWith(pattern))) continue;
        zip.extractEntryTo(entry.entryName, target, false, true);
        count++;
      }
    } catch {
      // A broken native jar should not abort the whole install.
    }
  }
  void features;
  return { count, dir: target };
}

/** Build the legacy `assets/virtual/legacy` layout required by old versions. */
async function buildVirtualAssets(version, index, onProgress) {
  const virtualDir = ensureDir(path.join(objectsDir(), "..", "virtual", index.id));
  const tasks = [];
  for (const [name, object] of Object.entries(index.objects || {})) {
    const source = path.join(objectsDir(), object.hash.slice(0, 2), object.hash);
    tasks.push({ name, source, dest: path.join(virtualDir, name) });
  }
  for (const task of tasks) {
    try {
      ensureDir(path.dirname(task.dest));
      if (!fs.existsSync(task.dest)) fs.copyFileSync(task.source, task.dest);
    } catch {
      // ignore individual copy failures
    }
  }
  void version;
  onProgress({ phase: "assets-virtual", done: tasks.length, total: tasks.length, message: `Built legacy asset layout` });
}

/** Verify which of a version's files are present. Used by the "repair" action. */
export async function verifyVersion(versionId) {
  const file = path.join(cacheDir(), "installed", `${versionId}.json`);
  if (!fs.existsSync(file)) return { installed: false, missing: [] };
  const record = JSON.parse(fs.readFileSync(file, "utf8"));
  const missing = [];
  if (!fs.existsSync(record.jar)) missing.push(record.jar);
  for (const lib of record.classpath || []) {
    const dest = path.join(librariesDir(), lib.path || "");
    if (dest && !fs.existsSync(dest)) missing.push(dest);
  }
  return { installed: missing.length === 0, missing, record };
}

export { fetchJson, download, downloadAssetObject, indexesDir };
