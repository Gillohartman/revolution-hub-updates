'use strict';

/*
 * Schach-KI: Alpha-Beta mit iterativer Vertiefung, Transpositionstabelle, Ruhesuche,
 * Nullzug, LMR, Killer-/History-Heuristik. Bewertung: Material + Figurentabellen
 * (Mittel-/Endspiel überblendet), Läuferpaar, Bauernstruktur, offene Linien, Königsschutz.
 */
(function (root) {
  const C = root.ChessCore || (typeof require === 'function' ? require('./chess-core.js') : null);
  const { PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING, WHITE, BLACK, F_CAPTURE, F_PROMO, VALUE, typeOf, colorOf, uci } = C;

  const MATE = 100000;
  const INF = 1000000;

  // Tabellen aus Weiß-Sicht, Zeile 0 = 8. Reihe.
  const PST = {
    [PAWN]: [0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10, 25, 25, 10, 5, 5, 0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0],
    [KNIGHT]: [-50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30, -30, 5, 15, 20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 5, 5, 0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50],
    [BISHOP]: [-20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10, -10, 5, 5, 10, 10, 5, 5, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10, -10, 5, 0, 0, 0, 0, 5, -10, -20, -10, -10, -10, -10, -10, -10, -20],
    [ROOK]: [0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0],
    [QUEEN]: [-20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5, 0, 5, 5, 5, 5, 0, -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20],
    [KING]: [-30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20, -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20],
  };
  const KING_END = [-50, -40, -30, -20, -20, -30, -40, -50, -30, -20, -10, 0, 0, -10, -20, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -30, 0, 0, 0, 0, -30, -30, -50, -30, -30, -30, -30, -30, -30, -50];
  const PAWN_END = [0, 0, 0, 0, 0, 0, 0, 0, 90, 90, 90, 90, 90, 90, 90, 90, 50, 50, 50, 50, 50, 50, 50, 50, 30, 30, 30, 30, 30, 30, 30, 30, 15, 15, 15, 15, 15, 15, 15, 15, 5, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
  const PHASE = [0, 0, 1, 1, 2, 4, 0];

  const idx = (sq, color) => (color === WHITE ? (7 - (sq >> 4)) * 8 + (sq & 7) : (sq >> 4) * 8 + (sq & 7));

  /** Statische Bewertung aus Sicht der Seite am Zug (Centipawns). */
  function evaluate(pos) {
    const b = pos.b;
    let mg = [0, 0], eg = [0, 0], phase = 0;
    const pawnFiles = [new Int8Array(8), new Int8Array(8)];
    const pawnRanks = [[], []];
    const bishops = [0, 0];
    const rooks = [[], []];
    for (let sq = 0; sq < 128; sq += 1) {
      if (sq & 0x88) {
        sq += 7;
        continue;
      }
      const p = b[sq];
      if (!p) continue;
      const t = typeOf(p), c = colorOf(p), s = c >> 3;
      const i = idx(sq, c);
      phase += PHASE[t];
      if (t === KING) {
        mg[s] += PST[KING][i];
        eg[s] += KING_END[i];
        continue;
      }
      mg[s] += VALUE[t] + PST[t][i];
      eg[s] += VALUE[t] + (t === PAWN ? PAWN_END[i] : PST[t][i]);
      if (t === PAWN) {
        pawnFiles[s][sq & 7] += 1;
        pawnRanks[s].push(sq);
      } else if (t === BISHOP) bishops[s] += 1;
      else if (t === ROOK) rooks[s].push(sq);
    }
    for (let s = 0; s < 2; s += 1) {
      const o = 1 - s;
      if (bishops[s] >= 2) {
        mg[s] += 30;
        eg[s] += 50;
      }
      for (let f = 0; f < 8; f += 1) {
        const n = pawnFiles[s][f];
        if (n > 1) {
          mg[s] -= 12 * (n - 1);
          eg[s] -= 20 * (n - 1);
        }
        if (n && !(f > 0 && pawnFiles[s][f - 1]) && !(f < 7 && pawnFiles[s][f + 1])) {
          mg[s] -= 12 * n;
          eg[s] -= 15 * n;
        }
      }
      // Freibauern
      for (const sq of pawnRanks[s]) {
        const f = sq & 7, r = sq >> 4;
        let passed = true;
        for (const other of pawnRanks[o]) {
          const of = other & 7, or = other >> 4;
          if (Math.abs(of - f) <= 1 && (s === 0 ? or > r : or < r)) {
            passed = false;
            break;
          }
        }
        if (passed) {
          const adv = s === 0 ? r : 7 - r;
          mg[s] += adv * 6;
          eg[s] += adv * adv * 4;
        }
      }
      for (const sq of rooks[s]) {
        const f = sq & 7;
        if (!pawnFiles[s][f]) {
          mg[s] += pawnFiles[o][f] ? 10 : 20;
          eg[s] += 10;
        }
      }
    }
    phase = Math.min(24, phase);
    const us = pos.turn >> 3;
    const score = ((mg[0] - mg[1]) * phase + (eg[0] - eg[1]) * (24 - phase)) / 24;
    return Math.round(us === 0 ? score : -score) + 10;
  }

  /* -------------------------------------------------------------- Suche */

  class Engine {
    constructor() {
      this.tt = new Map();
      this.history = new Int32Array(16 * 128);
    }

    reset() {
      this.tt.clear();
      this.history.fill(0);
    }

    probe(pos) {
      return this.tt.get(pos.key());
    }

    store(pos, depth, score, flag, move, ply) {
      if (this.tt.size > 600000) this.tt.clear();
      // Mattwerte relativ zur Wurzel speichern
      let s = score;
      if (s > MATE - 1000) s += ply;
      else if (s < -MATE + 1000) s -= ply;
      const k = pos.key();
      const old = this.tt.get(k);
      if (old && old.depth > depth && !move) return;
      this.tt.set(k, { depth, score: s, flag, move: move ? uci(move) : old?.move || null });
    }

    timeUp() {
      if ((++this.nodes & 1023) === 0 && (Date.now() > this.deadline || this.nodes > this.maxNodes)) this.stopped = true;
      return this.stopped;
    }

    order(pos, moves, ttMove, ply) {
      const killers = this.killers[ply] || [];
      for (const m of moves) {
        const u = uci(m);
        if (u === ttMove) m.sort = 1e7;
        else if (m.flags & F_CAPTURE) m.sort = 1e6 + VALUE[typeOf(m.captured)] * 10 - VALUE[typeOf(m.piece)] / 10;
        else if (m.promo) m.sort = 9e5 + VALUE[m.promo];
        else if (killers[0] === u) m.sort = 8e5;
        else if (killers[1] === u) m.sort = 7e5;
        else m.sort = this.history[m.piece * 128 + m.to];
      }
      moves.sort((a, b) => b.sort - a.sort);
      return moves;
    }

    quiesce(pos, alpha, beta, ply) {
      if (this.timeUp()) return 0;
      const stand = evaluate(pos);
      if (stand >= beta) return beta;
      if (stand > alpha) alpha = stand;
      if (ply > 40) return stand;
      const moves = this.order(pos, pos.moves(true), null, ply);
      for (const m of moves) {
        // Delta-Pruning: aussichtslose Schlagzüge weglassen
        if (!m.promo && stand + VALUE[typeOf(m.captured)] + 200 < alpha) continue;
        if (!pos.make(m)) continue;
        const score = -this.quiesce(pos, -beta, -alpha, ply + 1);
        pos.unmake();
        if (this.stopped) return 0;
        if (score >= beta) return beta;
        if (score > alpha) alpha = score;
      }
      return alpha;
    }

    search(pos, depth, alpha, beta, ply, allowNull = true) {
      if (this.timeUp()) return 0;
      if (ply > 0) {
        if (pos.half >= 100 || pos.repetitions() >= 2) return 0;
        // Mattdistanz-Pruning
        alpha = Math.max(alpha, -MATE + ply);
        beta = Math.min(beta, MATE - ply - 1);
        if (alpha >= beta) return alpha;
      }
      const inCheck = pos.inCheck();
      if (inCheck) depth += 1;
      if (depth <= 0) return this.quiesce(pos, alpha, beta, ply);

      const entry = this.probe(pos);
      if (entry && entry.depth >= depth && ply > 0) {
        let s = entry.score;
        if (s > MATE - 1000) s -= ply;
        else if (s < -MATE + 1000) s += ply;
        if (entry.flag === 0) return s;
        if (entry.flag === 1 && s >= beta) return s;
        if (entry.flag === 2 && s <= alpha) return s;
      }

      // Nullzug
      if (allowNull && !inCheck && depth >= 3 && ply > 0 && beta - alpha === 1 && this.hasPieces(pos) && evaluate(pos) >= beta) {
        pos.makeNull();
        const score = -this.search(pos, depth - 3, -beta, -beta + 1, ply + 1, false);
        pos.unmakeNull();
        if (this.stopped) return 0;
        if (score >= beta) return beta;
      }

      const moves = this.order(pos, pos.moves(), entry?.move || null, ply);
      let best = -INF, bestMove = null, legal = 0;
      const startAlpha = alpha;
      for (const m of moves) {
        if (!pos.make(m)) continue;
        legal += 1;
        let score;
        const quiet = !(m.flags & F_CAPTURE) && !m.promo;
        if (legal === 1) score = -this.search(pos, depth - 1, -beta, -alpha, ply + 1);
        else {
          const reduce = quiet && !inCheck && depth >= 3 && legal > 3 && !pos.inCheck() ? 1 + (legal > 10 ? 1 : 0) : 0;
          score = -this.search(pos, depth - 1 - reduce, -alpha - 1, -alpha, ply + 1);
          if (score > alpha && (reduce || score < beta)) score = -this.search(pos, depth - 1, -beta, -alpha, ply + 1);
        }
        pos.unmake();
        if (this.stopped) return 0;
        if (score > best) {
          best = score;
          bestMove = m;
        }
        if (score > alpha) {
          alpha = score;
          if (alpha >= beta) {
            if (quiet) {
              const k = (this.killers[ply] = this.killers[ply] || []);
              const u = uci(m);
              if (k[0] !== u) {
                k[1] = k[0];
                k[0] = u;
              }
              this.history[m.piece * 128 + m.to] += depth * depth;
            }
            break;
          }
        }
      }
      if (!legal) return inCheck ? -MATE + ply : 0;
      this.store(pos, depth, best, best >= beta ? 1 : best > startAlpha ? 0 : 2, bestMove, ply);
      return best;
    }

    hasPieces(pos) {
      for (let sq = 0; sq < 128; sq += 1) {
        if (sq & 0x88) continue;
        const p = pos.b[sq];
        if (p && colorOf(p) === pos.turn && typeOf(p) !== PAWN && typeOf(p) !== KING) return true;
      }
      return false;
    }

    pv(pos, max = 10) {
      const line = [];
      const seen = new Set();
      let made = 0;
      for (let i = 0; i < max; i += 1) {
        const e = this.probe(pos);
        if (!e?.move || seen.has(pos.key())) break;
        seen.add(pos.key());
        const m = pos.find(e.move);
        if (!m) break;
        line.push(e.move);
        pos.make(m);
        made += 1;
      }
      while (made--) pos.unmake();
      return line;
    }

    begin({ timeMs = 1000, maxNodes = 5e6 } = {}) {
      this.nodes = 0;
      this.stopped = false;
      this.deadline = Date.now() + timeMs;
      this.maxNodes = maxNodes;
      this.killers = [];
    }

    /** Bester Zug mit normalem Alpha-Beta an der Wurzel. */
    think(pos, { maxDepth = 6, timeMs = 1000 } = {}) {
      this.begin({ timeMs });
      let result = null;
      for (let depth = 1; depth <= maxDepth; depth += 1) {
        const score = this.search(pos, depth, -INF, INF, 0);
        if (this.stopped && result) break;
        const e = this.probe(pos);
        if (e?.move) result = { move: e.move, score, depth, pv: this.pv(pos) };
        if (this.stopped || Math.abs(score) > MATE - 1000) break;
      }
      if (!result) {
        const legal = pos.legalMoves();
        result = legal.length ? { move: uci(legal[0]), score: 0, depth: 0, pv: [uci(legal[0])] } : null;
      }
      return result;
    }

    /**
     * Bewertet jeden legalen Zug einzeln (volles Fenster) – für die Zugbewertung des Coaches
     * und für die schwächeren KI-Stufen. Werte aus Sicht der Seite am Zug.
     */
    scoreAll(pos, { maxDepth = 4, timeMs = 1200, minDepth = 1 } = {}) {
      this.begin({ timeMs: timeMs * 4 });
      const softDeadline = Date.now() + timeMs;
      const legal = pos.legalMoves();
      let done = null;
      for (let depth = minDepth; depth <= maxDepth; depth += 1) {
        const rows = [];
        // Vorherige Reihenfolge nutzen (beste zuerst) → mehr TT-Treffer
        const order = done ? done.map((r) => legal.find((m) => uci(m) === r.uci)) : legal;
        for (const m of order) {
          pos.make(m);
          const score = -this.search(pos, depth - 1, -INF, INF, 1);
          const reply = this.stopped ? [] : this.pv(pos, 8);
          pos.unmake();
          if (this.stopped) break;
          rows.push({ uci: uci(m), score, reply });
        }
        if (this.stopped) break;
        rows.sort((a, b) => b.score - a.score);
        done = rows.map((r) => ({ ...r, depth }));
        if (Date.now() > softDeadline) break;
      }
      return done || legal.map((m) => ({ uci: uci(m), score: 0, reply: [], depth: 0 }));
    }
  }

  /* -------------------------------------------------------------- Stufen */

  // Grob an Elo angelehnt: Tiefe, Bedenkzeit, Streuung (cp) und Patzer-Wahrscheinlichkeit.
  const LEVELS = [
    { elo: 400, name: 'Anfänger', depth: 1, time: 120, spread: 600, blunder: 0.5 },
    { elo: 600, name: 'Neuling', depth: 1, time: 180, spread: 320, blunder: 0.28 },
    { elo: 800, name: 'Gelegenheitsspieler', depth: 2, time: 250, spread: 170, blunder: 0.14 },
    { elo: 1000, name: 'Hobbyspieler', depth: 2, time: 300, spread: 80, blunder: 0.06 },
    { elo: 1200, name: 'Fortgeschritten', depth: 3, time: 400, spread: 45, blunder: 0.03 },
    { elo: 1400, name: 'Vereinsspieler', depth: 3, time: 500, spread: 25, blunder: 0.015 },
    { elo: 1600, name: 'Starker Vereinsspieler', depth: 4, time: 700, spread: 15, blunder: 0 },
    { elo: 1800, name: 'Experte', depth: 6, time: 900, spread: 0, blunder: 0 },
    { elo: 2000, name: 'Meisterkandidat', depth: 9, time: 1600, spread: 0, blunder: 0 },
    { elo: 2200, name: 'Meister', depth: 40, time: 3000, spread: 0, blunder: 0 },
  ];

  function pickMove(engine, pos, level) {
    const L = LEVELS[Math.max(0, Math.min(LEVELS.length - 1, level))];
    if (!L.spread && !L.blunder) {
      const r = engine.think(pos, { maxDepth: L.depth, timeMs: L.time });
      return r ? { move: r.move, score: r.score, pv: r.pv } : null;
    }
    const rows = engine.scoreAll(pos, { maxDepth: L.depth, timeMs: L.time });
    if (!rows.length) return null;
    const best = rows[0].score;
    // Matt sieht jede Stufe, aber ein Patzer kann trotzdem passieren
    if (Math.random() < L.blunder && best < MATE - 1000) {
      const pool = rows.filter((r) => r.score > best - 600);
      const r = pool[Math.floor(Math.random() * pool.length)];
      return { move: r.uci, score: r.score, pv: [r.uci, ...r.reply] };
    }
    const pool = rows.filter((r) => r.score >= best - L.spread);
    const weights = pool.map((r) => Math.exp((r.score - best) / Math.max(20, L.spread / 2.5)));
    let x = Math.random() * weights.reduce((a, b) => a + b, 0);
    for (let i = 0; i < pool.length; i += 1) {
      x -= weights[i];
      if (x <= 0) return { move: pool[i].uci, score: pool[i].score, pv: [pool[i].uci, ...pool[i].reply] };
    }
    return { move: pool[0].uci, score: pool[0].score, pv: [pool[0].uci, ...pool[0].reply] };
  }

  const api = { Engine, evaluate, pickMove, LEVELS, MATE };
  root.ChessEngine = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
