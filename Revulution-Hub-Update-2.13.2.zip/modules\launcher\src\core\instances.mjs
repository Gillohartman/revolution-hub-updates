import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import AdmZip from "adm-zip";
import { instanceDir, instancesDir, instanceFile, gameDir, slug, ensureDir } from "./paths.mjs";
import { readJson, writeJson } from "./store.mjs";

/** Folders created inside every instance's game directory. */
export const GAME_FOLDERS = ["mods", "resourcepacks", "shaderpacks", "saves", "screenshots", "config", "logs", "schematics", "datapacks", "backups"];

export function emptyInstance(patch = {}) {
  const now = Date.now();
  return {
    id: patch.id || `instance-${now.toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    name: patch.name || "New Instance",
    icon: patch.icon || "🧱",
    group: patch.group || "Default",
    notes: patch.notes || "",
    mcVersion: patch.mcVersion || "",
    versionId: patch.versionId || patch.mcVersion || "",
    loader: patch.loader || { type: "vanilla", version: "" },
    java: {
      path: "",
      major: 0,
      memoryMinMb: 512,
      memoryMaxMb: 4096,
      jvmArgs: "",
      gameArgs: "",
      autoDownloadJava: true,
      ...(patch.java || {}),
    },
    resolution: { width: 1280, height: 720, fullscreen: false, ...(patch.resolution || {}) },
    server: { ip: "", port: 25565, autoConnect: false, ...(patch.server || {}) },
    quickPlay: patch.quickPlay || { enabled: false, world: "", server: "" },
    content: patch.content || [],
    created: patch.created || now,
    lastPlayed: patch.lastPlayed || 0,
    playTimeMs: patch.playTimeMs || 0,
    launchCount: patch.launchCount || 0,
    lastExitCode: patch.lastExitCode ?? null,
    managed: patch.managed ?? true,
  };
}

export async function ensureInstanceDirs(id) {
  const root = ensureDir(gameDir(id));
  for (const folder of GAME_FOLDERS) ensureDir(path.join(root, folder));
  return root;
}

export async function listInstances() {
  ensureDir(instancesDir());
  const entries = await fsp.readdir(instancesDir(), { withFileTypes: true });
  const instances = [];
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const data = await readJson(instanceFile(entry.name));
    if (data?.id) instances.push(normalize(data));
  }
  return instances.sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0) || a.name.localeCompare(b.name));
}

function normalize(data) {
  const merged = emptyInstance({ ...data, id: data.id });
  return { ...merged, ...data, java: { ...merged.java, ...(data.java || {}) }, resolution: { ...merged.resolution, ...(data.resolution || {}) } };
}

export async function getInstance(id) {
  const data = await readJson(instanceFile(id));
  if (!data) throw new Error(`Instance not found: ${id}`);
  return normalize(data);
}

export async function createInstance(patch = {}) {
  const base = emptyInstance(patch);
  await ensureDir(instanceDir(base.id));
  await ensureInstanceDirs(base.id);
  await writeJson(instanceFile(base.id), base);
  return base;
}

export async function updateInstance(id, patch = {}) {
  const current = await getInstance(id);
  const next = {
    ...current,
    ...patch,
    id: current.id,
    java: { ...current.java, ...(patch.java || {}) },
    resolution: { ...current.resolution, ...(patch.resolution || {}) },
    server: { ...current.server, ...(patch.server || {}) },
    loader: { ...current.loader, ...(patch.loader || {}) },
  };
  await writeJson(instanceFile(id), next);
  return next;
}

export async function duplicateInstance(id, { name } = {}) {
  const source = await getInstance(id);
  const copy = emptyInstance({ ...source, id: undefined, name: name || `${source.name} (copy)`, created: Date.now(), lastPlayed: 0, playTimeMs: 0, launchCount: 0, lastExitCode: null });
  const destDir = ensureDir(instanceDir(copy.id));
  await fsp.cp(gameDir(id), path.join(destDir, ".minecraft"), { recursive: true, force: true });
  await writeJson(instanceFile(copy.id), copy);
  return copy;
}

export async function deleteInstance(id) {
  const dir = instanceDir(id);
  if (!fs.existsSync(dir)) throw new Error(`Instance not found: ${id}`);
  await fsp.rm(dir, { recursive: true, force: true });
  return true;
}

/** Recursive size of an instance in bytes (for the UI's storage readout). */
export async function instanceSize(id) {
  let total = 0;
  let files = 0;
  async function walk(dir) {
    let entries;
    try {
      entries = await fsp.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(full);
      else if (entry.isFile()) {
        try {
          total += (await fsp.stat(full)).size;
          files++;
        } catch { /* file vanished */ }
      }
    }
  }
  await walk(instanceDir(id));
  return { bytes: total, files };
}

/** Export an instance as a portable `.revolution.zip` archive. */
export async function exportInstance(id, destFile, { includeSaves = true } = {}) {
  const instance = await getInstance(id);
  const zip = new AdmZip();
  zip.addFile("instance.json", Buffer.from(JSON.stringify({ ...instance, content: instance.content, exportedAt: Date.now(), format: "revolution/1" }, null, 2)));
  const root = gameDir(id);
  const skip = includeSaves ? [] : ["saves", "logs"];
  function addFolder(dir, prefix) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (skip.includes(entry.name) && prefix === "") continue;
      const full = path.join(dir, entry.name);
      const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) addFolder(full, rel);
      else if (entry.isFile()) zip.addFile(`.minecraft/${rel}`, fs.readFileSync(full));
    }
  }
  if (fs.existsSync(root)) addFolder(root, "");
  await zip.writeZipPromise(destFile);
  return { file: destFile, instances: 1 };
}

/** Import an exported instance archive or a Modrinth `.mrpack` (handled by modpacks). */
export async function importInstanceArchive(file, { name } = {}) {
  const zip = new AdmZip(file);
  const manifestEntry = zip.getEntry("instance.json");
  let instance;
  if (manifestEntry) {
    instance = normalize(JSON.parse(manifestEntry.getData().toString("utf8")));
    instance.id = `instance-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    instance.name = name || instance.name || "Imported Instance";
  } else {
    instance = emptyInstance({ name: name || path.basename(file, path.extname(file)), mcVersion: "", versionId: "" });
  }
  instance.created = Date.now();
  const destDir = ensureDir(instanceDir(instance.id));
  const gameRoot = path.join(destDir, ".minecraft");
  ensureDir(gameRoot);

  for (const entry of zip.getEntries()) {
    if (entry.isDirectory) continue;
    const name_ = entry.entryName.replace(/\\/g, "/");
    const rel = name_.startsWith(".minecraft/") ? name_.slice(".minecraft/".length) : name_ === "instance.json" ? null : name_;
    if (!rel) continue;
    const target = path.join(gameRoot, rel);
    if (!target.startsWith(gameRoot)) continue; // zip-slip guard
    ensureDir(path.dirname(target));
    await fsp.writeFile(target, entry.getData());
  }
  await ensureInstanceDirs(instance.id);
  await writeJson(instanceFile(instance.id), instance);
  return instance;
}

/** Keep only instances whose folders still exist (housekeeping). */
export async function pruneOrphanRecords() {
  const entries = await fsp.readdir(instancesDir(), { withFileTypes: true }).catch(() => []);
  return entries.filter((e) => e.isDirectory()).map((e) => e.name);
}

export { slug, ensureDir };
