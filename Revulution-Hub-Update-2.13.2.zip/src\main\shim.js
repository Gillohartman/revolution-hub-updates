'use strict';

/**
 * Module sandbox for Revolution Hub.
 *
 * Every app that lives inside the hub (Dropzone, Launcher, Gaming Hub) was written as a
 * stand-alone Electron app. Instead of rewriting them, each one gets its own view of the
 * `electron` module:
 *
 *  - IPC channels are prefixed with the module id, so two modules can both register
 *    "settings:get" without clashing. The matching renderer side lives in
 *    src/preload/module-preload.js.
 *  - Each module runs in its own session partition (own protocols, cache, storage).
 *  - `app` keeps the module's own data folder, name and version, while the hub owns the
 *    single-instance lock, the tray and the app lifecycle.
 *  - The module's main window becomes a view inside the hub window (see module-view.js).
 */

const electron = require('electron');
const path = require('path');
const { EventEmitter } = require('events');

const MODULE_PRELOAD = path.join(__dirname, '..', 'preload', 'module-preload.js');

/** Collected from all modules; registered once by the hub before the app is ready. */
const privilegedSchemes = [];

/** Module app events the hub handles itself. */
const HUB_OWNED_EVENTS = new Set(['second-instance', 'window-all-closed', 'activate', 'open-file', 'open-url']);

function createShim(mod, hub) {
  const realApp = electron.app;
  const prefix = `${mod.id}:`;
  const channel = (name) => prefix + name;
  const moduleSession = () => electron.session.fromPartition(mod.partition);

  /* ------------------------------------------------------------------ ipcMain */
  const ipcMain = {
    handle: (name, fn) => electron.ipcMain.handle(channel(name), fn),
    handleOnce: (name, fn) => electron.ipcMain.handleOnce(channel(name), fn),
    removeHandler: (name) => electron.ipcMain.removeHandler(channel(name)),
    on(name, fn) {
      electron.ipcMain.on(channel(name), fn);
      return ipcMain;
    },
    once(name, fn) {
      electron.ipcMain.once(channel(name), fn);
      return ipcMain;
    },
    off(name, fn) {
      electron.ipcMain.off(channel(name), fn);
      return ipcMain;
    },
    removeListener(name, fn) {
      electron.ipcMain.removeListener(channel(name), fn);
      return ipcMain;
    },
    removeAllListeners(name) {
      if (name) electron.ipcMain.removeAllListeners(channel(name));
      return ipcMain;
    },
  };

  /* ---------------------------------------------------------------------- app */
  const appOverrides = {
    getPath: (name) => (name === 'userData' ? mod.dataDir : realApp.getPath(name)),
    setPath: (name, value) => {
      if (name === 'userData') mod.dataDir = value;
    },
    getName: () => mod.name,
    setName: () => {},
    getVersion: () => mod.version,
    requestSingleInstanceLock: () => true,
    hasSingleInstanceLock: () => true,
    releaseSingleInstanceLock: () => {},
    setAppUserModelId: () => {},
    setLoginItemSettings: () => {},
    setAboutPanelOptions: () => {},
    focus: () => hub.showWindow(),
    quit: () => hub.quit(),
  };
  for (const method of ['on', 'once', 'addListener']) {
    appOverrides[method] = (event, fn) => {
      if (!HUB_OWNED_EVENTS.has(event)) realApp[method](event, fn);
      return app;
    };
  }
  const app = new Proxy(realApp, {
    get(target, key) {
      if (Object.prototype.hasOwnProperty.call(appOverrides, key)) return appOverrides[key];
      const value = Reflect.get(target, key);
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });

  /* ----------------------------------------------------------------- protocol */
  const protocol = {
    registerSchemesAsPrivileged: (schemes) => {
      for (const scheme of schemes) {
        if (!privilegedSchemes.some((entry) => entry.scheme === scheme.scheme)) privilegedSchemes.push(scheme);
      }
    },
  };
  for (const method of ['handle', 'unhandle', 'isProtocolHandled', 'registerFileProtocol', 'registerBufferProtocol', 'registerStreamProtocol', 'registerStringProtocol', 'registerHttpProtocol', 'unregisterProtocol', 'interceptFileProtocol', 'uninterceptProtocol']) {
    protocol[method] = (...args) => moduleSession().protocol[method](...args);
  }

  /* ------------------------------------------------------------------ session */
  const session = new Proxy(electron.session, {
    get(target, key) {
      if (key === 'defaultSession') return moduleSession();
      const value = Reflect.get(target, key);
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });

  /* ------------------------------------------------------------ BrowserWindow */
  class ModuleBrowserWindow extends electron.BrowserWindow {
    constructor(options = {}) {
      super(wrapWindowOptions(mod, options));
    }

    static fromWebContents(contents) {
      return hub.viewForContents(contents) || electron.BrowserWindow.fromWebContents(contents);
    }

    static getFocusedWindow() {
      return electron.BrowserWindow.getFocusedWindow();
    }
  }

  /* ------------------------------------------------------------------- dialog */
  const unwrap = (win) => (win && win.__isModuleView ? hub.window : win);
  const dialog = new Proxy(electron.dialog, {
    get(target, key) {
      const value = Reflect.get(target, key);
      if (typeof value !== 'function') return value;
      return (first, ...rest) => value.call(target, unwrap(first), ...rest);
    },
  });

  /* --------------------------------------------------------------------- Tray */
  // Modules do not get their own tray icon; their menu becomes a submenu of the hub tray.
  class ModuleTray extends EventEmitter {
    constructor() {
      super();
      this.menu = null;
      this.destroyed = false;
      hub.registerModuleTray(mod.id, this);
    }
    setContextMenu(menu) {
      this.menu = menu;
      hub.refreshTray();
    }
    setToolTip() {}
    setTitle() {}
    setImage() {}
    setPressedImage() {}
    setIgnoreDoubleClickEvents() {}
    displayBalloon(options) {
      hub.notify(options?.title || mod.name, options?.content || '');
    }
    popUpContextMenu() {}
    closeContextMenu() {}
    getBounds() {
      return { x: 0, y: 0, width: 0, height: 0 };
    }
    isDestroyed() {
      return this.destroyed;
    }
    destroy() {
      this.destroyed = true;
      this.menu = null;
      hub.refreshTray();
    }
  }

  const crashReporter = { start() {}, getLastCrashReport: () => null, getUploadedReports: () => [], getUploadToServer: () => false, setUploadToServer() {}, addExtraParameter() {}, removeExtraParameter() {}, getParameters: () => ({}) };

  const overrides = { app, ipcMain, protocol, session, BrowserWindow: ModuleBrowserWindow, dialog, Tray: ModuleTray, crashReporter };
  return new Proxy(electron, {
    get(target, key) {
      if (Object.prototype.hasOwnProperty.call(overrides, key)) return overrides[key];
      return Reflect.get(target, key);
    },
  });
}

/** Routes a module window's preload through the IPC-prefixing wrapper. */
function wrapWindowOptions(mod, options) {
  const webPreferences = { ...(options.webPreferences || {}) };
  webPreferences.partition = mod.partition;
  if (webPreferences.preload) {
    webPreferences.additionalArguments = [
      ...(webPreferences.additionalArguments || []),
      `--hub-module=${mod.id}`,
      `--hub-preload=${webPreferences.preload}`,
    ];
    webPreferences.preload = MODULE_PRELOAD;
    webPreferences.sandbox = false;
  }
  return { ...options, webPreferences };
}

module.exports = { createShim, wrapWindowOptions, privilegedSchemes, MODULE_PRELOAD };
