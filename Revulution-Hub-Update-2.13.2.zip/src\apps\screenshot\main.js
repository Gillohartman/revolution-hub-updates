'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { boot } = require('../shared/boot');

const ctx = boot('screenshot', __dirname);
const { app, ipcMain, BrowserWindow, desktopCapturer, screen, clipboard, nativeImage, globalShortcut, shell, dialog, Notification, ClipboardItem } = ctx.electron;

/** Electron 45 uses the async ClipboardItem API; older versions have writeImage. */
async function copyImage(image) {
  if (typeof clipboard.writeImage === 'function') return clipboard.writeImage(image);
  return clipboard.write([new ClipboardItem({ 'image/png': image.toPNG() })]);
}
const hub = ctx.hub;

/* ------------------------------------------------------------------ settings */

const dataDir = () => app.getPath('userData');
const settingsFile = () => path.join(dataDir(), 'settings.json');
const DEFAULTS = {
  hotkey: 'CommandOrControl+Shift+X',
  autoCopy: true,
  openEditor: true,
  folder: '',
};

let settings = { ...DEFAULTS };
function loadSettings() {
  try {
    settings = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) };
  } catch {
    settings = { ...DEFAULTS };
  }
  if (!settings.folder) settings.folder = path.join(app.getPath('pictures'), 'Screenshots', 'Revolution');
}
function saveSettings() {
  fs.mkdirSync(dataDir(), { recursive: true });
  fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
}

let registered = '';
function registerHotkey() {
  if (registered) globalShortcut.unregister(registered);
  registered = '';
  if (!settings.hotkey) return { ok: true };
  try {
    if (globalShortcut.register(settings.hotkey, () => capture())) {
      registered = settings.hotkey;
      return { ok: true };
    }
  } catch {
    /* invalid accelerator */
  }
  return { ok: false };
}

/* ------------------------------------------------------------------- capture */

let overlays = [];
let capturing = false;

function stamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

async function capture({ hideHub = false } = {}) {
  if (capturing) return;
  capturing = true;
  try {
    if (hideHub && hub.window?.isVisible()) {
      hub.window.minimize();
      await new Promise((resolve) => setTimeout(resolve, 380));
    }
    const displays = screen.getAllDisplays();
    const largest = displays.reduce(
      (size, d) => ({ width: Math.max(size.width, Math.round(d.size.width * d.scaleFactor)), height: Math.max(size.height, Math.round(d.size.height * d.scaleFactor)) }),
      { width: 0, height: 0 },
    );
    const sources = await Promise.race([
      desktopCapturer.getSources({ types: ['screen'], thumbnailSize: largest }),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Der Bildschirm konnte nicht aufgenommen werden.')), 10000)),
    ]);
    if (!sources.length) throw new Error('Kein Bildschirm gefunden.');
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'revolution-shot-'));
    const shots = displays.map((display, index) => {
      const source = sources.find((s) => String(s.display_id) === String(display.id)) || sources[index] || sources[0];
      const image = source.thumbnail;
      const file = path.join(tmp, `${display.id}.png`);
      fs.writeFileSync(file, image.toPNG());
      return { display, image, file };
    });
    openOverlays(shots, tmp);
  } catch (error) {
    capturing = false;
    console.error('[screenshot] capture failed', error);
    hub.notify('Screenshot fehlgeschlagen', error.message || String(error));
    if (hideHub) hub.showWindow();
  }
}

function openOverlays(shots, tmp) {
  closeOverlays();
  overlays = shots.map((shot) => {
    const { bounds } = shot.display;
    const win = new BrowserWindow({
      x: bounds.x,
      y: bounds.y,
      width: bounds.width,
      height: bounds.height,
      frame: false,
      show: false,
      resizable: false,
      movable: false,
      minimizable: false,
      maximizable: false,
      fullscreenable: false,
      skipTaskbar: true,
      alwaysOnTop: true,
      enableLargerThanScreen: true,
      backgroundColor: '#000000',
      webPreferences: { preload: path.join(__dirname, 'overlay-preload.js'), contextIsolation: true, sandbox: false },
    });
    win.setAlwaysOnTop(true, 'screen-saver');
    win.setBounds(bounds);
    win.loadFile(path.join(__dirname, 'overlay.html'), { query: { image: shot.file, id: String(shot.display.id) } });
    win.once('ready-to-show', () => {
      win.show();
      win.focus();
    });
    return { win, shot };
  });
  overlays.tmp = tmp;
}

function closeOverlays() {
  for (const { win } of overlays) if (!win.isDestroyed()) win.destroy();
  if (overlays.tmp) fs.rmSync(overlays.tmp, { recursive: true, force: true });
  overlays = [];
  capturing = false;
}

ipcMain.on('overlay:done', async (_event, result) => {
  const entry = overlays.find((o) => String(o.shot.display.id) === String(result?.id));
  if (!result || result.cancel || !entry) {
    closeOverlays();
    return;
  }
  const { image, display } = entry.shot;
  const size = image.getSize();
  const scale = size.width / display.bounds.width;
  let picture = image;
  if (result.rect) {
    const r = result.rect;
    const crop = {
      x: Math.max(0, Math.round(r.x * scale)),
      y: Math.max(0, Math.round(r.y * scale)),
      width: Math.min(size.width, Math.round(r.width * scale)),
      height: Math.min(size.height, Math.round(r.height * scale)),
    };
    if (crop.width >= 2 && crop.height >= 2) picture = image.crop(crop);
  }
  closeOverlays();
  await finish(picture);
});

async function finish(picture) {
  fs.mkdirSync(settings.folder, { recursive: true });
  const file = path.join(settings.folder, `Screenshot_${stamp()}.png`);
  fs.writeFileSync(file, picture.toPNG());
  if (settings.autoCopy) await copyImage(picture).catch(() => {});
  ctx.send('captured', { file });
  pending = file;
  // The island (or Windows) confirms it with the picture itself as the icon.
  hub.notify('Screenshot gespeichert', settings.autoCopy ? 'In der Zwischenablage · Klick öffnet die Datei' : path.basename(file), {
    app: 'Screenshot',
    icon: file,
    open: file,
  });
  if (settings.openEditor) hub.open('screenshot');
}

let pending = null;

/* ----------------------------------------------------------------------- IPC */

ipcMain.handle('settings', () => ({ ...settings, registered: registered === settings.hotkey }));
ipcMain.handle('settings:set', (_event, patch) => {
  for (const key of ['autoCopy', 'openEditor']) if (typeof patch?.[key] === 'boolean') settings[key] = patch[key];
  if (typeof patch?.hotkey === 'string') settings.hotkey = patch.hotkey;
  saveSettings();
  const result = 'hotkey' in (patch || {}) ? registerHotkey() : { ok: true };
  // Startseite des Hubs zeigt den Hotkey an → sofort aktualisieren
  try {
    hub.pushState();
  } catch {
    /* Hub noch nicht bereit */
  }
  return { ...settings, registered: registered === settings.hotkey, hotkeyOk: result.ok };
});
ipcMain.handle('folder:choose', async () => {
  const result = await dialog.showOpenDialog(hub.window, { title: 'Speicherordner für Screenshots', properties: ['openDirectory', 'createDirectory'], defaultPath: settings.folder });
  if (result.canceled || !result.filePaths[0]) return settings;
  settings.folder = result.filePaths[0];
  saveSettings();
  return settings;
});
ipcMain.handle('capture', () => capture({ hideHub: true }));
ipcMain.handle('pending', () => {
  const file = pending;
  pending = null;
  return file;
});
ipcMain.handle('list', () => {
  try {
    return fs
      .readdirSync(settings.folder)
      .filter((name) => /\.(png|jpe?g)$/i.test(name))
      .map((name) => {
        const file = path.join(settings.folder, name);
        return { file, name, time: fs.statSync(file).mtimeMs };
      })
      .sort((a, b) => b.time - a.time)
      .slice(0, 60);
  } catch {
    return [];
  }
});
ipcMain.handle('read', (_event, file) => {
  // Data URL instead of file://, so the editor canvas is not "tainted" and can be exported.
  if (!file.startsWith(settings.folder)) throw new Error('Unbekannte Datei.');
  return `data:image/png;base64,${fs.readFileSync(file).toString('base64')}`;
});
ipcMain.handle('copy', async (_event, dataUrl) => {
  await copyImage(nativeImage.createFromDataURL(dataUrl));
  return true;
});
ipcMain.handle('save', (_event, { file, dataUrl }) => {
  if (!file.startsWith(settings.folder)) throw new Error('Unbekannte Datei.');
  fs.writeFileSync(file, nativeImage.createFromDataURL(dataUrl).toPNG());
  return true;
});
ipcMain.handle('saveAs', async (_event, { name, dataUrl }) => {
  const result = await dialog.showSaveDialog(hub.window, {
    title: 'Screenshot speichern',
    defaultPath: path.join(app.getPath('pictures'), name || `Screenshot_${stamp()}.png`),
    filters: [
      { name: 'PNG', extensions: ['png'] },
      { name: 'JPEG', extensions: ['jpg'] },
    ],
  });
  if (result.canceled || !result.filePath) return null;
  const image = nativeImage.createFromDataURL(dataUrl);
  fs.writeFileSync(result.filePath, /\.jpe?g$/i.test(result.filePath) ? image.toJPEG(92) : image.toPNG());
  return result.filePath;
});
ipcMain.handle('reveal', (_event, file) => shell.showItemInFolder(file || settings.folder));
ipcMain.handle('delete', async (_event, file) => {
  if (!file.startsWith(settings.folder)) throw new Error('Unbekannte Datei.');
  await shell.trashItem(file);
  return true;
});

/* ----------------------------------------------------------------- lifecycle */

app.whenReady().then(() => {
  loadSettings();
  registerHotkey();
  hub.api.screenshot = () => capture({ hideHub: false });
});

app.on('will-quit', () => {
  if (registered) globalShortcut.unregister(registered);
  closeOverlays();
});
