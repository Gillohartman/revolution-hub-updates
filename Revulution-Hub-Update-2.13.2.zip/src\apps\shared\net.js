'use strict';

/*
 * Online-Räume für Schach und Geo: ein kleiner MQTT-3.1.1-Client über WebSocket.
 * Beide Spieler verbinden sich mit einem öffentlichen MQTT-Broker und treffen sich in
 * einem Raum (Thema) mit einem zufälligen Code. Es braucht keinen eigenen Server.
 */
(function (root) {
  const BROKERS = ['wss://broker.emqx.io:8084/mqtt', 'wss://broker.hivemq.com:8884/mqtt', 'wss://test.mosquitto.org:8081/mqtt'];
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  function varint(n) {
    const out = [];
    do {
      let b = n % 128;
      n = Math.floor(n / 128);
      if (n > 0) b |= 0x80;
      out.push(b);
    } while (n > 0);
    return out;
  }
  const str = (s) => {
    const b = enc.encode(s);
    return [b.length >> 8, b.length & 255, ...b];
  };
  const packet = (type, body) => new Uint8Array([type, ...varint(body.length), ...body]);

  class MqttSocket {
    constructor(url, clientId) {
      this.url = url;
      this.clientId = clientId;
      this.handlers = new Set();
      this.buf = new Uint8Array(0);
      this.pid = 1;
      this.open = false;
    }

    connect(timeout = 6000) {
      return new Promise((resolve, reject) => {
        let done = false;
        const fail = (e) => {
          if (done) return;
          done = true;
          try {
            this.ws?.close();
          } catch {
            /* egal */
          }
          reject(e instanceof Error ? e : new Error(String(e)));
        };
        const timer = setTimeout(() => fail(new Error('Zeitüberschreitung')), timeout);
        try {
          this.ws = new WebSocket(this.url, ['mqtt']);
        } catch (e) {
          clearTimeout(timer);
          fail(e);
          return;
        }
        this.ws.binaryType = 'arraybuffer';
        this.ws.onopen = () => {
          const body = [...str('MQTT'), 4, 0x02, 0, 60, ...str(this.clientId)];
          this.ws.send(packet(0x10, body));
        };
        this.ws.onerror = () => fail(new Error('Verbindung fehlgeschlagen'));
        this.ws.onclose = () => {
          this.open = false;
          clearInterval(this.ping);
          if (!done) fail(new Error('Verbindung geschlossen'));
          else this.onclose?.();
        };
        this.ws.onmessage = (ev) => {
          const chunk = new Uint8Array(ev.data);
          const merged = new Uint8Array(this.buf.length + chunk.length);
          merged.set(this.buf);
          merged.set(chunk, this.buf.length);
          this.buf = merged;
          this.parse((type) => {
            if (type === 2 && !done) {
              done = true;
              clearTimeout(timer);
              this.open = true;
              this.ping = setInterval(() => this.raw(new Uint8Array([0xc0, 0])), 25000);
              resolve(this);
            }
          });
        };
      });
    }

    parse(onType) {
      for (;;) {
        if (this.buf.length < 2) return;
        let mult = 1, len = 0, i = 1, b;
        do {
          if (i >= this.buf.length) return;
          b = this.buf[i++];
          len += (b & 127) * mult;
          mult *= 128;
        } while (b & 128);
        if (this.buf.length < i + len) return;
        const head = this.buf[0];
        const body = this.buf.slice(i, i + len);
        this.buf = this.buf.slice(i + len);
        const type = head >> 4;
        onType(type);
        if (type === 3) {
          const tl = (body[0] << 8) | body[1];
          const topic = dec.decode(body.slice(2, 2 + tl));
          let p = 2 + tl;
          if ((head >> 1) & 3) p += 2; // Paket-ID bei QoS > 0
          const payload = dec.decode(body.slice(p));
          for (const h of this.handlers) h(topic, payload);
        }
      }
    }

    raw(bytes) {
      if (this.ws?.readyState === 1) this.ws.send(bytes);
    }

    subscribe(topic) {
      const id = this.pid++;
      this.raw(packet(0x82, [id >> 8, id & 255, ...str(topic), 0]));
    }

    publish(topic, text, retain = false) {
      this.raw(packet(retain ? 0x31 : 0x30, [...str(topic), ...enc.encode(text)]));
    }

    close() {
      clearInterval(this.ping);
      try {
        this.raw(new Uint8Array([0xe0, 0]));
        this.ws?.close();
      } catch {
        /* egal */
      }
    }
  }

  /**
   * Ein Spielraum. Nachrichten: { t: Typ, from, ...daten }.
   * room.on('msg', fn), room.send(type, data). Präsenz läuft automatisch ('hi'/'bye').
   */
  class Room {
    constructor({ app, code, name, brokers = BROKERS }) {
      this.app = app;
      this.code = String(code).toUpperCase();
      this.name = name || 'Spieler';
      this.id = Math.random().toString(36).slice(2, 10);
      this.brokers = brokers;
      this.topic = `revolution-hub/v1/${app}/${this.code}`;
      this.listeners = {};
      this.peers = new Map(); // id → { name, seen }
      this.sock = null;
    }

    on(ev, fn) {
      (this.listeners[ev] = this.listeners[ev] || []).push(fn);
      return this;
    }

    emit(ev, ...args) {
      for (const fn of this.listeners[ev] || []) {
        try {
          fn(...args);
        } catch (e) {
          console.error(e);
        }
      }
    }

    async join() {
      let lastError = null;
      for (const url of this.brokers) {
        try {
          const sock = new MqttSocket(url, `rh-${this.id}`);
          await sock.connect();
          this.sock = sock;
          this.broker = url;
          break;
        } catch (e) {
          lastError = e;
        }
      }
      if (!this.sock) throw lastError || new Error('Kein Server erreichbar');
      this.sock.handlers.add((topic, payload) => {
        if (topic !== this.topic) return;
        let msg;
        try {
          msg = JSON.parse(payload);
        } catch {
          return;
        }
        if (!msg || msg.from === this.id) return;
        const known = this.peers.has(msg.from);
        this.peers.set(msg.from, { name: msg.name || 'Gegner', seen: Date.now() });
        if (!known && msg.t !== 'bye') {
          this.emit('peer', { id: msg.from, name: msg.name });
          this.send('hi'); // sofort antworten, damit der andere uns auch sieht
        }
        if (msg.t === 'bye') {
          this.peers.delete(msg.from);
          this.emit('left', msg.from);
          return;
        }
        if (msg.t !== 'hi') this.emit('msg', msg);
      });
      this.sock.onclose = () => this.emit('disconnect');
      this.sock.subscribe(this.topic);
      this.send('hi');
      this.hiTimer = setInterval(() => {
        this.send('hi');
        const now = Date.now();
        for (const [id, p] of this.peers) {
          if (now - p.seen > 20000) {
            this.peers.delete(id);
            this.emit('left', id);
          }
        }
      }, 4000);
      return this;
    }

    send(t, data = {}) {
      this.sock?.publish(this.topic, JSON.stringify({ t, from: this.id, name: this.name, at: Date.now(), ...data }));
    }

    leave() {
      clearInterval(this.hiTimer);
      try {
        this.send('bye');
      } catch {
        /* egal */
      }
      setTimeout(() => this.sock?.close(), 150);
    }
  }

  /**
   * Zufällige Gegner finden: alle Suchenden treffen sich in einem öffentlichen Warteraum
   * (pro „Topf“, z. B. Rang). Der Spieler mit der kleineren ID bietet einen Raum-Code an,
   * der andere nimmt an – danach spielen beide in einem eigenen Raum wie bei Freunden.
   * accept(peer) entscheidet, ob ein Gegner passt (z. B. Elo-Fenster).
   */
  class Matchmaker {
    constructor({ app, bucket = 'all', name, info = {}, accept = () => true }) {
      this.app = app;
      this.bucket = bucket;
      this.name = name;
      this.info = info;
      this.accept = accept;
      this.listeners = {};
      this.done = false;
      this.started = Date.now();
    }

    on(ev, fn) {
      (this.listeners[ev] = this.listeners[ev] || []).push(fn);
      return this;
    }

    emit(ev, ...args) {
      for (const fn of this.listeners[ev] || []) fn(...args);
    }

    async start() {
      this.room = new Room({ app: `${this.app}-queue`, code: `Q-${this.bucket}`, name: this.name });
      this.room.on('msg', (m) => this.onMsg(m));
      await this.room.join();
      const seek = () => !this.done && this.room?.send('seek', { info: this.info, since: this.started });
      seek();
      this.timer = setInterval(() => {
        seek();
        this.emit('tick', Math.round((Date.now() - this.started) / 1000), this.room?.peers.size || 0);
      }, 1500);
      return this;
    }

    onMsg(m) {
      if (this.done) return;
      if (m.t === 'seek') {
        const peer = { id: m.from, name: m.name, info: m.info || {}, waited: (Date.now() - this.started) / 1000 };
        if (this.room.id < m.from && !this.offered && this.accept(peer)) {
          this.offered = { to: m.from, code: newCode(), at: Date.now() };
          this.room.send('offer', { to: m.from, code: this.offered.code, info: this.info });
          // Keine Antwort? Nächstes Angebot erlauben.
          setTimeout(() => {
            if (!this.done && this.offered?.to === m.from) this.offered = null;
          }, 4000);
        }
      } else if (m.t === 'offer' && m.to === this.room.id) {
        if (!this.accept({ id: m.from, name: m.name, info: m.info || {} })) return;
        this.room.send('accept', { to: m.from, code: m.code, info: this.info });
        this.finish({ code: m.code, host: false, opp: { name: m.name, info: m.info || {} } });
      } else if (m.t === 'accept' && m.to === this.room.id && this.offered?.code === m.code) {
        this.finish({ code: m.code, host: true, opp: { name: m.name, info: m.info || {} } });
      }
    }

    finish(match) {
      this.done = true;
      this.stop();
      this.emit('match', match);
    }

    stop() {
      clearInterval(this.timer);
      this.room?.leave();
      this.room = null;
    }
  }

  /**
   * Weltweite Rangliste ohne eigene Datenbank: jeder Spieler legt seinen Eintrag als
   * „retained“-Nachricht beim öffentlichen Server ab; wer abonniert, bekommt alle Einträge.
   */
  async function leaderboard(app, entry = null, { wait = 2500, brokers = BROKERS } = {}) {
    let sock = null;
    for (const url of brokers) {
      try {
        sock = await new MqttSocket(url, `rh-lb-${Math.random().toString(36).slice(2, 10)}`).connect();
        break;
      } catch {
        sock = null;
      }
    }
    if (!sock) throw new Error('Kein Server erreichbar');
    const base = `revolution-hub/v1/lb/${app}`;
    const list = new Map();
    sock.handlers.add((topic, payload) => {
      if (!topic.startsWith(base + '/')) return;
      try {
        const e = JSON.parse(payload);
        if (e && typeof e.name === 'string' && Number.isFinite(e.rating)) list.set(topic.slice(base.length + 1), { ...e, name: e.name.slice(0, 20) });
      } catch {
        /* ungültig */
      }
    });
    if (entry?.id) sock.publish(`${base}/${entry.id}`, JSON.stringify({ ...entry, at: Date.now() }), true);
    sock.subscribe(`${base}/+`);
    await new Promise((r) => setTimeout(r, wait));
    sock.close();
    return [...list.entries()].map(([id, e]) => ({ id, ...e }));
  }

  const newCode = () => Array.from(crypto.getRandomValues(new Uint8Array(6)), (b) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 32]).join('');

  root.RevNet = { Room, MqttSocket, BROKERS, newCode, Matchmaker, leaderboard };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.RevNet;
})(typeof self !== 'undefined' ? self : globalThis);
