'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const on = (channel, callback) => {
  const listener = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
};

contextBridge.exposeInMainWorld('shots', {
  settings: () => ipcRenderer.invoke('settings'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  chooseFolder: () => ipcRenderer.invoke('folder:choose'),
  capture: () => ipcRenderer.invoke('capture'),
  pending: () => ipcRenderer.invoke('pending'),
  list: () => ipcRenderer.invoke('list'),
  read: (file) => ipcRenderer.invoke('read', file),
  copy: (dataUrl) => ipcRenderer.invoke('copy', dataUrl),
  save: (file, dataUrl) => ipcRenderer.invoke('save', { file, dataUrl }),
  saveAs: (name, dataUrl) => ipcRenderer.invoke('saveAs', { name, dataUrl }),
  reveal: (file) => ipcRenderer.invoke('reveal', file),
  remove: (file) => ipcRenderer.invoke('delete', file),
  onCaptured: (callback) => on('captured', callback),
  onVisibility: (callback) => on('hub:visibility', callback),
});
