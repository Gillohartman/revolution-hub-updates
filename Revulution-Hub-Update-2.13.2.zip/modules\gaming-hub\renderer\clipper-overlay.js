const labelEl = document.getElementById('label');
const hotkeyEl = document.getElementById('hotkey');
const messageEl = document.getElementById('message');
const pill = document.getElementById('pill');
const wallEl = document.getElementById('wall');

const VIDEO = /\.(mp4|webm)$/i;

let currentWall = null;
let wallImage = null;

function clearWall() {
  wallEl.pause?.();
  wallEl.removeAttribute('src');
  wallEl.load?.();
  wallEl.hidden = true;
  if (wallImage) {
    wallImage.remove();
    wallImage = null;
  }
}

function applyWallpaper(name) {
  const value = String(name || '');
  if (value === currentWall) return;
  currentWall = value;
  clearWall();
  pill.classList.toggle('has-wall', value.length > 0);
  if (!value) return;

  const url = `wall://media/${encodeURIComponent(value)}`;
  if (VIDEO.test(value)) {
    wallEl.hidden = false;
    wallEl.src = url;
    wallEl.play?.().catch(() => {});
    return;
  }

  // Standbild-Wallpaper (jpg/png/webp/gif): Bild statt Video zeigen.
  wallImage = document.createElement('img');
  wallImage.className = 'wall';
  wallImage.alt = '';
  wallImage.src = url;
  pill.insertBefore(wallImage, wallEl.nextSibling);
  pill.querySelectorAll('.wall').forEach((node) => {
    node.style.display = 'block';
  });
}

function apply(payload) {
  if (!payload) return;
  labelEl.textContent = payload.active ? 'Clipper aktiv' : 'Clipper bereit';
  hotkeyEl.textContent = payload.hotkey || 'aus';
  const message = String(payload.message || '');
  messageEl.textContent = message;
  messageEl.classList.toggle('is-fresh', message.length > 0);
  applyWallpaper(payload.wallpaper);
}

if (window.clipper) {
  window.clipper.onState(apply);
  window.clipper.ready();
}
