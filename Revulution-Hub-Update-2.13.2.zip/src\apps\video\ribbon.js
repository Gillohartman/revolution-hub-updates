'use strict';

/*
 * Reiter-Leiste oben im Video-Schnitt: alle Funktionen schön geordnet in Reitern
 * (Start, Bearbeiten, Tempo, Look, Effekte, Ton, Übergänge, Export) – darunter die Arbeitsfläche.
 * Nutzt die Funktionen aus video.js (gleicher Skript-Bereich).
 */
(function () {
  const bar = document.querySelector('.bar');
  if (!bar) return;
  const ic = (n, s = 16) => (window.icon ? window.icon(n, s) : '');
  const sel = () => (state.selected ? clipById(state.selected) : null);
  const needClip = () => {
    const c = sel();
    if (!c) toast('Wähle zuerst einen Clip in der Zeitleiste.', 'error');
    return c;
  };
  const apply = (fn) => {
    const c = needClip();
    if (!c) return;
    snapshot();
    fn(c);
    changed();
  };

  const TABS = {
    start: ['Start', () => [
      ['add', 'plus', 'Hinzufügen', () => document.getElementById('add').click()],
      ['text', 'text', 'Text', () => addText()],
      ['rec', 'mic', 'Sprachaufnahme', () => startRecording()],
      ['cam', 'camera', 'Kamera (Reaction)', () => window.CamRec?.open()],
      ['new', 'doc', 'Neues Projekt', () => document.getElementById('new').click()],
      ['export', 'download', 'Exportieren', () => !document.getElementById('export').disabled ? openExport() : toast('Füge zuerst etwas zur Zeitleiste hinzu.', 'error')],
    ]],
    edit: ['Bearbeiten', () => [
      ['undo', 'undo', 'Rückgängig', () => restore(state.history, state.future)],
      ['redo', 'refresh', 'Wiederholen', () => restore(state.future, state.history)],
      ['split', 'scissors', 'Teilen (S)', () => split()],
      ['dup', 'layers', 'Duplizieren', () => (needClip() ? duplicateSelected() : null)],
      ['del', 'trash', 'Löschen', () => (needClip() ? removeSelected() : null)],
      ['marker', 'target', 'Marker', () => toggleMarker()],
      ['frame', 'image', 'Standbild', () => exportFrame()],
      ['snap', 'grid', state.snap ? 'Einrasten: an' : 'Einrasten: aus', () => {
        state.snap = !state.snap;
        updateChrome();
      }],
      ['full', 'maximize', 'Vollbild', () => document.getElementById('screen').requestFullscreen?.()],
    ]],
    speed: ['Tempo', () => [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 4].map((v) => [`sp${v}`, 'timer', `${String(v).replace('.', ',')}×`, () => apply((c) => {
      c.speed = v;
      resolveOverlaps(c);
    }), sel() && (Number(sel().speed) || 1) === v])],
    look: ['Look', () => Object.keys(PRESETS).map((k) => [`pr-${k}`, 'palette', { none: 'Neutral', cinema: 'Kino', vivid: 'Kräftig', warm: 'Warm', cold: 'Kalt', noir: 'Noir', retro: 'Retro', cyber: 'Cyber', sunset: 'Sunset', faded: 'Verblasst', dream: 'Traum', action: 'Action' }[k] || k, () => apply((c) => {
      for (const key of LOOK_KEYS) delete c[key];
      Object.assign(c, PRESETS[k]);
    })])],
    fx: ['Effekte', () => EFFECTS.map(([v, n]) => [`fx-${v || 'none'}`, 'spark', n, () => apply((c) => {
      c.effect = v;
    }), sel() && (sel().effect || '') === v])],
    audio: ['Ton', () => [
      ['mute', 'mute', sel()?.muted ? 'Ton an' : 'Stumm', () => apply((c) => (c.muted = !c.muted))],
      ...[0.25, 0.5, 1, 1.5, 2].map((v) => [`vol${v}`, 'volume', `${Math.round(v * 100)} %`, () => apply((c) => (c.volume = v)), sel() && (sel().volume ?? 1) === v]),
      ['echo', 'music', sel()?.echo ? 'Echo: an' : 'Echo', () => apply((c) => (c.echo = !c.echo))],
      ['denoise', 'mic', sel()?.denoise ? 'Entrauschen: an' : 'Entrauschen', () => apply((c) => (c.denoise = !c.denoise))],
    ]],
    fade: ['Übergänge', () => [
      ...[0, 0.5, 1, 2].map((v) => [`fi${v}`, 'arrow', v ? `Einblenden ${String(v).replace('.', ',')} s` : 'Kein Einblenden', () => apply((c) => (c.fadeIn = v)), sel() && (Number(sel().fadeIn) || 0) === v]),
      ...[0, 0.5, 1, 2].map((v) => [`fo${v}`, 'arrow', v ? `Ausblenden ${String(v).replace('.', ',')} s` : 'Kein Ausblenden', () => apply((c) => (c.fadeOut = v)), sel() && (Number(sel().fadeOut) || 0) === v]),
    ]],
    turn: ['Drehen', () => [
      ['r-90', 'refresh', '90° links', () => apply((c) => (c.rotation = ((Number(c.rotation) || 0) - 90 + 540) % 360 - 180))],
      ['r90', 'refresh', '90° rechts', () => apply((c) => (c.rotation = ((Number(c.rotation) || 0) + 90 + 540) % 360 - 180))],
      ['fh', 'resize', 'Horizontal spiegeln', () => apply((c) => (c.flipH = !c.flipH))],
      ['fv', 'resize', 'Vertikal spiegeln', () => apply((c) => (c.flipV = !c.flipV))],
      ['zoom', 'search', 'Größe 120 %', () => apply((c) => (c.scale = 1.2))],
      ['reset', 'undo', 'Zurücksetzen', () => apply((c) => {
        for (const k of ['scale', 'x', 'y', 'rotation', 'flipH', 'flipV', 'opacity']) delete c[k];
      })],
    ]],
  };
  let tab = 'start';
  const ribbon = document.createElement('div');
  ribbon.className = 'vribbon glass';
  bar.insertAdjacentElement('afterend', ribbon);
  document.body.classList.add('has-ribbon');

  function render() {
    const items = TABS[tab][1]();
    ribbon.innerHTML = `<nav class="vr-tabs">${Object.entries(TABS).map(([id, [n]]) => `<button class="${id === tab ? 'on' : ''}" data-vtab="${id}">${n}</button>`).join('')}<span class="vr-len" id="vr-len"></span></nav>
      <div class="vr-row">${items.map(([id, i, n, , on]) => `<button class="vr-btn ${on ? 'on' : ''}" data-vbtn="${id}">${ic(i, 18)}<span>${n}</span></button>`).join('')}</div>`;
    const len = document.getElementById('length');
    if (len) document.getElementById('vr-len').textContent = len.textContent;
  }
  ribbon.addEventListener('click', (e) => {
    const t = e.target.closest('[data-vtab]');
    if (t) {
      tab = t.dataset.vtab;
      return render();
    }
    const b = e.target.closest('[data-vbtn]');
    if (!b) return;
    const item = TABS[tab][1]().find((x) => x[0] === b.dataset.vbtn);
    item?.[3]();
    setTimeout(render, 30);
  });
  // Auswahl oder Projekt ändert sich → Knöpfe (an/aus) aktualisieren
  let last = '';
  setInterval(() => {
    const c = sel();
    const key = `${state.selected}|${c ? JSON.stringify([c.speed, c.effect, c.muted, c.volume, c.echo, c.denoise, c.fadeIn, c.fadeOut]) : ''}|${state.snap}|${document.getElementById('length')?.textContent}`;
    if (key !== last) {
      last = key;
      render();
    }
  }, 300);
  render();
})();
