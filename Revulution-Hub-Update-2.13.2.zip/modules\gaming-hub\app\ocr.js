// OCR fuer Schadenszahlen (Ziffern) und Kill-Feed (Namen).
// Laeuft im Main-Prozess (tesseract.js nutzt einen Worker-Thread), damit der
// Renderer waehrend des Spiels nicht blockiert.
//
// Zahlen und Feed haben je einen eigenen Worker: die Schadenszahlen brauchen
// mehrere hundert Millisekunden pro Bild und wuerden den Kill-Feed sonst
// ausbremsen – der Feed muss aber sofort nach dem Kill gelesen werden.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createWorker } = require('tesseract.js');

// screen: große Schriftzüge (Rang in der Lobby, „Victory Royale“) – eigener
// Worker, damit der Kill-Feed nie hinter einem Vollbild-Scan warten muss.
// chest: eigener Worker für den Truhen-Zähler, damit er nie hinter Kills wartet.
const workers = { feed: null, numbers: null, screen: null, hud: null, chest: null };
const failed = { feed: false, numbers: false, screen: false, hud: false, chest: false };
const queues = { feed: Promise.resolve(), numbers: Promise.resolve(), screen: Promise.resolve(), hud: Promise.resolve(), chest: Promise.resolve() };

function langPath() {
  const candidates = [
    process.resourcesPath ? path.join(process.resourcesPath, 'tessdata') : null,
    path.join(__dirname, '..', 'assets', 'tessdata'),
  ].filter(Boolean);
  return candidates.find((dir) => fs.existsSync(path.join(dir, 'eng.traineddata.gz'))) || candidates[candidates.length - 1];
}

function cachePath() {
  const dir = path.join(os.tmpdir(), 'revolution-tracker-tess');
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    /* egal */
  }
  return dir;
}

function getWorker(role) {
  if (failed[role]) return Promise.resolve(null);
  if (!workers[role]) {
    workers[role] = createWorker('eng', 1, {
      langPath: langPath(),
      cachePath: cachePath(),
      gzip: true,
      logger: () => {},
    }).catch((error) => {
      console.error(`OCR-Worker (${role}) konnte nicht starten:`, error.message);
      failed[role] = true;
      workers[role] = null;
      return null;
    });
  }
  return workers[role];
}

/** Serialisiert alle OCR-Aufrufe je Worker: immer eine Aufgabe gleichzeitig. */
function serialize(role, task) {
  const run = queues[role].then(task, task);
  queues[role] = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function withWorker(role, parameters, task) {
  return serialize(role, async () => {
    const worker = await getWorker(role);
    if (!worker) return null;
    try {
      await worker.setParameters(parameters);
      return await task(worker);
    } catch (error) {
      console.error(`OCR-Fehler (${role}):`, error.message);
      return null;
    }
  });
}

/** Liest bis zu `limit` plausible Schadenswerte (1..299) aus einem PNG-Puffer. */
async function readNumbers(buffer, limit = 6) {
  return withWorker('numbers', { tessedit_char_whitelist: '0123456789', tessedit_pageseg_mode: '6' }, async (worker) => {
    const { data } = await worker.recognize(buffer);
    const text = String(data.text || '');
    const values = [];
    for (const match of text.match(/\d+/g) || []) {
      // Vierstellige Treffer sind HUD-Zahlen (Datum, Preis, ...), keine Schadenszahlen.
      if (match.length > 3) continue;
      const value = Number(match);
      if (!Number.isFinite(value) || value < 1 || value > 299) continue;
      if (!values.includes(value)) values.push(value);
    }
    return values.slice(0, limit);
  }).then((result) => result || []);
}

/** Liest Text (Spielernamen) aus einem PNG-Puffer. */
async function readText(buffer) {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-';
  return withWorker('feed', { tessedit_char_whitelist: letters, tessedit_pageseg_mode: '6' }, async (worker) => {
    const { data } = await worker.recognize(buffer);
    return String(data.text || '');
  }).then((result) => result || '');
}

/**
 * Liest verstreuten UI-Text (z. B. den Rang in der Lobby). Mode 11 sucht
 * Wörter über das ganze Bild – Mode 6 erwartet einen Textblock und scheitert
 * an Screenshots mit HUD und Hintergrund.
 */
async function readScreenText(buffer, role = 'feed') {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789# ';
  return withWorker(['screen', 'hud', 'chest'].includes(role) ? role : 'feed', { tessedit_char_whitelist: letters, tessedit_pageseg_mode: '11' }, async (worker) => {
    const { data } = await worker.recognize(buffer);
    return String(data.text || '');
  }).then((result) => result || '');
}

/** Wie readScreenText, liefert aber zusätzlich jedes Wort mit seiner Lage im Bild. */
async function readScreenWords(buffer, role = 'chest') {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789# ';
  const result = await withWorker(['screen', 'hud', 'chest'].includes(role) ? role : 'feed', { tessedit_char_whitelist: letters, tessedit_pageseg_mode: '11' }, async (worker) => {
    const { data } = await worker.recognize(buffer, {}, { text: true, blocks: true });
    const words = [];
    for (const block of data.blocks || []) {
      for (const paragraph of block.paragraphs || []) {
        for (const line of paragraph.lines || []) {
          for (const word of line.words || []) words.push({ text: word.text, bbox: word.bbox });
        }
      }
    }
    return { text: String(data.text || ''), words };
  });
  return result || { text: '', words: [] };
}

function isReady() {
  return Object.keys(workers).some((role) => Boolean(workers[role]) && !failed[role]);
}

async function shutdown() {
  for (const role of Object.keys(workers)) {
    const pending = workers[role];
    workers[role] = null;
    if (!pending) continue;
    try {
      const worker = await pending;
      await worker?.terminate();
    } catch {
      /* egal */
    }
  }
}

module.exports = { readNumbers, readScreenText, readScreenWords, readText, isReady, shutdown, langPath };
