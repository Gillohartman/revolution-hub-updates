const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

/**
 * Audio-Mixer: hält einen PowerShell-Helfer offen und schickt Befehle über
 * stdin. Nur so ist das Ziehen eines Reglers flüssig – ein Neustart pro Klick
 * würde wegen der Interop-Kompilierung jedes Mal über eine Sekunde dauern.
 */

let child = null;
let buffer = '';
let sequence = 0;
const pending = new Map();

function scriptPath() {
  const packaged = process.resourcesPath ? path.join(process.resourcesPath, 'audio-mixer.ps1') : '';
  const local = path.join(__dirname, '..', 'build', 'audio-mixer.ps1');
  if (packaged && fs.existsSync(packaged)) return packaged;
  return local;
}

function failAll(reason) {
  for (const entry of pending.values()) entry.reject(new Error(reason));
  pending.clear();
}

function onData(chunk) {
  buffer += chunk;
  const parts = buffer.split(/\r?\n/);
  buffer = parts.pop() || '';
  for (const line of parts) {
    const text = line.trim();
    if (!text.startsWith('{')) continue;
    let parsed = null;
    try {
      parsed = JSON.parse(text);
    } catch {
      continue;
    }
    const entry = pending.get(String(parsed.id));
    if (!entry) continue;
    pending.delete(String(parsed.id));
    if (parsed.error) entry.reject(new Error(String(parsed.error)));
    else entry.resolve(parsed.data);
  }
}

function ensure() {
  if (child) return true;
  const file = scriptPath();
  if (!fs.existsSync(file)) return false;
  try {
    child = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file],
      { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] },
    );
  } catch {
    child = null;
    return false;
  }

  buffer = '';
  child.stdout.setEncoding('utf8');
  child.stdout.on('data', onData);
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk) => {
    const text = String(chunk).trim();
    if (text) console.log('[audio]', text.slice(0, 200));
  });
  child.on('exit', () => {
    child = null;
    failAll('Audio-Mixer beendet');
  });
  child.on('error', () => {
    child = null;
    failAll('Audio-Mixer nicht erreichbar');
  });
  return true;
}

function send(command, timeout = 12000) {
  if (!ensure()) return Promise.reject(new Error('Audio-Mixer nicht verfügbar'));
  const id = String((sequence += 1));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error('Audio-Mixer antwortet nicht'));
    }, timeout);
    pending.set(id, {
      resolve: (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      reject: (error) => {
        clearTimeout(timer);
        reject(error);
      },
    });
    try {
      child.stdin.write(`${JSON.stringify({ id, ...command })}\n`);
    } catch (error) {
      clearTimeout(timer);
      pending.delete(id);
      reject(error);
    }
  });
}

const list = () => send({ cmd: 'list' });
const setMaster = (volume, mute) => send({ cmd: 'master', volume, mute });
const setApp = (pid, volume, mute) => send({ cmd: 'app', pid, volume, mute });

function stop() {
  try {
    child?.stdin.end();
  } catch {
    /* egal */
  }
  try {
    child?.kill();
  } catch {
    /* egal */
  }
  child = null;
  failAll('Audio-Mixer beendet');
}

module.exports = { list, setMaster, setApp, stop, scriptPath };
