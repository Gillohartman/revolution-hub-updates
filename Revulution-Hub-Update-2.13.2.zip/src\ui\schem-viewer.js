'use strict';
/*
 * 3D-Vorschau für Minecraft-Schematics (.litematic, .schem, .schematic, .nbt) – ohne Bibliotheken.
 * NBT lesen → Blockgitter → nur sichtbare Seiten als Mesh → WebGL2 mit Orbit-Kamera und Ebenen-Regler.
 */
(function () {
  /* ------------------------------------------------------------ NBT */
  async function gunzip(bytes) {
    if (bytes[0] !== 0x1f || bytes[1] !== 0x8b) return bytes;
    const ds = new DecompressionStream('gzip');
    const out = new Response(new Blob([bytes]).stream().pipeThrough(ds));
    return new Uint8Array(await out.arrayBuffer());
  }
  function readNbt(buf) {
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    const td = new TextDecoder();
    let p = 0;
    const str = () => {
      const n = dv.getUint16(p);
      p += 2;
      const s = td.decode(buf.subarray(p, p + n));
      p += n;
      return s;
    };
    function payload(t) {
      switch (t) {
        case 1: return dv.getInt8(p++);
        case 2: { const v = dv.getInt16(p); p += 2; return v; }
        case 3: { const v = dv.getInt32(p); p += 4; return v; }
        case 4: { const hi = dv.getInt32(p), lo = dv.getUint32(p + 4); p += 8; return hi * 4294967296 + lo; }
        case 5: { const v = dv.getFloat32(p); p += 4; return v; }
        case 6: { const v = dv.getFloat64(p); p += 8; return v; }
        case 7: { const n = dv.getInt32(p); p += 4; const v = buf.subarray(p, p + n); p += n; return v; }
        case 8: return str();
        case 9: {
          const et = dv.getUint8(p++), n = dv.getInt32(p);
          p += 4;
          const a = new Array(Math.max(0, n));
          for (let i = 0; i < n; i += 1) a[i] = payload(et);
          return a;
        }
        case 10: {
          const o = {};
          for (;;) {
            const ct = dv.getUint8(p++);
            if (ct === 0) break;
            const name = str();
            o[name] = payload(ct);
          }
          return o;
        }
        case 11: { const n = dv.getInt32(p); p += 4; const a = new Int32Array(n); for (let i = 0; i < n; i += 1) a[i] = dv.getInt32(p + i * 4); p += n * 4; return a; }
        case 12: { const n = dv.getInt32(p); p += 4; const v = { longs: true, dv, off: p, n }; p += n * 8; return v; }
        default: throw new Error('Unbekanntes NBT-Format');
      }
    }
    const t = dv.getUint8(p++);
    if (t !== 10) throw new Error('Keine NBT-Datei');
    str();
    return payload(10);
  }

  /* ------------------------------------------------------- Formate → Gitter */
  // Ergebnis: { w, h, l, cells: Uint16Array (0 = Luft), names: [Blockname je Index] }
  const AIR = /^minecraft:(air|cave_air|void_air|structure_void)$/;
  function grid(w, h, l, names) {
    if (w * h * l > 80e6) throw new Error(`Zu groß für die Vorschau (${w}×${h}×${l}).`);
    return { w, h, l, cells: new Uint16Array(w * h * l), names };
  }
  const stateName = (s) => {
    if (!s) return 'minecraft:air';
    const name = s.Name || 'minecraft:air';
    const props = s.Properties ? Object.entries(s.Properties).map(([k, v]) => `${k}=${v}`).join(',') : '';
    return props ? `${name}[${props}]` : name;
  };

  function fromLitematic(root) {
    const regions = Object.values(root.Regions || {});
    if (!regions.length) throw new Error('Keine Regionen in der Datei');
    let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
    const rs = regions.map((r) => {
      const P = r.Position || { x: 0, y: 0, z: 0 }, S = r.Size || { x: 1, y: 1, z: 1 };
      const sx = Math.abs(S.x), sy = Math.abs(S.y), sz = Math.abs(S.z);
      const mx = P.x + (S.x < 0 ? S.x + 1 : 0), my = P.y + (S.y < 0 ? S.y + 1 : 0), mz = P.z + (S.z < 0 ? S.z + 1 : 0);
      x0 = Math.min(x0, mx); y0 = Math.min(y0, my); z0 = Math.min(z0, mz);
      x1 = Math.max(x1, mx + sx); y1 = Math.max(y1, my + sy); z1 = Math.max(z1, mz + sz);
      return { r, sx, sy, sz, mx, my, mz };
    });
    const names = ['minecraft:air'], key = new Map([['minecraft:air', 0]]);
    const g = grid(x1 - x0, y1 - y0, z1 - z0, names);
    for (const { r, sx, sy, sz, mx, my, mz } of rs) {
      const pal = (r.BlockStatePalette || []).map((s) => {
        const n = stateName(s);
        if (AIR.test(n.split('[')[0])) return 0;
        if (!key.has(n)) {
          key.set(n, names.length);
          names.push(n);
        }
        return key.get(n);
      });
      const L = r.BlockStates;
      if (!L || !L.longs) continue;
      const bits = Math.max(2, Math.ceil(Math.log2(Math.max(2, pal.length))));
      const mask = (1 << bits) >>> 0;
      const word = (i) => [L.dv.getUint32(L.off + i * 8 + 4), L.dv.getUint32(L.off + i * 8)]; // [lo, hi]
      const total = sx * sy * sz;
      for (let i = 0; i < total; i += 1) {
        const bit = i * bits, wi = Math.floor(bit / 64), off = bit % 64;
        if (wi >= L.n) break;
        const [lo, hi] = word(wi);
        let v;
        if (off < 32) v = off + bits <= 32 ? lo >>> off : ((lo >>> off) | (hi << (32 - off))) >>> 0;
        else v = hi >>> (off - 32);
        if (off + bits > 64 && wi + 1 < L.n) v = (v | (word(wi + 1)[0] << (64 - off))) >>> 0;
        v = (v % mask) >>> 0;
        const id = pal[v] || 0;
        if (!id) continue;
        const x = i % sx, z = Math.floor(i / sx) % sz, y = Math.floor(i / (sx * sz));
        g.cells[((my - y0 + y) * g.l + (mz - z0 + z)) * g.w + (mx - x0 + x)] = id;
      }
    }
    return g;
  }

  function fromSponge(root) {
    const s = root.Schematic && root.Schematic.Width != null ? root.Schematic : root;
    const w = s.Width, h = s.Height, l = s.Length;
    const palObj = s.Blocks ? s.Blocks.Palette : s.Palette;
    const data = s.Blocks ? s.Blocks.Data : s.BlockData;
    if (!palObj || !data) throw new Error('Unbekanntes .schem-Format');
    const names = ['minecraft:air'];
    const pal = [];
    for (const [n, idx] of Object.entries(palObj)) {
      if (AIR.test(n.split('[')[0])) pal[idx] = 0;
      else {
        pal[idx] = names.length;
        names.push(n);
      }
    }
    const g = grid(w, h, l, names);
    let p = 0;
    for (let i = 0; i < w * h * l && p < data.length; i += 1) {
      let v = 0, shift = 0, b;
      do {
        b = data[p++];
        v |= (b & 0x7f) << shift;
        shift += 7;
      } while (b & 0x80);
      g.cells[i] = pal[v] || 0; // gleiche Reihenfolge: (y * l + z) * w + x
    }
    return g;
  }

  const LEGACY = { 1: 'stone', 2: 'grass_block', 3: 'dirt', 4: 'cobblestone', 5: 'oak_planks', 7: 'bedrock', 8: 'water', 9: 'water', 10: 'lava', 11: 'lava', 12: 'sand', 13: 'gravel', 14: 'gold_ore', 15: 'iron_ore', 16: 'coal_ore', 17: 'oak_log', 18: 'oak_leaves', 19: 'sponge', 20: 'glass', 22: 'lapis_block', 24: 'sandstone', 35: 'white_wool', 41: 'gold_block', 42: 'iron_block', 43: 'stone_slab', 44: 'stone_slab', 45: 'bricks', 46: 'tnt', 47: 'bookshelf', 48: 'mossy_cobblestone', 49: 'obsidian', 50: 'torch', 53: 'oak_stairs', 54: 'chest', 57: 'diamond_block', 58: 'crafting_table', 61: 'furnace', 64: 'oak_door', 65: 'ladder', 67: 'cobblestone_stairs', 79: 'ice', 80: 'snow_block', 81: 'cactus', 82: 'clay', 85: 'oak_fence', 86: 'pumpkin', 87: 'netherrack', 88: 'soul_sand', 89: 'glowstone', 98: 'stone_bricks', 102: 'glass_pane', 109: 'stone_brick_stairs', 112: 'nether_bricks', 121: 'end_stone', 133: 'emerald_block', 152: 'redstone_block', 155: 'quartz_block', 159: 'white_terracotta', 162: 'acacia_log', 168: 'prismarine', 169: 'sea_lantern', 172: 'terracotta', 173: 'coal_block', 174: 'packed_ice', 179: 'red_sandstone' };
  const WOOL = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black'];
  function fromLegacy(root) {
    const w = root.Width, h = root.Height, l = root.Length, B = root.Blocks, D = root.Data;
    if (!B) throw new Error('Unbekanntes .schematic-Format');
    const names = ['minecraft:air'], key = new Map();
    const g = grid(w, h, l, names);
    for (let i = 0; i < w * h * l; i += 1) {
      const id = B[i] & 0xff;
      if (!id) continue;
      let n = LEGACY[id] || 'stone';
      if ((id === 35 || id === 159) && D) n = `${WOOL[D[i] & 15]}_${id === 35 ? 'wool' : 'terracotta'}`;
      n = `minecraft:${n}`;
      if (!key.has(n)) {
        key.set(n, names.length);
        names.push(n);
      }
      g.cells[i] = key.get(n);
    }
    return g;
  }

  function fromStructure(root) {
    const [w, h, l] = root.size || [1, 1, 1];
    const names = ['minecraft:air'];
    const pal = (root.palette || root.palettes?.[0] || []).map((s) => {
      const n = stateName(s);
      if (AIR.test(n.split('[')[0])) return 0;
      names.push(n);
      return names.length - 1;
    });
    const g = grid(w, h, l, names);
    for (const b of root.blocks || []) {
      const [x, y, z] = b.pos;
      const id = pal[b.state] || 0;
      if (id) g.cells[(y * l + z) * w + x] = id;
    }
    return g;
  }

  async function parse(bytes, fileName) {
    const raw = await gunzip(bytes);
    if (/\.mcstructure$/i.test(fileName)) throw new Error('Bedrock-Dateien (.mcstructure) kann die Vorschau noch nicht zeigen.');
    const root = readNbt(raw);
    if (root.Regions) return fromLitematic(root);
    if (root.Schematic || root.Palette || root.BlockData) return fromSponge(root);
    if (root.Blocks && root.Width != null) return fromLegacy(root);
    if (root.blocks && root.size) return fromStructure(root);
    throw new Error('Dieses Schematic-Format kenne ich noch nicht.');
  }

  /* ------------------------------------------------------- Blockfarben */
  const C = (hex) => [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)];
  const EXACT = {
    stone: '#7d7d7d', cobblestone: '#7a7a7a', grass_block: '#5d9a3a', dirt: '#86603e', coarse_dirt: '#77553a', podzol: '#5c3f1f', sand: '#dbd3a0', red_sand: '#be6621', gravel: '#857f7e', clay: '#a0a6b3', bedrock: '#555555',
    water: '#3f76e4', lava: '#d96415', ice: '#91b7fd', packed_ice: '#8db4fa', blue_ice: '#74a8fd', snow: '#f4fbfb', snow_block: '#f0fafa', obsidian: '#15101f', crying_obsidian: '#2a0b57', netherrack: '#6e3533', soul_sand: '#513e32', glowstone: '#ddb873',
    bricks: '#966153', mud_bricks: '#89684f', packed_mud: '#8e6b50', mud: '#3c3a3d', terracotta: '#985e43', tnt: '#d5402f', bookshelf: '#6e5636', chest: '#a2732e', crafting_table: '#7a5832', furnace: '#6e6e6e', torch: '#ffd863', lantern: '#e3a547', sea_lantern: '#acc7be',
    gold_block: '#f6d03d', iron_block: '#dcdcdc', diamond_block: '#62ede4', emerald_block: '#2ad04f', redstone_block: '#b01c10', lapis_block: '#1e4699', coal_block: '#101010', copper_block: '#c06b4f', quartz_block: '#ece6df', amethyst_block: '#8662bf', prismarine: '#63a38f', end_stone: '#dbdea0',
    deepslate: '#4d4d51', tuff: '#6c6d66', calcite: '#dfe0dc', basalt: '#4c4c51', blackstone: '#2a2328', magma_block: '#8e3f1a', hay_block: '#a68b0c', cactus: '#5a8a2f', pumpkin: '#c67618', melon: '#77a223', moss_block: '#5a6d2d', shroomlight: '#f09047', honey_block: '#f5a223', slime_block: '#6fc15b', sponge: '#c4c04a',
  };
  const WOODS = { oak: '#a2834f', spruce: '#735531', birch: '#c5b57b', jungle: '#a07351', acacia: '#a85a32', dark_oak: '#43301a', mangrove: '#763631', cherry: '#e3b3ad', bamboo: '#c2af53', crimson: '#653147', warped: '#2b6963' };
  const DYES = { white: '#e9ecec', orange: '#f07613', magenta: '#bd44b3', light_blue: '#3aafd9', yellow: '#f8c527', lime: '#70b919', pink: '#ed8dac', gray: '#3e4447', light_gray: '#8e8e86', cyan: '#158991', purple: '#792aac', blue: '#35399d', brown: '#724728', green: '#546d1b', red: '#a12722', black: '#141519' };
  const TERRA = { white: '#d1b2a1', orange: '#a15325', magenta: '#95576c', light_blue: '#706c8a', yellow: '#ba8523', lime: '#677534', pink: '#a14e4e', gray: '#392a23', light_gray: '#876a61', cyan: '#575b5b', purple: '#764656', blue: '#4a3b5b', brown: '#4d3323', green: '#4c532a', red: '#8f3d2e', black: '#251610' };
  const colorCache = new Map();
  function blockColor(full) {
    const n = full.split('[')[0].replace(/^minecraft:/, '');
    if (colorCache.has(n)) return colorCache.get(n);
    let hex = EXACT[n];
    if (!hex) {
      const dye = Object.keys(DYES).sort((a, b) => b.length - a.length).find((d) => n.startsWith(`${d}_`));
      const wood = Object.keys(WOODS).sort((a, b) => b.length - a.length).find((w) => n.startsWith(`${w}_`) || n.startsWith(`stripped_${w}_`));
      if (dye && /terracotta/.test(n)) hex = TERRA[dye];
      else if (dye && /(wool|concrete|carpet|glass|bed|banner|candle|shulker)/.test(n)) hex = DYES[dye];
      else if (wood && /leaves/.test(n)) hex = wood === 'cherry' ? '#e8a0c8' : wood === 'birch' ? '#80a755' : wood === 'spruce' ? '#619961' : '#4c8f2a';
      else if (wood && /(log|wood|stem|hyphae)$/.test(n)) hex = /stripped/.test(n) ? WOODS[wood] : { oak: '#6d5532', spruce: '#3b2712', birch: '#d8d7d2', jungle: '#56451b', acacia: '#696259', dark_oak: '#3c2e1a', mangrove: '#5b4a2e', cherry: '#38202a', crimson: '#5c1919', warped: '#3a3a4d', bamboo: '#8a9a2e' }[wood];
      else if (wood) hex = WOODS[wood];
      else if (/leaves/.test(n)) hex = '#4c8f2a';
      else if (/deepslate/.test(n)) hex = '#4f4f53';
      else if (/blackstone/.test(n)) hex = '#2d2830';
      else if (/(nether_brick)/.test(n)) hex = '#2f171c';
      else if (/(end_stone)/.test(n)) hex = '#dbdea0';
      else if (/purpur/.test(n)) hex = '#a77ba7';
      else if (/quartz/.test(n)) hex = '#ece6df';
      else if (/prismarine/.test(n)) hex = '#5ea493';
      else if (/sandstone/.test(n)) hex = /red_/.test(n) ? '#ba631e' : '#d8cb9b';
      else if (/(stone_brick|stone_bricks)/.test(n)) hex = '#7a7a7a';
      else if (/(cobble)/.test(n)) hex = '#7a7a7a';
      else if (/(andesite)/.test(n)) hex = '#888888';
      else if (/(diorite)/.test(n)) hex = '#bcbcbc';
      else if (/(granite)/.test(n)) hex = '#956756';
      else if (/(brick)/.test(n)) hex = '#966153';
      else if (/copper/.test(n)) hex = /oxidized/.test(n) ? '#52a385' : /weathered/.test(n) ? '#6c9c6e' : /exposed/.test(n) ? '#a17e68' : '#c06b4f';
      else if (/glass/.test(n)) hex = '#c0d8e0';
      else if (/(ore)$/.test(n)) hex = '#8a8a8a';
      else if (/(grass|fern|vine|sapling|bush|kelp|seagrass|lily|moss)/.test(n)) hex = '#5b8f30';
      else if (/(flower|tulip|rose|poppy|dandelion|orchid|allium|daisy|lilac|peony)/.test(n)) hex = '#d84f6a';
      else if (/(rail|lever|button|pressure_plate|tripwire|redstone)/.test(n)) hex = '#8a6e4a';
      else if (/(iron|anvil|chain|hopper|cauldron)/.test(n)) hex = '#5a5a5a';
      else if (/(lamp|light|lantern|torch|glow)/.test(n)) hex = '#f2c86b';
      else if (/stone|slab|stairs|wall/.test(n)) hex = '#7d7d7d';
      else hex = '#9a8f86';
    }
    const c = C(hex);
    colorCache.set(n, c);
    return c;
  }
  // Blöcke, die Nachbarn nicht verdecken (dünn, halb oder durchsichtig)
  const SEE_THROUGH = /(glass|pane|leaves|fence|wall|slab|stairs|door|trapdoor|torch|lantern|rail|carpet|button|lever|pressure_plate|sign|banner|flower|tulip|poppy|dandelion|sapling|grass$|^short_grass|tall_grass|fern|vine|ladder|bars|chain|bed|candle|head|skull|pot|water|lava|ice$|snow$|kelp|seagrass|redstone_wire|repeater|comparator|tripwire|cobweb|scaffolding|campfire|bell|anvil|hopper|cauldron|end_rod|lightning_rod|amethyst_cluster|bud|mushroom$|coral|pickle|lily|cake|chest|bush|roots|sprouts)/;
  // grobe Form: Höhe der Box (1 = voll)
  function shapeOf(full) {
    const n = full.split('[')[0].replace(/^minecraft:/, '');
    if (/carpet|pressure_plate|rail|redstone_wire|repeater|comparator|tripwire|lily_pad|snow$/.test(n)) return [0.12, 0.5];
    if (/slab$/.test(n)) return /type=double/.test(full) ? [1, 1] : /type=top/.test(full) ? [0.5, 1, 0.5] : [0.5, 1];
    if (/torch|flower|tulip|poppy|dandelion|sapling|short_grass|^grass$|fern|rod|candle|button|lever|mushroom$|bud|cluster|pickle|sprouts|roots/.test(n)) return [0.55, 0.35];
    if (/pane|bars|fence|wall|chain|ladder/.test(n)) return [1, 0.35];
    return [1, 1];
  }

  /* ------------------------------------------------------- Mesh bauen */
  const FACES = [
    { d: [1, 0, 0], v: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]], s: 0.8 },
    { d: [-1, 0, 0], v: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]], s: 0.8 },
    { d: [0, 1, 0], v: [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]], s: 1 },
    { d: [0, -1, 0], v: [[0, 0, 1], [0, 0, 0], [1, 0, 0], [1, 0, 1]], s: 0.5 },
    { d: [0, 0, 1], v: [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]], s: 0.65 },
    { d: [0, 0, -1], v: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]], s: 0.9 },
  ];
  function buildMesh(g) {
    const { w, h, l, cells, names } = g;
    const solid = new Uint8Array(names.length), col = names.map((n, i) => (i ? blockColor(n) : [0, 0, 0])), shape = names.map((n) => shapeOf(n));
    names.forEach((n, i) => (solid[i] = i && !SEE_THROUGH.test(n.split('[')[0].replace(/^minecraft:/, '')) ? 1 : 0));
    const at = (x, y, z) => (x < 0 || y < 0 || z < 0 || x >= w || y >= h || z >= l ? 0 : cells[(y * l + z) * w + x]);
    let faces = 0;
    const counts = new Map();
    for (let i = 0; i < cells.length; i += 1) if (cells[i]) counts.set(cells[i], (counts.get(cells[i]) || 0) + 1);
    const MAX = 1_400_000;
    const pos = new Float32Array(MAX * 12), clr = new Uint8Array(MAX * 12);
    let hidden = false;
    for (let y = 0; y < h && !hidden; y += 1)
      for (let z = 0; z < l && !hidden; z += 1)
        for (let x = 0; x < w; x += 1) {
          const id = cells[(y * l + z) * w + x];
          if (!id) continue;
          const [sh, sw, off = 0] = shape[id], c = col[id];
          const n = (x * 73856093) ^ (y * 19349663) ^ (z * 83492791);
          const jit = 0.94 + ((n >>> 0) % 13) / 100; // leichte Variation pro Block
          for (const f of FACES) {
            const nb = at(x + f.d[0], y + f.d[1], z + f.d[2]);
            if (nb && solid[nb] && sh === 1 && sw === 1) continue;
            if (faces >= MAX) {
              hidden = true;
              break;
            }
            const pi = faces * 12;
            for (let k = 0; k < 4; k += 1) {
              const [vx, vy, vz] = f.v[k];
              const inset = (1 - sw) / 2;
              pos[pi + k * 3] = x + inset + vx * sw;
              pos[pi + k * 3 + 1] = y + off + vy * sh;
              pos[pi + k * 3 + 2] = z + inset + vz * sw;
              const s = f.s * jit * (vy ? 1 : 0.86);
              clr[pi + k * 3] = Math.min(255, c[0] * s);
              clr[pi + k * 3 + 1] = Math.min(255, c[1] * s);
              clr[pi + k * 3 + 2] = Math.min(255, c[2] * s);
            }
            faces += 1;
          }
        }
    let total = 0;
    for (const v of counts.values()) total += v;
    const mats = [...counts.entries()].map(([id, n]) => ({ name: names[id].split('[')[0].replace(/^minecraft:/, ''), n, c: col[id] })).reduce((m, x) => (m.set(x.name, { ...x, n: (m.get(x.name)?.n || 0) + x.n }), m), new Map());
    return { pos: pos.subarray(0, faces * 12), clr: clr.subarray(0, faces * 12), faces, total, hidden, mats: [...mats.values()].sort((a, b) => b.n - a.n) };
  }

  /* ------------------------------------------------------- WebGL */
  const VS = `#version 300 es
  in vec3 p; in vec3 c; uniform mat4 m; uniform float cut; out vec3 vc; out float vy; out float vd;
  void main(){ vc=c; vy=p.y; vec4 q=m*vec4(p,1.0); vd=q.w; gl_Position=q; }`;
  const FS = `#version 300 es
  precision highp float; in vec3 vc; in float vy; in float vd; uniform float cut; uniform float far; out vec4 o;
  void main(){ if(vy>cut+0.001) discard; float f=clamp((vd-far*0.55)/(far*0.9),0.0,0.45); o=vec4(mix(vc,vec3(0.08,0.07,0.12),f),1.0); }`;
  function mat(fov, asp, eye, tgt) {
    const f = 1 / Math.tan(fov / 2), n = 0.1, fa = 4000;
    const P = [f / asp, 0, 0, 0, 0, f, 0, 0, 0, 0, (fa + n) / (n - fa), -1, 0, 0, (2 * fa * n) / (n - fa), 0];
    const z = norm3(sub(eye, tgt)), x = norm3(cross([0, 1, 0], z)), y = cross(z, x);
    const V = [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -dot(x, eye), -dot(y, eye), -dot(z, eye), 1];
    const o = new Float32Array(16);
    for (let i = 0; i < 4; i += 1) for (let j = 0; j < 4; j += 1) { let s = 0; for (let k = 0; k < 4; k += 1) s += P[k * 4 + j] * V[i * 4 + k]; o[i * 4 + j] = s; }
    return o;
  }
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const norm3 = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

  function render(host, g, mesh) {
    const canvas = document.createElement('canvas');
    canvas.className = 'sv-canvas';
    host.append(canvas);
    const gl = canvas.getContext('webgl2', { antialias: true });
    if (!gl) throw new Error('WebGL 2 ist nicht verfügbar.');
    const sh = (t, src) => { const s = gl.createShader(t); gl.shaderSource(s, src); gl.compileShader(s); return s; };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(prog);
    gl.useProgram(prog);
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const buf = (data, loc, type, normd) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 3, type, normd, 0, 0); };
    buf(mesh.pos, gl.getAttribLocation(prog, 'p'), gl.FLOAT, false);
    buf(mesh.clr, gl.getAttribLocation(prog, 'c'), gl.UNSIGNED_BYTE, true);
    const idx = new Uint32Array(mesh.faces * 6);
    for (let i = 0; i < mesh.faces; i += 1) idx.set([i * 4, i * 4 + 1, i * 4 + 2, i * 4, i * 4 + 2, i * 4 + 3], i * 6);
    const ib = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
    const uM = gl.getUniformLocation(prog, 'm'), uCut = gl.getUniformLocation(prog, 'cut'), uFar = gl.getUniformLocation(prog, 'far');
    gl.enable(gl.DEPTH_TEST);

    const size = Math.max(g.w, g.h, g.l);
    const cam = { yaw: -0.7, pitch: 0.55, dist: size * 1.7 + 6, tx: g.w / 2, ty: g.h / 3, tz: g.l / 2 };
    const st = { cut: g.h, raf: 0, dead: false, spin: true };
    function draw() {
      st.raf = 0;
      if (st.dead) return;
      const r = canvas.getBoundingClientRect(), dpr = Math.min(2, devicePixelRatio || 1);
      const W = Math.max(1, Math.round(r.width * dpr)), H = Math.max(1, Math.round(r.height * dpr));
      if (canvas.width !== W || canvas.height !== H) { canvas.width = W; canvas.height = H; }
      gl.viewport(0, 0, W, H);
      gl.clearColor(0.07, 0.065, 0.11, 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      const eye = [cam.tx + Math.cos(cam.pitch) * Math.sin(cam.yaw) * cam.dist, cam.ty + Math.sin(cam.pitch) * cam.dist, cam.tz + Math.cos(cam.pitch) * Math.cos(cam.yaw) * cam.dist];
      gl.uniformMatrix4fv(uM, false, mat(0.8, W / H, eye, [cam.tx, cam.ty, cam.tz]));
      gl.uniform1f(uCut, st.cut);
      gl.uniform1f(uFar, cam.dist + size);
      gl.drawElements(gl.TRIANGLES, idx.length, gl.UNSIGNED_INT, 0);
      if (st.spin) {
        cam.yaw += 0.0035;
        kick();
      }
    }
    const kick = () => { if (!st.raf) st.raf = requestAnimationFrame(draw); };
    let drag = null;
    canvas.addEventListener('pointerdown', (e) => {
      drag = { x: e.clientX, y: e.clientY, yaw: cam.yaw, pitch: cam.pitch, tx: cam.tx, tz: cam.tz, ty: cam.ty, pan: e.button === 2 || e.shiftKey };
      st.spin = false;
      canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (drag.pan) {
        const k = cam.dist / 600;
        cam.tx = drag.tx - (Math.cos(cam.yaw) * dx) * k;
        cam.tz = drag.tz + (Math.sin(cam.yaw) * dx) * k;
        cam.ty = drag.ty + dy * k;
      } else {
        cam.yaw = drag.yaw - dx * 0.008;
        cam.pitch = Math.max(-1.45, Math.min(1.5, drag.pitch + dy * 0.006));
      }
      kick();
    });
    canvas.addEventListener('pointerup', () => (drag = null));
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      cam.dist = Math.max(3, Math.min(size * 6 + 20, cam.dist * (e.deltaY > 0 ? 1.1 : 0.9)));
      kick();
    }, { passive: false });
    const ro = new ResizeObserver(kick);
    ro.observe(canvas);
    kick();
    return {
      setCut(y) { st.cut = y; kick(); },
      reset() { Object.assign(cam, { yaw: -0.7, pitch: 0.55, dist: size * 1.7 + 6, tx: g.w / 2, ty: g.h / 3, tz: g.l / 2 }); kick(); },
      top() { cam.pitch = 1.5; st.spin = false; kick(); },
      spin() { st.spin = !st.spin; kick(); },
      destroy() { st.dead = true; ro.disconnect(); gl.getExtension('WEBGL_lose_context')?.loseContext(); canvas.remove(); },
    };
  }

  /** Öffnet die Vorschau in host. bytes: Uint8Array. Gibt Infos zurück (Größe, Blöcke, Materialien). */
  async function open(host, bytes, fileName) {
    const g = await parse(bytes, fileName);
    const mesh = buildMesh(g);
    if (!mesh.total) throw new Error('Das Schematic ist leer.');
    const view = render(host, g, mesh);
    return { view, w: g.w, h: g.h, l: g.l, total: mesh.total, faces: mesh.faces, hidden: mesh.hidden, mats: mesh.mats };
  }

  window.SchemViewer = { open, parse, blockColor };
})();
