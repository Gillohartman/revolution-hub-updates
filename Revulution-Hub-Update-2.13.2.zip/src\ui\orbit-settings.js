'use strict';

/*
 * Every Orbit Island setting, grouped like the island's own settings window.
 * Field syntax: [path, label, type, options]
 *   b = switch, n = number {min,max,step,unit,pct}, e = choice {options:[[value,label]]},
 *   c = colour, t = text, k = shortcut
 */
const pct = (min = 0, max = 1, step = 0.01) => ({ min, max, step, pct: true });
const px = (min, max, step = 1) => ({ min, max, step, unit: 'px' });
const ms = (min, max, step = 10) => ({ min, max, step, unit: 'ms' });
const opts = (...list) => ({ options: list.map((entry) => (Array.isArray(entry) ? entry : [entry, entry])) });

window.ORBIT_SECTIONS = [
  {
    id: 'player',
    title: 'Separater Player',
    icon: 'music',
    groups: [{ title: 'Musik-Player – eigenes Overlay mit Cover, Songtext und Schallplatte', special: 'player' }],
  },
  {
    id: 'design',
    title: 'Design',
    icon: 'island',
    groups: [
      { title: 'Theme', special: 'themes' },
      {
        title: 'Hintergrund',
        fields: [
          ['Appearance.Backdrop', 'Material', 'e', opts(['Glass', 'Glas'], ['Solid', 'Einfarbig'], ['Gradient', 'Verlauf'], ['Minimal', 'Minimal'])],
          ['Appearance.Wallpaper', 'Live-Hintergrund (Effekt)', 'e', opts(['Off', 'Aus'], 'Nebula', 'Aurora', 'Galaxy', 'Liquid')],
          ['Appearance.WallpaperFile', 'Live-Video', 'wallpaper'],
          ['Appearance.WallpaperOpacity', 'Deckkraft des Hintergrunds', 'n', pct()],
          ['Appearance.WallpaperOnDesktop', 'Video auch auf dem Desktop abspielen', 'b'],
        ],
      },
      {
        title: 'Farben',
        fields: [
          ['Appearance.BackgroundColor', 'Hintergrund', 'c'],
          ['Appearance.BackgroundColor2', 'Hintergrund 2 (Verlauf)', 'c'],
          ['Appearance.AccentColor', 'Akzent', 'c'],
          ['Appearance.AccentColor2', 'Akzent 2', 'c'],
          ['Appearance.TextColor', 'Text', 'c'],
          ['Appearance.SubTextColor', 'Nebentext', 'c'],
          ['Appearance.ProgressColor', 'Fortschritt', 'c'],
          ['Appearance.GlowColor', 'Leuchten', 'c'],
          ['Appearance.BorderColor', 'Rand', 'c'],
        ],
      },
      {
        title: 'Glas & Effekte',
        fields: [
          ['Appearance.BackgroundOpacity', 'Deckkraft', 'n', pct()],
          ['Appearance.BlurIntensity', 'Unschärfe', 'n', { min: 0, max: 100, step: 1 }],
          ['Appearance.BorderOpacity', 'Rand-Deckkraft', 'n', pct()],
          ['Appearance.ShadowOpacity', 'Schatten-Deckkraft', 'n', pct()],
          ['Appearance.ContentOpacity', 'Inhalt-Deckkraft', 'n', pct(0.2)],
          ['Appearance.GlassHighlight', 'Glas-Glanz', 'n', pct()],
          ['Appearance.GlowIntensity', 'Leuchtstärke', 'n', pct()],
          ['Appearance.ReflectionIntensity', 'Spiegelung', 'n', pct()],
          ['Appearance.NoiseIntensity', 'Körnung', 'n', pct(0, 0.2, 0.005)],
          ['Appearance.ShowShadow', 'Schatten anzeigen', 'b'],
          ['Appearance.AnimatedBorder', 'Animierter Rand', 'b'],
          ['Appearance.Particles', 'Partikel', 'b'],
          ['Appearance.ReduceTransparency', 'Transparenz verringern', 'b'],
          ['Appearance.HighContrast', 'Hoher Kontrast', 'b'],
        ],
      },
      {
        title: 'Schrift & Symbole',
        fields: [
          ['Appearance.FontFamily', 'Schriftart', 'e', opts('Segoe UI Variable Display', 'Segoe UI', 'Cascadia Code', 'Consolas', 'Calibri', 'Georgia', 'Verdana')],
          ['Appearance.FontScale', 'Schriftgröße', 'n', { min: 0.7, max: 1.5, step: 0.01, pct: true }],
          ['Appearance.FontWeight', 'Schriftstärke', 'e', opts([400, 'Normal'], [500, 'Mittel'], [600, 'Halbfett'], [700, 'Fett'], [800, 'Extrafett'])],
          ['Appearance.TextAlignment', 'Textausrichtung', 'e', opts(['Left', 'Links'], ['Center', 'Mittig'], ['Right', 'Rechts'])],
          ['Appearance.CompactMode', 'Kompakter Modus', 'b'],
        ],
      },
      {
        title: 'Einblendungen',
        fields: [
          ['Appearance.VolumeHud', 'Lautstärke-Anzeige', 'b'],
          ['Appearance.HideNativeOsd', 'Lautstärke-Fenster von Windows ausblenden', 'b', { hint: 'Wenn die Island läuft, zeigt nur sie die Lautstärke.' }],
          ['Appearance.DeviceHud', 'Geräte-Anzeige (Kopfhörer, USB …)', 'b'],
        ],
      },
    ],
  },
  {
    id: 'size',
    title: 'Größe & Form',
    icon: 'resize',
    groups: [
      {
        title: 'Größen',
        fields: [
          ['Appearance.CollapsedWidth', 'Eingeklappt – Breite', 'n', px(40, 300)],
          ['Appearance.CollapsedHeight', 'Eingeklappt – Höhe', 'n', px(12, 60)],
          ['Appearance.HoverWidth', 'Beim Darüberfahren – Breite', 'n', px(200, 800)],
          ['Appearance.HoverHeight', 'Beim Darüberfahren – Höhe', 'n', px(60, 400)],
          ['Appearance.PinnedWidth', 'Geöffnet – Breite', 'n', px(300, 1200)],
          ['Appearance.PinnedHeight', 'Geöffnet – Höhe', 'n', px(120, 700)],
          ['Appearance.NotificationWidth', 'Benachrichtigung – Breite', 'n', px(200, 800)],
          ['Appearance.NotificationHeight', 'Benachrichtigung – Höhe', 'n', px(50, 300)],
        ],
      },
      {
        title: 'Form',
        fields: [
          ['Appearance.CornerRadiusCollapsed', 'Ecken eingeklappt', 'n', px(0, 40)],
          ['Appearance.CornerRadiusExpanded', 'Ecken geöffnet', 'n', px(0, 60)],
          ['Appearance.BorderThickness', 'Randstärke', 'n', px(0, 4, 0.5)],
          ['Appearance.AttachToTop', 'Am oberen Rand andocken (Notch-Look)', 'b'],
        ],
      },
    ],
  },
  {
    id: 'position',
    title: 'Position',
    icon: 'move',
    groups: [
      {
        title: 'Platzierung',
        fields: [
          ['Position.Anchor', 'Ausrichtung', 'e', opts(['TopCenter', 'Oben Mitte'], ['TopLeft', 'Oben links'], ['TopRight', 'Oben rechts'], ['Custom', 'Frei'])],
          ['Position.TopOffset', 'Abstand oben', 'n', px(0, 200)],
          ['Position.HorizontalOffset', 'Seitlicher Versatz', 'n', px(-1000, 1000)],
          ['Position.CustomX', 'Freie Position X', 'n', px(0, 8000)],
          ['Position.CustomY', 'Freie Position Y', 'n', px(0, 4000)],
          ['Position.MonitorId', 'Monitor', 'e', { monitors: true, hint: 'Auf welchem Bildschirm die Island sitzt.' }],
          ['Position.AutoHideAtTop', 'Am oberen Rand automatisch ausblenden', 'b'],
        ],
      },
    ],
  },
  {
    id: 'animation',
    title: 'Animation',
    icon: 'spark',
    groups: [
      {
        title: 'Bewegung',
        fields: [
          ['Animation.ExpandDurationMs', 'Aufklappen', 'n', ms(60, 1200)],
          ['Animation.CollapseDurationMs', 'Zuklappen', 'n', ms(60, 1200)],
          ['Animation.FadeDurationMs', 'Überblenden', 'n', ms(0, 800)],
          ['Animation.SpringIntensity', 'Federung', 'n', pct()],
          ['Animation.AnimationIntensity', 'Animationsstärke', 'n', pct(0, 2)],
          ['Animation.ContentTransition', 'Inhaltswechsel', 'e', opts(['Fade', 'Überblenden'], ['SlideUp', 'Nach oben gleiten'], ['ScaleFade', 'Zoomen'])],
          ['Animation.AnimateCornerRadius', 'Ecken mitanimieren', 'b'],
          ['Animation.ReducedMotion', 'Bewegung reduzieren', 'b'],
          ['Animation.FrameRateCap', 'Bildrate', 'e', opts([30, '30 fps'], [60, '60 fps'], [120, '120 fps'], [144, '144 fps'])],
        ],
      },
      {
        title: 'Visualizer',
        fields: [
          ['Animation.VisualizerIntensity', 'Stärke', 'n', pct(0, 2)],
          ['Animation.VisualizerSpeed', 'Tempo', 'n', pct(0.2, 3)],
        ],
      },
    ],
  },
  {
    id: 'interaction',
    title: 'Bedienung',
    icon: 'pointer',
    groups: [
      {
        title: 'Maus',
        fields: [
          ['Interaction.HoverToExpand', 'Beim Darüberfahren aufklappen', 'b'],
          ['Interaction.HoverDelayMs', 'Verzögerung beim Darüberfahren', 'n', ms(0, 1500)],
          ['Interaction.CollapseDelayMs', 'Verzögerung beim Zuklappen', 'n', ms(0, 3000)],
          ['Interaction.ClickAction', 'Klick bewirkt', 'e', opts(['Expand', 'Aufklappen'], ['Pin', 'Anheften'], ['Toggle', 'Umschalten'])],
          ['Interaction.CollapseOnOutsideClick', 'Bei Klick daneben zuklappen', 'b'],
          ['Interaction.ClickThroughWhenCollapsed', 'Eingeklappt durchklickbar', 'b'],
          ['Interaction.KeepOpenWhileInteracting', 'Offen lassen, solange ich bediene', 'b'],
        ],
      },
      {
        title: 'Inhalt',
        fields: [
          ['Interaction.DefaultModule', 'Standard-Inhalt', 'e', opts(['Auto', 'Automatisch'], ['Music', 'Musik'], ['Agenda', 'Termine'], ['Timers', 'Timer'], ['Clock', 'Uhr'], ['Tools', 'Werkzeuge'])],
          ['Interaction.AutoSwitchContent', 'Inhalt automatisch wechseln', 'b'],
          ['Interaction.AutoExpandOnNotification', 'Bei Benachrichtigung aufklappen', 'b'],
          ['Interaction.AutoExpandOnTimerComplete', 'Wenn ein Timer endet aufklappen', 'b'],
          ['Interaction.MusicPriority', 'Priorität Musik', 'n', { min: 0, max: 100, step: 1 }],
          ['Interaction.TimerPriority', 'Priorität Timer', 'n', { min: 0, max: 100, step: 1 }],
          ['Interaction.CalendarPriority', 'Priorität Kalender', 'n', { min: 0, max: 100, step: 1 }],
        ],
      },
      {
        title: 'Tastenkürzel',
        fields: [
          ['Interaction.EnableHotkeys', 'Tastenkürzel aktiv', 'b'],
          ['Interaction.ToggleIslandHotkey', 'Island ein/aus', 'k'],
          ['Interaction.PlayPauseHotkey', 'Wiedergabe / Pause', 'k'],
          ['Interaction.NextTrackHotkey', 'Nächster Titel', 'k'],
          ['Interaction.PreviousTrackHotkey', 'Vorheriger Titel', 'k'],
          ['Interaction.QuickTimerHotkey', 'Schnell-Timer', 'k'],
        ],
      },
    ],
  },
  {
    id: 'music',
    title: 'Musik',
    icon: 'music',
    groups: [
      {
        title: 'Wiedergabe',
        fields: [
          ['Music.Enabled', 'Musik in der Island', 'b'],
          ['Music.PreferredSourceId', 'Bevorzugte Quelle (App-ID, leer = automatisch)', 't'],
          ['Music.ShowAlbumArt', 'Albumcover', 'b'],
          ['Music.ShowProgress', 'Fortschrittsbalken', 'b'],
          ['Music.ShowLyricsButton', 'Songtext-Knopf', 'b'],
          ['Music.NotifyOnTrackChange', 'Bei Titelwechsel melden', 'b'],
        ],
      },
      {
        title: 'Plattenspieler',
        fields: [
          ['Music.VinylCrackle', 'Plattenknistern beim Abspielen', 'b', { hint: 'Leises Vinyl-Knistern unter der Musik. Die Nadel wandert mit dem Fortschritt des Titels.' }],
          ['Music.VinylCrackleVolume', 'Lautstärke des Knisterns', 'n', pct()],
        ],
      },
      {
        title: 'Visualizer',
        fields: [
          ['Music.ShowVisualizer', 'Visualizer anzeigen', 'b'],
          ['Music.VisualizerStyle', 'Stil', 'e', opts(['Off', 'Aus'], ['Waveform', 'Wellenform'], ['EqualizerBars', 'Equalizer'], ['CircularSpectrum', 'Kreis-Spektrum'], ['FlowingWaves', 'Fließende Wellen'], ['BouncingDots', 'Hüpfende Punkte'], ['ThinBars', 'Dünne Balken'], ['Particles', 'Partikel'], ['AlbumPulse', 'Cover-Puls'], ['PlaybackPulse', 'Wiedergabe-Puls'])],
          ['Music.VisualizerBars', 'Anzahl Balken', 'n', { min: 4, max: 64, step: 1 }],
          ['Music.VisualizerHeight', 'Höhe', 'n', px(4, 60)],
          ['Music.VisualizerThickness', 'Strichstärke', 'n', px(1, 10, 0.5)],
          ['Music.VisualizerOpacity', 'Deckkraft', 'n', pct()],
          ['Music.VisualizerGlow', 'Leuchten', 'b'],
          ['Music.AudioReactive', 'Reagiert auf den Ton', 'b'],
          ['Music.PauseVisualizerWhenPaused', 'Bei Pause anhalten', 'b'],
        ],
      },
      {
        title: 'Spotify',
        fields: [
          ['Spotify.EnableApi', 'Spotify-Verbindung', 'b'],
          ['Spotify.ClientId', 'Client-ID', 't'],
          ['Spotify.RedirectPort', 'Rückruf-Port', 'n', { min: 1024, max: 65535, step: 1 }],
          ['Spotify.UseApiPlaybackControls', 'Steuerung über Spotify', 'b'],
          ['Spotify.ShowDevice', 'Wiedergabegerät anzeigen', 'b'],
          ['Spotify.PreferSpotifySession', 'Spotify bevorzugen', 'b'],
        ],
      },
      {
        title: 'Songtexte',
        fields: [
          ['Lyrics.Enabled', 'Songtexte', 'b'],
          ['Lyrics.Provider', 'Quelle', 'e', opts(['Lrclib', 'LRCLIB (online)'], ['LocalFiles', 'Eigene Dateien'], ['None', 'Keine'])],
          ['Lyrics.LocalFolder', 'Ordner für eigene Dateien', 't'],
          ['Lyrics.FontSize', 'Schriftgröße', 'n', px(10, 30, 0.5)],
          ['Lyrics.LineSpacing', 'Zeilenabstand', 'n', { min: 1, max: 2.2, step: 0.05 }],
          ['Lyrics.UpcomingLines', 'Kommende Zeilen', 'n', { min: 0, max: 6, step: 1 }],
          ['Lyrics.OffsetMs', 'Zeitversatz', 'n', ms(-5000, 5000, 50)],
          ['Lyrics.Centered', 'Zentriert', 'b'],
          ['Lyrics.Compact', 'Kompakt', 'b'],
          ['Lyrics.MiniIsland', 'Mini-Island beim Mitlesen', 'b'],
          ['Lyrics.Karaoke', 'Karaoke-Hervorhebung', 'b'],
          ['Lyrics.SendMetadataToProvider', 'Titel an die Quelle senden', 'b'],
        ],
      },
    ],
  },
  {
    id: 'time',
    title: 'Uhr & Kalender',
    icon: 'clock',
    groups: [
      {
        title: 'Uhr',
        fields: [
          ['Clock.Enabled', 'Uhr anzeigen', 'b'],
          ['Clock.Use24Hour', '24-Stunden-Format', 'b'],
          ['Clock.ShowSeconds', 'Sekunden', 'b'],
          ['Clock.ShowDate', 'Datum', 'b'],
          ['Clock.ShowWorldClocks', 'Weltuhren', 'b'],
        ],
      },
      { title: 'Weltuhren', special: 'worldclocks' },
      {
        title: 'Kalender',
        fields: [
          ['Calendar.Enabled', 'Kalender', 'b'],
          ['Calendar.ShowNextEvent', 'Nächsten Termin zeigen', 'b'],
          ['Calendar.ShowAgendaInIsland', 'Terminliste in der Island', 'b'],
          ['Calendar.ShowAllDayEvents', 'Ganztägige Termine', 'b'],
          ['Calendar.UpcomingDays', 'Tage vorausschauen', 'n', { min: 1, max: 60, step: 1 }],
          ['Calendar.ReminderMinutes', 'Erinnerung vorher', 'n', { min: 0, max: 240, step: 1, unit: 'min' }],
          ['Calendar.SnoozeMinutes', 'Schlummern', 'n', { min: 1, max: 60, step: 1, unit: 'min' }],
          ['Calendar.ReminderSound', 'Erinnerungston', 'b'],
          ['Calendar.AutoExpandOnReminder', 'Bei Erinnerung aufklappen', 'b'],
        ],
      },
      { title: 'Termine', special: 'events' },
      { title: 'Abonnierte Kalender (ICS)', special: 'ics' },
    ],
  },
  {
    id: 'timers',
    title: 'Timer',
    icon: 'timer',
    groups: [
      {
        title: 'Timer',
        fields: [
          ['Timers.ShowInIsland', 'In der Island anzeigen', 'b'],
          ['Timers.CompletionSound', 'Ton, wenn ein Timer endet', 'b'],
          ['Timers.RestoreRunningTimersOnStartup', 'Laufende Timer nach Neustart fortsetzen', 'b'],
          ['Timers.PresetsMinutes', 'Schnellwahl (Minuten, mit Komma getrennt)', 'list'],
        ],
      },
    ],
  },
  {
    id: 'notifications',
    title: 'Benachrichtigungen',
    icon: 'bell',
    groups: [
      {
        title: 'Allgemein',
        fields: [
          ['Notifications.Enabled', 'Benachrichtigungen', 'b'],
          ['Notifications.DurationSeconds', 'Anzeigedauer', 'n', { min: 2, max: 30, step: 1, unit: 's' }],
          ['Notifications.Sound', 'Ton', 'b'],
          ['Notifications.ChimeSound', 'Benachrichtigungston', 'e', opts(['a', 'Klassisch (Windows 7)'], ['b', 'Modern'], ['default', 'Island-Glocke'])],
          ['Notifications.ChimeForApps', 'Auch bei Meldungen anderer Apps', 'b'],
          ['Notifications.MaxQueue', 'Warteschlange', 'n', { min: 1, max: 20, step: 1 }],
          ['Notifications.ExpandOnHighPriority', 'Wichtige aufklappen', 'b'],
          ['Notifications.SuppressDuplicates', 'Doppelte unterdrücken', 'b'],
        ],
      },
      {
        title: 'Quellen',
        fields: [
          ['Notifications.WindowsNotifications', 'Windows-Benachrichtigungen in der Island', 'b', { hint: 'Beim ersten Einschalten fragt Windows einmal nach der Erlaubnis.' }],
          ['Notifications.IslandOnly', 'Nur in der Island anzeigen (Windows-Banner aus)', 'b', { hint: 'Die Banner der Apps werden ausgeblendet – die Island klappt stattdessen auf. Im Infocenter bleiben sie erhalten.' }],
          ['Notifications.ShowAppIcon', 'App-Symbol einblenden (Discord, WhatsApp …)', 'b'],
          ['Notifications.MusicChanges', 'Musikwechsel', 'b'],
          ['Notifications.CalendarReminders', 'Kalender-Erinnerungen', 'b'],
          ['Notifications.TimerAlerts', 'Timer', 'b'],
        ],
      },
      {
        title: 'Nicht stören',
        fields: [
          ['Notifications.DndEnabled', 'Nicht stören', 'b'],
          ['Notifications.RespectQuietHours', 'Ruhezeiten beachten', 'b'],
          ['Notifications.QuietHoursStart', 'Ruhezeit ab', 'time'],
          ['Notifications.QuietHoursEnd', 'Ruhezeit bis', 'time'],
        ],
      },
    ],
  },
  {
    id: 'presence',
    title: 'Anwesenheit',
    icon: 'eye',
    groups: [
      { title: 'Gesichtserkennung', special: 'presence' },
      {
        title: 'Erkennung',
        fields: [
          ['Presence.Enabled', 'Anwesenheit erkennen (Kamera, nur lokal)', 'b'],
          ['Presence.CameraName', 'Kamera (Name)', 't'],
          ['Presence.AwaySeconds', 'Als abwesend gilt nach', 'n', { min: 5, max: 600, step: 5, unit: 's' }],
          ['Presence.RequireFaceMatch', 'Nur mein Gesicht zählt', 'b'],
          ['Presence.MatchThreshold', 'Erkennungsschwelle', 'n', pct(0.3, 0.95)],
          ['Presence.DetectionIntervalMs', 'Prüfintervall', 'n', ms(100, 2000, 50)],
          ['Presence.ShowStatusInIsland', 'Status in der Island', 'b'],
        ],
      },
      {
        title: 'Sperren',
        fields: [
          ['Presence.LockOnAway', 'PC sperren, wenn ich weg bin', 'b'],
          ['Presence.LockCountdownSeconds', 'Countdown vor dem Sperren', 'n', { min: 0, max: 300, step: 5, unit: 's' }],
          ['Presence.LockCountdownVisible', 'Countdown anzeigen', 'b'],
          ['Presence.UseWindowsHello', 'Windows Hello nutzen', 'b'],
          ['Presence.NotifyOnLock', 'Beim Sperren melden', 'b'],
          ['Presence.NotifyOnReturn', 'Bei Rückkehr begrüßen', 'b'],
        ],
      },
    ],
  },
  {
    id: 'widgets',
    title: 'Desktop-Widgets',
    icon: 'grid',
    groups: [
      {
        title: 'Widgets',
        fields: [
          ['Dock.Enabled', 'Desktop-Widgets anzeigen', 'b'],
          ['Dock.AutoHide', 'Automatisch ausblenden', 'b'],
        ],
      },
      { title: 'Einzelne Widgets', special: 'widgets' },
    ],
  },
  {
    id: 'indicators',
    title: 'Anzeigen',
    icon: 'cpu',
    groups: [
      {
        title: 'Mikrofon & Kamera',
        fields: [
          ['Indicators.PrivacyDots', 'Punkte bei Nutzung (orange = Mikrofon, grün = Kamera)', 'b'],
          ['Indicators.MicMuteSymbol', 'Stumm-Symbol, wenn das Mikrofon stumm ist oder nichts ankommt', 'b'],
          ['Indicators.MicSilenceSeconds', 'Stille bis zum Stumm-Symbol', 'n', { min: 10, max: 300, step: 5, unit: 's' }],
          ['Indicators.IgnoreOwnCamera', 'Kamera der Gesichtserkennung nicht anzeigen', 'b'],
        ],
      },
      {
        title: 'PC-Werte',
        fields: [
          ['Indicators.SystemStats', 'Klein in der eingeklappten Island', 'b'],
          ['Indicators.StatsInGlance', 'Beim Darüberfahren anzeigen', 'b'],
          ['Indicators.StatsCpu', 'CPU', 'b'],
          ['Indicators.StatsRam', 'Arbeitsspeicher', 'b'],
          ['Indicators.StatsGpu', 'Grafikkarte', 'b'],
        ],
      },
    ],
  },
  {
    id: 'system',
    title: 'Leistung & Start',
    icon: 'gauge',
    groups: [
      {
        title: 'Leistung',
        fields: [
          ['Performance.LowPowerMode', 'Stromsparmodus', 'b'],
          ['Performance.PauseWhenFullscreen', 'Bei Vollbild-Apps pausieren', 'b'],
          ['Performance.PauseVisualizerWhenCollapsed', 'Visualizer eingeklappt pausieren', 'b'],
          ['Performance.ReducedMotionOnBattery', 'Im Akkubetrieb weniger Bewegung', 'b'],
          ['Performance.IdleFrameRate', 'Bildrate im Leerlauf', 'e', opts([15, '15 fps'], [30, '30 fps'], [60, '60 fps'])],
        ],
      },
      {
        title: 'Verhalten',
        fields: [
          ['Behavior.ShowTrayIcon', 'Eigenes Symbol im Infobereich', 'b'],
          ['Behavior.StartWithWindows', 'Eigenständig mit Windows starten', 'b', { hint: 'Nicht nötig, wenn der Hub die Island startet.' }],
          ['Behavior.StartMinimizedToTray', 'Im Infobereich starten', 'b'],
          ['Behavior.CloseSettingsToTray', 'Einstellungsfenster in den Infobereich schließen', 'b'],
          ['Behavior.ConfirmExit', 'Beenden bestätigen', 'b'],
        ],
      },
    ],
  },
];

window.ORBIT_WIDGET_NAMES = {
  disks: 'Laufwerke',
  system: 'System',
  clock: 'Uhr',
  network: 'Netzwerk',
  gpu: 'Grafikkarte',
  cpu: 'Prozessor',
  ram: 'Arbeitsspeicher',
  battery: 'Akku',
  calendar: 'Kalender',
};
