import crypto from "node:crypto";
import dgram from "node:dgram";
import dns from "node:dns/promises";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { dataDir } from "./paths.mjs";
import { readJsonSync, writeJsonSync } from "./store.mjs";

/**
 * Multiplayer without a Mojang login.
 *
 * There is no account handshake here on purpose: Revolution keeps its offline accounts and
 * only talks to servers that do not verify accounts (`online-mode=false`) and to LAN worlds.
 * That means one thing only for this module — remember addresses, find worlds on the local
 * network and ask a server how it is doing. It never sends an access token anywhere.
 */

const PROTOCOL_VERSION = 769; // 1.21.4 handshake; status works across versions
const DEFAULT_PORT = 25565;
const PING_TIMEOUT = 2500;

export function serversFile() {
  return path.join(dataDir(), "servers.json");
}

function normalise(entry) {
  const port = Number(entry?.port) || DEFAULT_PORT;
  const host = String(entry?.host || "").trim();
  if (!host) return null;
  return {
    id: String(entry?.id || `srv-${crypto.randomUUID()}`),
    name: String(entry?.name || host),
    host,
    port,
    addedAt: Number(entry?.addedAt) || Date.now(),
    lastPlayed: Number(entry?.lastPlayed) || 0,
  };
}

export function listServers() {
  const raw = readJsonSync(serversFile(), { servers: [] });
  const list = Array.isArray(raw) ? raw : raw?.servers || [];
  return list.map(normalise).filter(Boolean);
}

function saveServers(list) {
  writeJsonSync(serversFile(), { servers: list });
  return list;
}

/**
 * Accepts `host`, `host:port`, `[::1]:port` and a pasted `minecraft://` link.
 */
export function parseAddress(input) {
  const text = String(input || "")
    .trim()
    .replace(/^minecraft:\/\//i, "")
    .replace(/\/+$/, "");
  if (!text) throw new Error("Enter a server address.");

  let host = text;
  let port = DEFAULT_PORT;

  if (text.startsWith("[")) {
    const end = text.indexOf("]");
    if (end < 0) throw new Error("That IPv6 address is missing its closing bracket.");
    host = text.slice(1, end);
    const rest = text.slice(end + 1);
    if (rest.startsWith(":")) port = Number(rest.slice(1));
    else if (rest) throw new Error("Unexpected text after the IPv6 address.");
  } else {
    const first = text.indexOf(":");
    const last = text.lastIndexOf(":");
    if (first > 0 && first === last) {
      host = text.slice(0, first);
      port = Number(text.slice(last + 1));
    }
  }

  host = host.trim().toLowerCase();
  if (!host) throw new Error("Enter a server address.");
  if (!Number.isInteger(port) || port <= 0 || port > 65535) {
    throw new Error("The port has to be a number between 1 and 65535.");
  }
  return { host, port };
}

export function addServer({ name, address } = {}) {
  const target = parseAddress(address);
  const list = listServers();
  if (list.some((entry) => entry.host === target.host && entry.port === target.port)) {
    throw new Error("That server is already in the list.");
  }
  const entry = {
    id: `srv-${crypto.randomUUID()}`,
    name: String(name || "").trim() || target.host,
    host: target.host,
    port: target.port,
    addedAt: Date.now(),
    lastPlayed: 0,
  };
  saveServers([entry, ...list]);
  return entry;
}

export function updateServer(id, patch = {}) {
  const list = listServers();
  const index = list.findIndex((entry) => entry.id === id);
  if (index < 0) throw new Error("That server is no longer in the list.");
  const current = list[index];
  let host = current.host;
  let port = current.port;
  if (typeof patch.address === "string" && patch.address.trim()) {
    const target = parseAddress(patch.address);
    host = target.host;
    port = target.port;
  }
  if (typeof patch.host === "string" && patch.host.trim()) host = patch.host.trim().toLowerCase();
  if (patch.port !== undefined) {
    const next = Number(patch.port);
    if (!Number.isInteger(next) || next <= 0 || next > 65535) throw new Error("The port has to be a number between 1 and 65535.");
    port = next;
  }
  const nextEntry = {
    ...current,
    host,
    port,
    name: typeof patch.name === "string" && patch.name.trim() ? patch.name.trim() : current.name,
  };
  list[index] = nextEntry;
  saveServers(list);
  return nextEntry;
}

export function removeServer(id) {
  const list = listServers().filter((entry) => entry.id !== id);
  saveServers(list);
  return list;
}

export function markPlayed(id) {
  const list = listServers();
  const entry = list.find((item) => item.id === id);
  if (!entry) return null;
  entry.lastPlayed = Date.now();
  saveServers(list);
  return entry;
}

/* ------------------------------------------------------------ packet helpers */

export function encodeVarInt(value) {
  let rest = Number(value) >>> 0;
  const bytes = [];
  do {
    let byte = rest & 0x7f;
    rest >>>= 7;
    if (rest !== 0) byte |= 0x80;
    bytes.push(byte);
  } while (rest !== 0);
  return Buffer.from(bytes);
}

export function decodeVarInt(buffer, offset = 0) {
  let value = 0;
  let shift = 0;
  let position = offset;
  while (position < buffer.length) {
    const byte = buffer[position++];
    value |= (byte & 0x7f) << shift;
    if ((byte & 0x80) === 0) return { value: value >>> 0, size: position - offset };
    shift += 7;
    if (shift > 35) break;
  }
  return null;
}

/** Minecraft's chat components arrive as a string, an object or a tree of both. */
export function flattenMotd(description) {
  if (description === null || description === undefined) return "";
  if (typeof description === "string") return description.replace(/\u00a7./g, "").trim();
  if (Array.isArray(description)) return description.map(flattenMotd).join("").trim();
  if (typeof description === "object") {
    const head = typeof description.text === "string" ? description.text : "";
    const tail = Array.isArray(description.extra) ? description.extra.map(flattenMotd).join("") : "";
    return `${head}${tail}`.replace(/\u00a7./g, "").trim();
  }
  return "";
}

/** `[MOTD]…[/MOTD][AD]25565[/AD]` — the datagram a LAN world broadcasts. */
export function parseLanBroadcast(message) {
  const text = String(message || "");
  const motd = /\[MOTD\]([\s\S]*?)\[\/MOTD\]/i.exec(text);
  const port = /\[AD\]([\s\S]*?)\[\/AD\]/i.exec(text);
  if (!motd || !port) return null;
  const value = Number(port[1]);
  if (!Number.isInteger(value) || value <= 0 || value > 65535) return null;
  return { motd: motd[1].replace(/\u00a7./g, "").trim(), port: value };
}

/* ------------------------------------------------------------------- ping */

function readStatusPacket(buffer) {
  const length = decodeVarInt(buffer, 0);
  if (!length) return null;
  if (buffer.length < length.size + length.value) return null;
  let offset = length.size;
  const packetId = decodeVarInt(buffer, offset);
  if (!packetId) return null;
  if (packetId.value !== 0x00) throw new Error("The server sent an unexpected packet.");
  offset += packetId.size;
  const size = decodeVarInt(buffer, offset);
  if (!size) return null;
  offset += size.size;
  if (buffer.length < offset + size.value) return null;
  return buffer.subarray(offset, offset + size.value).toString("utf8");
}

function queryStatus({ host, port }, timeout) {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ host, port });
    let buffer = Buffer.alloc(0);
    let settled = false;

    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      if (error) reject(error);
      else resolve(value);
    };

    socket.setTimeout(timeout, () => finish(new Error("The server did not answer in time.")));
    socket.on("error", (error) => {
      finish(new Error(error.code === "ECONNREFUSED" ? "Nothing is listening on that port." : error.message));
    });
    socket.on("connect", () => {
      const hostBuffer = Buffer.from(host, "utf8");
      const portBuffer = Buffer.alloc(2);
      portBuffer.writeUInt16BE(port);
      const body = Buffer.concat([
        encodeVarInt(0x00),
        encodeVarInt(PROTOCOL_VERSION),
        encodeVarInt(hostBuffer.length),
        hostBuffer,
        portBuffer,
        encodeVarInt(1),
      ]);
      socket.write(Buffer.concat([encodeVarInt(body.length), body, Buffer.from([0x01, 0x00])]));
    });
    socket.on("data", (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      try {
        const json = readStatusPacket(buffer);
        if (!json) return;
        const parsed = JSON.parse(json);
        finish(null, {
          motd: flattenMotd(parsed.description) || "(no MOTD)",
          version: String(parsed.version?.name || ""),
          players: {
            online: Number(parsed.players?.online) || 0,
            max: Number(parsed.players?.max) || 0,
          },
        });
      } catch (error) {
        finish(error);
      }
    });
  });
}

/** SRV records let `play.example.net` point at another host and port. */
async function resolveTarget({ host, port }) {
  if (net.isIP(host) || port !== DEFAULT_PORT) return { host, port };
  try {
    const records = await dns.resolveSrv(`_minecraft._tcp.${host}`);
    const best = [...records].sort((a, b) => a.priority - b.priority || b.weight - a.weight)[0];
    if (best?.name) return { host: best.name.replace(/\.$/, ""), port: best.port };
  } catch {
    /* no SRV record: connect to the name as given */
  }
  return { host, port };
}

/**
 * Never throws for network problems: the caller renders "offline" instead of an error page.
 */
export async function pingServer(input, { timeout = PING_TIMEOUT } = {}) {
  const target = typeof input === "string"
    ? parseAddress(input)
    : { host: String(input?.host || ""), port: Number(input?.port) || DEFAULT_PORT };
  const id = typeof input === "object" && input ? input.id : undefined;
  const started = Date.now();
  try {
    if (!target.host) throw new Error("Enter a server address.");
    const resolved = await resolveTarget(target);
    const status = await queryStatus(resolved, timeout);
    return { id, host: target.host, port: target.port, online: true, latencyMs: Date.now() - started, ...status };
  } catch (error) {
    return {
      id,
      host: target.host,
      port: target.port,
      online: false,
      latencyMs: Date.now() - started,
      motd: "",
      version: "",
      players: { online: 0, max: 0 },
      error: error?.message || "Unreachable",
    };
  }
}

export async function pingMany(targets = [], { timeout = PING_TIMEOUT } = {}) {
  const list = (Array.isArray(targets) ? targets : []).slice(0, 60).filter((entry) => entry && entry.host);
  const results = [];
  let cursor = 0;
  const workers = Array.from({ length: Math.min(6, list.length) }, async () => {
    while (cursor < list.length) {
      const target = list[cursor++];
      results.push(await pingServer(target, { timeout }));
    }
  });
  await Promise.all(workers);
  return results;
}

/* -------------------------------------------------------------------- LAN */

function localAddresses() {
  const addresses = new Set(["127.0.0.1", "::1"]);
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const entry of entries || []) addresses.add(entry.address);
  }
  return addresses;
}

/**
 * Listen for the multicast datagram every "Open to LAN" world sends, then ask each world
 * for its MOTD and player count. A world hosted on this machine is reached over loopback.
 */
export function discoverLan({ durationMs = 3500 } = {}) {
  const window = Math.max(600, Math.min(15000, Number(durationMs) || 3500));
  return new Promise((resolve) => {
    const socket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const found = new Map();
    const locals = localAddresses();
    let closed = false;

    const finish = async () => {
      if (closed) return;
      closed = true;
      try { socket.close(); } catch { /* already closed */ }
      const worlds = [];
      for (const entry of found.values()) {
        let details = null;
        try {
          details = await pingServer({ host: entry.host, port: entry.port }, { timeout: 1200 });
        } catch { /* the world may have closed already */ }
        worlds.push({
          host: entry.host,
          port: entry.port,
          address: `${entry.host}:${entry.port}`,
          motd: details?.online ? details.motd : entry.motd,
          version: details?.online ? details.version : "",
          players: details?.online ? details.players : { online: 0, max: 0 },
        });
      }
      resolve(worlds);
    };

    socket.on("message", (message, rinfo) => {
      const parsed = parseLanBroadcast(message.toString("utf8"));
      if (!parsed) return;
      const host = locals.has(rinfo.address) ? "127.0.0.1" : rinfo.address;
      const key = `${host}:${parsed.port}`;
      if (found.has(key)) {
        found.get(key).motd = parsed.motd;
        return;
      }
      found.set(key, { host, port: parsed.port, motd: parsed.motd });
    });
    socket.on("error", () => { void finish(); });
    socket.bind(4445, () => {
      try { socket.addMembership("224.0.2.60"); } catch { /* multicast unavailable */ }
      try { socket.setBroadcast(true); } catch { /* not fatal */ }
      setTimeout(() => { void finish(); }, window);
    });
    // A port that never binds must not leave the page spinning forever.
    setTimeout(() => { void finish(); }, window + 2500);
  });
}
