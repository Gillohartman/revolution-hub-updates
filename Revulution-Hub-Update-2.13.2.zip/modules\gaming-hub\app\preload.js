const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('fnpanel', {
  getState: () => ipcRenderer.invoke('state:get'),
  startScan: () => ipcRenderer.invoke('scan:start'),
  saveSettings: (patch) => ipcRenderer.invoke('settings:save', patch),
  pickReplayDir: () => ipcRenderer.invoke('dialog:pickReplayDir'),
  openPath: (target) => ipcRenderer.invoke('shell:openPath', target),
  clearMatches: () => ipcRenderer.invoke('matches:clear'),
  captureSources: () => ipcRenderer.invoke('capture:sources'),
  testPopup: () => ipcRenderer.invoke('overlay:test'),
  testNotice: () => ipcRenderer.invoke('overlay:noticeTest'),
  testCrosshair: () => ipcRenderer.invoke('overlay:crosshairTest'),
  ocrFrame: (base64) => ipcRenderer.invoke('ocr:frame', base64),
  feedFrame: (base64) => ipcRenderer.invoke('ocr:feed', base64),
  testSummary: () => ipcRenderer.invoke('summary:test'),

  clipChunk: (buffer, isFirst) =>
    ipcRenderer.send('clip:chunk', { buffer: buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength), isFirst }),
  clipSave: (options) => ipcRenderer.invoke('clip:save', options),
  clipReset: () => ipcRenderer.invoke('clip:reset'),
  clipList: () => ipcRenderer.invoke('clips:list'),
  clipDelete: (name) => ipcRenderer.invoke('clip:delete', name),
  clipClear: () => ipcRenderer.invoke('clips:clear'),

  onScanProgress: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('scan:progress', handler);
    return () => ipcRenderer.removeListener('scan:progress', handler);
  },
  onScanDone: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('scan:done', handler);
    return () => ipcRenderer.removeListener('scan:done', handler);
  },
  onClipSaved: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('clip:auto-saved', handler);
    return () => ipcRenderer.removeListener('clip:auto-saved', handler);
  },
  onClipTrigger: (callback) => {
    const handler = () => callback();
    ipcRenderer.on('clip:trigger', handler);
    return () => ipcRenderer.removeListener('clip:trigger', handler);
  },
  onOpenMatch: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('ui:open-match', handler);
    return () => ipcRenderer.removeListener('ui:open-match', handler);
  },
  onLiveKill: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('kill:live', handler);
    return () => ipcRenderer.removeListener('kill:live', handler);
  },
  onLiveDiag: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('live:diag', handler);
    return () => ipcRenderer.removeListener('live:diag', handler);
  },
});
