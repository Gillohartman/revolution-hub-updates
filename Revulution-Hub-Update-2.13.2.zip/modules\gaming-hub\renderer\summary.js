/* Match-Fenster nach dem Spiel: grosse Kennzahlen und alle Kills des Matches. */
(() => {
  const api = window.matchSummary;
  const root = document.getElementById('root');
  const numberFmt = new Intl.NumberFormat('de-DE');

  const n = (value) => numberFmt.format(Math.round(Number(value) || 0));
  const esc = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const time = (seconds) => {
    const total = Math.max(0, Math.round(Number(seconds) || 0));
    return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
  };

  const dateLabel = (raw) => {
    const date = raw ? new Date(raw) : new Date();
    if (Number.isNaN(date.getTime())) return '';
    const pad = (value) => String(value).padStart(2, '0');
    return `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${date.getFullYear()} · ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  };

  function render(data) {
    if (!data) return;
    const placement = Number(data.placement) || 0;
    const title = placement === 1 ? 'SIEG' : placement ? `#${placement}` : 'MATCH';
    const cards = Array.isArray(data.cards) ? data.cards : [];
    const stats = data.stats || {};
    const damagePerKill = cards.filter((card) => card.damage).length;

    root.innerHTML = `
      <div class="card">
        <div class="head">
          <div>
            <p class="kicker">Match beendet · ${esc(dateLabel(data.date))}</p>
            <div class="placement ${placement === 1 ? 'win' : ''}">${esc(title)}</div>
          </div>
          <div class="head-right">
            <button class="close" data-action="close" title="Schließen">✕</button>
            <span class="pill">${esc(data.name || 'Spieler')}</span>
            <span class="pill">${time(data.durationSec)}</span>
            ${data.recognizedCount ? `<span class="pill gold">${data.recognizedCount} bekannte Gegner</span>` : ''}
          </div>
        </div>

        <div class="hero">
          <div><span class="label">Kills</span><span class="value">${n(data.kills)}</span></div>
          <div><span class="label">Schaden</span><span class="value">${n(stats.damageToPlayers)}</span></div>
          <div><span class="label">Trefferquote</span><span class="value small">${(Number(stats.accuracy) || 0).toFixed(1)} %</span></div>
          <div><span class="label">Schaden genommen</span><span class="value">${n(stats.damageTaken)}</span></div>
        </div>

        <div class="grid">
          <div class="cell"><span>Material</span><b>${n(stats.materialsGathered)}</b></div>
          <div class="cell"><span>An Strukturen</span><b>${n(stats.damageToStructures)}</b></div>
          <div class="cell"><span>Distanz</span><b>${n((stats.distanceTraveled || 0) / 100)} m</b></div>
          <div class="cell"><span>Assists</span><b>${n(stats.assists)}</b></div>
          <div class="cell"><span>Revives</span><b>${n(stats.revives)}</b></div>
          <div class="cell"><span>Schaden / Kill</span><b>${data.kills ? n(stats.damageToPlayers / data.kills) : '–'}</b></div>
        </div>

        ${
          cards.length
            ? `<div class="kills">
                <h2>Deine Kills ${damagePerKill ? '· Schaden geschätzt (OCR)' : ''}</h2>
                <div class="kill-list">
                  ${cards
                    .map(
                      (card) => `
                    <div class="kill-row">
                      <span class="name">${esc(card.name || 'Unbekannt')}</span>
                      ${card.recognized ? '<span class="tag">Bekannt</span>' : ''}
                      ${card.bot ? '<span class="tag bot">Bot</span>' : ''}
                      <span class="dmg">${card.damage ? '≈ ' + n(card.damage) + ' Schaden' : '–'}</span>
                    </div>`,
                    )
                    .join('')}
                </div>
              </div>
              <p class="note">${damagePerKill ? 'Schaden pro Gegner ist eine OCR-Schätzung vom Bildschirm – Gesamtschaden oben ist exakt aus dem Replay.' : 'Schaden pro Gegner erscheint, sobald die Aufnahme während des Matches lief.'}</p>`
            : '<p class="note">Keine Kills in diesem Match – das Replay ist trotzdem im Archiv.</p>'
        }

        <div class="foot">
          <button class="btn" data-action="close">Schließen</button>
          <button class="btn primary" data-action="open-match">In der App öffnen</button>
        </div>
      </div>
    `;
  }

  document.addEventListener('click', (event) => {
    const action = event.target.closest('[data-action]')?.dataset.action;
    if (!action || !api) return;
    if (action === 'close') api.close();
    if (action === 'open-match') api.openMatch();
  });

  window.__renderSummary = render;

  if (api) {
    api.onData(render);
  } else {
    // Vorschau im Browser ohne App.
    document.body.style.background = '#08070f';
    render({
      date: new Date().toISOString(),
      name: 'DaddyAndrin',
      placement: 3,
      kills: 5,
      durationSec: 903,
      recognizedCount: 2,
      stats: {
        damageToPlayers: 1245,
        damageTaken: 640,
        accuracy: 21.4,
        materialsGathered: 1840,
        materialsUsed: 1210,
        damageToStructures: 3200,
        distanceTraveled: 615000,
        assists: 2,
        revives: 1,
      },
      cards: [
        { name: 'Sharkboy61', damage: 87, recognized: true },
        { name: 'Famous_king_31', damage: 120 },
        { name: 'Bot_Waechter', damage: 45, bot: true },
      ],
    });
  }
})();
