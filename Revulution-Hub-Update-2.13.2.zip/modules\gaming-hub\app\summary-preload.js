const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('matchSummary', {
  onData: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('summary:data', handler);
    return () => ipcRenderer.removeListener('summary:data', handler);
  },
  close: () => ipcRenderer.send('summary:close'),
  openMatch: () => ipcRenderer.send('summary:open'),
});
