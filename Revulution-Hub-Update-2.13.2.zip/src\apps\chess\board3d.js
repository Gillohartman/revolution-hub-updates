'use strict';

/*
 * 3D-Brett für den Schach-Coach (WebGL 2, ohne Bibliotheken).
 *   – gedrechselte Staunton-Figuren, Springer aus einer Silhouette modelliert
 *   – weiche Schatten (Shadow-Map), Spiegelung im Brett, Studio-Licht, ACES-Tonemapping
 *   – jeder Figuren-Skin und jedes Brett aus dem Shop als eigenes Material
 * Das DOM-Brett bleibt als Logik-Ebene bestehen; chess.js meldet hier nur den Zustand.
 */
(function () {
  const PI = Math.PI;
  const SKINS = ['classic', 'marble', 'neon', 'ice', 'gold', 'fire', 'void', 'galaxy', 'rainbow', 'obsidian', 'emerald', 'chrome'];
  const BOARDS = ['standard', 'walnut', 'marble', 'ocean', 'neon', 'lava', 'cosmos', 'glass', 'sakura', 'royal'];
  // Rahmenfarbe, Beschriftung, Spiegelstärke je Brett
  const BOARD_INFO = {
    standard: { frame: [0.2, 0.13, 0.08], label: '#e8d9b8', refl: 0.2 },
    walnut: { frame: [0.16, 0.085, 0.04], label: '#e3c08d', refl: 0.16 },
    marble: { frame: [0.2, 0.2, 0.22], label: '#f1efe9', refl: 0.34 },
    ocean: { frame: [0.03, 0.1, 0.2], label: '#bfe9ff', refl: 0.4 },
    neon: { frame: [0.03, 0.025, 0.07], label: '#5ff4ff', refl: 0.45 },
    lava: { frame: [0.06, 0.03, 0.025], label: '#ffb36b', refl: 0.1 },
    cosmos: { frame: [0.04, 0.035, 0.11], label: '#c7d2fe', refl: 0.4 },
    glass: { frame: [0.36, 0.42, 0.5], label: '#ffffff', refl: 0.55 },
    sakura: { frame: [0.3, 0.13, 0.18], label: '#ffe4ec', refl: 0.2 },
    royal: { frame: [0.13, 0.02, 0.04], label: '#f6d27a', refl: 0.3 },
  };
  // Leuchten unter den Figuren (Weiß, Schwarz) für Skins, die Licht abgeben
  const SKIN_GLOW = {
    neon: [[0.2, 0.9, 1.0], [1.0, 0.2, 0.85]],
    fire: [[1.0, 0.55, 0.1], [1.0, 0.2, 0.02]],
    void: [[0.55, 0.3, 1.0], [0.5, 0.2, 0.9]],
    galaxy: [[0.5, 0.55, 1.0], [0.4, 0.3, 0.9]],
    ice: [[0.35, 0.7, 1.0], [0.15, 0.5, 0.9]],
    emerald: [[0.2, 0.9, 0.5], [0.05, 0.6, 0.3]],
  };
  const OUT = 4.6; // halbe Kantenlänge inkl. Rahmen
  const HEIGHT = [0, 0.82, 1.0, 1.2, 0.96, 1.42, 1.6]; // Figurenhöhe je Typ (für Abzeichen)

  /* ------------------------------------------------------------------ Mathe */
  const mul = (a, b) => {
    const o = new Float32Array(16);
    for (let c = 0; c < 4; c += 1) for (let r = 0; r < 4; r += 1) o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
    return o;
  };
  const persp = (fovy, asp, n, f) => {
    const t = 1 / Math.tan(fovy / 2);
    return new Float32Array([t / asp, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) / (n - f), -1, 0, 0, (2 * f * n) / (n - f), 0]);
  };
  const ortho = (l, r, b, t, n, f) => new Float32Array([2 / (r - l), 0, 0, 0, 0, 2 / (t - b), 0, 0, 0, 0, -2 / (f - n), 0, -(r + l) / (r - l), -(t + b) / (t - b), -(f + n) / (f - n), 1]);
  const norm = (v) => {
    const l = Math.hypot(v[0], v[1], v[2]) || 1;
    return [v[0] / l, v[1] / l, v[2] / l];
  };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const lookAt = (e, c, up) => {
    const f = norm([c[0] - e[0], c[1] - e[1], c[2] - e[2]]);
    const s = norm(cross(f, up));
    const u = cross(s, f);
    return new Float32Array([s[0], u[0], -f[0], 0, s[1], u[1], -f[1], 0, s[2], u[2], -f[2], 0, -(s[0] * e[0] + s[1] * e[1] + s[2] * e[2]), -(u[0] * e[0] + u[1] * e[1] + u[2] * e[2]), f[0] * e[0] + f[1] * e[1] + f[2] * e[2], 1]);
  };
  const invert = (m) => {
    const o = new Float32Array(16);
    const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3], a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7], a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11], a30 = m[12], a31 = m[13], a32 = m[14], a33 = m[15];
    const b00 = a00 * a11 - a01 * a10, b01 = a00 * a12 - a02 * a10, b02 = a00 * a13 - a03 * a10, b03 = a01 * a12 - a02 * a11, b04 = a01 * a13 - a03 * a11, b05 = a02 * a13 - a03 * a12;
    const b06 = a20 * a31 - a21 * a30, b07 = a20 * a32 - a22 * a30, b08 = a20 * a33 - a23 * a30, b09 = a21 * a32 - a22 * a31, b10 = a21 * a33 - a23 * a31, b11 = a22 * a33 - a23 * a32;
    let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
    if (!det) return null;
    det = 1 / det;
    o[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det;
    o[1] = (a02 * b10 - a01 * b11 - a03 * b09) * det;
    o[2] = (a31 * b05 - a32 * b04 + a33 * b03) * det;
    o[3] = (a22 * b04 - a21 * b05 - a23 * b03) * det;
    o[4] = (a12 * b08 - a10 * b11 - a13 * b07) * det;
    o[5] = (a00 * b11 - a02 * b08 + a03 * b07) * det;
    o[6] = (a32 * b02 - a30 * b05 - a33 * b01) * det;
    o[7] = (a20 * b05 - a22 * b02 + a23 * b01) * det;
    o[8] = (a10 * b10 - a11 * b08 + a13 * b06) * det;
    o[9] = (a01 * b08 - a00 * b10 - a03 * b06) * det;
    o[10] = (a30 * b04 - a31 * b02 + a33 * b00) * det;
    o[11] = (a21 * b02 - a20 * b04 - a23 * b00) * det;
    o[12] = (a11 * b07 - a10 * b09 - a12 * b06) * det;
    o[13] = (a00 * b09 - a01 * b07 + a02 * b06) * det;
    o[14] = (a31 * b01 - a30 * b03 - a32 * b00) * det;
    o[15] = (a20 * b03 - a21 * b01 + a22 * b00) * det;
    return o;
  };
  const xf = (m, x, y, z, w = 1) => [m[0] * x + m[4] * y + m[8] * z + m[12] * w, m[1] * x + m[5] * y + m[9] * z + m[13] * w, m[2] * x + m[6] * y + m[10] * z + m[14] * w, m[3] * x + m[7] * y + m[11] * z + m[15] * w];
  const trs = (x, y, z, rot, s) => {
    const c = Math.cos(rot) * s, n = Math.sin(rot) * s;
    return new Float32Array([c, 0, -n, 0, 0, s, 0, 0, n, 0, c, 0, x, y, z, 1]);
  };
  const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  const sqXZ = (sq) => [(sq & 7) - 3.5, 3.5 - (sq >> 4)];

  /* ------------------------------------------------------------------ Geometrie */
  const newMesh = () => ({ p: [], n: [], i: [] });
  function merge(...ms) {
    const o = newMesh();
    for (const m of ms) {
      const base = o.p.length / 3;
      for (const v of m.p) o.p.push(v);
      for (const v of m.n) o.n.push(v);
      for (const v of m.i) o.i.push(v + base);
    }
    return o;
  }
  function move(m, dx, dy, dz) {
    for (let k = 0; k < m.p.length; k += 3) {
      m.p[k] += dx;
      m.p[k + 1] += dy;
      m.p[k + 2] += dz;
    }
    return m;
  }

  /** Catmull-Rom durch eine offene Punktfolge. */
  function smoothRun(pts, sub) {
    if (pts.length < 3) return pts.slice();
    const out = [];
    for (let i = 0; i < pts.length - 1; i += 1) {
      const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
      for (let s = 0; s < sub; s += 1) {
        const t = s / sub, t2 = t * t, t3 = t2 * t;
        out.push([0, 1].map((k) => 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3)));
      }
    }
    out.push(pts[pts.length - 1].slice(0, 2));
    return out;
  }

  /** Drehkörper aus einem Profil [[r, y, ecke?], …] – Ecken (3. Wert = 1) bleiben scharf. */
  function lathe(profile, seg = 44) {
    const m = newMesh();
    const runs = [];
    let cur = [profile[0]];
    for (let i = 1; i < profile.length; i += 1) {
      cur.push(profile[i]);
      if (profile[i][2] || i === profile.length - 1) {
        runs.push(cur);
        cur = [profile[i]];
      }
    }
    for (const run of runs) {
      const pts = smoothRun(run, 5).map(([r, y]) => [Math.max(0, r), y]);
      const segN = [];
      for (let i = 0; i < pts.length - 1; i += 1) {
        const dr = pts[i + 1][0] - pts[i][0], dy = pts[i + 1][1] - pts[i][1];
        const l = Math.hypot(dr, dy) || 1;
        segN.push([dy / l, -dr / l]);
      }
      const vn = pts.map((_, i) => {
        const a = segN[Math.max(0, i - 1)], b = segN[Math.min(segN.length - 1, i)];
        const l = Math.hypot(a[0] + b[0], a[1] + b[1]) || 1;
        return [(a[0] + b[0]) / l, (a[1] + b[1]) / l];
      });
      const base = m.p.length / 3;
      for (let i = 0; i < pts.length; i += 1)
        for (let j = 0; j <= seg; j += 1) {
          const a = (j / seg) * PI * 2, c = Math.cos(a), s = Math.sin(a);
          m.p.push(pts[i][0] * c, pts[i][1], pts[i][0] * s);
          m.n.push(vn[i][0] * c, vn[i][1], vn[i][0] * s);
        }
      const row = seg + 1;
      for (let i = 0; i < pts.length - 1; i += 1)
        for (let j = 0; j < seg; j += 1) {
          const a = base + i * row + j, b = a + row;
          m.i.push(a, b, a + 1, b, b + 1, a + 1);
        }
    }
    return m;
  }
  const arc = (cy, rad, a0, a1, n) => Array.from({ length: n + 1 }, (_, k) => {
    const a = ((a0 + ((a1 - a0) * k) / n) * PI) / 180;
    return [Math.cos(a) * rad, cy + Math.sin(a) * rad];
  });
  const ball = (rad, seg = 14) => lathe(arc(0, rad, -90, 90, 8), seg);

  function quad(m, a, b, c, d) {
    // a,b,c,d gegen den Uhrzeigersinn von außen gesehen
    const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [d[0] - a[0], d[1] - a[1], d[2] - a[2]];
    const n = norm(cross(u, v));
    const base = m.p.length / 3;
    for (const q of [a, b, c, d]) {
      m.p.push(q[0], q[1], q[2]);
      m.n.push(n[0], n[1], n[2]);
    }
    m.i.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
  function box(cx, cy, cz, sx, sy, sz) {
    const m = newMesh();
    const x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2;
    quad(m, [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]);
    quad(m, [x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]);
    quad(m, [x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]);
    quad(m, [x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]);
    quad(m, [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]);
    quad(m, [x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]);
    return m;
  }
  /** Ringstück (Zinne des Turms). */
  function sector(r0, r1, y0, y1, a0, a1, n = 5) {
    const m = newMesh();
    const P = (r, a, y) => [Math.cos(a) * r, y, Math.sin(a) * r];
    for (let k = 0; k < n; k += 1) {
      const a = a0 + ((a1 - a0) * k) / n, b = a0 + ((a1 - a0) * (k + 1)) / n;
      quad(m, P(r1, a, y0), P(r1, a, y1), P(r1, b, y1), P(r1, b, y0)); // außen
      quad(m, P(r0, b, y0), P(r0, b, y1), P(r0, a, y1), P(r0, a, y0)); // innen
      quad(m, P(r0, a, y1), P(r0, b, y1), P(r1, b, y1), P(r1, a, y1)); // oben
    }
    quad(m, P(r0, a0, y0), P(r0, a0, y1), P(r1, a0, y1), P(r1, a0, y0));
    quad(m, P(r1, a1, y0), P(r1, a1, y1), P(r0, a1, y1), P(r0, a1, y0));
    return m;
  }

  /** Sockel, den alle Figuren teilen (R = Radius). */
  const foot = (R) => [[0, 0], [R * 0.97, 0, 1], [R, 0.035], [R * 0.985, 0.085, 1], [R * 0.84, 0.105, 1], [R * 0.86, 0.15], [R * 0.78, 0.19, 1]];

  function earclip(poly) {
    const idx = poly.map((_, i) => i);
    const tris = [];
    const area = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
    const inside = (p, a, b, c) => area(a, b, p) >= 0 && area(b, c, p) >= 0 && area(c, a, p) >= 0;
    let guard = poly.length * poly.length;
    while (idx.length > 3 && guard-- > 0) {
      let cut = false;
      for (let k = 0; k < idx.length; k += 1) {
        const i0 = idx[(k + idx.length - 1) % idx.length], i1 = idx[k], i2 = idx[(k + 1) % idx.length];
        const a = poly[i0], b = poly[i1], c = poly[i2];
        if (area(a, b, c) <= 1e-9) continue;
        let ok = true;
        for (const j of idx) {
          if (j === i0 || j === i1 || j === i2) continue;
          if (inside(poly[j], a, b, c)) {
            ok = false;
            break;
          }
        }
        if (!ok) continue;
        tris.push(i0, i1, i2);
        idx.splice(k, 1);
        cut = true;
        break;
      }
      if (!cut) idx.splice(0, 1); // entartete Stelle überspringen
    }
    if (idx.length === 3) tris.push(idx[0], idx[1], idx[2]);
    return tris;
  }

  /** Pferdekopf: Seitenansicht (x nach vorn, y nach oben), in z gewölbt ausgezogen. */
  function horse() {
    const ctrl = [
      [-0.2, 0.26], [0.0, 0.25], [0.2, 0.26], [0.215, 0.36], [0.175, 0.45], [0.115, 0.52], [0.105, 0.575], [0.16, 0.595], [0.25, 0.585], [0.315, 0.6],
      [0.345, 0.655], [0.335, 0.72], [0.285, 0.775], [0.235, 0.835], [0.19, 0.9], [0.165, 0.95], [0.16, 1.03], [0.105, 0.985], [0.05, 0.975],
      [-0.04, 0.94], [-0.125, 0.86], [-0.185, 0.74], [-0.215, 0.6], [-0.205, 0.47], [-0.22, 0.36],
    ];
    const n0 = ctrl.length;
    const pts = [];
    for (let i = 0; i < n0; i += 1) {
      const p0 = ctrl[(i + n0 - 1) % n0], p1 = ctrl[i], p2 = ctrl[(i + 1) % n0], p3 = ctrl[(i + 2) % n0];
      for (let s = 0; s < 4; s += 1) {
        const t = s / 4, t2 = t * t, t3 = t2 * t;
        pts.push([0, 1].map((k) => 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3)));
      }
    }
    const n = pts.length;
    const nor = pts.map((_, i) => {
      const a = pts[(i - 1 + n) % n], b = pts[(i + 1) % n];
      const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1;
      return [dy / l, -dx / l];
    });
    const hz = (y) => (y < 0.6 ? 0.19 - ((y - 0.26) / 0.34) * 0.06 : 0.13 - ((y - 0.6) / 0.43) * 0.045);
    const K = 8, bev = 0.034;
    const m = newMesh();
    for (let k = 0; k <= K; k += 1) {
      const a = -PI / 2 + (PI * k) / K;
      const inset = bev * (1 - Math.cos(a));
      for (let i = 0; i < n; i += 1) {
        const x = pts[i][0] - nor[i][0] * inset, y = pts[i][1] - nor[i][1] * inset;
        m.p.push(x, y, hz(y) * Math.sin(a) * (1 - 0.12 * (1 - Math.cos(a))));
      }
    }
    for (let k = 0; k < K; k += 1)
      for (let i = 0; i < n; i += 1) {
        const a = k * n + i, b = k * n + ((i + 1) % n), c = a + n, d = b + n;
        m.i.push(a, b, c, b, d, c);
      }
    // weiche Normalen aus den Flächen
    m.n = new Array(m.p.length).fill(0);
    for (let t = 0; t < m.i.length; t += 3) {
      const [a, b, c] = [m.i[t] * 3, m.i[t + 1] * 3, m.i[t + 2] * 3];
      const u = [m.p[b] - m.p[a], m.p[b + 1] - m.p[a + 1], m.p[b + 2] - m.p[a + 2]], v = [m.p[c] - m.p[a], m.p[c + 1] - m.p[a + 1], m.p[c + 2] - m.p[a + 2]];
      const f = cross(u, v);
      for (const q of [a, b, c]) {
        m.n[q] += f[0];
        m.n[q + 1] += f[1];
        m.n[q + 2] += f[2];
      }
    }
    for (let q = 0; q < m.n.length; q += 3) {
      const v = norm([m.n[q], m.n[q + 1], m.n[q + 2]]);
      m.n[q] = v[0];
      m.n[q + 1] = v[1];
      m.n[q + 2] = v[2];
    }
    // flache Seitenflächen mit eigenen Punkten (sonst entstehen Schlieren im Glanz)
    const cap = pts.map((p, i) => [p[0] - nor[i][0] * bev, p[1] - nor[i][1] * bev]);
    const tris = earclip(cap);
    for (const side of [1, -1]) {
      const base = m.p.length / 3;
      const ring = side > 0 ? K * n : 0;
      for (let i = 0; i < n; i += 1) {
        m.p.push(m.p[(ring + i) * 3], m.p[(ring + i) * 3 + 1], m.p[(ring + i) * 3 + 2]);
        m.n.push(0, 0.12, side);
      }
      for (let t = 0; t < tris.length; t += 3) {
        if (side > 0) m.i.push(base + tris[t], base + tris[t + 1], base + tris[t + 2]);
        else m.i.push(base + tris[t], base + tris[t + 2], base + tris[t + 1]);
      }
    }
    return m;
  }

  function buildPieces() {
    const P = [];
    // Bauer
    P[1] = lathe([...foot(0.29), [0.17, 0.225], [0.115, 0.33], [0.092, 0.44], [0.098, 0.5, 1], [0.175, 0.515, 1], [0.175, 0.545, 1], [0.1, 0.565, 1], ...arc(0.68, 0.142, -62, 90, 9).map((p, i) => (i === 0 ? [p[0], p[1], 1] : p))]);
    // Springer
    const kb = lathe([...foot(0.34), [0.245, 0.215, 1], [0.245, 0.25, 1], [0.21, 0.275, 1], [0, 0.285]]);
    P[2] = merge(kb, horse());
    // Läufer
    P[3] = lathe([...foot(0.33), [0.19, 0.235], [0.13, 0.41], [0.1, 0.6], [0.108, 0.665, 1], [0.195, 0.68, 1], [0.195, 0.712, 1], [0.118, 0.73, 1], [0.135, 0.77], [0.172, 0.85], [0.165, 0.93], [0.118, 1.03], [0.055, 1.095], [0.032, 1.115, 1], ...arc(1.155, 0.05, -70, 90, 6).map((p, i) => (i === 0 ? [p[0], p[1], 1] : p))]);
    // Turm
    const rook = lathe([...foot(0.33), [0.21, 0.23], [0.178, 0.42], [0.172, 0.62], [0.19, 0.685, 1], [0.255, 0.7, 1], [0.255, 0.735, 1], [0.215, 0.755, 1], [0.225, 0.775, 1], [0.268, 0.8, 1], [0.268, 0.875, 1], [0, 0.875]]);
    const merlons = [];
    for (let k = 0; k < 6; k += 1) merlons.push(sector(0.175, 0.268, 0.87, 0.965, (k / 6) * PI * 2 + 0.16, ((k + 1) / 6) * PI * 2 - 0.16));
    P[4] = merge(rook, ...merlons);
    // Dame
    const queen = lathe([...foot(0.36), [0.21, 0.24], [0.14, 0.46], [0.108, 0.72], [0.118, 0.8, 1], [0.215, 0.815, 1], [0.215, 0.848, 1], [0.13, 0.866, 1], [0.132, 0.9], [0.16, 1.02], [0.215, 1.13], [0.25, 1.2, 1], [0.2, 1.205, 1], [0.165, 1.175], [0.1, 1.215], [0.04, 1.26, 1], ...arc(1.305, 0.052, -75, 90, 6).map((p, i) => (i === 0 ? [p[0], p[1], 1] : p))]);
    const pearls = [];
    for (let k = 0; k < 8; k += 1) pearls.push(move(ball(0.036, 10), Math.cos((k / 8) * PI * 2) * 0.225, 1.222, Math.sin((k / 8) * PI * 2) * 0.225));
    P[5] = merge(queen, ...pearls);
    // König
    const king = lathe([...foot(0.37), [0.22, 0.25], [0.15, 0.5], [0.118, 0.78], [0.128, 0.86, 1], [0.225, 0.875, 1], [0.225, 0.908, 1], [0.14, 0.926, 1], [0.142, 0.96], [0.17, 1.09], [0.235, 1.235, 1], [0.195, 1.262, 1], [0.105, 1.305], [0.058, 1.335, 1], [0.058, 1.365, 1], [0, 1.365]]);
    P[6] = merge(king, box(0, 1.475, 0, 0.068, 0.25, 0.052), box(0, 1.5, 0, 0.2, 0.068, 0.052));
    return P;
  }

  function boardMeshes() {
    const top = newMesh();
    quad(top, [-4, 0, 4], [4, 0, 4], [4, 0, -4], [-4, 0, -4]);
    const frame = newMesh();
    const B = OUT - 0.1, D = -0.42;
    // Oberseite des Rahmens (4 Streifen) + Fase + Seiten
    quad(frame, [-B, 0, B], [B, 0, B], [4, 0, 4], [-4, 0, 4]);
    quad(frame, [B, 0, -B], [-B, 0, -B], [-4, 0, -4], [4, 0, -4]);
    quad(frame, [B, 0, B], [B, 0, -B], [4, 0, -4], [4, 0, 4]);
    quad(frame, [-B, 0, -B], [-B, 0, B], [-4, 0, 4], [-4, 0, -4]);
    const O = OUT, H = -0.09;
    quad(frame, [-O, H, O], [O, H, O], [B, 0, B], [-B, 0, B]);
    quad(frame, [O, H, -O], [-O, H, -O], [-B, 0, -B], [B, 0, -B]);
    quad(frame, [O, H, O], [O, H, -O], [B, 0, -B], [B, 0, B]);
    quad(frame, [-O, H, -O], [-O, H, O], [-B, 0, B], [-B, 0, -B]);
    quad(frame, [-O, D, O], [O, D, O], [O, H, O], [-O, H, O]);
    quad(frame, [O, D, -O], [-O, D, -O], [-O, H, -O], [O, H, -O]);
    quad(frame, [O, D, O], [O, D, -O], [O, H, -O], [O, H, O]);
    quad(frame, [-O, D, -O], [-O, D, O], [-O, H, O], [-O, H, -O]);
    const ground = newMesh();
    quad(ground, [-9, D, 9], [9, D, 9], [9, D, -9], [-9, D, -9]);
    return { top, frame, ground };
  }

  /* ------------------------------------------------------------------ Shader */
  const VS = `#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNor;
uniform mat4 uModel, uVP, uLightVP; uniform float uMirror;
out vec3 vW; out vec3 vN; out vec3 vL; out vec4 vS;
void main(){ vec4 w=uModel*vec4(aPos,1.); vec3 n=mat3(uModel)*aNor; vS=uLightVP*w; w.y*=uMirror; n.y*=uMirror; vW=w.xyz; vN=n; vL=aPos; gl_Position=uVP*w; }`;

  const DEPTH_FS = `#version 300 es
precision mediump float; void main(){}`;

  const COMMON = `#version 300 es
precision highp float; precision highp int; precision highp sampler2DShadow;
in vec3 vW; in vec3 vN; in vec3 vL; in vec4 vS; out vec4 o;
uniform vec3 uEye, uLightDir; uniform vec2 uYaw; uniform float uTime, uMirror;
uniform sampler2DShadow uShadow;
const vec3 LIGHT=vec3(2.9,2.72,2.5);
float hash(vec3 p){ p=fract(p*.3183099+.1); p*=17.; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float noise(vec3 x){ vec3 i=floor(x), f=fract(x); f=f*f*(3.-2.*f);
  return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z); }
float fbm(vec3 p){ float a=.5, s=0.; for(int i=0;i<4;i++){ s+=a*noise(p); p=p*2.03+7.1; a*=.5; } return s; }
vec3 hsv(float h,float s,float v){ vec3 k=clamp(abs(fract(h+vec3(0.,2./3.,1./3.))*6.-3.)-1.,0.,1.); return v*mix(vec3(1.),k,s); }
vec3 env(vec3 r, float rough){
  r=vec3(uYaw.y*r.x-uYaw.x*r.z, r.y, uYaw.x*r.x+uYaw.y*r.z);
  float t=r.y*.5+.5;
  vec3 c=mix(vec3(.035,.035,.05), vec3(.30,.34,.44), smoothstep(.15,1.,t));
  c+=vec3(.20,.17,.15)*smoothstep(.3,0.,abs(r.y+.05));
  float k=mix(90.,5.,rough);
  c+=LIGHT*pow(max(dot(r,normalize(vec3(-.6,.95,.2))),0.),k)*mix(1.6,.22,rough);
  c+=vec3(.55,.72,1.)*pow(max(dot(r,normalize(vec3(.8,.45,-.35))),0.),k*.45)*mix(1.5,.3,rough);
  c+=vec3(1.,.82,.66)*pow(max(dot(r,normalize(vec3(-.75,.3,-.6))),0.),k*.45)*mix(1.2,.25,rough);
  c+=vec3(.9,.95,1.)*smoothstep(.16,.0,abs(r.y-.55))*smoothstep(-.2,.6,r.z)*.5*(1.-rough);
  return c;
}
float shadow(float nl){
  vec3 p=vS.xyz/vS.w*.5+.5; if(p.z>1.||p.x<0.||p.x>1.||p.y<0.||p.y>1.) return 1.;
  float b=mix(.0045,.0016,clamp(nl,0.,1.)), s=0.;
  for(int x=-2;x<=2;x++) for(int y=-2;y<=2;y++) s+=texture(uShadow, vec3(p.xy+vec2(x,y)/2048.*1.3, p.z-b));
  return s/25.;
}
vec3 shade(vec3 alb,float rough,float metal,vec3 emis,vec3 N,vec3 V,float sh,float ao){
  vec3 L=uLightDir, H=normalize(L+V);
  float nl=max(dot(N,L),0.), nv=max(dot(N,V),1e-3), nh=max(dot(N,H),0.), vh=max(dot(V,H),0.);
  vec3 F0=mix(vec3(.04),alb,metal);
  float a=rough*rough, a2=a*a, d=nh*nh*(a2-1.)+1., D=a2/(3.14159*d*d);
  float k=(rough+1.); k=k*k/8.;
  float G=(nl/(nl*(1.-k)+k))*(nv/(nv*(1.-k)+k));
  vec3 F=F0+(1.-F0)*pow(1.-vh,5.);
  vec3 col=((1.-F)*(1.-metal)*alb/3.14159 + min(D*G/(4.*nl*nv+1e-3),30.)*F)*LIGHT*nl*sh;
  vec3 hemi=mix(vec3(.10,.09,.10), vec3(.30,.32,.38), N.y*.5+.5);
  col+=alb*(1.-metal)*hemi*ao;
  vec3 Fe=F0+(max(vec3(1.-rough),F0)-F0)*pow(1.-nv,5.);
  col+=env(reflect(-V,N),rough)*Fe*ao;
  return col+emis;
}
vec3 aces(vec3 x){ x*=.74; return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.); }
vec3 finish(vec3 c){ return pow(aces(c),vec3(1./2.2)); }
`;

  const PIECE_FS = `${COMMON}
uniform int uSkin; uniform float uWhite, uAlpha, uSeed;
void main(){
  vec3 W=vW, N=normalize(vN), E=uEye;
  if(uMirror<0.){ W.y=-W.y; N.y=-N.y; E.y=-E.y; }
  vec3 V=normalize(E-W); vec3 p=vL+uSeed; float w=uWhite, t=uTime;
  float nv=max(dot(N,V),0.), rim=pow(1.-nv,2.6);
  vec3 alb=vec3(.5), em=vec3(0.); float rough=.3, metal=0.;
  if(uSkin==0){ float g=fbm(p*vec3(9.,3.,9.)); alb=mix(vec3(.055,.048,.046),vec3(.80,.74,.61),w)*(.9+.2*g); rough=mix(.2,.27,w); }
  else if(uSkin==1){ float v=fbm(p*2.6); float vein=smoothstep(0.,.10,abs(sin((p.x*1.3+p.y*1.7+p.z+v*2.6)*5.)));
    alb=mix(mix(vec3(.46,.46,.5),vec3(.085,.085,.095),vein), mix(vec3(.55,.52,.47),vec3(.93,.92,.88),vein), w); rough=.12; }
  else if(uSkin==2){ vec3 c=mix(vec3(1.,.22,.82),vec3(.25,.95,1.),w); alb=vec3(.015,.015,.03); rough=.22;
    float band=smoothstep(.93,1.,sin(vL.y*26.-t*2.4)*.5+.5);
    em=c*(rim*3.2+band*1.3+.12)*(.85+.15*sin(t*2.8)); }
  else if(uSkin==3){ float f=fbm(p*5.); alb=mix(vec3(.04,.26,.44),vec3(.72,.90,1.),w)*(.85+.3*f); rough=.07;
    float sp=step(.985,noise(p*46.+floor(t*3.)*.37));
    em=mix(vec3(.1,.45,.8),vec3(.45,.8,1.),w)*(rim*1.5+.06)+vec3(sp)*1.8; }
  else if(uSkin==4){ alb=mix(vec3(.50,.25,.07),vec3(1.,.77,.34),w); metal=1.; rough=.22+.08*noise(p*30.); }
  else if(uSkin==5){ float f=fbm(vec3(p.x*3.,p.y*3.-t*1.5,p.z*3.)); float h=clamp(vL.y*.9,0.,1.);
    if(w>.5){ alb=vec3(.55,.22,.05); em=mix(vec3(1.9,.5,.04),vec3(2.6,1.9,.55),smoothstep(.3,.75,f+h*.25))*(.55+.75*f); }
    else { alb=vec3(.045,.02,.018); float cr=smoothstep(.56,.5,abs(f-.5)*4.+.18); em=vec3(2.6,.5,.04)*smoothstep(.07,0.,abs(f-.5))*1.6+vec3(.5,.06,0.)*rim; }
    rough=.55; }
  else if(uSkin==6){ alb=mix(vec3(.03,.01,.07),vec3(.80,.77,.93),w); rough=.2;
    float pu=.6+.4*sin(t*2.2+uSeed); float sw=fbm(p*3.+vec3(0.,t*.4,0.));
    em=vec3(.5,.2,1.)*(rim*2.6*pu+smoothstep(.62,.8,sw)*mix(.9,.35,w)); }
  else if(uSkin==7){ vec3 q=p*2.2+vec3(t*.05,t*.03,0.); float n1=fbm(q), n2=fbm(q*1.7+4.);
    vec3 neb=mix(vec3(.25,.1,.7),vec3(.1,.6,.95),n1)+vec3(.9,.25,.6)*smoothstep(.5,.8,n2);
    float st=step(.992,hash(floor(p*38.)))*(.6+.4*sin(t*3.+hash(floor(p*38.))*40.));
    alb=mix(vec3(.02,.02,.07),vec3(.62,.6,.86),w); rough=.14; em=neb*mix(.5,.22,w)*(.4+n1)+vec3(st)*2.2+vec3(.4,.45,1.)*rim*.8; }
  else if(uSkin==8){ vec3 c=hsv(fract(vL.y*.55+t*.12+N.x*.12+N.z*.08),.85,1.); alb=mix(c*.42,mix(c,vec3(1.),.3),w); rough=.16; metal=.35; em=c*rim*mix(.9,.4,w); }
  else if(uSkin==9){ alb=mix(vec3(.012,.012,.018),vec3(.62,.63,.68),w); rough=.045; metal=mix(0.,.6,w); em=mix(vec3(.35,.2,.7),vec3(.6,.7,.9),w)*rim*.5; }
  else if(uSkin==10){ float f=fbm(p*4.); alb=mix(vec3(.01,.26,.14),vec3(.50,.92,.66),w)*(.8+.4*f); rough=.06;
    em=mix(vec3(.02,.7,.32),vec3(.3,1.,.6),w)*(rim*1.1+.05+.5*pow(max(dot(N,normalize(vec3(.3,.9,.3))),0.),18.)); }
  else { alb=mix(vec3(.23,.25,.30),vec3(.93,.94,.96),w); metal=1.; rough=.06; }
  float ao=mix(.5,1.,smoothstep(0.,.3,vL.y));
  float sh=uMirror<0.?1.:shadow(dot(N,uLightDir));
  vec3 col=shade(alb,rough,metal,em,N,V,sh,ao);
  if(uMirror<0.) col*=exp(-W.y*.95)*.9;
  o=vec4(finish(col)*uAlpha,uAlpha);
}`;

  const BOARD_FS = `${COMMON}
uniform int uKind, uBoard, uPN; uniform vec3 uLight, uDark, uFrame, uGlowW, uGlowB; uniform float uRefl;
uniform vec4 uP[32]; uniform sampler2D uFill, uFlags, uLabels;
void main(){
  vec3 N=normalize(vN), V=normalize(uEye-vW); float t=uTime;
  if(uKind==3){ o=vec4(finish(env(reflect(-V,N),.35)*.5+uFrame*.05),1.); return; }
  if(uKind==2){ float a=.5*smoothstep(5.25,4.55,max(abs(vW.x),abs(vW.z))); o=vec4(0.,0.,0.,a); return; }
  float sh=shadow(dot(N,uLightDir));
  if(uKind==1){
    vec3 alb=uFrame*(.8+.4*fbm(vec3(vW.x*1.2,vW.y*6.,vW.z*9.)));
    float rough=.32; vec3 em=vec3(0.);
    if(uBoard==4){ float e=smoothstep(.06,0.,abs(max(abs(vW.x),abs(vW.z))-4.05)); em=mix(vec3(.2,.9,1.),vec3(1.,.2,.85),.5+.5*sin(t+vW.x+vW.z))*e*2.2; }
    if(uBoard==7) rough=.08;
    if(N.y>.9){ vec4 lb=texture(uLabels, vW.xz/(2.*${OUT.toFixed(2)})+.5); alb=mix(alb,lb.rgb,lb.a*.92); }
    float inner=smoothstep(4.0,4.07,max(abs(vW.x),abs(vW.z)));
    vec3 col=shade(alb,rough,0.,em,N,V,sh,mix(.55,1.,inner));
    o=vec4(finish(col),1.); return;
  }
  vec2 q=vW.xz+4.; ivec2 c=clamp(ivec2(floor(q)),0,7); vec2 f=fract(q);
  int file=c.x, rank=7-c.y; bool dk=((file+rank)&1)==0; float d01=dk?1.:0.;
  vec3 seed=vec3(float(file)*3.1,float(rank)*5.7,0.);
  vec3 alb=dk?uDark:uLight; float rough=.26; vec3 em=vec3(0.);
  if(uBoard==0){ alb*=.93+.14*fbm(vec3(vW.x*2.,vW.z*14.,3.)+seed); }
  else if(uBoard==1){ vec3 l=vec3(.86,.70,.48), d=vec3(.33,.18,.085); float g=fbm(vec3(vW.x*1.4+seed.y,vW.z*22.,seed.x)); float r2=sin((vW.z*9.+g*5.)+seed.x)*.5+.5;
    alb=(dk?d:l)*(.78+.3*g+.12*r2); rough=.34; }
  else if(uBoard==2){ float v=fbm(vec3(vW.xz*1.1,d01*9.)); float vein=smoothstep(0.,.07,abs(sin((vW.x+vW.z*.6+v*3.)*3.)));
    alb=dk?mix(vec3(.80,.80,.84),vec3(.36,.38,.44),vein):mix(vec3(.62,.60,.57),vec3(.94,.93,.90),vein); rough=.07; }
  else if(uBoard==3){ float w1=fbm(vec3(vW.xz*1.6+vec2(t*.15,t*.1),t*.12)); float ca=pow(1.-abs(sin((w1*6.+vW.x*.8+t*.3))),6.);
    alb=dk?vec3(.05,.22,.50):vec3(.62,.84,.97); em=(dk?vec3(.15,.55,.9):vec3(.3,.5,.6))*ca*(dk?.55:.12); rough=.06; }
  else if(uBoard==4){ alb=dk?vec3(.035,.025,.09):vec3(.02,.018,.05); float e=min(min(f.x,1.-f.x),min(f.y,1.-f.y));
    vec3 lc=mix(vec3(.15,.9,1.),vec3(1.,.17,.82),.5+.5*sin(vW.x*.7+vW.z*.5+t*.8));
    em=lc*(smoothstep(.035,0.,e)*1.7+smoothstep(.3,0.,e)*.10*(dk?1.6:.6)); rough=.1; }
  else if(uBoard==5){ float n1=fbm(vec3(vW.xz*1.3,t*.12)); float cr=smoothstep(.05,0.,abs(n1-.5));
    alb=dk?vec3(.035,.016,.012):vec3(.13,.06,.04); em=vec3(2.4,.55,.05)*cr*(dk?.9:.3)*(.7+.3*sin(t*1.5+n1*20.))+vec3(.5,.08,0.)*smoothstep(.55,.9,n1)*(dk?.8:.2); rough=.6; }
  else if(uBoard==6){ vec3 qq=vec3(vW.xz*.55,t*.03); float n1=fbm(qq), n2=fbm(qq*2.+5.);
    alb=dk?vec3(.03,.025,.09):vec3(.10,.09,.24);
    vec2 g=floor(vW.xz*14.); float h=hash(vec3(g,1.)); float st=step(.955,h)*smoothstep(.45,.0,length(fract(vW.xz*14.)-.5))*(.5+.5*sin(t*2.5+h*60.));
    em=(mix(vec3(.2,.1,.6),vec3(.1,.45,.8),n1)*smoothstep(.45,.8,n2)*.55+vec3(st)*2.)*(dk?1.:.75); rough=.1; }
  else if(uBoard==7){ alb=dk?vec3(.22,.34,.48):vec3(.70,.80,.90); alb*=.9+.2*fbm(vec3(vW.xz*6.,d01)); rough=.035; em=vec3(.3,.5,.7)*smoothstep(.05,0.,min(min(f.x,1.-f.x),min(f.y,1.-f.y)))*.25; }
  else if(uBoard==8){ float pz=fbm(vec3(vW.xz*3.,d01*4.)); alb=dk?mix(vec3(.80,.40,.54),vec3(.92,.58,.68),pz):mix(vec3(.99,.90,.90),vec3(1.,.96,.94),pz); rough=.28; }
  else { float g=fbm(vec3(vW.xz*5.,d01)); alb=dk?vec3(.36,.035,.075)*(.75+.5*g):vec3(.92,.74,.40)*(.85+.3*g); rough=dk?.24:.2; }
  // Fugen
  float e=min(min(f.x,1.-f.x),min(f.y,1.-f.y)); alb*=mix(.72,1.,smoothstep(0.,.022,e));
  // Markierungen
  vec4 fl=texelFetch(uFill,ivec2(file,rank),0); alb=mix(alb,fl.rgb,fl.a); em*=1.-fl.a*.7;
  vec4 fg=texelFetch(uFlags,ivec2(file,rank),0); float r=length(f-.5);
  if(fg.r>.7){ float ring=smoothstep(.34,.37,r)*smoothstep(.47,.44,r); vec3 rc=fg.a>.5?vec3(1.,.67,0.):vec3(0.); alb=mix(alb,rc,ring*(fg.a>.5?.8:.34)); }
  else if(fg.r>.2){ float dt=smoothstep(.17,.145,r); vec3 rc=fg.a>.5?vec3(1.,.67,0.):vec3(0.); alb=mix(alb,rc,dt*(fg.a>.5?.8:.3)); }
  if(fg.g>.5){ float k=smoothstep(.62,.05,r); alb=mix(alb,vec3(1.,.12,.10),k*.9); em+=vec3(1.3,.08,.05)*k*(.55+.25*sin(t*4.)); }
  if(fg.b>.5){ float bd=smoothstep(.07,.055,e); alb=mix(alb,vec3(1.),bd*.75); em+=vec3(.35)*bd; }
  // Kontaktschatten und Leuchten der Figuren
  float ao=1.; vec3 glow=vec3(0.);
  for(int i=0;i<32;i++){ if(i>=uPN) break; float dd=length(vW.xz-uP[i].xy); ao*=1.-.42*smoothstep(uP[i].z*1.7,uP[i].z*.55,dd);
    glow+=(uP[i].w>.5?uGlowW:uGlowB)*exp(-dd*dd*4.5); }
  em+=glow*.5*(alb+.12);
  vec3 col=shade(alb,rough,0.,em,N,V,sh,ao);
  float nv=max(dot(N,V),0.); float a=1.-uRefl*(.55+.45*pow(1.-nv,3.));
  o=vec4(finish(col)*a,a);
}`;

  /* ------------------------------------------------------------------ Renderer */
  function create(boardEl, { onView, wheelZoom = true, frame: withFrame = true } = {}) {
    const canvas = document.createElement('canvas');
    canvas.className = 'board3d';
    const gl = canvas.getContext('webgl2', { antialias: true, alpha: true, premultipliedAlpha: true, stencil: true, powerPreference: 'high-performance' });
    if (!gl) return null;

    const compile = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || 'shader');
      return s;
    };
    const program = (vs, fs) => {
      const p = gl.createProgram();
      gl.attachShader(p, compile(gl.VERTEX_SHADER, vs));
      gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs));
      gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p) || 'link');
      const u = {};
      const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
      for (let i = 0; i < n; i += 1) {
        const name = gl.getActiveUniform(p, i).name.replace(/\[0\]$/, '');
        u[name] = gl.getUniformLocation(p, name);
      }
      return { p, u };
    };
    let progPiece, progBoard, progDepth;
    try {
      progPiece = program(VS, PIECE_FS);
      progBoard = program(VS, BOARD_FS);
      progDepth = program(VS, DEPTH_FS);
    } catch (error) {
      console.warn('3D-Brett nicht verfügbar:', error.message);
      return null;
    }

    const upload = (m) => {
      const vao = gl.createVertexArray();
      gl.bindVertexArray(vao);
      const data = new Float32Array((m.p.length / 3) * 6);
      for (let i = 0, k = 0; i < m.p.length; i += 3) {
        data[k++] = m.p[i];
        data[k++] = m.p[i + 1];
        data[k++] = m.p[i + 2];
        data[k++] = m.n[i];
        data[k++] = m.n[i + 1];
        data[k++] = m.n[i + 2];
      }
      gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 24, 0);
      gl.enableVertexAttribArray(1);
      gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 24, 12);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(m.i), gl.STATIC_DRAW);
      gl.bindVertexArray(null);
      return { vao, count: m.i.length };
    };
    const pieceGeo = buildPieces().map((m) => (m ? upload(m) : null));
    const bm = boardMeshes();
    const geoTop = upload(bm.top), geoFrame = upload(bm.frame), geoGround = upload(bm.ground);

    // Schatten-Textur
    const SH = 2048;
    const shadowTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, shadowTex);
    gl.texStorage2D(gl.TEXTURE_2D, 1, gl.DEPTH_COMPONENT24, SH, SH);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
    const shadowFb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, shadowFb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, shadowTex, 0);
    gl.drawBuffers([gl.NONE]);
    gl.readBuffer(gl.NONE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    const tex8 = () => {
      const tx = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tx);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 8, 8, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(256));
      return tx;
    };
    const fillTex = tex8(), flagTex = tex8();
    const fillData = new Uint8Array(256), flagData = new Uint8Array(256);
    const labelTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, labelTex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const aniso = gl.getExtension('EXT_texture_filter_anisotropic');
    if (aniso) gl.texParameterf(gl.TEXTURE_2D, aniso.TEXTURE_MAX_ANISOTROPY_EXT, 8);

    let labelKey = '';
    function drawLabels(color, flip) {
      const key = `${color}|${flip}`;
      if (key === labelKey) return;
      labelKey = key;
      const S = 1024, c = document.createElement('canvas');
      c.width = c.height = S;
      const g = c.getContext('2d');
      const px = (v) => (v / (2 * OUT) + 0.5) * S;
      g.fillStyle = color;
      g.font = `700 ${Math.round(S * 0.024)}px "Segoe UI", system-ui, sans-serif`;
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      const put = (text, x, z) => {
        g.save();
        g.translate(px(x), px(z));
        if (flip) g.rotate(PI);
        g.fillText(text, 0, 1);
        g.restore();
      };
      for (let k = 0; k < 8; k += 1) {
        put('abcdefgh'[k], k - 3.5, 4.26);
        put('abcdefgh'[k], k - 3.5, -4.26);
        put(String(k + 1), -4.26, 3.5 - k);
        put(String(k + 1), 4.26, 3.5 - k);
      }
      gl.bindTexture(gl.TEXTURE_2D, labelTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
      gl.generateMipmap(gl.TEXTURE_2D);
    }

    const colorCtx = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
    const colorCache = new Map();
    function rgba(css) {
      if (colorCache.has(css)) return colorCache.get(css);
      colorCtx.clearRect(0, 0, 1, 1);
      colorCtx.fillStyle = '#000';
      colorCtx.fillStyle = css;
      colorCtx.fillRect(0, 0, 1, 1);
      const d = colorCtx.getImageData(0, 0, 1, 1).data;
      const out = [d[0], d[1], d[2], d[3]];
      colorCache.set(css, out);
      return out;
    }
    const lin = (css) => rgba(css).slice(0, 3).map((v) => Math.pow(v / 255, 2.2));

    /* ---------------- Zustand */
    const st = { board: 'standard', light: '#ebecd0', dark: '#779556', flipped: false, sel: -1, hover: -1 };
    let inst = [];
    let active = false;
    let dirty = true;
    let raf = 0;
    let seedN = 1;
    const cam = { yaw: 0, yawBase: 0, yawOff: 0, pitch: 0.98, pitchT: 0.98, dist: 1, distT: 1, yawOffT: 0 };
    let VP = M4(), VPi = M4(), eye = [0, 10, 10];
    function M4() {
      return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
    }
    let drag = null;

    // Ecken des Bretts (mit Rahmen) und Spitzen der Figuren: müssen immer ins Bild passen
    const FIT = [];
    for (const x of [-OUT, OUT]) for (const z of [-OUT, OUT]) FIT.push([x, 0.02, z], [x, -0.42, z], [x * 0.78, 1.75, z * 0.78]);
    function build(d, yaw, pitch, asp) {
      const fov = (24 * PI) / 180;
      const cp = Math.cos(pitch), sp = Math.sin(pitch);
      const target = [0, 0.35, 0.1];
      const e = [target[0] + Math.sin(yaw) * cp * d, target[1] + sp * d, target[2] + Math.cos(yaw) * cp * d];
      const up = pitch > 1.5 ? [-Math.sin(yaw), 0, -Math.cos(yaw)] : [0, 1, 0];
      return { e, m: mul(persp(fov, asp, 1, 90), lookAt(e, target, up)) };
    }
    function updateCamera() {
      const yaw = cam.yaw + cam.yawOff;
      const pitch = Math.min(1.5607, cam.pitch + (cam.lift || 0));
      const asp = canvas.width / Math.max(1, canvas.height);
      // Abstand so wählen, dass beim Drehen keine Ecke abgeschnitten wird (Zoom des Nutzers kommt oben drauf)
      let base = 25.2;
      for (let k = 0; k < 3; k += 1) {
        const { m } = build(base, yaw, pitch, asp);
        let worst = 0;
        for (const [x, y, z] of FIT) {
          const c = xf(m, x, y, z);
          if (c[3] <= 0.1) continue;
          worst = Math.max(worst, Math.abs(c[0] / c[3]), Math.abs(c[1] / c[3]));
        }
        if (worst <= 0.94) break;
        base *= worst / 0.92;
      }
      cam.fit = cam.fit ? cam.fit + (base - cam.fit) * 0.35 : base;
      if (Math.abs(base - cam.fit) > 0.02) dirty = true; // weiter nachführen, bis es passt
      const { e, m } = build(cam.fit * cam.dist, yaw, pitch, asp);
      eye = e;
      VP = m;
      VPi = invert(VP) || VPi;
    }

    function ray(clientX, clientY) {
      const r = canvas.getBoundingClientRect();
      const nx = ((clientX - r.left) / r.width) * 2 - 1, ny = 1 - ((clientY - r.top) / r.height) * 2;
      const a = xf(VPi, nx, ny, -1), b = xf(VPi, nx, ny, 1);
      const o = [a[0] / a[3], a[1] / a[3], a[2] / a[3]], e = [b[0] / b[3], b[1] / b[3], b[2] / b[3]];
      return { o, d: [e[0] - o[0], e[1] - o[1], e[2] - o[2]] };
    }
    function hitPlane(clientX, clientY, h = 0) {
      const { o, d } = ray(clientX, clientY);
      if (Math.abs(d[1]) < 1e-6) return null;
      const t = (h - o[1]) / d[1];
      if (t < 0) return null;
      return [o[0] + d[0] * t, o[2] + d[2] * t];
    }
    function pick(clientX, clientY) {
      const p = hitPlane(clientX, clientY);
      if (!p) return -1;
      const f = Math.floor(p[0] + 4), r = Math.floor(4 - p[1]);
      if (f < 0 || f > 7 || r < 0 || r > 7) return -1;
      return r * 16 + f;
    }
    /** Brettpunkt → Position relativ zum Brett-Element (0…1). */
    function project(sq, h = 0) {
      const [x, z] = sqXZ(sq);
      const c = xf(VP, x, h, z);
      const cr = canvas.getBoundingClientRect(), br = boardEl.getBoundingClientRect();
      const px = cr.left + ((c[0] / c[3]) * 0.5 + 0.5) * cr.width, py = cr.top + (0.5 - (c[1] / c[3]) * 0.5) * cr.height;
      return { x: (px - br.left) / br.width, y: (py - br.top) / br.height };
    }

    /* ---------------- Figuren-Instanzen */
    const mk = (pc, sq) => {
      const [x, z] = sqXZ(sq);
      return { type: pc.type, white: pc.white, skin: pc.skin, sq, x, z, y: 0, lift: 0, tw: null, born: 0, die: 0, seed: (seedN++ * 1.37) % 9 };
    };
    function tweenTo(it, sq, { dur = 270, hop } = {}) {
      const [x, z] = sqXZ(sq);
      const dist = Math.hypot(x - it.x, z - it.z);
      it.sq = sq;
      if (dist < 0.01) return;
      it.tw = { x0: it.x, z0: it.z, y0: it.y, x1: x, z1: z, t0: performance.now(), dur: dur + dist * 14, hop: hop ?? (it.type === 2 ? 0.85 : Math.min(0.32, 0.1 + dist * 0.04)) };
    }

    function sync(s) {
      Object.assign(st, { board: s.board, light: s.light, dark: s.dark, sel: s.sel });
      if (s.flipped !== st.flipped || cam.first !== false) {
        st.flipped = s.flipped;
        cam.yawBase = s.flipped ? PI : 0;
        if (cam.first !== false) cam.yaw = cam.yawBase;
        else cam.flip = { from: cam.yaw, to: cam.yawBase, t0: performance.now() };
        cam.first = false;
      }
      const now = performance.now();
      const want = new Map(s.pieces.map((p) => [p.sq, p]));
      const alive = inst.filter((i) => !i.die);
      const used = new Set();
      const open = [];
      for (const it of alive) {
        const w = want.get(it.sq);
        if (w && w.type === it.type && w.white === it.white && !used.has(it.sq)) {
          used.add(it.sq);
          it.skin = w.skin;
          it.keep = true;
          if (!it.tw && it !== drag?.it) {
            const [x, z] = sqXZ(it.sq);
            if (Math.hypot(x - it.x, z - it.z) > 0.01) tweenTo(it, it.sq, { dur: 160, hop: 0.05 });
          }
        } else {
          it.keep = false;
          open.push(it);
        }
      }
      const missing = s.pieces.filter((p) => !used.has(p.sq));
      const bulk = missing.length > 4 || !inst.length;
      for (const p of missing) {
        let best = null, bd = 1e9;
        if (!bulk)
          for (const it of open) {
            if (it.keep || it.type !== p.type || it.white !== p.white) continue;
            const [x, z] = sqXZ(p.sq);
            const d = Math.hypot(x - it.x, z - it.z);
            if (d < bd) {
              bd = d;
              best = it;
            }
          }
        if (best) {
          best.keep = true;
          best.skin = p.skin;
          tweenTo(best, p.sq);
        } else {
          const it = mk(p, p.sq);
          it.keep = true;
          if (!bulk) it.born = now;
          inst.push(it);
        }
      }
      for (const it of open) if (!it.keep) it.die = bulk ? now - 1000 : now;
      if (bulk) inst = inst.filter((i) => !i.die);

      // Markierungen
      fillData.fill(0);
      flagData.fill(0);
      const at = (sq) => ((sq >> 4) * 8 + (sq & 7)) * 4;
      const blend = (sq, c, alpha) => {
        const k = at(sq), a0 = fillData[k + 3] / 255, a1 = alpha, a = a1 + a0 * (1 - a1);
        for (let j = 0; j < 3; j += 1) fillData[k + j] = a ? (c[j] * a1 + fillData[k + j] * a0 * (1 - a1)) / a : 0;
        fillData[k + 3] = a * 255;
      };
      const srgbLin = (c) => c.map((v) => Math.pow(v / 255, 2.2) * 255);
      for (const sq of s.last || []) blend(sq, srgbLin([255, 240, 60]), 0.5);
      for (const [sq, color] of s.marks || []) {
        const c = rgba(color);
        blend(sq, srgbLin(c), Math.min(0.8, (c[3] / 255) * 0.75));
      }
      if (s.sel >= 0) blend(s.sel, srgbLin([70, 190, 90]), 0.6);
      for (const [sq, cap, plan] of s.dots || []) {
        flagData[at(sq)] = cap ? 255 : 128;
        flagData[at(sq) + 3] = plan ? 255 : 0;
      }
      if (s.check >= 0) flagData[at(s.check) + 1] = 255;
      if (st.hover >= 0) flagData[at(st.hover) + 2] = 255;
      gl.bindTexture(gl.TEXTURE_2D, fillTex);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, 8, 8, gl.RGBA, gl.UNSIGNED_BYTE, fillData);
      gl.bindTexture(gl.TEXTURE_2D, flagTex);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, 8, 8, gl.RGBA, gl.UNSIGNED_BYTE, flagData);
      dirty = true;
      kick();
    }

    function setHover(sq) {
      if (sq === st.hover) return;
      const at = (q) => ((q >> 4) * 8 + (q & 7)) * 4;
      if (st.hover >= 0) flagData[at(st.hover) + 2] = 0;
      st.hover = sq;
      if (sq >= 0) flagData[at(sq) + 2] = 255;
      gl.bindTexture(gl.TEXTURE_2D, flagTex);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, 8, 8, gl.RGBA, gl.UNSIGNED_BYTE, flagData);
      dirty = true;
      kick();
    }

    /** Zug animieren, bevor die Stellung wechselt. */
    function moveAnim({ from, to, castle, ep }) {
      const now = performance.now();
      const find = (sq) => inst.find((i) => !i.die && i.sq === sq);
      const mover = find(from);
      if (!mover) return;
      for (const sq of [to, ep]) {
        const victim = sq >= 0 && sq != null ? find(sq) : null;
        if (victim && victim !== mover) victim.die = now + 130;
      }
      tweenTo(mover, to);
      if (castle) {
        const rook = find(castle[0]);
        if (rook) tweenTo(rook, castle[1], { hop: 0.5 });
      }
      dirty = true;
      kick();
    }

    function dragStart(sq) {
      const it = inst.find((i) => !i.die && i.sq === sq);
      if (!it) return;
      drag = { it };
      it.tw = null;
      kick();
    }
    function dragMove(clientX, clientY) {
      if (!drag) return;
      const p = hitPlane(clientX, clientY, 0.42);
      if (!p) return;
      drag.it.x = Math.max(-4.6, Math.min(4.6, p[0]));
      drag.it.z = Math.max(-4.6, Math.min(4.6, p[1]));
      drag.moved = true;
      dirty = true;
      kick();
    }
    /** Loslassen: mit Zielfeld gleitet die Figur dorthin, sonst zurück. */
    function dragEnd(to = -1) {
      if (!drag) return;
      const it = drag.it;
      drag = null;
      const now = performance.now();
      if (to >= 0) {
        const victim = inst.find((i) => !i.die && i.sq === to && i !== it);
        if (victim) victim.die = now;
      }
      tweenTo(it, to >= 0 ? to : it.sq, { dur: 110, hop: 0 });
      dirty = true;
      kick();
    }

    /* ---------------- Kamera-Steuerung */
    let orbit = null;
    canvas.addEventListener('pointerdown', (e) => {
      const off = pick(e.clientX, e.clientY) < 0;
      if (e.button === 1 || (e.button === 0 && off)) {
        orbit = { x: e.clientX, y: e.clientY, yaw: cam.yawOffT, pitch: cam.pitchT };
        canvas.setPointerCapture(e.pointerId);
        canvas.classList.add('orbiting');
        e.preventDefault();
        if (e.button === 1) e.stopPropagation();
      }
    });
    canvas.addEventListener('pointermove', (e) => {
      if (!orbit) return;
      cam.yawOffT = orbit.yaw - (e.clientX - orbit.x) * 0.0075;
      cam.pitchT = Math.max(0.3, Math.min(1.5607, orbit.pitch + (e.clientY - orbit.y) * 0.006));
      kick();
    });
    const endOrbit = (e) => {
      if (!orbit) return;
      orbit = null;
      canvas.classList.remove('orbiting');
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch {}
    };
    canvas.addEventListener('pointerup', endOrbit);
    canvas.addEventListener('pointercancel', endOrbit);
    canvas.addEventListener('wheel', (e) => {
      if (!wheelZoom && !e.ctrlKey) return; // z. B. auf der Website: Seite scrollt normal weiter
      e.preventDefault();
      cam.distT = Math.max(0.62, Math.min(1.35, cam.distT * (e.deltaY > 0 ? 1.07 : 0.935)));
      kick();
    }, { passive: false });
    canvas.addEventListener('dblclick', (e) => {
      if (pick(e.clientX, e.clientY) < 0) view('reset');
    });
    function view(name) {
      if (name === 'top') {
        cam.pitchT = cam.pitchT > 1.5 ? 0.98 : 1.5607;
        cam.yawOffT = 0;
      } else if (name === 'side') {
        cam.yawOffT = Math.abs(cam.yawOffT - PI / 2) < 0.05 ? -PI / 2 : PI / 2;
        cam.pitchT = 0.7;
      } else if (name === 'low') {
        cam.pitchT = 0.48;
        cam.yawOffT = 0.5;
      } else {
        cam.pitchT = 0.98;
        cam.yawOffT = 0;
        cam.distT = 1;
      }
      kick();
    }

    /* ---------------- Zeichnen */
    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(2, Math.round(canvas.clientWidth * dpr)), h = Math.max(2, Math.round(canvas.clientHeight * dpr));
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
        return true;
      }
      return false;
    }

    function step(now) {
      let moving = false;
      // Kamera weich nachführen
      const near = (a, b) => Math.abs(a - b) < 0.0006;
      cam.lift = 0;
      if (cam.flip) {
        const t = Math.min(1, (now - cam.flip.t0) / 950);
        const e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        cam.yaw = cam.flip.from + (cam.flip.to - cam.flip.from) * e;
        cam.lift = Math.sin(Math.PI * t) * 0.16; // beim Drehen leicht anheben – wirkt wie eine Kamerafahrt
        moving = true;
        if (t >= 1) {
          cam.flip = null;
          cam.yaw = cam.yawBase;
        }
      } else cam.yaw = cam.yawBase;
      for (const [k, tgt] of [['yawOff', 'yawOffT'], ['pitch', 'pitchT'], ['dist', 'distT']]) {
        if (!near(cam[k], cam[tgt])) {
          cam[k] += (cam[tgt] - cam[k]) * 0.2;
          moving = true;
        } else cam[k] = cam[tgt];
      }
      let animating = false;
      for (const it of inst) {
        if (it.tw) {
          const t = Math.min(1, (now - it.tw.t0) / it.tw.dur), e = ease(t);
          it.x = it.tw.x0 + (it.tw.x1 - it.tw.x0) * e;
          it.z = it.tw.z0 + (it.tw.z1 - it.tw.z0) * e;
          it.y = it.tw.y0 * (1 - e) + Math.sin(PI * t) * it.tw.hop;
          if (t >= 1) {
            it.tw = null;
            it.y = 0;
          }
          animating = true;
        }
        const liftT = it === drag?.it ? 0.42 : it.sq === st.sel && !it.tw && !it.die ? 0.13 : 0;
        if (Math.abs(it.lift - liftT) > 0.002) {
          it.lift += (liftT - it.lift) * 0.28;
          animating = true;
        } else it.lift = liftT;
        if (it.born && now - it.born < 260) animating = true;
        if (it.die) animating = true;
      }
      inst = inst.filter((i) => !i.die || now - i.die < 240);
      return { moving, animating };
    }

    function drawPieces(prog, { depth = false, mirror = 1, fading = false, now = 0 } = {}) {
      const u = prog.u;
      let lastGeo = null;
      for (const it of inst) {
        let alpha = 1, scale = 1;
        if (it.die) {
          const k = Math.max(0, Math.min(1, (now - it.die) / 220));
          if (now < it.die) alpha = 1;
          else {
            alpha = 1 - k;
            scale = 1 - 0.35 * k;
          }
        } else if (it.born) {
          const k = Math.min(1, (now - it.born) / 240);
          scale = 0.4 + 0.6 * (1 - Math.pow(1 - k, 3));
          alpha = k;
          if (k >= 1) it.born = 0;
        }
        if (!depth && fading !== alpha < 0.999) continue;
        if (depth && alpha < 0.5) continue;
        const rot = it.type === 2 ? (it.white ? PI - 0.5 : -0.5) : 0;
        gl.uniformMatrix4fv(u.uModel, false, trs(it.x, it.y + it.lift, it.z, rot, scale * 1.1));
        if (!depth) {
          gl.uniform1i(u.uSkin, Math.max(0, SKINS.indexOf(it.skin)));
          gl.uniform1f(u.uWhite, it.white ? 1 : 0);
          gl.uniform1f(u.uAlpha, alpha);
          gl.uniform1f(u.uSeed, it.seed);
        }
        const geo = pieceGeo[it.type];
        if (geo !== lastGeo) {
          gl.bindVertexArray(geo.vao);
          lastGeo = geo;
        }
        gl.drawElements(gl.TRIANGLES, geo.count, gl.UNSIGNED_INT, 0);
      }
    }

    const t0 = performance.now();
    function frame(now) {
      raf = 0;
      if (!active || !canvas.isConnected) return;
      const resized = resize();
      const { moving, animating } = step(now);
      const animatedLook = !document.hidden && (['ocean', 'neon', 'lava', 'cosmos'].includes(st.board) || inst.some((i) => ['neon', 'ice', 'fire', 'void', 'galaxy', 'rainbow'].includes(i.skin)) || flagData.some((v, k) => k % 4 === 1 && v));
      if (!(dirty || resized || moving || animating || animatedLook || drag)) return;
      dirty = false;
      updateCamera();
      if (moving || resized) onView?.();
      const time = (now - t0) / 1000;
      const info = BOARD_INFO[st.board] || BOARD_INFO.standard;
      drawLabels(info.label, st.flipped);

      // Licht dreht mit der Grundansicht mit (nicht mit der freien Kamera)
      const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
      const L0 = norm([-0.6, 0.95, 0.2]);
      const L = [L0[0] * cy + L0[2] * sy, L0[1], -L0[0] * sy + L0[2] * cy];
      const lightVP = mul(ortho(-7.2, 7.2, -7.2, 7.2, 1, 40), lookAt([L[0] * 18, L[1] * 18, L[2] * 18], [0, 0, 0], [0, 1, 0]));

      // 1) Schatten
      gl.bindFramebuffer(gl.FRAMEBUFFER, shadowFb);
      gl.viewport(0, 0, SH, SH);
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
      gl.disable(gl.STENCIL_TEST);
      gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.FRONT);
      gl.useProgram(progDepth.p);
      gl.uniformMatrix4fv(progDepth.u.uVP, false, lightVP);
      gl.uniformMatrix4fv(progDepth.u.uLightVP, false, lightVP);
      gl.uniform1f(progDepth.u.uMirror, 1);
      drawPieces(progDepth, { depth: true, now });
      gl.cullFace(gl.BACK);

      // 2) Bild
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.clearColor(0, 0, 0, 0);
      gl.clearStencil(0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, shadowTex);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, fillTex);
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, flagTex);
      gl.activeTexture(gl.TEXTURE3);
      gl.bindTexture(gl.TEXTURE_2D, labelTex);

      const common = (prog, mirror = 1) => {
        const u = prog.u;
        gl.useProgram(prog.p);
        gl.uniformMatrix4fv(u.uVP, false, VP);
        gl.uniformMatrix4fv(u.uLightVP, false, lightVP);
        gl.uniform3fv(u.uEye, eye);
        gl.uniform3fv(u.uLightDir, L);
        gl.uniform2f(u.uYaw, sy, cy);
        gl.uniform1f(u.uTime, time);
        gl.uniform1f(u.uMirror, mirror);
        gl.uniform1i(u.uShadow, 0);
      };
      const boardUniforms = (kind) => {
        const u = progBoard.u;
        gl.uniform1i(u.uKind, kind);
        gl.uniform1i(u.uBoard, Math.max(0, BOARDS.indexOf(st.board)));
        gl.uniform3fv(u.uLight, lin(st.light));
        gl.uniform3fv(u.uDark, lin(st.dark));
        gl.uniform3fv(u.uFrame, info.frame);
        gl.uniform1f(u.uRefl, info.refl);
        gl.uniform1i(u.uFill, 1);
        gl.uniform1i(u.uFlags, 2);
        gl.uniform1i(u.uLabels, 3);
        gl.uniformMatrix4fv(u.uModel, false, M4());
      };
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);

      // Schatten unter dem Brett
      common(progBoard);
      if (withFrame) {
        boardUniforms(2);
        gl.depthMask(false);
        gl.bindVertexArray(geoGround.vao);
        gl.drawElements(gl.TRIANGLES, geoGround.count, gl.UNSIGNED_INT, 0);
        gl.depthMask(true);
      }

      // Spiegelung: nur dort, wo die Brettoberfläche ist
      gl.enable(gl.STENCIL_TEST);
      gl.stencilFunc(gl.ALWAYS, 1, 0xff);
      gl.stencilOp(gl.KEEP, gl.KEEP, gl.REPLACE);
      gl.depthMask(false);
      boardUniforms(3); // deckender Untergrund, damit das Brett nie durchscheint
      gl.bindVertexArray(geoTop.vao);
      gl.drawElements(gl.TRIANGLES, geoTop.count, gl.UNSIGNED_INT, 0);
      gl.depthMask(true);
      gl.stencilFunc(gl.EQUAL, 1, 0xff);
      gl.stencilOp(gl.KEEP, gl.KEEP, gl.KEEP);
      gl.frontFace(gl.CW);
      common(progPiece, -1);
      drawPieces(progPiece, { now });
      gl.frontFace(gl.CCW);
      gl.disable(gl.STENCIL_TEST);
      gl.clear(gl.DEPTH_BUFFER_BIT);

      // Brett
      common(progBoard);
      boardUniforms(0);
      const glowOf = (white) => {
        const skin = inst.find((i) => i.white === white && !i.die)?.skin;
        return SKIN_GLOW[skin]?.[white ? 0 : 1] || [0, 0, 0];
      };
      gl.uniform3fv(progBoard.u.uGlowW, glowOf(true));
      gl.uniform3fv(progBoard.u.uGlowB, glowOf(false));
      const pv = new Float32Array(32 * 4);
      let pn = 0;
      for (const it of inst) {
        if (pn >= 32 || it.die) continue;
        const air = Math.max(0, 1 - (it.y + it.lift) * 1.6);
        pv.set([it.x, it.z, (it.type === 1 ? 0.3 : 0.36) * (0.4 + 0.6 * air), it.white ? 1 : 0], pn * 4);
        pn += 1;
      }
      gl.uniform4fv(progBoard.u.uP, pv);
      gl.uniform1i(progBoard.u.uPN, pn);
      gl.bindVertexArray(geoTop.vao);
      gl.drawElements(gl.TRIANGLES, geoTop.count, gl.UNSIGNED_INT, 0);
      if (withFrame) {
        boardUniforms(1);
        gl.bindVertexArray(geoFrame.vao);
        gl.drawElements(gl.TRIANGLES, geoFrame.count, gl.UNSIGNED_INT, 0);
      }

      // Figuren
      common(progPiece);
      drawPieces(progPiece, { now });
      gl.depthMask(false);
      drawPieces(progPiece, { now, fading: true });
      gl.depthMask(true);
      gl.bindVertexArray(null);
      kick();
    }
    function kick() {
      if (!raf && active) raf = requestAnimationFrame(frame);
    }

    boardEl.appendChild(canvas);
    new ResizeObserver(() => {
      dirty = true;
      kick();
    }).observe(canvas);
    document.addEventListener('visibilitychange', () => {
      dirty = true;
      kick();
    });

    return {
      canvas,
      setActive(on) {
        active = on;
        canvas.hidden = !on;
        if (on) {
          dirty = true;
          kick();
        }
      },
      sync,
      setHover,
      pick,
      project,
      move: moveAnim,
      dragStart,
      dragMove,
      dragEnd,
      view,
      height: (type) => (HEIGHT[type] || 1) * 1.1,
      cam,
    };
  }

  window.Board3D = { create, SKINS, BOARDS };
})();
