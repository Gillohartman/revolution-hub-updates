'use strict';

/*
 * Echte Spiel-FPS mit Intel PresentMon (MIT-Lizenz, ~1 MB). Windows gibt die Bildrate eines
 * Spiels nur über ETW-Ereignisse heraus – dafür braucht PresentMon Admin-Rechte oder die
 * Gruppe „Leistungsprotokollbenutzer“ (S-1-5-32-559). Die Einrichtung trägt den eigenen
 * Benutzer einmalig dort ein (Windows fragt per UAC); danach einmal ab- und anmelden.
 */
const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');
const { net } = require('electron');

const URL = 'https://github.com/GameTechDev/PresentMon/releases/download/v2.6.0/PresentMon-2.6.0-x64.exe';

class GameFps {
  constructor({ dir, onChange }) {
    this.exe = path.join(dir, 'presentmon', 'PresentMon.exe');
    this.onChange = onChange || (() => {});
    this.proc = null;
    this.target = '';
    this.frames = []; // [Zeitpunkt, ms zwischen Bildern]
    this.fps = 0;
    this.at = 0;
    this.permission = 'unknown'; // unknown | ok | denied
    this.busy = '';
    this.error = '';
  }

  status() {
    return { installed: fs.existsSync(this.exe), permission: this.permission, running: Boolean(this.proc), target: this.target, fps: this.live() ? this.fps : 0, busy: this.busy, error: this.error };
  }

  live() {
    return this.fps > 0 && Date.now() - this.at < 2500;
  }

  async install() {
    if (fs.existsSync(this.exe)) return true;
    this.busy = 'download';
    this.onChange(this.status());
    try {
      fs.mkdirSync(path.dirname(this.exe), { recursive: true });
      const res = await net.fetch(URL);
      if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 100000 || buf[0] !== 0x4d || buf[1] !== 0x5a) throw new Error('Download ist keine gültige Programmdatei');
      fs.writeFileSync(`${this.exe}.tmp`, buf);
      fs.renameSync(`${this.exe}.tmp`, this.exe);
      return true;
    } catch (error) {
      this.error = error.message || String(error);
      return false;
    } finally {
      this.busy = '';
      this.onChange(this.status());
    }
  }

  /** SID des angemeldeten Benutzers (für die Gruppen-Freigabe). */
  sid() {
    return new Promise((resolve) => {
      execFile('whoami', ['/user', '/fo', 'csv', '/nh'], { windowsHide: true }, (_e, out) => resolve(/"(S-1-[\d-]+)"/.exec(String(out || ''))?.[1] || ''));
    });
  }

  /** Einmalig: Benutzer in „Leistungsprotokollbenutzer“ eintragen (Windows fragt per UAC). */
  async grant() {
    const sid = await this.sid();
    if (!sid) throw new Error('Benutzer konnte nicht ermittelt werden');
    this.busy = 'grant';
    this.onChange(this.status());
    const inner = `try { Add-LocalGroupMember -SID 'S-1-5-32-559' -Member '${sid}' -ErrorAction Stop } catch { if ($_.Exception.Message -notmatch 'already|bereits') { exit 1 } }`;
    const encoded = Buffer.from(inner, 'utf16le').toString('base64');
    const outer = `$p = Start-Process powershell -Verb RunAs -WindowStyle Hidden -Wait -PassThru -ArgumentList '-NoProfile','-EncodedCommand','${encoded}'; exit $p.ExitCode`;
    const code = await new Promise((resolve) => {
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', outer], { windowsHide: true, timeout: 120000 }, (e) => resolve(e ? e.code || 1 : 0));
    });
    this.busy = '';
    if (code !== 0) {
      this.error = 'Freigabe abgebrochen oder abgelehnt.';
      this.onChange(this.status());
      return false;
    }
    this.error = '';
    this.permission = 'pending'; // gilt nach dem nächsten Anmelden
    this.onChange(this.status());
    return true;
  }

  /** Bildrate eines Prozesses messen (z. B. FortniteClient-Win64-Shipping.exe). */
  start(processName) {
    if (!fs.existsSync(this.exe) || this.permission === 'denied') return;
    if (this.proc && this.target === processName) return;
    if (!this.proc && Date.now() - (this.exitAt || 0) < 15000) return; // nach Absturz kurz warten
    this.stop();
    this.target = processName;
    this.frames = [];
    let header = null, col = -1, buf = '', err = '';
    const args = ['--process_name', processName, '--output_stdout', '--no_console_stats', '--stop_existing_session', '--session_name', 'RevulutionFPS', '--v1_metrics', '--terminate_on_proc_exit'];
    const proc = spawn(this.exe, args, { windowsHide: true });
    this.proc = proc;
    proc.stdout.on('data', (d) => {
      buf += d.toString();
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (!line) continue;
        const cells = line.split(',');
        if (!header) {
          if (!/Application/i.test(line)) continue;
          header = cells.map((c) => c.trim());
          col = header.findIndex((c) => /^MsBetweenPresents$/i.test(c));
          if (col < 0) col = header.findIndex((c) => /^(FrameTime|MsBetweenAppStart)$/i.test(c));
          continue;
        }
        const ms = Number(cells[col]);
        if (!(ms > 0 && ms < 1000)) continue;
        const now = Date.now();
        this.frames.push([now, ms]);
        // gleitender Mittelwert über die letzte Sekunde
        while (this.frames.length && now - this.frames[0][0] > 1000) this.frames.shift();
        const avg = this.frames.reduce((a, f) => a + f[1], 0) / this.frames.length;
        this.fps = Math.round(1000 / avg);
        this.at = now;
        if (this.permission !== 'ok') {
          this.permission = 'ok';
          this.onChange(this.status());
        }
      }
    });
    proc.stderr.on('data', (d) => (err += d.toString()));
    proc.on('error', () => {});
    proc.on('exit', (code) => {
      if (this.proc !== proc) return; // schon ersetzt oder gestoppt
      this.proc = null;
      this.exitAt = Date.now();
      const noRight = /access|denied|zugriff|privilege|administrat|Performance Log/i.test(err);
      if (code && noRight) this.permission = 'denied';
      if (code && !noRight) this.error = err.split('\n').find((l) => l.trim()) || '';
      this.onChange(this.status());
    });
  }

  stop() {
    try {
      this.proc?.kill();
    } catch {
      /* egal */
    }
    this.proc = null;
    this.target = '';
    this.fps = 0;
  }

  /** Nach dem Ab-/Anmelden nochmals versuchen. */
  retry() {
    if (this.permission === 'denied' || this.permission === 'pending') this.permission = 'unknown';
    this.error = '';
    this.exitAt = 0;
  }
}

module.exports = { GameFps };
