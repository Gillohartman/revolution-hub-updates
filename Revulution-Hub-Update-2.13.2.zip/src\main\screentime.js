'use strict';

/*
 * Bildschirmzeit wie am iPhone: welche App im Vordergrund ist (alle 5 s), wie lange,
 * zu welcher Stunde, nach Kategorie – nur solange jemand am PC ist (2 Minuten ohne
 * Eingabe zählen nicht). Daten liegen nur auf diesem PC (screentime.json, 60 Tage).
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type @"
using System; using System.Runtime.InteropServices;
public static class Fg {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [StructLayout(LayoutKind.Sequential)] public struct LII { public uint cbSize; public uint dwTime; }
  [DllImport("user32.dll")] public static extern bool GetLastInputInfo(ref LII p);
  public static uint Idle() { var l = new LII(); l.cbSize = (uint)Marshal.SizeOf(l); GetLastInputInfo(ref l); return ((uint)Environment.TickCount - l.dwTime) / 1000; }
}
"@
$names = @{}
while ($true) {
  $h = [Fg]::GetForegroundWindow(); $p = 0; [void][Fg]::GetWindowThreadProcessId($h, [ref]$p)
  $exe = ''; $desc = ''
  if ($p -gt 0) {
    $proc = Get-Process -Id $p
    if ($proc) {
      $exe = $proc.ProcessName
      if (-not $names.ContainsKey($exe)) { $d = ''; try { $d = $proc.MainModule.FileVersionInfo.FileDescription } catch {}; $names[$exe] = $d }
      $desc = $names[$exe]
    }
  }
  $o = @{ exe = $exe; name = $desc; idle = [Fg]::Idle() } | ConvertTo-Json -Compress
  [Console]::Out.WriteLine($o); [Console]::Out.Flush()
  Start-Sleep -Seconds 5
}`;

// Kategorien wie beim iPhone (nach Programmname)
const CATS = [
  ['games', 'Spiele', '#f97316', /fortnite|minecraft|javaw|valorant|leagueclient|league of legends|cs2|csgo|roblox|steam|epicgameslauncher|battle\.net|rocketleague|gta|overwatch|apex|eldenring|genshin|lunarclient|revolution launcher|prismlauncher/i],
  ['social', 'Soziale Netzwerke', '#38bdf8', /discord|whatsapp|telegram|signal|slack|teams|zoom|skype|instagram|tiktok|snapchat/i],
  ['web', 'Internet', '#a78bfa', /chrome|msedge|firefox|opera|brave|vivaldi|revolution browser|arc/i],
  ['creative', 'Kreativität', '#f472b6', /photoshop|premiere|aftereffects|davinci|resolve|obs64|obs|blender|figma|capcut|audacity|gimp|krita|paint/i],
  ['productivity', 'Produktivität', '#34d399', /code|devenv|winword|excel|powerpnt|onenote|outlook|notepad|notion|obsidian|acrobat|explorer|claude|cursor|idea64|pycharm/i],
  ['entertainment', 'Unterhaltung', '#facc15', /spotify|vlc|netflix|primevideo|disney|youtube|music|itunes|twitch/i],
];
const catOf = (exe, name) => {
  const s = `${exe} ${name}`;
  if (/revolution hub|revulution hub/i.test(s)) return 'hub';
  for (const [id, , , re] of CATS) if (re.test(s)) return id;
  return 'other';
};
const CAT_INFO = Object.fromEntries([...CATS.map(([id, n, c]) => [id, { name: n, color: c }]), ['hub', { name: 'Revulution Hub', color: '#8b6cff' }], ['other', { name: 'Andere', color: '#94a3b8' }]]);
const IGNORE = /^(idle|lockapp|searchhost|shellexperiencehost|startmenuexperiencehost|applicationframehost|textinputhost|screenclippinghost)$/i;
const dayKey = (t = new Date()) => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;

class ScreenTime {
  constructor({ dir, notify, getSettings }) {
    this.file = path.join(dir, 'screentime.json');
    this.notify = notify;
    this.getSettings = getSettings || (() => ({}));
    this.data = { days: {}, names: {} };
    this.last = 0;
    this.away = true;
    try {
      this.data = { days: {}, names: {}, ...JSON.parse(fs.readFileSync(this.file, 'utf8')) };
    } catch {
      /* erster Start */
    }
    this.dirty = false;
  }

  start() {
    if (process.platform !== 'win32' || this.proc) return;
    const encoded = Buffer.from(SCRIPT, 'utf16le').toString('base64');
    this.proc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true });
    let buf = '';
    this.proc.stdout.on('data', (d) => {
      buf += d.toString();
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (line.startsWith('{')) {
          try {
            this.tick(JSON.parse(line));
          } catch {
            /* ungültige Zeile */
          }
        }
      }
    });
    this.proc.on('exit', () => {
      this.proc = null;
      // neu starten, falls es abgestürzt ist
      if (!this.stopped) setTimeout(() => this.start(), 15000);
    });
    this.saveTimer = setInterval(() => this.save(), 60000);
  }

  stop() {
    this.stopped = true;
    clearInterval(this.saveTimer);
    try {
      this.proc?.kill();
    } catch {
      /* egal */
    }
    this.save();
  }

  tick({ exe, name, idle }) {
    const now = Date.now();
    const gap = this.last ? Math.min(15, Math.round((now - this.last) / 1000)) : 5;
    this.last = now;
    const active = Number(idle) < 120 && exe && !IGNORE.test(exe);
    const d = (this.data.days[dayKey()] ||= { total: 0, apps: {}, hours: Array(24).fill(0), pickups: 0, first: 0, notified: false });
    if (!active) {
      this.away = true;
      return;
    }
    if (this.away) {
      d.pickups += 1; // wieder an den PC gekommen
      this.away = false;
    }
    if (!d.first) d.first = now;
    d.total += gap;
    d.apps[exe] = (d.apps[exe] || 0) + gap;
    d.hours[new Date().getHours()] += gap;
    if (name && !this.data.names[exe]) this.data.names[exe] = String(name).slice(0, 60);
    this.dirty = true;
    // Tageslimit: Hinweis in der Island
    const limit = Number(this.getSettings().screentimeLimit) || 0;
    if (limit && !d.notified && d.total >= limit * 60) {
      d.notified = true;
      this.notify?.('Tageslimit erreicht', `Du warst heute schon ${Math.round(d.total / 60)} Minuten am PC.`);
    }
  }

  save() {
    if (!this.dirty) return;
    this.dirty = false;
    // nur 60 Tage behalten
    const keys = Object.keys(this.data.days).sort();
    for (const k of keys.slice(0, Math.max(0, keys.length - 60))) delete this.data.days[k];
    try {
      fs.writeFileSync(`${this.file}.tmp`, JSON.stringify(this.data));
      fs.renameSync(`${this.file}.tmp`, this.file);
    } catch {
      /* egal */
    }
  }

  /** Übersicht für die App: heute, Woche, Kategorien, Apps. */
  summary(day = dayKey()) {
    const names = this.data.names;
    const label = (exe) => names[exe] || exe;
    const today = this.data.days[day] || { total: 0, apps: {}, hours: Array(24).fill(0), pickups: 0, first: 0 };
    const week = [];
    for (let i = 6; i >= 0; i -= 1) {
      const t = new Date();
      t.setDate(t.getDate() - i);
      const k = dayKey(t);
      const d = this.data.days[k] || { total: 0, apps: {} };
      const cats = {};
      for (const [exe, s] of Object.entries(d.apps || {})) {
        const c = catOf(exe, names[exe] || '');
        cats[c] = (cats[c] || 0) + s;
      }
      week.push({ day: k, total: d.total || 0, cats });
    }
    const cats = {};
    for (const [exe, s] of Object.entries(today.apps)) {
      const c = catOf(exe, names[exe] || '');
      cats[c] = (cats[c] || 0) + s;
    }
    const apps = Object.entries(today.apps)
      .map(([exe, s]) => ({ exe, name: label(exe), secs: s, cat: catOf(exe, names[exe] || '') }))
      .sort((a, b) => b.secs - a.secs)
      .slice(0, 25);
    const weekTotals = week.map((w) => w.total);
    const avg = Math.round(weekTotals.reduce((a, b) => a + b, 0) / Math.max(1, weekTotals.filter(Boolean).length));
    return { day, total: today.total, hours: today.hours, pickups: today.pickups, first: today.first, apps, cats, week, avg, catInfo: CAT_INFO, limit: Number(this.getSettings().screentimeLimit) || 0 };
  }
}

module.exports = { ScreenTime };
