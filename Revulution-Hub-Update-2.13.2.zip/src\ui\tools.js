'use strict';

/*
 * Mini-Apps des Hubs: kleine Helfer für den Alltag. Jede lässt sich im Starter ins Dock
 * legen oder daraus entfernen.
 *   Übersetzer · Rechner · Einheiten · Währungen · Wetter · Notizen · Timer & Stoppuhr ·
 *   Passwort-Generator · Zwischenablage · Weltuhr
 */
(function () {
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const fmt = (n, d = 4) => (Number.isFinite(n) ? Number(n.toFixed(d)).toLocaleString('de-DE', { maximumFractionDigits: d }) : '–');

  const TOOLS = {
    'tool-translate': { nav: 'Übersetzer', title: 'Übersetzer', sub: 'Texte in andere Sprachen', icon: 'text', tint: 'linear-gradient(135deg,#38bdf8,#2563eb)', desc: 'Übersetzt Texte zwischen Deutsch, Englisch, Spanisch, Französisch, Italienisch, Türkisch und mehr.' },
    'tool-calc': { nav: 'Rechner', title: 'Rechner', sub: 'Mit Klammern, Potenzen & Wurzeln', icon: 'grid', tint: 'linear-gradient(135deg,#f59e0b,#d97706)', desc: 'Taschenrechner mit Verlauf, Klammern, Prozent, Potenzen und Wurzeln – auch per Tastatur.' },
    'tool-convert': { nav: 'Einheiten', title: 'Einheiten-Umrechner', sub: 'Länge, Gewicht, Temperatur …', icon: 'resize', tint: 'linear-gradient(135deg,#34d399,#059669)', desc: 'Rechnet Länge, Gewicht, Temperatur, Volumen, Fläche, Geschwindigkeit, Datenmengen und Zeit um.' },
    'tool-currency': { nav: 'Währungen', title: 'Währungsrechner', sub: 'Aktuelle Wechselkurse', icon: 'refresh', tint: 'linear-gradient(135deg,#a3e635,#4d7c0f)', desc: 'Euro, Dollar, Franken, Pfund und mehr – mit den Kursen der Europäischen Zentralbank.' },
    'tool-weather': { nav: 'Wetter', title: 'Wetter', sub: 'Jetzt und die nächsten Tage', icon: 'spark', tint: 'linear-gradient(135deg,#60a5fa,#1d4ed8)', desc: 'Aktuelles Wetter und Vorhersage für deinen Ort – ohne Konto.' },
    'tool-notes': { nav: 'Notizen', title: 'Notizen', sub: 'Schnell etwas aufschreiben', icon: 'doc', tint: 'linear-gradient(135deg,#fde047,#ca8a04)', desc: 'Ein Notizblock, der automatisch speichert.' },
    'tool-timer': { nav: 'Timer', title: 'Timer & Stoppuhr', sub: 'Countdown und Rundenzeiten', icon: 'timer', tint: 'linear-gradient(135deg,#fb7185,#e11d48)', desc: 'Countdown mit Meldung in der Dynamic Island und eine Stoppuhr mit Runden.' },
    'tool-password': { nav: 'Passwörter', title: 'Passwort-Generator', sub: 'Sichere Passwörter erzeugen', icon: 'shield', tint: 'linear-gradient(135deg,#94a3b8,#475569)', desc: 'Erzeugt sichere, zufällige Passwörter – nur auf deinem PC, nichts wird gespeichert.' },
    'tool-clipboard': { nav: 'Ablage', title: 'Zwischenablage', sub: 'Was du zuletzt kopiert hast', icon: 'layers', tint: 'linear-gradient(135deg,#c084fc,#7c3aed)', desc: 'Die letzten 30 kopierten Texte – mit einem Klick wieder einfügen.' },
    'tool-worldclock': { nav: 'Weltuhr', title: 'Weltuhr', sub: 'Uhrzeit in anderen Städten', icon: 'clock', tint: 'linear-gradient(135deg,#2dd4bf,#0f766e)', desc: 'Die Uhrzeit in anderen Städten und Zeitzonen auf einen Blick.' },
  };

  let ctx = { state: () => null, render: () => {}, toast: () => {}, settings: (patch) => window.hub.setSettings(patch) };

  /* ================================================================ Übersetzer */
  const LANGS = [['de', 'Deutsch'], ['en', 'Englisch'], ['es', 'Spanisch'], ['fr', 'Französisch'], ['it', 'Italienisch'], ['pt', 'Portugiesisch'], ['nl', 'Niederländisch'], ['pl', 'Polnisch'], ['tr', 'Türkisch'], ['ru', 'Russisch'], ['uk', 'Ukrainisch'], ['ar', 'Arabisch'], ['zh', 'Chinesisch'], ['ja', 'Japanisch']];
  const tr = { text: '', from: 'de', to: 'en', out: '', busy: false, err: '' };
  async function translate() {
    const q = tr.text.trim();
    if (!q) return;
    tr.busy = true;
    tr.err = '';
    ctx.render();
    try {
      const parts = q.match(/[\s\S]{1,480}(?=\s|$)|[\s\S]{1,480}/g) || [q];
      const out = [];
      for (const part of parts) {
        const r = await window.hub.tool.fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(part)}&langpair=${tr.from}|${tr.to}`);
        out.push(r?.responseData?.translatedText || '');
      }
      tr.out = out.join(' ').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&');
    } catch (error) {
      tr.err = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
    tr.busy = false;
    ctx.render();
  }
  const opts = (list, sel) => list.map(([v, n]) => `<option value="${v}" ${v === sel ? 'selected' : ''}>${esc(n)}</option>`).join('');
  function translateHtml() {
    return `<div class="tool-grid two">
      <div class="tool-card"><div class="tool-row"><select class="select" data-tr="from">${opts(LANGS, tr.from)}</select><button class="btn small ghost" data-tool="tr-swap" title="Tauschen">⇄</button><select class="select" data-tr="to">${opts(LANGS, tr.to)}</select></div>
        <textarea class="input tool-area" data-tr="text" placeholder="Text eingeben … (Strg+Enter übersetzt)">${esc(tr.text)}</textarea>
        <div class="tool-row end"><small class="muted">${tr.text.length} Zeichen</small><button class="btn primary" data-tool="tr-go" ${tr.busy ? 'disabled' : ''}>${tr.busy ? 'Übersetze …' : 'Übersetzen'}</button></div></div>
      <div class="tool-card"><div class="tool-label">${esc(LANGS.find((l) => l[0] === tr.to)?.[1] || '')}</div>
        <div class="tool-out">${tr.err ? `<span class="err">${esc(tr.err)}</span>` : esc(tr.out) || '<span class="muted">Hier erscheint die Übersetzung.</span>'}</div>
        <div class="tool-row end"><button class="btn small" data-tool="tr-copy" ${tr.out ? '' : 'disabled'}>Kopieren</button></div></div>
    </div>`;
  }

  /* ================================================================ Rechner */
  const calc = { expr: '', result: '', history: [], rad: false, ans: 0 };
  const fact = (n) => {
    if (n < 0 || n > 170 || Math.floor(n) !== n) throw new Error('Fakultät nur für ganze Zahlen 0–170');
    let r = 1;
    for (let k = 2; k <= n; k += 1) r *= k;
    return r;
  };
  function evaluate(src) {
    const s = src.replace(/×/g, '*').replace(/÷/g, '/').replace(/,/g, '.').replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/\bmod\b/gi, '#');
    const ang = (x) => (calc.rad ? x : (x * Math.PI) / 180);
    const unang = (x) => (calc.rad ? x : (x * 180) / Math.PI);
    let i = 0;
    const peek = () => s[i];
    const skip = () => {
      while (s[i] === ' ') i += 1;
    };
    const num = () => {
      skip();
      const m = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i));
      if (m) {
        i += m[0].length;
        return parseFloat(m[0]);
      }
      const f = /^[a-z]+/i.exec(s.slice(i));
      if (f) {
        i += f[0].length;
        const name = f[0].toLowerCase();
        if (name === 'pi') return Math.PI;
        if (name === 'e') return Math.E;
        if (name === 'ans') return calc.ans;
        const fn = { sqrt: Math.sqrt, cbrt: Math.cbrt, sin: (x) => Math.sin(ang(x)), cos: (x) => Math.cos(ang(x)), tan: (x) => Math.tan(ang(x)), asin: (x) => unang(Math.asin(x)), acos: (x) => unang(Math.acos(x)), atan: (x) => unang(Math.atan(x)), sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh, log: Math.log10, lb: Math.log2, ln: Math.log, exp: Math.exp, abs: Math.abs, round: Math.round, floor: Math.floor, ceil: Math.ceil }[name];
        if (!fn) throw new Error(`Unbekannt: ${name}`);
        return fn(factor());
      }
      if (peek() === '(') {
        i += 1;
        const v = expr();
        skip();
        if (s[i] !== ')') throw new Error('Klammer fehlt');
        i += 1;
        return v;
      }
      throw new Error('Ungültige Eingabe');
    };
    const factor = () => {
      skip();
      if (peek() === '-') {
        i += 1;
        return -factor();
      }
      if (peek() === '+') {
        i += 1;
        return factor();
      }
      let v = num();
      skip();
      while (peek() === '!') {
        i += 1;
        v = fact(v);
        skip();
      }
      if (peek() === '%') {
        i += 1;
        v /= 100;
      }
      skip();
      if (peek() === '^') {
        i += 1;
        v = v ** factor();
      }
      return v;
    };
    const term = () => {
      let v = factor();
      for (;;) {
        skip();
        if (peek() === '*') {
          i += 1;
          v *= factor();
        } else if (peek() === '/') {
          i += 1;
          v /= factor();
        } else if (peek() === '#') {
          i += 1;
          const m = factor();
          v = ((v % m) + m) % m;
        } else if (peek() === '(' || /[a-z]/i.test(peek() || '')) {
          v *= factor(); // 2(3+4), 2pi, 3sin(30)
        } else return v;
      }
    };
    const expr = () => {
      let v = term();
      for (;;) {
        skip();
        if (peek() === '+') {
          i += 1;
          v += term();
        } else if (peek() === '-') {
          i += 1;
          v -= term();
        } else return v;
      }
    };
    const v = expr();
    skip();
    if (i < s.length) throw new Error('Ungültige Eingabe');
    return v;
  }
  function calcLive() {
    if (!calc.expr.trim()) return '';
    try {
      const v = evaluate(calc.expr);
      return Number.isFinite(v) ? fmt(v, 10) : 'Fehler';
    } catch {
      return '';
    }
  }
  function calcPress(k) {
    if (k === 'C') calc.expr = '';
    else if (k === '⌫') calc.expr = calc.expr.slice(0, -1);
    else if (k === 'RAD' || k === 'DEG') calc.rad = !calc.rad;
    else if (k === '=') {
      try {
        const v = evaluate(calc.expr);
        if (!Number.isFinite(v)) throw new Error('Fehler');
        calc.ans = v;
        calc.history = [{ e: calc.expr, r: fmt(v, 10) }, ...calc.history].slice(0, 12);
        calc.expr = String(Number(v.toFixed(10)));
      } catch (error) {
        ctx.toast(error.message, 'error');
      }
    } else calc.expr += k;
    ctx.render();
    const inp = document.querySelector('.calc-expr');
    if (inp && inp.value !== calc.expr) inp.value = calc.expr;
  }
  function calcHtml() {
    const keys = ['C', '(', ')', '⌫', '7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '-', '0', ',', '%', '+', '√', '^', 'π', '='];
    const sci = [['sin', 'sin('], ['cos', 'cos('], ['tan', 'tan('], ['ln', 'ln('], ['log', 'log('], [calc.rad ? 'RAD' : 'DEG', calc.rad ? 'RAD' : 'DEG'], ['sin⁻¹', 'asin('], ['cos⁻¹', 'acos('], ['tan⁻¹', 'atan('], ['eˣ', 'exp('], ['|x|', 'abs('], ['Ans', 'ans'], ['x²', '^2'], ['xʸ', '^'], ['¹⁄ₓ', '^(-1)'], ['n!', '!'], ['e', 'e'], ['mod', ' mod ']];
    return `<div class="tool-grid calc-wrap"><div class="tool-card calc">
      <div class="calc-screen"><input class="calc-expr" data-calc="expr" value="${esc(calc.expr)}" placeholder="0" spellcheck="false" /><div class="calc-live">${esc(calcLive())}</div></div>
      <div class="calc-sci">${sci.map(([n, k]) => `<button class="calc-key sci ${n === 'RAD' || n === 'DEG' ? 'mode' : ''}" data-calc-key="${esc(k)}">${esc(n)}</button>`).join('')}</div>
      <div class="calc-keys">${keys.map((k) => `<button class="calc-key ${'÷×-+='.includes(k) ? 'op' : ''} ${k === '=' ? 'eq' : ''} ${k === 'C' ? 'clr' : ''}" data-calc-key="${esc(k)}">${esc(k)}</button>`).join('')}</div></div>
      <div class="tool-card"><div class="tool-label">Verlauf</div>${calc.history.length ? calc.history.map((h, i) => `<button class="calc-hist" data-calc-hist="${i}"><span>${esc(h.e)}</span><b>= ${esc(h.r)}</b></button>`).join('') : '<p class="muted">Noch nichts gerechnet. Tipp: auch per Tastatur – z. B. 2pi, sqrt(2), 5!, 17 mod 5, sin(30). Enter rechnet.</p>'}</div></div>`;
  }

  /* ================================================================ Einheiten */
  const UNITS = {
    Länge: { mm: 0.001, cm: 0.01, m: 1, km: 1000, Zoll: 0.0254, Fuß: 0.3048, Yard: 0.9144, Meile: 1609.344, Seemeile: 1852 },
    Gewicht: { mg: 1e-6, g: 0.001, kg: 1, t: 1000, Unze: 0.0283495, Pfund: 0.453592, Stone: 6.35029 },
    Volumen: { ml: 0.001, cl: 0.01, l: 1, 'm³': 1000, Teelöffel: 0.00492892, Esslöffel: 0.0147868, Tasse: 0.24, 'US-Gallone': 3.78541, 'UK-Gallone': 4.54609 },
    Fläche: { 'mm²': 1e-6, 'cm²': 1e-4, 'm²': 1, Ar: 100, Hektar: 1e4, 'km²': 1e6, Acre: 4046.86, 'ft²': 0.092903 },
    Geschwindigkeit: { 'm/s': 1, 'km/h': 1 / 3.6, mph: 0.44704, Knoten: 0.514444 },
    Daten: { Byte: 1, KB: 1e3, MB: 1e6, GB: 1e9, TB: 1e12, KiB: 1024, MiB: 1024 ** 2, GiB: 1024 ** 3, 'Bit': 0.125, 'MBit': 125000 },
    Zeit: { Sekunde: 1, Minute: 60, Stunde: 3600, Tag: 86400, Woche: 604800, Monat: 2629800, Jahr: 31557600 },
    Temperatur: { '°C': 'c', '°F': 'f', K: 'k' },
  };
  const conv = { cat: 'Länge', from: 'm', to: 'km', value: '1' };
  function convert() {
    const v = parseFloat(String(conv.value).replace(',', '.'));
    if (!Number.isFinite(v)) return null;
    if (conv.cat === 'Temperatur') {
      const c = conv.from === '°C' ? v : conv.from === '°F' ? ((v - 32) * 5) / 9 : v - 273.15;
      return conv.to === '°C' ? c : conv.to === '°F' ? (c * 9) / 5 + 32 : c + 273.15;
    }
    const u = UNITS[conv.cat];
    return (v * u[conv.from]) / u[conv.to];
  }
  function convertHtml() {
    const units = Object.keys(UNITS[conv.cat]);
    const r = convert();
    const all = units.filter((x) => x !== conv.from).slice(0, 8);
    const v = parseFloat(String(conv.value).replace(',', '.'));
    const allRows = Number.isFinite(v)
      ? all.map((to) => {
          const keep = conv.to;
          conv.to = to;
          const x = convert();
          conv.to = keep;
          return `<div class="conv-row"><span>${esc(to)}</span><b>${fmt(x, 6)}</b></div>`;
        }).join('')
      : '';
    return `<div class="tool-card"><div class="chip-row">${Object.keys(UNITS).map((c) => `<button class="chip ${c === conv.cat ? 'on' : ''}" data-conv-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div>
      <div class="conv-main"><input class="input conv-in" data-conv="value" value="${esc(conv.value)}" inputmode="decimal" /><select class="select" data-conv="from">${units.map((u) => `<option ${u === conv.from ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select>
      <button class="btn small ghost" data-tool="conv-swap">⇄</button><select class="select" data-conv="to">${units.map((u) => `<option ${u === conv.to ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select></div>
      <div class="conv-result">${r == null ? '–' : `${fmt(r, 6)} <small>${esc(conv.to)}</small>`}</div></div>
      ${allRows ? `<div class="tool-card"><div class="tool-label">${esc(conv.value)} ${esc(conv.from)} sind …</div><div class="conv-all">${allRows}</div></div>` : ''}`;
  }

  /* ================================================================ Währungen */
  const CUR = ['EUR', 'USD', 'CHF', 'GBP', 'JPY', 'PLN', 'CZK', 'SEK', 'NOK', 'DKK', 'TRY', 'HUF', 'CAD', 'AUD', 'CNY', 'INR', 'BRL', 'MXN'];
  const cur = { amount: '100', from: 'EUR', to: 'USD', rates: null, date: '', busy: false, err: '' };
  async function loadRates() {
    if (cur.busy) return;
    cur.busy = true;
    cur.err = '';
    try {
      let r;
      try {
        r = await window.hub.tool.fetch('https://api.frankfurter.app/latest?from=EUR');
      } catch {
        r = await window.hub.tool.fetch('https://api.frankfurter.dev/v1/latest?base=EUR');
      }
      cur.rates = { EUR: 1, ...(r.rates || {}) };
      cur.date = r.date || '';
    } catch (error) {
      cur.err = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
    cur.busy = false;
    ctx.render();
  }
  function currencyHtml() {
    if (!cur.rates && !cur.busy && !cur.err) loadRates();
    const a = parseFloat(String(cur.amount).replace(',', '.'));
    const val = cur.rates && Number.isFinite(a) && cur.rates[cur.from] && cur.rates[cur.to] ? (a / cur.rates[cur.from]) * cur.rates[cur.to] : null;
    const list = CUR.filter((c) => cur.rates?.[c]);
    const sel = (key) => `<select class="select" data-cur="${key}">${(list.length ? list : CUR).map((c) => `<option ${c === cur[key] ? 'selected' : ''}>${c}</option>`).join('')}</select>`;
    return `<div class="tool-card"><div class="conv-main"><input class="input conv-in" data-cur="amount" value="${esc(cur.amount)}" inputmode="decimal" />${sel('from')}<button class="btn small ghost" data-tool="cur-swap">⇄</button>${sel('to')}</div>
      <div class="conv-result">${cur.err ? `<span class="err">${esc(cur.err)}</span>` : val == null ? (cur.busy ? 'Lade Kurse …' : '–') : `${fmt(val, 2)} <small>${esc(cur.to)}</small>`}</div>
      ${val != null ? `<p class="muted">1 ${esc(cur.from)} = ${fmt(cur.rates[cur.to] / cur.rates[cur.from], 4)} ${esc(cur.to)} · Kurs vom ${esc(cur.date)} (EZB)</p>` : ''}
      <div class="tool-row end"><button class="btn small" data-tool="cur-reload">Kurse neu laden</button></div></div>`;
  }

  /* ================================================================ Wetter */
  const WMO = { 0: ['☀️', 'Klar'], 1: ['🌤️', 'Überwiegend klar'], 2: ['⛅', 'Teils bewölkt'], 3: ['☁️', 'Bewölkt'], 45: ['🌫️', 'Nebel'], 48: ['🌫️', 'Reifnebel'], 51: ['🌦️', 'Leichter Niesel'], 53: ['🌦️', 'Niesel'], 55: ['🌧️', 'Starker Niesel'], 61: ['🌧️', 'Leichter Regen'], 63: ['🌧️', 'Regen'], 65: ['🌧️', 'Starker Regen'], 66: ['🌧️', 'Eisregen'], 67: ['🌧️', 'Eisregen'], 71: ['🌨️', 'Leichter Schnee'], 73: ['🌨️', 'Schnee'], 75: ['❄️', 'Starker Schnee'], 77: ['🌨️', 'Schneegriesel'], 80: ['🌦️', 'Schauer'], 81: ['🌧️', 'Starke Schauer'], 82: ['⛈️', 'Heftige Schauer'], 85: ['🌨️', 'Schneeschauer'], 86: ['🌨️', 'Schneeschauer'], 95: ['⛈️', 'Gewitter'], 96: ['⛈️', 'Gewitter mit Hagel'], 99: ['⛈️', 'Gewitter mit Hagel'] };
  const wx = { q: '', results: null, data: null, busy: false, err: '', loadedFor: '' };
  async function wxSearch() {
    if (!wx.q.trim()) return;
    wx.busy = true;
    ctx.render();
    try {
      const r = await window.hub.tool.fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(wx.q.trim())}&count=6&language=de`);
      wx.results = r.results || [];
      if (!wx.results.length) wx.err = 'Ort nicht gefunden.';
      else wx.err = '';
    } catch (error) {
      wx.err = String(error?.message || error);
    }
    wx.busy = false;
    ctx.render();
  }
  async function wxLoad(city) {
    wx.busy = true;
    wx.err = '';
    wx.loadedFor = `${city.lat},${city.lon}`;
    ctx.render();
    try {
      wx.data = await window.hub.tool.fetch(`https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_gusts_10m_max&timezone=auto&forecast_days=6`);
      if (wx.data?.daily) wxWarn(city, wx.data);
    } catch (error) {
      wx.err = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
    wx.busy = false;
    ctx.render();
  }
  const wxCities = () => {
    const s = ctx.state()?.settings || {};
    const list = Array.isArray(s.weatherCities) ? [...s.weatherCities] : [];
    if (s.weatherCity?.name && !list.some((c) => c.name === s.weatherCity.name)) list.unshift(s.weatherCity);
    return list;
  };
  /** Sturm, Gewitter oder starker Schnee in den nächsten zwei Tagen → einmal am Tag melden. */
  function wxWarn(city, d) {
    try {
      const day = new Date().toLocaleDateString('sv-SE');
      const key = `${day}|${city.name}`;
      if (ctx.state()?.settings?.weatherWarned === key) return;
      for (let i = 0; i < 2; i += 1) {
        const code = d.daily.weather_code[i], gust = d.daily.wind_gusts_10m_max?.[i] || 0;
        const what = code >= 95 ? 'Gewitter' : code === 75 || code === 86 ? 'Starker Schneefall' : code === 65 || code === 82 ? 'Starker Regen' : gust >= 75 ? `Sturm (Böen bis ${Math.round(gust)} km/h)` : '';
        if (!what) continue;
        window.hub.tool.notify(`⚠️ ${what} in ${city.name}`, i ? 'Morgen – plane entsprechend.' : 'Heute – pass auf dich auf.').catch(() => {});
        ctx.settings({ weatherWarned: key });
        return;
      }
    } catch {}
  }
  /** Kleine Karte um den Ort (OpenStreetMap-Kacheln, 3×3) mit Stecknadel. */
  function wxMap(city, z = 10) {
    const n = 2 ** z;
    const x = ((city.lon + 180) / 360) * n;
    const lat = (city.lat * Math.PI) / 180;
    const y = ((1 - Math.log(Math.tan(lat) + 1 / Math.cos(lat)) / Math.PI) / 2) * n;
    const tx = Math.floor(x), ty = Math.floor(y);
    const tiles = [];
    // 7 × 3 Kacheln – genug für jede Fensterbreite
    for (let dy = -1; dy <= 1; dy += 1)
      for (let dx = -3; dx <= 3; dx += 1) tiles.push(`<img src="https://tile.openstreetmap.org/${z}/${(tx + dx + n) % n}/${ty + dy}.png" alt="" draggable="false" style="left:${(dx + 3) * 256}px;top:${(dy + 1) * 256}px" />`);
    // die Kachelfläche so verschieben, dass der Ort genau in der Mitte der Karte liegt
    const ox = (x - tx + 3) * 256, oy = (y - ty + 1) * 256;
    return `<div class="tool-card wx-map"><div class="wx-tiles" style="transform:translate(${(-ox).toFixed(1)}px, ${(-oy).toFixed(1)}px)">${tiles.join('')}</div><i class="wx-pin"></i><span class="wx-mapname">${esc(city.name)}</span><small class="wx-osm">© OpenStreetMap</small></div>`;
  }
  function weatherHtml() {
    const city = ctx.state()?.settings?.weatherCity;
    if (city?.name && wx.loadedFor !== `${city.lat},${city.lon}` && !wx.busy) wxLoad(city);
    const d = wx.data;
    const cur = d?.current;
    const days = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
    return `<div class="tool-card"><div class="tool-row"><input class="input" data-wx="q" value="${esc(wx.q)}" placeholder="Ort suchen, z. B. Zürich" /><button class="btn" data-tool="wx-search">Suchen</button></div>
      ${wx.results?.length ? `<div class="chip-row">${wx.results.map((r, i) => `<button class="chip" data-wx-pick="${i}">${esc(r.name)}${r.admin1 ? `, ${esc(r.admin1)}` : ''} (${esc(r.country_code || '')})</button>`).join('')}</div>` : ''}
      ${wxCities().length ? `<div class="chip-row">${wxCities().map((c, i) => `<span class="chip wx-city ${c.name === city?.name ? 'on' : ''}" data-wx-city="${i}">${esc(c.name)}<button data-wx-del="1" title="Entfernen">×</button></span>`).join('')}</div>` : ''}
      ${wx.err ? `<p class="err">${esc(wx.err)}</p>` : ''}</div>
      ${cur ? `<div class="tool-card wx-now"><div class="wx-ic">${WMO[cur.weather_code]?.[0] || '🌡️'}</div><div><span class="tool-label">${esc(city?.name || '')}</span><b class="wx-temp">${Math.round(cur.temperature_2m)}°</b><span>${esc(WMO[cur.weather_code]?.[1] || '')} · gefühlt ${Math.round(cur.apparent_temperature)}° · ${cur.relative_humidity_2m}% Luftfeuchte · Wind ${Math.round(cur.wind_speed_10m)} km/h</span></div></div>
        ${wxMap(city)}
        <div class="wx-days">${d.daily.time.map((t, i) => `<div class="tool-card wx-day"><span>${i ? days[new Date(t).getDay()] : 'Heute'}</span><i>${WMO[d.daily.weather_code[i]]?.[0] || ''}</i><b>${Math.round(d.daily.temperature_2m_max[i])}°</b><small>${Math.round(d.daily.temperature_2m_min[i])}°</small><em>💧 ${d.daily.precipitation_probability_max[i] ?? 0}%</em></div>`).join('')}</div>` : !city?.name ? '<p class="muted tool-note">Such deinen Ort – er wird gespeichert.</p>' : wx.busy ? '<p class="muted tool-note">Lade Wetter …</p>' : ''}`;
  }

  /* ================================================================ Notizen */
  let notesTimer = null;
  function notesHtml() {
    const text = ctx.state()?.settings?.notes || '';
    return `<div class="tool-card notes"><textarea class="input notes-area" data-notes="1" placeholder="Schreib einfach los – wird automatisch gespeichert.">${esc(text)}</textarea><div class="tool-row end"><small class="muted" id="notes-status">${text.length} Zeichen · gespeichert</small><button class="btn small" data-tool="notes-copy">Kopieren</button></div></div>`;
  }

  /* ================================================================ Timer & Stoppuhr */
  const tm = { total: 0, end: 0, left: 0, running: false, paused: 0, label: '', sw: { start: 0, acc: 0, running: false, laps: [] }, input: '5' };
  const mmss = (ms) => {
    const s = Math.max(0, Math.round(ms / 1000));
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return `${h ? `${h}:` : ''}${String(m).padStart(h ? 2 : 1, '0')}:${String(x).padStart(2, '0')}`;
  };
  const swTime = () => tm.sw.acc + (tm.sw.running ? Date.now() - tm.sw.start : 0);
  const swFmt = (ms) => `${mmss(ms)},${String(Math.floor((ms % 1000) / 10)).padStart(2, '0')}`;
  function timerStart(min) {
    tm.total = min * 60000;
    tm.end = Date.now() + tm.total;
    tm.running = true;
    tm.paused = 0;
    tm.label = `${min} min`;
    ctx.render();
  }
  setInterval(() => {
    if (tm.running && Date.now() >= tm.end) {
      tm.running = false;
      tm.total = 0;
      window.hub.tool.notify('⏰ Timer abgelaufen', `${tm.label} sind um.`).catch(() => {});
      try {
        const a = new AudioContext();
        [0, 0.35, 0.7].forEach((t) => {
          const o = a.createOscillator();
          const g = a.createGain();
          o.frequency.value = 880;
          g.gain.setValueAtTime(0.25, a.currentTime + t);
          g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + t + 0.3);
          o.connect(g).connect(a.destination);
          o.start(a.currentTime + t);
          o.stop(a.currentTime + t + 0.3);
        });
      } catch {}
      ctx.toast('Timer abgelaufen!');
      ctx.render();
    }
    const el = document.getElementById('tm-left');
    if (el && tm.running) {
      el.textContent = mmss(tm.end - Date.now());
      const ring = document.getElementById('tm-ring');
      if (ring) ring.style.strokeDasharray = `${((tm.end - Date.now()) / tm.total) * 302} 302`;
    }
    const sw = document.getElementById('sw-time');
    if (sw && tm.sw.running) sw.textContent = swFmt(swTime());
    const wc = document.querySelectorAll('[data-wc-zone]');
    wc.forEach((n) => {
      try {
        n.textContent = new Date().toLocaleTimeString('de-DE', { timeZone: n.dataset.wcZone, hour: '2-digit', minute: '2-digit', second: '2-digit' });
      } catch {}
    });
  }, 250);
  function timerHtml() {
    const left = tm.running ? tm.end - Date.now() : tm.paused;
    const frac = tm.total ? left / tm.total : 0;
    return `<div class="tool-grid two">
      <div class="tool-card timer"><div class="tool-label">Timer</div>
        <div class="tm-dial"><svg viewBox="0 0 110 110"><circle cx="55" cy="55" r="48" class="trk"/><circle id="tm-ring" cx="55" cy="55" r="48" class="val" style="stroke-dasharray:${frac * 302} 302"/></svg><b id="tm-left">${tm.total ? mmss(left) : '0:00'}</b></div>
        <div class="chip-row center">${[1, 3, 5, 10, 15, 25, 45, 60].map((m) => `<button class="chip" data-tm-min="${m}">${m} min</button>`).join('')}</div>
        <div class="tool-row center"><input class="input short" data-tm="input" value="${esc(tm.input)}" inputmode="numeric" /><span class="muted">min</span><button class="btn primary" data-tool="tm-go">Start</button>
        ${tm.total ? `<button class="btn" data-tool="tm-pause">${tm.running ? 'Pause' : 'Weiter'}</button><button class="btn ghost" data-tool="tm-stop">Stopp</button>` : ''}</div>
        <small class="muted">Wenn die Zeit um ist, meldet sich die Dynamic Island.</small></div>
      <div class="tool-card"><div class="tool-label">Stoppuhr</div><b class="sw-time" id="sw-time">${swFmt(swTime())}</b>
        <div class="tool-row center"><button class="btn primary" data-tool="sw-toggle">${tm.sw.running ? 'Stopp' : 'Start'}</button><button class="btn" data-tool="sw-lap" ${tm.sw.running ? '' : 'disabled'}>Runde</button><button class="btn ghost" data-tool="sw-reset">Zurücksetzen</button></div>
        <div class="sw-laps">${tm.sw.laps.map((l, i) => `<div><span>Runde ${tm.sw.laps.length - i}</span><b>${swFmt(l)}</b></div>`).join('')}</div></div></div>`;
  }

  /* ================================================================ Passwörter */
  const pw = { len: 18, upper: true, lower: true, digits: true, symbols: true, value: '' };
  function genPw() {
    const sets = [pw.lower && 'abcdefghijkmnopqrstuvwxyz', pw.upper && 'ABCDEFGHJKLMNPQRSTUVWXYZ', pw.digits && '23456789', pw.symbols && '!@#$%&*?+-=_.:'].filter(Boolean);
    if (!sets.length) return '';
    const all = sets.join('');
    const rnd = new Uint32Array(pw.len + sets.length);
    crypto.getRandomValues(rnd);
    const chars = sets.map((s, i) => s[rnd[i] % s.length]);
    for (let i = chars.length; i < pw.len; i += 1) chars.push(all[rnd[i] % all.length]);
    // mischen
    const mix = new Uint32Array(chars.length);
    crypto.getRandomValues(mix);
    for (let i = chars.length - 1; i > 0; i -= 1) {
      const j = mix[i] % (i + 1);
      [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    return chars.join('');
  }
  function pwHtml() {
    if (!pw.value) pw.value = genPw();
    const pool = (pw.lower ? 25 : 0) + (pw.upper ? 24 : 0) + (pw.digits ? 8 : 0) + (pw.symbols ? 14 : 0);
    const bits = Math.round(pw.len * Math.log2(Math.max(2, pool)));
    const level = bits >= 100 ? ['Sehr stark', '#4ade80'] : bits >= 70 ? ['Stark', '#a3e635'] : bits >= 50 ? ['Mittel', '#fbbf24'] : ['Schwach', '#f87171'];
    const box = (k, n) => `<label class="pw-opt"><button class="switch ${pw[k] ? 'on' : ''}" data-pw-opt="${k}"></button>${n}</label>`;
    return `<div class="tool-card"><div class="pw-value" id="pw-value">${esc(pw.value)}</div>
      <div class="pw-meter"><i style="width:${Math.min(100, bits / 1.28)}%;background:${level[1]}"></i></div><small style="color:${level[1]}">${level[0]} · ca. ${bits} Bit</small>
      <div class="tool-row"><span>Länge</span><input type="range" min="8" max="64" value="${pw.len}" data-pw="len" /><b>${pw.len}</b></div>
      <div class="pw-opts">${box('upper', 'A–Z')}${box('lower', 'a–z')}${box('digits', '0–9')}${box('symbols', '!@#')}</div>
      <div class="tool-row end"><button class="btn" data-tool="pw-new">Neu erzeugen</button><button class="btn primary" data-tool="pw-copy">Kopieren</button></div></div>
      <p class="muted tool-note">Wird nur auf deinem PC erzeugt und nirgends gespeichert.</p>`;
  }

  /* ================================================================ Zwischenablage */
  let clipList = null;
  let clipTimer = null;
  function clipHtml() {
    if (!clipTimer) {
      const load = () => window.hub.tool.clipboard('list').then((l) => {
        const changed = JSON.stringify(l) !== JSON.stringify(clipList);
        clipList = l;
        if (changed && ctx.state()?.active === 'tool-clipboard') ctx.render();
      }).catch(() => {});
      load();
      clipTimer = setInterval(() => ctx.state()?.active === 'tool-clipboard' && load(), 2000);
    }
    const list = clipList || [];
    return `<div class="tool-card"><div class="tool-row"><span class="tool-label">Zuletzt kopiert</span><button class="btn small ghost" data-tool="clip-clear" ${list.length ? '' : 'disabled'}>Alles leeren</button></div>
      ${list.length ? `<div class="clip-list">${list.map((c, i) => `<div class="clip-item"><button class="clip-text" data-clip-copy="${i}" title="Klicken zum Kopieren">${esc(c.text.slice(0, 300))}${c.text.length > 300 ? '…' : ''}</button><small>${new Date(c.at).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}</small><button class="btn small ghost" data-clip-del="${i}">✕</button></div>`).join('')}</div>` : '<p class="muted">Kopier irgendwo einen Text – er erscheint hier. Der Verlauf bleibt nur, solange der Hub läuft.</p>'}</div>`;
  }

  /* ================================================================ Weltuhr */
  const ZONES = [['Europe/Berlin', 'Berlin'], ['Europe/Zurich', 'Zürich'], ['Europe/Vienna', 'Wien'], ['Europe/London', 'London'], ['Europe/Madrid', 'Madrid'], ['Europe/Istanbul', 'Istanbul'], ['Europe/Moscow', 'Moskau'], ['America/New_York', 'New York'], ['America/Chicago', 'Chicago'], ['America/Los_Angeles', 'Los Angeles'], ['America/Sao_Paulo', 'São Paulo'], ['America/Mexico_City', 'Mexiko-Stadt'], ['Asia/Dubai', 'Dubai'], ['Asia/Kolkata', 'Neu-Delhi'], ['Asia/Bangkok', 'Bangkok'], ['Asia/Shanghai', 'Peking'], ['Asia/Tokyo', 'Tokio'], ['Asia/Seoul', 'Seoul'], ['Australia/Sydney', 'Sydney'], ['Pacific/Auckland', 'Auckland']];
  function wcHtml() {
    const mine = ctx.state()?.settings?.worldclocks || ['America/New_York', 'Asia/Tokyo', 'Europe/London'];
    const off = (z) => {
      try {
        const now = new Date();
        const a = new Date(now.toLocaleString('en-US', { timeZone: z }));
        const b = new Date(now.toLocaleString('en-US'));
        const h = Math.round((a - b) / 36e5);
        return h === 0 ? 'gleiche Zeit' : `${h > 0 ? '+' : ''}${h} h`;
      } catch {
        return '';
      }
    };
    return `<div class="wc-grid">${mine
      .map((z) => `<div class="tool-card wc"><span class="tool-label">${esc(ZONES.find((x) => x[0] === z)?.[1] || z)}</span><b data-wc-zone="${esc(z)}">${new Date().toLocaleTimeString('de-DE', { timeZone: z, hour: '2-digit', minute: '2-digit', second: '2-digit' })}</b><small class="muted">${esc(new Date().toLocaleDateString('de-DE', { timeZone: z, weekday: 'long', day: '2-digit', month: '2-digit' }))} · ${off(z)}</small><button class="btn small ghost" data-wc-del="${esc(z)}">Entfernen</button></div>`)
      .join('')}</div>
      <div class="tool-card"><div class="tool-row"><select class="select" id="wc-add">${ZONES.filter((x) => !mine.includes(x[0])).map(([z, n]) => `<option value="${z}">${esc(n)}</option>`).join('')}</select><button class="btn primary" data-tool="wc-add">Stadt hinzufügen</button></div></div>`;
  }

  /* ================================================================ Ereignisse */
  document.addEventListener('input', (e) => {
    const t = e.target;
    if (t.dataset.tr) {
      tr[t.dataset.tr] = t.value;
      if (t.dataset.tr !== 'text') ctx.render();
      return;
    }
    if (t.dataset.calc === 'expr') {
      calc.expr = t.value;
      const live = document.querySelector('.calc-live');
      if (live) live.textContent = calcLive();
      return;
    }
    if (t.dataset.conv) {
      conv[t.dataset.conv] = t.value;
      ctx.render();
      return;
    }
    if (t.dataset.cur) {
      cur[t.dataset.cur] = t.value;
      ctx.render();
      return;
    }
    if (t.dataset.wx) wx.q = t.value;
    if (t.dataset.tm) tm.input = t.value;
    if (t.dataset.pw === 'len') {
      pw.len = Number(t.value);
      pw.value = genPw();
      ctx.render();
    }
    if (t.dataset.notes) {
      const status = document.getElementById('notes-status');
      if (status) status.textContent = `${t.value.length} Zeichen · speichert …`;
      clearTimeout(notesTimer);
      const v = t.value;
      notesTimer = setTimeout(() => {
        ctx.settings({ notes: v }).then(() => {
          const s2 = document.getElementById('notes-status');
          if (s2) s2.textContent = `${v.length} Zeichen · gespeichert`;
        });
      }, 600);
    }
  });
  document.addEventListener('change', (e) => {
    const t = e.target;
    if (t.tagName !== 'SELECT') return;
    if (t.dataset.tr) tr[t.dataset.tr] = t.value;
    else if (t.dataset.conv) conv[t.dataset.conv] = t.value;
    else if (t.dataset.cur) cur[t.dataset.cur] = t.value;
    else return;
    ctx.render();
  });
  document.addEventListener('keydown', (e) => {
    if (e.target.dataset?.tr === 'text' && e.key === 'Enter' && e.ctrlKey) translate();
    if (e.target.dataset?.calc === 'expr' && e.key === 'Enter') calcPress('=');
    if (e.target.dataset?.wx === 'q' && e.key === 'Enter') wxSearch();
    if (e.target.dataset?.tm === 'input' && e.key === 'Enter') timerStart(Math.max(1, Math.min(999, parseFloat(tm.input) || 5)));
  });
  document.addEventListener('click', async (e) => {
    const k = e.target.closest?.('[data-calc-key]');
    if (k) return calcPress(k.dataset.calcKey);
    const h = e.target.closest?.('[data-calc-hist]');
    if (h) {
      calc.expr = calc.history[Number(h.dataset.calcHist)].r.replace(/\./g, '').replace(',', '.');
      return ctx.render();
    }
    const cc = e.target.closest?.('[data-conv-cat]');
    if (cc) {
      conv.cat = cc.dataset.convCat;
      const u = Object.keys(UNITS[conv.cat]);
      conv.from = u[conv.cat === 'Temperatur' ? 0 : Math.min(2, u.length - 1)];
      conv.to = u[conv.cat === 'Temperatur' ? 1 : Math.min(3, u.length - 1)];
      return ctx.render();
    }
    const wp = e.target.closest?.('[data-wx-pick]');
    if (wp) {
      const r = wx.results[Number(wp.dataset.wxPick)];
      wx.results = null;
      const city = { name: r.name, lat: r.latitude, lon: r.longitude };
      const list = (ctx.state()?.settings?.weatherCities || []).filter((c) => c.name !== city.name);
      wx.q = '';
      await ctx.settings({ weatherCity: city, weatherCities: [city, ...list].slice(0, 8) });
      return;
    }
    const wc = e.target.closest?.('[data-wx-city]');
    if (wc) {
      const list = wxCities();
      const i = Number(wc.dataset.wxCity);
      if (e.target.closest('[data-wx-del]')) {
        const rest = list.filter((_, k) => k !== i);
        await ctx.settings({ weatherCities: rest, ...(rest[0] && list[i].name === ctx.state()?.settings?.weatherCity?.name ? { weatherCity: rest[0] } : {}) });
      } else await ctx.settings({ weatherCity: list[i] });
      return;
    }
    const tmMin = e.target.closest?.('[data-tm-min]');
    if (tmMin) return timerStart(Number(tmMin.dataset.tmMin));
    const po = e.target.closest?.('[data-pw-opt]');
    if (po) {
      pw[po.dataset.pwOpt] = !pw[po.dataset.pwOpt];
      if (![pw.upper, pw.lower, pw.digits, pw.symbols].some(Boolean)) pw.lower = true;
      pw.value = genPw();
      return ctx.render();
    }
    const cl = e.target.closest?.('[data-clip-copy]');
    if (cl) {
      clipList = await window.hub.tool.clipboard('copy', clipList[Number(cl.dataset.clipCopy)].text);
      ctx.toast('Kopiert');
      return ctx.render();
    }
    const cd = e.target.closest?.('[data-clip-del]');
    if (cd) {
      clipList = await window.hub.tool.clipboard('remove', Number(cd.dataset.clipDel));
      return ctx.render();
    }
    const wd = e.target.closest?.('[data-wc-del]');
    if (wd) {
      const mine = ctx.state()?.settings?.worldclocks || ['America/New_York', 'Asia/Tokyo', 'Europe/London'];
      return ctx.settings({ worldclocks: mine.filter((z) => z !== wd.dataset.wcDel) });
    }
    const b = e.target.closest?.('[data-tool]');
    if (!b) return;
    const a = b.dataset.tool;
    if (a === 'tr-go') return translate();
    if (a === 'tr-swap') {
      [tr.from, tr.to] = [tr.to, tr.from];
      if (tr.out) [tr.text, tr.out] = [tr.out, tr.text];
      return ctx.render();
    }
    if (a === 'tr-copy' || a === 'pw-copy' || a === 'notes-copy') {
      const text = a === 'tr-copy' ? tr.out : a === 'pw-copy' ? pw.value : ctx.state()?.settings?.notes || '';
      await window.hub.tool.clipboard('copy', text);
      return ctx.toast('In die Zwischenablage kopiert.');
    }
    if (a === 'conv-swap') {
      [conv.from, conv.to] = [conv.to, conv.from];
      return ctx.render();
    }
    if (a === 'cur-swap') {
      [cur.from, cur.to] = [cur.to, cur.from];
      return ctx.render();
    }
    if (a === 'cur-reload') {
      cur.rates = null;
      return loadRates();
    }
    if (a === 'wx-search') return wxSearch();
    if (a === 'tm-go') return timerStart(Math.max(1, Math.min(999, parseFloat(String(tm.input).replace(',', '.')) || 5)));
    if (a === 'tm-pause') {
      if (tm.running) {
        tm.paused = tm.end - Date.now();
        tm.running = false;
      } else {
        tm.end = Date.now() + tm.paused;
        tm.running = true;
      }
      return ctx.render();
    }
    if (a === 'tm-stop') {
      tm.running = false;
      tm.total = 0;
      return ctx.render();
    }
    if (a === 'sw-toggle') {
      if (tm.sw.running) {
        tm.sw.acc += Date.now() - tm.sw.start;
        tm.sw.running = false;
      } else {
        tm.sw.start = Date.now();
        tm.sw.running = true;
      }
      return ctx.render();
    }
    if (a === 'sw-lap') {
      tm.sw.laps.unshift(swTime());
      return ctx.render();
    }
    if (a === 'sw-reset') {
      tm.sw = { start: 0, acc: 0, running: false, laps: [] };
      return ctx.render();
    }
    if (a === 'pw-new') {
      pw.value = genPw();
      return ctx.render();
    }
    if (a === 'clip-clear') {
      clipList = await window.hub.tool.clipboard('clear');
      return ctx.render();
    }
    if (a === 'wc-add') {
      const z = document.getElementById('wc-add')?.value;
      const mine = ctx.state()?.settings?.worldclocks || ['America/New_York', 'Asia/Tokyo', 'Europe/London'];
      if (z) return ctx.settings({ worldclocks: [...mine, z] });
    }
  });

  const RENDER = {
    'tool-translate': translateHtml,
    'tool-calc': calcHtml,
    'tool-convert': convertHtml,
    'tool-currency': currencyHtml,
    'tool-weather': weatherHtml,
    'tool-notes': notesHtml,
    'tool-timer': timerHtml,
    'tool-password': pwHtml,
    'tool-clipboard': clipHtml,
    'tool-worldclock': wcHtml,
  };

  window.HubTools = {
    TOOLS,
    /** Weitere Mini-Apps anmelden (tools-extra.js). */
    register(id, meta, render) {
      TOOLS[id] = meta;
      RENDER[id] = render;
    },
    ctx: () => ctx,
    init(next) {
      ctx = { ...ctx, ...next };
    },
    html(id) {
      const t = TOOLS[id];
      if (!t || !RENDER[id]) return '';
      return `<div class="page tool-page" data-tool-page="${id}"><div class="tool-head">${window.appArt(id, 'tool-ic')}<div><h2>${esc(t.title)}</h2><p class="muted">${esc(t.desc)}</p></div></div>${RENDER[id]()}</div>`;
    },
    /** Kleine Status-Infos für das Kontrollzentrum. */
    timerStatus: () => (tm.running ? mmss(tm.end - Date.now()) : ''),
    /** Beim Start einmal prüfen, ob für den gespeicherten Ort ein Unwetter ansteht. */
    weatherCheck: () => {
      const city = ctx.state()?.settings?.weatherCity;
      if (city?.name && !wx.busy && !wx.data) wxLoad(city);
    },
    evaluate,
  };
})();
