'use strict';

/**
 * Revolution Client (Fabric mod) integration: installs the bundled jar into launcher
 * instances, adds Fabric API, and can set up a ready-to-play instance.
 */

const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const JAR_PATTERN = /^revolutionclient-([\d.]+)-([\d.]+)\.jar$/i;
const ANY_CLIENT_JAR = /^revolutionclient-.*\.jar$/i;

class RevolutionClient {
  constructor(getCore) {
    this.getCore = getCore;
  }

  jar() {
    const dirs = [path.join(process.resourcesPath || '', 'client'), path.join(app.getAppPath(), 'vendor', 'client')];
    for (const dir of dirs) {
      if (!fs.existsSync(dir)) continue;
      const file = fs.readdirSync(dir).find((name) => JAR_PATTERN.test(name));
      if (file) {
        const [, version, mcVersion] = JAR_PATTERN.exec(file);
        return { file: path.join(dir, file), name: file, version, mcVersion };
      }
    }
    return null;
  }

  modsDir(core, instanceId) {
    return path.join(core.paths.gameDir(instanceId), 'mods');
  }

  installedJar(core, instanceId) {
    const dir = this.modsDir(core, instanceId);
    if (!fs.existsSync(dir)) return null;
    return fs.readdirSync(dir).find((name) => ANY_CLIENT_JAR.test(name)) || null;
  }

  hasFabricApi(core, instanceId) {
    const dir = this.modsDir(core, instanceId);
    if (!fs.existsSync(dir)) return false;
    return fs.readdirSync(dir).some((name) => /^fabric-api/i.test(name));
  }

  async info() {
    const jar = this.jar();
    if (!jar) return { available: false, instances: [] };
    const core = await this.getCore();
    const list = await core.instances.listInstances();
    const instances = list.map((instance) => {
      const installed = this.installedJar(core, instance.id);
      return {
        id: instance.id,
        name: instance.name,
        icon: instance.icon,
        mcVersion: instance.mcVersion,
        loader: instance.loader?.type || 'vanilla',
        compatible: instance.loader?.type === 'fabric' && instance.mcVersion === jar.mcVersion,
        installed: Boolean(installed),
        current: installed === jar.name,
      };
    });
    return { available: true, version: jar.version, mcVersion: jar.mcVersion, instances };
  }

  async install(instanceId) {
    const jar = this.jar();
    if (!jar) throw new Error('Die Client-Datei fehlt in dieser Installation.');
    const core = await this.getCore();
    const instance = await core.instances.getInstance(instanceId);
    if (instance.loader?.type !== 'fabric') throw new Error('Der Revolution Client braucht eine Fabric-Instanz.');
    if (instance.mcVersion !== jar.mcVersion) {
      throw new Error(`Der Client ist für Minecraft ${jar.mcVersion}, die Instanz nutzt ${instance.mcVersion}.`);
    }

    const dir = this.modsDir(core, instanceId);
    fs.mkdirSync(dir, { recursive: true });
    for (const name of fs.readdirSync(dir)) {
      if (ANY_CLIENT_JAR.test(name) && name !== jar.name) fs.rmSync(path.join(dir, name), { force: true });
    }
    fs.copyFileSync(jar.file, path.join(dir, jar.name));

    let warning = '';
    if (!this.hasFabricApi(core, instanceId)) {
      try {
        const versions = await core.content.getProjectVersions('fabric-api', { mcVersion: jar.mcVersion, loader: 'fabric' });
        if (!versions.length) throw new Error('keine passende Version');
        const project = await core.content.getProject('fabric-api');
        await core.content.installContent({ instanceId, project, version: versions[0] });
      } catch (error) {
        warning = `Fabric API konnte nicht automatisch geladen werden (${error.message}). Installiere sie im Minecraft-Bereich unter „Mods“.`;
      }
    }
    return { ok: true, warning };
  }

  async createInstance(onProgress = () => {}) {
    const jar = this.jar();
    if (!jar) throw new Error('Die Client-Datei fehlt in dieser Installation.');
    const core = await this.getCore();
    onProgress('Fabric wird gesucht …');
    const loaders = await core.loaders.listLoaderVersions('fabric', jar.mcVersion, { limit: 20 });
    const loader = loaders.find((entry) => entry.stable !== false) || loaders[0];
    if (!loader) throw new Error(`Für Minecraft ${jar.mcVersion} gibt es noch keinen Fabric Loader.`);

    onProgress('Instanz wird angelegt …');
    const instance = await core.instances.createInstance({
      name: 'Revolution Client',
      icon: '⚡',
      group: 'Revolution',
      mcVersion: jar.mcVersion,
      versionId: jar.mcVersion,
      loader: { type: 'fabric', version: loader.version },
    });
    await core.instances.ensureInstanceDirs(instance.id);

    onProgress('Fabric wird installiert …');
    const result = await core.loaders.installLoader({ mcVersion: jar.mcVersion, type: 'fabric', loaderVersion: loader.version });
    await core.instances.updateInstance(instance.id, { versionId: result.versionId });

    onProgress('Client wird installiert …');
    const install = await this.install(instance.id);
    return { id: instance.id, warning: install.warning };
  }

  async openMods(instanceId) {
    const core = await this.getCore();
    const dir = this.modsDir(core, instanceId);
    fs.mkdirSync(dir, { recursive: true });
    return dir;
  }
}

module.exports = { RevolutionClient };
