const card = document.getElementById('card');
const wallEl = document.getElementById('wall');
const rowsEl = document.getElementById('rows');

const CIRCUMFERENCE = 94.25;
let signature = '';
let nodes = {};
let sparkHistory = [];
let lastWall = '';

function ringHtml(id) {
  return `<svg class="ring" viewBox="0 0 36 36"><circle class="track" cx="18" cy="18" r="15"></circle><circle class="value" id="${id}" cx="18" cy="18" r="15" transform="rotate(-90 18 18)"></circle></svg>`;
}

function buildRows(rows) {
  rowsEl.replaceChildren();
  nodes = {};
  const template = document.createElement('template');

  for (const key of rows) {
    let html = '';
    if (key === 'fps') {
      html = `
        <div class="row fps">
          <span class="k" data-node="fpsLabel">Hz</span>
          <span class="big" data-node="fps">–</span>
          <span class="sub" data-node="ms"></span>
          <svg class="spark" viewBox="0 0 240 18" preserveAspectRatio="none"><path data-node="spark" d=""></path></svg>
        </div>`;
    } else if (key === 'cpu') {
      html = `<div class="row"><span class="k">CPU</span>${ringHtml('cpuRing')}<span class="big" data-node="cpu">0%</span><span class="sub" data-node="cpuTemp"></span></div>`;
    } else if (key === 'gpu') {
      html = `<div class="row"><span class="k">GPU</span>${ringHtml('gpuRing')}<span class="big" data-node="gpu">0%</span><span class="sub" data-node="gpuTemp"></span></div>`;
    } else if (key === 'ram') {
      html = `<div class="row"><span class="k">RAM</span>${ringHtml('ramRing')}<span class="big" data-node="ram">0 GB</span><span class="sub" data-node="ramTotal"></span></div>`;
    } else if (key === 'ping') {
      html = `<div class="row"><span class="k">PING</span><span class="dot" data-node="pingDot"></span><span class="big" data-node="ping">– ms</span></div>`;
    }
    if (!html) continue;
    template.innerHTML = html.trim();
    const row = template.content.firstElementChild;
    rowsEl.appendChild(row);
    for (const node of row.querySelectorAll('[data-node]')) {
      nodes[node.dataset.node] = node;
    }
    // Die Ringe liegen als SVG in der Zeile und haben eine feste ID.
    for (const id of ['cpuRing', 'gpuRing', 'ramRing']) {
      const ring = row.querySelector(`#${id}`);
      if (ring) nodes[id] = ring;
    }
  }
}

function setRing(id, percent) {
  const ring = nodes[id];
  if (!ring) return;
  const value = Math.min(100, Math.max(0, Number(percent) || 0));
  ring.style.strokeDashoffset = String(CIRCUMFERENCE * (1 - value / 100));
  // Grün bis 60 %, gelb bis 85 %, darüber rot – wie im Referenzbild.
  ring.style.stroke = value >= 85 ? '#ff5b6e' : value >= 60 ? '#ffc24b' : '#3ce88f';
}

function setText(name, text) {
  const node = nodes[name];
  if (node) node.textContent = text;
}

function setWall(src) {
  if (!src) {
    wallEl.hidden = true;
    wallEl.removeAttribute('src');
    lastWall = '';
    return;
  }
  wallEl.hidden = false;
  if (lastWall !== src) {
    lastWall = src;
    wallEl.src = src;
  }
  const played = wallEl.play();
  if (played && typeof played.catch === 'function') played.catch(() => {});
}

function setShade(value) {
  const pct = Number(value);
  if (!Number.isFinite(pct)) return;
  const bottom = Math.min(1, Math.max(0, pct / 100));
  const top = bottom * 0.85;
  document.getElementById('shade').style.background =
    `linear-gradient(180deg, rgba(8, 9, 13, ${top.toFixed(3)}), rgba(8, 9, 13, ${bottom.toFixed(3)}))`;
  document.getElementById('card').style.background =
    `rgba(12, 10, 14, ${(0.08 + 0.47 * bottom).toFixed(3)})`;
}

function paintSpark(fps) {
  sparkHistory.push(Number(fps) || 0);
  if (sparkHistory.length > 48) sparkHistory.shift();
  const path = nodes.spark;
  if (!path) return;
  const values = sparkHistory;
  const max = Math.max(...values, 30);
  const step = 240 / Math.max(1, values.length - 1);
  let d = '';
  values.forEach((value, index) => {
    const x = Number((index * step).toFixed(2));
    const y = Number((16 - (value / max) * 14).toFixed(2));
    d += `${index === 0 ? 'M' : 'L'}${x} ${y}`;
  });
  path.setAttribute('d', d);
}

function apply(payload) {
  const factor = Math.min(2, Math.max(0.35, Number(payload.scale) || 0.45));
  document.documentElement.style.zoom = String(factor);

  const rows = Array.isArray(payload.rows) ? payload.rows : ['fps', 'cpu', 'gpu', 'ram'];
  const next = rows.join(',');
  if (next !== signature) {
    signature = next;
    buildRows(rows);
    sparkHistory = [];
  }

  setWall(payload.wall);
  setShade(payload.shade);

  if (nodes.fpsLabel) setText('fpsLabel', payload.fpsLabel === 'FPS' ? 'FPS' : 'Hz');
  if (nodes.fps) setText('fps', String(Math.round(Number(payload.fps) || 0)));
  if (nodes.ms) setText('ms', `${Number(payload.ms) || 0} ms`);
  paintSpark(payload.fps);

  setRing('cpuRing', payload.cpu);
  setText('cpu', `${Math.round(Number(payload.cpu) || 0)}%`);
  setText('cpuTemp', payload.temp ? `${payload.temp}°C` : '');

  setRing('gpuRing', payload.gpu);
  setText('gpu', `${Math.round(Number(payload.gpu) || 0)}%`);
  setText('gpuTemp', '');

  const used = Number(payload.ram) || 0;
  const total = Number(payload.ramTotal) || 0;
  setRing('ramRing', total > 0 ? (used / total) * 100 : 0);
  setText('ram', `${used.toFixed(1)} GB`);
  setText('ramTotal', total > 0 ? `/ ${total.toFixed(1)} GB` : '');

  if (nodes.pingDot) {
    const ping = Number(payload.ping);
    const ok = Number.isFinite(ping) && ping > 0;
    nodes.pingDot.style.background = !ok ? '#8b93a7' : ping > 90 ? '#ff5b6e' : ping > 45 ? '#ffc24b' : '#3ce88f';
  }
  setText('ping', Number.isFinite(Number(payload.ping)) && Number(payload.ping) > 0 ? `${payload.ping} ms` : '– ms');

  card.classList.add('is-on');
}

if (window.perfOverlay) {
  window.perfOverlay.onUpdate(apply);
  window.perfOverlay.ready();
} else {
  // Vorschau im Browser (Design-Entwicklung) – ohne App-Daten.
  apply({
    fps: 120,
    ms: 8.3,
    cpu: 54,
    gpu: 69,
    ram: 4.3,
    ramTotal: 15.9,
    temp: 67,
    ping: 18,
    rows: ['fps', 'cpu', 'gpu', 'ram', 'ping'],
    scale: 1,
  });
}
