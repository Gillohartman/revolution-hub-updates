'use strict';

/*
 * App-Symbole des Hubs: gefüllte Zeichen auf einer farbigen Kachel (48×48).
 * Weiß = Hauptform, currentColor = Aussparungen in der Farbe der Kachel.
 * Überall gleich: Dock, Starter, Startseite und Mini-Apps.
 */
(function () {
  const W = 'fill="#fff"';
  const C = 'fill="currentColor"';
  const line = (d, w = 2.4, extra = '') => `<path d="${d}" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
  const wline = (d, w = 3.2, extra = '') => `<path d="${d}" fill="none" stroke="#fff" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
  const dots = (pts, r = 2.1, extra = '') => pts.map(([x, y]) => `<circle cx="${x}" cy="${y}" r="${r}" ${C} ${extra}/>`).join('');
  const txt = (s, x, y, size, extra = '') => `<text x="${x}" y="${y}" font-size="${size}" font-weight="800" text-anchor="middle" ${C} font-family="'Segoe UI', system-ui, sans-serif" ${extra}>${s}</text>`;
  const teeth = [0, 45, 90, 135, 180, 225, 270, 315].map((a) => `<rect x="20.6" y="5.5" width="6.8" height="10" rx="2.2" ${W} transform="rotate(${a} 24 24)"/>`).join('');
  const grid = ['#ff6b6b', '#ffb84d', '#ffe14d', '#5ee08a', '#4dd2ff', '#6f8cff', '#b47bff', '#ff7ad1', '#e9edf5']
    .map((c, i) => `<rect x="${9 + (i % 3) * 11}" y="${9 + Math.floor(i / 3) * 11}" width="8" height="8" rx="2.6" fill="${c}"/>`)
    .join('');

  const ART = {
    home: ['#b79cff', '#6a3cf0', `<path d="M10 22.5V38a2.5 2.5 0 0 0 2.5 2.5H19V30a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v10.5h6.500A2.500 2.500 0 0 0 38 38V22.500L24 11Z" ${W}/>${wline('M6 22.500 24 8l18 14.500', 3.4)}`],
    dropzone: ['#74bcff', '#2b67f0', `<path d="M6.500 14.500a3.500 3.500 0 0 1 3.500-3.500h8.300a3 3 0 0 1 2.100.900l2.700 2.600H38a3.500 3.500 0 0 1 3.500 3.500V22h-35Z" ${W} opacity=".62"/><rect x="6.500" y="18.500" width="35" height="20.500" rx="4" ${W}/>`],
    gaming: ['#ff80ac', '#d61c5c', `<path d="M15 15.500h18a9.500 9.500 0 0 1 9.500 9.500v2.500c0 4.400-2.300 8-5.400 8-2.200 0-3.700-1.400-5.100-3.500l-.9-1.500H16.900l-.9 1.500c-1.400 2.100-2.900 3.500-5.100 3.500-3.100 0-5.400-3.600-5.400-8V25a9.500 9.500 0 0 1 9.500-9.500Z" ${W}/><path d="M14.200 20.300h3.200v2.900h2.900v3.200h-2.900v2.900h-3.200v-2.900h-2.900v-3.200h2.900Z" ${C}/>${dots([[30.3, 27.2], [35, 22.4]], 2.2)}`],
    orbit: ['#8f7dff', '#3d2bbf', `<rect x="6.500" y="15.500" width="35" height="17" rx="8.500" fill="#0a0a12" stroke="#fff" stroke-opacity=".9" stroke-width="2"/><circle cx="33" cy="24" r="3.200" fill="#6dffb0"/>${wline('M13.500 22.800v2.400M17.800 20.500v7M22.100 22v4', 2.4)}`],
    screenshot: ['#63d6ff', '#127dd6', `${wline('M8 16.500V12a4 4 0 0 1 4-4h4.500M31.500 8H36a4 4 0 0 1 4 4v4.500M40 31.500V36a4 4 0 0 1-4 4h-4.500M16.500 40H12a4 4 0 0 1-4-4v-4.500', 3.4)}<circle cx="24" cy="24" r="7.500" ${W}/><circle cx="24" cy="24" r="3.200" ${C}/>`],
    video: ['#ffc566', '#ee6c0a', `<path d="m7.300 17.900 30.900-8.300a2.200 2.200 0 0 1 2.700 1.600l.7 2.700-33.500 9Z" ${W} opacity=".66"/><rect x="7" y="20" width="34" height="20.500" rx="4" ${W}/><path d="M20.800 25.300v9.900l8.600-4.950Z" ${C}/>`],
    docs: ['#93b8ff', '#3b5be6', `<path d="M14 5.500h13.500L38 16v23.500a3 3 0 0 1-3 3H14a3 3 0 0 1-3-3v-31a3 3 0 0 1 3-3Z" ${W}/><path d="M27.500 5.500V13a3 3 0 0 0 3 3H38Z" ${C} opacity=".38"/>${line('M16.500 23.500h15M16.500 29h15M16.500 34.500h9', 2.6, 'opacity=".85"')}`],
    chess: ['#a2d766', '#467a24', `<path d="M19.500 35.500c.6-4.900 2.100-8.300 4.600-11.200-3.300.4-6.200 1.900-8.900 4L12.500 24c1.200-5.800 4.600-11.200 9.500-14.500l-1.200-4.200 4.800 2.500c6.600.8 10.900 6.600 10.900 14.500v13.200Z" ${W}/><rect x="13" y="36.500" width="25" height="5.500" rx="2.750" ${W}/><circle cx="25.800" cy="15.600" r="1.600" ${C}/>`],
    agenda: ['#ff9070', '#e02f63', `${wline('M16 6.500v6M32 6.500v6', 3.2)}<rect x="8" y="10" width="32" height="31" rx="5.500" ${W}/><path d="M8 15.500A5.500 5.500 0 0 1 13.500 10h21a5.500 5.500 0 0 1 5.500 5.500V19H8Z" ${C} opacity=".5"/>${dots([[16, 26.500], [24, 26.500], [32, 26.500], [16, 33.500], [24, 33.500]], 2.2)}`],
    chats: ['#62e6ae', '#0d966c', `<path d="M24 8c9.400 0 17 6.300 17 14s-7.600 14-17 14c-1.900 0-3.700-.25-5.400-.7L11 39.500l1.900-6.300C9.300 30.600 7 26.500 7 22 7 14.300 14.600 8 24 8Z" ${W}/>${dots([[17, 22], [24, 22], [31, 22]], 2.2)}`],
    geo: ['#56d98f', '#0a7b8c', `<circle cx="24" cy="24" r="16.500" ${W}/>${line('M7.500 24h33M24 7.500c5 4.600 7.500 10.100 7.500 16.500S29 35.900 24 40.500c-5-4.600-7.500-10.100-7.500-16.500S19 12.100 24 7.500ZM10.500 15.500h27M10.500 32.500h27', 2.1)}`],
    shop: ['#ffd964', '#f29a05', `${wline('M17.500 18v-3a6.500 6.500 0 0 1 13 0v3', 3.2, 'opacity=".8"')}<path d="M10.500 17h27l-1.900 21.300a3 3 0 0 1-3 2.700H15.400a3 3 0 0 1-3-2.700Z" ${W}/>${dots([[17.500, 23], [30.500, 23]], 1.900)}`],
    settings: ['#b0bac9', '#525c6b', `${teeth}<circle cx="24" cy="24" r="12.500" ${W}/><circle cx="24" cy="24" r="5.200" ${C}/>`],
    control: ['#767f92', '#272c38', `<rect x="8" y="10" width="32" height="12" rx="6" ${W} opacity=".5"/><circle cx="34" cy="16" r="4.300" ${W}/><rect x="8" y="26" width="32" height="12" rx="6" ${W} opacity=".5"/><circle cx="14" cy="32" r="4.300" ${W}/>`],
    launcher: ['#434961', '#151823', grid],
    'tool-translate': ['#62c9ff', '#275fe6', `<rect x="5.500" y="7.500" width="23" height="21" rx="4.500" ${W}/>${txt('A', 17, 23.800, 16)}<rect x="20.500" y="21.500" width="22" height="19.500" rx="4.500" ${W} opacity=".72"/>${txt('文', 31.500, 36, 13)}`],
    'tool-calc': ['#ffb945', '#de7603', `<rect x="11" y="5.500" width="26" height="37" rx="5.500" ${W}/><rect x="15" y="9.500" width="18" height="8.500" rx="2.500" ${C} opacity=".65"/>${dots([[17.500, 24], [24, 24], [30.500, 24], [17.500, 30.200], [24, 30.200], [30.500, 30.200], [17.500, 36.400], [24, 36.400], [30.500, 36.400]], 2.1)}`],
    'tool-convert': ['#55e3aa', '#058f67', `<rect x="5.500" y="15" width="37" height="18" rx="4" ${W}/>${line('M11.500 15.500v7M17.700 15.500v4.500M23.900 15.500v7M30.100 15.500v4.500M36.300 15.500v7', 2.4)}`],
    'tool-currency': ['#bdf05a', '#4b8a0e', `<circle cx="24" cy="24" r="16.500" ${W}/><circle cx="24" cy="24" r="12.800" fill="none" stroke="currentColor" stroke-width="1.500" opacity=".35"/>${txt('€', 23.500, 31, 20)}`],
    'tool-weather': ['#74bcff', '#1a52d6', `<circle cx="17.500" cy="16.500" r="7.500" fill="#ffd84d"/><path d="M17.500 3.500v2.800M7.200 6.200l2 2M4.500 16.500h2.800M27.800 6.200l-2 2" fill="none" stroke="#ffd84d" stroke-width="2.600" stroke-linecap="round"/><path d="M15.500 39.500a8 8 0 0 1-.7-15.970 10.200 10.200 0 0 1 19.300-1.700 8.900 8.900 0 0 1-.6 17.670Z" ${W}/>`],
    'tool-notes': ['#ffe873', '#dd9c06', `<rect x="10" y="6.500" width="28" height="35" rx="5" ${W}/><path d="M10 11.500a5 5 0 0 1 5-5h18a5 5 0 0 1 5 5V15H10Z" ${C} opacity=".5"/>${line('M15.500 22h17M15.500 28h17M15.500 34h10', 2.4, 'opacity=".8"')}`],
    'tool-timer': ['#ff8fa0', '#df1f4c', `${wline('M20 6h8M24 6v6.500M36.200 13.300l2.300 2.300', 3.4)}<circle cx="24" cy="27.500" r="14" ${W}/>${line('M24 27.500v-8.500', 3)}<circle cx="24" cy="27.500" r="2.300" ${C}/>`],
    'tool-password': ['#a1aec0', '#455266', `${wline('M16 21v-6a8 8 0 0 1 16 0v6', 3.6, 'opacity=".8"')}<rect x="9.500" y="20" width="29" height="21.500" rx="5.500" ${W}/>${dots([[17.200, 30.700], [24, 30.700], [30.800, 30.700]], 2.3)}`],
    'tool-clipboard': ['#d2a0ff', '#7733e3', `<rect x="10" y="9" width="28" height="33" rx="5" ${W}/><rect x="17" y="5" width="14" height="8.500" rx="3.200" ${W} stroke="currentColor" stroke-width="2"/>${line('M16 22.500h16M16 28.500h16M16 34.500h9', 2.4, 'opacity=".8"')}`],
    'tool-autoclick': ['#ff8fc7', '#c2185b', `<path d="M17 15.500 35.500 24l-7.300 2.600L33 37l-3.600 1.700-4.800-10.300-5.600 5.300Z" ${W}/>${wline('M11.500 6.500v4.500M4.500 13.500H9M6.500 7.500l3 3M17.500 7.500l-2.500 2.500', 2.8, 'opacity=".85"')}`],
    'tool-shield': ['#5fe0a6', '#04795a', `<path d="M24 5.500 9.500 11v11.500c0 9 6.200 15.800 14.500 18 8.300-2.200 14.500-9 14.500-18V11Z" ${W}/>${line('m17 23.500 5 5 9.500-10.500', 3.4)}`],
    'tool-schematics': ['#6ee7a0', '#15803d', `<path d="m24 6 16 8.5v19L24 42 8 33.5v-19Z" ${W}/><path d="m8 14.5 16 8.5 16-8.5M24 23v19" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"/><path d="M14 22.5v6l5 2.7v-6Z" ${C} opacity=".55"/>`],
    'tool-account': ['#b6a4ff', '#4f46e5', `<circle cx="24" cy="17" r="8" ${W}/><path d="M9 40c1.5-8 7.5-12.5 15-12.5S37.5 32 39 40Z" ${W}/><circle cx="35" cy="34" r="6.5" fill="#22c55e" stroke="currentColor" stroke-width="2"/>${line('m32.3 34 1.8 1.8 3.4-3.6', 2)}`],
    'tool-football': ['#6ee58f', '#118a3e', `<circle cx="24" cy="24" r="16.5" ${W}/><path d="M24 15.5l6.4 4.6-2.4 7.6h-8l-2.4-7.6Z" ${C}/>${line('M24 15.5V8.4M30.4 20.1l6.9-2.3M28 27.7l4.3 5.9M20 27.7l-4.3 5.9M17.6 20.1l-6.9-2.3', 1.8, 'opacity=".75"')}`],
    'tool-screentime': ['#a78bfa', '#5b21b6', `<path d="M14 8h20M14 40h20" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/><path d="M16 8c0 9 16 9 16 16S16 31 16 40h16c0-9-16-9-16-16S32 17 32 8Z" ${W}/><path d="M19 37c2-3 8-3 10 0Z" ${C} opacity=".55"/>`],
    'tool-phone': ['#60a5fa', '#1d4ed8', `<rect x="14" y="5.5" width="20" height="37" rx="5" ${W}/><rect x="17" y="10" width="14" height="25" rx="1.6" ${C} opacity=".35"/><circle cx="24" cy="38.5" r="1.6" ${C}/>`],
    'tool-worldclock': ['#4ce3d0', '#0c7c74', `<circle cx="24" cy="24" r="16.500" ${W}/>${line('M24 13.500V24l6.800 4.200', 3)}${dots([[24, 9.800], [38.200, 24], [24, 38.200], [9.800, 24]], 1.100, 'opacity=".6"')}`],
  };

  /** Farbige Kachel mit dem Symbol der App. */
  window.appArt = (id, cls = '') => {
    const a = ART[id] || ART.home;
    return `<span class="app-art ${cls}" style="--a:${a[0]};--b:${a[1]}"><svg viewBox="0 0 48 48" aria-hidden="true">${a[2]}</svg></span>`;
  };
  window.APP_ART = ART;
})();
