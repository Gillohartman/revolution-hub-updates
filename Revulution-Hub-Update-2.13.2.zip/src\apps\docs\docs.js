'use strict';

const $ = (selector) => document.querySelector(selector);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
const api = window.docs;
const paper = $('#paper');

const doc = { file: null, dirty: false, zoom: 1 };
let savedRange = null;

const FONTS = ['Calibri', 'Segoe UI', 'Arial', 'Times New Roman', 'Georgia', 'Cambria', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Garamond', 'Consolas', 'Courier New', 'Comic Sans MS'];
const SIZES = [8, 9, 10, 10.5, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 60, 72];
const STYLES = [
  ['p', 'Standard'],
  ['title', 'Titel'],
  ['h1', 'Überschrift 1'],
  ['h2', 'Überschrift 2'],
  ['h3', 'Überschrift 3'],
  ['blockquote', 'Zitat'],
  ['pre', 'Code'],
];
const TEXT_COLORS = ['#1d1d24', '#595959', '#a6a6a6', '#ffffff', '#c00000', '#ff0000', '#ffc000', '#ffff00', '#92d050', '#00b050', '#00b0f0', '#0070c0', '#002060', '#7030a0', '#8b6cff', '#e83e8c'];
const MARK_COLORS = ['transparent', '#ffff00', '#00ff00', '#00ffff', '#ff66cc', '#ffc000', '#b4c7e7', '#d9d2e9'];

/* ------------------------------------------------------------------ helpers */
const svg = (inner, size = 17) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
const I = {
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
  redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H9a5 5 0 0 0 0 10h3"/>',
  left: '<path d="M4 6h16M4 10h10M4 14h16M4 18h10"/>',
  center: '<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>',
  right: '<path d="M4 6h16M10 10h10M4 14h16M10 18h10"/>',
  justify: '<path d="M4 6h16M4 10h16M4 14h16M4 18h16"/>',
  bullets: '<circle cx="5" cy="7" r="1.2" fill="currentColor"/><circle cx="5" cy="12" r="1.2" fill="currentColor"/><circle cx="5" cy="17" r="1.2" fill="currentColor"/><path d="M10 7h10M10 12h10M10 17h10"/>',
  numbers: '<path d="M4 5h1.5v4M4 9h3M4 14.5c0-1 2.5-1.5 2.5 0 0 1-2.5 2-2.5 3h3M10 7h10M10 12h10M10 17h10"/>',
  outdent: '<path d="M4 6h16M11 10h9M11 14h9M4 18h16M8 9l-3 3 3 3"/>',
  indent: '<path d="M4 6h16M11 10h9M11 14h9M4 18h16M5 9l3 3-3 3"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
  shot: '<path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/>',
  table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16M15 4v16"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1"/><path d="M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1"/>',
  hr: '<path d="M3 12h18"/>',
  pagebreak: '<path d="M6 3v5h12V3M6 21v-5h12v5M3 12h2M8 12h2M13 12h2M18 12h3"/>',
  clear: '<path d="M6 4h12M12 4l-3 16M4 20l16-16" />',
  find: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  rowAdd: '<rect x="3" y="4" width="18" height="10" rx="2"/><path d="M12 17v4M10 19h4"/>',
  colAdd: '<rect x="3" y="3" width="10" height="18" rx="2"/><path d="M17 12h4M19 10v4"/>',
  rowDel: '<rect x="3" y="4" width="18" height="10" rx="2"/><path d="M10 19h4"/>',
  colDel: '<rect x="3" y="3" width="10" height="18" rx="2"/><path d="M17 12h4"/>',
  date: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
};

function toast(message, kind = '') {
  document.querySelector('.toast')?.remove();
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = String(message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  document.body.appendChild(el);
  setTimeout(() => el.remove(), kind === 'error' ? 6000 : 2800);
}

function exec(command, value = null) {
  restoreSelection();
  document.execCommand('styleWithCSS', false, true);
  document.execCommand(command, false, value);
  changed();
  updateState();
}

function saveSelection() {
  const sel = window.getSelection();
  if (sel.rangeCount && paper.contains(sel.anchorNode)) savedRange = sel.getRangeAt(0).cloneRange();
}

function restoreSelection() {
  paper.focus({ preventScroll: true });
  if (!savedRange) return;
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(savedRange);
}

function currentBlock() {
  const sel = window.getSelection();
  let node = sel.anchorNode;
  while (node && node !== paper) {
    if (node.nodeType === 1 && /^(P|H1|H2|H3|H4|BLOCKQUOTE|PRE|LI|DIV|TD|TH)$/.test(node.tagName)) return node;
    node = node.parentNode;
  }
  return null;
}

function selectedBlocks() {
  const sel = window.getSelection();
  if (!sel.rangeCount) return [];
  const range = sel.getRangeAt(0);
  const all = [...paper.querySelectorAll('p, h1, h2, h3, h4, blockquote, pre, li')];
  const hit = all.filter((el) => range.intersectsNode(el) && !el.querySelector('p, h1, h2, h3, li'));
  const own = currentBlock();
  return hit.length ? hit : own ? [own] : [];
}

/* ------------------------------------------------------------------ ribbon */
function rb(cmd, icon, title, extra = '') {
  return `<button class="rb" data-cmd="${cmd}" title="${title}" ${extra}>${icon}</button>`;
}

function buildRibbon() {
  $('#ribbon').innerHTML = `
    <div class="group">${rb('undo', svg(I.undo), 'Rückgängig (Strg+Z)')}${rb('redo', svg(I.redo), 'Wiederholen (Strg+Y)')}</div>
    <span class="sep"></span>
    <select class="select" id="style" title="Formatvorlage">${STYLES.map(([v, t]) => `<option value="${v}">${t}</option>`).join('')}</select>
    <select class="select" id="font" title="Schriftart">${FONTS.map((f) => `<option value="${f}" style="font-family:'${f}'">${f}</option>`).join('')}</select>
    <select class="select" id="size" title="Schriftgröße">${SIZES.map((s) => `<option value="${s}">${String(s).replace('.', ',')}</option>`).join('')}</select>
    <span class="sep"></span>
    <div class="group">
      ${rb('bold', '<b>F</b>', 'Fett (Strg+B)')}
      ${rb('italic', '<i style="font-family:Georgia">K</i>', 'Kursiv (Strg+I)')}
      ${rb('underline', '<u>U</u>', 'Unterstrichen (Strg+U)')}
      ${rb('strikeThrough', '<s>S</s>', 'Durchgestrichen')}
      ${rb('superscript', 'x²', 'Hochgestellt')}
      ${rb('subscript', 'x₂', 'Tiefgestellt')}
      ${rb('color', `A<span class="bar" id="color-bar" style="background:#c00000"></span>`, 'Schriftfarbe')}
      ${rb('mark', `${svg('<path d="M9 15l-3 5h7l1-2M9 15l6-11 4 2-6 11Z"/>', 16)}<span class="bar" id="mark-bar" style="background:#ffff00"></span>`, 'Texthervorhebung')}
      ${rb('removeFormat', svg(I.clear), 'Formatierung löschen')}
    </div>
    <span class="sep"></span>
    <div class="group">
      ${rb('justifyLeft', svg(I.left), 'Linksbündig')}${rb('justifyCenter', svg(I.center), 'Zentriert')}${rb('justifyRight', svg(I.right), 'Rechtsbündig')}${rb('justifyFull', svg(I.justify), 'Blocksatz')}
    </div>
    <span class="sep"></span>
    <div class="group">
      ${rb('insertUnorderedList', svg(I.bullets), 'Aufzählung')}${rb('insertOrderedList', svg(I.numbers), 'Nummerierung')}${rb('outdent', svg(I.outdent), 'Einzug verkleinern')}${rb('indent', svg(I.indent), 'Einzug vergrößern')}
      <select class="select" id="spacing" title="Zeilenabstand"><option value="1">1,0</option><option value="1.15">1,15</option><option value="1.5" selected>1,5</option><option value="2">2,0</option><option value="2.5">2,5</option></select>
    </div>
    <span class="sep"></span>
    <div class="group">
      ${rb('image', svg(I.image), 'Bild einfügen')}${rb('shot', svg(I.shot), 'Screenshot einfügen')}${rb('table', svg(I.table), 'Tabelle einfügen')}${rb('link', svg(I.link), 'Link einfügen (Strg+K)')}${rb('hr', svg(I.hr), 'Trennlinie')}${rb('pagebreak', svg(I.pagebreak), 'Seitenumbruch (Strg+Enter)')}${rb('date', svg(I.date), 'Datum einfügen')}
    </div>
    <div class="group" id="table-tools" hidden>
      <span class="sep"></span>
      ${rb('rowAdd', svg(I.rowAdd), 'Zeile darunter einfügen')}${rb('colAdd', svg(I.colAdd), 'Spalte rechts einfügen')}${rb('rowDel', svg(I.rowDel), 'Zeile löschen')}${rb('colDel', svg(I.colDel), 'Spalte löschen')}
    </div>
    <span class="sep"></span>
    <div class="group">
      ${rb('toc', svg('<path d="M4 6h10M4 12h16M8 18h12"/><circle cx="20" cy="6" r="1"/>'), 'Inhaltsverzeichnis aus den Überschriften')}${rb('checklist', svg('<rect x="3" y="4" width="6" height="6" rx="1.5"/><path d="m4.5 7 1.2 1.2L8 6M13 7h8M3 15h6v6H3zM13 18h8"/>'), 'Checkliste')}${rb('quote', svg('<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>'), 'Zitat')}${rb('code', svg('<path d="m8 8-4 4 4 4M16 8l4 4-4 4M13.5 5l-3 14"/>'), 'Code-Block')}${rb('symbols', '<b style="font-size:15px">Ω</b>', 'Sonderzeichen & Emojis')}${rb('case', '<b style="font-size:12px">Aa</b>', 'Groß-/Kleinschreibung ändern')}
    </div>
    <span class="sep"></span>
    ${rb('find', svg(I.find), 'Suchen & Ersetzen (Strg+F)')}${rb('speak', svg('<path d="M11 5 6 9H3v6h3l5 4Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>'), 'Vorlesen (nochmal klicken stoppt)')}${rb('focus', svg('<path d="M4 9V5h4M20 9V5h-4M4 15v4h4M20 15v4h-4"/>'), 'Fokusmodus (Esc beendet)')}`;
  $('#font').value = 'Calibri';
  $('#size').value = '11';
}

function buildMenu() {
  $('#menu').innerHTML = `
    <button class="btn small" data-cmd="new">${icon('plus', 15)} Neu</button>
    <button class="btn small" data-cmd="openMenu">${icon('folder', 15)} Öffnen</button>
    <button class="btn small primary" data-cmd="save">${icon('download', 15)} Speichern</button>
    <button class="btn small" data-cmd="saveAs">Speichern unter …</button>
    <button class="btn small" data-cmd="pdf">PDF</button>
    <button class="btn small icon" data-cmd="print" title="Drucken (Strg+P)">${svg('<path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1h-2M6 14h12v7H6z"/>', 16)}</button>`;
  $('#doc-icon').innerHTML = icon('doc', 20);
}

/** Highlights the ribbon buttons for the formatting at the cursor. */
function updateState() {
  for (const cmd of ['bold', 'italic', 'underline', 'strikeThrough', 'superscript', 'subscript', 'justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'insertUnorderedList', 'insertOrderedList']) {
    const button = document.querySelector(`[data-cmd="${cmd}"]`);
    if (button) button.classList.toggle('on', document.queryCommandState(cmd));
  }
  const block = currentBlock();
  if (block) {
    const tag = block.tagName.toLowerCase();
    $('#style').value = tag === 'h1' && block.dataset.style === 'title' ? 'title' : STYLES.some(([v]) => v === tag) ? tag : 'p';
  }
  const sel = window.getSelection();
  const el = sel.anchorNode?.nodeType === 1 ? sel.anchorNode : sel.anchorNode?.parentElement;
  if (el && paper.contains(el)) {
    const cs = getComputedStyle(el);
    const family = cs.fontFamily.split(',')[0].replace(/["']/g, '').trim();
    if (FONTS.includes(family)) $('#font').value = family;
    const pt = Math.round(parseFloat(cs.fontSize) * 0.75 * 2) / 2;
    if (!SIZES.includes(pt)) {
      const option = document.createElement('option');
      option.value = String(pt);
      option.textContent = String(pt).replace('.', ',');
      $('#size').appendChild(option);
    }
    $('#size').value = String(pt);
  }
  $('#table-tools').hidden = !el?.closest?.('td, th');
}

/* ------------------------------------------------------------------ actions */
function setStyle(value) {
  restoreSelection();
  if (value === 'title') {
    document.execCommand('formatBlock', false, 'h1');
    const block = currentBlock();
    if (block) block.dataset.style = 'title';
  } else {
    document.execCommand('formatBlock', false, value);
    const block = currentBlock();
    if (block) delete block.dataset.style;
  }
  changed();
  updateState();
}

function setFontSize(pt) {
  restoreSelection();
  document.execCommand('styleWithCSS', false, false);
  document.execCommand('fontSize', false, '7');
  for (const font of paper.querySelectorAll('font[size="7"]')) {
    const span = document.createElement('span');
    span.style.fontSize = `${pt}pt`;
    span.innerHTML = font.innerHTML;
    font.replaceWith(span);
  }
  for (const span of paper.querySelectorAll('span[style*="xxx-large"]')) span.style.fontSize = `${pt}pt`;
  changed();
}

function setSpacing(value) {
  restoreSelection();
  for (const block of selectedBlocks()) block.style.lineHeight = value;
  changed();
}

function insertHtml(html) {
  restoreSelection();
  document.execCommand('insertHTML', false, html);
  changed();
}

function popAt(anchor, html) {
  const pop = $('#pop');
  pop.innerHTML = html;
  pop.hidden = false;
  const r = anchor.getBoundingClientRect();
  pop.style.left = `${Math.min(r.left, innerWidth - pop.offsetWidth - 10)}px`;
  pop.style.top = `${r.bottom + 6}px`;
}

function closePop() {
  $('#pop').hidden = true;
}

function tableCell() {
  const sel = window.getSelection();
  const el = sel.anchorNode?.nodeType === 1 ? sel.anchorNode : sel.anchorNode?.parentElement;
  return el?.closest?.('td, th');
}

function tableAction(kind) {
  const cell = tableCell();
  if (!cell) return;
  const row = cell.parentElement;
  const table = cell.closest('table');
  const index = [...row.children].indexOf(cell);
  if (kind === 'rowAdd') {
    const next = row.cloneNode(true);
    next.querySelectorAll('td, th').forEach((c) => (c.innerHTML = '<br>'));
    row.after(next);
  } else if (kind === 'rowDel') {
    if (table.rows.length > 1) row.remove();
    else table.remove();
  } else if (kind === 'colAdd') {
    for (const r of table.rows) {
      const c = document.createElement(r.children[index]?.tagName || 'td');
      c.innerHTML = '<br>';
      r.children[index]?.after(c);
    }
  } else if (kind === 'colDel') {
    if (row.children.length > 1) for (const r of table.rows) r.children[index]?.remove();
    else table.remove();
  }
  changed();
}

async function command(cmd, el) {
  switch (cmd) {
    case 'undo':
    case 'redo':
    case 'bold':
    case 'italic':
    case 'underline':
    case 'strikeThrough':
    case 'superscript':
    case 'subscript':
    case 'justifyLeft':
    case 'justifyCenter':
    case 'justifyRight':
    case 'justifyFull':
    case 'insertUnorderedList':
    case 'insertOrderedList':
    case 'indent':
    case 'outdent':
    case 'removeFormat':
      return exec(cmd);
    case 'color':
      return popAt(el, `<div class="colors">${TEXT_COLORS.map((c) => `<button data-color="${c}" style="background:${c}" title="${c}"></button>`).join('')}</div>`);
    case 'mark':
      return popAt(el, `<div class="colors">${MARK_COLORS.map((c) => `<button data-mark="${c}" style="background:${c === 'transparent' ? 'repeating-linear-gradient(45deg,#444 0 4px,#222 4px 8px)' : c}" title="${c === 'transparent' ? 'Keine' : c}"></button>`).join('')}</div>`);
    case 'table':
      return popAt(el, `<div class="grid" id="tgrid">${Array.from({ length: 64 }, (_, i) => `<i data-cell="${i}"></i>`).join('')}</div><div class="hint" id="thint">Größe wählen</div>`);
    case 'image': {
      const src = await api.image();
      if (src) insertHtml(`<img src="${src}" alt="">`);
      return;
    }
    case 'shot': {
      const shots = await api.screenshots();
      if (!shots.length) return popAt(el, '<div class="hint" style="padding:6px 4px">Noch keine Screenshots. Aufnehmen mit Strg+Umschalt+X.</div>');
      const url = (p) => `file:///${p.replace(/\\/g, '/').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
      return popAt(el, `<div class="shots">${shots.map((s) => `<button data-shot="${esc(s.file)}" title="${esc(s.file.split(/[\\/]/).pop())}" style="background-image:url('${url(s.file)}')"></button>`).join('')}</div>`);
    }
    case 'link':
      return popAt(el || document.querySelector('[data-cmd="link"]'), `<div style="display:flex;gap:6px;align-items:center"><input class="input" id="link-url" placeholder="https://…" style="width:280px" /><button class="btn small primary" data-linkok="1">Einfügen</button></div>`), setTimeout(() => $('#link-url')?.focus(), 0);
    case 'hr':
      return insertHtml('<hr><p><br></p>');
    case 'pagebreak':
      return insertHtml('<div class="page-break" contenteditable="false"></div><p><br></p>');
    case 'toc': {
      const heads = [...paper.querySelectorAll('h1, h2, h3')];
      if (!heads.length) return toast('Keine Überschriften gefunden – nutze die Formatvorlagen „Überschrift 1–3“.', 'error');
      heads.forEach((h, i) => (h.id ||= `h-${Date.now().toString(36)}-${i}`));
      const items = heads.map((h) => `<li class="toc-${h.tagName.toLowerCase()}"><a href="#${h.id}">${esc(h.textContent.trim())}</a></li>`).join('');
      paper.querySelector('.doc-toc')?.remove();
      paper.insertAdjacentHTML('afterbegin', `<nav class="doc-toc" contenteditable="false"><b>Inhaltsverzeichnis</b><ol>${items}</ol></nav>`);
      changed();
      return toast('Inhaltsverzeichnis eingefügt – nochmal klicken aktualisiert es.');
    }
    case 'checklist':
      return insertHtml('<ul class="checklist"><li><input type="checkbox" contenteditable="false"> Aufgabe</li></ul><p><br></p>');
    case 'quote':
      return exec('formatBlock', 'blockquote');
    case 'code':
      return exec('formatBlock', 'pre');
    case 'symbols':
      return popAt(el, `<div class="symbols">${'€ £ $ ¥ © ® ™ ° ± × ÷ ≈ ≠ ≤ ≥ ∞ √ π Σ µ ½ ¼ ¾ ² ³ → ← ↑ ↓ ⇒ • … – — « » „ “ ‚ ‘ § ¶ ✓ ✗ ★ ☆ ♥ ☺ 😀 😂 😍 👍 🙏 🎉 🔥 💡 ✅ ❌ ⚠️ 📌 📅'.split(' ').map((c) => `<button data-sym="${c}">${c}</button>`).join('')}</div>`);
    case 'case':
      return popAt(el, `<div class="list"><button data-case="upper"><b>GROSSBUCHSTABEN</b></button><button data-case="lower"><b>kleinbuchstaben</b></button><button data-case="title"><b>Jedes Wort Groß</b></button><button data-case="sentence"><b>Satzanfang groß</b></button></div>`);
    case 'speak': {
      if (speechSynthesis.speaking) {
        speechSynthesis.cancel();
        return;
      }
      const sel = String(window.getSelection() || '').trim();
      const text = sel || paper.innerText.trim();
      if (!text) return;
      const u = new SpeechSynthesisUtterance(text.slice(0, 30000));
      u.lang = 'de-DE';
      u.rate = 1.02;
      speechSynthesis.speak(u);
      return toast(sel ? 'Liest die Auswahl vor …' : 'Liest das Dokument vor …');
    }
    case 'focus':
      document.body.classList.toggle('focus-mode');
      return;
    case 'date':
      return insertHtml(esc(new Date().toLocaleDateString('de-CH', { day: 'numeric', month: 'long', year: 'numeric' })));
    case 'rowAdd':
    case 'rowDel':
    case 'colAdd':
    case 'colDel':
      return tableAction(cmd);
    case 'find':
      $('#findbar').hidden = false;
      $('#find').focus();
      $('#find').select();
      return;
    case 'closeFind':
      $('#findbar').hidden = true;
      return;
    case 'findNext':
      return findNext();
    case 'replaceOne':
      return replaceOne();
    case 'replaceAll':
      return replaceAll();
    case 'new':
      return newDocument();
    case 'openMenu':
      return openMenu(el);
    case 'save':
      return save(false);
    case 'saveAs':
      return popAt(el, `<div class="list">
        <button data-saveas="docx"><b>Word-Dokument (.docx)</b><small>Öffnet in Word, LibreOffice und Google Docs</small></button>
        <button data-saveas="html"><b>Webseite (.html)</b><small>Mit allen Formatierungen und Bildern</small></button>
        <button data-saveas="txt"><b>Nur Text (.txt)</b><small>Ohne Formatierung</small></button></div>`);
    case 'pdf':
      try {
        const out = await api.pdf(fileTitle());
        if (out) toast(`PDF gespeichert: ${out}`);
      } catch (error) {
        toast(error.message || error, 'error');
      }
      return;
    case 'print':
      return api.print();
    default:
  }
}

function insertLink(raw) {
  closePop();
  if (!raw) return;
  const url = /^[a-z]+:/i.test(raw) ? raw : `https://${raw}`;
  if (savedRange && !savedRange.collapsed) exec('createLink', url);
  else insertHtml(`<a href="${esc(url)}">${esc(raw)}</a>`);
}

document.addEventListener('keydown', (event) => {
  if (event.target.id === 'link-url' && event.key === 'Enter') insertLink(event.target.value.trim());
});

/* -------------------------------------------------------------- find/replace */
function findNext(wrap = true) {
  const term = $('#find').value;
  if (!term) return false;
  paper.focus();
  const found = window.find(term, false, false, wrap, false, false, false);
  if (!found) toast('Nicht gefunden.');
  return found;
}

function replaceOne() {
  const sel = window.getSelection();
  const term = $('#find').value;
  if (sel.toString().toLowerCase() === term.toLowerCase() && paper.contains(sel.anchorNode)) {
    document.execCommand('insertText', false, $('#replace').value);
    changed();
  }
  findNext();
}

function replaceAll() {
  const term = $('#find').value;
  if (!term) return;
  const replacement = $('#replace').value;
  const walker = document.createTreeWalker(paper, NodeFilter.SHOW_TEXT);
  const pattern = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  let count = 0;
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  for (const node of nodes) {
    const next = node.textContent.replace(pattern, () => {
      count += 1;
      return replacement;
    });
    if (next !== node.textContent) node.textContent = next;
  }
  $('#find-count').textContent = `${count} ersetzt`;
  if (count) changed();
}

/* --------------------------------------------------------------- documents */
function fileTitle() {
  return $('#title').value.trim() || 'Dokument';
}

function setStatus(text) {
  $('#status').textContent = text;
}

function changed() {
  doc.dirty = true;
  setStatus(doc.file ? 'Ungespeicherte Änderungen' : 'Nicht gespeichert');
  updateCounts();
}

function load(html, { file = null, name = 'Unbenanntes Dokument' } = {}) {
  paper.innerHTML = html && html.trim() ? html : '<p><br></p>';
  doc.file = file;
  doc.dirty = false;
  $('#title').value = name.replace(/\.(docx|html?|txt|md|rdoc)$/i, '');
  setStatus(file ? `Gespeichert · ${file}` : 'Nicht gespeichert');
  updateCounts();
  paper.focus();
}

function confirmDiscard() {
  return !doc.dirty || confirm('Ungespeicherte Änderungen verwerfen?');
}

function newDocument() {
  if (!confirmDiscard()) return;
  load('');
  api.saveDraft(null);
}

function textToHtml(text) {
  return text
    .split(/\r?\n\r?\n/)
    .map((block) => `<p>${esc(block).replace(/\r?\n/g, '<br>') || '<br>'}</p>`)
    .join('');
}

function markdownToHtml(md) {
  const inline = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\*(.+?)\*/g, '<i>$1</i>').replace(/`(.+?)`/g, '<code>$1</code>').replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2">$1</a>');
  const out = [];
  let list = null;
  for (const line of md.split(/\r?\n/)) {
    const h = /^(#{1,3})\s+(.*)$/.exec(line);
    const li = /^\s*([-*]|\d+\.)\s+(.*)$/.exec(line);
    if (li) {
      const tag = /\d/.test(li[1]) ? 'ol' : 'ul';
      if (list !== tag) {
        if (list) out.push(`</${list}>`);
        out.push(`<${tag}>`);
        list = tag;
      }
      out.push(`<li>${inline(li[2])}</li>`);
      continue;
    }
    if (list) {
      out.push(`</${list}>`);
      list = null;
    }
    if (h) out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`);
    else if (line.startsWith('> ')) out.push(`<blockquote>${inline(line.slice(2))}</blockquote>`);
    else if (line.trim()) out.push(`<p>${inline(line)}</p>`);
  }
  if (list) out.push(`</${list}>`);
  return out.join('');
}

async function open(file) {
  if (!file && !confirmDiscard()) return;
  try {
    const result = await api.open(file);
    if (!result) return;
    let html;
    if (result.kind === 'docx') html = window.Docx.importDocx(result);
    else if (result.kind === 'html') {
      const parsed = new DOMParser().parseFromString(result.html, 'text/html');
      parsed.querySelectorAll('script, style, link, meta').forEach((n) => n.remove());
      html = (parsed.querySelector('article.paper') || parsed.body).innerHTML;
    } else if (result.kind === 'markdown') html = markdownToHtml(result.text);
    else html = textToHtml(result.text);
    load(html, { file: result.file, name: result.name });
    api.saveDraft(null);
  } catch (error) {
    toast(`Öffnen fehlgeschlagen: ${error.message || error}`, 'error');
  }
}

async function openMenu(el) {
  const list = await api.recents();
  popAt(
    el,
    `<div class="list"><button data-pick="1"><b>Datei auswählen …</b><small>.docx, .html, .txt, .md</small></button>
    ${list.map((r) => `<button data-recent="${esc(r.file)}"><b>${esc(r.name)}</b><small>${esc(r.file)}</small></button>`).join('')}</div>`,
  );
}

function htmlDocument() {
  return `<!doctype html><html lang="de"><head><meta charset="utf-8"><title>${esc(fileTitle())}</title>
<style>body{max-width:794px;margin:40px auto;padding:0 40px;font-family:Calibri,'Segoe UI',sans-serif;font-size:11pt;line-height:1.5;color:#1d1d24}
table{border-collapse:collapse;width:100%}td,th{border:1px solid #bfbfbf;padding:5pt 7pt}blockquote{border-left:3pt solid #8b6cff;margin-left:24pt;padding-left:12pt;color:#555566;font-style:italic}
pre{background:#f2f2f5;padding:8pt 10pt}img{max-width:100%}.page-break{break-after:page}</style></head>
<body><article class="paper">${paper.innerHTML}</article></body></html>`;
}

async function save(as, format) {
  try {
    let file = doc.file;
    if (as || !file || !/\.(docx|html?|txt)$/i.test(file)) {
      file = await api.saveAs(fileTitle(), format || 'docx');
      if (!file) return;
    }
    const payload = { file };
    if (/\.docx$/i.test(file)) payload.docx = window.Docx.exportDocx(paper);
    else if (/\.html?$/i.test(file)) payload.html = htmlDocument();
    else payload.text = paper.innerText;
    const result = await api.write(payload);
    if (!as || /\.(docx|html?)$/i.test(file)) {
      doc.file = result.file;
      $('#title').value = result.name.replace(/\.(docx|html?|txt)$/i, '');
    }
    doc.dirty = false;
    setStatus(`Gespeichert · ${result.file}`);
    api.saveDraft(null);
    toast('Gespeichert.');
  } catch (error) {
    toast(`Speichern fehlgeschlagen: ${error.message || error}`, 'error');
  }
}

/* ------------------------------------------------------------------ status */
function updateCounts() {
  const text = paper.innerText.trim();
  const words = text ? text.split(/\s+/).length : 0;
  const pages = Math.max(1, Math.ceil(paper.scrollHeight / 1123));
  const mins = Math.max(1, Math.round(words / 220));
  $('#counts').textContent = `Seite ${pages > 1 ? `1–${pages}` : '1'} · ${words.toLocaleString('de-CH')} Wörter · ${text.length.toLocaleString('de-CH')} Zeichen${words > 40 ? ` · ≈ ${mins} min Lesezeit` : ''}`;
}

/* Sonderzeichen, Groß/Klein, Checklisten-Häkchen, Inhaltsverzeichnis, Fokusmodus */
document.addEventListener('click', (e) => {
  const sym = e.target.closest?.('[data-sym]');
  if (sym) {
    $('#pop').hidden = true;
    return insertHtml(esc(sym.dataset.sym));
  }
  const cs = e.target.closest?.('[data-case]');
  if (cs) {
    $('#pop').hidden = true;
    restoreSelection();
    const text = String(window.getSelection() || '');
    if (!text) return toast('Markiere zuerst den Text.', 'error');
    const k = cs.dataset.case;
    const low = text.toLocaleLowerCase('de');
    const out = k === 'upper' ? text.toLocaleUpperCase('de') : k === 'lower' ? low : k === 'title' ? low.replace(/(^|[\s\-(„"])(\p{L})/gu, (m, a, b) => a + b.toLocaleUpperCase('de')) : low.replace(/(^\s*|[.!?]\s+)(\p{L})/gu, (m, a, b) => a + b.toLocaleUpperCase('de'));
    document.execCommand('insertText', false, out);
    return changed();
  }
  const box = e.target.closest?.('.checklist input[type=checkbox]');
  if (box) {
    box.toggleAttribute('checked', box.checked);
    box.closest('li')?.classList.toggle('done', box.checked);
    changed();
  }
  const link = e.target.closest?.('.doc-toc a');
  if (link) {
    e.preventDefault();
    paper.querySelector(link.getAttribute('href'))?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && document.body.classList.contains('focus-mode')) document.body.classList.remove('focus-mode');
});

function setZoom(value) {
  doc.zoom = Math.min(2, Math.max(0.5, Math.round(value * 100) / 100));
  $('#zoomer').style.transform = `scale(${doc.zoom})`;
  $('#zoomer').style.marginBottom = `${(doc.zoom - 1) * paper.offsetHeight}px`;
  $('#zoom').value = String(doc.zoom);
  $('#zoom-val').textContent = `${Math.round(doc.zoom * 100)} %`;
}

/* ------------------------------------------------------------------ events */
document.addEventListener('selectionchange', () => {
  if (paper.contains(window.getSelection().anchorNode)) {
    saveSelection();
    updateState();
  }
});

paper.addEventListener('input', changed);
paper.addEventListener('click', (event) => {
  paper.querySelectorAll('img.selected').forEach((img) => img.classList.remove('selected'));
  if (event.target.tagName === 'IMG') event.target.classList.add('selected');
});

// Ribbon buttons must not steal the text selection.
document.addEventListener('mousedown', (event) => {
  if (event.target.closest('.rb, .pop button, .pop i') && !event.target.closest('#link-url')) event.preventDefault();
});

document.addEventListener('click', (event) => {
  const el = event.target.closest('button, i[data-cell]');
  if (!el) {
    if (!event.target.closest('.pop')) closePop();
    return;
  }
  if (el.dataset.cmd) {
    if (!['color', 'mark', 'table', 'openMenu', 'saveAs'].includes(el.dataset.cmd)) closePop();
    command(el.dataset.cmd, el);
  } else if (el.dataset.color) {
    closePop();
    exec('foreColor', el.dataset.color);
    $('#color-bar').style.background = el.dataset.color;
  } else if (el.dataset.shot) {
    closePop();
    api.screenshotData(el.dataset.shot).then((src) => insertHtml(`<img src="${src}" alt="Screenshot">`));
  } else if (el.dataset.mark) {
    closePop();
    exec('hiliteColor', el.dataset.mark);
    if (el.dataset.mark !== 'transparent') $('#mark-bar').style.background = el.dataset.mark;
  } else if (el.dataset.cell) {
    const i = Number(el.dataset.cell);
    const rows = Math.floor(i / 8) + 1;
    const cols = (i % 8) + 1;
    closePop();
    const row = `<tr>${'<td><br></td>'.repeat(cols)}</tr>`;
    insertHtml(`<table><tbody>${row.repeat(rows)}</tbody></table><p><br></p>`);
  } else if (el.dataset.saveas) {
    closePop();
    save(true, el.dataset.saveas);
  } else if (el.dataset.recent) {
    closePop();
    if (confirmDiscard()) open(el.dataset.recent);
  } else if (el.dataset.pick) {
    closePop();
    open(null);
  } else if (el.dataset.linkok) {
    insertLink($('#link-url').value.trim());
  } else if (el.dataset.zoom) setZoom(doc.zoom + Number(el.dataset.zoom));
  else if (el.dataset.restore) {
    const draft = JSON.parse(el.dataset.restore === '1' ? sessionStorage.getItem('draft') : 'null');
    $('#banner').hidden = true;
    if (draft) {
      load(draft.html, { file: draft.file, name: draft.name });
      doc.dirty = true;
      setStatus('Wiederhergestellt – noch nicht gespeichert');
    } else api.saveDraft(null);
  }
});

document.addEventListener('mouseover', (event) => {
  const cell = event.target.closest('i[data-cell]');
  if (!cell) return;
  const i = Number(cell.dataset.cell);
  const rows = Math.floor(i / 8);
  const cols = i % 8;
  document.querySelectorAll('#tgrid i').forEach((c, k) => c.classList.toggle('on', Math.floor(k / 8) <= rows && k % 8 <= cols));
  $('#thint').textContent = `${cols + 1} × ${rows + 1} Tabelle`;
});

document.addEventListener('change', (event) => {
  const id = event.target.id;
  if (id === 'style') setStyle(event.target.value);
  else if (id === 'font') exec('fontName', event.target.value);
  else if (id === 'size') setFontSize(Number(event.target.value));
  else if (id === 'spacing') setSpacing(event.target.value);
});

$('#zoom').addEventListener('input', (event) => setZoom(Number(event.target.value)));
$('#title').addEventListener('input', () => changed());
$('#find').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') findNext();
  if (event.key === 'Escape') $('#findbar').hidden = true;
});

document.addEventListener('keydown', (event) => {
  if (!event.ctrlKey) return;
  const key = event.key.toLowerCase();
  const map = { s: () => save(event.shiftKey), o: () => open(null), n: () => newDocument(), p: () => api.print(), f: () => command('find'), h: () => command('find'), k: () => command('link') };
  if (key === 'enter') {
    event.preventDefault();
    return command('pagebreak');
  }
  if (map[key]) {
    event.preventDefault();
    map[key]();
  }
});

document.querySelector('.desk').addEventListener('wheel', (event) => {
  if (!event.ctrlKey) return;
  event.preventDefault();
  setZoom(doc.zoom + (event.deltaY < 0 ? 0.1 : -0.1));
}, { passive: false });

// Crash safety: an autosaved copy of unsaved work.
setInterval(() => {
  if (doc.dirty) api.saveDraft({ html: paper.innerHTML, file: doc.file, name: fileTitle(), time: Date.now() });
}, 15000);

/* ------------------------------------------------------------------- start */
buildMenu();
buildRibbon();
document.execCommand('defaultParagraphSeparator', false, 'p');
load('');
api.loadDraft().then((draft) => {
  if (!draft?.html) return;
  sessionStorage.setItem('draft', JSON.stringify(draft));
  const banner = $('#banner');
  banner.hidden = false;
  banner.innerHTML = `<span>Es gibt einen automatisch gesicherten Entwurf „${esc(draft.name)}“ vom ${new Date(draft.time).toLocaleString('de-CH')}.</span>
    <span class="row" style="display:flex;gap:8px"><button class="btn small" data-restore="0">Verwerfen</button><button class="btn small primary" data-restore="1">Wiederherstellen</button></span>`;
});
