'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('chatApp', {
  load: () => ipcRenderer.invoke('load'),
  save: (data) => ipcRenderer.invoke('save', data),
  notify: (n) => ipcRenderer.invoke('notify', n),
  identity: (id) => ipcRenderer.invoke('identity', id),
  unread: (n) => ipcRenderer.invoke('unread', n),
  pending: () => ipcRenderer.invoke('pending'),
  isOpen: () => ipcRenderer.invoke('is-open'),
  onGameRequest: (fn) => ipcRenderer.on('game-request', (_e, item) => fn(item)),
});
contextBridge.exposeInMainWorld('hubProfile', {
  get: () => ipcRenderer.invoke('hp:get'),
  name: (v) => ipcRenderer.invoke('hp:name', v),
  shop: () => ipcRenderer.invoke('hp:shop'),
});
