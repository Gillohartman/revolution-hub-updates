'use strict';

/*
 * „PC-Stärke“: grobe Einstufung von CPU, Arbeitsspeicher und Grafikkarte (1–10).
 * Dazu Live-Werte und eine Analyse, ob der PC so schnell ist, wie er sein sollte.
 */
const os = require('os');
const { execFile } = require('child_process');

let cache = null;

function powershell(script, timeout = 15000) {
  const encoded = Buffer.from(`$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.Encoding]::UTF8;${script}`, 'utf16le').toString('base64');
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, timeout, maxBuffer: 4 * 1024 * 1024 }, (error, stdout) => resolve(error ? '' : String(stdout)));
  });
}

async function gpus() {
  if (process.platform !== 'win32') return [];
  // qwMemorySize ist korrekt auch über 4 GB (AdapterRAM nicht)
  const out = await powershell(
    "$r=@();Get-ItemProperty 'HKLM:\\SYSTEM\\ControlSet001\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0*' -ErrorAction SilentlyContinue | ForEach-Object { $m=$_.'HardwareInformation.qwMemorySize'; if(-not $m){$m=$_.'HardwareInformation.MemorySize'}; if($_.DriverDesc){$r+=[pscustomobject]@{name=$_.DriverDesc;mem=[double]($m -as [double])}} };$r|ConvertTo-Json -Compress",
  );
  try {
    const list = JSON.parse(out.trim() || '[]');
    return (Array.isArray(list) ? list : [list]).filter((g) => g && g.name && !/basic|remote|virtual|parsec|meta/i.test(g.name)).map((g) => ({ name: g.name, vram: Math.round(((Number(g.mem) || 0) / 1024 ** 3) * 10) / 10 }));
  } catch {
    return [];
  }
}

async function info(force = false) {
  if (cache && !force) return cache;
  const cpus = os.cpus();
  const cores = cpus.length;
  const ghz = cpus.length ? Math.max(...cpus.map((c) => c.speed || 0)) / 1000 : 2;
  const ram = Math.round((os.totalmem() / 1024 ** 3) * 10) / 10;
  const gpuList = await gpus();
  const best = gpuList.sort((a, b) => b.vram - a.vram)[0] || null;
  const dedicated = best && /nvidia|geforce|rtx|gtx|radeon rx|arc a/i.test(best.name);
  const cpuScore = Math.max(1, Math.min(10, cores * 0.55 + Math.max(0, ghz - 2) * 2));
  const ramScore = Math.max(1, Math.min(10, ram / 3.2));
  const gpuScore = best ? Math.max(1, Math.min(10, (dedicated ? best.vram * 1.25 : best.vram * 0.6) || 1)) : 1;
  const level = Math.max(1, Math.min(10, Math.round(cpuScore * 0.35 + ramScore * 0.3 + gpuScore * 0.35)));
  const label = level <= 3 ? 'Einsteiger' : level <= 6 ? 'Mittelklasse' : level <= 8 ? 'Stark' : 'High-End';
  // KI-Empfehlung: nur kleine Modelle für einfache Fragen
  let ai;
  if (ram < 6) ai = { ok: false, model: 'qwen2.5:0.5b', reason: 'Zu wenig Arbeitsspeicher (unter 6 GB) – eine lokale KI würde den PC stark ausbremsen.' };
  else if (ram < 12 || level <= 4) ai = { ok: true, model: 'qwen2.5:0.5b', size: '≈ 400 MB', reason: 'Kleinstes Modell – schnell und schonend, für ganz einfache Fragen.' };
  else if (level <= 7) ai = { ok: true, model: 'llama3.2:1b', size: '≈ 1,3 GB', reason: 'Kleines Modell – gut für einfache Fragen.' };
  else ai = { ok: true, model: 'llama3.2:3b', size: '≈ 2 GB', reason: 'Dein PC ist stark genug für ein etwas klügeres kleines Modell.' };
  cache = { cores, ghz: Math.round(ghz * 10) / 10, ram, cpu: cpus[0]?.model?.trim() || 'CPU', gpu: best, gpus: gpuList, scores: { cpu: Math.round(cpuScore), ram: Math.round(ramScore), gpu: Math.round(gpuScore) }, level, label, ai, threads: Math.max(1, Math.min(8, cores - 2)) };
  return cache;
}

/* ------------------------------------------------------------------ Live-Werte & Analyse */
// Nur CIM-Klassen (nicht lokalisiert) – Get-Counter-Namen wären auf deutschem Windows übersetzt.
const LIVE_PS = `
$o=[ordered]@{}
$pi=Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'" -EA SilentlyContinue
$o.cpu=if($pi){[double]$pi.PercentProcessorUtility}else{[double](Get-CimInstance Win32_Processor|Measure-Object LoadPercentage -Average).Average}
$o.perf=if($pi){[double]$pi.PercentProcessorPerformance}else{$null}
$cores=[Environment]::ProcessorCount
$o.procs=@(Get-CimInstance Win32_PerfFormattedData_PerfProc_Process -EA SilentlyContinue|?{$_.Name -notmatch '^(_Total|Idle|System|Memory Compression)$'}|%{[pscustomobject]@{n=($_.Name -replace '#\\d+$','');c=[double]$_.PercentProcessorTime/$cores;m=[double]$_.WorkingSetPrivate}}|Group-Object n|%{[pscustomobject]@{n=$_.Name;c=[math]::Round(($_.Group|Measure-Object c -Sum).Sum,1);m=[math]::Round(($_.Group|Measure-Object m -Sum).Sum/1MB);k=$_.Count}})
$g=Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -EA SilentlyContinue|?{$_.Name -match 'engtype_3D'}
$o.gpu=if($g){[math]::Min(100,[double]($g|Measure-Object UtilizationPercentage -Sum).Sum)}else{$null}
$o.disks=@(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -EA SilentlyContinue|%{[pscustomobject]@{d=$_.DeviceID;free=[double]$_.FreeSpace;size=[double]$_.Size}})
$plan=(powercfg /getactivescheme) -join ' '
$o.plan=if($plan -match '([0-9a-f]{8}-[0-9a-f-]{27})'){$matches[1]}else{''}
$o.planName=if($plan -match '\\((.+)\\)'){$matches[1]}else{''}
$b=Get-CimInstance Win32_Battery -EA SilentlyContinue|Select -First 1
$o.battery=if($b){[pscustomobject]@{pct=$b.EstimatedChargeRemaining;onBattery=($b.BatteryStatus -eq 1)}}else{$null}
$o.autostart=@(Get-CimInstance Win32_StartupCommand -EA SilentlyContinue).Count
$o|ConvertTo-Json -Compress -Depth 4`;

let liveBusy = null;

function analyse(i, l) {
  const issues = [];
  const add = (sev, title, text, procs) => issues.push({ sev, title, text, procs });
  const fmt = (n) => String(Math.round(n * 10) / 10).replace('.', ',');
  const byCpu = [...l.procs].sort((a, b) => b.c - a.c).filter((p) => p.c >= 3 && !/revolution|electron/i.test(p.n)).slice(0, 5);
  const byRam = [...l.procs].sort((a, b) => b.m - a.m).slice(0, 5);
  if (l.cpu >= 85) add(3, 'Prozessor am Limit', `Der Prozessor ist zu ${Math.round(l.cpu)} % ausgelastet. Diese Programme ziehen gerade am meisten Leistung:`, byCpu);
  else if (l.cpu >= 55) add(2, 'Viel los im Hintergrund', `Der Prozessor ist zu ${Math.round(l.cpu)} % ausgelastet, obwohl du gerade nur den Hub offen hast. Hauptverursacher:`, byCpu);
  else if (byCpu[0] && byCpu[0].c >= 20) add(1, 'Ein Programm frisst Leistung', `„${byCpu[0].n}“ braucht allein ${Math.round(byCpu[0].c)} % des Prozessors.`, byCpu.slice(0, 1));
  if (l.ramPct >= 90) add(3, 'Arbeitsspeicher voll', `${Math.round(l.ramPct)} % vom Arbeitsspeicher sind belegt – Windows muss auf die Festplatte auslagern, das macht alles langsam. Größte Verbraucher:`, byRam);
  else if (l.ramPct >= 78) add(2, 'Arbeitsspeicher knapp', `${Math.round(l.ramPct)} % vom Arbeitsspeicher sind belegt. Schließ Programme, die du nicht brauchst:`, byRam);
  if (l.perf != null && l.perf > 0 && l.perf < 65 && l.cpu > 15) add(3, 'Prozessor wird gedrosselt', `Er läuft nur mit ${Math.round(l.perf)} % seiner Leistung. Meist zu heiß (Lüfter/Staub prüfen) oder durch einen Stromsparmodus begrenzt.`);
  if (/^a1841308/i.test(l.plan)) add(3, 'Energiesparmodus aktiv', `Der Energieplan „${l.planName || 'Energiesparmodus'}“ bremst den Prozessor bewusst aus. Stell in den Windows-Energieoptionen auf „Ausbalanciert“ oder „Höchstleistung“.`);
  if (l.battery?.onBattery) add(2, 'Läuft im Akkubetrieb', `Im Akkubetrieb (${l.battery.pct} %) drosselt Windows die Leistung. Am Netzteil ist der PC schneller.`);
  for (const d of l.disks) {
    const pct = d.size ? (d.free / d.size) * 100 : 100;
    if (pct < 8 || d.free < 10 * 1024 ** 3) add(d.d === 'C:' ? 3 : 1, `Laufwerk ${d.d} fast voll`, `Nur noch ${fmt(d.free / 1024 ** 3)} GB frei (${Math.round(pct)} %). Ein volles Systemlaufwerk macht Windows spürbar langsamer.`);
  }
  if (l.gpu != null && l.gpu >= 60) add(2, 'Grafikkarte stark belastet', `Die Grafikkarte ist zu ${Math.round(l.gpu)} % beschäftigt – läuft im Hintergrund ein Spiel, Video oder Miner?`);
  if (l.autostart >= 15) add(1, 'Viele Autostart-Programme', `${l.autostart} Programme starten mit Windows. Im Task-Manager unter „Autostart“ kannst du unnötige deaktivieren.`);
  if (l.uptime > 4 * 86400) add(1, 'Lange nicht neu gestartet', `Der PC läuft seit ${Math.floor(l.uptime / 86400)} Tagen durch. Ein Neustart räumt Speicher und hängende Prozesse auf.`);
  issues.sort((a, b) => b.sev - a.sev);
  const worst = issues[0]?.sev || 0;
  // „Erwartete“ Stufe: Hardware-Stufe minus Abzüge durch die gefundenen Bremsen
  const penalty = issues.reduce((s, x) => s + (x.sev === 3 ? 2 : x.sev === 2 ? 1 : 0.3), 0);
  const effective = Math.max(1, Math.round((i.level - penalty) * 10) / 10);
  const verdict = worst === 0 ? { ok: true, text: 'Dein PC bringt die Leistung, die er haben soll.' } : worst === 1 ? { ok: true, text: 'Läuft gut – nur Kleinigkeiten.' } : { ok: false, text: `Dein PC läuft unter seinen Möglichkeiten (${issues.filter((x) => x.sev >= 2).length} Bremse${issues.filter((x) => x.sev >= 2).length === 1 ? '' : 'n'} gefunden).` };
  return { issues, verdict, effective };
}

async function live() {
  if (liveBusy) return liveBusy;
  liveBusy = (async () => {
    const i = await info();
    const total = os.totalmem();
    let raw = {};
    if (process.platform === 'win32') {
      try {
        raw = JSON.parse((await powershell(LIVE_PS, 20000)).trim() || '{}');
      } catch {}
    }
    const arr = (x) => (Array.isArray(x) ? x : x ? [x] : []);
    const l = {
      cpu: Number(raw.cpu) || 0,
      perf: raw.perf == null ? null : Number(raw.perf),
      gpu: raw.gpu == null ? null : Number(raw.gpu),
      ramPct: ((total - os.freemem()) / total) * 100,
      ramUsed: Math.round(((total - os.freemem()) / 1024 ** 3) * 10) / 10,
      ramTotal: i.ram,
      procs: arr(raw.procs).map((p) => ({ n: String(p.n), c: Number(p.c) || 0, m: Number(p.m) || 0, k: p.k || 1 })),
      disks: arr(raw.disks).filter((d) => d.size > 0),
      plan: raw.plan || '',
      planName: raw.planName || '',
      battery: raw.battery || null,
      autostart: Number(raw.autostart) || 0,
      uptime: os.uptime(),
      at: Date.now(),
    };
    return { ...l, procs: [...l.procs].sort((a, b) => b.c - a.c || b.m - a.m).slice(0, 8), ...analyse(i, l) };
  })().finally(() => setTimeout(() => (liveBusy = null), 0));
  return liveBusy;
}

module.exports = { info, live, analyse };
