'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('agendaApp', {
  list: () => ipcRenderer.invoke('list'),
  save: (evt) => ipcRenderer.invoke('save', evt),
  remove: (id) => ipcRenderer.invoke('delete', id),
  onChanged: (cb) => ipcRenderer.on('changed', (_e, list) => cb(list)),
});
