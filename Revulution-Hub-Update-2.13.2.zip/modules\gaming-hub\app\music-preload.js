const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('musicOverlay', {
  onUpdate: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('music:update', handler);
    return () => ipcRenderer.removeListener('music:update', handler);
  },
  ready: () => ipcRenderer.send('music:ready'),
});
