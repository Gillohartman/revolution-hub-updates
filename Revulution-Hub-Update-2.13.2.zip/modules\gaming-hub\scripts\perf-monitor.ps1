﻿# Leistungsdaten fürs Overlay: CPU, RAM, GPU, Temperatur und Ping.
# Gibt pro Sekunde eine JSON-Zeile aus. Alles über sprachneutrale WMI-Klassen,
# damit es auch auf deutschen Windows-Installationen funktioniert.
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [System.Text.Encoding]::UTF8

$pingClient = New-Object System.Net.NetworkInformation.Ping
$pingHost = '1.1.1.1'
$pingValue = $null
$tick = 0
$pingTarget = $pingHost
$pingFails = 0

# Ping zum Server des Spiels im Vordergrund: dessen offene Verbindung statt einer festen Adresse.
Add-Type -Namespace RevPerf -Name Fg -MemberDefinition @'
[DllImport("user32.dll")] public static extern System.IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(System.IntPtr hWnd, out uint pid);
'@
function Get-GameHost {
  try {
    $procId = 0
    [void][RevPerf.Fg]::GetWindowThreadProcessId([RevPerf.Fg]::GetForegroundWindow(), [ref]$procId)
    if ($procId -le 4) { return $null }
    $name = (Get-Process -Id $procId).ProcessName
    if ($name -match '^(explorer|Revolution Hub|electron|chrome|msedge|firefox|Code|dwm|ShellExperienceHost|SearchHost|ApplicationFrameHost)$') { return $null }
    $cons = Get-NetTCPConnection -State Established -OwningProcess $procId | Where-Object {
      $_.RemoteAddress -notmatch ':' -and $_.RemoteAddress -notmatch '^(10\.|127\.|192\.168\.|169\.254\.|172\.(1[6-9]|2[0-9]|3[01])\.)'
    }
    if (-not $cons) { return $null }
    return ($cons | Group-Object RemoteAddress | Sort-Object Count -Descending | Select-Object -First 1).Name
  } catch { return $null }
}

while ($true) {
  # CPU: _Total gibt es sprachneutral, sonst Mittel über alle Kerne.
  $cpu = 0
  $cores = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Processor
  if ($cores) {
    $total = $cores | Where-Object { $_.Name -eq '_Total' } | Select-Object -First 1
    if ($null -ne $total) { $cpu = [double]$total.PercentProcessorTime }
    else {
      $avg = ($cores | Measure-Object -Property PercentProcessorTime -Average).Average
      if ($null -ne $avg) { $cpu = [double]$avg }
    }
  }

  # RAM in GB (belegt / gesamt)
  $ram = 0.0
  $ramTotal = 0.0
  $os = Get-CimInstance -ClassName Win32_OperatingSystem
  if ($os) {
    $ramTotal = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
    $ram = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB, 1)
  }

  # GPU: Summe aller 3D-Engines über die Perf-Klasse (Name enthält engtype_3D)
  $gpu = 0
  $engines = Get-CimInstance -ClassName Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine
  if ($engines) {
    $used = ($engines | Where-Object { $_.Name -like '*engtype_3D*' } | Measure-Object -Property UtilizationPercentage -Sum).Sum
    if ($null -ne $used) { $gpu = [math]::Min(100, [math]::Round([double]$used, 0)) }
  }

  # Temperatur ist nicht auf jedem Board verfügbar – dann bleibt das Feld leer.
  $temp = $null
  $zones = Get-CimInstance -Namespace root/WMI -ClassName MSAcpi_ThermalZoneTemperature
  if ($zones) {
    $values = @()
    foreach ($zone in $zones) {
      $celsius = ([double]$zone.CurrentTemperature / 10) - 273.15
      if ($celsius -gt 5 -and $celsius -lt 120) { $values += $celsius }
    }
    if ($values.Count -gt 0) { $temp = [math]::Round(($values | Measure-Object -Maximum).Maximum, 0) }
  }

  # Ping nur jeden zweiten Takt – ein Timeout würde die Schleife sonst bremsen.
  if ($tick % 10 -eq 0) {
    $found = Get-GameHost
    if ($found) { if ($found -ne $pingTarget) { $pingTarget = $found; $pingFails = 0 } }
    else { $pingTarget = $pingHost }
  }
  if ($tick % 2 -eq 0) {
    $reply = $pingClient.Send($pingTarget, 600)
    if ($reply -and $reply.Status -eq 'Success') { $pingValue = [int]$reply.RoundtripTime; $pingFails = 0 }
    else {
      # Viele Spielserver antworten nicht auf Ping – dann zurück zur allgemeinen Messung.
      $pingFails += 1
      if ($pingTarget -ne $pingHost -and $pingFails -ge 2) {
        $reply = $pingClient.Send($pingHost, 600)
        if ($reply -and $reply.Status -eq 'Success') { $pingValue = [int]$reply.RoundtripTime } else { $pingValue = $null }
      } else { $pingValue = $null }
    }
  }
  $tick += 1

  $payload = [ordered]@{
    cpu      = [math]::Round($cpu, 0)
    ram      = $ram
    ramTotal = $ramTotal
    gpu      = $gpu
    temp     = $temp
    ping     = $pingValue
  } | ConvertTo-Json -Compress
  Write-Output $payload

  Start-Sleep -Milliseconds 1000
}
