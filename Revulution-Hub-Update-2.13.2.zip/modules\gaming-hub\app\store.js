const fs = require('fs');
const path = require('path');
const { DEFAULT_APP, normalizeApp } = require('./crosshair');

const CROSSHAIR_SIZE = 15;
const HEX = /^#[0-9a-f]{6}$/i;
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

/** Klassisches Kreuz mit Lücke in der Mitte. */
function crosshairPreset(kind = 'cross', color = '#9df7c8') {
  const mid = Math.floor(CROSSHAIR_SIZE / 2);
  const pixels = Array.from({ length: CROSSHAIR_SIZE }, () => Array(CROSSHAIR_SIZE).fill(''));
  const put = (x, y) => {
    if (x >= 0 && y >= 0 && x < CROSSHAIR_SIZE && y < CROSSHAIR_SIZE) pixels[y][x] = color;
  };

  if (kind === 'dot') {
    put(mid, mid);
    return pixels;
  }
  if (kind === 'x') {
    for (let i = 0; i < CROSSHAIR_SIZE; i += 1) {
      if (Math.abs(i - mid) < 2) continue;
      put(i, i);
      put(CROSSHAIR_SIZE - 1 - i, i);
    }
    return pixels;
  }

  const gap = kind === 't' ? 2 : 2;
  for (let i = 0; i < CROSSHAIR_SIZE; i += 1) {
    if (Math.abs(i - mid) <= gap) continue;
    put(mid, i);
    if (kind !== 't') put(i, mid);
  }
  return pixels;
}

/**
 * Musik-Einstellungen prüfen. Ältere Profile hatten 100 % – das ist auf dem
 * Desktop zu groß, deshalb einmalig auf 80 % und danach die Nutzerwahl lassen.
 */
function normalizeMusic(input) {
  const source = input && typeof input === 'object' ? input : {};
  const offset = (value) => {
    if (value === null || value === undefined || value === '') return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.round(parsed) : null;
  };
  const scale = Number(source.scale);
  const x = offset(source.x);
  const y = offset(source.y);
  // Position: benannte Ecke/Rand oder frei verschoben (x/y in Pixeln).
  const stored =
    typeof source.preset === 'string' && MUSIC_PRESETS.includes(source.preset)
      ? source.preset
      : null;
  // Standard: oben mittig mit kleiner Lücke am Rand. Bestehende Profile
  // werden einmalig dorthin gesetzt, danach gilt die eigene Wahl.
  const preset =
    source.edgeDefault === true
      ? stored || (x !== null || y !== null ? 'free' : 'tc')
      : 'tc';
  const music = {
    enabled: source.enabled !== false,
    preset,
    x,
    y,
    scale: Number.isFinite(scale) ? clamp(Math.round(scale * 100) / 100, 0.6, 2) : 0.8,
    lyrics: source.lyrics !== false,
    // Einzelne Teile der Karte lassen sich ausblenden.
    title: source.title !== false,
    progress: source.progress !== false,
    // „Nur Schallplatte“: ausschließlich der runde Kreis.
    vinylOnly: source.vinylOnly === true,
    vinyl: source.vinyl === true || source.vinylOnly === true,
    scaleDefault: true,
  };
  if (source.scaleDefault !== true) music.scale = 0.8;
  return music;
}

const DEFAULT_CROSSHAIR = {
  enabled: true,
  pixelSize: 4,
  opacity: 0.95,
  outline: true,
  pixels: crosshairPreset('cross'),
};

/** Crosshair-Einstellungen aus Nutzereingaben prüfen und begrenzen. */
function normalizeCrosshair(input) {
  const base = {
    ...DEFAULT_CROSSHAIR,
    pixels: DEFAULT_CROSSHAIR.pixels.map((row) => [...row]),
  };
  if (!input || typeof input !== 'object') return base;

  if (typeof input.enabled === 'boolean') base.enabled = input.enabled;
  if (typeof input.outline === 'boolean') base.outline = input.outline;

  const pixelSize = Number(input.pixelSize);
  if (Number.isFinite(pixelSize)) base.pixelSize = clamp(Math.round(pixelSize), 1, 12);
  const opacity = Number(input.opacity);
  if (Number.isFinite(opacity)) base.opacity = clamp(Math.round(opacity * 100) / 100, 0.1, 1);

  if (Array.isArray(input.pixels)) {
    base.pixels = Array.from({ length: CROSSHAIR_SIZE }, (_, y) => {
      const row = Array.isArray(input.pixels[y]) ? input.pixels[y] : [];
      return Array.from({ length: CROSSHAIR_SIZE }, (_, x) =>
        HEX.test(row[x]) ? String(row[x]).toLowerCase() : '',
      );
    });
  }
  return base;
}

const MUSIC_PRESETS = ['tl', 'tc', 'tr', 'ml', 'mc', 'mr', 'bl', 'bc', 'br', 'free'];
const PERF_PRESETS = ['tl', 'tc', 'tr', 'ml', 'mc', 'mr', 'bl', 'bc', 'br', 'free'];

/** Performance-Overlay: welche Werte sichtbar sind und wo die Karte steht. */
function normalizePerf(input) {
  const source = input && typeof input === 'object' ? input : {};
  const offset = (value) => {
    if (value === null || value === undefined || value === '') return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.round(parsed) : null;
  };
  const scale = Number(source.scale);
  const x = offset(source.x);
  const y = offset(source.y);
  return {
    enabled: source.enabled === true,
    preset:
      typeof source.preset === 'string' && PERF_PRESETS.includes(source.preset)
        ? source.preset
        : x !== null || y !== null
          ? 'free'
          : 'tr',
    x,
    y,
    // Standard sind 45 % – danach gilt immer die eigene Wahl.
    scale:
      source.scaleDefault === true && Number.isFinite(scale)
        ? clamp(Math.round(scale * 100) / 100, 0.35, 2)
        : 0.45,
    scaleDefault: true,
    fps: source.fps !== false,
    cpu: source.cpu !== false,
    gpu: source.gpu !== false,
    ram: source.ram !== false,
    ping: source.ping !== false,
    temp: source.temp !== false,
  };
}

const DEFAULT_SETTINGS = {
  displayName: '',
  replayDir: '',
  autoScan: true,
  clipMaxGb: 2,
  clipSeconds: 30,
  clipHotkey: 'F9',
  clipHotkeyEnabled: true,
  clipSourceId: '',
  clipFps: 60,
  clipQuality: 'hoch',
  clipOnKill: true,
  clipOnWin: true,
  clipAutoGame: true,
  clipBurnCrosshair: true,
  clipKeystrokes: true,
  clipAudio: true,
  clipKeystrokesController: true,
  // Sekunden vor einem Kill, die im Kill-Clip landen.
  clipKillSeconds: 15,
  // Sekunden nach dem letzten Kill, bevor der Clip geschrieben wird.
  clipKillPost: 2,
  // Keystrokes im Player standardmäßig zeigen (pro Clip umschaltbar).
  clipKeysShow: true,
  // Mikrofon im Clip (aus), Gerät ('' = Windows-Standard) und Lautstärken in %.
  clipMic: false,
  clipMicId: '',
  clipMicVolume: 100,
  clipSystemVolume: 100,
  // Facecam: eigene Datei neben jedem Clip, im Player verschieb- und abschaltbar.
  camEnabled: false,
  camDeviceId: '',
  // Lange Aufnahmen (bis zum Stoppen) per Knopf oder Hotkey.
  recHotkey: 'F10',
  matchSummary: true,
  clipAutoStart: true,
  clipAutoSave: true,
  killPopup: true,
  damageOcr: true,
  killFeed: true,
  knockDetection: true,
  liveMonitor: true,
  liveSourceId: '',
  crosshair: DEFAULT_CROSSHAIR,
  xh: DEFAULT_APP,
  // Musik-Overlay: kleines Fenster oben am Bildschirm.
  // x/y sind Abstände von der linken oberen Ecke des Arbeitsbereichs.
  // preset: 'tl' oben links (Standard), 'free' = frei verschoben über x/y.
  music: {
    enabled: false, // separater Player standardmäßig aus
    preset: 'tc',
    x: null,
    y: null,
    scale: 0.8,
    lyrics: true,
    vinyl: false,
    scaleDefault: true,
    presetDefault: true,
    edgeDefault: true,
  },
  // Performance-Overlay: FPS, Ping, CPU, GPU und RAM einzeln zuschaltbar.
  perf: {
    enabled: false,
    preset: 'tr',
    x: null,
    y: null,
    scale: 0.45,
    scaleDefault: true,
    fps: true,
    cpu: true,
    gpu: true,
    ram: true,
    ping: true,
    temp: true,
  },
  // Quick Notes und Bildschirmzeit (Sekunden pro Tag, lokal).
  notes: [],
  screentime: {},
  screentimeGame: {},
};

class Store {
  constructor(file) {
    this.file = file;
    this.data = { version: 1, settings: { ...DEFAULT_SETTINGS }, matches: [] };
    this.timer = null;
  }

  load() {
    try {
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.data = {
        version: 1,
        settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
        matches: Array.isArray(parsed.matches) ? parsed.matches.filter((m) => m && m.file) : [],
      };
      this.data.settings.crosshair = normalizeCrosshair(this.data.settings.crosshair);
      this.data.settings.xh = normalizeApp(this.data.settings.xh);
      this.data.settings.music = normalizeMusic(this.data.settings.music);
      this.data.settings.perf = normalizePerf(this.data.settings.perf);
      // einmalig: separater Player und Leistungs-Widget aus (neuer Standard ab Hub 2.10)
      if (!this.data.settings.defaultsV3) {
        this.data.settings.music = { ...this.data.settings.music, enabled: false };
        this.data.settings.perf = { ...this.data.settings.perf, enabled: false };
        this.data.settings.defaultsV3 = true;
      }
      if (!Array.isArray(this.data.settings.notes)) this.data.settings.notes = [];
      if (!this.data.settings.screentime || typeof this.data.settings.screentime !== 'object') {
        this.data.settings.screentime = {};
      }
      if (!this.data.settings.screentimeGame || typeof this.data.settings.screentimeGame !== 'object') {
        this.data.settings.screentimeGame = {};
      }
    } catch {
      this.data = { version: 1, settings: { ...DEFAULT_SETTINGS }, matches: [] };
    }

    for (const key of ['clipMaxGb', 'clipSeconds']) {
      const value = Number(this.data.settings[key]);
      if (!Number.isFinite(value) || value <= 0) {
        this.data.settings[key] = DEFAULT_SETTINGS[key];
      }
    }

    return this.data;
  }

  save() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.flush(), 200);
  }

  flush() {
    clearTimeout(this.timer);
    this.timer = null;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data), 'utf8');
    fs.renameSync(tmp, this.file);
  }

  upsert(match) {
    const entry = { ...match, parsedAt: new Date().toISOString() };
    const index = this.data.matches.findIndex((m) => m.file === match.file);
    if (index >= 0) {
      this.data.matches[index] = entry;
    } else {
      this.data.matches.push(entry);
    }
    this.data.matches.sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
    this.save();
  }

  replaceAll(matches) {
    this.data.matches = matches;
    this.flush();
  }

  clearMatches() {
    this.data.matches = [];
    this.flush();
  }

  get settings() {
    return this.data.settings;
  }
}

module.exports = {
  Store,
  DEFAULT_SETTINGS,
  DEFAULT_CROSSHAIR,
  CROSSHAIR_SIZE,
  normalizeCrosshair,
  normalizeMusic,
  normalizePerf,
  MUSIC_PRESETS,
  PERF_PRESETS,
  crosshairPreset,
};
