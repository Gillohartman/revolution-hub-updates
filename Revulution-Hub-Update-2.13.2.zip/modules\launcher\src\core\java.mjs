import path from "node:path";
import fs from "node:fs";
import { execFile, spawn } from "node:child_process";
import AdmZip from "adm-zip";
import { fetchJson, download } from "./http.mjs";
import { ensureDir, javaDir } from "./paths.mjs";
import { readJson, readJsonSync, writeJson } from "./store.mjs";
import { resolveVersion } from "./mojang.mjs";

const MANIFEST_FILE = () => path.join(javaDir(), "runtimes.json");

function javaBinaryName() {
  return process.platform === "win32" ? "java.exe" : "java";
}

/**
 * Runtimes the launcher downloaded itself, as java binaries.
 *
 * Reads the manifest synchronously on purpose: this is called from the synchronous
 * candidate scan, and using the async reader here silently produced a Promise — so a
 * runtime installed by the launcher was never found and Java was downloaded again on
 * every single launch.
 */
export function managedJavaCandidates() {
  const manifest = readJsonSync(MANIFEST_FILE(), null) || {};
  const runtimes = manifest.runtimes && typeof manifest.runtimes === "object" ? manifest.runtimes : {};
  return Object.values(runtimes)
    .filter((runtime) => runtime && typeof runtime.home === "string" && runtime.home)
    .map((runtime) => path.join(runtime.home, "bin", javaBinaryName()));
}

export function parseJavaVersion(text) {
  // "openjdk version \"21.0.5\" 2024-10-15" / "java version \"1.8.0_402\""
  const match = /version "(\d+)(?:\.(\d+))?[^"]*"/.exec(text);
  if (!match) return null;
  const major = Number(match[1]);
  if (major === 1 && match[2]) return Number(match[2]);
  return major;
}

export function inspectJava(binary) {
  return new Promise((resolve) => {
    execFile(binary, ["-version"], { timeout: 15000 }, (error, stdout, stderr) => {
      const text = `${stdout || ""}\n${stderr || ""}`.trim();
      if (error && !text) return resolve({ path: binary, valid: false, error: String(error.message || error) });
      const major = parseJavaVersion(text);
      const vendorMatch = /^(openjdk|java) version/i.test(text.split("\n")[0] || "") ? text.split("\n")[0] : "";
      // A 32-bit runtime cannot host a large heap, so the bitness matters when choosing.
      const arch = /32-Bit/i.test(text) ? "32" : /64-Bit/i.test(text) ? "64" : "";
      resolve({
        path: binary,
        valid: Boolean(major),
        major,
        arch,
        version: text.split("\n")[0] || "",
        vendor: /(temurin|adoptium)/i.test(text) ? "Eclipse Temurin"
          : /(zulu|azul)/i.test(text) ? "Azul Zulu"
          : /(microsoft)/i.test(text) ? "Microsoft OpenJDK"
          : /(graal)/i.test(text) ? "GraalVM"
          : /(oracle)/i.test(text) ? "Oracle"
          : "Unknown",
        description: vendorMatch,
      });
    });
  });
}

function candidatePaths() {
  const candidates = [];
  if (process.env.JAVA_HOME) candidates.push(path.join(process.env.JAVA_HOME, "bin", javaBinaryName()));
  if (process.platform === "win32") {
    const roots = [
      path.join(process.env.ProgramFiles || "C:\\Program Files"),
      path.join(process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)"),
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, "Programs") : "",
    ].filter(Boolean);
    const vendors = ["Java", "Eclipse Adoptium", "Eclipse Foundation", "Microsoft", "Zulu", "Amazon Corretto", "BellSoft", "Semeru", "JetBrains"];
    for (const root of roots) {
      for (const vendor of vendors) {
        const dir = path.join(root, vendor);
        let entries = [];
        try {
          entries = fs.readdirSync(dir);
        } catch {
          continue;
        }
        for (const entry of entries) {
          candidates.push(path.join(dir, entry, "bin", javaBinaryName()));
        }
      }
    }
  } else if (process.platform === "darwin") {
    candidates.push("/usr/bin/java", "/opt/homebrew/opt/openjdk/bin/java", "/usr/local/opt/openjdk/bin/java");
    const jvms = "/Library/Java/JavaVirtualMachines";
    try {
      for (const entry of fs.readdirSync(jvms)) candidates.push(path.join(jvms, entry, "Contents", "Home", "bin", "java"));
    } catch { /* no JVMs installed */ }
  } else {
    candidates.push("/usr/bin/java", "/usr/local/bin/java");
    for (const dir of ["/usr/lib/jvm", "/usr/java", path.join(process.env.HOME || "", ".sdkman/candidates/java")]) {
      try {
        for (const entry of fs.readdirSync(dir)) candidates.push(path.join(dir, entry, "bin", "java"));
      } catch { /* not present */ }
    }
  }
  // Launcher-managed runtimes.
  candidates.push(...managedJavaCandidates());
  return candidates;
}

/** Every usable Java installation found on this machine, de-duplicated. */
export async function listJavaInstallations({ extraPaths = [] } = {}) {
  const seen = new Set();
  const results = [];
  const paths = [...extraPaths, ...candidatePaths()].filter(Boolean);
  for (const candidate of paths) {
    const resolved = path.resolve(candidate);
    if (seen.has(resolved)) continue;
    seen.add(resolved);
    if (!fs.existsSync(resolved)) continue;
    const info = await inspectJava(resolved);
    if (info.valid) results.push(info);
  }
  // `java` from PATH, resolved last so explicit installs win ties.
  const fromPath = await new Promise((resolve) => {
    execFile(process.platform === "win32" ? "where" : "which", ["java"], { timeout: 10000 }, (error, stdout) => {
      if (error || !stdout) return resolve(null);
      resolve(String(stdout).split(/\r?\n/)[0].trim() || null);
    });
  });
  if (fromPath && !seen.has(path.resolve(fromPath))) {
    const info = await inspectJava(fromPath);
    if (info.valid) results.push(info);
  }
  // Newest first, preferring 64-bit runtimes when two share a major version.
  return results.sort((a, b) => (b.major || 0) - (a.major || 0) || (b.arch === "64" ? 1 : 0) - (a.arch === "64" ? 1 : 0));
}

/** Required Java major version for an already-resolved version json. */
export function requiredJavaMajor(version) {
  return version?.javaVersion?.majorVersion || 8;
}

/**
 * Required runtime for a version that may inherit from another one.
 *
 * Loader profiles (Fabric, Quilt, Forge, NeoForge) carry no `javaVersion` of their own —
 * it lives on the vanilla version they inherit. Reading it from the raw profile makes every
 * loader instance look like it needs Java 8, which is how a 1.21.4 instance ends up launched
 * with a 32-bit Java 8 and dies on "Invalid maximum heap size".
 */
export async function requiredJavaFor(versionJson) {
  const resolved = versionJson?.inheritsFrom ? await resolveVersion(versionJson) : versionJson;
  return {
    major: requiredJavaMajor(resolved),
    component: requiredJavaComponent(resolved),
    resolved,
  };
}

export function requiredJavaComponent(version) {
  return version?.javaVersion?.component || "jre-legacy";
}

/**
 * Choose the best runtime for a required major version: an exact match first,
 * then the smallest newer runtime (Minecraft tolerates newer JVMs, not older).
 */
export function pickJava(installations, required, { preferredPath } = {}) {
  if (preferredPath) {
    const preferred = installations.find((j) => path.resolve(j.path) === path.resolve(preferredPath));
    // Honour a pinned runtime only when it can actually run the version: a runtime older
    // than required would fail deep inside the game instead of here.
    if (preferred && (preferred.major || 0) >= required) return preferred;
    if (!preferred && fs.existsSync(preferredPath)) return { path: preferredPath, major: required, valid: true, vendor: "Configured", version: "" };
  }
  const exact = installations.filter((j) => j.major === required);
  if (exact.length) return exact[0];
  const newer = installations.filter((j) => (j.major || 0) > required).sort((a, b) => a.major - b.major);
  if (newer.length) return newer[0];
  return null;
}

function adoptiumPlatform() {
  const os = process.platform === "win32" ? "windows" : process.platform === "darwin" ? "mac" : "linux";
  const arch = process.arch === "arm64" ? "aarch64" : "x64";
  return { os, arch };
}

/**
 * Download and unpack an Eclipse Temurin JRE for the given major version.
 * (Mojang's own runtime manifest is LZMA-compressed, which needs a native
 * module; Temurin is the same OpenJDK lineage and ships plain zip archives.)
 */
export async function installJavaRuntime(major, { onProgress = () => {} } = {}) {
  const { os, arch } = adoptiumPlatform();
  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${os}/${arch}/jre/hotspot/normal/eclipse`;
  const target = ensureDir(path.join(javaDir(), `temurin-${major}`));
  const zipPath = path.join(target, `temurin-${major}.zip`);

  onProgress({ phase: "java", done: 0, total: 1, message: `Downloading Java ${major} (Eclipse Temurin)` });
  await download(url, zipPath);

  onProgress({ phase: "java", done: 0, total: 1, message: `Extracting Java ${major}` });
  const zip = new AdmZip(zipPath);
  zip.extractAllTo(target, true);
  fs.rmSync(zipPath, { force: true });

  // JDK/JRE archives contain a single versioned top-level folder.
  const entries = fs.readdirSync(target, { withFileTypes: true }).filter((e) => e.isDirectory());
  let home = target;
  for (const entry of entries) {
    const nested = path.join(target, entry.name);
    if (fs.existsSync(path.join(nested, "bin", javaBinaryName()))) {
      home = nested;
      break;
    }
    const macHome = path.join(nested, "Contents", "Home");
    if (fs.existsSync(path.join(macHome, "bin", javaBinaryName()))) {
      home = macHome;
      break;
    }
  }

  const binary = path.join(home, "bin", javaBinaryName());
  if (!fs.existsSync(binary)) throw new Error(`Java ${major} was downloaded but no java binary was found in ${target}`);
  if (process.platform !== "win32") {
    try {
      fs.chmodSync(binary, 0o755);
    } catch { /* best effort */ }
  }

  const manifest = (await readJson(MANIFEST_FILE(), null)) || {};
  if (!manifest.runtimes || typeof manifest.runtimes !== "object") manifest.runtimes = {};
  manifest.runtimes[`temurin-${major}`] = { major, home, binary, installedAt: Date.now(), source: "Eclipse Temurin" };
  await writeJson(MANIFEST_FILE(), manifest);

  onProgress({ phase: "java", done: 1, total: 1, message: `Java ${major} installed` });
  return { major, home, binary };
}

/** Quick validity check used before launching. */
export function testJava(binary) {
  return new Promise((resolve) => {
    const child = spawn(binary, ["-version"], { stdio: ["ignore", "pipe", "pipe"] });
    let output = "";
    child.stdout.on("data", (d) => (output += d));
    child.stderr.on("data", (d) => (output += d));
    child.on("error", (err) => resolve({ ok: false, error: err.message, output }));
    child.on("close", (code) => resolve({ ok: code === 0, code, output, major: parseJavaVersion(output) }));
  });
}

export { fetchJson };
