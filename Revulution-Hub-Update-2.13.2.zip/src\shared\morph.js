'use strict';

/*
 * Flimmerfreies Neuzeichnen: statt innerHTML komplett zu ersetzen (Bilder laden neu,
 * Animationen starten neu = Blinken) werden nur die Knoten geändert, die anders sind.
 * Nutzung: RevMorph.morph(element, html)
 */
(function (root) {
  function morphAttrs(from, to) {
    for (const { name } of [...from.attributes]) if (!to.hasAttribute(name)) from.removeAttribute(name);
    for (const { name, value } of [...to.attributes]) if (from.getAttribute(name) !== value) from.setAttribute(name, value);
    if (from.tagName === 'INPUT' || from.tagName === 'TEXTAREA' || from.tagName === 'SELECT') {
      if (document.activeElement !== from) {
        if (from.type === 'checkbox' || from.type === 'radio') from.checked = to.hasAttribute('checked');
        else if (from.tagName === 'SELECT') {
          const sel = [...to.options].findIndex((o) => o.hasAttribute('selected'));
          if (sel >= 0 && from.selectedIndex !== sel) from.selectedIndex = sel;
        } else if (from.tagName === 'TEXTAREA') {
          if (from.value !== to.textContent) from.value = to.textContent;
        } else if (from.value !== (to.getAttribute('value') ?? '')) from.value = to.getAttribute('value') ?? '';
      }
    }
  }

  function sameKind(a, b) {
    if (a.nodeType !== b.nodeType) return false;
    if (a.nodeType !== 1) return true;
    return a.tagName === b.tagName && (a.id || '') === (b.id || '') && (a.dataset.key || '') === (b.dataset.key || '');
  }

  function morphChildren(from, to) {
    const next = [...to.childNodes];
    let cur = from.firstChild;
    for (const node of next) {
      if (cur && sameKind(cur, node)) {
        if (cur.nodeType === 1) {
          morphAttrs(cur, node);
          if (cur.tagName !== 'TEXTAREA') morphChildren(cur, node);
        } else if (cur.nodeValue !== node.nodeValue) cur.nodeValue = node.nodeValue;
        cur = cur.nextSibling;
      } else {
        from.insertBefore(node, cur);
      }
    }
    while (cur) {
      const rest = cur.nextSibling;
      cur.remove();
      cur = rest;
    }
  }

  function morph(el, html) {
    const tpl = document.createElement('template');
    tpl.innerHTML = html;
    morphChildren(el, tpl.content);
  }

  root.RevMorph = { morph };
})(typeof window !== 'undefined' ? window : globalThis);
