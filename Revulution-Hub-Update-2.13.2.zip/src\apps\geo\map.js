'use strict';

/* Kleine Weltkarte zum Tippen: Kacheln, Ziehen, Zoomen, Pins und Linien. */
(function (root) {
  const TILE = 256;
  // Kartenkacheln ohne API-Schlüssel; fällt ein Anbieter aus, wird der nächste genommen.
  const PROVIDERS = [
    (z, x, y, lang) => `https://mt${(x + y) % 4}.google.com/vt/lyrs=m&hl=${lang}&x=${x}&y=${y}&z=${z}`,
    (z, x, y) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`,
    (z, x, y) => `https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/${z}/${y}/${x}`,
  ];
  let provider = 0;
  let failures = 0;
  const tileUrl = (z, x, y) => PROVIDERS[provider](z, x, y, root.GeoMapLang || 'de');

  const project = (lat, lng, z) => {
    const s = TILE * 2 ** z;
    const sin = Math.sin((Math.max(-85, Math.min(85, lat)) * Math.PI) / 180);
    return { x: ((lng + 180) / 360) * s, y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s };
  };
  const unproject = (x, y, z) => {
    const s = TILE * 2 ** z;
    const lng = (x / s) * 360 - 180;
    const n = Math.PI - (2 * Math.PI * y) / s;
    return { lat: (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lng };
  };

  class GeoMap {
    constructor(el, { onClick, minZoom = 1, maxZoom = 18 } = {}) {
      this.el = el;
      this.el.classList.add('geomap');
      this.el.innerHTML = '<div class="gm-tiles"></div><svg class="gm-svg"></svg><div class="gm-pins"></div>';
      this.tilesEl = el.querySelector('.gm-tiles');
      this.svg = el.querySelector('.gm-svg');
      this.pinsEl = el.querySelector('.gm-pins');
      this.zoom = 2;
      this.center = { lat: 25, lng: 0 };
      this.minZoom = minZoom;
      this.maxZoom = maxZoom;
      this.onClick = onClick;
      this.pins = [];
      this.lines = [];
      this.tiles = new Map();
      this.bind();
      new ResizeObserver(() => this.render()).observe(el);
    }

    size() {
      return { w: this.el.clientWidth, h: this.el.clientHeight };
    }

    toScreen(lat, lng) {
      const c = project(this.center.lat, this.center.lng, this.zoom);
      const p = project(lat, lng, this.zoom);
      const { w, h } = this.size();
      // Welt wiederholt sich horizontal → nächste Kopie wählen
      const world = TILE * 2 ** this.zoom;
      let dx = p.x - c.x;
      if (dx > world / 2) dx -= world;
      if (dx < -world / 2) dx += world;
      return { x: w / 2 + dx, y: h / 2 + (p.y - c.y) };
    }

    toLatLng(sx, sy) {
      const c = project(this.center.lat, this.center.lng, this.zoom);
      const { w, h } = this.size();
      const p = unproject(c.x + sx - w / 2, c.y + sy - h / 2, this.zoom);
      p.lng = ((((p.lng + 180) % 360) + 360) % 360) - 180;
      return p;
    }

    setView(lat, lng, zoom) {
      this.center = { lat, lng };
      this.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, Math.round(zoom)));
      this.render();
    }

    /** Alle Punkte sichtbar machen; bottom = Platz unten (z. B. für ein Ergebnisfenster). */
    fit(points, pad = 60, bottom = 0) {
      if (!points.length) return;
      const { w, h } = this.size();
      for (let z = this.maxZoom; z >= this.minZoom; z -= 1) {
        const pr = points.map((p) => project(p.lat, p.lng, z));
        const xs = pr.map((p) => p.x), ys = pr.map((p) => p.y);
        if (Math.max(...xs) - Math.min(...xs) <= w - pad * 2 && Math.max(...ys) - Math.min(...ys) <= h - pad * 2 - bottom) {
          const c = unproject((Math.max(...xs) + Math.min(...xs)) / 2, (Math.max(...ys) + Math.min(...ys)) / 2 + bottom / 2, z);
          this.setView(c.lat, c.lng, Math.min(z, 16));
          return;
        }
      }
      this.setView(20, 0, this.minZoom);
    }

    bind() {
      let drag = null;
      this.el.addEventListener('pointerdown', (e) => {
        drag = { x: e.clientX, y: e.clientY, c: project(this.center.lat, this.center.lng, this.zoom), moved: false };
        this.el.setPointerCapture(e.pointerId);
      });
      this.el.addEventListener('pointermove', (e) => {
        if (!drag) return;
        const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
        if (!drag.moved) return;
        const c = unproject(drag.c.x - dx, drag.c.y - dy, this.zoom);
        this.center = { lat: Math.max(-80, Math.min(80, c.lat)), lng: c.lng };
        this.render();
      });
      this.el.addEventListener('pointerup', (e) => {
        if (drag && !drag.moved && this.onClick) {
          const r = this.el.getBoundingClientRect();
          this.onClick(this.toLatLng(e.clientX - r.left, e.clientY - r.top));
        }
        drag = null;
      });
      this.el.addEventListener(
        'wheel',
        (e) => {
          e.preventDefault();
          const r = this.el.getBoundingClientRect();
          const sx = e.clientX - r.left, sy = e.clientY - r.top;
          const before = this.toLatLng(sx, sy);
          // Mausrad sammeln: pro Raster ein Schritt, höchstens alle 110 ms – kein Springen mehr
          const now = performance.now();
          this.wheelAcc = (now - (this.wheelAt || 0) > 400 ? 0 : this.wheelAcc || 0) + e.deltaY;
          this.wheelAt = now;
          if (Math.abs(this.wheelAcc) < 60 || now - (this.wheelStep || 0) < 110) return;
          const nz = Math.max(this.minZoom, Math.min(this.maxZoom, this.zoom + (this.wheelAcc < 0 ? 1 : -1)));
          this.wheelAcc = 0;
          this.wheelStep = now;
          if (nz === this.zoom) return;
          this.el.classList.remove('zooming');
          void this.el.offsetWidth;
          this.el.classList.add('zooming');
          this.zoom = nz;
          // Punkt unter dem Mauszeiger bleibt stehen
          const { w, h } = this.size();
          const p = project(before.lat, before.lng, nz);
          const c = unproject(p.x - (sx - w / 2), p.y - (sy - h / 2), nz);
          this.center = { lat: Math.max(-80, Math.min(80, c.lat)), lng: c.lng };
          this.render();
        },
        { passive: false },
      );
    }

    setPins(pins) {
      this.pins = pins || [];
      this.renderOverlay();
    }

    setLines(lines) {
      this.lines = lines || [];
      this.renderOverlay();
    }

    render() {
      const { w, h } = this.size();
      if (!w || !h) return;
      const z = this.zoom;
      const n = 2 ** z;
      const c = project(this.center.lat, this.center.lng, z);
      const x0 = Math.floor((c.x - w / 2) / TILE), x1 = Math.floor((c.x + w / 2) / TILE);
      const y0 = Math.max(0, Math.floor((c.y - h / 2) / TILE)), y1 = Math.min(n - 1, Math.floor((c.y + h / 2) / TILE));
      const want = new Set();
      for (let tx = x0; tx <= x1; tx += 1) {
        for (let ty = y0; ty <= y1; ty += 1) {
          const key = `${z}/${tx}/${ty}`;
          want.add(key);
          let img = this.tiles.get(key);
          if (!img) {
            img = document.createElement('img');
            img.draggable = false;
            img.alt = '';
            img.onerror = () => {
              img.style.visibility = 'hidden';
              // mehrere Fehler hintereinander → anderen Kartenanbieter versuchen
              failures += 1;
              if (failures >= 4 && provider < PROVIDERS.length - 1) {
                provider += 1;
                failures = 0;
                this.reloadTiles();
              }
            };
            img.onload = () => {
              failures = 0;
            };
            const wx = ((tx % n) + n) % n;
            img.src = tileUrl(z, wx, ty);
            this.tiles.set(key, img);
            this.tilesEl.appendChild(img);
          }
          img.style.transform = `translate(${Math.round(tx * TILE - c.x + w / 2)}px, ${Math.round(ty * TILE - c.y + h / 2)}px)`;
        }
      }
      for (const [key, img] of this.tiles) {
        if (!want.has(key)) {
          img.remove();
          this.tiles.delete(key);
        }
      }
      this.renderOverlay();
    }

    reloadTiles() {
      for (const img of this.tiles.values()) img.remove();
      this.tiles.clear();
      this.render();
    }

    renderOverlay() {
      const { w, h } = this.size();
      this.svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
      this.svg.innerHTML = this.lines
        .map((l) => {
          const a = this.toScreen(l.from.lat, l.from.lng), b = this.toScreen(l.to.lat, l.to.lng);
          return `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="${l.color || '#111'}" stroke-width="3" stroke-dasharray="7 6" stroke-linecap="round"/>`;
        })
        .join('');
      this.pinsEl.innerHTML = this.pins
        .map((p) => {
          const s = this.toScreen(p.lat, p.lng);
          return `<div class="gm-pin ${p.kind || ''}" style="left:${s.x}px;top:${s.y}px;--pc:${p.color || '#7552ff'}">${p.label ? `<span>${p.label}</span>` : ''}</div>`;
        })
        .join('');
    }
  }

  root.GeoMap = GeoMap;
})(typeof self !== 'undefined' ? self : globalThis);
