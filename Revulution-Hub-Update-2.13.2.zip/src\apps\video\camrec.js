'use strict';

/*
 * Kamera-Aufnahme (z. B. für Reactions): Webcam + Mikrofon gleichzeitig. Während der Aufnahme
 * läuft das Projekt mit; danach liegt das Video als Bild-im-Bild auf „Video 2“ ab der Stelle,
 * an der die Aufnahme begann.
 */
(function () {
  let cam = null; // { stream, recorder, chunks, startedAt, began, timer }
  const panel = document.createElement('div');
  panel.className = 'camrec glass';
  panel.hidden = true;
  document.body.appendChild(panel);

  function fmt(s) {
    s = Math.max(0, Math.floor(s));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  }

  async function devices() {
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      return { cams: list.filter((d) => d.kind === 'videoinput'), mics: list.filter((d) => d.kind === 'audioinput') };
    } catch {
      return { cams: [], mics: [] };
    }
  }

  async function open(camId = '', micId = '') {
    close();
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: camId ? { exact: camId } : undefined, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } },
        audio: { deviceId: micId ? { exact: micId } : undefined, echoCancellation: true, noiseSuppression: true },
      });
    } catch {
      toast('Kein Zugriff auf Kamera oder Mikrofon. In Windows unter Datenschutz › Kamera/Mikrofon erlauben.', 'error');
      return;
    }
    const { cams, mics } = await devices();
    const vTrack = stream.getVideoTracks()[0], aTrack = stream.getAudioTracks()[0];
    cam = { stream, recorder: null, chunks: [], cams, mics, camId: vTrack?.getSettings().deviceId || camId, micId: aTrack?.getSettings().deviceId || micId };
    panel.hidden = false;
    panel.innerHTML = `<div class="cr-head"><b>Kamera-Aufnahme</b><span class="muted">Webcam + Mikrofon · landet als Bild-im-Bild auf „Video 2“</span><button class="cr-x" data-cr="close" title="Schließen">✕</button></div>
      <video class="cr-preview" autoplay muted playsinline></video>
      <div class="cr-meter"><i id="cr-level"></i></div>
      <div class="cr-row">
        <select class="select" data-cr-cam>${cams.map((d, i) => `<option value="${d.deviceId}" ${d.deviceId === cam.camId ? 'selected' : ''}>${d.label || `Kamera ${i + 1}`}</option>`).join('')}</select>
        <select class="select" data-cr-mic>${mics.map((d, i) => `<option value="${d.deviceId}" ${d.deviceId === cam.micId ? 'selected' : ''}>${d.label || `Mikrofon ${i + 1}`}</option>`).join('')}</select>
      </div>
      <label class="cr-opt"><input type="checkbox" id="cr-play" checked /> Video läuft während der Aufnahme mit (für Reactions – Kopfhörer empfohlen)</label>
      <div class="cr-row"><button class="btn primary cr-rec" data-cr="rec"><i></i>Aufnahme starten</button><span class="cr-time" id="cr-time"></span></div>`;
    panel.querySelector('.cr-preview').srcObject = stream;
    // Pegel des Mikrofons anzeigen
    const ac = new AudioContext();
    const an = ac.createAnalyser();
    an.fftSize = 512;
    ac.createMediaStreamSource(stream).connect(an);
    const buf = new Uint8Array(an.fftSize);
    cam.ac = ac;
    const meter = () => {
      if (!cam || cam.stream !== stream) return;
      an.getByteTimeDomainData(buf);
      let peak = 0;
      for (const v of buf) peak = Math.max(peak, Math.abs(v - 128) / 128);
      const el = document.getElementById('cr-level');
      if (el) el.style.width = `${Math.min(100, peak * 140)}%`;
      if (cam.recorder) {
        const t = document.getElementById('cr-time');
        if (t) t.textContent = `● ${fmt((performance.now() - cam.began) / 1000)}`;
      }
      requestAnimationFrame(meter);
    };
    meter();
  }

  function start() {
    if (!cam || cam.recorder) return;
    const type = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find((t) => MediaRecorder.isTypeSupported(t));
    const recorder = new MediaRecorder(cam.stream, { mimeType: type, videoBitsPerSecond: 6_000_000 });
    cam.chunks = [];
    recorder.ondataavailable = (e) => e.data.size && cam?.chunks.push(e.data);
    recorder.onstop = save;
    cam.recorder = recorder;
    cam.startedAt = state.time;
    cam.began = performance.now();
    recorder.start(500);
    panel.classList.add('recording');
    const btn = panel.querySelector('[data-cr="rec"]');
    if (btn) btn.innerHTML = '<i></i>Stopp';
    if (document.getElementById('cr-play')?.checked && !state.playing) play();
  }

  async function save() {
    const c = cam;
    const chunks = c.chunks;
    const startedAt = c.startedAt;
    close();
    if (state.playing) pause();
    const blob = new Blob(chunks, { type: 'video/webm' });
    if (blob.size < 20000) return toast('Die Aufnahme war zu kurz.');
    busy('Kamera-Aufnahme wird gespeichert …');
    try {
      const info = await api.camRecording(await blob.arrayBuffer());
      const id = addMedia(info);
      snapshot();
      // Reaction-Ecke unten rechts auf Video 2
      const clip = { id: uid(), track: 'v2', media: id, start: startedAt, in: 0, out: info.duration, volume: 1, muted: false, scale: 0.34, x: 0.62, y: 0.6 };
      P().clips.push(clip);
      resolveOverlaps(clip);
      state.selected = clip.id;
      changed();
      toast('Kamera-Aufnahme liegt als Bild-im-Bild auf „Video 2“ – Größe und Ecke rechts unter „Transformieren“.');
    } catch (error) {
      toast(error.message || String(error), 'error');
    } finally {
      busy('');
    }
  }

  function close() {
    if (!cam) return;
    const c = cam;
    cam = null;
    try {
      if (c.recorder && c.recorder.state !== 'inactive') {
        cam = c; // save() braucht die Daten noch
        c.recorder.stop();
        return;
      }
    } catch {
      /* egal */
    }
    c.stream.getTracks().forEach((t) => t.stop());
    c.ac?.close().catch(() => {});
    panel.hidden = true;
    panel.classList.remove('recording');
    panel.innerHTML = '';
  }

  panel.addEventListener('click', (e) => {
    const a = e.target.closest('[data-cr]')?.dataset.cr;
    if (a === 'close') {
      if (cam?.recorder) cam.recorder.stop();
      else close();
    }
    if (a === 'rec') {
      if (cam?.recorder) cam.recorder.stop();
      else start();
    }
  });
  panel.addEventListener('change', (e) => {
    if (cam?.recorder) return;
    if (e.target.matches('[data-cr-cam]')) open(e.target.value, cam?.micId || '');
    if (e.target.matches('[data-cr-mic]')) open(cam?.camId || '', e.target.value);
  });

  window.CamRec = { open: () => open(), active: () => Boolean(cam) };
})();
