const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('clipper', {
  onState: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('clipper:state', handler);
    return () => ipcRenderer.removeListener('clipper:state', handler);
  },
  ready: () => ipcRenderer.send('clipper:ready'),
});
