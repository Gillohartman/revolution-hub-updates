# Third-party notices

A Revolution build redistributes the software below. Nothing else is bundled:
Minecraft itself, its libraries, assets and the mod loaders are downloaded from
their own publishers on the user's machine at the user's request.

## Bundled in every build

| Component | Licence | Notice |
| --- | --- | --- |
| [Electron](https://github.com/electron/electron) (incl. Node.js) | MIT | Full text ships next to the app as `LICENSE.electron.txt` |
| Chromium and its third-party libraries | BSD-3-Clause and others | Full list ships next to the app as `LICENSES.chromium.html` |
| [React](https://react.dev) / React DOM | MIT | Copyright Meta Platforms, Inc. and affiliates |
| [adm-zip](https://github.com/cthackers/adm-zip) | MIT | Used for `.zip` instance export and modpack import |

## Downloaded at runtime, not redistributed

| Component | Licence | Source |
| --- | --- | --- |
| Minecraft client, libraries and assets | Mojang's own terms | `piston-meta.mojang.com`, `resources.download.minecraft.net` |
| Eclipse Temurin JRE | GPL-2.0-with-classpath-exception | Adoptium API, only when a version needs a Java the machine lacks |
| Fabric, Quilt, Forge, NeoForge | Each project's own licence | Their metadata APIs and Maven repositories |
| Modrinth content (mods, packs, shaders) | Each project's own licence | Modrinth API |

## Trademarks and affiliation

Minecraft is a trademark of Mojang Studios. Revolution is an independent,
clean-room implementation; it is not affiliated with, endorsed by or sponsored
by Mojang Studios, Microsoft, or the Prism Launcher project. Prism Launcher is
GPL-3.0-only and no part of its code or branding is used here.
