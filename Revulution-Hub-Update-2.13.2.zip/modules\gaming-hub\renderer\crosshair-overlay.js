const stage = document.getElementById('stage');
const mark = document.getElementById('mark');

let current = null;
let aiming = false;

/** Beim Zielen (rechte Maustaste) rückt das Crosshair enger zusammen. */
function applyTransform() {
  if (!current) return;
  const profile = current.profile;
  if (!profile) return;
  const tighten = aiming && profile.aimTighten !== false ? 0.72 : 1;
  mark.style.transform =
    `translate(${Math.round(current.offsetX || 0)}px, ${Math.round(current.offsetY || 0)}px)` +
    (tighten !== 1 ? ` scale(${tighten})` : '') +
    (profile.rotation ? ` rotate(${profile.rotation}deg)` : '');
}

function setAiming(next) {
  const value = Boolean(next?.aiming);
  if (value === aiming) return;
  aiming = value;
  mark.style.transition = 'transform 90ms ease-out';
  applyTransform();
}

function mediaUrl(file) {
  const value = String(file || '');
  if (value.startsWith('ranks/')) return `xh://rank/${encodeURIComponent(value.slice(6))}`;
  return `xh://crosshair/${encodeURIComponent(value)}`;
}

function apply(payload) {
  if (!payload) return;
  current = payload;

  const profile = payload.profile;
  const visible = Boolean(payload.visible && profile && profile.opacity > 0);

  if (!profile) {
    mark.replaceChildren();
    stage.dataset.visible = 'false';
    return;
  }

  const pixelRatio = window.devicePixelRatio || 1;
  XH.render(mark, profile, {
    scale: payload.scale || 1,
    pixelRatio,
    mediaUrl,
  });

  mark.style.opacity = String(profile.opacity);
  applyTransform();

  stage.dataset.visible = visible ? 'true' : 'false';
}

if (window.xhOverlay) {
  window.xhOverlay.onConfig(apply);
  window.xhOverlay.onAim?.(setAiming);
  window.xhOverlay.ready();
} else {
  // Vorschau im normalen Browser (Design-Entwicklung).
  apply({
    profile: {
      kind: 'cross',
      color: '#3ce88f',
      length: 14,
      thickness: 3,
      gap: 5,
      dot: 0,
      ring: 12,
      outline: 1.5,
      opacity: 1,
      rotation: 0,
      image: '',
      imageScale: 1,
      blend: 'normal',
    },
    scale: 1,
    offsetX: 0,
    offsetY: 0,
    visible: true,
  });
}
