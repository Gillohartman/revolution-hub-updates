import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { fetchJson, request, download } from "./http.mjs";
import { ensureDir, metaDir, versionsDir, instancesDir, javaDir } from "./paths.mjs";
import { readJson, readJsonSync } from "./store.mjs";
import { getVersionJson, saveVersionJson, resolveVersion } from "./mojang.mjs";

export const LOADERS = [
  { id: "vanilla", name: "Vanilla", description: "Unmodified Minecraft, no mods." },
  { id: "fabric", name: "Fabric", description: "Lightweight, fast-updating mod loader." },
  { id: "quilt", name: "Quilt", description: "Fabric-compatible loader with extra APIs." },
  { id: "forge", name: "Forge", description: "The classic large mod-loader ecosystem." },
  { id: "neoforge", name: "NeoForge", description: "Modern Forge fork for 1.20.2 and newer." },
  { id: "optifine", name: "OptiFine", description: "Performance and shader support (uses your own OptiFine jar)." },
];

const FABRIC_META = "https://meta.fabricmc.net/v2";
const QUILT_META = "https://meta.quiltmc.org/v3";
const FORGE_MAVEN = "https://maven.minecraftforge.net/net/minecraftforge/forge";
const NEOFORGE_MAVEN = "https://maven.neoforged.net/releases/net/neoforged";

/** Pre-release markers used by loader projects (Quilt ships mostly betas). */
export function isPrerelease(version) {
  return /(?:alpha|beta|rc|pre|snapshot)/i.test(String(version || ""));
}

/**
 * Order loader builds the way a player wants them: newest stable first, then newest
 * pre-releases. Quilt's meta API returns its list in build order, not version order, so
 * without this the UI would offer a beta (or an old stable) as the default build.
 */
export function sortLoaderOptions(options) {
  const ranked = [...options].map((option) => ({
    ...option,
    stable: option.stable !== false && !isPrerelease(option.version),
  }));
  ranked.sort((a, b) => {
    if (a.stable !== b.stable) return a.stable ? -1 : 1;
    return compareVersions(b.version, a.version);
  });
  return ranked;
}

function parseMavenMetadata(xml) {
  const versions = [];
  const re = /<version>([^<]+)<\/version>/g;
  let match;
  while ((match = re.exec(xml))) versions.push(match[1]);
  return versions;
}

/** Loader versions compatible with a Minecraft version, newest first. */
export async function listLoaderVersions(type, mcVersion, { limit = 60 } = {}) {
  if (!mcVersion) return [];
  switch (type) {
    case "fabric": {
      const data = await fetchJson(`${FABRIC_META}/versions/loader/${mcVersion}`);
      return sortLoaderOptions(data.map((entry) => ({ version: entry.loader.version, stable: entry.loader.stable }))).slice(0, limit);
    }
    case "quilt": {
      const data = await fetchJson(`${QUILT_META}/versions/loader/${mcVersion}`);
      return sortLoaderOptions(data.map((entry) => ({ version: entry.loader.version }))).slice(0, limit);
    }
    case "forge": {
      const xml = await (await request(`${FORGE_MAVEN}/maven-metadata.xml`)).text();
      const prefix = `${mcVersion}-`;
      const versions = parseMavenMetadata(xml)
        .filter((v) => v.startsWith(prefix))
        .map((v) => ({ version: v.slice(prefix.length), stable: true }));
      // Recommended/latest tags from the promotions file are surfaced first.
      try {
        const promos = await fetchJson("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json");
        const latest = promos.promos?.[`${mcVersion}-latest`];
        const recommended = promos.promos?.[`${mcVersion}-recommended`];
        // Forge marks one build "recommended" and one "latest"; recommended is the safer
        // default for players, so it leads the list.
        const rank = (tag) => (tag === "recommended" ? 2 : tag === "latest" ? 1 : 0);
        return versions
          .map((v) => ({ ...v, tag: v.version === recommended ? "recommended" : v.version === latest ? "latest" : "" }))
          .sort((a, b) => rank(b.tag) - rank(a.tag) || compareVersions(b.version, a.version))
          .slice(0, limit);
      } catch {
        return sortLoaderOptions(versions).slice(0, limit);
      }
    }
    case "neoforge": {
      const xml = await (await request(`${NEOFORGE_MAVEN}/neoforge/maven-metadata.xml`)).text();
      const all = parseMavenMetadata(xml);
      const [major, minor] = mcVersion.split(".").slice(1);
      const expectedPrefix = `${major}.${minor}.`;
      const versions = all.filter((v) => v.startsWith(expectedPrefix)).map((v) => ({ version: v, stable: true }));
      if (versions.length) return sortLoaderOptions(versions).slice(0, limit);
      // 1.20.1 NeoForge ships under the legacy `forge` artifact id.
      if (mcVersion === "1.20.1") {
        const legacyXml = await (await request(`${NEOFORGE_MAVEN}/forge/maven-metadata.xml`)).text();
        return parseMavenMetadata(legacyXml)
          .filter((v) => v.startsWith("1.20.1-"))
          .map((v) => ({ version: v, stable: true }))
          .sort((a, b) => compareVersions(b.version, a.version))
          .slice(0, limit);
      }
      return [];
    }
    default:
      return [];
  }
}

function compareVersions(a, b) {
  const pa = String(a).split(/[.\-+]/).map((n) => Number(n) || 0);
  const pb = String(b).split(/[.\-+]/).map((n) => Number(n) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  }
  return 0;
}

/** The version id a loader install produces (used for launching). */
export function loaderVersionId(mcVersion, type, loaderVersion) {
  switch (type) {
    case "fabric":
      return `fabric-loader-${loaderVersion}-${mcVersion}`;
    case "quilt":
      return `quilt-loader-${loaderVersion}-${mcVersion}`;
    case "forge":
      return `${mcVersion}-forge-${loaderVersion}`;
    case "neoforge":
      return `neoforge-${loaderVersion}`;
    default:
      return mcVersion;
  }
}

/**
 * Install a mod loader into the shared meta directory and return the version id
 * that can then be launched like any vanilla version.
 */
export async function installLoader({ mcVersion, type, loaderVersion, javaPath, onProgress = () => {} }) {
  if (type === "vanilla") return { versionId: mcVersion, type };
  if (!mcVersion) throw new Error("A Minecraft version is required before installing a loader.");

  onProgress({ phase: "loader", message: `Preparing ${type}` });

  if (type === "fabric" || type === "quilt") {
    const base = type === "fabric" ? FABRIC_META : QUILT_META;
    const profile = await fetchJson(`${base}/versions/loader/${mcVersion}/${loaderVersion}/profile/json`);
    await getVersionJson(mcVersion); // ensure the parent version exists locally
    await saveVersionJson(profile);
    onProgress({ phase: "loader", done: 1, total: 1, message: `${type} ${loaderVersion} installed` });
    return { versionId: profile.id, type, loaderVersion };
  }

  if (type === "forge" || type === "neoforge" || type === "optifine") {
    const before = listInstalledVersionIds();
    let jarPath;
    if (type === "neoforge") {
      const artifact = mcVersion === "1.20.1" ? `${NEOFORGE_MAVEN}/forge/${loaderVersion}/forge-${loaderVersion}-installer.jar`
        : `${NEOFORGE_MAVEN}/neoforge/${loaderVersion}/neoforge-${loaderVersion}-installer.jar`;
      jarPath = path.join(metaDir(), "installers", `neoforge-${loaderVersion}-installer.jar`);
      await download(artifact, jarPath);
    } else if (type === "forge") {
      const artifact = `${FORGE_MAVEN}/${mcVersion}-${loaderVersion}/forge-${mcVersion}-${loaderVersion}-installer.jar`;
      jarPath = path.join(metaDir(), "installers", `forge-${mcVersion}-${loaderVersion}-installer.jar`);
      await download(artifact, jarPath);
    } else {
      throw new Error("OptiFine must be installed from a jar you downloaded from optifine.net.");
    }

    await getVersionJson(mcVersion);
    await runInstallerJar(jarPath, { javaPath, onProgress });
    const after = listInstalledVersionIds();
    const created = after.filter((id) => !before.includes(id));
    const versionId = created.find((id) => /forge|optifine/i.test(id)) || created[0] || loaderVersionId(mcVersion, type, loaderVersion);
    onProgress({ phase: "loader", done: 1, total: 1, message: `${type} installed as ${versionId}` });
    return { versionId, type, loaderVersion, created };
  }

  throw new Error(`Unsupported loader: ${type}`);
}

/** Run a downloaded OptiFine (or custom) installer jar into the shared meta dir. */
export async function installFromInstallerJar({ jarPath, javaPath, onProgress = () => {} }) {
  const before = listInstalledVersionIds();
  await runInstallerJar(jarPath, { javaPath, onProgress });
  const created = listInstalledVersionIds().filter((id) => !before.includes(id));
  if (!created.length) throw new Error("The installer finished but produced no launchable version.");
  return { versionId: created[0], created };
}

function listInstalledVersionIds() {
  try {
    return fs.readdirSync(versionsDir()).filter((entry) => fs.existsSync(path.join(versionsDir(), entry, `${entry}.json`)));
  } catch {
    return [];
  }
}

/**
 * Forge/NeoForge/OptiFine installers are plain Java programs. They expect a
 * launcher-like directory, so we give them the shared meta dir plus a minimal
 * launcher_profiles.json, then run the jar with the configured runtime.
 */
function runInstallerJar(jarPath, { javaPath, onProgress = () => {} }) {
  if (!fs.existsSync(jarPath)) throw new Error(`Installer jar not found: ${jarPath}`);
  const target = ensureDir(metaDir());
  const profilesFile = path.join(target, "launcher_profiles.json");
  if (!fs.existsSync(profilesFile)) {
    fs.writeFileSync(profilesFile, JSON.stringify({ profiles: {}, settings: {}, version: 3 }, null, 2), "utf8");
  }
  const java = javaPath || resolveAnyJava();
  if (!java) throw new Error("Java is required to run mod-loader installers. Install a JRE or let Revolution download one.");

  return new Promise((resolve, reject) => {
    const child = spawn(java, ["-jar", jarPath, "--installClient", target], { cwd: target, windowsHide: true });
    const lines = [];
    child.stdout.on("data", (d) => {
      const text = d.toString();
      lines.push(text);
      onProgress({ phase: "loader", message: text.trim().split(/\r?\n/).pop() || "" });
    });
    child.stderr.on("data", (d) => {
      const text = d.toString();
      lines.push(text);
      onProgress({ phase: "loader", message: text.trim().split(/\r?\n/).pop() || "" });
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve({ code, output: lines.join("") });
      else reject(new Error(`The loader installer exited with code ${code}: ${lines.join("").slice(-800)}`));
    });
  });
}

function resolveAnyJava() {
  // Synchronous read: see managedJavaCandidates() in java.mjs — the async reader returns a
  // Promise here, which made every launcher-managed runtime invisible to this scan.
  const manifest = readJsonSync(path.join(javaDir(), "runtimes.json"), null) || {};
  const managed = Object.values(manifest.runtimes || {})[0];
  if (managed?.binary && fs.existsSync(managed.binary)) return managed.binary;
  if (process.env.JAVA_HOME) {
    const candidate = path.join(process.env.JAVA_HOME, "bin", process.platform === "win32" ? "java.exe" : "java");
    if (fs.existsSync(candidate)) return candidate;
  }
  return process.platform === "win32" ? "java.exe" : "java";
}

/** Fabric dependencies (fabric-api etc.) are discovered through Modrinth in content.mjs. */

export { resolveVersion, instancesDir };
