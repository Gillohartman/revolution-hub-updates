const badge = document.getElementById('badge');

function flash() {
  badge.classList.remove('is-on');
  // Reflow erzwingen, damit die Animation bei schnellen Clips neu startet.
  void badge.offsetWidth;
  badge.classList.add('is-on');
  clearTimeout(flash.timer);
  flash.timer = setTimeout(() => badge.classList.remove('is-on'), 1100);
}

if (window.clipCheck) window.clipCheck.onFlash(flash);
