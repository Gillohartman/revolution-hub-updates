'use strict';
/*
 * Der Coach als Charakter: Gesicht mit Augen und Mund, spricht mit der Windows-Stimme
 * (Web Speech, offline) und bewegt dabei den Mund. Stimmung je nach Zug (froh, besorgt, nachdenklich).
 */
(function () {
  const svg = `<svg viewBox="0 0 120 120" class="ca-svg" aria-hidden="true">
    <defs>
      <radialGradient id="ca-skin" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#f8d6b6"/><stop offset="1" stop-color="#e7bb93"/></radialGradient>
      <linearGradient id="ca-hair" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e6c584"/><stop offset="1" stop-color="#c09a56"/></linearGradient>
    </defs>
    <ellipse cx="60" cy="113" rx="36" ry="6" fill="rgba(0,0,0,.28)"/>
    <path d="M20 114c2-20 18-31 40-31s38 11 40 31Z" fill="#1e2a3a"/>
    <path d="M50 81l10 15 10-15 8 5-18 24-18-24Z" fill="#f4f6fa"/>
    <path d="M57 84l3 6 3-6 4 3-7 22-7-22Z" fill="#2f4a6d"/>
    <path d="M53 78h14v9H53Z" fill="#e7bb93"/>
    <circle cx="60" cy="55" r="34" fill="url(#ca-skin)"/>
    <ellipse cx="27" cy="57" rx="5" ry="8" fill="#e7bb93"/><ellipse cx="93" cy="57" rx="5" ry="8" fill="#e7bb93"/>
    <path d="M25 47c1-23 17-35 36-35 21 0 35 13 35 34-8-9-20-13-35-13-14 0-27 5-36 14Z" fill="url(#ca-hair)"/>
    <path d="M31 30c8-9 18-13 30-11-9 2-18 8-24 17Z" fill="#f0d59a"/>
    <path d="M83 25c4 5 6 11 6 17-4-7-9-12-16-15Z" fill="#b78f4d"/>
    <g class="ca-brows"><path class="ca-brow l" d="M38 42q8-5 15 0"/><path class="ca-brow r" d="M67 42q7-5 15 0"/></g>
    <g class="ca-eyes"><ellipse class="ca-eye" cx="46" cy="54" rx="5" ry="6"/><ellipse class="ca-eye" cx="74" cy="54" rx="5" ry="6"/>
      <circle cx="47.5" cy="52" r="1.6" fill="#fff"/><circle cx="75.5" cy="52" r="1.6" fill="#fff"/></g>
    <path d="M60 55v8l3 2" fill="none" stroke="#d8a67f" stroke-width="1.6" stroke-linecap="round"/>
    <ellipse cx="35" cy="68" rx="6" ry="3.5" fill="#ef9a8f" opacity=".3"/><ellipse cx="85" cy="68" rx="6" ry="3.5" fill="#ef9a8f" opacity=".3"/>
    <path class="ca-mouth" d="M47 72q13 9 26 0"/>
  </svg>`;
  const MOUTH = {
    smile: 'M48 72q12 9 24 0',
    flat: 'M50 74q10 1 20 0',
    worried: 'M50 77q10-6 20 0',
    o: 'M54 72q6-6 12 0q-6 9-12 0Z',
    open: 'M48 70q12-2 24 0q-12 14-24 0Z',
    half: 'M49 71q11 0 22 0q-11 8-22 0Z',
    wide: 'M46 70q14-3 28 0q-14 12-28 0Z',
  };
  const MOODS = { brilliant: 'happy', great: 'happy', best: 'happy', excellent: 'happy', good: 'happy', book: 'happy', inaccuracy: 'think', mistake: 'worried', miss: 'worried', blunder: 'worried', think: 'think' };

  let el = null, mouth = null, mood = 'happy', talking = null, lastText = '', voice = null;
  const pickVoice = (lang) => {
    const vs = window.speechSynthesis?.getVoices() || [];
    const same = vs.filter((v) => v.lang?.toLowerCase().startsWith(lang));
    // Weibliche Stimme als Standard (Hedda, Katja, Zira, Sabina …).
    const female = /hedda|katja|zira|sabina|aria|jenny|sonia|natasha|helena|female|frau/i;
    return same.find((v) => female.test(v.name) && /natural|online/i.test(v.name)) || same.find((v) => female.test(v.name)) || same.find((v) => /natural|online/i.test(v.name)) || same[0] || null;
  };
  window.speechSynthesis?.addEventListener?.('voiceschanged', () => (voice = null));

  function rest() {
    if (mouth) mouth.setAttribute('d', mood === 'worried' ? MOUTH.worried : mood === 'think' ? MOUTH.flat : MOUTH.smile);
  }
  function setMood(m) {
    mood = m || 'happy';
    if (el) el.dataset.mood = mood;
    if (!talking) rest();
  }
  function stopTalking() {
    clearInterval(talking);
    talking = null;
    el?.classList.remove('talking');
    rest();
  }
  function startTalking() {
    clearInterval(talking);
    el?.classList.add('talking');
    const shapes = [MOUTH.half, MOUTH.open, MOUTH.o, MOUTH.wide, MOUTH.half, MOUTH.flat];
    talking = setInterval(() => mouth?.setAttribute('d', shapes[Math.floor(Math.random() * shapes.length)]), 95);
  }
  const clean = (html) => {
    const d = document.createElement('div');
    d.innerHTML = String(html || '');
    d.querySelectorAll('button').forEach((b) => b.remove());
    return d.textContent.replace(/\s+/g, ' ').replace(/[♔-♟◆★✓✗⏱]/g, '').trim();
  };
  // Schachnotation vorlesbar machen: Sf3 → Springer f3, exd5 → e schlägt d5
  const speakable = (t, lang) => {
    if (lang !== 'de') return t;
    const P = { K: 'König', D: 'Dame', T: 'Turm', L: 'Läufer', S: 'Springer' };
    return t
      .replace(/\b([KDTLS])([a-h]?[1-8]?)x([a-h][1-8])[+#]?/g, (_, p, _d, sq) => `${P[p]} schlägt ${sq}`)
      .replace(/\b([KDTLS])[a-h]?[1-8]?([a-h][1-8])[+#]?/g, (_, p, sq) => `${P[p]} ${sq}`)
      .replace(/\b([a-h])x([a-h][1-8])[+#]?/g, '$1 schlägt $2')
      .replace(/\bO-O-O\b/g, 'lange Rochade')
      .replace(/\bO-O\b/g, 'kurze Rochade');
  };

  window.CoachAvatar = {
    mount(host) {
      if (!host) return;
      host.innerHTML = svg;
      el = host;
      el.classList.add('coach-avatar');
      mouth = host.querySelector('.ca-mouth');
      setMood('happy');
      // Gesicht bleibt ruhig – nur der Mund bewegt sich beim Sprechen
    },
    mood: setMood,
    moodFor: (cls) => MOODS[cls] || 'happy',
    /** Spricht den Text (HTML erlaubt). on = Stimme an, sonst nur Mundbewegung. */
    natural: false, // Piper-Stimme verwenden (falls installiert)
    say(html, { on = true, lang = 'de', cls = '' } = {}) {
      const text = clean(html);
      if (cls) setMood(MOODS[cls] || 'happy');
      if (!text || text === lastText) return Promise.resolve();
      lastText = text;
      if (on && this.natural && window.chessTts) return this.sayNatural(speakable(text, lang), this.voiceId || lang).catch(() => this.sayWindows(text, lang));
      return this.sayWindows(text, lang, on);
    },
    /** Piper: WAV abspielen, Mund folgt der Lautstärke. */
    async sayNatural(text, lang) {
      this.quietAudio();
      const id = (this.seq = (this.seq || 0) + 1);
      const bytes = await window.chessTts.speak(text, lang);
      if (id !== this.seq) return;
      const ac = (this.ac ||= new AudioContext());
      const buf = await ac.decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
      if (id !== this.seq) return;
      const src = ac.createBufferSource();
      const an = ac.createAnalyser();
      an.fftSize = 512;
      src.buffer = buf;
      src.connect(an);
      an.connect(ac.destination);
      this.src = src;
      el?.classList.add('talking');
      const data = new Uint8Array(an.fftSize);
      const shapes = [MOUTH.flat, MOUTH.half, MOUTH.o, MOUTH.open, MOUTH.wide];
      const loop = () => {
        if (this.src !== src) return;
        an.getByteTimeDomainData(data);
        let sum = 0;
        for (const v of data) sum += (v - 128) * (v - 128);
        const rms = Math.sqrt(sum / data.length) / 128;
        mouth?.setAttribute('d', shapes[Math.min(shapes.length - 1, Math.floor(rms * 18))]);
        requestAnimationFrame(loop);
      };
      return new Promise((resolve) => {
        src.onended = () => {
          if (this.src === src) this.src = null;
          stopTalking();
          resolve();
        };
        src.start();
        loop();
      });
    },
    quietAudio() {
      try {
        this.src?.stop();
      } catch {}
      this.src = null;
    },
    sayWindows(text, lang = 'de', on = true) {
      const synth = window.speechSynthesis;
      if (!on || !synth) {
        startTalking();
        clearTimeout(this.t);
        this.t = setTimeout(stopTalking, Math.min(4000, 300 + text.length * 45));
        return Promise.resolve();
      }
      synth.cancel();
      return new Promise((resolve) => {
        const u = new SpeechSynthesisUtterance(speakable(text, lang).slice(0, 400));
        voice = (this.winVoice && (window.speechSynthesis.getVoices() || []).find((v) => v.name === this.winVoice)) || voice || pickVoice(lang);
        if (voice) u.voice = voice;
        u.lang = { de: 'de-DE', en: 'en-US', es: 'es-ES' }[lang] || 'de-DE';
        u.rate = 1.04;
        u.pitch = 1.05;
        u.onstart = startTalking;
        const done = () => {
          stopTalking();
          resolve();
        };
        u.onend = done;
        u.onerror = done;
        synth.speak(u);
        // Sicherheitsnetz, falls Windows kein Ende meldet
        setTimeout(done, 1500 + text.length * 90);
      });
    },
    quiet() {
      this.seq = (this.seq || 0) + 1;
      this.quietAudio();
      window.speechSynthesis?.cancel();
      stopTalking();
      lastText = '';
    },
  };
})();
