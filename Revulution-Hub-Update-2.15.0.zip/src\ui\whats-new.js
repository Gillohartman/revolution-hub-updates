'use strict';
/* „Was ist neu“: erscheint einmal nach jedem Update. Jeder Eintrag führt direkt zur Funktion. */
window.WHATS_NEW = {
  version: '2.15.0',
  title: 'Revulution Hub 2.15',
  sub: 'Klick auf einen Eintrag – du landest direkt dort. Oben links kommst du jederzeit hierher zurück.',
  items: [
    { open: 'video', icon: 'video', title: 'TikTok-Effekte & Übergänge', text: 'VHS, Neon, Chromatic, Oldfilm, Kalt und Warm als Effekte – dazu Blitz, Zoom, Schieben und Shake als Übergänge zwischen Clips. Projektformat jetzt auch 9:16 und 1:1.' },
    { open: 'chess', icon: 'chess', title: 'Magnus als Coach', text: 'Der Schach-Coach hat einen neuen Magnus-Look und spricht standardmäßig mit weiblicher Stimme (Lena). Weitere Stimmen bleiben auswählbar.' },
    { open: 'tool-keyboard', icon: 'tool-keyboard', title: 'Standard-GIFs fürs Display', text: 'Wireframe, Pixel und Mini sind fest dabei – einzeln oder als „Alle drei“ fürs Tastatur-Display. Ein eigenes hochgeladenes GIF bleibt jetzt stehen.' },
    { open: 'home', icon: 'home', title: 'Neues Design in der ganzen App', text: 'Dunkle Resolve-Optik mit blauem Akzent, klareren Panels und einheitlichen Knöpfen – von der Startseite bis in die Apps.' },
  ],
};
