'use strict';

const $ = (selector) => document.querySelector(selector);
const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);

const APPS = {
  gaming: {
    nav: 'Gaming',
    title: 'Gaming Hub',
    sub: 'Revulution Gaming Hub',
    icon: 'crosshair',
    tint: 'linear-gradient(135deg,#ff5d8f,#c2295d)',
    desc: 'Crosshair-Overlay für Fortnite, Clips, Musik- und Leistungs-Overlay, Audio-Mixer, Statistiken und Bildschirmzeit.',
  },
  orbit: {
    nav: 'Island',
    title: 'Revulution Island',
    sub: 'Dynamic Island für Windows',
    icon: 'island',
    tint: 'linear-gradient(135deg,#9a7dff,#6a45f5)',
    desc: 'Die Dynamic Island am oberen Bildschirmrand – mit allen Einstellungen direkt hier im Hub.',
  },
  screenshot: {
    nav: 'Screenshot',
    title: 'Screenshot',
    sub: 'Aufnehmen, markieren, teilen',
    icon: 'camera',
    tint: 'linear-gradient(135deg,#38bdf8,#1d7fd1)',
    desc: 'Bereich oder Bildschirm per Hotkey aufnehmen, mit Pfeilen, Text, Markern und Verpixeln bearbeiten, kopieren oder speichern.',
  },
  video: {
    nav: 'Video',
    title: 'Video-Schnitt',
    sub: 'Schneiden & exportieren',
    icon: 'scissors',
    tint: 'linear-gradient(135deg,#ffb547,#e9720f)',
    desc: 'Videos zuschneiden, teilen und Stücke entfernen. Export als MP4, GIF oder MP3 – auch blitzschnell ohne Neukodierung.',
  },
  beat: {
    nav: 'Beat Lab',
    title: 'Beat Lab',
    sub: 'Beats bauen & exportieren',
    icon: 'music',
    tint: 'linear-gradient(135deg,#38bdf8,#8b5cf6)',
    desc: 'Step-Sequencer mit Drums, Bass, Lead und Piano Roll. Kits, Mixer, Effekte, Song-Kette und WAV-Export – direkt im Hub.',
  },
  docs: {
    nav: 'Dokumente',
    title: 'Dokumente',
    sub: 'Textverarbeitung',
    icon: 'doc',
    tint: 'linear-gradient(135deg,#7aa7ff,#4a63e6)',
    desc: 'Schreiben wie in Word: Formatvorlagen, Tabellen, Bilder, Seitenansicht. Öffnet und speichert .docx, exportiert PDF.',
  },
  chess: {
    nav: 'Schach',
    title: 'Schach',
    sub: 'Lernen gegen die KI',
    icon: 'chess',
    tint: 'linear-gradient(135deg,#81b64c,#4e7a2c)',
    desc: 'Spiel gegen die KI (bis unschlagbar) oder online gegen Freunde. Der Coach bewertet jeden Zug, erklärt Fehler und analysiert ganze Partien.',
  },
  agenda: {
    nav: 'Agenda',
    title: 'Agenda',
    sub: 'Termine & Erinnerungen',
    icon: 'calendar',
    tint: 'linear-gradient(135deg,#ff7a59,#e8336d)',
    desc: 'Termine als Liste, Woche oder Monat – verbunden mit der Revulution Island. Erinnert dich rechtzeitig, auf Wunsch auch einen Tag vorher.',
  },
  chats: {
    nav: 'Chats',
    title: 'Chats',
    sub: 'Mit Freunden schreiben',
    icon: 'chat',
    tint: 'linear-gradient(135deg,#34d399,#0f766e)',
    desc: 'Räume und Direktnachrichten per Code. Achtung: Chats sind nicht verschlüsselt – teile keine sensiblen Daten.',
  },
  model3d: {
    nav: '3D-Modell',
    title: '3D-Modell',
    sub: 'Modellieren für den 3D-Druck',
    icon: 'cube',
    tint: 'linear-gradient(135deg,#3ee6c8,#2f5bea)',
    desc: 'Grundkörper, 3D-Text, Löcher und boolesche Operationen auf dem Druckbett – Export als STL, 3MF oder OBJ.',
  },
  worldview: {
    nav: 'Weltansicht',
    title: 'Weltansicht',
    sub: 'Die Welt entdecken',
    icon: 'globe',
    tint: 'linear-gradient(135deg,#8fc4ff,#6856ea)',
    desc: '3D-Globus mit kostenlosen Live-Daten, Wetter und Satelliten.',
  },
  geo: {
    nav: 'Geo',
    title: 'GeoRevulution',
    sub: 'Wo auf der Welt bist du?',
    icon: 'globe',
    tint: 'linear-gradient(135deg,#22c55e,#0e7490)',
    desc: 'Street View erraten wie bei GeoGuessr: Klassisch, Tägliche Challenge, Länder-Streak und online Duell oder Party mit Freunden.',
  },
};

const NAV = ['home', 'gaming', 'orbit', 'agenda', 'screenshot', 'video', 'beat', 'docs', 'chess', 'geo', 'chats', 'worldview', 'model3d'];
const MODULE_PAGES = new Set(['gaming', 'agenda', 'screenshot', 'video', 'beat', 'docs', 'chess', 'geo', 'chats', 'worldview', 'model3d']);
// Seitenleiste: oben max. 3 angeheftete Apps, darunter frei benannte Gruppen (per Ziehen sortierbar).
const DEFAULT_NAV = () => ({
  pinned: ['home', 'gaming', 'orbit'],
  groups: [
    { id: 'g-tools', name: 'Werkzeuge', apps: ['agenda', 'screenshot', 'video', 'beat', 'docs'] },
    { id: 'g-fun', name: 'Spiele & Chat', apps: ['chess', 'geo', 'chats'] },
  ],
});
const PIN_MAX = 3;
const tintColor = (id) => (id === 'home' ? '#b39dff' : /#[0-9a-f]{6}/i.exec(APPS[id]?.tint || '')?.[0] || '#b39dff');
const WALL_NAMES = {
  nebula: 'Nebula', aurora: 'Aurora', galaxy: 'Galaxy', synthwave: 'Synthwave', liquid: 'Liquid', silk: 'Silk', waves: 'Waves',
  ocean: 'Ocean', clouds: 'Clouds', mountains: 'Mountains', fireflies: 'Fireflies', bokeh: 'Bokeh', lava: 'Lava', warp: 'Warp',
};

let state = null;
let page = null;
const sound = window.createClickSound();
sound.attach(document);

/* ------------------------------------------------------------------ helpers */
function toast(message, kind = '') {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast ${kind}`;
  el.hidden = false;
  sound.play(kind === 'error' ? 'error' : 'success');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (el.hidden = true), kind === 'error' ? 7000 : 4200);
}

async function run(action, success) {
  try {
    const result = await action();
    if (success) toast(success);
    return result;
  } catch (error) {
    toast(String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
    return null;
  }
}

const moduleState = (id) => state?.modules.find((mod) => mod.id === id);
const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;

/* Startseiten-Karten: der Glanz folgt dem Zeiger und die Karte kippt minimal mit. */
document.addEventListener('pointermove', (event) => {
  const card = event.target.closest?.('.hc, .card.app');
  if (!card) return;
  const rect = card.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const x = Math.max(0, Math.min(rect.width, event.clientX - rect.left));
  const y = Math.max(0, Math.min(rect.height, event.clientY - rect.top));
  card.style.setProperty('--mx', `${x}px`);
  card.style.setProperty('--my', `${y}px`);
  card.style.setProperty('--tilt-x', `${((y / rect.height) - 0.5) * -4.5}deg`);
  card.style.setProperty('--tilt-y', `${((x / rect.width) - 0.5) * 5.5}deg`);
}, { passive: true });
document.addEventListener('pointerout', (event) => {
  const card = event.target.closest?.('.hc, .card.app');
  if (!card || card.contains(event.relatedTarget)) return;
  card.style.setProperty('--tilt-x', '0deg');
  card.style.setProperty('--tilt-y', '0deg');
}, { passive: true });

/* ---------------------------------------------------------------- wallpaper */
let currentWall = null;
let backdropFile = '';

function applyBackdrop() {
  if (!state) return;
  const s = state.settings || {};
  const on = s.backdropBlur !== false; // Glas ist nur ein Standbild – bleibt auch im Game-Modus
  const frost = $('#wall-blur');
  const amount = Math.max(0, Math.min(40, Number(s.backdropBlurAmount ?? 18)));
  const dim = Math.max(0, Math.min(0.75, Number(s.backdropDim ?? 0.14)));
  document.body.classList.toggle('backdrop-blur', on);
  // 2.45.9: Standard ist Glas aus dem einmal weichgezeichneten Desktop-Bild („image“) – keine Kästchen
  // (Acrylic aktualisierte nur Teile), flüssiges Ziehen (keine Live-Unschärfe). „live“ = altes Acrylic.
  const imageGlass = s.glassMode === 'image' || s.glassImage; // Standard wieder Live-Glas (Bild-Glas hinkte beim Ziehen)
  if (frost) frost.style.backdropFilter = imageGlass ? 'none' : `blur(${Math.min(10, amount)}px) saturate(1.05)`;
  const glass = $('#glass-bg');
  if (glass && state.desktopBackdrop) {
    // vorab weichgezeichnete Fassung (…-blur.jpg) zuerst, das Original darunter als Rückfall
    const blur = state.desktopBackdrop.replace(/\.jpg$/i, '-blur.jpg');
    const url = `url("${fileUrl(blur)}"), url("${fileUrl(state.desktopBackdrop)}")`;
    if (glass.dataset.src !== url) {
      glass.dataset.src = url;
      glass.style.backgroundImage = url;
    }
    glass.classList.toggle('preblur', imageGlass);
  }
  document.body.classList.toggle('glass', Boolean(on && imageGlass && state.desktopBackdrop));
  document.body.classList.toggle('glass-ready', Boolean(on && state.desktopBackdrop));
  const shade = $('#wall-shade');
  if (shade) {
    // Nothing-Glas: tiefes Schwarz über dem live verschwommenen Desktop (Acrylic des Fensters).
    shade.style.opacity = '1';
    shade.style.background = `rgba(8, 10, 16, ${on ? Math.max(0.0, Math.min(0.5, dim * 0.35)) : 0.86})`;
  }
}

async function loadBackdrop(force = false) {
  if (!window.hub.desktopBackdrop) return;
  try {
    const next = await window.hub.desktopBackdrop();
    if (!next) return;
    if (!force && next === backdropFile) return;
    backdropFile = next;
    if (state) {
      state.desktopBackdrop = next;
      applyBackdrop();
      if (state.active === 'tool-desktop') render();
    }
  } catch {}
}
window.__hubRefreshBackdrop = () => loadBackdrop(true);

function applyWallpaper() {
  const video = $('#wall');
  // Game-Modus: kein Live-Hintergrund (spart GPU und RAM)
  // 2.41: die App hat keinen eigenen Hintergrund mehr – sie ist durchsichtig (Windows-Acryl dahinter)
  const id = 'none';
  applyBackdrop();
  if (id === currentWall && !video.error) return;
  currentWall = id;
  if (id === 'custom' && state.settings.appBgFile) {
    // eigenes Bild aus den Hintergründen (gespeichert/geliked) als App-Hintergrund
    video.hidden = false;
    video.removeAttribute('src');
    video.poster = fileUrl(state.settings.appBgFile);
    video.load();
    return;
  }
  if (id === 'none') {
    video.removeAttribute('src');
    video.removeAttribute('poster');
    video.load();
    video.hidden = true;
    return;
  }
  video.hidden = false;
  // Standbild als Poster: bleibt sichtbar, falls das Video gerade nicht decodiert wird.
  video.poster = fileUrl(`${state.wallpaperDir}/thumbs/${id}.jpg`);
  video.src = fileUrl(`${state.wallpaperDir}/live-${id}.mp4`);
  video.load();
  video.play().catch(() => {});
}

/* ---------------------------------------------------------------------- nav */
function navButton(id, label, iconName, draggable = false) {
  const live = id === 'orbit' && state?.orbit.running;
  return `<button class="nav-btn ${state?.active === id ? 'active' : ''}" data-open="${id}" title="${esc(label)}" style="--nc:${tintColor(id)}" ${draggable ? `draggable="true" data-nav-id="${id}"` : ''}>
    <span class="nav-ic">${icon(iconName, 20)}</span><span>${esc(label)}</span>${live ? '<i class="dot"></i>' : ''}
  </button>`;
}

/** Gespeicherte Anordnung – unbekannte/neue Apps landen automatisch in der letzten Gruppe. */
function navLayout() {
  const saved = state?.settings?.nav;
  const nav = saved && Array.isArray(saved.pinned) && Array.isArray(saved.groups) ? JSON.parse(JSON.stringify(saved)) : DEFAULT_NAV();
  const known = new Set(NAV);
  nav.pinned = nav.pinned.filter((id) => known.has(id)).slice(0, PIN_MAX);
  const used = new Set(nav.pinned);
  for (const g of nav.groups) g.apps = (g.apps || []).filter((id) => known.has(id) && !used.has(id) && (used.add(id), true));
  if (!nav.groups.length) nav.groups.push({ id: 'g-apps', name: 'Apps', apps: [] });
  for (const id of NAV) if (!used.has(id)) nav.groups[nav.groups.length - 1].apps.push(id);
  return nav;
}

const navBtn = (id) => (id === 'home' ? navButton('home', 'Start', 'home', true) : navButton(id, APPS[id].nav, APPS[id].icon, true));

function renderNav() {
  renderDock();
}

/* ================================================================== Dock (wie macOS) */
const TOOLS = window.HubTools?.TOOLS || {};
const SPECIAL = {
  home: { nav: 'Start', title: 'Start', icon: 'home', tint: 'linear-gradient(135deg,#ff5a50,#c81e16)', desc: 'Die Startseite des Hubs.' },
  shop: { nav: 'Shop', title: 'Shop', icon: 'palette', tint: 'linear-gradient(135deg,#fbbf24,#f59e0b)', desc: 'Cosmetics für Schach, Geo und Chats.' },
  settings: { nav: 'Optionen', title: 'Einstellungen', icon: 'settings', tint: 'linear-gradient(135deg,#94a3b8,#475569)', desc: 'Einstellungen des Hubs.' },
};
const ALL_APPS = () => ({ ...SPECIAL, ...APPS, ...TOOLS });
// 2.33: schlanker Standard – nur die wichtigsten Apps, der Rest ist über „Alle Apps“ da
const DEFAULT_DOCK = ['home', 'gaming', 'orbit', 'tool-backgrounds', 'tool-account', 'tool-schematics', 'docs', 'tool-store', 'chess', 'tool-desktop'];
/* ------------------------------------------------------------------ Unscharfe App-Suche
   Findet auch Tippfehler, Wortanfänge, Buchstabenfolgen und Begriffe, die nicht im Namen
   stehen („musik“ → Beat Lab, „shop“ → Store, „tastatur“ → Tastatur). */
const APP_WORDS = {
  beat: 'musik music beats produzieren drum song', 'tool-store': 'shop kaufen coins designs skins', 'tool-backgrounds': 'wallpaper hintergrundbild bild live',
  agenda: 'kalender termine calendar plan', 'tool-keyboard': 'tastatur keyboard ajazz led rgb', orbit: 'island dynamic insel', gaming: 'spiele games fps clips',
  'tool-calc': 'rechner calculator mathe', 'tool-currency': 'geld wechselkurs euro franken', 'tool-account': 'konto login profil anmelden', docs: 'text schreiben word dokument diktat',
  video: 'schnitt film clip untertitel', screenshot: 'foto bildschirm aufnahme', 'tool-desktop': 'widgets desktop taskleiste', 'tool-airplay': 'iphone handy spiegeln airplay',
  chats: 'nachrichten anrufen chat freunde', chess: 'schach coach', geo: 'geografie karte länder', 'tool-football': 'fussball liveticker tore', 'tool-speed': 'wlan internet speedtest', 'tool-parental': 'kindersicherung eltern pin bildschirmzeit sperren webseiten jugendschutz', 'tool-player': 'player musik songtext lyrics cover spotify vollbild', 'tool-radio': 'radio sender weltkarte live stream fm musik welt', 'tool-achievements': 'erfolge achievements profil belohnungen trophäen', 'tool-modrinth': 'modrinth mods minecraft fabric forge shader ressourcenpakete modrif',
  'tool-wordle': 'wordle wort raten buchstaben rätsel', 'tool-sizeup': 'size it up grösse grosse schätzen silhouette', 'tool-cloud': 'cloud speicher dateien hochladen backup clips screenshots projekte', 'tool-piano': 'klavier piano lernen noten lieder akkorde mikrofon midi keyboard coach musik', 'tool-eyeball': 'augenmass augenmaß schätzen punkte zählen winkel spiel reaktion', 'tool-deepdive': 'tiefgang quiz trivia krill tiefsee taucher fragen mehrspieler',
  'tool-draw': 'zeichnen malen stift pinsel skizze', 'tool-photo': 'foto bild bildbearbeitung photoshop ebenen filter zuschneiden retusche', 'tool-slides': 'präsentation powerpoint folien slides vortrag', 'tool-taskman': 'task manager taskmanager prozesse beenden', 'tool-recherche': 'osint recherche whois rdap dns ip ssl zertifikat header domain hash exif metadaten archiv wayback weiterleitung',
  'tool-fans': 'lüfter fan control drehzahl kühlung', 'tool-streamdeck': 'stream deck elgato tasten shortcuts soundboard makro', 'tool-clips': 'clips aufnahme recording highlights',
};
function appScore(q, id, text) {
  q = q.trim().toLowerCase();
  if (!q) return 1;
  const hay = `${text} ${APP_WORDS[id] || ''}`.toLowerCase();
  if (hay.includes(q)) return hay.startsWith(q) ? 100 : 80;
  const words = hay.split(/[^a-z0-9äöüß]+/).filter(Boolean);
  if (words.some((w) => w.startsWith(q.slice(0, Math.max(2, q.length - 1))))) return 60;
  // Tippfehler: höchstens 1 (kurz) bzw. 2 (lang) Zeichen falsch
  const lev = (a, b) => {
    const d = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      let prev = d[0];
      d[0] = i;
      for (let j = 1; j <= b.length; j++) {
        const t = d[j];
        d[j] = Math.min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
        prev = t;
      }
    }
    return d[b.length];
  };
  const tol = q.length <= 4 ? 1 : 2;
  if (words.some((w) => lev(q, w.slice(0, q.length + 1)) <= tol || lev(q, w) <= tol)) return 40;
  // Buchstaben in Reihenfolge (z. B. „bkg“ → Hintergründe/backgrounds)
  let k = 0;
  for (const ch of hay) if (ch === q[k]) k++;
  return k === q.length && q.length >= 3 ? 20 : 0;
}
const appSearch = (ids, q, textOf) => ids.map((id) => [id, appScore(q, id, textOf(id))]).filter(([, s]) => s > 0).sort((a, b) => b[1] - a[1]).map(([id]) => id);

const dockItems = () => (state?.settings?.dock?.items || DEFAULT_DOCK).filter((id) => ALL_APPS()[id]);
const dockCfg = () => ({ pos: 'bottom', size: 'm', magnify: true, ...(state?.settings?.dock || {}) });
let dockDrag = null;

let dockLaunch = { id: '', until: 0 };

function dockTile(id) {
  const a = ALL_APPS()[id];
  const live = id === 'orbit' && state?.orbit?.running;
  const on = state?.active === id || (state?.opened || []).includes(id);
  const bounce = dockLaunch.id === id && Date.now() < dockLaunch.until;
  return `<button class="dock-item ${state?.active === id ? 'active' : ''} ${bounce ? 'launching' : ''}" data-open="${id}" data-dock-id="${id}" draggable="true" data-tip="${esc(a.nav || a.title)}">${appArt(id, 'dock-ic')}${live || on ? '<i class="dock-dot"></i>' : ''}${state?.badges?.[id] ? `<b class="app-badge">${state.badges[id] > 99 ? '99+' : state.badges[id]}</b>` : ''}</button>`;
}

function renderDock() {
  const el = $('#dock');
  if (!el || !state) return;
  const c = dockCfg();
  const vertical = c.pos === 'left' || c.pos === 'right';
  document.body.dataset.dock = c.pos;
  document.body.dataset.dockSize = c.size;
  el.className = `dock dock-${c.pos} size-${c.size} ${c.magnify ? 'magnify' : ''} ${dockFx.live ? 'live' : ''}`;
  // Passen nicht alle Apps hinein, werden die Kacheln kleiner (statt zu scrollen).
  const items = dockItems();
  const base = { s: 38, m: 46, l: 56 }[c.size] || 46;
  const room = (vertical ? window.innerHeight - 44 : window.innerWidth) - 64;
  const fit = Math.floor((room - 30) / (items.length + 3) - 4);
  const tile = Math.max(28, Math.min(base, fit));
  el.style.setProperty('--tile', `${tile}px`);
  const fixed = (attr, id, tip, on) => `<button class="dock-item fixed ${on ? 'active' : ''}" ${attr} data-tip="${esc(tip)}">${appArt(id, 'dock-ic')}${on ? '<i class="dock-dot"></i>' : ''}</button>`;
  morph(el, `<div class="dock-bar">${items.map((id) => dockTile(id)).join('')}<span class="dock-sep"></span>
    ${fixed('data-dock-special="start"', 'start', 'Windows-Start', false)}
    ${fixed('data-dock-special="launcher"', 'launcher', 'Alle Apps', overlay === 'launcher')}
    ${fixed('data-dock-special="control"', 'control', 'Kontrollzentrum', overlay === 'control')}
    ${fixed('data-open="settings"', 'settings', 'Einstellungen', state.active === 'settings')}</div>`);
  dockFx.base = null;
  if (dockFx.ev) dockMagnify(dockFx.ev);
  // Dock als eigene Ebene über den Apps: Modell an die Dock-Ebene schicken
  document.body.classList.toggle('dock-ext', Boolean(state.dockExternal));
  if (state.dockExternal) {
    const opened = state.opened || [];
    const model = {
      pos: c.pos,
      size: c.size,
      magnify: c.magnify,
      pinned: false,
      tile,
      items: items.map((id) => {
        const a = ALL_APPS()[id];
        const module = MODULE_PAGES.has(id);
        return { id, tip: a.nav || a.title, active: state.active === id, dot: (id === 'orbit' && state.orbit?.running) || state.active === id || opened.includes(id), badge: state.badges?.[id] || 0, module, canQuit: (module && opened.includes(id) && id !== 'gaming') || (!module && state.active === id && id !== 'home'), quitLabel: module ? 'App beenden' : 'Schließen' };
      }),
      fixed: [
        { id: 'start', special: 'start', tip: 'Windows-Start', active: false, dot: false },
        { id: 'launcher', special: 'launcher', tip: 'Alle Apps', active: overlay === 'launcher', dot: overlay === 'launcher' },
        { id: 'control', special: 'control', tip: 'Kontrollzentrum', active: overlay === 'control', dot: overlay === 'control' },
        { id: 'settings', tip: 'Einstellungen', active: state.active === 'settings', dot: state.active === 'settings' },
      ],
    };
    const key = JSON.stringify(model);
    if (key !== renderDock.last) {
      renderDock.last = key;
      window.hub.dockModel?.(model).catch(() => {});
    }
  }
}
window.hub.onDockSpecial?.((kind) => {
  if (kind === 'start') return window.hub.taskbar?.start().catch(() => {});
  if (kind === 'launcher' || kind === 'control') openOverlay(kind);
});

/* Dock: Vergrößern wie am Mac – die Kachel unter dem Zeiger wächst, die Nachbarn weich mit. */
const dockFx = { base: null, ev: null, live: false, tip: null };
const DOCK_MAX = 1.4;
function dockMeasure(el) {
  const bar = el.querySelector('.dock-bar');
  if (!bar) return null;
  const tile = parseFloat(el.style.getPropertyValue('--tile')) || 54;
  const kids = [...bar.children];
  const sizes = kids.map((k) => (k.classList.contains('dock-sep') ? 13 : tile));
  const total = sizes.reduce((a, b) => a + b, 0) + 4 * (kids.length - 1);
  let at = -total / 2;
  const centers = kids.map((k, i) => {
    const c = at + sizes[i] / 2;
    at += sizes[i] + 4;
    return c;
  });
  return { bar, kids, centers, tile };
}
function dockMagnify(e) {
  const el = $('#dock');
  const c = dockCfg();
  dockFx.ev = e;
  if (!el || dockDrag) return;
  if (!dockFx.base) dockFx.base = dockMeasure(el);
  const b = dockFx.base;
  if (!b) return;
  const vertical = c.pos === 'left' || c.pos === 'right';
  const r = b.bar.getBoundingClientRect();
  const p = vertical ? e.clientY - (r.top + r.height / 2) : e.clientX - (r.left + r.width / 2);
  const range = b.tile * 2.7;
  if (!dockFx.live) {
    dockFx.live = true;
    el.classList.add('live');
  }
  let hot = null, hotS = 0;
  b.kids.forEach((k, i) => {
    if (!k.classList.contains('dock-item')) return;
    const d = Math.abs(p - b.centers[i]);
    const s = c.magnify && d < range ? 1 + (DOCK_MAX - 1) * Math.pow((Math.cos((Math.PI * d) / range) + 1) / 2, 1.25) : 1;
    k.style.setProperty('--s', s.toFixed(3));
    if (d < b.tile * 0.62 && s >= hotS) {
      hot = k;
      hotS = s;
    }
  });
  dockTip(hot);
}
function dockCalm() {
  const el = $('#dock');
  dockFx.ev = null;
  if (!dockFx.live) return;
  dockFx.live = false;
  el?.classList.remove('live');
  el?.querySelectorAll('.dock-item').forEach((k) => k.style.removeProperty('--s'));
  dockTip(null);
}
/** Name der App neben der Kachel. Über einer geöffneten App zeigt Windows den Namen selbst (title). */
function dockTip(item) {
  const tip = $('#dock-label');
  if (!tip) return;
  const covered = MODULE_PAGES.has(state?.active) && !overlay;
  document.querySelectorAll('#dock .dock-item').forEach((k) => (covered ? k.setAttribute('title', k.dataset.tip || '') : k.removeAttribute('title')));
  if (!item || covered || dockDrag) {
    tip.hidden = true;
    dockFx.tip = null;
    return;
  }
  tip.textContent = item.dataset.tip || '';
  tip.hidden = false;
  requestAnimationFrame(() => {
    if (tip.hidden) return;
    const pos = dockCfg().pos;
    const r = item.getBoundingClientRect(), t = tip.getBoundingClientRect();
    const cx = Math.max(8, Math.min(window.innerWidth - t.width - 8, r.left + r.width / 2 - t.width / 2));
    const cy = r.top + r.height / 2 - t.height / 2;
    tip.dataset.pos = pos;
    tip.style.left = `${pos === 'left' ? r.right + 12 : pos === 'right' ? r.left - t.width - 12 : cx}px`;
    tip.style.top = `${pos === 'bottom' ? r.top - t.height - 12 : pos === 'top' ? r.bottom + 12 : cy}px`;
  });
}
document.addEventListener('mousemove', (e) => {
  if (e.target.closest?.('.dock-bar')) dockMagnify(e);
  else dockCalm();
});
document.addEventListener('mouseleave', dockCalm);
window.addEventListener('blur', dockCalm);
window.addEventListener('resize', () => renderDock());
document.addEventListener('click', (e) => {
  const it = e.target.closest?.('#dock [data-dock-id]');
  if (!it || it.classList.contains('active')) return;
  dockLaunch = { id: it.dataset.dockId, until: Date.now() + 800 };
  it.classList.add('launching');
}, true);

function saveDock(items) {
  state.settings.dock = { ...dockCfg(), items };
  renderDock();
  run(() => window.hub.setSettings({ dock: { items } }));
}

/* Dock: Ziehen zum Umsortieren, Rechtsklick-Menü */
document.addEventListener('dragstart', (e) => {
  const it = e.target.closest?.('[data-dock-id]');
  if (!it) return;
  dockDrag = it.dataset.dockId;
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', dockDrag);
  it.classList.add('dragging');
});
document.addEventListener('dragover', (e) => {
  if (!dockDrag) return;
  const over = e.target.closest?.('[data-dock-id]');
  if (!e.target.closest?.('#dock')) return;
  e.preventDefault();
  document.querySelectorAll('.dock-item.drop-before').forEach((x) => x.classList.remove('drop-before'));
  if (over && over.dataset.dockId !== dockDrag) over.classList.add('drop-before');
});
document.addEventListener('drop', (e) => {
  if (!dockDrag || !e.target.closest?.('#dock')) return;
  e.preventDefault();
  const before = e.target.closest('[data-dock-id]')?.dataset.dockId;
  const items = dockItems().filter((x) => x !== dockDrag);
  const at = before ? items.indexOf(before) : -1;
  if (at >= 0) items.splice(at, 0, dockDrag);
  else items.push(dockDrag);
  saveDock(items);
});
document.addEventListener('dragend', () => {
  dockDrag = null;
  document.querySelectorAll('.dock-item.dragging, .dock-item.drop-before').forEach((x) => x.classList.remove('dragging', 'drop-before'));
});
document.addEventListener('contextmenu', (e) => {
  const it = e.target.closest?.('#dock [data-dock-id]');
  if (!it) return;
  e.preventDefault();
  const id = it.dataset.dockId;
  const menu = $('#dock-menu');
  menu.innerHTML = `<b>${esc(ALL_APPS()[id]?.title || id)}</b><button data-dockmenu="open" data-id="${id}">Öffnen</button>${(state?.opened || []).includes(id) && id !== 'gaming' && MODULE_PAGES.has(id) ? `<button data-dockmenu="quit" data-id="${id}">App beenden</button>` : ''}${state?.active === id && !MODULE_PAGES.has(id) && id !== 'home' ? `<button data-dockmenu="quit" data-id="${id}">Schließen</button>` : ''}${id !== 'home' ? `<button data-dockmenu="remove" data-id="${id}">Aus dem Dock entfernen</button>` : ''}<button data-dockmenu="launcher">Alle Apps …</button>`;
  menu.hidden = false;
  const r = menu.getBoundingClientRect();
  menu.style.left = `${Math.min(e.clientX, window.innerWidth - r.width - 8)}px`;
  menu.style.top = `${Math.max(8, Math.min(e.clientY - r.height - 6, window.innerHeight - r.height - 8))}px`;
});
document.addEventListener('mousedown', (e) => {
  const menu = $('#dock-menu');
  if (menu && !menu.hidden && !e.target.closest('#dock-menu')) menu.hidden = true;
});
document.addEventListener('click', (e) => {
  const m = e.target.closest?.('[data-dockmenu]');
  if (!m) return;
  $('#dock-menu').hidden = true;
  const id = m.dataset.id;
  if (m.dataset.dockmenu === 'open') window.hub.open(id);
  if (m.dataset.dockmenu === 'remove') saveDock(dockItems().filter((x) => x !== id));
  if (m.dataset.dockmenu === 'quit') {
    if (MODULE_PAGES.has(id)) run(() => window.hub.closeModule(id), `${ALL_APPS()[id]?.nav || id} beendet.`);
    else window.hub.open('home');
  }
  if (m.dataset.dockmenu === 'launcher') openOverlay('launcher');
});

/* ================================================================== Starter & Kontrollzentrum */
let overlay = '';
let launcherQuery = '';
const cc = { volume: null, brightness: null, power: null, loading: false };

function openOverlay(kind) {
  overlay = overlay === kind ? '' : kind;
  window.hub.overlay?.(Boolean(overlay)).catch(() => {});
  renderOverlay();
  renderDock();
  if (overlay === 'control') {
    loadControl();
    refreshPcLive();
  }
  if (overlay === 'launcher') setTimeout(() => $('#launcher-search')?.focus(), 50);
}

function launcherHtml() {
  const all = ALL_APPS();
  const inDock = new Set(dockItems());
  const q = launcherQuery.trim().toLowerCase();
  const match = (id) => !q || appScore(q, id, `${all[id].title} ${all[id].nav} ${all[id].desc || ''}`) > 0;
  const groups = [
    ['Apps', ['home', ...Object.keys(APPS)]],
    ['Mini-Apps', Object.keys(TOOLS)],
    ['System', ['settings']],
  ];
  return `<div class="launcher"><div class="launcher-head"><input class="input" id="launcher-search" placeholder="Apps durchsuchen …" value="${esc(launcherQuery)}" /><small class="muted">Klick öffnet · Plus legt die App ins Dock · Rechtsklick im Dock entfernt sie</small></div>
    ${groups
      .map(([name, ids]) => {
        const list = ids.filter((id) => all[id] && match(id));
        if (!list.length) return '';
        return `<h4>${name}</h4><div class="launcher-grid">${list
          .map((id) => `<div class="launch-tile"><button class="launch-open" data-launch="${id}">${appArt(id, 'launch-ic')}<b>${esc(all[id].nav || all[id].title)}</b><small>${esc(all[id].desc || all[id].sub || '')}</small></button>
            ${id === 'settings' ? '' : `<button class="launch-pin ${inDock.has(id) ? 'on' : ''}" data-pin="${id}" title="${inDock.has(id) ? 'Aus dem Dock entfernen' : 'Ins Dock legen'}">${icon(inDock.has(id) ? 'check' : 'plus', 14)}</button>`}</div>`)
          .join('')}</div>`;
      })
      .join('')}</div>`;
}

const fmtLeft = (at) => {
  const s = Math.max(0, Math.round((at - Date.now()) / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`;
};
setInterval(() => document.querySelectorAll('[data-cc-until]').forEach((el) => (el.textContent = fmtLeft(Number(el.dataset.ccUntil)))), 1000);
async function loadTimers() {
  cc.timers = await window.hub.cc.timers?.().catch(() => []) || [];
  if (overlay === 'control') renderOverlay();
}
document.addEventListener('click', async (e) => {
  const tb = e.target.closest?.('[data-cc-timer]');
  if (tb) {
    const v = tb.dataset.ccTimer === 'custom' ? parseFloat(String($('#cc-min')?.value || '').replace(',', '.')) : Number(tb.dataset.ccTimer);
    if (!v || v <= 0) return toast('Bitte Minuten eingeben.', 'error');
    await run(() => window.hub.cc.timer(v * 60, `Timer ${v} min`), `Timer ${v} min läuft – in der Island.`);
    return loadTimers();
  }
  if (e.target.closest?.('[data-cc-alarm]')) {
    cc.alarm = $('#cc-alarm')?.value || '07:00';
    const r = await run(() => window.hub.cc.alarm(cc.alarm));
    if (r) toast(`Wecker gestellt: ${new Date(r.at).toLocaleString('de-DE', { weekday: 'short', hour: '2-digit', minute: '2-digit' })}`);
    return loadTimers();
  }
});

async function loadMix() {
  cc.mix = await window.hub.mix?.list().catch(() => null) || { apps: [], error: 'Mixer nicht verfügbar' };
  if (overlay === 'control') renderOverlay();
}
let mixTimer = null;
document.addEventListener('input', (e) => {
  const pid = e.target.dataset?.mixPid;
  if (!pid) return;
  const v = Number(e.target.value) / 100;
  const a = cc.mix?.apps?.find((x) => String(x.pid) === pid);
  if (a) a.volume = v;
  clearTimeout(mixTimer);
  mixTimer = setTimeout(() => window.hub.mix.app(Number(pid), v, null).catch(() => {}), 60);
});
document.addEventListener('click', (e) => {
  const m = e.target.closest?.('[data-mix-mute]');
  if (m) {
    const a = cc.mix?.apps?.find((x) => String(x.pid) === m.dataset.mixMute);
    if (!a) return;
    a.muted = !a.muted;
    window.hub.mix.app(a.pid, null, a.muted).catch(() => {});
    return renderOverlay();
  }
  if (e.target.closest?.('[data-mix="reload"]')) loadMix();
});
window.hub.onOpenControl?.(() => {
  if (overlay !== 'control') openOverlay('control');
  loadMix();
});

async function loadControl() {
  loadTimers();
  loadMix();
  if (cc.loading) return;
  cc.loading = true;
  const [v, b, p] = await Promise.all([window.hub.cc.volume().catch(() => null), window.hub.cc.brightness().catch(() => null), window.hub.cc.power().catch(() => null)]);
  cc.volume = v;
  cc.brightness = b;
  cc.power = p;
  cc.loading = false;
  if (overlay === 'control') renderOverlay();
}

function controlHtml() {
  const s = state.settings;
  const tile = (key, label, on, ic, sub = '') => `<button class="cc-tile ${on ? 'on' : ''}" data-cc="${key}"><span class="cc-ic">${icon(ic, 20)}</span><b>${esc(label)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</button>`;
  const l = pcLive;
  const timer = window.HubTools?.timerStatus?.();
  return `<div class="control">
    <div class="cc-grid">
      ${tile('island', 'Dynamic Island', state.orbit.running, 'island', state.orbit.running ? 'An' : 'Aus')}
      ${tile('dnd', 'Nicht stören', s.dnd, 'bell', s.dnd ? 'Keine Meldungen' : 'Aus')}
      ${tile('power', cc.power?.mode === 'performance' ? 'Höchstleistung' : cc.power?.mode === 'saver' ? 'Energiesparen' : 'Ausbalanciert', cc.power?.mode === 'performance', 'bolt', 'Energiemodus')}
      ${tile('screenshot', 'Screenshot', false, 'camera', 'Bereich wählen')}
      ${tile('speed', 'WLAN-Test', false, 'gauge', 'Geschwindigkeit')}
      ${tile('lock', 'PC sperren', false, 'shield', 'Win+L')}
      ${tile('game', 'Game-Modus', state.gameMode, 'crosshair', state.gameMode ? 'Nur das Nötigste' : 'Spart RAM')}
      ${tile('notes', 'Notizen', false, 'doc', 'Schnell notieren')}
      ${tile('shieldscan', 'Schutz', false, 'shield', 'Tracker & Viren')}
      ${tile('awake', 'Wach halten', state.keepAwake, 'coffee', state.keepAwake ? (state.keepAwakeUntil ? `bis ${new Date(state.keepAwakeUntil).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}` : 'Bildschirm bleibt an') : 'PC schläft normal')}
      ${tile('account', 'Konto', false, 'users', 'Sync & Login')}
      ${tile('schem', 'Schematics', false, 'cube', 'KELPI-Cloud')}
    </div>
    <div class="cc-card cc-mix"><div class="cc-trow"><span class="cc-ic sm">${icon('volume', 16)}</span><b>Apps-Lautstärke</b><small class="muted">Strg+Umschalt+M öffnet das hier – auch im Spiel</small><button class="btn small ghost" data-mix="reload" style="margin-left:auto">${icon('refresh', 14)}</button></div>
      ${!cc.mix ? '<small class="muted">wird gelesen …</small>' : cc.mix.error && !cc.mix.apps?.length ? `<small class="muted">${esc(cc.mix.error)}</small>` : (cc.mix.apps || []).length ? cc.mix.apps.map((a) => `<div class="cc-row mix-row"><span class="mix-name" title="${esc(a.name)}">${esc(a.name)}</span><input type="range" min="0" max="100" value="${Math.round((Number(a.volume) || 0) * 100)}" data-mix-pid="${a.pid}" /><button class="mix-mute ${a.muted ? 'on' : ''}" data-mix-mute="${a.pid}" title="${a.muted ? 'Ton an' : 'Stumm'}">${icon(a.muted ? 'mute' : 'volume', 14)}</button></div>`).join('') : '<small class="muted">Gerade spielt keine App Ton ab.</small>'}
    </div>
    <div class="cc-card cc-time">
      <div class="cc-trow"><span class="cc-ic sm">${icon('timer', 16)}</span><b>Timer</b>${[1, 5, 10, 15, 30].map((m) => `<button class="chip" data-cc-timer="${m}">${m} min</button>`).join('')}<input class="input cc-min" id="cc-min" placeholder="min" inputmode="numeric" /><button class="btn small" data-cc-timer="custom">Start</button></div>
      <div class="cc-trow"><span class="cc-ic sm">${icon('clock', 16)}</span><b>Wecker</b><input class="input cc-alarm" id="cc-alarm" type="time" value="${esc(cc.alarm || '07:00')}" /><button class="btn small" data-cc-alarm="1">Stellen</button><small class="muted">läuft in der Island</small></div>
      ${(cc.timers || []).length ? `<div class="cc-tlist">${cc.timers.map((x) => `<span>${esc(x.label)} · <b data-cc-until="${x.at}">${fmtLeft(x.at)}</b></span>`).join('')}</div>` : ''}
    </div>
    <div class="cc-card"><div class="cc-row"><span class="cc-ic sm">${icon('volume', 16)}</span><input type="range" min="0" max="100" value="${cc.volume?.level ?? 50}" data-cc-range="volume" ${cc.volume ? '' : 'disabled'} /><b>${cc.volume ? `${cc.volume.level}%` : '–'}</b></div>
      ${cc.brightness != null ? `<div class="cc-row"><span class="cc-ic sm">${icon('spark', 16)}</span><input type="range" min="5" max="100" value="${cc.brightness}" data-cc-range="brightness" /><b>${cc.brightness}%</b></div>` : ''}
      <div class="cc-media"><button class="btn small ghost" data-cc-media="prev">⏮</button><button class="btn small" data-cc-media="playpause">⏯</button><button class="btn small ghost" data-cc-media="next">⏭</button><small class="muted">Steuert die Musik, die gerade läuft</small></div></div>
    <div class="cc-card cc-sys" data-pc-open="1"><span class="muted">System</span>${l ? `<div class="cc-stats"><span>CPU <b style="color:${pcCol(l.cpu)}">${Math.round(l.cpu)}%</b></span><span>RAM <b style="color:${pcCol(l.ramPct)}">${Math.round(l.ramPct)}%</b></span>${l.gpu != null ? `<span>GPU <b>${Math.round(l.gpu)}%</b></span>` : ''}</div>` : '<small class="muted">wird gemessen …</small>'}${timer ? `<span class="cc-timer">⏱ ${esc(timer)}</span>` : ''}</div>
  </div>`;
}

/* ---------------------------------------------------------- Was ist neu */
function newsHtml() {
  const N = window.WHATS_NEW;
  if (!N) return '';
  return `<div class="news"><div class="news-head"><div><span class="news-kicker">Neu · Version ${esc(state?.version || N.version)}</span><h2>${esc(N.title)}</h2><p>${esc(N.sub)}</p></div><button class="btn ghost small" data-news="close">Schliessen</button></div>
    <div class="news-grid">${N.items.map((it, i) => `<button class="news-item" data-news-open="${esc(it.open)}" style="animation-delay:${i * 45}ms"><span class="news-ic">${icon(it.icon, 20)}</span><div><b>${esc(it.title)}</b><small>${esc(it.text)}</small></div><span class="news-go">›</span></button>`).join('')}</div></div>`;
}
document.addEventListener('click', (e) => {
  const go = e.target.closest?.('[data-news-open]')?.dataset.newsOpen;
  if (go) {
    openOverlay('news'); // schliessen
    $('#news-back').hidden = false;
    return window.hub.open(go);
  }
  if (e.target.closest?.('[data-news="close"]')) {
    $('#news-back').hidden = true;
    return openOverlay('news');
  }
  if (e.target.closest?.('#news-back')) {
    if (overlay !== 'news') openOverlay('news');
    return;
  }
  if (e.target.closest?.('[data-news="show"]')) openOverlay('news');
});
function maybeShowNews() {
  const v = state?.version;
  if (!v || !window.WHATS_NEW || state.settings?.seenVersion === v) return;
  const first = !state.settings?.seenVersion;
  window.hub.setSettings({ seenVersion: v }).catch(() => {});
  setTimeout(() => (first ? null : showUpdateCard(v)), 900);
  // 2.45.14: beim ersten Start und nach jedem Update das Design wählen lassen (abschaltbar)
  if (!state.settings?.designPickerOff) setTimeout(showDesignPicker, first ? 600 : 1500);
  // Beim ersten Start und nach jedem Update fragen, ob der Hub mit Windows starten soll
  if (!state.settings?.autoStart) setTimeout(showAutostartCard, first ? 1200 : 2600);
}
function showAutostartCard() {
  if (document.querySelector('.as-card')) return;
  const el = document.createElement('div');
  el.className = 'upd-card as-card';
  el.innerHTML = `<div class="upd-ring as-ring">${icon('power', 20)}</div>
    <div class="upd-txt"><span>AUTOSTART</span><b>Mit Windows starten?</b><small>Dann sind Island, Widgets und Leiste sofort nach dem Hochfahren da.</small></div>
    <div class="upd-btns"><button class="btn small primary" data-as="yes">Ja, mit Windows</button><button class="btn small ghost" data-as="no">Nein</button></div>`;
  document.body.appendChild(el);
  // über einer Update-Karte stapeln
  if (document.querySelector('.upd-card:not(.as-card)')) el.style.bottom = '130px';
  requestAnimationFrame(() => el.classList.add('in'));
  el.addEventListener('click', (e) => {
    const a = e.target.closest('[data-as]')?.dataset.as;
    if (!a) return;
    if (a === 'yes') run(() => window.hub.setSettings({ autoStart: true }), 'Revulution Hub startet jetzt mit Windows.');
    el.classList.remove('in');
    setTimeout(() => el.remove(), 400);
  });
}
/* 2.45.14 Design wählen (erster Start und nach jedem Update): schwebende Karte ohne Abdunkeln –
   ein Klick schaltet sofort um, dahinter sieht man den Hub direkt im neuen Design. */
function applyDesign(d) {
  try { localStorage.setItem('rh-design', d); } catch {}
  if (d === 'pro') document.documentElement.setAttribute('data-theme', 'pro');
  else document.documentElement.removeAttribute('data-theme');
  return window.hub.setSettings({ design: d }).catch(() => {});
}
function showDesignPicker() {
  if (document.querySelector('.dp-card')) return;
  const cur = () => (state.settings?.design === 'standard' ? 'standard' : 'pro');
  const el = document.createElement('div');
  el.className = 'dp-card';
  const opt = (k, name, sub) => `<button class="dp-opt ${cur() === k ? 'on' : ''}" data-dp="${k}"><span class="dp-prev dp-prev-${k}"><i></i><i></i><i></i><b></b></span><strong>${name}</strong><small>${sub}</small></button>`;
  el.innerHTML = `<div class="dp-head"><b>Wähle dein Design</b><small>Klick probiert es sofort aus – du siehst es direkt im Hintergrund. Später jederzeit unter Einstellungen → Design.</small></div>
    <div class="dp-opts">${opt('pro', 'Pro', 'Ruhig und kompakt wie Profi-Software')}${opt('standard', 'Liquid Glass', 'Glas, weiche Formen, farbig')}</div>
    <div class="dp-foot"><label><input type="checkbox" data-dp-off /> Nicht mehr anzeigen</label><button class="btn small primary" data-dp-done>Fertig</button></div>`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  el.addEventListener('click', (e) => {
    const d = e.target.closest('[data-dp]')?.dataset.dp;
    if (d) {
      el.querySelectorAll('[data-dp]').forEach((b) => b.classList.toggle('on', b.dataset.dp === d));
      if (state.settings) state.settings.design = d;
      applyDesign(d);
      return;
    }
    if (e.target.closest('[data-dp-done]')) {
      if (el.querySelector('[data-dp-off]')?.checked) window.hub.setSettings({ designPickerOff: true }).catch(() => {});
      el.classList.remove('in');
      setTimeout(() => el.remove(), 250);
    }
  });
}
/* Nach einem Update: kleine, deckende Karte unten rechts – die ganze Liste nur auf Wunsch. */
function showUpdateCard(v) {
  document.querySelector('.upd-card')?.remove();
  const N = window.WHATS_NEW;
  const el = document.createElement('div');
  el.className = 'upd-card';
  el.innerHTML = `<div class="upd-ring"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7"/></svg></div>
    <div class="upd-txt"><span>UPDATE INSTALLIERT</span><b>Revulution Hub ${esc(v)}</b><small>${esc(N?.sub || 'Neue Funktionen und Verbesserungen.')}</small></div>
    <div class="upd-btns"><button class="btn small primary" data-upd="news">Was ist neu</button><button class="btn small ghost" data-upd="close">Später</button></div>`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  const close = () => {
    el.classList.remove('in');
    setTimeout(() => el.remove(), 400);
  };
  el.addEventListener('click', (e) => {
    const a = e.target.closest('[data-upd]')?.dataset.upd;
    if (a === 'news') {
      close();
      if (overlay !== 'news') openOverlay('news');
    } else if (a === 'close') close();
  });
  setTimeout(close, 15000);
}

function renderOverlay() {
  const host = $('#overlay');
  if (!host) return;
  if (!overlay) {
    host.hidden = true;
    host.innerHTML = '';
    return;
  }
  host.hidden = false;
  host.className = `overlay ov-${overlay} dockpos-${dockCfg().pos}`;
  morph(host, `<div class="ov-sheet">${overlay === 'launcher' ? launcherHtml() : overlay === 'news' ? newsHtml() : controlHtml()}</div>`);
}

document.addEventListener('mousedown', (e) => {
  if (overlay && e.target.id === 'overlay') openOverlay('');
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && overlay) openOverlay('');
});
document.addEventListener('input', (e) => {
  if (e.target.id === 'launcher-search') {
    launcherQuery = e.target.value;
    renderOverlay();
  }
  const r = e.target.dataset?.ccRange;
  if (r === 'volume') {
    cc.volume = { ...(cc.volume || {}), level: Number(e.target.value) };
    e.target.nextElementSibling.textContent = `${e.target.value}%`;
    clearTimeout(cc.vt);
    cc.vt = setTimeout(() => window.hub.cc.volume(Number(e.target.value)).catch(() => {}), 120);
  }
  if (r === 'brightness') {
    cc.brightness = Number(e.target.value);
    e.target.nextElementSibling.textContent = `${e.target.value}%`;
    window.hub.cc.brightness(Number(e.target.value)).catch(() => {});
  }
});
document.addEventListener('click', async (e) => {
  const sp = e.target.closest?.('[data-dock-special]');
  if (sp) {
    if (sp.dataset.dockSpecial === 'start') return window.hub.taskbar?.start().catch(() => {});
    return openOverlay(sp.dataset.dockSpecial);
  }
  const lo = e.target.closest?.('[data-launch]');
  if (lo) {
    openOverlay('');
    return window.hub.open(lo.dataset.launch);
  }
  const pin = e.target.closest?.('[data-pin]');
  if (pin) {
    const id = pin.dataset.pin;
    const items = dockItems();
    saveDock(items.includes(id) ? items.filter((x) => x !== id) : [...items, id]);
    return renderOverlay();
  }
  const media = e.target.closest?.('[data-cc-media]');
  if (media) return window.hub.cc.media(media.dataset.ccMedia).catch(() => {});
  const t = e.target.closest?.('[data-cc]');
  if (!t) return;
  const k = t.dataset.cc;
  if (k === 'island') await run(() => (state.orbit.running ? window.hub.orbit.stop() : window.hub.orbit.start()));
  if (k === 'dnd') await run(() => window.hub.setSettings({ dnd: !state.settings.dnd }), !state.settings.dnd ? 'Nicht stören ist an – keine Meldungen.' : 'Meldungen sind wieder an.');
  if (k === 'power') {
    cc.power = await window.hub.cc.power(cc.power?.mode === 'performance' ? 'balanced' : 'performance').catch(() => cc.power);
  }
  if (k === 'screenshot') {
    openOverlay('');
    return window.hub.cc.screenshot();
  }
  if (k === 'lock') return window.hub.cc.lock();
  if (k === 'game') {
    await run(() => window.hub.gameMode(!state.gameMode));
    return renderOverlay();
  }
  if (k === 'awake') {
    await run(() => window.hub.awake(!state.keepAwake, 0), !state.keepAwake ? 'PC bleibt wach – bis du es wieder ausschaltest.' : 'PC darf wieder schlafen.');
    return renderOverlay();
  }
  if (k === 'account' || k === 'schem') {
    openOverlay('');
    return window.hub.open(k === 'account' ? 'tool-account' : 'tool-schematics');
  }
  if (k === 'notes') {
    openOverlay('');
    return window.hub.open('tool-notes');
  }
  if (k === 'shieldscan') {
    openOverlay('');
    return window.hub.open('tool-shield');
  }
  if (k === 'speed') {
    openOverlay('');
    await window.hub.open('settings');
    return setTimeout(() => $('#speed-box')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 300);
  }
  renderOverlay();
});

/* ------------------------------------------------- Seitenleiste: Ziehen & Gruppen */
let dragNav = null;
function saveNav(nav) {
  run(() => window.hub.setSettings({ nav }));
}
document.addEventListener('dragstart', (event) => {
  const btn = event.target.closest?.('[data-nav-id]');
  if (!btn) return;
  dragNav = btn.dataset.navId;
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', dragNav);
  btn.classList.add('dragging');
  document.body.classList.add('nav-dragging');
});
document.addEventListener('dragend', () => {
  dragNav = null;
  document.body.classList.remove('nav-dragging');
  document.querySelectorAll('.nav-btn.dragging, .drop-before, .zone-over').forEach((el) => el.classList.remove('dragging', 'drop-before', 'zone-over'));
});
document.addEventListener('dragover', (event) => {
  if (!dragNav) return;
  const zone = event.target.closest?.('[data-zone]');
  if (!zone) return;
  event.preventDefault();
  document.querySelectorAll('.drop-before, .zone-over').forEach((el) => el.classList.remove('drop-before', 'zone-over'));
  const before = event.target.closest('[data-nav-id]');
  if (before && before.dataset.navId !== dragNav) before.classList.add('drop-before');
  else (zone.closest('.nav-zone') || zone).classList.add('zone-over');
});
document.addEventListener('drop', (event) => {
  if (!dragNav) return;
  const zoneEl = event.target.closest?.('[data-zone]');
  if (!zoneEl) return;
  event.preventDefault();
  const zone = zoneEl.dataset.zone;
  const beforeId = event.target.closest('[data-nav-id]')?.dataset.navId;
  const nav = navLayout();
  const lists = [nav.pinned, ...nav.groups.map((g) => g.apps)];
  for (const l of lists) {
    const i = l.indexOf(dragNav);
    if (i >= 0) l.splice(i, 1);
  }
  const target = zone === 'pinned' ? nav.pinned : nav.groups.find((g) => g.id === zone)?.apps;
  if (!target) return;
  const at = beforeId && beforeId !== dragNav ? target.indexOf(beforeId) : -1;
  if (at >= 0) target.splice(at, 0, dragNav);
  else target.push(dragNav);
  // Oben höchstens 3 – die überzählige App rutscht in die erste Gruppe
  while (nav.pinned.length > PIN_MAX) {
    const k = nav.pinned.map((x, i) => i).reverse().find((i) => nav.pinned[i] !== dragNav);
    nav.groups[0].apps.unshift(nav.pinned.splice(k, 1)[0]);
  }
  state.settings.nav = nav;
  renderNav();
  saveNav(nav);
});

/** Kleines Eingabefeld (prompt() gibt es in Electron nicht). */
function askText(title, value, done) {
  const box = document.createElement('div');
  box.className = 'ask-back';
  box.innerHTML = `<div class="ask"><b>${esc(title)}</b><input class="input" maxlength="18" value="${esc(value)}" /><div class="ask-btns"><button class="btn ghost" data-ask="no">Abbrechen</button><button class="btn primary" data-ask="ok">OK</button></div></div>`;
  document.body.appendChild(box);
  const input = box.querySelector('input');
  input.focus();
  input.select();
  const close = (ok) => {
    const v = input.value.trim().slice(0, 18);
    box.remove();
    if (ok && v) done(v);
  };
  box.addEventListener('click', (e) => {
    const a = e.target.closest('[data-ask]')?.dataset.ask;
    if (a) close(a === 'ok');
    else if (e.target === box) close(false);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') close(true);
    if (e.key === 'Escape') close(false);
  });
}

/** Rechtsklick auf die Seitenleiste: Gruppen anlegen, umbenennen, löschen, zurücksetzen. */
document.addEventListener('contextmenu', (event) => {
  const rail = event.target.closest?.('#nav');
  if (!rail) return;
  event.preventDefault();
  const groupId = event.target.closest('[data-group]')?.dataset.group || '';
  const menu = $('#nav-menu');
  menu.innerHTML = `<button data-navmenu="new">＋ Neue Gruppe</button>${groupId ? '<button data-navmenu="rename">✎ Gruppe umbenennen</button><button data-navmenu="delete">✕ Gruppe auflösen</button>' : ''}<button data-navmenu="reset">↺ Standard-Anordnung</button><small>Apps lassen sich per Ziehen verschieben. Oben max. ${PIN_MAX}.</small>`;
  menu.dataset.group = groupId;
  menu.style.left = `${event.clientX + 4}px`;
  menu.style.top = `${Math.min(event.clientY, window.innerHeight - 180)}px`;
  menu.hidden = false;
});
document.addEventListener('mousedown', (event) => {
  const menu = $('#nav-menu');
  if (menu && !menu.hidden && !event.target.closest('#nav-menu')) menu.hidden = true;
});
document.addEventListener('click', (event) => {
  const toggle = event.target.closest?.('[data-group-toggle]');
  if (toggle) {
    const id = toggle.dataset.groupToggle;
    const set = new Set(state.settings.navCollapsed || []);
    if (set.has(id)) set.delete(id);
    else set.add(id);
    state.settings.navCollapsed = [...set];
    renderNav();
    run(() => window.hub.setSettings({ navCollapsed: [...set] }));
    return;
  }
  const item = event.target.closest?.('[data-navmenu]');
  if (!item) return;
  const menu = $('#nav-menu');
  menu.hidden = true;
  const nav = navLayout();
  const gid = menu.dataset.group;
  const act = item.dataset.navmenu;
  if (act === 'new') {
    return askText('Name der neuen Gruppe', 'Neue Gruppe', (name) => {
      nav.groups.push({ id: `g-${Date.now().toString(36)}`, name, apps: [] });
      state.settings.nav = nav;
      renderNav();
      saveNav(nav);
    });
  } else if (act === 'rename') {
    const g = nav.groups.find((x) => x.id === gid);
    if (!g) return;
    return askText('Gruppe umbenennen', g.name, (name) => {
      g.name = name;
      state.settings.nav = nav;
      renderNav();
      saveNav(nav);
    });
  } else if (act === 'delete') {
    const i = nav.groups.findIndex((x) => x.id === gid);
    if (i < 0 || nav.groups.length < 2) return;
    const [g] = nav.groups.splice(i, 1);
    nav.groups[Math.max(0, i - 1)].apps.push(...g.apps);
  } else if (act === 'reset') {
    Object.assign(nav, DEFAULT_NAV());
  }
  state.settings.nav = nav;
  renderNav();
  saveNav(nav);
});

/* -------------------------------------------------------------------- pages */
function appCard(id) {
  const app = APPS[id];
  const mod = moduleState(id);
  let status = '<span class="pill ok">Bereit</span>';
  if (mod?.error) status = '<span class="pill bad">Fehler beim Laden</span>';
  else if (id === 'orbit') {
    status = !state.orbit.available ? '<span class="pill">Nicht verfügbar</span>' : state.orbit.running ? '<span class="pill ok">Läuft</span>' : '<span class="pill">Aus</span>';
  } else if (id === 'gaming') status = '<span class="pill ok">Aktiv im Hintergrund</span>';
  else if (id === 'screenshot') status = state.screenshotHotkey ? `<span class="pill ok">Hotkey ${esc(state.screenshotHotkey)}</span>` : '<span class="pill">Kein Hotkey</span>';
  return `<article class="card app" data-open="${id}">
    <div class="card-head">
      ${appArt(id, 'app-icon')}
      <div><h3>${esc(app.title)}</h3><div class="sub">${esc(app.sub)}</div></div>
    </div>
    <p class="desc">${esc(app.desc)}</p>
    <div class="card-foot">${status}<span class="open-link">Öffnen ${icon('arrow', 16)}</span></div>
  </article>`;
}

/* ------------------------------------------------------------------ Startseite
 * Kategorien, Suche, zuletzt benutzt – alle Apps öffnen im selben Fenster. */
const HOME_CATS = [
  ['all', 'Alle', 'Alles auf einen Blick'],
  ['general', 'Allgemein', 'Alltag: Rechner, Notizen, Wetter und mehr'],
  ['gaming', 'Gaming', 'Clips, Crosshair, Geräte und Minecraft'],
  ['productivity', 'Produktivität', 'Video, Dokumente, Präsentation, Zeichnen'],
  ['entertainment', 'Unterhaltung', 'Quiz, Wordle, Schach, Geo und Shop'],
  ['desktop', 'Desktop', 'Island, Widgets, Task-Manager, Windows'],
];
// 2.45 Kategorie-Karten: Farbe und Symbol wie im Referenzbild
const HOME_CAT_COLOR = { general: '#a78bfa', gaming: '#38bdf8', productivity: '#60a5fa', entertainment: '#c084fc', desktop: '#93c5fd' };
const HOME_CAT_SVG = {
  general: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M12 2.8 20.5 7.5v9L12 21.2 3.5 16.5v-9Z"/><path d="M3.8 7.6 12 12l8.2-4.4M12 12v9"/></svg>',
  gaming: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 7h10a5 5 0 0 1 5 5v1.6c0 2.4-1.2 4.4-3 4.4-1.2 0-2-.8-2.8-1.9l-.5-.8H8.3l-.5.8C7 17.2 6.2 18 5 18c-1.8 0-3-2-3-4.4V12a5 5 0 0 1 5-5Z" opacity=".95"/><path d="M6.6 10.2h1.6v1.6h1.6v1.6H8.2V15H6.6v-1.6H5v-1.6h1.6Z" fill="#0b1020"/><circle cx="16" cy="13.6" r="1.1" fill="#0b1020"/><circle cx="18.4" cy="11.2" r="1.1" fill="#0b1020"/></svg>',
  productivity: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.6 2 5 13.3h6l-1.6 8.7L19 10.4h-6.1Z"/></svg>',
  entertainment: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.3l-5.8 3.1 1.1-6.5-4.7-4.6 6.5-.9Z"/></svg>',
  desktop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><rect x="2.8" y="4" width="18.4" height="12.4" rx="2.2"/><path d="M9 20.2h6M12 16.4v3.8"/></svg>',
};
const HOME_CAT_ICON = { all: 'spark', general: 'grid', gaming: 'crosshair', productivity: 'bolt', entertainment: 'music', desktop: 'home' };
const HOME_APPS = {
  general: ['chats', 'tool-achievements', 'tool-speed', 'tool-backgrounds', 'tool-calc', 'tool-notes', 'tool-translate', 'tool-convert', 'tool-currency', 'tool-weather', 'tool-worldclock', 'tool-timer', 'tool-password', 'tool-clipboard', 'tool-account'],
  gaming: ['gaming', 'tool-clips', 'tool-keyboard', 'tool-streamdeck', 'tool-fans', 'tool-modrinth', 'tool-autoclick', 'tool-schematics'],
  productivity: ['tool-cloud', 'video', 'beat', 'screenshot', 'docs', 'tool-slides', 'tool-draw', 'tool-photo', 'model3d', 'agenda', 'tool-recherche'],
  entertainment: ['tool-piano', 'tool-radio', 'tool-deepdive', 'tool-wordle', 'tool-sizeup', 'tool-eyeball', 'tool-player', 'chess', 'geo', 'worldview', 'tool-games', 'tool-football', 'tool-store'],
  desktop: ['tool-desktop', 'orbit', 'control', 'tool-taskman', 'tool-parental', 'tool-screentime', 'tool-phone', 'tool-shield', 'settings'],
};
let homeCat = 'all';
let homeQuery = '';
const homeInfo = (id) => {
  if (id === 'control') return { title: 'Kontrollzentrum', sub: 'Lautstärke, Helligkeit, Mixer', desc: 'Lautstärke, Helligkeit, App-Mixer, Game-Modus, Wecker und „PC wach halten“.' };
  const a = ALL_APPS()[id];
  return a ? { title: a.title, sub: a.sub || '', desc: a.desc || '' } : null;
};
function homeStatus(id) {
  const mod = moduleState(id);
  if (mod?.error) return '<span class="hc-pill bad">Fehler</span>';
  if (id === 'orbit') return state.orbit?.running ? '<span class="hc-pill ok">Läuft</span>' : '';
  if (id === 'gaming') return '<span class="hc-pill ok">Aktiv</span>';
  if (state.badges?.[id]) return `<span class="hc-pill red">${state.badges[id]} neu</span>`;
  if ((state.opened || []).includes(id) && MODULE_PAGES.has(id)) return '<span class="hc-pill">Offen</span>';
  return '';
}
function homeCard(id, i = 0) {
  const info = homeInfo(id);
  if (!info) return '';
  const attr = id === 'control' ? 'data-dock-special="control"' : `data-open="${id}"`;
  const fav = (state.settings.favoriteApps || []).includes(id);
  return `<button class="hc" ${attr} style="--d:${Math.min(i, 16) * 22}ms">${appArt(id, 'hc-ic')}<div class="hc-txt"><b>${esc(info.title)}</b><small>${esc(info.desc || info.sub)}</small></div>${homeStatus(id)}<span class="hc-fav ${fav ? 'on' : ''}" data-fav="${esc(id)}" title="${fav ? 'Aus Favoriten entfernen' : 'Zu Favoriten hinzufügen'}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.8l2.75 5.86 6.4.74-4.76 4.38 1.3 6.32L12 16.9l-5.69 3.2 1.3-6.32L2.85 9.4l6.4-.74z"/></svg></span></button>`;
}
function homeListHtml() {
  const q = homeQuery.trim().toLowerCase();
  if (q) {
    const all = [...new Set(Object.values(HOME_APPS).flat())];
    const hits = appSearch(all.filter((id) => homeInfo(id)), q, (id) => { const i = homeInfo(id); return `${i.title} ${i.sub} ${i.desc}`; });
    return hits.length ? `<div class="hc-grid">${hits.map(homeCard).join('')}</div>` : `<p class="muted hc-empty">Keine App gefunden für „${esc(homeQuery)}“.</p>`;
  }
  if (homeCat === 'all')
    return HOME_CATS.slice(1)
      .map(([k, n, d]) => `<section class="hc-sec"><div class="hc-sec-h"><h3>${esc(n)}</h3><small>${esc(d)}</small><button class="hc-more" data-home-cat="${k}">Alle ${HOME_APPS[k].length} ›</button></div><div class="hc-grid">${HOME_APPS[k].map(homeCard).join('')}</div></section>`)
      .join('');
  return `<div class="hc-grid">${HOME_APPS[homeCat].map(homeCard).join('')}</div>`;
}
/* ------------------------------------------------------------------ Startseite 2.28
 * Apple × Nothing: große Glas-Widgets (Punktmatrix-Uhr, System, Kalender, Musik, Bildschirmzeit,
 * Favoriten) und darunter ein App-Raster wie am iPad. */
const pad2 = (n) => String(n).padStart(2, '0');
function homeIcon(id, i = 0) {
  const info = homeInfo(id);
  if (!info) return '';
  const attr = id === 'control' ? 'data-dock-special="control"' : `data-open="${id}"`;
  const fav = (state.settings.favoriteApps || []).includes(id);
  const badge = state.badges?.[id] ? `<em class="ai-badge">${state.badges[id]}</em>` : '';
  const run = (state.opened || []).includes(id) && MODULE_PAGES.has(id) ? '<i class="ai-run"></i>' : '';
  return `<button class="ai" ${attr} style="--d:${Math.min(i, 24) * 14}ms" title="${esc(info.desc || info.sub || info.title)}"><span class="ai-ic">${appArt(id, 'ai-art')}${badge}</span><span class="ai-n">${esc(info.title)}</span><span class="ai-d">${esc(info.sub || "")}</span>${run}<span class="ai-fav hc-fav ${fav ? 'on' : ''}" data-fav="${esc(id)}" title="${fav ? 'Aus Favoriten entfernen' : 'Zu Favoriten'}"><svg viewBox="0 0 24 24"><path d="M12 2.8l2.75 5.86 6.4.74-4.76 4.38 1.3 6.32L12 16.9l-5.69 3.2 1.3-6.32L2.85 9.4l6.4-.74z"/></svg></span></button>`;
}
function homeGridHtml() {
  const q = homeQuery.trim().toLowerCase();
  if (q) {
    const all = [...new Set(Object.values(HOME_APPS).flat())];
    const hits = appSearch(all.filter((id) => homeInfo(id)), q, (id) => { const i = homeInfo(id); return `${i.title} ${i.sub} ${i.desc}`; });
    return hits.length ? `<div class="ai-grid">${hits.map(homeIcon).join('')}</div>` : `<p class="muted hc-empty">Keine App gefunden für „${esc(homeQuery)}“.</p>`;
  }
  if (homeCat === 'all')
    return HOME_CATS.slice(1)
      .map(([k, n]) => `<section class="ai-sec"><h3>${esc(n)}</h3><div class="ai-grid">${HOME_APPS[k].map(homeIcon).join('')}</div></section>`)
      .join('');
  return `<div class="ai-grid">${HOME_APPS[homeCat].map(homeIcon).join('')}</div>`;
}
function dotBar(v, n = 18) {
  const k = Math.round((Math.max(0, Math.min(100, Number(v) || 0)) / 100) * n);
  let h = '<span class="w3-dots">';
  for (let i = 0; i < n; i++) h += `<i class="${i < k - 1 ? 'on' : i === k - 1 ? 'tip' : ''}"></i>`;
  return `${h}</span>`;
}
let homeMedia = null;
let homeScreen = null;
let homeScreenAt = 0;
/* 2.45 SBB-Bahnhofsuhr (wie in der Revulution Island): Sekundenzeiger läuft in 58,5 s herum,
   wartet 1,5 s oben, dann springt der Minutenzeiger. */
function sbbClockSvg(cls = '') {
  let ticks = '';
  for (let i = 0; i < 60; i++) {
    const hour = i % 5 === 0;
    ticks += `<rect x="${hour ? 48.2 : 49.3}" y="${hour ? 4 : 4}" width="${hour ? 3.6 : 1.4}" height="${hour ? 12 : 3.6}" transform="rotate(${i * 6} 50 50)"/>`;
  }
  return `<svg class="sbb ${cls}" viewBox="0 0 100 100" aria-label="Bahnhofsuhr"><circle cx="50" cy="50" r="49" class="sbb-face"/><g class="sbb-ticks">${ticks}</g>
    <g class="sbb-h"><path d="M47.3 61 L48 22 L52 22 L52.7 61Z"/></g><g class="sbb-m"><path d="M48.1 62 L48.7 8.5 L51.3 8.5 L51.9 62Z"/></g>
    <g class="sbb-s"><rect x="49.35" y="17" width="1.3" height="47"/><circle cx="50" cy="17.5" r="5.2"/></g><circle cx="50" cy="50" r="1.4" class="sbb-pin"/></svg>`;
}
function sbbAngles(d = new Date()) {
  const s = d.getSeconds() + d.getMilliseconds() / 1000;
  const sec = Math.min(360, (s / 58.5) * 360);
  const min = (d.getMinutes() + (s >= 59.6 ? 1 : 0)) * 6; // springt, wenn der Sekundenzeiger oben ankommt
  const hour = ((d.getHours() % 12) + d.getMinutes() / 60) * 30;
  return { sec: sec >= 360 ? 0 : sec, min, hour };
}
let sbbRaf = 0;
function sbbTick() {
  sbbRaf = 0;
  const clocks = document.querySelectorAll('svg.sbb');
  if (!clocks.length || document.hidden) return;
  const a = sbbAngles();
  for (const c of clocks) {
    c.querySelector('.sbb-s')?.setAttribute('transform', `rotate(${a.sec.toFixed(2)} 50 50)`);
    c.querySelector('.sbb-m')?.setAttribute('transform', `rotate(${a.min} 50 50)`);
    c.querySelector('.sbb-h')?.setAttribute('transform', `rotate(${a.hour.toFixed(2)} 50 50)`);
  }
  sbbRaf = requestAnimationFrame(sbbTick);
}
const sbbStart = () => { if (!sbbRaf) sbbRaf = requestAnimationFrame(sbbTick); };
document.addEventListener('visibilitychange', sbbStart);
setInterval(sbbStart, 1000);
function w3Clock() {
  const d = new Date();
  const wd = d.toLocaleDateString('de-DE', { weekday: 'long' });
  return `<div class="w3 w3-clock">
    <div class="w3c-digital">
      <div class="w3-label">${esc(d.toLocaleDateString('de-DE', { weekday: 'short' }).replace('.', '').toUpperCase())} · ${pad2(d.getDate())} ${esc(d.toLocaleDateString('de-DE', { month: 'short' }).replace('.', '').toUpperCase())}</div>
      <time class="w3-time" id="w3-time">${pad2(d.getHours())}:${pad2(d.getMinutes())}</time>
      <div class="w3-sub"><span id="w3-sec">${pad2(d.getSeconds())}</span> s · ${esc(wd)}, ${d.getDate()}. ${esc(d.toLocaleDateString('de-DE', { month: 'long' }))}</div>
    </div>
    <div class="w3c-analog" data-key="sbb" data-morph-keep>${sbbClockSvg()}</div>
  </div>`;
}
function w3Sys() {
  const l = pcLive;
  const rows = l ? [['CPU', l.cpu], ['RAM', l.ramPct], ['GPU', l.gpu]] : [];
  return `<div class="w3 w3-sys" data-pc-open="1">
    <div class="w3-label">SYSTEM</div>
    <div id="w3-sys">${l ? rows.map(([n, v]) => `<div class="w3-row"><span>${n}</span>${dotBar(v)}<b>${v == null ? '–' : Math.round(v)}<small>%</small></b></div>`).join('') : '<div class="w3-wait">wird gemessen …</div>'}</div>
  </div>`;
}
/* 2.38 Countdown-Ring: hohl, schließt sich über 7 Tage im Uhrzeigersinn; am Tag selbst steht der Anfangsbuchstabe drin. */
function countdownRing(e, size = 22) {
  const start = new Date(e.start);
  const now = new Date();
  const span = 7 * 86400000;
  const left = start - now;
  const p = Math.max(0, Math.min(1, 1 - left / span));
  const today = start.toDateString() === now.toDateString();
  const col = e.color || '#ff453a';
  const days = Math.ceil(left / 86400000);
  const tip = today ? 'Heute' : days <= 1 ? 'Morgen' : `in ${days} Tagen`;
  return `<span class="cd-ring ${today ? 'today' : ''}" style="--c:${esc(col)};width:${size}px;height:${size}px" title="${esc(tip)}"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5" pathLength="100" class="t"/><circle cx="12" cy="12" r="9.5" pathLength="100" class="p" style="stroke-dashoffset:${(100 - p * 100).toFixed(1)}"/></svg>${today ? `<b>${esc(String(e.title || '?').trim().charAt(0).toUpperCase())}</b>` : ''}</span>`;
}
function w3Cal() {
  // Apple-Stil: links Wochentag + große Zahl, rechts der Monat mit Punkten für Termine
  const now = new Date();
  const y = now.getFullYear();
  const m = now.getMonth();
  const first = (new Date(y, m, 1).getDay() + 6) % 7;
  const days = new Date(y, m + 1, 0).getDate();
  // 2.46 Apple-Kalender: Punkte unter den Zahlen (mehrere Termine = mehrere Punkte mit Farbübergang), Quick-Add +
  let dayMap = state.calMonth && state.calMonth.y === y && state.calMonth.m === m ? state.calMonth.days || {} : null;
  if (!dayMap) {
    dayMap = {};
    for (const e of state.upcoming || []) { const d = new Date(e.start); if (d.getFullYear() === y && d.getMonth() === m) (dayMap[d.getDate()] = dayMap[d.getDate()] || []).push(e.color || '#ff453a'); }
  }
  const list = (state.upcoming || []).slice(0, 2);
  const whenTxt = (e) => {
    const w = new Date(e.start);
    const tm = new Date(Date.now() + 86400000);
    const day = w.toDateString() === now.toDateString() ? 'Heute' : w.toDateString() === tm.toDateString() ? 'Morgen' : w.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
    return e.allDay ? day : `${day} · ${w.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
  };
  const grid = window.RevCal ? window.RevCal.month(y, m, dayMap, { today: now }) : '';
  void first; void days;
  return `<div class="w3 w3-cal" data-open="agenda">
    ${window.RevCal ? window.RevCal.plus() : ''}
    <div class="w3c-top">
      <div class="w3c-head"><span class="w3c-wd">${esc(now.toLocaleDateString('de-DE', { weekday: 'long' }).toUpperCase())}</span><b class="w3c-day">${now.getDate()}</b>
        ${list.length ? `<div class="w3c-list">${list.map((e) => `<div class="w3c-ev" style="--c:${esc(e.color || '#ff453a')}"><i></i><div><b>${esc(e.title)}</b><small>${esc(whenTxt(e))}</small></div></div>`).join('')}</div>` : '<span class="w3c-none">Keine Termine</span>'}
      </div>
      <div class="w3c-grid"><div class="w3c-mon">${esc(now.toLocaleDateString('de-DE', { month: 'long' }))}</div>${grid}</div>
    </div>
  </div>`;
}
function w3Music() {
  const m = homeMedia;
  if (!m?.title) return `<div class="w3 w3-music empty"><div class="w3-label">LÄUFT GERADE</div><div class="w3-mu-empty">${icon('music', 22)}<span>Gerade läuft nichts</span></div></div>`;
  const art = m.art ? `style="background-image:url('data:image/jpeg;base64,${m.art}')"` : '';
  const prog = m.duration > 0 ? Math.min(100, (m.position / m.duration) * 100) : 0;
  return `<div class="w3 w3-music ${m.playing ? 'playing' : ''}">
    <div class="w3-art" ${art}></div>
    <div class="w3-mu">
      <div class="w3-label">LÄUFT GERADE</div>
      <b>${esc(m.title)}</b><span>${esc(m.artist || '')}</span>
      <div class="w3-ly" aria-live="off"></div>
      <div class="w3-prog"><i style="width:${prog}%"></i></div>
      <div class="w3-ctl"><button data-media="prev">${icon('arrow', 14).replace('class="icon"', 'class="icon flip"')}</button><button class="main" data-media="playpause" data-ic="${m.playing ? 'pause' : 'play'}">${icon(m.playing ? 'pause' : 'play', 16)}</button><button data-media="next">${icon('arrow', 14)}</button></div>
    </div>
  </div>`;
}
/* 2.45.1 Wetter-Widget auf der Startseite (Ort aus Wetter-App bzw. Standort) */
const WX_IC = { 0: '☀️', 1: '🌤️', 2: '⛅', 3: '☁️', 45: '🌫️', 48: '🌫️', 51: '🌦️', 53: '🌦️', 55: '🌧️', 61: '🌧️', 63: '🌧️', 65: '🌧️', 71: '🌨️', 73: '🌨️', 75: '❄️', 80: '🌦️', 81: '🌧️', 82: '⛈️', 95: '⛈️', 96: '⛈️', 99: '⛈️' };
let homeWx = null;
let homeWxAt = 0;
function w3Weather() {
  const city = state.settings?.weatherCity;
  if (city?.name && Date.now() - homeWxAt > 15 * 60000) {
    homeWxAt = Date.now();
    window.hub.tool.fetch(`https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1`).then((d) => {
      homeWx = { city: city.name, t: d?.current?.temperature_2m, c: d?.current?.weather_code, max: d?.daily?.temperature_2m_max?.[0], min: d?.daily?.temperature_2m_min?.[0] };
      const el = document.querySelector('.w3-weather');
      if (el) el.outerHTML = w3Weather();
    }).catch(() => {});
  }
  const w = homeWx;
  if (!city?.name) return '<div class="w3 w3-weather" data-open="tool-weather"><div class="w3-label">WETTER</div><small>Ort in der Wetter-App wählen oder Standort erlauben.</small></div>';
  return `<div class="w3 w3-weather" data-open="tool-weather"><div class="w3-label">${esc(String(city.name).toUpperCase())}</div>
    <div class="wx-big"><i>${w ? WX_IC[w.c] || '🌡️' : '…'}</i><b>${w && Number.isFinite(w.t) ? `${Math.round(w.t)}°` : '–'}</b></div>
    <small>${w && Number.isFinite(w.max) ? `H ${Math.round(w.max)}° · T ${Math.round(w.min)}°` : 'lädt …'}</small></div>`;
}
function w3Screen() {
  const t = homeScreen?.total || 0;
  const h = Math.floor(t / 3600);
  const mi = Math.round((t % 3600) / 60);
  const apps = (homeScreen?.apps || []).slice(0, 3);
  const max = Math.max(1, apps[0]?.secs || 1);
  if (Date.now() - homeScreenAt > 60000) {
    homeScreenAt = Date.now();
    window.hub.screentime?.summary?.().then((r) => { homeScreen = r; const el = $('#w3-screen'); if (el) el.outerHTML = w3Screen(); }).catch(() => {});
  }
  return `<div class="w3 w3-screen" id="w3-screen" data-open="tool-screentime">
    <div class="w3-label">BILDSCHIRMZEIT</div>
    <div class="w3-big">${h ? `${h}<small>h</small> ` : ''}${mi}<small>m</small></div>
    ${apps.map((a) => `<div class="w3-app"><span>${esc(a.name || a.exe)}</span><i><em style="width:${Math.max(4, (a.secs / max) * 100)}%"></em></i></div>`).join('')}
  </div>`;
}
function w3Fav() {
  const favs = (state.settings.favoriteApps || []).filter((id) => homeInfo(id)).slice(0, 8);
  const recent = (state.settings.recentApps || []).filter((id) => homeInfo(id) && !favs.includes(id)).slice(0, 8 - favs.length);
  const list = [...favs, ...recent];
  return `<div class="w3 w3-fav">
    <div class="w3-label">${favs.length ? 'FAVORITEN' : 'ZULETZT'}</div>
    <div class="w3-favs">${list.length ? list.map((id) => `<button ${id === 'control' ? 'data-dock-special="control"' : `data-open="${id}"`} title="${esc(homeInfo(id).title)}">${appArt(id, 'w3-fic')}</button>`).join('') : '<span class="w3-wait">Tippe auf den Stern einer App.</span>'}</div>
  </div>`;
}
function pageHome() {
  if (!state.settings.onboarded) return pageWelcome();
  const hour = new Date().getHours();
  const greeting = hour < 11 ? 'Guten Morgen' : hour < 18 ? 'Hallo' : 'Guten Abend';
  const failed = state.modules.filter((mod) => mod.error);
  if (!pcInfo && !pcLoading) {
    pcLoading = true;
    window.hub.pcInfo?.().then((r) => { pcInfo = r; }).catch(() => {});
  }
  refreshPcLive();
  return `<div class="page home3">
    <header class="h3-head">
      <div class="h3-hello"><h1>${greeting}${profile?.name ? `, ${esc(profile.name)}` : ''}</h1><p>Was möchtest du heute machen?</p></div>
      <div class="h3-me"><button class="h3-news" data-news="show" title="Was ist neu in ${esc(state.version || '')}">${icon('spark', 15)}<span>Was ist neu</span></button></div>
    </header>
    ${cameraWidget()}
    ${state.settings.locAsked ? '' : `<div class="loc-ask"><span class="loc-ask-ic">📍</span><div class="grow"><b>Standort für das Wetter verwenden?</b><small>Der Hub fragt Windows nach deinem Standort (sonst grob über die Internetverbindung) und zeigt dir dein lokales Wetter. Jederzeit in den Einstellungen änderbar.</small></div><button class="btn small primary" data-loc-ask="yes">Erlauben</button><button class="btn small ghost" data-loc-ask="no">Nein danke</button></div>`}
    ${failed.length ? `<div class="note" style="margin-bottom:16px">${icon('alert', 18)}<div>${failed.map((mod) => `<b>${esc(mod.name)}</b> konnte nicht geladen werden: ${esc(mod.error)}`).join('<br>')}</div></div>` : ''}
    ${homeQuery ? '' : `<section class="w3-grid">${w3Clock()}${w3Sys()}${w3Cal()}${w3Music()}${w3Weather()}${w3Screen()}${w3Fav()}</section>`}
    <div class="h3-bar">
      <nav class="h2-tabs h3-tabs">${HOME_CATS.map(([k, n]) => `<button class="${homeCat === k && !homeQuery ? 'on' : ''}" data-home-cat="${k}"><span>${esc(n)}</span></button>`).join('')}</nav>
      <label class="h2-search h3-search">${icon('search', 15)}<input id="home-q" type="search" placeholder="Apps suchen" value="${esc(homeQuery)}" spellcheck="false" autocomplete="off" /></label>
    </div>
    <div id="home-results">${homeGridHtml()}</div>
  </div>`;
}
// Uhr jede Sekunde, ohne die Seite neu zu bauen
setInterval(() => {
  const t = $('#w3-time');
  if (!t) return;
  const d = new Date();
  const hm = `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  if (t.textContent !== hm) t.textContent = hm;
  const s = $('#w3-sec');
  if (s) s.textContent = pad2(d.getSeconds());
}, 1000);
function w3SysPatch() {
  const el = $('#w3-sys');
  if (!el || !pcLive) return;
  const l = pcLive;
  el.innerHTML = [['CPU', l.cpu], ['RAM', l.ramPct], ['GPU', l.gpu]].map(([n, v]) => `<div class="w3-row"><span>${n}</span>${dotBar(v)}<b>${v == null ? '–' : Math.round(v)}<small>%</small></b></div>`).join('');
}
document.addEventListener('click', (e) => {
  const b = e.target.closest?.('.w3-music [data-media]');
  if (!b) return;
  e.stopPropagation();
  window.hub.cc?.media?.(b.dataset.media)?.catch?.(() => {});
  if (b.dataset.media === 'playpause' && homeMedia) {
    homeMedia.playing = !homeMedia.playing;
    const el = document.querySelector('.w3-music');
    if (el) el.outerHTML = w3Music();
  }
});
/* 2.44 Songtext in der Player-Karte – wie in der Island: die aktuelle Zeile gleitet weich von unten
   herein, die alte verschwindet nach oben, und die gesungenen Wörter füllen sich weiß. */
let homeLyRaf = 0;
let homeLyIdx = -2;
let homeLyKey = '';
function homeLyricsTick() {
  if (homeLyRaf) return;
  homeLyRaf = requestAnimationFrame(() => {
    homeLyRaf = 0;
    const box = document.querySelector('.w3-music .w3-ly');
    const L = window.PlayerLyrics;
    if (!box || !L) return;
    const lines = L.lines();
    const p = L.pos();
    const i = lines?.length ? L.index(p) : -1;
    if (L.key() !== homeLyKey || box.dataset.idx !== String(homeLyIdx)) homeLyIdx = -2;
    homeLyKey = L.key();
    if (i !== homeLyIdx) {
      homeLyIdx = i;
      box.dataset.idx = String(i);
      for (const old of box.querySelectorAll('p:not(.out)')) {
        old.classList.add('out');
        setTimeout(() => old.remove(), 600);
      }
      const text = i >= 0 ? lines[i].text : '';
      if (text) {
        const el = document.createElement('p');
        el.innerHTML = L.words(text);
        box.appendChild(el);
      }
    }
    const cur = box.querySelector('p:not(.out)');
    if (cur && i >= 0) L.paint(cur, i, p);
    if (homeMedia?.playing) homeLyricsTick();
    else setTimeout(homeLyricsTick, 500);
  });
}
window.hub.onMedia?.((m) => {
  if (!m) return;
  setTimeout(homeLyricsTick, 0);
  const same = homeMedia && homeMedia.title === m.title && homeMedia.artist === m.artist;
  const prevArt = homeMedia?.art || '';
  homeMedia = { ...m, art: m.art || (same ? prevArt : '') };
  const el = document.querySelector('.w3-music');
  if (!el) return;
  // Gleicher Song: nur Fortschritt und Knopf anfassen – sonst flackerte das Widget beim Scrollen.
  if (same && homeMedia.art === prevArt && !el.classList.contains('empty')) {
    el.classList.toggle('playing', Boolean(homeMedia.playing));
    const bar = el.querySelector('.w3-prog i');
    if (bar) bar.style.width = `${homeMedia.duration > 0 ? Math.min(100, (homeMedia.position / homeMedia.duration) * 100) : 0}%`;
    const main = el.querySelector('[data-media="playpause"]');
    const want = homeMedia.playing ? 'pause' : 'play';
    if (main && main.dataset.ic !== want) {
      main.dataset.ic = want;
      main.innerHTML = icon(want, 16);
    }
    return;
  }
  el.outerHTML = w3Music();
  document.querySelector('.w3-music')?.classList.add('no-in');
});
/* Kamera läuft: wer sie benutzt – und ein Knopf zum Ausschalten, wenn es der Hub selbst ist. */
function cameraWidget() {
  const cam = state.camera;
  if (!cam?.on) return '';
  const own = cam.users.some((u) => u.own);
  const names = cam.users.map((u) => (u.own && cam.parts?.length ? `Revulution Hub · ${cam.parts.join(', ')}` : u.name));
  return `<section class="cam-live">
    <div class="cam-dot"><i></i></div>
    <div class="cam-txt"><span>KAMERA LÄUFT</span><b>Wird benutzt von ${names.map((n) => `<em>${esc(n)}</em>`).join(', ')}</b></div>
    ${own ? `<button class="btn small" data-cam="stop">${icon('close', 13)} Ausschalten</button>` : ''}
    <button class="btn small ghost" data-cam="settings">Kamera-Einstellungen</button>
  </section>`;
}
document.addEventListener('click', (e) => {
  const b = e.target.closest?.('[data-cam]');
  if (!b) return;
  if (b.dataset.cam === 'stop') run(() => window.hub.camera.stopOwn(), 'Kamera im Hub ausgeschaltet.');
  else window.hub.camera.settings().catch(() => {});
});
function pageWelcome() {
  const cats = HOME_CATS.slice(1);
  return `<div class="page welcome">
    <div class="wl-hero">
      <img class="wl-logo" src="assets/logo-mark.png" alt="" />
      <span class="wl-kicker">Willkommen</span>
      <h1>Revulution Hub</h1>
      <p>Alle deine Apps und Werkzeuge in einer einzigen App – Gaming, Schach, Videos, Dokumente, die Dynamic Island und vieles mehr. Alles öffnet im selben Fenster, das R oben links bringt dich immer zurück zur Startseite.</p>
    </div>
    <div class="wl-cats">${cats.map(([k, n, d], i) => `<div class="wl-cat" style="--d:${i * 80}ms"><div class="wl-icons">${HOME_APPS[k].slice(0, 4).map((id) => appArt(id, 'wl-ic')).join('')}</div><b>${esc(n)}</b><small>${esc(d)}</small></div>`).join('')}</div>
    <button class="wl-go" data-welcome="go">Zur Startseite <span>→</span></button>
  </div>`;
}
document.addEventListener('click', (e) => {
  const c = e.target.closest?.('[data-home-cat]');
  if (c) {
    homeCat = c.dataset.homeCat;
    homeQuery = '';
    render();
    const results = $('#home-results');
    if (results) {
      results.classList.remove('nt-cat-in');
      void results.offsetWidth;
      results.classList.add('nt-cat-in');
    }
    return;
  }
  if (e.target.closest?.('[data-welcome="go"]')) {
    state.settings.onboarded = true;
    window.hub.setSettings({ onboarded: true }).catch(() => {});
    return render();
  }
  if (e.target.closest?.('[data-welcome="reset"]')) {
    state.settings.onboarded = false;
    window.hub.setSettings({ onboarded: false }).catch(() => {});
    window.hub.open('home');
    return render();
  }
});
document.addEventListener('input', (e) => {
  if (e.target.id !== 'home-q') return;
  homeQuery = e.target.value;
  const box = $('#home-results');
  if (box) {
    box.innerHTML = homeGridHtml(); // nur die Liste – das Suchfeld behält den Fokus
    const widgets = document.querySelector('.w3-grid');
    if (widgets) widgets.hidden = Boolean(homeQuery);
    box.classList.remove('nt-cat-in');
    void box.offsetWidth;
    box.classList.add('nt-cat-in');
  }
  document.querySelectorAll('.h2-tabs button').forEach((b) => b.classList.toggle('on', !homeQuery && b.dataset.homeCat === homeCat));
});

/* ------------------------------------------------------------------ Profil & Shop */
let profile = null;
let shopSlot = 'pieces';
const Cos = () => window.RevCos;

function profileCardHtml() {
  if (!profile || !Cos()) return '';
  const eq = profile.cos.eq;
  return `<button class="me-card" data-open="tool-store">
    ${Cos().avatarHtml(eq, 54)}
    <div class="me-txt"><b ${Cos().nameStyle(eq)}>${esc(profile.name || 'Kein Name')}</b>${Cos().titleHtml(eq)}<span class="me-pts">◆ ${profile.points.toLocaleString('de-DE')} Punkte</span></div>
    <span class="me-shop">${icon('spark', 16)} Store</span>
  </button>`;
}

const SLOT_DESC = {
  pieces: 'Wie deine Figuren im Schach aussehen – auch deine Gegner sehen sie.',
  board: 'Das Schachbrett, auf dem du spielst.',
  avatar: 'Dein Bild in Schach, Geo, Chats und Ranglisten. Oder lade dein eigenes hoch.',
  color: 'Hintergrund deines Bildes.',
  frame: 'Rahmen um dein Bild.',
  name: 'Farbe deines Namens.',
  title: 'Titel neben deinem Namen.',
  effect: 'Effekt bei jedem Schachzug.',
};

function pageShop() {
  if (!profile || !Cos()) return '<div class="page"><div class="empty">Shop wird geladen …</div></div>';
  const C = Cos();
  const eq = profile.cos.eq;
  const slots = Object.keys(C.COSMETICS);
  const items = (C.COSMETICS[shopSlot] || []).filter((it) => !it.coins);
  return `<div class="page shop-page">
    <div class="shop-head">
      <div class="shop-me">${C.avatarHtml(eq, 88)}<div><b ${C.nameStyle(eq)}>${esc(profile.name || 'Kein Name')}</b>${C.titleHtml(eq)}<small>Ein Profil für Schach, Geo und Chats</small></div></div>
      <div class="shop-pts"><span>Deine Punkte</span><b>◆ ${profile.points.toLocaleString('de-DE')}</b><small>Punkte gibt es in Schach (Lernpfad, Partien) und Geo (Runden, Ranked).</small></div>
    </div>
    <div class="shop-tabs">${slots.map((sl) => `<button class="${sl === shopSlot ? 'on' : ''}" data-shop-slot="${sl}">${esc(C.SLOT_NAMES[sl]?.de || sl)}</button>`).join('')}</div>
    <p class="muted shop-desc">${esc(SLOT_DESC[shopSlot] || '')}</p>
    <div class="shop-grid">${items
      .map((it, i) => {
        const owned = it.price === 0 || (profile.cos.owned[shopSlot] || []).includes(it.id);
        const on = (eq[shopSlot] || C.COSMETICS[shopSlot][0].id) === it.id;
        const name = it.t?.de || (it.glyph ? '' : '') || '';
        const afford = profile.points >= it.price;
        const action = on ? (it.custom ? 'Neues Bild' : 'Angelegt') : owned ? (it.custom ? 'Bild hochladen' : 'Anlegen') : `◆ ${it.price.toLocaleString('de-DE')}`;
        return `<button class="shop-card ${on ? 'on' : ''} ${owned ? 'owned' : ''} ${!owned && !afford ? 'locked' : ''} ${it.anim ? 'anim' : ''}" data-shop-item="${it.id}" style="animation-delay:${Math.min(i, 12) * 35}ms">
          <div class="sc-prev">${C.preview(shopSlot, it, eq, profile.name)}</div>
          ${name ? `<span class="sc-name">${esc(name)}</span>` : ''}
          <span class="sc-act">${action}</span></button>`;
      })
      .join('')}</div>
  </div>`;
}

function uploadProfileImage() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.onchange = () => {
    const file = input.files?.[0];
    if (!file) return;
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = c.height = 96;
      const side = Math.min(img.width, img.height);
      c.getContext('2d').drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 96, 96);
      URL.revokeObjectURL(img.src);
      run(() => window.hub.profile.image(c.toDataURL('image/jpeg', 0.82)), 'Profilbild gespeichert.').then((p) => p && setProfile(p));
    };
    img.src = URL.createObjectURL(file);
  };
  input.click();
}

/* Zahnrad + Profil schweben fest links neben den Fenster-Knöpfen – egal welche Seite offen ist */
function placeTopTools() {
  const tools = document.querySelector('.top-tools');
  const win = document.querySelector('.topbar .win');
  if (!tools || !win) return;
  const r = win.getBoundingClientRect();
  if (!r.width) return;
  tools.style.right = `${Math.round(window.innerWidth - r.left + 8)}px`;
  tools.style.top = `${Math.round(r.top + r.height / 2 - 16)}px`;
}
window.addEventListener('resize', placeTopTools);
setInterval(placeTopTools, 1500);
function topAccount() {
  placeTopTools();
  // Konto oben in der Fensterleiste: nur das Profilbild
  const acc = $('#top-acc');
  if (acc && profile && Cos()) {
    const html = Cos().avatarHtml(profile.cos.eq, 26);
    if (acc.dataset.h !== html) {
      acc.dataset.h = html;
      acc.innerHTML = html;
    }
    acc.title = profile.name ? `${profile.name} · Konto` : 'Konto';
  }
}
function setProfile(p) {
  profile = p;
  topAccount();
  if (['home', 'shop', 'settings'].includes(state?.active)) render();
}

document.addEventListener('click', async (event) => {
  const slot = event.target.closest?.('[data-shop-slot]');
  if (slot) {
    shopSlot = slot.dataset.shopSlot;
    return render();
  }
  const item = event.target.closest?.('[data-shop-item]');
  if (!item) return;
  const C = Cos();
  const it = C.COSMETICS[shopSlot].find((x) => x.id === item.dataset.shopItem);
  const owned = it.price === 0 || (profile.cos.owned[shopSlot] || []).includes(it.id);
  if (!owned) {
    if (profile.points < it.price) return toast(`Dafür fehlen dir noch ◆ ${(it.price - profile.points).toLocaleString('de-DE')}.`, 'error');
    const p = await run(() => window.hub.profile.buy(shopSlot, it.id), 'Freigeschaltet!');
    if (p) {
      sound.play('success');
      setProfile(p);
      if (it.custom) uploadProfileImage();
    }
    return;
  }
  if (it.custom) return uploadProfileImage();
  const p = await run(() => window.hub.profile.equip(shopSlot, it.id));
  if (p) setProfile(p);
});

/** Startseite: die nächsten Termine aus der Agenda. */
function upcomingHtml() {
  const list = state.upcoming || [];
  if (!list.length) return '';
  const fmt = (e) => {
    const d = new Date(e.start);
    const today = new Date();
    const tomorrow = new Date(Date.now() + 86400000);
    const day = d.toDateString() === today.toDateString() ? 'Heute' : d.toDateString() === tomorrow.toDateString() ? 'Morgen' : d.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
    return e.allDay ? `${day} · ganztägig` : `${day} · ${d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
  };
  return `<div class="upcoming card" data-open="agenda">
    <div class="up-head">${icon('calendar', 18)}<b>Nächste Termine</b><span class="open-link">Agenda ${icon('arrow', 14)}</span></div>
    <div class="up-list">${list.map((e) => `<div class="up-item">${countdownRing(e, 26)}<div><b>${esc(e.title)}</b><small>${esc(fmt(e))}${e.location ? ` · ${esc(e.location)}` : ''}</small></div></div>`).join('')}</div>
  </div>`;
}

function pageModule(id) {
  const mod = moduleState(id);
  if (mod?.error) {
    return `<div class="page"><div class="note">${icon('alert', 18)}<div><b>${esc(APPS[id].title)}</b> konnte nicht geladen werden.<br>${esc(mod.error)}</div></div></div>`;
  }
  // The app is drawn on top; the page stays empty so the wallpaper shows through.
  if (mod?.ready) return '';
  return `<div class="page"><div class="empty">${icon('refresh', 22).replace('class="icon"', 'class="icon spin"')}<br>${esc(APPS[id].title)} wird geladen …</div></div>`;
}

function settingRow(key, title, text, on) {
  return `<div class="list-row"><div class="grow"><strong>${esc(title)}</strong><small>${esc(text)}</small></div><button class="switch ${on ? 'on' : ''}" data-setting="${key}" aria-pressed="${on}"></button></div>`;
}

const FRIENDLY = { hub: 'Revulution Hub', dropzone: 'Dateien (Dropzone)', gaming: 'Gaming Hub', orbit: 'Revulution Island', sysmon: 'System-Monitor', screenshot: 'Screenshots', video: 'Video-Schnitt', beat: 'Beat Lab', docs: 'Dokumente', chess: 'Schach', geo: 'GeoRevulution', agenda: 'Agenda', chats: 'Chats' };

/** „PC-Stärke“: Einstufung 1–10 aus CPU, RAM und Grafikkarte. */
let pcInfo = null;
let pcLoading = false;
let pcLive = null;
let pcBig = false;
let pcTimer = null;

const pcPct = (v) => (v == null ? '–' : `${Math.round(v)} %`);
const pcCol = (v) => (v == null ? '#64748b' : v >= 85 ? '#f87171' : v >= 60 ? '#fbbf24' : '#4ade80');

function pcStatsHtml(big = false) {
  const l = pcLive;
  if (!l) return `<div class="pc-stats"><span class="pc-wait">Live-Werte werden gemessen …</span></div>`;
  const sys = l.disks.find((d) => d.d === 'C:') || l.disks[0];
  const diskPct = sys ? 100 - (sys.free / sys.size) * 100 : null;
  const stats = [
    ['CPU', l.cpu, pcPct(l.cpu)],
    ['RAM', l.ramPct, `${String(l.ramUsed).replace('.', ',')} / ${String(l.ramTotal).replace('.', ',')} GB`],
    ['GPU', l.gpu, pcPct(l.gpu)],
    [`Laufwerk ${sys?.d || ''}`, diskPct, sys ? `${Math.round(sys.free / 1024 ** 3)} GB frei` : '–'],
  ];
  return `<div class="pc-stats ${big ? 'big' : ''}">${stats
    .map(([n, v, d]) => `<div class="pc-stat" style="--c:${pcCol(v)}"><span>${n}</span><b>${v == null ? '–' : Math.round(v) + '<i>%</i>'}</b><div class="pc-mini"><i style="width:${Math.max(2, Math.min(100, v || 0))}%"></i></div><small>${esc(d)}</small></div>`)
    .join('')}</div>`;
}

function pcVerdictHtml() {
  if (!pcLive) return '';
  const v = pcLive.verdict;
  return `<div class="pc-verdict ${v.ok ? 'ok' : 'bad'}">${icon(v.ok ? 'check' : 'alert', 16)}<span>${esc(v.text)}</span>${!v.ok ? '<em>Details ›</em>' : ''}</div>`;
}

function pcBigHtml() {
  const p = pcInfo;
  const l = pcLive;
  if (!p) return '';
  const hue = 10 + p.level * 12;
  const bars = [['Prozessor', p.scores.cpu, `${p.cpu} · ${p.cores} Threads${p.ghz ? ` · ${String(p.ghz).replace('.', ',')} GHz` : ''}`], ['Arbeitsspeicher', p.scores.ram, `${String(p.ram).replace('.', ',')} GB`], ['Grafikkarte', p.scores.gpu, p.gpu ? `${p.gpu.name}${p.gpu.vram ? ` · ${String(p.gpu.vram).replace('.', ',')} GB` : ''}` : 'Nicht erkannt']];
  const procRows = (list) => {
    const now = Date.now();
    const rows = list.filter((x) => !killed.has(x.n) || killed.get(x.n) > now);
    return `<table class="pc-procs"><tr><th>Programm</th><th>CPU</th><th>RAM</th><th></th></tr>${rows.map((x) => {
      const until = killed.get(x.n);
      const protectedProc = /^(electron|revulution|revulutionhub)$/i.test(x.n);
      const kill = until
        ? `<span class="pc-ring" title="Wird beendet …"><svg viewBox="0 0 18 18"><circle class="trk" cx="9" cy="9" r="7"/><circle class="val" cx="9" cy="9" r="7"/></svg></span>`
        : protectedProc
          ? '<small class="muted">geschützt</small>'
          : `<button class="pc-kill" data-kill="${x.id || 0}" data-kill-name="${esc(x.n)}" ${x.id ? '' : 'disabled'}>Beenden</button>`;
      return `<tr class="${until ? 'pc-killing' : ''}"><td>${esc(x.n)}${x.k > 1 ? ` <small>×${x.k}</small>` : ''}</td><td style="color:${pcCol(x.c * 2)}">${String(Math.round(x.c * 10) / 10).replace('.', ',')} %</td><td>${x.m >= 1024 ? String(Math.round(x.m / 102.4) / 10).replace('.', ',') + ' GB' : x.m + ' MB'}</td><td>${kill}</td></tr>`;
    }).join('')}</table>`;
  };
  const issues = l
    ? l.issues.length
      ? l.issues.map((x) => `<div class="pc-issue sev${x.sev}"><b>${esc(x.title)}</b><p>${esc(x.text)}</p>${x.procs?.length ? procRows(x.procs) : ''}</div>`).join('')
      : `<div class="pc-issue ok"><b>Alles im grünen Bereich</b><p>Keine Hintergrundprozesse, kein Energiesparmodus, genug Speicher – dein PC läuft so schnell, wie es seine Hardware erlaubt.</p></div>`
    : '<div class="pc-wait">Analyse läuft …</div>';
  return `<div class="pc-modal" data-pc-close="1"><div class="pc-sheet">
    <button class="pc-x" data-pc-close="1">${icon('close', 18)}</button>
    <div class="pc-top">
      <div class="pc-level big" style="--h:${hue}"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" class="trk"/><circle cx="60" cy="60" r="50" class="val" style="stroke-dasharray:${(p.level / 10) * 314} 314"/></svg><div><b>${p.level}</b><span>von 10</span></div></div>
      <div class="pc-info"><strong>PC-Stärke: ${esc(p.label)}</strong>
        ${l ? `<small>Gerade nutzbar: <b style="color:${l.effective >= p.level - 0.5 ? '#4ade80' : '#fbbf24'}">${String(l.effective).replace('.', ',')} / 10</b> · Aktualisiert alle paar Sekunden</small>` : ''}
        ${bars.map(([n, v, d]) => `<div class="pc-bar"><span>${n}</span><div class="pc-track"><i style="width:${v * 10}%"></i></div><small>${esc(d)}</small></div>`).join('')}
      </div>
    </div>
    <div id="pc-live-big">${pcStatsHtml(true)}</div>
    <h4 class="pc-h">Analyse – bringt dein PC seine Leistung?</h4>
    <div id="pc-analysis">${pcVerdictHtml()}${issues}</div>
    ${l ? `${l.procs.length ? `<h4 class="pc-h">Größte Prozesse gerade</h4><div id="pc-top-procs">${procRows(l.procs)}</div>` : ''}
    ${l.ramProcs?.length ? `<h4 class="pc-h">Größte RAM-Verbraucher – direkt beenden</h4><div id="pc-ram-procs">${procRows(l.ramProcs)}</div>` : ''}
    <p class="muted pc-foot">Energieplan: ${esc(l.planName || 'unbekannt')} · ${l.autostart} Autostart-Programme · läuft seit ${l.uptime >= 86400 ? Math.floor(l.uptime / 86400) + ' Tag(en)' : Math.floor(l.uptime / 3600) + ' Std.'}</p>` : ''}
  </div></div>`;
}

function withPcScroll(apply) {
  const host = $('#pc-big-host');
  const before = host?.querySelector('.pc-sheet');
  const sc = before?.scrollTop || 0;
  // Wer ganz unten ist, bleibt unten – auch wenn die Prozessliste kürzer wird.
  const atBottom = before ? before.scrollHeight - before.clientHeight - sc < 4 : false;
  apply();
  const after = host?.querySelector('.pc-sheet');
  if (!after) return;
  const target = () => (atBottom ? after.scrollHeight - after.clientHeight : sc);
  after.scrollTop = target();
  // Nach dem Neuaufbau kann der Browser die Höhe erst im nächsten Frame
  // kennen – dann noch einmal setzen, damit nichts nach oben springt.
  requestAnimationFrame(() => { if (after.isConnected) after.scrollTop = target(); });
}

function refreshPcLive() {
  if (pcTimer) return;
  const tick = async () => {
    const visible = state?.active === 'settings' || state?.active === 'home' || pcBig || overlay === 'control';
    if (!visible) {
      pcTimer = null;
      return;
    }
    try {
      pcLive = await window.hub.pcLive();
    } catch {}
    pcPatch();
    w3SysPatch();
    if (overlay === 'control') renderOverlay();
    const small = $('#pc-live');
    if (small) morph(small, pcStatsHtml() + pcVerdictHtml());
    const big = $('#pc-big-host');
    if (big && pcBig) {
      big.classList.add('pc-still');
      withPcScroll(() => morph(big, pcBigHtml()));
    }
    pcTimer = setTimeout(tick, pcBig ? 2500 : 4000);
  };
  pcTimer = setTimeout(tick, 50);
}

function setPcBig(on) {
  pcBig = on;
  let host = $('#pc-big-host');
  if (!host) {
    host = document.createElement('div');
    host.id = 'pc-big-host';
    document.body.appendChild(host);
  }
  if (on && !pcInfo) window.hub.pcInfo?.().then((r) => { pcInfo = r; if (pcBig) host.innerHTML = pcBigHtml(); }).catch(() => {});
  host.classList.remove('pc-still');
  host.innerHTML = on ? pcBigHtml() : '';
  if (on) refreshPcLive();
}

const killed = new Map();
function pcRerender() {
  pcPatch();
  if (pcBig) {
    const host = $('#pc-big-host');
    if (host) {
      host.classList.add('pc-still');
      withPcScroll(() => { host.innerHTML = pcBigHtml(); });
    }
  }
}
document.addEventListener('click', async (event) => {
  const kill = event.target.closest?.('[data-kill]');
  if (kill) {
    event.preventDefault();
    event.stopPropagation();
    const pid = Number(kill.dataset.kill) || 0;
    const name = kill.dataset.killName || 'Programm';
    if (!pid) return toast('Für dieses Programm wurde keine Prozess-ID gefunden.');
    kill.disabled = true;
    try {
      const ok = await window.hub.pcKill(pid);
      if (!ok) throw new Error('Windows hat das Beenden abgelehnt.');
      killed.set(name, Date.now() + 6000);
      toast(`„${name}“ wird beendet – verschwindet gleich aus der Liste.`);
      pcRerender();
      setTimeout(() => {
        killed.delete(name);
        pcRerender();
      }, 6000);
    } catch (error) {
      kill.disabled = false;
      toast(String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''));
    }
    return;
  }
  if (event.target.closest?.('[data-pc-close]') && (event.target.dataset.pcClose || event.target.closest('.pc-x'))) return setPcBig(false);
  if (event.target.closest?.('[data-pc-open]')) setPcBig(true);
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && pcBig) setPcBig(false);
});

/* ------------------------------------------------------------------ WLAN-Speedtest */
const speed = { running: false, phase: '', pct: 0, live: {}, result: null, wlan: undefined, history: null, error: '' };
const fmtN = (v) => (v == null ? '–' : String(v).replace('.', ','));
const PHASES = { wlan: 'WLAN wird geprüft …', ping: 'Ping wird gemessen …', down: 'Download wird gemessen …', up: 'Upload wird gemessen …', done: 'Fertig' };

function speedGauge(label, value, unit, active, color) {
  return `<div class="sp-g ${active ? 'on' : ''}" style="--c:${color}"><span>${label}</span><b>${value == null ? '–' : fmtN(value)}</b><small>${unit}</small></div>`;
}

function speedInner() {
  const r = speed.result;
  const live = speed.running ? speed.live : r || {};
  const w = speed.running ? speed.wlan : r?.wlan ?? speed.wlan;
  const sig = w?.signal || 0;
  const wlanLine = w === undefined ? '<span class="muted">WLAN wird gelesen …</span>' : !w ? '<span class="muted">WLAN-Daten nicht verfügbar</span>' : !w.connected ? '<span class="muted">Nicht per WLAN verbunden (Kabel?)</span>'
    : `<span class="sp-wifi" style="--s:${sig >= 65 ? '#4ade80' : sig >= 40 ? '#fbbf24' : '#f87171'}"><i class="${sig >= 25 ? 'a' : ''}"></i><i class="${sig >= 50 ? 'a' : ''}"></i><i class="${sig >= 75 ? 'a' : ''}"></i></span>
       <b>${esc(w.ssid || 'WLAN')}</b><span>${sig} % Signal</span>${w.band ? `<span>${esc(w.band)}</span>` : ''}${w.rx ? `<span>Funkrate ${fmtN(w.rx)} MBit/s</span>` : ''}`;
  const tips = r && !speed.running
    ? (r.tips.length ? r.tips.map((x) => `<div class="pc-issue sev${x.sev}"><b>${esc(x.title)}</b><p>${esc(x.text)}</p></div>`).join('') : `<div class="pc-issue ok"><b>Alles bestens</b><p>Signal, Ping und Geschwindigkeit sind gut – da bremst nichts.</p></div>`)
    : '';
  const hist = (speed.history || []).slice(0, 5);
  return `<div class="sp-top">
      <div class="sp-wlan">${wlanLine}</div>
      <button class="btn ${speed.running ? '' : 'primary'}" data-speed="run" ${speed.running ? 'disabled' : ''}>${speed.running ? '⏳ Läuft …' : r ? 'Nochmal testen' : 'Test starten'}</button>
    </div>
    <div class="sp-gauges">
      ${speedGauge('Download', live.down, 'MBit/s', speed.phase === 'down', '#38bdf8')}
      ${speedGauge('Upload', live.up, 'MBit/s', speed.phase === 'up', '#ff6b61')}
      ${speedGauge('Ping', live.ping, 'ms', speed.phase === 'ping', '#4ade80')}
    </div>
    ${speed.running ? `<div class="sp-prog"><div class="pc-mini" style="--c:#38bdf8"><i style="width:${Math.round(speed.pct)}%"></i></div><small>${esc(PHASES[speed.phase] || '')}</small></div>` : ''}
    ${speed.error ? `<div class="pc-issue sev3"><b>Test fehlgeschlagen</b><p>${esc(speed.error)}</p></div>` : ''}
    ${r && !speed.running ? `<div class="sp-grade">Ergebnis: <b>${esc(r.grade)}</b>${r.jitter != null ? ` · Schwankung ${r.jitter} ms` : ''}${r.loss ? ` · ${r.loss} % Verlust` : ''}</div>${tips}` : ''}
    ${hist.length > 1 && !speed.running ? `<div class="sp-hist"><span>Letzte Tests</span>${hist.map((h) => `<div><small>${new Date(h.at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</small><b>↓ ${fmtN(h.down)}</b><b>↑ ${fmtN(h.up)}</b><b>${h.ping} ms</b></div>`).join('')}</div>` : ''}
    <p class="muted sp-note">Getestet über speed.cloudflare.com, ca. 20 Sekunden. Bei langsamem WLAN werden nur wenige MB geladen.</p>`;
}

function speedPatch() {
  const el = $('#speed-box');
  if (el) el.innerHTML = speedInner();
}

function speedHtml() {
  if (speed.wlan === undefined && !speed.wlanLoading) {
    speed.wlanLoading = true;
    window.hub.speed?.wlan().then((w) => { speed.wlan = w || null; speedPatch(); }).catch(() => { speed.wlan = null; speedPatch(); });
    window.hub.speed?.history().then((h) => { speed.history = h; speedPatch(); }).catch(() => {});
  }
  return `<div class="section"><h4>Internet & WLAN</h4><div class="panel sp-panel" id="speed-box">${speedInner()}</div></div>`;
}

window.hub.onSpeed?.((p) => {
  speed.phase = p.phase;
  speed.pct = p.pct;
  if (p.phase === 'ping' && p.value != null) speed.live.ping = Math.round(p.value);
  if (p.phase === 'down' && p.value != null) speed.live.down = p.value;
  if (p.phase === 'up' && p.value != null) speed.live.up = p.value;
  speedPatch();
});

document.addEventListener('click', async (event) => {
  if (!event.target.closest?.('[data-speed="run"]') || speed.running) return;
  speed.running = true;
  speed.error = '';
  speed.live = {};
  speed.phase = 'wlan';
  speed.pct = 0;
  speedPatch();
  try {
    const r = await window.hub.speed.run();
    speed.result = r;
    speed.wlan = r.wlan ?? speed.wlan;
    speed.history = [{ at: r.at, down: r.down, up: r.up, ping: r.ping }, ...(speed.history || [])].slice(0, 10);
    sound.play('success');
  } catch (error) {
    speed.error = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  }
  speed.running = false;
  speed.phase = '';
  speedPatch();
});

/** Startseite: Live-Systemkarte (ersetzt den System-Tab). Klick öffnet die große Ansicht. */
function homeSysRows() {
  const l = pcLive;
  const p = pcInfo;
  if (!l) return [];
  const sys = l.disks.find((d) => d.d === 'C:') || l.disks[0];
  const diskPct = sys ? 100 - (sys.free / sys.size) * 100 : null;
  return [
    ['CPU', l.cpu, p ? p.cpu.replace(/\(R\)|\(TM\)|CPU|Processor|@.*$/gi, '').replace(/\s+/g, ' ').trim() : ''],
    ['RAM', l.ramPct, `${fmtN(l.ramUsed)} / ${fmtN(l.ramTotal)} GB`],
    ['GPU', l.gpu, p?.gpu?.name || ''],
    [`Laufwerk ${sys?.d || ''}`, diskPct, sys ? `${Math.round(sys.free / 1024 ** 3)} GB frei` : ''],
  ];
}
function homeSysSide() {
  const l = pcLive;
  if (!l) return '';
  const top = l.procs.slice(0, 3);
  return `<div class="pc-verdict ${l.verdict.ok ? 'ok' : 'bad'}">${icon(l.verdict.ok ? 'check' : 'alert', 15)}<span>${esc(l.verdict.text)}</span></div>
    ${top.length ? `<div class="hs-procs">${top.map((x) => `<div><span>${esc(x.n)}</span><b>${fmtN(Math.round(x.c * 10) / 10)} %</b></div>`).join('')}</div>` : ''}`;
}
function homeSysInner() {
  const l = pcLive;
  if (!l) return `<div class="hs-wait">${icon('cpu', 18)} Systemwerte werden gemessen …</div>`;
  return `<div class="hs-stats">${homeSysRows()
    .map(([n, v, d]) => `<div class="hs-stat" style="--c:${pcCol(v)}"><div class="hs-row"><span>${n}</span><b>${v == null ? '–' : `${Math.round(v)}<i>%</i>`}</b></div><div class="pc-mini"><i style="width:${Math.max(2, Math.min(100, v || 0))}%"></i></div><small>${esc(d)}</small></div>`)
    .join('')}</div>
    <div class="hs-side">${homeSysSide()}</div>`;
}

function homeSysHtml() {
  if (!pcInfo && !pcLoading) {
    pcLoading = true;
    window.hub.pcInfo?.().then((r) => { pcInfo = r; pcPatch(); }).catch(() => {});
  }
  refreshPcLive();
  return `<div class="card home-sys home-sys-cell" data-pc-open="1" title="Klicken für Details">
    <div class="hs-title">${icon('cpu', 16)}<b>System live</b></div>
    <div id="home-sys">${homeSysInner()}</div><span class="pc-expand">${icon('maximize', 16)}</span></div>`;
}

function pcPatch() {
  const home = $('#home-sys');
  if (!home || !pcLive) return;
  const stats = home.querySelectorAll('.hs-stat');
  const rows = homeSysRows();
  if (stats.length !== rows.length) {
    morph(home, homeSysInner());
    return;
  }
  // Werte direkt in die vorhandenen Karten schreiben – kein Neuaufbau, damit
  // die Balken nicht bei jeder Messung neu einblenden und nichts flackert.
  rows.forEach(([name, value, detail], i) => {
    const card = stats[i];
    card.style.setProperty('--c', pcCol(value));
    const label = card.querySelector('.hs-row span');
    const num = card.querySelector('.hs-row b');
    const bar = card.querySelector('.pc-mini i');
    const small = card.querySelector('small');
    if (label) label.textContent = name;
    if (num) num.innerHTML = value == null ? '–' : `${Math.round(value)}<i>%</i>`;
    if (bar) bar.style.width = `${Math.max(2, Math.min(100, value || 0))}%`;
    if (small) small.textContent = detail;
  });
  const side = home.querySelector('.hs-side');
  if (side) morph(side, homeSysSide());
}

function pcHtml() {
  if (!pcInfo) {
    if (!pcLoading) {
      pcLoading = true;
      window.hub.pcInfo?.().then((r) => {
        pcInfo = r;
        if (state.active === 'settings') render();
      }).catch(() => {});
    }
    return `<div class="section"><h4>Dein PC</h4><div class="panel"><div class="list-row"><div class="grow"><strong>PC-Stärke wird gemessen …</strong></div></div></div></div>`;
  }
  const p = pcInfo;
  const hue = 10 + p.level * 12;
  refreshPcLive();
  return `<div class="section"><h4>Dein PC</h4><div class="panel pc-panel" data-pc-open="1" title="Klicken für Details">
    <div class="pc-level" style="--h:${hue}"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" class="trk"/><circle cx="60" cy="60" r="50" class="val" style="stroke-dasharray:${(p.level / 10) * 314} 314"/></svg><div><b>${p.level}</b><span>von 10</span></div></div>
    <div class="pc-info"><strong>PC-Stärke: ${esc(p.label)}</strong><small>${esc(p.cpu)} · ${String(p.ram).replace('.', ',')} GB RAM${p.gpu ? ` · ${esc(p.gpu.name)}` : ''}</small>
      <div id="pc-live">${pcStatsHtml()}${pcVerdictHtml()}</div>
    </div>
    <span class="pc-expand">${icon('maximize', 16)}</span>
  </div></div>`;
}

/* ------------------------------------------------------------------ Updates */
const upd = { busy: false, result: null, step: '', pct: 0, err: '' };
const UPD_STEPS = { download: 'Wird geladen …', unpack: 'Wird entpackt …', install: 'Wird eingespielt …', restart: 'Fertig – der Hub startet neu …' };
function updateHtml() {
  const s = state.settings;
  const r = upd.result;
  const line = upd.step ? `${UPD_STEPS[upd.step] || ''}${upd.step === 'download' && upd.pct ? ` ${upd.pct} %` : ''}` : upd.err ? upd.err : !r ? 'Noch nicht gesucht.' : !r.ok ? r.error : r.available ? `Version ${r.version} ist verfügbar.${r.notes ? ` Neu: ${r.notes}` : ''}` : `Du hast die neueste Version (${r.current}).`;
  return `<div class="section"><h4>Updates</h4><div class="panel">
    ${settingRow('updateAuto', 'Beim Start nach Updates suchen', 'Meldet sich, wenn eine neue Version bereitliegt.', s.updateAuto !== false)}
    <div class="list-row"><div class="grow"><strong>Version ${esc(state.version)}</strong><small class="${upd.err || (r && !r.ok) ? 'err' : ''}">${esc(line)}</small></div>
      <button class="btn small ghost" data-news="show">Was ist neu?</button>
      <button class="btn small ghost" data-welcome="reset">Willkommen zeigen</button>
      <button class="btn small" data-upd="check" ${upd.busy ? 'disabled' : ''}>${upd.busy && !upd.step ? 'Suche …' : 'Nach Updates suchen'}</button>
      ${r?.ok && r.available ? `<button class="btn small primary" data-upd="install" ${upd.busy ? 'disabled' : ''}>Jetzt einspielen</button>` : ''}</div>
  </div></div>`;
}
/* Update-Leiste unten: erscheint, wenn eine neue Version bereitliegt */
let upAvail = null;
function renderUpbar() {
  const bar = $('#upbar');
  if (!bar) return;
  // Liegt das Dock als eigene Ebene oben, zeigt es das Update-Popup selbst
  const show = upAvail && !upAvail.dismissed && upAvail.version !== state?.version && !state?.dockExternal;
  bar.hidden = !show;
  if (!show) return;
  const step = upd.step ? (UPD_STEPS[upd.step] || '') + (upd.step === 'download' && upd.pct ? ` ${upd.pct} %` : '') : '';
  bar.innerHTML = `<span class="up-ic">${icon('download', 18)}</span><div class="up-txt"><b>Update ${esc(upAvail.version)} ist da</b><small>${esc(step || upd.err || upAvail.notes || 'Neue Funktionen und Fehlerbehebungen.')}</small></div>
    <button class="btn small primary" data-upbar="go" ${upd.busy ? 'disabled' : ''}>${upd.busy ? (upd.step === 'download' && upd.pct ? `${upd.pct} %` : 'Läuft …') : 'Aktualisieren'}</button><button class="btn small ghost" data-upbar="hide">Ausblenden</button>`;
}
window.hub.onUpdateAvailable?.((u) => {
  upAvail = u;
  upd.result = { ok: true, available: true, version: u.version, notes: u.notes, current: state?.version };
  renderUpbar();
});
window.hub.update?.pending().then((u) => {
  if (u) {
    upAvail = u;
    renderUpbar();
  }
}).catch(() => {});
document.addEventListener('click', async (e) => {
  const a = e.target.closest?.('[data-upbar]')?.dataset.upbar;
  if (!a) return;
  if (a === 'hide') {
    upAvail.dismissed = true;
    window.hub.update.dismiss(upAvail.version).catch(() => {});
    return renderUpbar();
  }
  upd.busy = true;
  upd.err = '';
  renderUpbar();
  try {
    await window.hub.update.check();
    await window.hub.update.install();
  } catch (error) {
    upd.err = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    upd.step = '';
  }
  upd.busy = false;
  renderUpbar();
});
window.hub.onUpdate?.((p) => {
  upd.step = p.step;
  upd.pct = p.pct;
  renderUpbar();
  if (state?.active === 'settings') render();
});
document.addEventListener('click', async (e) => {
  const a = e.target.closest?.('[data-upd]')?.dataset.upd;
  if (!a) return;
  upd.busy = true;
  upd.err = '';
  render();
  try {
    if (a === 'check') upd.result = await window.hub.update.check();
    if (a === 'install') await window.hub.update.install();
  } catch (error) {
    upd.err = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    upd.step = '';
  }
  upd.busy = false;
  render();
});

function pageSettings() {
  const s = state.settings;
  return `<div class="page">
    <div class="hero"><div><span class="eyebrow">Optionen</span><h2>Einstellungen</h2><p>So sieht der Revulution Hub aus und so verhält er sich. Die Einstellungen der einzelnen Apps findest du in ihrem jeweiligen Bereich.</p></div></div>

    <div class="section"><h4>Profil</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Revulution Hub-Konto</strong><small>Anmelden, damit Elo, Punkte und Cosmetics auf jedem PC gleich sind.</small></div><button class="btn small primary" data-open="tool-account">Konto & Sync</button></div>
      <div class="list-row"><div class="grow"><strong>Anzeigename</strong><small>Gilt überall gleich: Schach, Geo, Chats und Ranglisten.</small></div>
        <div class="name-edit"><input class="input" id="hub-name" maxlength="16" value="${esc(profile?.name || '')}" placeholder="Dein Name" /><button class="btn small primary" data-save-name="1">Speichern</button></div></div>
    </div></div>

    <div class="section"><h4>Desktop</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Desktop anpassen</strong><small>Hintergrund mit Blur, Revulution-Leiste und Widgets – alles direkt mit Vorschau.</small></div><button class="btn small primary" data-open="tool-desktop">${icon('palette', 15)} Anpassen</button></div>
      <div class="list-row"><div class="grow"><strong>Hintergrund weichzeichnen</strong><small>Der Desktop hinter dem Hub wird weich und ruhig – Stärke und Abdunkelung stellst du in „Desktop“ ein.</small></div><button class="switch ${s.backdropBlur !== false ? 'on' : ''}" data-setting="backdropBlur"></button></div>
    </div></div>

    <div class="section"><h4>Windows</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Taskleiste</strong><small>Die Revulution-Leiste (ersetzt die Windows-Taskleiste) und ihre Transparenz stellst du jetzt in der Desktop-App ein. Aktuell: ${s.replaceTaskbar ? 'Revulution-Leiste' : 'Windows-Taskleiste'}.</small></div><button class="btn small primary" data-desk-goto-taskbar>${icon('layers', 15)} In Desktop öffnen</button></div>
      <div class="list-row"><div class="grow"><strong>Alle Monitore</strong><small>Auf jedem Monitor erscheint dieselbe transparente Leiste. Auf dem Monitor mit dem aktiven Hub übernimmt der Hub selbst.</small></div><span class="tb-ok">${icon('check', 13)} synchron</span></div>
      <div class="list-row"><div class="grow"><strong>Windows-Startmenü</strong><small>Öffnet das Startmenü, auch wenn die Taskleiste ausgeblendet ist.</small></div><button class="btn small" data-taskbar-start>Startmenü öffnen</button></div>
    </div></div>

    <div class="section"><h4>Obere Leiste</h4><div class="panel">
      ${[['crosshair', 'Crosshair', 'Ein kleines Fadenkreuz mittig auf dem Hauptmonitor – standardmäßig aus.'], ['screentime', 'Bildschirmzeit', 'Öffnet die Bildschirmzeit direkt aus der Leiste.'], ['speed', 'WLAN-Test', 'Öffnet den Speedtest direkt aus der Leiste.'], ['settings', 'Einstellungen', 'Ein zusätzlicher Zahnrad-Knopf in der Leiste.']]
        .map(([id, name, hint]) => `<div class="list-row"><div class="grow"><strong>${name}</strong><small>${hint}</small></div><button class="switch ${(s.topbarItems || ['crosshair']).includes(id) ? 'on' : ''}" data-topbar-toggle="${id}" aria-label="${name} in der Leiste"></button></div>`)
        .join('')}
      <div class="list-row"><div class="grow"><strong>Position</strong><small>Die Elemente sitzen rechts in der oberen Desktop-Leiste.</small></div><span class="muted">Oben rechts</span></div>
    </div></div>

    <div class="section"><h4>App-Leiste (Dock)</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Position</strong><small>Wo die App-Leiste schwebt.</small></div>
        <div class="seg">${[['bottom', 'Unten'], ['top', 'Oben'], ['left', 'Links'], ['right', 'Rechts']].map(([v, n]) => `<button class="${dockCfg().pos === v ? 'on' : ''}" data-dock-pos="${v}">${n}</button>`).join('')}</div></div>
      <div class="list-row"><div class="grow"><strong>Größe</strong></div>
        <div class="seg">${[['s', 'Klein'], ['m', 'Mittel'], ['l', 'Groß']].map(([v, n]) => `<button class="${dockCfg().size === v ? 'on' : ''}" data-dock-size="${v}">${n}</button>`).join('')}</div></div>
      <div class="list-row"><div class="grow"><strong>Vergrößern beim Drüberfahren</strong><small>Wie beim Mac.</small></div><button class="switch ${dockCfg().magnify ? 'on' : ''}" data-dock-magnify="1"></button></div>
      <div class="list-row"><div class="grow"><strong>Apps im Dock</strong><small>Hinzufügen und entfernen im Starter („Alle Apps“), Reihenfolge per Ziehen.</small></div><button class="btn small" data-dock-special="launcher">Alle Apps</button><button class="btn small ghost" data-dock-reset="1">Standard</button></div>
    </div></div>

    ${pcHtml()}

    ${speedHtml()}

    <div class="section"><h4>Sprache</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Sprache</strong><small>Für den ganzen Hub und alle Apps – Deutsch, English, Español.</small></div>
        <div class="segmented">${[['de', 'Deutsch'], ['en', 'English'], ['es', 'Español']].map(([k, n]) => `<button class="${(s.lang || state.lang) === k ? 'on' : ''}" data-lang="${k}">${n}</button>`).join('')}</div></div>
    </div></div>

    <div class="section"><h4>Design</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Aussehen</strong><small>„Pro“ (Standard) ist ruhig und kompakt wie Profi-Software (Foto, Video, 3D): neutrales Dunkelgrau, feine Linien, blaue Auswahl, gedämpfte App-Logos. „Liquid Glass“ ist das frühere Glas-Design. Gilt für den Hub und alle Apps.</small></div>
        <div class="segmented">${[['pro', 'Pro'], ['standard', 'Liquid Glass']].map(([k, n]) => `<button class="${(s.design === 'standard' ? 'standard' : 'pro') === k ? 'on' : ''}" data-design="${k}">${n}</button>`).join('')}</div></div>
      <div class="list-row"><div class="grow"><strong>Design-Auswahl nach Updates</strong><small>${s.designPickerOff ? 'Ausgeschaltet – der Knopf öffnet die Auswahl und fragt künftig wieder.' : 'Nach jedem Update erscheint kurz die Auswahl mit Live-Vorschau.'}</small></div><button class="btn small" data-dp-open>Auswahl öffnen</button></div>
    </div></div>

    <div class="section"><h4>Liquid Glass</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Deckkraft des Glases</strong><small>Links ganz durchsichtig, rechts mehr wie mattes Glas – gilt für Karten, Leisten und Pop-ups.</small></div>
        <div class="range"><input type="range" min="0" max="0.85" step="0.05" value="${s.glassOpacity ?? 0.12}" data-range="glassOpacity" /><output>${Math.round((s.glassOpacity ?? 0.12) * 100)} %</output></div></div>
    </div></div>

    <div class="section"><h4>Hintergrund-Schnellwechsler</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Gelikte Hintergründe per Tastenkürzel</strong><small>Zeigt deine gelikten Hintergründe schwebend in der Bildschirmmitte – Pfeiltasten wechseln, Esc schließt.</small></div><button class="switch ${s.wpSwitch?.enabled ? 'on' : ''}" data-wpswitch></button></div>
      <div class="list-row"><div class="grow"><strong>Tastenkürzel</strong><small>z. B. Control+T, Alt+W oder Control+Shift+B</small></div><input class="input" style="width:170px" data-wpswitch-key value="${esc(s.wpSwitch?.key || 'Control+T')}" /></div>
    </div></div>

    <div class="section"><h4>Mauszeiger</h4><div class="panel">
      <div class="list-row"><div class="grow"><strong>Revulution-Mauszeiger für ganz Windows</strong><small>Der schlanke Apple-Pfeil überall auf dem PC – dann wechselt der Zeiger auch nicht mehr zwischen Hub und anderen Fenstern. Ausschalten stellt deine alten Zeiger wieder her.</small></div><button class="switch ${s.systemCursor ? 'on' : ''}" data-sys-cursor></button></div>
    </div></div>

    <div class="section"><h4>Klicksounds</h4><div class="panel">
      ${settingRow('sounds', 'Klicksounds', 'Ein Klick bei Knöpfen und Schaltern – in allen Bereichen gleich.', s.sounds)}
      ${settingRow('muteWinNotify', 'Windows-Ton bei Meldungen aus', 'Nur noch der Ton der Island – kein doppelter Klang mehr bei neuen Nachrichten.', s.muteWinNotify !== false)}
      <div class="list-row"><div class="grow"><strong>Klang</strong><small>Dezenter Klick oder der „Killer Queen“-Auslöser.</small></div>
        <div class="seg">${[['nothing', 'Revulution'], ['classic', 'Synth'], ['kq', 'Killer Queen']].map(([v, n]) => `<button class="${(s.clickSound || 'nothing') === v ? 'on' : ''}" data-click-style="${v}">${n}</button>`).join('')}</div></div>
      <div class="list-row"><div class="grow"><strong>Lautstärke</strong><small>Gilt für alle Klicksounds im Hub.</small></div>
        <div class="range"><input type="range" min="0.05" max="1" step="0.05" value="${s.soundVolume}" data-range="soundVolume" /><output>${Math.round(s.soundVolume * 100)} %</output></div></div>
    </div></div>

    <div class="section"><h4>Start & Verhalten</h4><div class="panel">
      ${settingRow('autoStart', 'Mit Windows starten', 'Der Hub startet unsichtbar im Infobereich – Crosshair, Screenshot-Hotkey und Revulution Island sind sofort da.', s.autoStart)}
      ${settingRow('closeToTray', 'Beim Schließen im Infobereich bleiben', 'Das Fenster verschwindet, Overlays, Hotkeys und Island laufen weiter. Beenden über das Tray-Symbol.', s.closeToTray)}
      ${settingRow('orbitWithHub', 'Revulution Island mitstarten', 'Startet die Dynamic Island zusammen mit dem Hub.', s.orbitWithHub)}
      ${settingRow('homeScrollReset', 'Startseite merkt sich die Position', 'Wenn du aus einer App zurückkommst, landest du wieder dort, wo du warst (z. B. unten bei den Apps). Aus = immer ganz oben.', s.homeScrollReset !== true)}
      <div class="list-row"><div class="grow"><strong>Standort automatisch ermitteln</strong><small>Für das Wetter: Windows-Standortdienst, sonst grob über die Internetverbindung. ${s.weatherAuto && s.weatherCity?.name ? `Zuletzt: ${esc(s.weatherCity.name)}.` : ''}</small></div><button class="btn small ghost" data-loc-now>Jetzt ermitteln</button><button class="switch ${s.autoLocation ? 'on' : ''}" data-loc-toggle aria-pressed="${Boolean(s.autoLocation)}"></button></div>
      <div class="list-row"><div class="grow"><strong>Startseite</strong><small>Was beim Öffnen des Hubs angezeigt wird.</small></div>
        <div class="segmented"><button class="${s.startPage === 'home' ? 'on' : ''}" data-start="home">Start</button><button class="${s.startPage === 'last' ? 'on' : ''}" data-start="last">Zuletzt geöffnet</button></div></div>
    </div></div>

    ${updateHtml()}

    <div class="section"><h4>Daten</h4><div class="panel">
      ${['hub', 'gaming', 'orbit', 'screenshot', 'docs', 'chess', 'geo']
        .map((id) => `<div class="list-row"><div class="grow"><strong>${esc(FRIENDLY[id])}</strong><small>Einstellungen und Daten bleiben beim Aktualisieren erhalten.</small></div><button class="btn small" data-data="${id}">${icon('folder', 15)} Ordner öffnen</button></div>`)
        .join('')}
    </div></div>

    <div class="section"><h4>Über</h4><div class="panel kv">
      <span>Revulution Hub</span><b>${esc(state.version)}</b>
      ${state.modules.filter((mod) => mod.id !== 'dropzone').map((mod) => `<span>${esc(FRIENDLY[mod.id] || mod.name)}</span><b>${esc(mod.version)}${mod.error ? ' – Fehler' : ''}</b>`).join('')}
      <span>Revulution Island</span><b>${state.orbit.available ? '1.0.0' : 'nicht enthalten'}</b>
    </div></div>
  </div>`;
}

/* ------------------------------------------------------- obere Leiste: Aktionen */
let crosshairOn = false;
const TOPBAR_ITEMS = [
  ['crosshair', 'Crosshair', 'crosshair'],
  ['screentime', 'Bildschirmzeit', 'clock'],
  ['speed', 'WLAN-Test', 'globe'],
  ['settings', 'Einstellungen', 'settings'],
];
function renderTopActions() {
  // 2.45: runder Crosshair-Knopf neben Support/Einstellungen (im Gaming Hub einschaltbar)
  const xh = $('#top-xh');
  if (xh && state) {
    // 2.45.1: erst sichtbar, wenn das Crosshair einmal eingeschaltet wurde (im Gaming Hub abschaltbar)
    if (crosshairOn && !state.settings?.crosshairEverOn) {
      state.settings.crosshairEverOn = true;
      window.hub.setSettings({ crosshairEverOn: true }).catch(() => {});
    }
    xh.hidden = !state.settings?.crosshairEverOn || state.settings?.topCrosshair === false;
    xh.classList.toggle('on', crosshairOn);
    xh.title = crosshairOn ? 'Crosshair ausschalten' : 'Crosshair einschalten';
  }
  const host = $('#top-actions');
  if (!host || !state) return;
  const s = state.settings || {};
  const items = (s.topbarItems || ['crosshair']).map((k) => TOPBAR_ITEMS.find((x) => x[0] === k)).filter(Boolean);
  host.innerHTML = `${items
    .map(([id, label, ic]) =>
      id === 'crosshair'
        ? `<button class="top-act ${crosshairOn ? 'on' : ''}" data-top-crosshair title="Crosshair ${crosshairOn ? 'ausschalten' : 'einschalten'}">${icon('crosshair', 16)}</button>`
        : `<button class="top-act" data-open="${id === 'screentime' ? 'tool-screentime' : id === 'speed' ? 'tool-speed' : 'settings'}" title="${esc(label)}">${icon(ic, 16)}</button>`,
    )
    .join('')}
    <span class="top-add"><button class="top-act" data-top-add title="Elemente hinzufügen">${icon('plus', 16)}</button>
      <div class="top-menu" data-top-menu hidden>${TOPBAR_ITEMS.map(([id, label]) => `<button data-top-item="${id}" class="${items.some((x) => x[0] === id) ? 'on' : ''}"><i></i>${esc(label)}</button>`).join('')}<button data-top-item="__reset"><i></i>Standard</button></div>
    </span>`;
}
document.addEventListener('click', (event) => {
  const add = event.target.closest?.('[data-top-add]');
  if (add) {
    event.preventDefault();
    event.stopPropagation();
    const menu = $('[data-top-menu]');
    if (menu) menu.hidden = !menu.hidden;
    return;
  }
  const item = event.target.closest?.('[data-top-item]')?.dataset.topItem;
  if (item) {
    event.preventDefault();
    event.stopPropagation();
    const current = state.settings.topbarItems || ['crosshair'];
    const next = item === '__reset' ? ['crosshair'] : current.includes(item) ? current.filter((x) => x !== item) : [...current, item];
    run(() => window.hub.setSettings({ topbarItems: next }));
    return;
  }
  const cross = event.target.closest?.('[data-top-crosshair]');
  if (cross) {
    event.preventDefault();
    event.stopPropagation();
    const next = !crosshairOn;
    crosshairOn = next;
    state.settings.crosshairOn = next;
    renderTopActions();
    window.hub.crosshair?.set(next).then((r) => {
      crosshairOn = Boolean(r?.on ?? next);
      renderTopActions();
      toast(crosshairOn ? 'Crosshair ist an – mittig auf dem Hauptmonitor.' : 'Crosshair ist aus.');
    }).catch(() => {
      crosshairOn = !next;
      renderTopActions();
    });
    return;
  }
  if (!event.target.closest?.('.top-add')) $('[data-top-menu]')?.setAttribute('hidden', '');
});
document.addEventListener('click', (event) => {
  const fav = event.target.closest?.('[data-fav]');
  if (!fav) return;
  event.preventDefault();
  event.stopPropagation();
  const id = fav.dataset.fav;
  const current = state.settings.favoriteApps || [];
  const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
  run(() => window.hub.setSettings({ favoriteApps: next }), next.includes(id) ? 'Zu Favoriten hinzugefügt.' : 'Aus Favoriten entfernt.');
}, true);
window.hub.crosshair?.on?.((s) => {
  crosshairOn = Boolean(s?.on);
  if (state) state.settings.crosshairOn = crosshairOn;
  renderTopActions();
});
window.hub.crosshair?.state?.().then((s) => {
  crosshairOn = Boolean(s?.on);
  renderTopActions();
}).catch(() => {});
window.hub.onImmersive?.((on) => {
  document.body.classList.toggle('immersive', Boolean(on));
  if (!on) document.body.classList.remove('peek');
  squareCorners.full = Boolean(on);
  squareCorners();
});
/* Maximiert oder Vollbild: Windows zeichnet eckig – dann auch den Inhalt nicht mehr runden. */
function squareCorners() {
  document.documentElement.classList.toggle('square', Boolean(squareCorners.max || squareCorners.full));
}
// Ist der Hub nicht im Vordergrund, schaltet Windows das Acrylic-Glas ab – dann übernimmt
// der unscharfe Desktop, damit der Hub nie klar durchsichtig wirkt.
window.addEventListener('blur', () => document.body.classList.add('inactive'));
window.addEventListener('focus', () => document.body.classList.remove('inactive'));
window.hub.onGlass?.((g) => {
  if (!g) return;
  const r = document.documentElement.style;
  r.setProperty('--gx', `${-g.x}px`);
  r.setProperty('--gy', `${-g.y}px`);
  r.setProperty('--gw', `${g.w}px`);
  r.setProperty('--gh', `${g.h}px`);
});
let peekTimer = 0;
window.hub.onPeek?.(() => {
  document.body.classList.add('peek');
  clearTimeout(peekTimer);
  peekTimer = setTimeout(() => document.body.classList.remove('peek'), 2600);
});

/* ------------------------------------------------------------------- render */
/* ------------------------------------------------------------------ flimmerfreies Neuzeichnen */
/**
 * Statt bei jeder Aktualisierung den ganzen Bereich per innerHTML neu aufzubauen (das
 * blinkt: Bilder laden neu, Animationen starten neu), werden nur die Knoten geändert,
 * die sich wirklich unterscheiden.
 */
function morphAttrs(from, to) {
  const keepStyle = from.classList?.contains('dock-item');
  for (const { name } of [...from.attributes]) if (!to.hasAttribute(name) && !(keepStyle && name === 'style')) from.removeAttribute(name);
  for (const { name, value } of [...to.attributes]) if (from.getAttribute(name) !== value) from.setAttribute(name, value);
  if (from.tagName === 'INPUT' || from.tagName === 'TEXTAREA' || from.tagName === 'SELECT') {
    if (document.activeElement !== from) {
      if (from.type === 'checkbox' || from.type === 'radio') from.checked = to.hasAttribute('checked');
      else if (from.tagName === 'SELECT') {
        const sel = [...to.options].findIndex((o) => o.hasAttribute('selected'));
        if (sel >= 0 && from.selectedIndex !== sel) from.selectedIndex = sel;
      } else if (from.tagName === 'TEXTAREA') {
        if (from.value !== to.textContent) from.value = to.textContent;
      } else if (from.value !== (to.getAttribute('value') ?? '')) from.value = to.getAttribute('value') ?? '';
    }
  }
}

function sameKind(a, b) {
  if (a.nodeType !== b.nodeType) return false;
  if (a.nodeType !== 1) return true;
  return a.tagName === b.tagName && (a.id || '') === (b.id || '') && (a.dataset.key || '') === (b.dataset.key || '');
}

function morphChildren(from, to) {
  const next = [...to.childNodes];
  let cur = from.firstChild;
  for (const node of next) {
    if (cur && sameKind(cur, node)) {
      // 2.45: selbst verwaltete Bereiche der neuen Apps nicht anfassen
      if (cur.nodeType === 1 && cur.hasAttribute('data-morph-keep') && node.hasAttribute('data-morph-keep')) {
        cur = cur.nextSibling;
        continue;
      }
      if (cur.nodeType === 1) {
        morphAttrs(cur, node);
        if (cur.tagName !== 'TEXTAREA') morphChildren(cur, node);
      } else if (cur.nodeValue !== node.nodeValue) cur.nodeValue = node.nodeValue;
      cur = cur.nextSibling;
    } else {
      from.insertBefore(node, cur);
    }
  }
  while (cur) {
    const rest = cur.nextSibling;
    cur.remove();
    cur = rest;
  }
}

function morph(el, html) {
  const tpl = document.createElement('template');
  tpl.innerHTML = html;
  morphChildren(el, tpl.content);
}

/** Deckkraft des Glases (Einstellung): färbt alle Glasflächen leicht dunkel ein. */
function applyGlassOpacity(o) {
  const v = Math.max(0, Math.min(0.85, Number(o ?? 0.25)));
  document.documentElement.style.setProperty('--lg-fill', `rgba(24, 24, 28, ${v.toFixed(2)})`);
  document.documentElement.style.setProperty('--lg-b', `${(v * 16).toFixed(1)}px`);
}
function render() {
  if (!state) return;
  applyGlassOpacity(state.settings.glassOpacity ?? 0.12);
  topAccount();
  renderTopActions();

  renderNav();
  applyWallpaper();
  sound.configure({ enabled: state.settings.sounds, volume: state.settings.soundVolume, style: state.settings.clickSound || 'nothing' });
  if ((state.settings.clickSound || 'nothing') === 'nothing' && !render.packLoaded) {
    render.packLoaded = true;
    window.hub.clickPack?.().then((pack) => pack && sound.configure({ pack })).catch(() => {});
  }
  if (state.settings.clickSound === 'kq' && !render.clipLoaded) {
    render.clipLoaded = true;
    window.hub.clickClip?.().then((clip) => clip && sound.configure({ clip })).catch(() => {});
  }
  state.desktopBackdrop = backdropFile;
  const active = state.active;
  const meta = active === 'home' ? { title: 'Start', sub: 'Revulution Hub' } : active === 'settings' ? { title: 'Einstellungen', sub: 'Revulution Hub' } : active === 'shop' ? { title: 'Shop', sub: 'Cosmetics für Schach, Geo & Chats' } : active === 'gaming' && state.clipsMode && TOOLS['tool-clips'] ? TOOLS['tool-clips'] : TOOLS[active] || APPS[active] || { title: active, sub: '' };
  $('#page-title').textContent = meta.title;
  $('#page-sub').textContent = meta.sub;
  // 2.42: Titel als runde Pille – Klick zeigt die Beschreibung der App
  const pop = $('#page-pop');
  if (pop) {
    pop.innerHTML = `<b>${esc(meta.title)}</b>${meta.sub ? `<small>${esc(meta.sub)}</small>` : ''}${meta.desc ? `<p>${esc(meta.desc)}</p>` : ''}`;
    if (render.lastTitle !== active) pop.hidden = true;
    render.lastTitle = active;
  }
  $('#win-max').title = state.maximized ? 'Wiederherstellen' : 'Maximieren';
  squareCorners.max = Boolean(state.maximized);
  squareCorners();
  document.body.classList.toggle('module-open', MODULE_PAGES.has(active));

  const html =
    active === 'home' ? pageHome() : active === 'orbit' ? window.OrbitPage.html(state) : active === 'settings' ? pageSettings() : active === 'shop' ? pageShop() : TOOLS[active] ? window.HubTools.html(active) : pageModule(active);
  const content = $('#content');
  const body = content.querySelector('.set-body');
  // 2.46: Startseite merkt sich beim Wechsel in eine App die Position (z. B. unten bei den Apps) und
  // springt beim Zurückkommen wieder dorthin – abschaltbar in den Einstellungen („Start & Verhalten“).
  if (page === 'home' && active !== 'home') render.homeScroll = content.scrollTop;
  const back = page !== active && active === 'home' && state.settings?.homeScrollReset !== true ? render.homeScroll || 0 : 0;
  const scroll = page === active ? content.scrollTop : back;
  const innerScroll = page === active && body ? body.scrollTop : 0;
  if (page === active) {
    // Gleiche Seite: nur ändern, was anders ist – kein Blinken, keine neue Einblend-Animation
    morph(content, html.replace(/^(\s*<div class=")(page|set-page)/, '$1$2 still'));
    content.querySelector('.page')?.classList.add('still');
  } else {
    // 2.37: ohne Einblend-Animation – sie wirkte wie ein Neuladen (alles blinkte einmal)
    content.innerHTML = html;
  }
  content.scrollTop = scroll;
  const nextBody = content.querySelector('.set-body');
  if (nextBody) nextBody.scrollTop = innerScroll;
  // 2.46 Revolution Store: noch nicht offen – grauer Schleier mit „Coming Soon“ über der ganzen Seite
  if (active === 'tool-store' && false) { // 2.48.1: Shop ist wieder betretbar – Kaufen meldet „geschlossen“
    const pg = content.querySelector('.tool-page, .page');
    if (pg && !pg.querySelector(':scope > .cs-veil')) {
      pg.classList.add('cs-host');
      pg.insertAdjacentHTML('beforeend', `<div class="cs-veil" aria-live="polite"><div class="cs-card"><div class="cs-ic"><svg viewBox="0 0 24 24"><path d="M6 8h12l-1 12H7Z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/></svg></div><h2 class="cs-title">Coming Soon</h2><p class="cs-sub">Der Revolution Store mit Designs, Widgets, GIFs und mehr ist gleich fertig. Bis dahin ist hier noch geschlossen.</p><span class="cs-pill"><i></i>In Arbeit</span></div></div>`);
    }
  }
  page = active;
  if (overlay) renderOverlay();
}

/* ------------------------------------------------------------------- events */
window.OrbitPage.bind($('#content'), render, toast);

document.addEventListener('click', async (event) => {
  const target = event.target.closest('button, [data-open]');
  if (!target) return;
  // 2.46 Kalender: Quick-Add (+) und Tag anklicken → Termin für diesen Tag
  if (target.matches('[data-rc-add]')) { event.stopPropagation(); return window.RevCal?.open(target); }
  const rcDay = event.target.closest('.w3-cal [data-rc-day]');
  if (rcDay) { const n = new Date(); return window.RevCal?.open(target.querySelector('[data-rc-add]') || rcDay, { date: new Date(n.getFullYear(), n.getMonth(), Number(rcDay.dataset.rcDay)) }); }

  if (target.dataset.win) return window.hub.window(target.dataset.win);
  if (target.dataset.open) {
    if (target.dataset.open === 'orbit') window.OrbitPage.load(true).then(render);
    return window.hub.open(target.dataset.open);
  }
  if (target.dataset.setting) {
    const key = target.dataset.setting;
    return run(() => window.hub.setSettings({ [key]: !state.settings[key] }));
  }
  if (target.dataset.topbarToggle) {
    const id = target.dataset.topbarToggle;
    const current = state.settings.topbarItems || ['crosshair'];
    const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
    return run(() => window.hub.setSettings({ topbarItems: next }), next.includes(id) ? 'In die obere Leiste gelegt.' : 'Aus der oberen Leiste entfernt.');
  }
  if (target.dataset.wall) return run(() => window.hub.setSettings({ wallpaper: target.dataset.wall }));
  if (target.dataset.start) return run(() => window.hub.setSettings({ startPage: target.dataset.start }));
  if (target.dataset.lang) return run(() => window.hub.setSettings({ lang: target.dataset.lang }));
  if (target.matches?.('[data-dp-open]')) { if (state.settings?.designPickerOff) window.hub.setSettings({ designPickerOff: false }).catch(() => {}); return showDesignPicker(); }
  if (target.dataset.design) { // Runde 11b: Design sofort umschalten, dann speichern (Hauptprozess verteilt es an alle Fenster)
    const d = target.dataset.design === 'pro' ? 'pro' : 'standard';
    try { localStorage.setItem('rh-design', d); } catch {}
    document.documentElement.toggleAttribute('data-theme', d === 'pro');
    if (d === 'pro') document.documentElement.setAttribute('data-theme', 'pro');
    return run(() => window.hub.setSettings({ design: d }));
  }
  if (target.dataset.data) return window.hub.openData(target.dataset.data);
  if (target.id === 'orbit-start') return run(() => window.hub.orbit.start(), 'Revulution Island wird gestartet …');
  if (target.id === 'orbit-stop') return run(() => window.hub.orbit.stop(), 'Revulution Island beendet.');
});

let rangeTimer = null;
document.addEventListener('input', (event) => {
  const el = event.target;
  if (!el.dataset.range) return;
  const value = Number(el.value);
  el.parentElement.querySelector('output').textContent = `${Math.round(value * 100)} %`;
  if (el.dataset.range === 'wallpaperDim') $('#wall-shade').style.opacity = String(value);
  if (el.dataset.range === 'glassOpacity') applyGlassOpacity(value);
  if (el.dataset.range === 'soundVolume') {
    sound.configure({ volume: value });
    sound.play('tap');
  }
  clearTimeout(rangeTimer);
  rangeTimer = setTimeout(() => window.hub.setSettings({ [el.dataset.range]: value }), 200);
});

document.addEventListener('click', (event) => {
  if (!event.target.closest?.('[data-wpswitch]')) return;
  const cur = state.settings.wpSwitch || {};
  run(() => window.hub.setSettings({ wpSwitch: { enabled: !cur.enabled, key: cur.key || 'Control+T' } }), !cur.enabled ? `Schnellwechsler an: ${cur.key || 'Control+T'}` : 'Schnellwechsler aus.');
});
document.addEventListener('change', (event) => {
  if (!event.target.matches?.('[data-wpswitch-key]')) return;
  const cur = state.settings.wpSwitch || {};
  run(() => window.hub.setSettings({ wpSwitch: { enabled: Boolean(cur.enabled), key: event.target.value.trim() || 'Control+T' } }), 'Tastenkürzel gespeichert.');
});
document.addEventListener('click', (event) => {
  if (!event.target.closest?.('[data-sys-cursor]')) return;
  const on = !state.settings.systemCursor;
  run(() => window.hub.systemCursor(on), on ? 'Revulution-Mauszeiger ist jetzt überall aktiv.' : 'Deine alten Mauszeiger sind zurück.').then(() => render());
});
document.addEventListener('dblclick', (event) => {
  if (event.target.closest('.topbar') && !event.target.closest('.win')) window.hub.window('maximize');
});

window.hub.onProfile?.((p) => setProfile(p));
window.hub.profile?.get().then((p) => setProfile(p)).catch(() => {});
document.addEventListener('click', (event) => {
  if (!event.target.closest?.('[data-save-name]')) return;
  const v = ($('#hub-name')?.value || '').trim();
  if (v.length < 2) return toast('Mindestens 2 Zeichen.', 'error');
  run(() => window.hub.profile.name(v), 'Name gespeichert – gilt in allen Apps.').then((p) => p && setProfile(p));
});

window.hub.onState((next) => {
  const wasOrbit = state?.active === 'orbit';
  if (next.lang && next.lang !== window.RevTranslate?.lang) window.RevTranslate?.set(next.lang);
  state = next;
  if (next.active === 'orbit' && !wasOrbit) window.OrbitPage.load(true).then(render);
  // Do not wipe what the user is typing in the island editor.
  if (next.active === 'orbit' && wasOrbit && document.activeElement?.closest?.('.set-body')) {
    renderNav();
    return;
  }
  render();
});

window.hub.state().then((initial) => {
  state = initial;
  window.RevTranslate?.set(initial.lang || "de");
  render();
  loadBackdrop();
  maybeShowNews();
  if (initial.active === 'orbit') window.OrbitPage.load(true).then(render);
});
setInterval(() => loadBackdrop(), 12000);

/* Dock-Einstellungen */
document.addEventListener('click', (e) => {
  // Nur Knöpfe – <body> trägt selbst data-dock / data-dock-size fürs Layout
  const p = e.target.closest?.('button[data-dock-pos]');
  if (p) return run(() => window.hub.setSettings({ dock: { pos: p.dataset.dockPos } }));
  const z = e.target.closest?.('button[data-dock-size]');
  if (z) return run(() => window.hub.setSettings({ dock: { size: z.dataset.dockSize } }));
  if (e.target.closest?.('[data-dock-magnify]')) return run(() => window.hub.setSettings({ dock: { magnify: !dockCfg().magnify } }));
  if (e.target.closest?.('[data-dock-reset]')) return saveDock([...DEFAULT_DOCK]);
  const tb = e.target.closest?.('[data-taskbar-replace]');
  if (tb) return run(() => window.hub.taskbar.replace(tb.dataset.taskbarReplace === 'on'), tb.dataset.taskbarReplace === 'on' ? 'Revulution-Leiste übernimmt – die Windows-Taskleiste ist aus.' : 'Windows-Taskleiste ist wieder da.');
  if (e.target.closest?.('[data-taskbar-start]')) return window.hub.taskbar.start().catch(() => {});
  const cs = e.target.closest?.('[data-click-style]');
  if (cs) return run(() => window.hub.setSettings({ clickSound: cs.dataset.clickStyle })).then(() => setTimeout(() => sound.play('tap'), 250));
});
setTimeout(() => window.HubTools?.weatherCheck?.(), 8000);
window.HubTools?.init({ state: () => state, render: () => render(), toast: (m, k) => toast(m, k), settings: (patch) => run(() => window.hub.setSettings(patch)), profile: () => profile });

/* 2.45 Standort fürs Wetter: Frage auf der Startseite, Schalter + „Jetzt ermitteln“ in den Einstellungen */
async function locateNow(quiet = false) {
  try {
    const r = await window.hub.geo.locate();
    if (!quiet) toast(r.source === 'windows' ? `Standort: ${r.name}` : `Standort (ungefähr, über die Internetverbindung): ${r.name}`);
    if (r.denied) toast('Windows erlaubt Desktop-Apps keinen Standortzugriff – darum nur ungefähr. Unter Einstellungen → Datenschutz → Standort kannst du es erlauben.', 'error');
  } catch (e) {
    toast(String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
    if (/Windows erlaubt/.test(String(e?.message))) window.hub.geo.windowsSettings();
  }
}
document.addEventListener('click', (e) => {
  const ask = e.target.closest?.('[data-loc-ask]')?.dataset.locAsk;
  if (ask) {
    e.stopPropagation();
    run(() => window.hub.setSettings({ autoLocation: ask === 'yes' })).then(() => ask === 'yes' && locateNow());
    return;
  }
  if (e.target.closest?.('[data-loc-toggle]')) {
    e.stopPropagation();
    const on = !state.settings.autoLocation;
    run(() => window.hub.setSettings({ autoLocation: on })).then(() => on && locateNow());
    return;
  }
  if (e.target.closest?.('[data-loc-now]')) {
    e.stopPropagation();
    locateNow();
  }
});

/* 2.42: Klick auf den Titel oben öffnet/schließt die Beschreibung */
document.addEventListener('click', (e) => {
  const pop = document.getElementById('page-pop');
  if (!pop) return;
  if (e.target.closest('#page-title')) {
    pop.hidden = !pop.hidden;
    return;
  }
  if (!e.target.closest('#page-pop')) pop.hidden = true;
});
