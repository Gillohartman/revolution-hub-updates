'use strict';

/*
 * Desktop-Hintergrund setzen – auf allen, ausgewählten Monitoren oder über alle gestreckt.
 * Nutzt die Windows-Schnittstelle IDesktopWallpaper (pro Monitor). Windows setzt ein neues Bild
 * gern wieder zurück (Spotlight, Diashow) – deshalb Registry festnageln und kurz nachfassen.
 */
const { execFile } = require('child_process');

const CS = `
using System;
using System.Runtime.InteropServices;
[StructLayout(LayoutKind.Sequential)] public struct RevRect { public int Left, Top, Right, Bottom; }
[ComImport, Guid("B92B56A9-8B55-4E14-9A89-0199BBB6F93B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IRevDesktopWallpaper {
  void SetWallpaper([MarshalAs(UnmanagedType.LPWStr)] string monitorID, [MarshalAs(UnmanagedType.LPWStr)] string wallpaper);
  [return: MarshalAs(UnmanagedType.LPWStr)] string GetWallpaper([MarshalAs(UnmanagedType.LPWStr)] string monitorID);
  [return: MarshalAs(UnmanagedType.LPWStr)] string GetMonitorDevicePathAt(uint monitorIndex);
  uint GetMonitorDevicePathCount();
  RevRect GetMonitorRECT([MarshalAs(UnmanagedType.LPWStr)] string monitorID);
  void SetBackgroundColor(uint color);
  uint GetBackgroundColor();
  void SetPosition(int position);
  int GetPosition();
}
[ComImport, Guid("C2CF3110-460E-4fc1-B9D0-8A1C0C9CC4BD")] public class RevDesktopWallpaperClass { }
public static class RevWall {
  static IRevDesktopWallpaper W() { return (IRevDesktopWallpaper)new RevDesktopWallpaperClass(); }
  public static string Monitors() {
    var w = W(); var sb = new System.Text.StringBuilder();
    uint n = w.GetMonitorDevicePathCount();
    for (uint i = 0; i < n; i++) {
      string id = w.GetMonitorDevicePathAt(i);
      try { var r = w.GetMonitorRECT(id); if (r.Right - r.Left <= 0) continue; sb.Append(i + "|" + r.Left + "|" + r.Top + "|" + (r.Right - r.Left) + "|" + (r.Bottom - r.Top) + "\\n"); } catch { }
    }
    return sb.ToString();
  }
  public static void Apply(string img, string mode, string list) {
    var w = W();
    if (mode == "span") { w.SetPosition(5); w.SetWallpaper(null, img); return; }
    w.SetPosition(4);
    if (mode == "all" || string.IsNullOrEmpty(list)) { w.SetWallpaper(null, img); return; }
    foreach (var s in list.Split(',')) { uint i; if (uint.TryParse(s, out i) && i < w.GetMonitorDevicePathCount()) w.SetWallpaper(w.GetMonitorDevicePathAt(i), img); }
  }
}`;

function run(script, timeout = 25000) {
  const full = `$ErrorActionPreference = 'Stop'\nAdd-Type -TypeDefinition @'\n${CS}\n'@\n${script}`;
  const encoded = Buffer.from(full, 'utf16le').toString('base64');
  return new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { windowsHide: true, timeout }, (error, stdout, stderr) => {
      if (error) return reject(new Error(String(stderr || error.message || 'Fehler').trim().split(/\r?\n/)[0]));
      resolve(String(stdout || ''));
    });
  });
}

/** Monitore in Windows-Reihenfolge: [{ id, x, y, w, h }] (physische Pixel). */
async function monitors() {
  const out = await run('[RevWall]::Monitors()', 15000);
  return out
    .split(/\r?\n/)
    .map((l) => l.trim().split('|').map(Number))
    .filter((p) => p.length === 5 && p.every((n) => Number.isFinite(n)))
    .map(([id, x, y, w, h]) => ({ id, x, y, w, h }));
}

/**
 * @param {string} filePath
 * @param {{ mode?: 'all'|'span'|'select', monitors?: number[] }} [opts]
 */
/**
 * Gegen „verpixelt“: kleine oder stark komprimierte Bilder werden vor dem Setzen mit Lanczos
 * auf 4K hochgerechnet und Farbstufen (Banding) geglättet. Windows bekommt dann eine Datei,
 * die auch auf dem Hochkant-Monitor und beim Strecken über alle Monitore scharf bleibt.
 */
function enhance(src) {
  const path = require('path');
  const fs = require('fs');
  const ffmpeg = path.join(__dirname, '..', '..', 'vendor', 'ffmpeg', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
  if (!fs.existsSync(ffmpeg) || !fs.existsSync(src)) return Promise.resolve(src);
  const dst = src.replace(/\.[a-z0-9]+$/i, '') + '-hq.jpg';
  const vf = "scale='if(lt(iw,3840),3840,iw)':-2:flags=lanczos+accurate_rnd+full_chroma_int,gradfun=strength=1.4:radius=18,format=yuvj444p";
  return new Promise((resolve) => {
    execFile(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-i', src, '-frames:v', '1', '-vf', vf, '-q:v', '1', '-y', dst], { windowsHide: true, timeout: 45000 }, (error) => {
      resolve(!error && fs.existsSync(dst) && fs.statSync(dst).size > 10000 ? dst : src);
    });
  });
}

async function applyDesktopWallpaper(filePath, opts = {}) {
  const sharp = opts.raw ? filePath : await enhance(String(filePath || ''));
  const img = String(sharp || '').replace(/'/g, "''");
  const mode = ['all', 'span', 'select'].includes(opts.mode) ? opts.mode : 'all';
  const list = (Array.isArray(opts.monitors) ? opts.monitors : []).map((n) => Math.max(0, Math.round(Number(n) || 0))).join(',');
  const out = await run(`
$img = '${img}'
if (-not (Test-Path -LiteralPath $img)) { Write-Output 'missing'; exit 1 }
Set-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Wallpapers' -Name BackgroundType -Value 0 -ErrorAction SilentlyContinue
# Windows komprimiert Hintergründe sonst noch einmal auf 85 % JPEG-Qualität
Set-ItemProperty -Path 'HKCU:\\Control Panel\\Desktop' -Name JPEGImportQuality -Value 100 -Type DWord -ErrorAction SilentlyContinue
for ($i = 0; $i -lt 3; $i++) {
  [RevWall]::Apply($img, '${mode}', '${list}')
  if ($i -lt 2) { Start-Sleep -Milliseconds 700 }
}
Write-Output 'ok'`);
  if (!out.includes('ok')) throw new Error('Hintergrund konnte nicht gesetzt werden.');
  return true;
}

module.exports = { applyDesktopWallpaper, monitors };
