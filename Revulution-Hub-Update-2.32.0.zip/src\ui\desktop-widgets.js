'use strict';

/* Widgets auf dem Windows-Desktop: ein durchsichtiges Fenster pro Monitor.
   Klicks gehen überall durch – nur über einem Widget nimmt das Fenster die Maus,
   damit man es frei ziehen (auch auf einen anderen Monitor) und bedienen kann. */
(function () {
  const stage = document.getElementById('stack');
  const query = new URLSearchParams(location.search);
  const MY_DISPLAY = Number(query.get('display'));
  const IS_PRIMARY = query.get('primary') === '1';
  let state = null;
  let pc = {};
  let screen = null;
  let media = null;
  let interactive = false;

  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const pct = (v) => (v == null || Number.isNaN(Number(v)) ? '–' : `${Math.round(Number(v))} %`);
  const clamp = (v) => Math.max(0, Math.min(100, Number(v) || 0));
  const mmss = (s) => `${Math.floor((Number(s) || 0) / 60)}:${String(Math.floor((Number(s) || 0) % 60)).padStart(2, '0')}`;

  const timeText = () => new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const dayHtml = () => {
    const d = new Date();
    const wd = d.toLocaleDateString('de-DE', { weekday: 'short' }).replace('.', '').toUpperCase();
    return `<b>${esc(wd)}</b> · ${String(d.getDate()).padStart(2, '0')} ${esc(d.toLocaleDateString('de-DE', { month: 'short' }).replace('.', '').toUpperCase())}`;
  };
  const fmtDuration = (seconds) => {
    const s = Math.max(0, Math.round(Number(seconds) || 0));
    const h = Math.floor(s / 3600);
    const m = Math.round((s % 3600) / 60);
    return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m`;
  };
  /** Punkte-Balken: der letzte gefüllte Punkt ist rot. */
  function dots(value, n = 20) {
    const k = Math.round((clamp(value) / 100) * n);
    let html = '<div class="dw-dots">';
    for (let i = 0; i < n; i++) html += `<i class="${i < k - 1 ? 'on' : i === k - 1 ? 'tip' : ''}"></i>`;
    return `${html}</div>`;
  }

  const ICON = {
    prev: '<svg viewBox="0 0 24 24"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M16 5h2v14h-2zM4 5v14l11-7z"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4v16l13-8z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
  };

  /* Tonarm wie im Musik-Overlay: Drehpunkt oben rechts, wandert mit dem Song nach innen. */
  const ARM_SVG = `<svg class="dw-arm" viewBox="0 0 100 100" aria-hidden="true">
    <defs>
      <linearGradient id="dwArmMetal" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4f6fa"/><stop offset="0.55" stop-color="#b9c0cc"/><stop offset="1" stop-color="#7d8594"/></linearGradient>
      <radialGradient id="dwArmBase" cx="0.4" cy="0.35" r="0.7"><stop offset="0" stop-color="#5c6370"/><stop offset="1" stop-color="#1b1e25"/></radialGradient>
    </defs>
    <g class="dw-arm-rot">
      <g transform="translate(92 8)">
        <rect x="-15" y="-3.2" width="8" height="6.4" rx="1.6" fill="#2a2e37" stroke="#7d8594" stroke-width="0.6"/>
        <rect x="-7" y="-1.3" width="60" height="2.6" rx="1.3" fill="url(#dwArmMetal)" stroke="rgba(0,0,0,0.35)" stroke-width="0.3"/>
        <g transform="translate(55 0) rotate(22)">
          <rect x="-4" y="-2.6" width="11" height="5.2" rx="1.2" fill="#d9dde5" stroke="#5c6370" stroke-width="0.5"/>
          <rect x="4.6" y="1.2" width="1.6" height="2.6" rx="0.4" fill="#ff2d2d"/>
        </g>
      </g>
      <circle cx="92" cy="8" r="6.5" fill="url(#dwArmBase)" stroke="rgba(255,255,255,0.25)" stroke-width="0.6"/>
      <circle cx="92" cy="8" r="2.2" fill="#c9ced8"/>
    </g>
  </svg>`;
  const ARM_REST = 82;
  const ARM_START = 90.5;
  const ARM_END = 108.4;

  /* Standardplätze auf dem Hauptmonitor (rechts oben) – danach zählt, wo du sie hinziehst. */
  const W = window.innerWidth;
  const DEFAULTS = {
    clock: { x: W - 330, y: 76 },
    face: { x: W - 560, y: 76 },
    music: { x: W - 360, y: 236 },
    system: { x: W - 300, y: 420 },
    calendar: { x: W - 560, y: 296 },
    screen: { x: W - 300, y: 540 },
    upcoming: { x: W - 300, y: 690 },
    eq: { x: W - 640, y: 560 },
    mixer: { x: 40, y: 560 },
  };

  stage.innerHTML = `
    <section class="dw dw-clock" data-w="clock"><time id="dw-time">${timeText()}</time><div class="dw-day" id="dw-day">${dayHtml()}</div></section>
    <section class="dw dw-face" data-w="face"><canvas id="dw-face" width="340" height="340"></canvas></section>
    <section class="dw dw-music" data-w="music"><div class="dw-label">Läuft gerade</div><div id="dw-music-body"></div></section>
    <section class="dw dw-system" data-w="system"><div class="dw-label">System</div><div id="dw-sys-body"></div></section>
    <section class="dw dw-cal" data-w="calendar"><div id="dw-cal-body"></div></section>
    <section class="dw dw-screen" data-w="screen"><div class="dw-label">Bildschirmzeit</div><div id="dw-screen-body"></div></section>
    <section class="dw dw-up" data-w="upcoming"><div class="dw-label">Termine</div><div id="dw-up-body"></div></section>
    <section class="dw dw-eq-w" data-w="eq"><div class="dw-label">Sound <em id="dw-eq-state">…</em></div><canvas id="dw-eq" width="560" height="200"></canvas><div class="dw-eq-foot"><span>BASS</span><i id="dw-eq-bass"><b></b></i><span>30 Hz – 16 kHz</span></div></section>
    <section class="dw dw-mix" data-w="mixer"><div class="dw-label">Mixer</div><div id="dw-mix-body"><div class="dw-empty">…</div></div></section>`;

  const cards = Object.fromEntries([...stage.querySelectorAll('[data-w]')].map((el) => [el.dataset.w, el]));
  const visible = (id) => cards[id] && !cards[id].hidden && !cards[id].classList.contains('away');

  /** Gehört das Widget auf diesen Monitor? Alte Positionen (ohne Monitor) = Hauptmonitor. */
  function slot(id) {
    const p = state?.settings?.widgetPos?.[id];
    if (!p) return IS_PRIMARY ? { ...DEFAULTS[id] } : null;
    if (p.d == null) return IS_PRIMARY ? { x: p.x, y: p.y + 36 } : null; // früher lag das Fenster 36 px tiefer
    return Number(p.d) === MY_DISPLAY ? { x: p.x, y: p.y } : null;
  }

  function place() {
    for (const [id, el] of Object.entries(cards)) {
      if (drag?.el === el || el.classList.contains('ghost')) continue;
      const p = slot(id);
      el.classList.toggle('away', !p);
      if (!p) continue;
      el.style.left = `${Math.max(0, Math.min(window.innerWidth - 60, p.x))}px`;
      el.style.top = `${Math.max(0, Math.min(window.innerHeight - 40, p.y))}px`;
    }
  }

  /* ------------------------------------------------------------ Ziehen (auch über Monitore) */
  let drag = null;
  let dragSent = 0;
  stage.addEventListener('pointerdown', (e) => {
    const el = e.target.closest('.dw');
    if (!el || e.button !== 0 || e.target.closest('button')) return;
    const r = el.getBoundingClientRect();
    drag = { el, dx: e.clientX - r.left, dy: e.clientY - r.top, moved: false };
    el.setPointerCapture(e.pointerId);
    el.classList.add('dragging');
  });
  stage.addEventListener('pointermove', (e) => {
    if (!drag) return;
    drag.moved = true;
    const outside = e.clientX < 0 || e.clientY < 0 || e.clientX > window.innerWidth || e.clientY > window.innerHeight;
    // Draußen (auf einem anderen Monitor) zeigt das Fenster dort das Widget – hier ausblenden.
    drag.el.classList.toggle('leaving', outside);
    drag.el.style.left = `${e.clientX - drag.dx}px`;
    drag.el.style.top = `${e.clientY - drag.dy}px`;
    if (!dragSent) {
      dragSent = requestAnimationFrame(() => {
        dragSent = 0;
        if (drag) window.hub.widgetDrag?.(drag.el.dataset.w, drag.dx, drag.dy, 'move');
      });
    }
  });
  const endDrag = () => {
    if (!drag) return;
    const { el, moved, dx, dy } = drag;
    el.classList.remove('dragging', 'leaving');
    drag = null;
    if (moved) window.hub.widgetDrag?.(el.dataset.w, dx, dy, 'end');
  };
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);

  // Ein Widget, das gerade von einem anderen Monitor herübergezogen wird.
  window.hub.onWidgetGhost?.((g) => {
    const el = g && cards[g.id];
    if (!el || drag?.el === el) return;
    if (g.off) {
      if (el.classList.contains('ghost')) {
        el.classList.remove('ghost', 'dragging');
        place();
      }
      return;
    }
    el.classList.remove('away');
    el.classList.add('ghost', 'dragging');
    el.style.left = `${g.x}px`;
    el.style.top = `${g.y}px`;
    if (g.id === 'face') drawFace();
  });

  // Nur über einem Widget nimmt das Fenster die Maus – sonst geht alles zum Desktop durch.
  document.addEventListener('mousemove', (e) => {
    const over = Boolean(drag || document.elementFromPoint(e.clientX, e.clientY)?.closest('.dw'));
    if (over !== interactive) {
      interactive = over;
      window.hub.widgetsInteractive?.(over);
    }
  });

  /* ------------------------------------------------------------ Inhalte */
  function paintClock() {
    const t = document.getElementById('dw-time');
    if (t && t.textContent !== timeText()) t.textContent = timeText();
    const d = document.getElementById('dw-day');
    if (d && d.innerHTML !== dayHtml()) d.innerHTML = dayHtml();
  }

  function paintSystem() {
    const body = document.getElementById('dw-sys-body');
    if (!body) return;
    body.innerHTML = [['CPU', pc.cpu], ['RAM', pc.ramPct], ['GPU', pc.gpu]].map(([n, v]) => `<div class="dw-row"><span>${n}</span>${dots(v)}<b>${pct(v)}</b></div>`).join('');
  }

  function paintScreen() {
    const body = document.getElementById('dw-screen-body');
    if (!body) return;
    if (!screen) return (body.innerHTML = '<div class="dw-empty">…</div>');
    const apps = (screen.apps || []).slice(0, 3);
    body.innerHTML = `<div class="dw-big">${fmtDuration(screen.total)}</div><div style="height:10px"></div>${apps.map((a) => `<div class="dw-app"><span>${esc(a.name)}</span>${dots((a.secs / Math.max(1, screen.total)) * 100)}</div>`).join('')}`;
  }

  function paintUpcoming() {
    const body = document.getElementById('dw-up-body');
    if (!body) return;
    const list = (state?.upcoming || []).slice(0, 3);
    if (!list.length) return (body.innerHTML = '<div class="dw-empty">Keine Termine</div>');
    body.innerHTML = list
      .map((e) => {
        const d = new Date(e.start);
        const today = new Date();
        const tomorrow = new Date(Date.now() + 86400000);
        const day = d.toDateString() === today.toDateString() ? 'Heute' : d.toDateString() === tomorrow.toDateString() ? 'Morgen' : d.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
        const when = e.allDay ? `${day} · ganztägig` : `${day} · ${d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
        return `<div class="dw-event"><i></i><div><b>${esc(e.title)}</b><small>${esc(when)}</small></div></div>`;
      })
      .join('');
  }

  function paintCalendar() {
    const body = document.getElementById('dw-cal-body');
    if (!body) return;
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth();
    const key = `${y}-${m}-${now.getDate()}`;
    if (body.dataset.key === key) return;
    const first = (new Date(y, m, 1).getDay() + 6) % 7; // Montag zuerst
    const days = new Date(y, m + 1, 0).getDate();
    const prevDays = new Date(y, m, 0).getDate();
    let html = ['MO', 'DI', 'MI', 'DO', 'FR', 'SA', 'SO'].map((d) => `<span class="wd">${d}</span>`).join('');
    for (let i = 0; i < 42; i++) {
      const n = i - first + 1;
      if (n < 1) html += `<span class="d off">${prevDays + n}</span>`;
      else if (n > days) html += `<span class="d off">${n - days}</span>`;
      else html += `<span class="d ${n === now.getDate() ? 'today' : ''}">${n}</span>`;
      if (i >= 34 && n >= days) break;
    }
    body.dataset.key = key;
    body.innerHTML = `<div class="dw-cal-head"><span>${esc(now.toLocaleDateString('de-DE', { month: 'long' }))}</span><span>${y}</span></div><div class="dw-cal-grid">${html}</div>`;
  }

  /* ------------------------------------------------------------ Musik: Plattenspieler oder Cover */
  const vinylOn = () => state?.settings?.desktopWidgets?.vinyl !== false;
  let musicKey = '';
  function paintMusic() {
    const body = document.getElementById('dw-music-body');
    if (!body) return;
    const m = media;
    const vinyl = vinylOn();
    cards.music.classList.toggle('playing', Boolean(m?.playing));
    cards.music.classList.toggle('vinyl', vinyl);
    if (!m?.title) {
      musicKey = '';
      body.innerHTML = '<div class="dw-empty">Gerade läuft nichts</div>';
      return;
    }
    const art = m.art ? `background-image:url('data:image/jpeg;base64,${m.art}')` : '';
    // Grundgerüst nur neu bauen, wenn sich Song/Cover/Modus ändert – sonst läuft die Platte weich weiter.
    const key = `${vinyl}|${m.title}|${m.artist}|${m.art ? m.art.length : 0}`;
    if (key !== musicKey) {
      musicKey = key;
      const disc = vinyl
        ? `<div class="dw-deck"><div class="dw-vinyl"><div class="dw-label-art" style="${art}">${m.art ? '' : '♪'}</div><div class="dw-sheen"></div></div>${ARM_SVG}</div>`
        : `<div class="dw-cover" style="${art}">${m.art ? '' : '♪'}</div>`;
      body.innerHTML = `<div class="dw-mu-top">${disc}<div class="dw-mu-text"><b>${esc(m.title)}</b><span>${esc(m.artist || '')}</span>
        <div class="dw-mu-ctl"><button data-media="prev">${ICON.prev}</button><button class="main" data-media="playpause"></button><button data-media="next">${ICON.next}</button></div></div></div>
        <div class="dw-mu-prog"><span data-mu-pos></span><div data-mu-dots></div><span data-mu-dur></span></div>`;
    }
    const prog = m.duration > 0 ? (m.position / m.duration) * 100 : 0;
    body.querySelector('[data-mu-pos]').textContent = mmss(m.position);
    body.querySelector('[data-mu-dur]').textContent = mmss(m.duration);
    body.querySelector('[data-mu-dots]').innerHTML = dots(prog, 28);
    body.querySelector('.main').innerHTML = m.playing ? ICON.pause : ICON.play;
    const arm = body.querySelector('.dw-arm-rot');
    if (arm) {
      const angle = m.playing ? ARM_START + (ARM_END - ARM_START) * Math.min(1, Math.max(0, prog / 100)) : ARM_REST;
      arm.style.transform = `rotate(${angle.toFixed(2)}deg)`;
    }
  }
  stage.addEventListener('click', (e) => {
    const b = e.target.closest('[data-media]');
    if (!b) return;
    window.hub.cc?.media?.(b.dataset.media)?.catch?.(() => {});
    if (b.dataset.media === 'playpause' && media) {
      media.playing = !media.playing;
      paintMusic();
    }
  });


  /* ------------------------------------------------------------ Sound-Visualizer (Systemton live) */
  const EQ_COLS = 28;
  const EQ_ROWS = 10;
  const eq = { stream: null, ctx: null, an: null, data: null, raf: 0, peaks: new Array(EQ_COLS).fill(0), lvl: new Array(EQ_COLS).fill(0), bass: 0, tried: 0 };
  async function eqStart() {
    if (eq.stream || Date.now() - eq.tried < 5000) return;
    eq.tried = Date.now();
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
      s.getVideoTracks().forEach((t) => t.stop());
      if (!s.getAudioTracks().length) return;
      eq.stream = s;
      eq.ctx = new AudioContext();
      const src = eq.ctx.createMediaStreamSource(new MediaStream(s.getAudioTracks()));
      eq.an = eq.ctx.createAnalyser();
      eq.an.fftSize = 2048;
      eq.an.smoothingTimeConstant = 0.72;
      src.connect(eq.an);
      eq.data = new Uint8Array(eq.an.frequencyBinCount);
    } catch {
      /* ohne Systemton bleibt das Widget ruhig */
    }
  }
  function eqStop() {
    cancelAnimationFrame(eq.raf);
    eq.raf = 0;
    eq.stream?.getTracks().forEach((t) => t.stop());
    eq.ctx?.close().catch(() => {});
    eq.stream = eq.ctx = eq.an = null;
  }
  function eqFrame() {
    eq.raf = 0;
    const cv = document.getElementById('dw-eq');
    if (!cv || !visible('eq')) return eqStop();
    const g = cv.getContext('2d');
    const W2 = cv.width;
    const H2 = cv.height;
    g.clearRect(0, 0, W2, H2);
    const bins = eq.data ? eq.data.length : 0;
    if (eq.an) eq.an.getByteFrequencyData(eq.data);
    // logarithmische Bänder: 30 Hz … 16 kHz
    const nyq = (eq.ctx?.sampleRate || 48000) / 2;
    for (let c = 0; c < EQ_COLS; c++) {
      let v = 0;
      if (bins) {
        const f0 = 30 * Math.pow(16000 / 30, c / EQ_COLS);
        const f1 = 30 * Math.pow(16000 / 30, (c + 1) / EQ_COLS);
        const i0 = Math.max(1, Math.floor((f0 / nyq) * bins));
        const i1 = Math.max(i0 + 1, Math.floor((f1 / nyq) * bins));
        let sum = 0;
        for (let i = i0; i < i1 && i < bins; i++) sum = Math.max(sum, eq.data[i]);
        v = sum / 255;
      }
      eq.lvl[c] += (v - eq.lvl[c]) * 0.5;
      eq.peaks[c] = Math.max(eq.lvl[c], eq.peaks[c] - 0.012);
    }
    eq.bass += ((eq.lvl[0] + eq.lvl[1] + eq.lvl[2] + eq.lvl[3]) / 4 - eq.bass) * 0.3;
    const cw = W2 / EQ_COLS;
    const rh = H2 / EQ_ROWS;
    const r = Math.min(cw, rh) * 0.32;
    for (let c = 0; c < EQ_COLS; c++) {
      const on = Math.round(eq.lvl[c] * EQ_ROWS);
      const pk = Math.min(EQ_ROWS - 1, Math.round(eq.peaks[c] * EQ_ROWS));
      for (let row = 0; row < EQ_ROWS; row++) {
        const y = H2 - (row + 0.5) * rh;
        const x = (c + 0.5) * cw;
        g.beginPath();
        g.arc(x, y, r, 0, Math.PI * 2);
        g.fillStyle = row === pk && pk > 0 ? '#ff2d2d' : row < on ? '#ffffff' : 'rgba(255,255,255,0.12)';
        g.fill();
      }
    }
    const bassEl = document.getElementById('dw-eq-bass');
    if (bassEl) bassEl.style.setProperty('--b', eq.bass.toFixed(3));
    const lab = document.getElementById('dw-eq-state');
    if (lab) lab.textContent = eq.stream ? (media?.playing ? 'LIVE' : 'BEREIT') : 'KEIN TON';
    eq.raf = requestAnimationFrame(eqFrame);
  }
  function eqEnsure() {
    if (!visible('eq')) return eqStop();
    eqStart();
    if (!eq.raf) eq.raf = requestAnimationFrame(eqFrame);
  }

  /* ------------------------------------------------------------ Mixer: Lautstärke pro App */
  let mixData = null;
  let mixBusy = false;
  async function loadMixer() {
    if (!visible('mixer') || mixBusy) return;
    mixBusy = true;
    try {
      mixData = await window.hub.mix?.list?.();
    } catch {
      mixData = null;
    }
    mixBusy = false;
    paintMixer();
  }
  function paintMixer() {
    const body = document.getElementById('dw-mix-body');
    if (!body || document.activeElement?.closest?.('#dw-mix-body')) return; // nicht unter dem Finger neu bauen
    const apps = (mixData?.apps || []).filter((a) => a && a.name).sort((x, y) => Number(y.active) - Number(x.active)).slice(0, 5);
    if (!apps.length) return (body.innerHTML = '<div class="dw-empty">Keine App spielt gerade Ton</div>');
    body.innerHTML = apps
      .map((a) => `<label class="dw-mix-row"><span>${esc(a.name)}</span><input type="range" min="0" max="100" value="${Math.round(Number(a.volume ?? 1) * 100)}" data-mix="${esc(a.pid)}" style="--v:${Math.round(Number(a.volume ?? 1) * 100)}%" /><b>${Math.round(Number(a.volume ?? 1) * 100)}</b></label>`)
      .join('');
  }
  stage.addEventListener('input', (e) => {
    const r = e.target.closest?.('[data-mix]');
    if (!r) return;
    r.style.setProperty('--v', `${r.value}%`);
    const b = r.parentElement.querySelector('b');
    if (b) b.textContent = r.value;
    window.hub.mix?.app?.(Number(r.dataset.mix), Number(r.value) / 100, null)?.catch?.(() => {});
  });
  stage.addEventListener('change', () => setTimeout(loadMixer, 400));
  setInterval(loadMixer, 5000);

  /* ------------------------------------------------------------ Punktmatrix-Gesicht */
  const face = { blinkAt: Date.now() + 2500, look: 0, lookTo: 0, lookAt: Date.now() + 1800 };
  function drawFace() {
    const cv = document.getElementById('dw-face');
    if (!cv || !visible('face')) return;
    const g = cv.getContext('2d');
    const N = 21;
    const S = cv.width / N;
    const now = Date.now();
    g.clearRect(0, 0, cv.width, cv.height);
    if (now > face.lookAt) {
      face.lookTo = [-1, 0, 0, 1][Math.floor(Math.random() * 4)];
      face.lookAt = now + 1500 + Math.random() * 2500;
    }
    face.look += (face.lookTo - face.look) * 0.35;
    const blink = now > face.blinkAt && now < face.blinkAt + 140;
    if (now > face.blinkAt + 140) face.blinkAt = now + 2200 + Math.random() * 3000;
    const lx = Math.round(face.look);
    const lit = new Set();
    const red = new Set();
    const eye = (cx) => {
      for (let y = 7; y <= 10; y++) for (let x = cx - 2; x <= cx + 1; x++) if (!blink || y === 9) lit.add(`${x + lx},${y}`);
    };
    eye(7);
    eye(14);
    red.add(`${5 + lx},13`);
    red.add(`${15 + lx},13`);
    // Mund: wippt, solange Musik spielt
    const open = media?.playing ? Math.round((Math.sin(now / 160) + 1) * 0.9) : 0;
    for (let x = 9; x <= 11; x++) for (let y = 14; y <= 14 + open; y++) lit.add(`${x + lx},${y}`);
    for (let y = 0; y < N; y++)
      for (let x = 0; x < N; x++) {
        const dx = x - (N - 1) / 2;
        const dy = y - (N - 1) / 2;
        if (dx * dx + dy * dy > 10.2 * 10.2) continue;
        const k = `${x},${y}`;
        g.beginPath();
        g.arc(x * S + S / 2, y * S + S / 2, S * (lit.has(k) || red.has(k) ? 0.4 : 0.22), 0, Math.PI * 2);
        g.fillStyle = red.has(k) ? '#ff2d2d' : lit.has(k) ? '#ffffff' : 'rgba(255,255,255,0.14)';
        g.fill();
      }
  }

  /* ------------------------------------------------------------ Steuerung */
  function apply() {
    const d = state?.settings?.desktopWidgets || {};
    const on = (k, def = true) => (d[k] === undefined ? def : d[k] !== false);
    document.body.classList.toggle('cards', d.cards !== false);
    cards.clock.hidden = !on('clock');
    cards.face.hidden = !on('face');
    cards.music.hidden = !on('music');
    cards.system.hidden = !on('system');
    cards.calendar.hidden = !on('calendar');
    cards.screen.hidden = !on('screentime', false);
    cards.upcoming.hidden = !on('upcoming', false);
    cards.eq.hidden = !on('eq', true);
    cards.mixer.hidden = !on('mixer', false);
    place();
    paintClock();
    paintSystem();
    paintScreen();
    paintUpcoming();
    paintCalendar();
    paintMusic();
    // nach dem Platzieren: erst dann ist klar, ob die Widgets auf diesem Monitor sichtbar sind
    setTimeout(() => {
      eqEnsure();
      loadMixer();
    }, 50);
  }

  async function loadSystem() {
    if (!visible('system')) return;
    try {
      pc = (await window.hub.pcLive()) || {};
      paintSystem();
    } catch {
      /* letzter Wert bleibt */
    }
  }
  async function loadScreen() {
    if (!visible('screen')) return;
    try {
      screen = await window.hub.screentime.summary();
      paintScreen();
    } catch {
      /* letzter Wert bleibt */
    }
  }

  setInterval(() => {
    if (visible('clock')) paintClock();
    if (visible('calendar')) paintCalendar();
  }, 1000);
  setInterval(loadSystem, 4000);
  setInterval(loadScreen, 60000);
  setInterval(drawFace, 90); // ~11 Bilder/s reichen für das Gesicht

  window.hub.onMedia?.((m) => {
    if (!m) return;
    const sameSong = media && media.title === m.title && media.artist === m.artist;
    media = { ...m, art: m.art ? m.art : sameSong ? media.art || '' : '' };
    if (visible('music')) paintMusic();
  });
  window.hub.onState((next) => {
    state = next;
    apply();
  });
  window.hub
    .state()
    .then((initial) => {
      state = initial;
      apply();
      loadSystem();
      loadScreen();
    })
    .catch(() => {});
})();
