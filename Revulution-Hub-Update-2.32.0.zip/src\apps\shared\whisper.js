'use strict';

/*
 * Gemeinsame Spracherkennung für Dokumente (Diktieren) und Video (Auto-Untertitel).
 * whisper.cpp läuft komplett lokal; Programm und Modell werden einmal geladen und
 * liegen für alle Apps im selben Ordner.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile, spawn } = require('child_process');

const DIR = path.join(process.env.APPDATA || os.homedir(), 'Revolution Hub', 'whisper');
const MODEL = path.join(DIR, 'ggml-small-q5_1.bin');
const MODEL_URL = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin';
const FFMPEG = path.join(__dirname, '..', '..', '..', 'vendor', 'ffmpeg', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');

let installing = 0;
let lastError = '';
const listeners = new Set();
const tell = () => {
  for (const cb of listeners) {
    try {
      cb(status());
    } catch {
      /* Fenster zu */
    }
  }
};

function exe() {
  const walk = (d, depth = 0) => {
    let list = [];
    try {
      list = fs.readdirSync(d, { withFileTypes: true });
    } catch {
      return '';
    }
    for (const e of list) if (e.isFile() && /^whisper-cli\.exe$/i.test(e.name)) return path.join(d, e.name); // nicht main.exe – nur ein Platzhalter
    for (const e of list) {
      if (!e.isDirectory() || depth >= 3) continue;
      const r = walk(path.join(d, e.name), depth + 1);
      if (r) return r;
    }
    return '';
  };
  return walk(path.join(DIR, 'bin'));
}

function status() {
  return { installed: Boolean(exe()) && fs.existsSync(MODEL), installing, error: lastError };
}

async function download(url, file, onPart) {
  const r = await fetch(url, { redirect: 'follow', headers: { 'user-agent': 'Revulution-Hub' } });
  if (!r.ok) throw new Error(`Download fehlgeschlagen (${r.status})`);
  const total = Number(r.headers.get('content-length')) || 0;
  const out = fs.createWriteStream(`${file}.part`);
  let got = 0;
  for await (const chunk of r.body) {
    out.write(chunk);
    got += chunk.length;
    if (total) onPart(got / total);
  }
  await new Promise((res) => out.end(res));
  fs.renameSync(`${file}.part`, file);
}

async function install() {
  if (installing) return status();
  lastError = '';
  installing = 0.01;
  tell();
  try {
    fs.mkdirSync(path.join(DIR, 'bin'), { recursive: true });
    if (!exe()) {
      // Nicht jedes Release hat Windows-Dateien – das neueste mit dem x64-Paket nehmen.
      const rels = await (await fetch('https://api.github.com/repos/ggml-org/whisper.cpp/releases?per_page=12', { headers: { 'user-agent': 'Revulution-Hub' } })).json();
      let asset = null;
      for (const rel of Array.isArray(rels) ? rels : []) {
        asset = (rel.assets || []).find((a) => /^whisper-bin-x64\.zip$/i.test(a.name));
        if (asset) break;
      }
      if (!asset) throw new Error('Whisper-Programm nicht gefunden.');
      const zip = path.join(DIR, 'whisper.zip');
      await download(asset.browser_download_url, zip, (p) => {
        installing = 0.01 + p * 0.14;
        tell();
      });
      await new Promise((res, rej) =>
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${path.join(DIR, 'bin').replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 180000 }, (e) => (e ? rej(e) : res())),
      );
      fs.rmSync(zip, { force: true });
    }
    if (!fs.existsSync(MODEL))
      await download(MODEL_URL, MODEL, (p) => {
        installing = 0.15 + p * 0.85;
        tell();
      });
  } catch (error) {
    lastError = String(error?.message || error);
  }
  installing = 0;
  tell();
  return status();
}

function ffmpeg(args) {
  return new Promise((res, rej) => execFile(FFMPEG, ['-hide_banner', '-loglevel', 'error', ...args], { windowsHide: true, timeout: 600000 }, (e) => (e ? rej(new Error('Audio konnte nicht umgewandelt werden.')) : res())));
}

/**
 * Erkennt Sprache in einer Audio-/Videodatei.
 * @param {string} file  beliebige Datei, die ffmpeg lesen kann
 * @param {{ lang?: string, from?: number, to?: number }} opts
 * @returns {Promise<{ text: string, segments: { start: number, end: number, text: string }[] }>}
 */
async function transcribe(file, { lang = 'de', from = 0, to = 0 } = {}) {
  const bin = exe();
  if (!bin || !fs.existsSync(MODEL)) throw new Error('Die Spracherkennung ist noch nicht eingerichtet.');
  const tmp = path.join(os.tmpdir(), `rev-whisper-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`);
  try {
    const cut = [];
    if (from > 0) cut.push('-ss', String(from));
    if (to > from) cut.push('-t', String(to - from));
    await ffmpeg([...cut, '-i', file, '-vn', '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', '-y', `${tmp}.wav`]);
    const threads = Math.max(2, Math.min(8, os.cpus().length - 1));
    await new Promise((res, rej) => {
      const p = spawn(bin, ['-m', MODEL, '-l', ['de', 'en', 'es', 'auto'].includes(lang) ? lang : 'de', '-t', String(threads), '-osrt', '-otxt', '-of', tmp, '-f', `${tmp}.wav`], { windowsHide: true, cwd: path.dirname(bin) });
      p.on('exit', (code) => (code === 0 ? res() : rej(new Error('Spracherkennung fehlgeschlagen.'))));
      p.on('error', rej);
    });
    const text = fs.existsSync(`${tmp}.txt`) ? fs.readFileSync(`${tmp}.txt`, 'utf8').replace(/\s+/g, ' ').trim() : '';
    const segments = [];
    if (fs.existsSync(`${tmp}.srt`)) {
      const ts = (v) => {
        const m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(v);
        return m ? Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000 : 0;
      };
      for (const block of fs.readFileSync(`${tmp}.srt`, 'utf8').split(/\r?\n\r?\n/)) {
        const lines = block.trim().split(/\r?\n/);
        const time = lines.find((l) => l.includes('-->'));
        if (!time) continue;
        const [a, b] = time.split('-->');
        const t = lines.slice(lines.indexOf(time) + 1).join(' ').trim();
        if (t) segments.push({ start: ts(a), end: ts(b), text: t });
      }
    }
    return { text, segments };
  } finally {
    for (const ext of ['.wav', '.txt', '.srt']) fs.rmSync(tmp + ext, { force: true });
  }
}

module.exports = { status, install, transcribe, onChange: (cb) => listeners.add(cb), DIR };
