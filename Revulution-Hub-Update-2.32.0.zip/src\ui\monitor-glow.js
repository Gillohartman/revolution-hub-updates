'use strict';

/* Leuchtender Rand + aufsteigende Partikel auf einem echten Monitor, solange er in der
   Hintergrund-Auswahl gewählt ist. Gezeichnet in voller Pixeldichte – scharf, 60 fps. */
(() => {
  const cv = document.getElementById('c');
  const g = cv.getContext('2d');
  let W = 0;
  let H = 0;
  let dpr = 1;
  const resize = () => {
    dpr = window.devicePixelRatio || 1;
    W = window.innerWidth;
    H = window.innerHeight;
    cv.width = Math.round(W * dpr);
    cv.height = Math.round(H * dpr);
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
  };
  resize();
  window.addEventListener('resize', resize);

  const spawn = (fresh) => ({
    x: Math.random() * W,
    y: fresh ? Math.random() * H : H + 20,
    r: 1 + Math.random() * 2.6,
    v: 0.4 + Math.random() * 1.4,
    a: Math.random() * Math.PI * 2,
    s: 0.4 + Math.random() * 0.6,
  });
  const ps = Array.from({ length: 140 }, () => spawn(true));
  let t0 = performance.now();

  function frame(now) {
    const t = (now - t0) / 1000;
    g.clearRect(0, 0, W, H);
    // Rand: weiches blaues Leuchten, das langsam pulsiert
    const pulse = 0.75 + Math.sin(t * 2.2) * 0.25;
    const edge = Math.min(W, H) * 0.09;
    for (const [x0, y0, x1, y1, w, h, x, y] of [
      [0, 0, 0, edge, W, edge, 0, 0],
      [0, H, 0, H - edge, W, edge, 0, H - edge],
      [0, 0, edge, 0, edge, H, 0, 0],
      [W, 0, W - edge, 0, edge, H, W - edge, 0],
    ]) {
      const grad = g.createLinearGradient(x0, y0, x1, y1);
      grad.addColorStop(0, `rgba(80, 160, 255, ${0.55 * pulse})`);
      grad.addColorStop(1, 'rgba(40, 110, 255, 0)');
      g.fillStyle = grad;
      g.fillRect(x, y, w, h);
    }
    g.strokeStyle = `rgba(140, 200, 255, ${0.9 * pulse})`;
    g.lineWidth = 3;
    g.strokeRect(1.5, 1.5, W - 3, H - 3);
    // Partikel
    for (const p of ps) {
      p.y -= p.v;
      p.a += 0.02;
      p.x += Math.sin(p.a) * 0.4;
      if (p.y < -20) Object.assign(p, spawn(false));
      const fade = Math.min(1, (H - p.y) / 120, p.y / 160);
      const rad = p.r * 5;
      const glow = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, rad);
      glow.addColorStop(0, `rgba(190, 225, 255, ${0.95 * p.s * fade})`);
      glow.addColorStop(0.35, `rgba(90, 160, 255, ${0.5 * p.s * fade})`);
      glow.addColorStop(1, 'rgba(40, 110, 255, 0)');
      g.fillStyle = glow;
      g.beginPath();
      g.arc(p.x, p.y, rad, 0, Math.PI * 2);
      g.fill();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  requestAnimationFrame(() => document.body.classList.add('on'));
  window.addEventListener('message', () => {});
})();
