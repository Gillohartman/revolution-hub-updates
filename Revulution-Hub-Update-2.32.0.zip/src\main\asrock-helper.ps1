$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

public static class AsrockHid {
  [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
  [DllImport("setupapi.dll", CharSet=CharSet.Auto)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int f);
  [DllImport("setupapi.dll")] static extern bool SetupDiEnumDeviceInterfaces(IntPtr s, IntPtr d, ref Guid g, int i, ref SP_DEVICE_INTERFACE_DATA data);
  [DllImport("setupapi.dll", CharSet=CharSet.Auto)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr s, ref SP_DEVICE_INTERFACE_DATA d, IntPtr detail, int size, out int req, IntPtr info);
  [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr s);
  [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Auto)] static extern SafeFileHandle CreateFile(string n, uint a, uint s, IntPtr sa, uint c, uint f, IntPtr t);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool WriteFile(SafeFileHandle h, byte[] b, int n, out int w, IntPtr o);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool ReadFile(SafeFileHandle h, byte[] b, int n, out int r, IntPtr o);
  [StructLayout(LayoutKind.Sequential)] struct SP_DEVICE_INTERFACE_DATA { public int cbSize; public Guid g; public int flags; public IntPtr r; }

  static SafeFileHandle H;
  static byte[] Last = new byte[65];

  static string FindPath() {
    Guid g; HidD_GetHidGuid(out g);
    IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);
    var d = new SP_DEVICE_INTERFACE_DATA(); d.cbSize = Marshal.SizeOf(d);
    for (int i = 0; SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref d); i++) {
      int req; SetupDiGetDeviceInterfaceDetail(set, ref d, IntPtr.Zero, 0, out req, IntPtr.Zero);
      IntPtr buf = Marshal.AllocHGlobal(req);
      Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
      if (SetupDiGetDeviceInterfaceDetail(set, ref d, buf, req, out req, IntPtr.Zero)) {
        string p = Marshal.PtrToStringAuto(buf + 4);
        string low = p.ToLowerInvariant();
        if (low.Contains("vid_26ce") && low.Contains("pid_01a2")) { Marshal.FreeHGlobal(buf); SetupDiDestroyDeviceInfoList(set); return p; }
      }
      Marshal.FreeHGlobal(buf);
    }
    SetupDiDestroyDeviceInfoList(set);
    return "";
  }

  static byte[] Cmd(byte id, byte arg) {
    var b = new byte[65]; b[0] = 0; b[1] = id; b[3] = arg; return b;
  }

  static bool Send(byte[] b, out string err) {
    err = "";
    if (H == null || H.IsInvalid) { err = "NO_DEVICE"; return false; }
    int w, r;
    if (!WriteFile(H, b, 65, out w, IntPtr.Zero)) { err = "WRITE_" + Marshal.GetLastWin32Error(); return false; }
    var resp = new byte[65];
    if (!ReadFile(H, resp, 65, out r, IntPtr.Zero)) { err = "READ_" + Marshal.GetLastWin32Error(); return false; }
    Last = resp;
    return true;
  }

  public static string Open() {
    string p = FindPath();
    if (p == "") return "NO_DEVICE";
    H = CreateFile(p, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
    if (H.IsInvalid) return "OPEN_" + Marshal.GetLastWin32Error();
    string err;
    if (!Send(Cmd(0x14, 0x02), out err)) return err;
    var sizes = new List<int>();
    for (int i = 5; i <= 12; i++) sizes.Add(Last[i]);
    return "OK|" + string.Join(",", sizes);
  }

  public static string Apply(int mode, int r, int g, int b, int speed, int swap) {
    int[] rr = new int[8], gg = new int[8], bb = new int[8];
    for (int z = 0; z < 8; z++) { rr[z] = r; gg[z] = g; bb[z] = b; }
    return ApplyZones(mode, speed, swap, rr, gg, bb);
  }

  public static string ApplyZones(int mode, int speed, int swap, int[] rr, int[] gg, int[] bb) {
    string err;
    for (byte z = 0; z < 8; z++) {
      bool rgswap = (swap & (1 << z)) != 0;
      int r = rr != null && z < rr.Length ? rr[z] : 0;
      int g = gg != null && z < gg.Length ? gg[z] : 0;
      int b = bb != null && z < bb.Length ? bb[z] : 0;
      var cmd = new byte[65];
      cmd[0] = 0; cmd[1] = 0x10; cmd[3] = z; cmd[4] = (byte)mode;
      cmd[5] = (byte)(rgswap ? r : g); cmd[6] = (byte)(rgswap ? g : r); cmd[7] = (byte)b;
      cmd[8] = (byte)speed; cmd[9] = 0xFF; cmd[16] = 0;
      if (!Send(cmd, out err)) return err;
    }
    if (!Send(Cmd(0x12, 0), out err)) return err;
    return "OK";
  }

  public static string Status() {
    var parts = new List<string>();
    string err;
    for (byte z = 0; z < 8; z++) {
      if (!Send(Cmd(0x11, z), out err)) return err;
      parts.Add(z + "," + Last[5] + "," + Last[6] + "," + Last[7] + "," + Last[8] + "," + Last[9]);
    }
    return "OK|" + string.Join(";", parts);
  }

  public static string Off() { return Apply(0, 0, 0, 0, 0, 0); }

  public static void Close() {
    try { H.Dispose(); } catch { }
    H = null;
  }
}
'@

$init = [AsrockHid]::Open()
if (-not $init.StartsWith('OK')) {
  @{ ok = $false; error = $init } | ConvertTo-Json -Compress
  exit 1
}
$sizes = ($init.Substring(3) -split ',') | ForEach-Object { [int]$_ }
$board = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
$name = if ($board) { (($board.Manufacturer + ' ' + $board.Product) -replace '\s+', ' ').Trim() } else { 'ASRock RGB Controller' }
@{ ok = $true; name = $name; sizes = $sizes; zones = $sizes.Count } | ConvertTo-Json -Compress

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  try {
    $msg = $line | ConvertFrom-Json
    $cmd = [string]$msg.cmd
    if ($cmd -eq 'status') {
      $r = [AsrockHid]::Status()
      if ($r.StartsWith('OK')) {
        $zones = @()
        foreach ($z in ($r.Substring(3) -split ';')) {
          $p = $z -split ','
          $zones += @{ zone = [int]$p[0]; mode = [int]$p[1]; r = [int]$p[3]; g = [int]$p[2]; b = [int]$p[4]; speed = [int]$p[5] }
        }
        @{ ok = $true; zones = $zones } | ConvertTo-Json -Compress -Depth 4
      } else {
        @{ ok = $false; error = $r } | ConvertTo-Json -Compress
      }
    } elseif ($cmd -eq 'apply') {
      $zones = @($msg.zones)
      if ($zones.Count -eq 8) {
        $rr = @($zones | ForEach-Object { [int]$_.r })
        $gg = @($zones | ForEach-Object { [int]$_.g })
        $bb = @($zones | ForEach-Object { [int]$_.b })
        $r = [AsrockHid]::ApplyZones([int]$msg.mode, [int]$msg.speed, [int]$msg.swap, [int[]]$rr, [int[]]$gg, [int[]]$bb)
      } else {
        $r = [AsrockHid]::Apply([int]$msg.mode, [int]$msg.r, [int]$msg.g, [int]$msg.b, [int]$msg.speed, [int]$msg.swap)
      }
      @{ ok = ($r -eq 'OK'); error = $r } | ConvertTo-Json -Compress
    } elseif ($cmd -eq 'off') {
      $r = [AsrockHid]::Off()
      @{ ok = ($r -eq 'OK'); error = $r } | ConvertTo-Json -Compress
    } elseif ($cmd -eq 'quit') {
      [AsrockHid]::Close()
      @{ ok = $true } | ConvertTo-Json -Compress
      break
    } else {
      @{ ok = $false; error = 'UNKNOWN_COMMAND' } | ConvertTo-Json -Compress
    }
  } catch {
    @{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress
  }
}
