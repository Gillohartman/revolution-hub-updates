'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('docs', {
  recents: () => ipcRenderer.invoke('recents'),
  open: (file) => ipcRenderer.invoke('open', file),
  saveAs: (name, format) => ipcRenderer.invoke('saveAs', { name, format }),
  write: (payload) => ipcRenderer.invoke('write', payload),
  pdf: (name) => ipcRenderer.invoke('pdf', name),
  print: () => ipcRenderer.invoke('print'),
  image: () => ipcRenderer.invoke('image'),
  screenshots: () => ipcRenderer.invoke('screenshots'),
  screenshotData: (file) => ipcRenderer.invoke('screenshot:data', file),
  reveal: (file) => ipcRenderer.invoke('reveal', file),
  saveDraft: (draft) => ipcRenderer.invoke('draft:save', draft),
  loadDraft: () => ipcRenderer.invoke('draft:load'),
  stt: {
    status: () => ipcRenderer.invoke('stt:status'),
    install: () => ipcRenderer.invoke('stt:install'),
    transcribe: (bytes, lang) => ipcRenderer.invoke('stt:transcribe', bytes, lang),
    onProgress: (cb) => ipcRenderer.on('stt:progress', (_e, s) => cb(s)),
  },
  fixText: (text, lang) => ipcRenderer.invoke('fix:text', text, lang),
});
