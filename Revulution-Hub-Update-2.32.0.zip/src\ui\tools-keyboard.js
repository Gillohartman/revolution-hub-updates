'use strict';

/*
 * Tastatur: Tasten umbelegen (Taste, Kombination, Text, Programm/Webseite, Medien, Makro, aus),
 * Profile pro Spiel/App, Tastentest mit Prell-Erkennung, Geräte + Licht/Display über die
 * Herstellerprogramme.
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const active = () => ctx().state()?.active === 'tool-keyboard';
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

  /* Tastennamen für die Anzeige */
  const NAMES = {
    Space: 'Leertaste', Enter: 'Enter', NumpadEnter: 'Num Enter', Tab: 'Tab', Escape: 'Esc', Backspace: '⌫', Delete: 'Entf', Insert: 'Einfg', Home: 'Pos1', End: 'Ende', PageUp: 'Bild ↑', PageDown: 'Bild ↓',
    ArrowLeft: '←', ArrowUp: '↑', ArrowRight: '→', ArrowDown: '↓', ShiftLeft: 'Shift', ShiftRight: 'Shift R', ControlLeft: 'Strg', ControlRight: 'Strg R', AltLeft: 'Alt', AltRight: 'AltGr',
    MetaLeft: 'Win', MetaRight: 'Win R', ContextMenu: 'Menü', CapsLock: 'Feststell', NumLock: 'Num', ScrollLock: 'Rollen', Pause: 'Pause', PrintScreen: 'Druck',
    Comma: ',', Period: '.', Minus: 'ß', Equal: '´', Semicolon: 'Ü', Slash: '-', Backquote: '^', BracketLeft: 'ü', BracketRight: '+', Backslash: '#', Quote: 'Ä', IntlBackslash: '<',
    NumpadMultiply: 'Num *', NumpadAdd: 'Num +', NumpadSubtract: 'Num -', NumpadDecimal: 'Num ,', NumpadDivide: 'Num /',
    MediaPlayPause: '⏯', MediaTrackNext: '⏭', MediaTrackPrevious: '⏮', AudioVolumeMute: '🔇', AudioVolumeDown: '🔉', AudioVolumeUp: '🔊',
  };
  const keyName = (code) => {
    if (!code) return '–';
    if (NAMES[code]) return NAMES[code];
    let m;
    if ((m = /^Key([A-Z])$/.exec(code))) return m[1] === 'Y' ? 'Y' : m[1];
    if ((m = /^Digit(\d)$/.exec(code))) return m[1];
    if ((m = /^Numpad(\d)$/.exec(code))) return `Num ${m[1]}`;
    return code;
  };
  // DE-Layout: Y und Z sind vertauscht – KeyboardEvent.code nennt die US-Position
  const deName = (code) => (code === 'KeyZ' ? 'Y' : code === 'KeyY' ? 'Z' : keyName(code));

  const TYPES = [
    ['key', 'Andere Taste'],
    ['combo', 'Tastenkombination'],
    ['text', 'Text schreiben'],
    ['run', 'Programm / Webseite'],
    ['media', 'Medien & Lautstärke'],
    ['macro', 'Makro'],
    ['off', 'Ausschalten'],
  ];
  const MEDIA = [
    ['play', 'Play / Pause'],
    ['next', 'Nächster Titel'],
    ['prev', 'Vorheriger Titel'],
    ['stop', 'Stopp'],
    ['mute', 'Stumm'],
    ['volup', 'Lauter'],
    ['voldown', 'Leiser'],
  ];
  const PRESETS = [
    ['FortniteClient-Win64-Shipping', 'Fortnite'],
    ['cs2', 'Counter-Strike 2'],
    ['javaw', 'Minecraft'],
    ['RobloxPlayerBeta', 'Roblox'],
    ['ReadyOrNot-Win64-Shipping', 'Ready or Not'],
    ['Discord', 'Discord'],
    ['chrome', 'Chrome'],
  ];

  const kb = { cfg: null, tab: 'light', prof: 0, status: null, devs: null, capture: null, rec: null, test: { down: new Set(), seen: new Set(), last: null, lastUp: {}, chatter: [] }, saveTimer: 0, newApp: '' };
  const cfg = () => {
    if (!kb.cfg) {
      const s = ctx().state()?.settings?.keyboard || {};
      kb.cfg = { enabled: s.enabled === true, profiles: Array.isArray(s.profiles) && s.profiles.length ? JSON.parse(JSON.stringify(s.profiles)) : [{ id: 'global', name: 'Überall', apps: [], on: true, rules: [] }] };
    }
    return kb.cfg;
  };
  const save = (now = false) => {
    clearTimeout(kb.saveTimer);
    kb.saveTimer = setTimeout(async () => {
      try {
        await ctx().settings({ keyboard: cfg() });
        kb.status = await window.hub.keyboard.apply();
        if (active()) paintStatus();
      } catch (error) {
        ctx().toast(errText(error), 'error');
      }
    }, now ? 0 : 400);
  };
  const prof = () => cfg().profiles[Math.min(kb.prof, cfg().profiles.length - 1)];

  window.hub.onKeyboard?.((st) => {
    kb.status = st;
    if (active()) paintStatus();
  });

  function paintStatus() {
    const el = document.getElementById('kb-status');
    if (el) el.innerHTML = statusHtml();
  }
  function statusHtml() {
    const s = kb.status;
    const c = cfg();
    if (!c.enabled) return '<span class="pill">Aus</span>';
    if (!s) return '<span class="pill">…</span>';
    if (s.error) return `<span class="pill warn">${esc(s.error)}</span>`;
    if (!s.rules) return '<span class="pill">Noch keine Regeln</span>';
    return `<span class="pill ok">Aktiv · ${s.rules} ${s.rules === 1 ? 'Regel' : 'Regeln'}${s.hits ? ` · ${s.hits}× ausgelöst` : ''}</span>`;
  }

  /* ---------------------------------------------------------------- Ziel-Editor einer Regel */
  function targetHtml(r, i) {
    const cap = (what, label) => `<button class="btn small kb-cap ${kb.capture?.i === i && kb.capture?.what === what ? 'listening' : ''}" data-kb-cap="${what}" data-i="${i}">${kb.capture?.i === i && kb.capture?.what === what ? 'Taste drücken …' : label}</button>`;
    switch (r.type) {
      case 'key':
        return cap('to', r.to ? esc(deName(r.to)) : 'Taste wählen');
      case 'combo':
        return cap('combo', Array.isArray(r.to) && r.to.length ? esc(r.to.map(deName).join(' + ')) : 'Kombination drücken');
      case 'text':
        return `<input class="input" data-kb-to="${i}" placeholder="z. B. gg ez" value="${esc(r.to)}" />`;
      case 'run':
        return `<input class="input" data-kb-to="${i}" placeholder="https://… oder C:\\Programm.exe" value="${esc(r.to)}" />`;
      case 'media':
        return `<select class="select" data-kb-to="${i}">${MEDIA.map(([v, n]) => `<option value="${v}" ${r.to === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
      case 'macro': {
        const steps = Array.isArray(r.to) ? r.to : [];
        const rec = kb.rec?.i === i;
        const summary = steps.length ? steps.filter((s) => s.key && s.act !== 'up').slice(0, 8).map((s) => deName(s.key)).join(' · ') + (steps.filter((s) => s.key && s.act !== 'up').length > 8 ? ' …' : '') : 'Noch leer';
        return `<span class="kb-macro"><button class="btn small ${rec ? 'danger' : ''}" data-kb-rec="${i}">${rec ? `■ Stopp (${kb.rec.steps.length})` : '● Aufnehmen'}</button><small class="muted">${esc(summary)}</small></span>`;
      }
      default:
        return '<small class="muted">Taste macht nichts mehr</small>';
    }
  }

  function keysHtml() {
    const c = cfg();
    const p = prof();
    const chips = c.profiles
      .map((x, i) => `<button class="kb-chip ${i === kb.prof ? 'on' : ''} ${x.on ? '' : 'off'}" data-kb-prof="${i}">${esc(x.name)}${x.apps.length ? '' : ' 🌐'}</button>`)
      .join('');
    const rules = p.rules.length
      ? p.rules
          .map(
            (r, i) => `<div class="kb-rule ${r.on ? '' : 'dim'}">
          <button class="btn small kb-cap kb-from ${kb.capture?.i === i && kb.capture?.what === 'from' ? 'listening' : ''}" data-kb-cap="from" data-i="${i}">${kb.capture?.i === i && kb.capture?.what === 'from' ? 'Taste drücken …' : r.from ? esc(deName(r.from)) : 'Taste wählen'}</button>
          <span class="kb-arrow">→</span>
          <select class="select kb-type" data-kb-type="${i}">${TYPES.map(([v, n]) => `<option value="${v}" ${r.type === v ? 'selected' : ''}>${n}</option>`).join('')}</select>
          <span class="kb-target">${targetHtml(r, i)}</span>
          <button class="switch ${r.on ? 'on' : ''}" data-kb-ruleon="${i}" title="An/Aus"></button>
          <button class="icon-btn" data-kb-del="${i}" title="Löschen">✕</button>
        </div>`,
          )
          .join('')
      : '<p class="muted kb-empty">Noch keine Regel. Leg mit „+ Regel“ los – z. B. Feststelltaste → Shift oder F1 → „gg ez“ schreiben.</p>';
    return `<div class="tool-card">
        <div class="list-row"><div class="grow"><strong>Tasten-Umbelegung</strong><small>Gilt für jede angeschlossene Tastatur. Aus = alle Tasten wieder normal.</small></div><span id="kb-status">${statusHtml()}</span><button class="switch ${c.enabled ? 'on' : ''}" data-kb-master></button></div>
      </div>
      <div class="tool-card">
        <div class="kb-chips">${chips}<button class="kb-chip add" data-kb-addprof>+ Profil für Spiel/App</button></div>
        ${
          p.apps.length
            ? `<div class="list-row"><div class="grow"><strong>${esc(p.name)}</strong><small>Nur aktiv, wenn ${p.apps.map((a) => `<b>${esc(a)}</b>`).join(', ')} im Vordergrund ist – sonst gilt „Überall“.</small></div><button class="switch ${p.on ? 'on' : ''}" data-kb-profon></button><button class="btn small" data-kb-delprof>Profil löschen</button></div>`
            : '<small class="muted">Profil „Überall“: gilt in allen Programmen. Spiel-Profile haben Vorrang, solange das Spiel vorne ist.</small>'
        }
        ${
          kb.newApp !== ''
            ? `<div class="kb-newprof"><input class="input" id="kb-app" placeholder="Programmname, z. B. FortniteClient-Win64-Shipping" value="${esc(kb.newApp === ' ' ? '' : kb.newApp)}" /><button class="btn small primary" data-kb-createprof>Anlegen</button><button class="btn small" data-kb-cancelprof>Abbrechen</button>
               <div class="kb-presets">${PRESETS.map(([exe, n]) => `<button class="kb-chip" data-kb-preset="${exe}" data-name="${esc(n)}">${esc(n)}</button>`).join('')}</div></div>`
            : ''
        }
        <div class="kb-rules">${rules}</div>
        <div><button class="btn small primary" data-kb-addrule>+ Regel</button></div>
      </div>
      <p class="muted tool-note">Tipp: Tasten wie F13–F24 oder Makro-Tasten deiner Tastatur kannst du hier frei belegen. Läuft ein Spiel als Administrator, muss auch der Hub als Administrator laufen, damit die Umbelegung dort greift.</p>`;
  }

  /* ---------------------------------------------------------------- Tastentest */
  const ROWS = [
    ['Escape', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12', 'PrintScreen', 'Delete'],
    ['Backquote', 'Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5', 'Digit6', 'Digit7', 'Digit8', 'Digit9', 'Digit0', 'Minus', 'Equal', 'Backspace:2', 'Home'],
    ['Tab:1.5', 'KeyQ', 'KeyW', 'KeyE', 'KeyR', 'KeyT', 'KeyY', 'KeyU', 'KeyI', 'KeyO', 'KeyP', 'BracketLeft', 'BracketRight', 'Enter:1.5', 'PageUp'],
    ['CapsLock:1.75', 'KeyA', 'KeyS', 'KeyD', 'KeyF', 'KeyG', 'KeyH', 'KeyJ', 'KeyK', 'KeyL', 'Semicolon', 'Quote', 'Backslash', 'PageDown:1.25'],
    ['ShiftLeft:1.25', 'IntlBackslash', 'KeyZ', 'KeyX', 'KeyC', 'KeyV', 'KeyB', 'KeyN', 'KeyM', 'Comma', 'Period', 'Slash', 'ShiftRight:1.75', 'ArrowUp', 'End'],
    ['ControlLeft:1.25', 'MetaLeft:1.25', 'AltLeft:1.25', 'Space:6.25', 'AltRight', 'ControlRight', 'ArrowLeft', 'ArrowDown', 'ArrowRight'],
  ];
  function testHtml() {
    const t = kb.test;
    const board = ROWS.map(
      (row) =>
        `<div class="kb-row">${row
          .map((k) => {
            const [code, w] = k.split(':');
            return `<span class="kb-key ${t.down.has(code) ? 'down' : t.seen.has(code) ? 'seen' : ''}" data-code="${code}" style="flex:${w || 1}">${esc(deName(code))}</span>`;
          })
          .join('')}</div>`,
    ).join('');
    const l = t.last;
    return `<div class="tool-card"><div class="list-row"><div class="grow"><strong>Tastentest</strong><small>Drück jede Taste einmal – geprüfte Tasten werden grün. Prellende (doppelt auslösende) Tasten werden rot gemeldet.</small></div><button class="btn small" data-kb-testreset>Zurücksetzen</button></div>
      <div class="kb-board" id="kb-board">${board}</div>
      <div class="kb-info" id="kb-info">${l ? `Zuletzt: <b>${esc(deName(l.code))}</b> · Code <code>${esc(l.code)}</code> · Zeichen <code>${esc(l.key)}</code> · gehalten ${l.held} ms` : 'Noch keine Taste gedrückt.'} · ${t.seen.size} Tasten geprüft</div>
      ${t.chatter.length ? `<p class="err">Prellen erkannt bei: ${[...new Set(t.chatter)].map((c) => esc(deName(c))).join(', ')} – die Taste hat sehr schnell doppelt ausgelöst (Schalter evtl. defekt oder verschmutzt).</p>` : ''}</div>`;
  }

  /* ---------------------------------------------------------------- Geräte, Licht & Display */
  async function loadDevs() {
    try {
      kb.devs = await window.hub.keyboard.devices();
    } catch {
      kb.devs = { keyboards: [], tools: [] };
    }
    if (active()) ctx().render();
  }
  /* AJAZZ direkt: Licht, Display, Uhr, Schlafmodus */
  const aj = { probe: null, probing: false, modes: null, busy: '', progress: 0, frames: null, preview: '', slot: 1, battery: null, msg: '', source: 'file', autoPreview: false, loading: false, gen: 0, thumbs: {}, thumbsLoading: false, thumbsAll: false };

  /* ---------------------------------------------------------------- Display-Studio */
  const scr = { feed: [], lastAuto: 0, uploading: false };
  const SCR_PRESETS = [
    ['clock', 'Uhr'],
    ['text', 'Text'],
    ['messages', 'Revulutionland'],
    ['rainbow', 'Regenbogen'],
    ['pulse', 'Puls'],
    ['pc', 'PC-Werte'],
  ];
  /* Mitgelieferte Standard-GIFs (src/ui/assets/gifs) */
  const AJ_GIFS = [
    ['wireframe', 'Wireframe'],
    ['pixel', 'Pixel'],
    ['mini', 'Mini'],
  ];
  const gifCache = new Map();
  const screenCfg = () => {
    if (!aj.screen) {
      aj.screen = { preset: 'clock', text: 'Revulution Hub', slot: 1, color: '#8b6cff', autoMessages: false, autoClock: false, ...(ctx().state()?.settings?.screen || {}) };
      if ([1, 2, 3].includes(Number(aj.screen.slot))) aj.slot = Number(aj.screen.slot);
    }
    return aj.screen;
  };
  const screenSave = () => {
    try {
      ctx().settings({ screen: screenCfg() });
    } catch {
      /* egal */
    }
  };

  function screenCanvas() {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 128;
    return { canvas, g: canvas.getContext('2d', { willReadFrequently: true }) };
  }
  /** RGB565-Bild als kleines Vorschaubild für die Vorlagen-Kacheln. */
  function frameThumb(rgb565) {
    const { canvas, g } = screenCanvas();
    const img = g.createImageData(128, 128);
    const src = rgb565 || [];
    for (let i = 0, o = 0; i < 128 * 128; i++, o += 2) {
      const v = (src[o] || 0) | ((src[o + 1] || 0) << 8);
      img.data[i * 4] = ((v >> 11) & 31) * 255 / 31;
      img.data[i * 4 + 1] = ((v >> 5) & 63) * 255 / 63;
      img.data[i * 4 + 2] = (v & 31) * 255 / 31;
      img.data[i * 4 + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    return canvas.toDataURL('image/png');
  }
  async function presetThumbs() {
    if (aj.thumbsLoading || aj.thumbsAll) return;
    aj.thumbsLoading = true;
    const saved = { preview: aj.preview, loading: aj.loading, frames: aj.frames, source: aj.source };
    aj.loading = true;
    try {
      for (const [kind] of SCR_PRESETS) {
        if (aj.thumbs[kind]) continue;
        try {
          const frames = await presetFrames(kind, aj.gen);
          if (frames[0]?.rgb565) aj.thumbs[kind] = frameThumb(frames[0].rgb565);
        } catch {
          /* einzelne Vorlage ohne Vorschau */
        }
      }
    } finally {
      aj.loading = saved.loading;
      aj.preview = saved.preview;
      aj.frames = saved.frames;
      aj.source = saved.source;
      aj.thumbsLoading = false;
      aj.thumbsAll = true;
    }
    if (active() && kb.tab === 'light') ctx().render();
  }
  /** Canvas → RGB565 (little endian), wie es die Tastatur erwartet. */
  function screen565(g) {
    const px = g.getImageData(0, 0, 128, 128).data;
    const out = new Uint8Array(128 * 128 * 2);
    for (let i = 0, o = 0; i < px.length; i += 4, o += 2) {
      const v = ((px[i] >> 3) << 11) | ((px[i + 1] >> 2) << 5) | (px[i + 2] >> 3);
      out[o] = v & 255;
      out[o + 1] = v >> 8;
    }
    return out;
  }
  function screenCover(g, src, w, h) {
    const s = Math.max(128 / w, 128 / h);
    g.fillStyle = '#000';
    g.fillRect(0, 0, 128, 128);
    g.drawImage(src, (128 - w * s) / 2, (128 - h * s) / 2, w * s, h * s);
  }
  /** Text auf die Breite umbrechen. */
  function scrWrap(g, text, max) {
    const words = String(text || '').trim().split(/\s+/).filter(Boolean);
    const lines = [];
    let line = '';
    for (const w of words) {
      const t = line ? `${line} ${w}` : w;
      if (g.measureText(t).width > max && line) {
        lines.push(line);
        line = w;
      } else line = t;
    }
    if (line) lines.push(line);
    return lines.length ? lines : [''];
  }
  const scrBase = (g, color) => {
    const bg = g.createLinearGradient(0, 0, 0, 128);
    bg.addColorStop(0, '#0b0b16');
    bg.addColorStop(1, '#000');
    g.fillStyle = bg;
    g.fillRect(0, 0, 128, 128);
    g.strokeStyle = color;
    g.globalAlpha = 0.55;
    g.lineWidth = 2;
    g.strokeRect(3, 3, 122, 122);
    g.globalAlpha = 1;
    g.textAlign = 'left';
  };
  const FONT = '"Segoe UI", system-ui, sans-serif';

  /** Vorlagen als fertige Bildfolge (128×128) zeichnen. */
  async function presetFrames(kind, gen = aj.gen) {
    if (String(kind).startsWith('gif:')) {
      const gif = await ajGifFrames(String(kind).slice(4));
      if (!aj.loading && gen === aj.gen && !aj.preview) aj.preview = gif.preview;
      return gif.frames;
    }
    const s = screenCfg();
    const color = s.color || '#8b6cff';
    const frames = [];
    if (gen === aj.gen) aj.preview = '';
    const add = (canvas, g, delay) => {
      if (!aj.loading && gen === aj.gen && !aj.preview) aj.preview = canvas.toDataURL();
      frames.push({ delay, rgb565: screen565(g) });
    };

    if (kind === 'rainbow') {
      for (let i = 0; i < 20; i++) {
        const { canvas, g } = screenCanvas();
        for (let x = 0; x < 128; x++) {
          g.fillStyle = `hsl(${(i * 18 + x * 2.2) % 360} 92% 55%)`;
          g.fillRect(x, 0, 1, 128);
        }
        g.fillStyle = 'rgba(0,0,0,0.5)';
        g.fillRect(0, 92, 128, 36);
        g.fillStyle = '#fff';
        g.textAlign = 'center';
        g.font = `700 12px ${FONT}`;
        g.fillText('REVULUTION', 64, 114);
        add(canvas, g, 90);
      }
      return frames;
    }

    if (kind === 'pulse') {
      for (let i = 0; i < 16; i++) {
        const { canvas, g } = screenCanvas();
        g.fillStyle = '#000';
        g.fillRect(0, 0, 128, 128);
        const k = 0.5 - 0.5 * Math.cos((i / 16) * Math.PI * 2);
        const r = 24 + k * 38;
        const rg = g.createRadialGradient(64, 64, Math.max(1, r * 0.3), 64, 64, r);
        rg.addColorStop(0, color);
        rg.addColorStop(1, 'rgba(0,0,0,0)');
        g.globalAlpha = 0.5 + 0.5 * k;
        g.fillStyle = rg;
        g.beginPath();
        g.arc(64, 64, r, 0, Math.PI * 2);
        g.fill();
        g.globalAlpha = 1;
        g.fillStyle = 'rgba(255,255,255,0.8)';
        g.textAlign = 'center';
        g.font = `700 11px ${FONT}`;
        g.fillText('REVULUTION', 64, 118);
        add(canvas, g, 80);
      }
      return frames;
    }

    if (kind === 'messages') {
      const list = scr.feed.slice(0, 2);
      const { canvas, g } = screenCanvas();
      g.fillStyle = '#05050c';
      g.fillRect(0, 0, 128, 128);
      g.textAlign = 'left';
      g.fillStyle = color;
      g.font = `700 10px ${FONT}`;
      g.fillText('REVULUTIONLAND', 8, 15);
      g.fillStyle = 'rgba(255,255,255,0.18)';
      g.fillRect(8, 20, 112, 1);
      if (!list.length) {
        g.fillStyle = '#8b8b9e';
        g.font = `500 11px ${FONT}`;
        g.fillText('Noch keine Nachrichten', 10, 64);
        g.fillStyle = 'rgba(255,255,255,0.45)';
        g.font = `500 9px ${FONT}`;
        g.fillText('Im Hub unter Chats schreiben.', 10, 80);
      }
      let y = 36;
      for (const m of list) {
        if (y > 116) break;
        g.fillStyle = 'rgba(255,255,255,0.6)';
        g.font = `700 9px ${FONT}`;
        g.fillText(String(m.from || '?').slice(0, 15) + (m.chat ? ` · ${String(m.chat).slice(0, 9)}` : ''), 8, y);
        y += 12;
        g.fillStyle = '#fff';
        g.font = `500 11px ${FONT}`;
        for (const line of scrWrap(g, m.text, 112).slice(0, 3)) {
          if (y > 122) break;
          g.fillText(line, 8, y);
          y += 12;
        }
        y += 5;
      }
      add(canvas, g, 0);
      return frames;
    }

    if (kind === 'pc') {
      let live = null;
      try {
        live = await window.hub.pcLive();
      } catch {
        live = null;
      }
      const { canvas, g } = screenCanvas();
      scrBase(g, color);
      g.fillStyle = color;
      g.fillText('PC LIVE', 10, 18);
      const row = (label, value, y) => {
        const v = Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
        g.fillStyle = 'rgba(255,255,255,0.6)';
        g.font = `700 10px ${FONT}`;
        g.fillText(label, 10, y);
        g.textAlign = 'right';
        g.fillStyle = '#fff';
        g.font = `600 9px ${FONT}`;
        g.fillText(`${v}%`, 118, y);
        g.textAlign = 'left';
        g.fillStyle = 'rgba(255,255,255,0.12)';
        g.fillRect(10, y + 5, 108, 8);
        const grad = g.createLinearGradient(10, 0, 118, 0);
        grad.addColorStop(0, color);
        grad.addColorStop(1, '#00d5ff');
        g.fillStyle = grad;
        g.fillRect(10, y + 5, Math.max(2, (108 * v) / 100), 8);
      };
      row('CPU', live?.cpu, 34);
      row('RAM', live?.ramPct, 72);
      row('GPU', live?.gpu == null ? 0 : live.gpu, 110);
      if (live?.gpu == null) {
        g.fillStyle = 'rgba(255,255,255,0.35)';
        g.font = `500 8px ${FONT}`;
        g.textAlign = 'right';
        g.fillText('GPU n/a', 118, 118);
      }
      add(canvas, g, 0);
      return frames;
    }

    if (kind === 'text') {
      const text = s.text || 'Revulution Hub';
      const probe = screenCanvas();
      probe.g.font = `600 15px ${FONT}`;
      const lines = scrWrap(probe.g, text, 104);
      const total = lines.length * 19;
      const paint = (g, offset) => {
        scrBase(g, color);
        g.save();
        g.beginPath();
        g.rect(6, 20, 116, 92);
        g.clip();
        g.fillStyle = '#fff';
        g.font = `600 15px ${FONT}`;
        lines.forEach((line, i) => g.fillText(line, 10, 32 + i * 19 - offset));
        g.restore();
      };
      if (total <= 94) {
        const { canvas, g } = screenCanvas();
        paint(g, 0);
        add(canvas, g, 0);
      } else {
        for (let i = 0; i < 18; i++) {
          const { canvas, g } = screenCanvas();
          paint(g, (i / 18) * (total - 70));
          add(canvas, g, 110);
        }
      }
      return frames;
    }

    /* Uhr (Standard) */
    const { canvas, g } = screenCanvas();
    const now = new Date();
    scrBase(g, color);
    g.textAlign = 'center';
    g.fillStyle = color;
    g.font = `bold 38px ${FONT}`;
    g.fillText(`${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`, 64, 66);
    g.fillStyle = 'rgba(255,255,255,0.8)';
    g.font = `600 12px ${FONT}`;
    g.fillText(now.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit' }), 64, 88);
    g.fillStyle = 'rgba(255,255,255,0.42)';
    g.font = `700 9px ${FONT}`;
    g.fillText('REVULUTION HUB', 64, 110);
    add(canvas, g, 0);
    return frames;
  }

  async function screenPreview(kind) {
    const s = screenCfg();
    s.preset = kind;
    screenSave();
    const gen = ++aj.gen;
    const isGif = String(kind).startsWith('gif:');
    if (isGif) {
      aj.loading = true;
      aj.msg = 'GIF wird für die Vorschau vorbereitet …';
      if (active()) ctx().render();
    }
    try {
      const frames = await presetFrames(kind, gen);
      if (gen !== aj.gen) return;
      aj.frames = frames;
      aj.source = 'preset';
      aj.msg = '';
    } catch (error) {
      ctx().toast(errText(error), 'error');
    } finally {
      if (gen === aj.gen) aj.loading = false;
    }
    if (active()) ctx().render();
  }

  /** Neuen Chat-Beitrag fürs Display nachladen (nur im Kabelmodus, gedrosselt). */
  async function screenAuto(kind) {
    const s = screenCfg();
    if (aj.busy || aj.loading || scr.uploading || aj.probe?.mode !== 'cable') return;
    // Ein selbst hochgeladenes Bild/GIF bleibt stehen, bis wieder eine Vorlage gewählt wird.
    if (aj.source === 'file') return;
    // Ein ausgewähltes GIF wird nicht von Uhr oder Nachrichten überschrieben.
    if (String(s.preset).startsWith('gif:')) return;
    if (Date.now() - scr.lastAuto < 20000) return;
    scr.lastAuto = Date.now();
    scr.uploading = true;
    aj.busy = 'tft';
    aj.progress = 0;
    try {
      const frames = await presetFrames(kind);
      await window.hub.ajazz.tft(frames, s.slot);
    } catch {
      /* Tastatur evtl. gerade nicht bereit – beim nächsten Mal neu */
    }
    aj.busy = '';
    scr.uploading = false;
    // Der Upload selbst ändert keine sichtbare Beschriftung – kein Neuaufbau der Seite.
  }

  window.hub.ajazz?.feed?.().then((list) => {
    scr.feed = Array.isArray(list) ? list : [];
    if (active() && kb.tab === 'light') ctx().render();
  }).catch(() => {});
  const inField = () => /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '');
  window.hub.onAjazzFeed?.((item) => {
    if (!item?.text) return;
    scr.feed = [item, ...scr.feed.filter((m) => !(m.at === item.at && m.from === item.from))].slice(0, 20);
    if (active() && kb.tab === 'light' && !inField()) paintFeed();
    if (screenCfg().autoMessages) {
      clearTimeout(scr.msgTimer);
      scr.msgTimer = setTimeout(() => screenAuto('messages'), 3500);
    }
  });

  /* Uhr/Nachrichten automatisch aktuell halten, auch wenn die Seite geschlossen ist. */
  /** Nur die Nachrichtenvorschau aktualisieren, damit die Seite nicht neu aufgebaut wird. */
  function paintFeed() {
    const box = document.querySelector('.scr-feed');
    if (!box) return;
    box.innerHTML = scr.feed.length
      ? scr.feed.slice(0, 3).map((m) => `<div class="scr-msg"><b>${esc(m.from || '?')}</b>${m.chat ? `<small class="muted"> · ${esc(m.chat)}</small>` : ''}<div>${esc(String(m.text).slice(0, 120))}</div></div>`).join('')
      : '<p class="muted">Noch keine Nachrichten aus den Hub-Chats. Sobald jemand im „Revulutionland“-Chat schreibt, erscheint es hier und – wenn eingeschaltet – auf dem Display.</p>';
  }
  setInterval(() => {
    const s = screenCfg();
    if (s.autoClock) {
      if (aj.probe?.mode === 'cable') screenAuto('clock');
      else if (!aj.probe && !aj.probing) ajProbe();
    }
  }, 30000);
  setTimeout(() => {
    const s = screenCfg();
    if ((s.autoClock || s.autoMessages) && !aj.probe) ajProbe();
  }, 12000);

  window.hub.onAjazzProgress?.((p) => {
    aj.progress = p;
    const bar = document.getElementById('aj-bar');
    if (bar) bar.style.width = `${Math.round(p * 100)}%`;
  });
  const ajCfg = () => {
    if (!aj.cfg) aj.cfg = { mode: 1, color: '#8b6cff', brightness: 4, speed: 3, direction: 0, colorful: false, sleep: 5, ...(ctx().state()?.settings?.ajazz || {}) };
    return aj.cfg;
  };
  async function ajProbe() {
    if (aj.probing) return;
    aj.probing = true;
    const prevProbe = JSON.stringify(aj.probe || null);
    const prevBattery = aj.battery;
    try {
      [aj.probe, aj.modes] = await Promise.all([window.hub.ajazz.probe(), aj.modes || window.hub.ajazz.modes()]);
      if (aj.probe?.mode === 'cable' || aj.probe?.mode === 'dongle') aj.battery = await window.hub.ajazz.battery().catch(() => null);
      // Gespeicherte Display-Vorlage einmal vorbereiten, damit „Aufs Display laden“ sofort geht
      if (aj.probe?.mode === 'cable' && !aj.frames && !aj.autoPreview) {
        aj.autoPreview = true;
        // Kein neuer gen-Zähler: ein gerade laufender Upload darf nicht verworfen werden.
        const gen = aj.gen;
        presetFrames(screenCfg().preset, gen)
          .then((frames) => {
            if (gen !== aj.gen || aj.loading || aj.frames) return;
            aj.frames = frames;
            aj.source = 'preset';
            if (active() && (kb.tab === 'light' || kb.tab === 'rgb')) ctx().render();
          })
          .catch(() => {});
      }
    } catch (error) {
      aj.probe = { mode: 'error', error: errText(error) };
    }
    aj.probing = false;
    if (active() && (kb.tab === 'light' || kb.tab === 'rgb') && (prevProbe !== JSON.stringify(aj.probe || null) || prevBattery !== aj.battery)) ctx().render();
  }
  const SWATCHES = ['#ffffff', '#ff3b3b', '#ff8a00', '#ffd400', '#2ee66b', '#00d5ff', '#3b82f6', '#8b6cff', '#ff4fd8'];
  const DIRS = [['0', '←'], ['2', '↑'], ['1', '↓'], ['3', '→']];

  function ajazzHtml() {
    if (!aj.probe) {
      ajProbe();
      return '<div class="tool-card"><p class="muted">Suche deine AJAZZ-Tastatur …</p></div>';
    }
    if (aj.probe.mode === 'cable' && !aj.thumbsAll && !aj.thumbsLoading) setTimeout(presetThumbs, 60);
    const st = aj.probe;
    if (st.mode !== 'cable' && st.mode !== 'dongle')
      return `<div class="tool-card aj-wait"><div class="aj-hero"><span class="aj-ic">⌨️</span><div><b>Keine AJAZZ AK820 Pro gefunden</b>
        <small class="muted">${st.error ? esc(st.error) : 'Dongle einstecken (Schalter auf 2.4G) oder per USB-C-Kabel anstecken (Schalter in die Mitte).'}</small></div></div>
        <button class="btn primary" data-aj="probe">${aj.probing ? 'Suche …' : 'Erneut suchen'}</button></div>`;
    const c = ajCfg();
    const modes = (aj.modes || []).map(([v, n]) => `<button class="aj-mode ${c.mode === v ? 'on' : ''}" data-aj-mode="${v}">${esc(n)}</button>`).join('');
    const dis = aj.busy ? 'disabled' : '';
    const sc = screenCfg();
    const gifId = String(sc.preset).startsWith('gif:') ? String(sc.preset).slice(4) : '';
    const gifSrc = gifId && gifId !== 'all' ? `assets/gifs/${gifId}.gif` : '';
    const range = (key, label) => `<label class="aj-range"><span>${label}</span><input type="range" min="0" max="5" step="1" value="${c[key]}" data-aj-range="${key}" /><b>${c[key]}</b></label>`;
    return `<div class="tool-card"><div class="list-row"><div class="grow"><strong>AJAZZ AK820 Pro</strong><small>${st.mode === 'dongle' ? 'Kabellos über den 2.4G-Dongle' : 'Per Kabel verbunden'} · ${esc(st.pid)}${aj.battery != null ? ` · Akku ${aj.battery} %` : ''}. Änderungen bleiben in der Tastatur gespeichert.</small></div><button class="btn small" data-aj="probe">Neu verbinden</button></div></div>
      <div class="tool-grid two">
        <div class="tool-card"><div class="tool-label">Beleuchtung</div>
          <div class="aj-modes">${modes}</div>
          <div class="aj-colors"><input type="color" value="${esc(c.color)}" data-aj-color />${SWATCHES.map((h) => `<button class="aj-sw ${c.color.toLowerCase() === h ? 'on' : ''}" style="background:${h}" data-aj-sw="${h}"></button>`).join('')}
            <button class="aj-rainbow ${c.colorful ? 'on' : ''}" data-aj-colorful title="Regenbogen statt einer Farbe">🌈</button></div>
          ${range('brightness', 'Helligkeit')}${range('speed', 'Tempo')}
          <div class="aj-dir"><span>Richtung</span><div class="seg">${DIRS.map(([v, n]) => `<button class="${String(c.direction) === v ? 'on' : ''}" data-aj-dir="${v}">${n}</button>`).join('')}</div></div>
          <button class="btn primary" data-aj="light" ${dis}>${aj.busy === 'light' ? 'Wird übertragen …' : 'Auf Tastatur übernehmen'}</button>
        </div>
        <div class="tool-card"><div class="tool-label">Display · 128 × 128</div>
          ${st.mode === 'dongle' ? '<p class="muted aj-note">Bilder, Videos und Vorlagen gehen nur per Kabel: USB-C anstecken und den Schalter hinten in die Mitte stellen, dann „Neu verbinden“.</p>' : ''}
          <div class="aj-tft ${st.mode === 'dongle' ? 'aj-off' : ''}"><div class="aj-screen">${gifSrc ? `<img class="aj-gif" src="${gifSrc}" alt="GIF-Vorschau" />` : aj.preview ? `<img src="${aj.preview}" alt="" />` : '<span>128 × 128</span>'}</div>
            <div class="aj-tft-side"><label class="btn small"><input type="file" accept="image/*,video/*" data-aj-file hidden />Bild, GIF oder Video wählen</label>
              <small class="muted">${aj.loading ? 'Wird gelesen …' : aj.frames ? `${aj.frames.length} ${aj.frames.length === 1 ? 'Bild' : 'Bilder'} bereit` : 'PNG, JPG, GIF, MP4 oder WebM – wird auf 128×128 zugeschnitten. Videos und GIFs laufen mit bis zu 30 Bildern.'}</small>
              <div class="seg">${[1, 2, 3].map((n) => `<button class="${aj.slot === n ? 'on' : ''}" data-aj-slot="${n}">Platz ${n}</button>`).join('')}</div>
              <button class="btn primary small" data-aj="tft" ${aj.frames && !aj.busy && st.mode === 'cable' ? '' : 'disabled'}>${aj.busy === 'tft' ? 'Lädt …' : 'Aufs Display laden'}</button></div></div>
          <div class="tool-label">Vorlagen</div>
          <div class="gif-gallery scr-presets">${SCR_PRESETS.map(([v, n]) => `<button class="gif-tile ${sc.preset === v ? 'on' : ''}" data-aj-preset="${v}" title="${n} als Display-Vorlage">${aj.thumbs[v] ? `<img src="${aj.thumbs[v]}" alt="${n}" />` : '<span class="gif-all">▣</span>'}<span>${n}</span></button>`).join('')}</div>
          <div class="tool-label">Standard-GIFs</div>
          <div class="gif-gallery">${AJ_GIFS.map(([v, n]) => `<button class="gif-tile ${sc.preset === `gif:${v}` ? 'on' : ''}" data-aj-gif="${v}" title="${n} als Display-GIF"><img src="assets/gifs/${v}.gif" alt="${n}" /><span>${n}</span></button>`).join('')}<button class="gif-tile ${sc.preset === 'gif:all' ? 'on' : ''}" data-aj-gif="all" title="Alle drei GIFs abwechselnd"><span class="gif-all">▦</span><span>Alle drei</span></button></div>
          <div class="aj-colors"><input type="color" value="${esc(sc.color)}" data-aj-scrcolor title="Farbe der Vorlagen" /><small class="muted">Farbe der Vorlagen</small></div>
          ${sc.preset === 'text' ? `<input class="input scr-text" data-aj-text value="${esc(sc.text)}" placeholder="Text fürs Display …" maxlength="200" />` : ''}
          ${sc.preset === 'messages' ? `<div class="scr-feed">${scr.feed.length ? scr.feed.slice(0, 3).map((m) => `<div class="scr-msg"><b>${esc(m.from || '?')}</b>${m.chat ? `<small class="muted"> · ${esc(m.chat)}</small>` : ''}<div>${esc(String(m.text).slice(0, 120))}</div></div>`).join('') : '<p class="muted">Noch keine Nachrichten aus den Hub-Chats. Sobald jemand im „Revulutionland“-Chat schreibt, erscheint es hier und – wenn eingeschaltet – auf dem Display.</p>'}</div>` : ''}
          <div class="scr-auto">
            <div class="list-row"><div class="grow"><strong>Neue Nachrichten automatisch zeigen</strong><small>Beiträge aus den Hub-Chats landen von selbst auf dem Display – höchstens alle 20 Sekunden.</small></div><button class="switch ${sc.autoMessages ? 'on' : ''}" data-aj-auto="messages"></button></div>
            <div class="list-row"><div class="grow"><strong>Uhr automatisch aktuell halten</strong><small>Das Display zeigt regelmäßig die aktuelle PC-Zeit.</small></div><button class="switch ${sc.autoClock ? 'on' : ''}" data-aj-auto="clock"></button></div>
            <small class="muted">Ein eigenes Bild oder GIF bleibt auf dem Display, bis du wieder eine Vorlage oder ein Standard-GIF wählst.</small>
          </div>
          ${aj.busy === 'tft' ? `<div class="ph-bar"><i id="aj-bar" style="width:${Math.round(aj.progress * 100)}%"></i></div>` : ''}
          <small class="muted">Am Display umschalten: Fn + Entf wechselt zwischen Uhr und deinem Bild.</small>
          <div class="tool-label">Uhr & Energie</div>
          <div class="list-row"><div class="grow"><strong>Uhrzeit aufs Display</strong><small>Stellt die Uhr der Tastatur auf die PC-Zeit.</small></div><button class="btn small" data-aj="clock" ${dis}>${aj.busy === 'clock' ? '…' : 'Uhr stellen'}</button></div>
          <div class="list-row ${st.mode === 'dongle' ? 'aj-off' : ''}"><div class="grow"><strong>Schlafmodus</strong><small>Licht aus nach … ohne Tastendruck</small></div><div class="seg">${[[0, 'Nie'], [1, '1 min'], [5, '5 min'], [30, '30 min']].map(([v, n]) => `<button class="${c.sleep === v ? 'on' : ''}" data-aj-sleep="${v}">${n}</button>`).join('')}</div></div>
        </div>
      </div>
      ${aj.msg ? `<p class="muted tool-note">${esc(aj.msg)}</p>` : ''}`;
  }

  /** Animiertes Bild (GIF/WebP/PNG) oder Standbild → bis `limit` Bilder 128×128 als RGB565. */
  async function readFrames(blob, type, limit = 30) {
    const { canvas, g } = screenCanvas();
    const frames = [];
    const draw = (src, w, h) => {
      screenCover(g, src, w || 128, h || 128);
      return screen565(g);
    };
    if (/gif|webp|png/i.test(type) && 'ImageDecoder' in window) {
      try {
        const dec = new window.ImageDecoder({ data: await blob.arrayBuffer(), type });
        try {
          await dec.tracks.ready;
          const count = dec.tracks.selectedTrack?.frameCount || 1;
          const step = Math.max(1, Math.ceil(count / limit));
          for (let i = 0; i < count && frames.length < limit; i += step) {
            const { image } = await dec.decode({ frameIndex: i });
            const delay = ((image.duration || 100000) / 1000) * step;
            frames.push({ delay, rgb565: draw(image, image.displayWidth, image.displayHeight) });
            image.close();
          }
        } finally {
          dec.close();
        }
      } catch {
        frames.length = 0;
      }
    }
    if (!frames.length) {
      const bmp = await createImageBitmap(blob);
      frames.push({ delay: 0, rgb565: draw(bmp, bmp.width, bmp.height) });
      bmp.close?.();
    }
    return frames;
  }

  /** Ersten Frame als Vorschau – erscheint sofort, auch wenn ein großes GIF noch decodiert. */
  function firstPreview(blob) {
    return createImageBitmap(blob)
      .then((bmp) => {
        const { canvas, g } = screenCanvas();
        screenCover(g, bmp, bmp.width, bmp.height);
        bmp.close?.();
        return canvas.toDataURL();
      })
      .catch(() => '');
  }

  /** Standard-GIFs aus src/ui/assets/gifs über den Main-Prozess laden (funktioniert auch gepackt). */
  async function ajGifFrames(id) {
    if (gifCache.has(id)) return gifCache.get(id);
    const ids = id === 'all' ? AJ_GIFS.map(([key]) => key) : [id];
    if (!ids.length || !ids.every((key) => AJ_GIFS.some(([k]) => k === key))) throw new Error('Standard-GIF nicht gefunden');
    const limit = id === 'all' ? Math.max(1, Math.floor(30 / ids.length)) : 30;
    const frames = [];
    let preview = '';
    for (const key of ids) {
      const raw = await window.hub.ajazz.gif(key);
      if (!raw) continue;
      const bytes = raw instanceof Uint8Array ? raw : Array.isArray(raw) ? Uint8Array.from(raw) : raw?.data ? Uint8Array.from(raw.data) : null;
      if (!bytes?.length) continue;
      const blob = new Blob([bytes], { type: 'image/gif' });
      const part = await readFrames(blob, 'image/gif', limit);
      if (!part.length) continue;
      if (!preview) preview = await firstPreview(blob);
      frames.push(...part);
    }
    if (!frames.length) throw new Error('Standard-GIFs konnten nicht geladen werden');
    const out = { frames, preview };
    gifCache.set(id, out);
    return out;
  }

  /** Bild, GIF oder Video → bis 30 Bilder 128×128 als RGB565 (little endian). */
  async function ajLoadFile(file) {
    const gen = ++aj.gen;
    aj.loading = true;
    aj.preview = '';
    const frames = [];
    try {
      if (/^video\//i.test(file.type) || /\.(mp4|webm|mov|mkv|avi)$/i.test(file.name || '')) {
        const { canvas, g } = screenCanvas();
        const draw = (src, w, h) => {
          screenCover(g, src, w, h);
          return screen565(g);
        };
        const url = URL.createObjectURL(file);
        const video = document.createElement('video');
        video.muted = true;
        video.playsInline = true;
        video.src = url;
        try {
          await new Promise((resolve, reject) => {
            video.onloadedmetadata = resolve;
            video.onerror = () => reject(new Error('Video konnte nicht gelesen werden'));
          });
          // Max. 15 s, weil die Tastatur pro Bild höchstens 510 ms Pause kann (30 Bilder)
          const dur = Math.max(0.2, Math.min(15, Number(video.duration) || 4));
          const count = 30;
          await new Promise((resolve) => {
            if (video.readyState >= 2) resolve();
            else video.onloadeddata = resolve;
          });
          for (let i = 0; i < count; i++) {
            const at = Math.min(dur - 0.02, (dur * i) / count);
            await new Promise((resolve) => {
              // „seeked“ kommt nicht, wenn die Zeit schon stimmt – deshalb mit Notausstieg
              const done = () => {
                clearTimeout(timer);
                video.removeEventListener('seeked', done);
                resolve();
              };
              const timer = setTimeout(done, 700);
              video.addEventListener('seeked', done);
              video.currentTime = at;
            });
            frames.push({ delay: Math.round((dur * 1000) / count), rgb565: draw(video, video.videoWidth || 16, video.videoHeight || 16) });
            if (frames.length === 1 && gen === aj.gen) aj.preview = canvas.toDataURL();
          }
        } finally {
          URL.revokeObjectURL(url);
        }
      } else {
        const blob = new Blob([await file.arrayBuffer()], { type: file.type || 'image/gif' });
        firstPreview(blob).then((url) => {
          if (url && gen === aj.gen && !aj.preview) {
            aj.preview = url;
            if (active() && (kb.tab === 'light' || kb.tab === 'rgb')) ctx().render();
          }
        });
        frames.push(...(await readFrames(blob, file.type || 'image/gif')));
        if (gen === aj.gen && !aj.preview) aj.preview = await firstPreview(blob);
      }
      if (!frames.length) throw new Error('Datei konnte nicht gelesen werden');
      if (gen !== aj.gen) return;
      aj.frames = frames;
      aj.source = 'file';
    } finally {
      if (gen === aj.gen) aj.loading = false;
    }
  }

  async function ajRun(what, fn, done) {
    aj.busy = what;
    aj.progress = 0;
    ctx().render();
    try {
      await fn();
      ctx().toast(done);
    } catch (error) {
      ctx().toast(errText(error), 'error');
      if (/nicht .*gefunden|öffnen/.test(errText(error))) aj.probe = null;
    }
    aj.busy = '';
    ctx().render();
  }
  const ajSave = () => ctx().settings({ ajazz: ajCfg() });

  document.addEventListener('click', (e) => {
    if (!active() || kb.tab !== 'light') return;
    const d = (sel) => e.target.closest?.(sel);
    const c = ajCfg();
    let el;
    if ((el = d('[data-aj-mode]'))) c.mode = Number(el.dataset.ajMode);
    else if ((el = d('[data-aj-sw]'))) {
      c.color = el.dataset.ajSw;
      c.colorful = false;
    } else if (d('[data-aj-colorful]')) c.colorful = !c.colorful;
    else if ((el = d('[data-aj-dir]'))) c.direction = Number(el.dataset.ajDir);
    else if ((el = d('[data-aj-slot]'))) {
      aj.slot = Number(el.dataset.ajSlot);
      screenCfg().slot = aj.slot;
      screenSave();
    } else if ((el = d('[data-aj-preset]'))) return screenPreview(el.dataset.ajPreset);
    else if ((el = d('[data-aj-gif]'))) return screenPreview(`gif:${el.dataset.ajGif}`);
    else if ((el = d('[data-aj-auto]'))) {
      const s = screenCfg();
      const key = el.dataset.ajAuto === 'messages' ? 'autoMessages' : 'autoClock';
      s[key] = !s[key];
      screenSave();
      if (s[key] && !aj.probe) ajProbe();
      ctx().toast(s[key] ? 'Automatik an – Tastatur im Kabelmodus nötig' : 'Automatik aus');
      return ctx().render();
    } else if ((el = d('[data-aj-sleep]'))) {
      c.sleep = Number(el.dataset.ajSleep);
      ajSave();
      return ajRun('sleep', () => window.hub.ajazz.sleep(c.sleep), 'Schlafmodus gespeichert');
    } else if ((el = d('[data-aj]'))) {
      const a = el.dataset.aj;
      if (a === 'probe') {
        aj.probe = null;
        aj.probing = false;
      } else if (a === 'light') {
        ajSave();
        return ajRun('light', () => window.hub.ajazz.light(c), 'Beleuchtung übernommen');
      } else if (a === 'clock') return ajRun('clock', () => window.hub.ajazz.clock(), 'Uhr gestellt');
      else if (a === 'tft' && (aj.frames || aj.source === 'preset'))
        return ajRun(
          'tft',
          async () => {
            // Vorlagen frisch zeichnen, damit Text/Nachrichten/Uhr aktuell sind
            const frames = aj.source === 'preset' ? await presetFrames(screenCfg().preset) : aj.frames;
            await window.hub.ajazz.tft(frames, aj.slot);
          },
          'Display aktualisiert',
        );
    } else return;
    ctx().render();
  });
  document.addEventListener('input', (e) => {
    if (!active() || kb.tab !== 'light') return;
    const r = e.target.closest?.('[data-aj-range]');
    if (r) {
      ajCfg()[r.dataset.ajRange] = Number(r.value);
      const b = r.parentElement.querySelector('b');
      if (b) b.textContent = r.value;
    }
    if (e.target.matches?.('[data-aj-color]')) {
      ajCfg().color = e.target.value;
      ajCfg().colorful = false;
    }
    if (e.target.matches?.('[data-aj-scrcolor]')) screenCfg().color = e.target.value;
  });
  document.addEventListener('change', async (e) => {
    if (!active() || kb.tab !== 'light') return;
    if (e.target.matches?.('[data-aj-color]')) return ctx().render();
    if (e.target.matches?.('[data-aj-text]')) {
      screenCfg().text = e.target.value.slice(0, 200);
      screenSave();
      return screenPreview(screenCfg().preset);
    }
    if (e.target.matches?.('[data-aj-scrcolor]')) {
      screenSave();
      return screenPreview(screenCfg().preset);
    }
    if (e.target.matches?.('[data-aj-file]') && e.target.files?.[0]) {
      aj.loading = true;
      ctx().render();
      try {
        await ajLoadFile(e.target.files[0]);
      } catch (error) {
        ctx().toast(errText(error), 'error');
      }
      aj.loading = false;
      ctx().render();
    }
  });

  /* ---------------------------------------------------------------- Ganzer PC (direkt) */
  const or = { st: null, loading: false, busy: false, poll: 0, autoTried: false };
  const OR_EFFECTS = [
    ['static', 'Statisch'], ['wave', 'Regenbogenwelle'], ['spectrum', 'Spektrum'], ['breath', 'Atmen'],
    ['gradient', 'Verlauf (2 Farben)'], ['pulse', 'Pulsieren'], ['rainbow', 'Regenbogen drehen'], ['comet', 'Komet'],
    ['sparkle', 'Glitzer'], ['fire', 'Feuer'], ['lava', 'Lava'], ['ocean', 'Ozean'], ['aurora', 'Polarlicht'],
    ['strobe', 'Blitzlicht'], ['chase', 'Lauflicht'], ['split', 'Zweifarbig'], ['radar', 'Radar'],
    ['twinkle', 'Sternenfunkeln'], ['heartbeat', 'Herzschlag'], ['off', 'Aus'],
  ];
  const orCfg = () => {
    if (!or.cfg) or.cfg = { effect: 'wave', color: '#8b6cff', color2: '#00d5ff', speed: 55, brightness: 100, autoConnect: true, ...(ctx().state()?.settings?.rgb || {}) };
    return or.cfg;
  };
  /** Nur neu zeichnen, wenn sich wirklich etwas geändert hat – sonst flackert die Seite. */
  const orStruct = (st) => JSON.stringify({
    installed: Boolean(st?.installed),
    running: Boolean(st?.running),
    installing: st?.installing ? Math.round(Number(st.installing) * 20) : 0,
    error: st?.error || '',
    devices: (st?.devices || []).map((d) => [d.name, d.leds, d.activeMode, d.modes?.length]),
    effects: st?.effects?.length || 0,
    effect: st?.effect?.effect || '',
  });
  /** Live-Werte im RGB-Bereich aktualisieren, ohne die Seite neu aufzubauen. */
  function paintRgb(st) {
    const summary = document.getElementById('or-summary');
    if (summary) {
      const devices = st?.devices || [];
      const effects = st?.effects || [];
      const activeFx = st?.effect?.effect;
      summary.innerHTML = `${devices.length} ${devices.length === 1 ? 'Gerät' : 'Geräte'} verbunden · ${effects.length} Effekte${activeFx ? ` · läuft: <b>${esc(effects.find(([id]) => id === activeFx)?.[1] || activeFx)}</b>` : ''}`;
    }
    document.querySelectorAll('[data-or-fx]').forEach((el) => el.classList.toggle('on', el.dataset.orFx === st?.effect?.effect));
    document.querySelectorAll('[data-or-devcolor]').forEach((el) => {
      if (document.activeElement === el) return;
      const d = st?.devices?.[Number(el.dataset.orDevcolor)];
      if (d?.color) el.value = d.color;
    });
    document.querySelectorAll('[data-or-mode]').forEach((el) => {
      const d = st?.devices?.[Number(el.dataset.orMode)];
      if (d && document.activeElement !== el) el.selectedIndex = Number(d.activeMode) || 0;
    });
  }
  function orSchedule() {
    clearTimeout(or.poll);
    const st = or.st;
    if (!st || or.busy) return;
    or.poll = setTimeout(() => active() && kb.tab === 'rgb' && !or.busy && orLoad(), st.installing ? 700 : st.running ? 12000 : 7000);
  }
  function orSet(st) {
    const before = or.st;
    const beforeAll = JSON.stringify(before);
    const beforeStruct = orStruct(before);
    or.st = st;
    orSchedule();
    if (beforeAll === JSON.stringify(st)) return false;
    if (active() && kb.tab === 'rgb') {
      if (beforeStruct === orStruct(st)) paintRgb(st);
      else ctx().render();
    }
    return true;
  }
  window.hub.onOpenRgb?.((st) => orSet(st));
  async function orLoad() {
    if (or.loading) return;
    or.loading = true;
    try {
      orSet(await window.hub.rgb.status());
    } catch (error) {
      orSet({ installed: false, running: false, error: errText(error), devices: [], effects: [] });
    }
    or.loading = false;
  }
  async function orDo(fn, done) {
    or.busy = true;
    try {
      const st = await fn();
      if (st && typeof st === 'object' && Array.isArray(st.devices)) or.st = st;
      if (done) ctx().toast(done);
    } catch (error) {
      ctx().toast(errText(error), 'error');
    }
    or.busy = false;
    ctx().render();
  }

  /** Einmalig automatisch einrichten und verbinden – ohne extra Download-Seite. */
  function orAuto() {
    if (or.autoTried) return;
    or.autoTried = true;
    (async () => {
      try {
        let st = await window.hub.rgb.status();
        if (!st.installed) st = await window.hub.rgb.install();
        if (st.installed && !st.running) st = await window.hub.rgb.connect();
        orSet(st);
      } catch (error) {
        orSet({ ...(or.st || {}), installed: or.st?.installed === true, running: false, error: errText(error), devices: or.st?.devices || [], effects: OR_EFFECTS });
      }
    })();
  }

  function orHtml() {
    if (!or.st) {
      orLoad();
      return '<div class="tool-card"><p class="muted">Suche RGB-Geräte …</p></div>';
    }
    const st = or.st;
    orSchedule();
    const head = (title, text, btn = '') => `<div class="tool-card"><div class="aj-hero"><span class="aj-ic">🎛️</span><div><b>${title}</b><small class="muted">${text}</small></div></div>${btn}</div>`;
    if (st.installing)
      return head(
        'PC-RGB wird eingerichtet',
        `Herunterladen und entpacken … ${Math.round((st.installing || 0) * 100)} %. Das dauert nur beim ersten Mal.`,
        `<div class="ph-bar"><i style="width:${Math.round((st.installing || 0) * 100)}%"></i></div>`,
      );
    if (!st.installed) {
      if (st.error) return head('PC-RGB konnte nicht eingerichtet werden', esc(st.error), '<div class="or-actions"><button class="btn primary" data-or="install">Erneut versuchen</button><button class="btn small ghost" data-or="reload">Neu prüfen</button></div>');
      orAuto();
      return head(
        'PC-RGB wird vorbereitet',
        'Der Hub verbindet den RGB-Controller des Mainboards direkt – ohne Download und ohne OpenRGB. Beim ersten Öffnen kann das einen Moment dauern.',
        '<div class="or-actions"><div class="ph-bar"><i style="width:35%"></i></div><button class="btn small ghost" data-or="reload">Erneut prüfen</button></div>',
      );
    }
    if (!st.running) {
      if (st.error) return head('RGB-Schnittstelle antwortet nicht', esc(st.error), '<div class="or-actions"><button class="btn primary" data-or="connect">Erneut verbinden</button></div>');
      orAuto();
      return head(
        'PC-RGB wird verbunden',
        'Der Hub verbindet den RGB-Controller direkt. Das dauert nur beim ersten Mal einen Moment.',
        '<div class="or-actions"><div class="ph-bar"><i style="width:65%"></i></div><button class="btn small ghost" data-or="connect">Jetzt verbinden</button></div>',
      );
    }
    const c = orCfg();
    const effects = st.effects || [];
    const devices = st.devices || [];
    const activeFx = st.effect?.effect;
    return `<div class="tool-card">
        <div class="list-row"><div class="grow"><strong>Ganzer PC · RGB</strong><small id="or-summary">${devices.length} ${devices.length === 1 ? 'Gerät' : 'Geräte'} verbunden · ${effects.length} Effekte${activeFx ? ` · läuft: <b>${esc(effects.find(([id]) => id === activeFx)?.[1] || activeFx)}</b>` : ''}</small></div>
          <button class="switch ${c.autoConnect ? 'on' : ''}" data-or-auto title="Beim Hub-Start automatisch verbinden"></button>
          <button class="btn small" data-or="rescan">Neu suchen</button><button class="btn small" data-or="stop">Alle aus</button></div>
        <div class="or-list">${devices.map((d, i) => `<div class="or-dev">
            <div class="grow"><b>${esc(d.name)}</b><small>${esc(d.type)} · ${d.leds} LEDs${d.zones?.length ? ` · ${d.zones.map((z) => esc(z.name)).join(', ')}` : ''}</small></div>
            <select class="select" data-or-mode="${i}" title="Hardware-Effekt">${(d.modes || []).map((m, k) => `<option value="${k}" ${k === d.activeMode ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select>
            <input type="color" value="${esc(d.color)}" data-or-devcolor="${i}" title="Farbe" />
            <button class="btn small" data-or-dev="${i}">Setzen</button>
          </div>`).join('') || '<p class="muted">Keine Geräte gefunden. Prüfe die Kabel und klicke „Neu suchen“.</p>'}</div>
      </div>`;
  }

  function effectsCard() {
    const c = orCfg();
    const st = or.st;
    const effects = st?.effects?.length ? st.effects : OR_EFFECTS;
    const activeFx = st?.effect?.effect || c.effect;
    const canApply = Boolean(st?.running);
    return `<div class="tool-card"><div class="list-row"><div class="grow"><strong>Eigene Effekte</strong><small>${canApply ? 'Läuft direkt im RGB-Controller des Mainboards – ohne extra Programm und ohne Aussetzer. Die Vorschau ist eine Näherung.' : 'Vorschau und Auswahl gehen schon – zum Anwenden zuerst PC-RGB verbinden.'}</small></div>
        <button class="btn primary small" data-or="apply" ${or.busy || !canApply ? 'disabled' : ''}>${canApply ? 'Auf alle Geräte anwenden' : 'Erst verbinden'}</button></div>
        <div class="aj-colors"><input type="color" value="${esc(c.color)}" data-or-color title="Farbe 1" /><input type="color" value="${esc(c.color2)}" data-or-color2 title="Farbe 2" /><span class="muted">Farbe 1 / Farbe 2</span></div>
        <label class="aj-range"><span>Tempo</span><input type="range" min="1" max="100" value="${c.speed}" data-or-range="speed" /><b>${c.speed}</b></label>
        <label class="aj-range"><span>Helligkeit</span><input type="range" min="0" max="100" value="${c.brightness}" data-or-range="brightness" /><b>${c.brightness}</b></label>
        <div class="sr-grid">${effects.map(([id, name]) => `<button class="sr-fx ${activeFx === id ? 'on' : ''}" data-or-fx="${id}">${esc(name)}</button>`).join('')}</div>
      </div>`;
  }

  function rgbPreviewHtml() {
    const c = orCfg();
    const effects = or.st?.effects?.length ? or.st.effects : OR_EFFECTS;
    const name = effects.find(([id]) => id === c.effect)?.[1] || c.effect;
    const status = or.st?.running ? `${or.st.devices?.length || 0} Geräte live` : or.st?.installed ? 'RGB bereit – noch nicht verbunden' : 'Vorschau · RGB optional';
    return `<div class="rgb-stage" data-fx="${esc(c.effect)}" style="--c1:${esc(c.color)};--c2:${esc(c.color2)};--rgb-speed:${Math.max(1.2, 8 - c.speed / 14)}s">
      <div class="rgb-glow"></div><div class="rgb-scan"></div>
      <div class="rgb-stage-txt"><b>${esc(name)}</b><small>${esc(status)}</small></div>
      <div class="rgb-dots"><i style="background:${esc(c.color)}"></i><i style="background:${esc(c.color2)}"></i></div>
    </div>`;
  }

  const RGB_KB_ROWS = [
    ['Esc', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'ß', '´', '⌫'],
    ['Tab', 'Q', 'W', 'E', 'R', 'T', 'Z', 'U', 'I', 'O', 'P', 'Ü', '+', 'Enter'],
    ['Caps', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ö', 'Ä', '#'],
    ['Shift', 'Y', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '-', 'Shift'],
    ['Ctrl', 'Win', 'Alt', 'Space', 'AltGr', 'Fn', 'Ctrl'],
  ];

  /** Tastatur separat: eigener RGB-Effekt für die AJAZZ, unabhängig vom Mainboard. */
  const KB_RGB_FX = [
    [1, 'Statisch', 'static'],
    [7, 'Atmen', 'breath'],
    [8, 'Farbwechsel', 'wave'],
    [6, 'Regenbogen', 'rainbow'],
    [4, 'Glitzern', 'sparkle'],
    [10, 'Lauflicht', 'chase'],
    [12, 'Drehen', 'radar'],
    [17, 'Pulsieren', 'pulse'],
  ];
  const kbFx = (mode) => KB_RGB_FX.find(([m]) => m === Number(mode))?.[2] || 'static';
  const kbRowsHtml = () => {
    let n = 0;
    return RGB_KB_ROWS.map((row) => `<div class="rgb-kb-row">${row.map((label) => {
      const cls = label === 'Space' ? 'space' : /^(Esc|Tab|Caps|Shift|Ctrl|Win|Alt|AltGr|Fn|Enter|⌫)$/.test(label) ? 'mod' : '';
      return `<i class="rgb-key ${cls}" style="--i:${n++}">${esc(label)}</i>`;
    }).join('')}</div>`).join('');
  };
  function keyboardRgbHtml() {
    if (!aj.probe && !aj.probing) ajProbe();
    const c = ajCfg();
    const st = aj.probe;
    const connected = st?.mode === 'cable' || st?.mode === 'dongle';
    const name = KB_RGB_FX.find(([m]) => m === Number(c.mode))?.[1] || 'Statisch';
    return `<div class="tool-card rgb-kb-card keyboard-rgb-card"><div class="list-row"><div class="grow"><strong>Tastatur separat · AJAZZ</strong><small>${connected ? 'Eigener Effekt nur für die Tastatur – das Mainboard bleibt unabhängig.' : 'Tastatur nicht gefunden – Kabel oder 2.4G-Dongle prüfen.'}</small></div><span class="rgb-kb-live">${connected ? 'BEREIT' : 'OFFLINE'}</span></div>
      <div class="kb-fx-grid">${KB_RGB_FX.map(([m, n]) => `<button class="sr-fx ${Number(c.mode) === m ? 'on' : ''}" data-kb-rgb-mode="${m}">${n}</button>`).join('')}</div>
      <div class="aj-colors"><input type="color" value="${esc(c.color)}" data-kb-rgb-color title="Tastaturfarbe" /><span class="muted">Farbe der Tastatur</span><button class="btn small ghost" data-kb-rgb="probe">Neu suchen</button><button class="btn primary small" data-kb-rgb="apply" ${connected && !aj.busy ? '' : 'disabled'}>${aj.busy === 'light' ? 'Überträgt …' : 'Auf Tastatur anwenden'}</button></div>
      <div class="kb-ranges"><label class="aj-range"><span>Helligkeit</span><input type="range" min="0" max="5" step="1" value="${c.brightness}" data-kb-rgb-range="brightness" /><b>${c.brightness}</b></label><label class="aj-range"><span>Tempo</span><input type="range" min="0" max="5" step="1" value="${c.speed}" data-kb-rgb-range="speed" /><b>${c.speed}</b></label></div>
      <div class="rgb-kb" data-fx="${kbFx(c.mode)}" style="--c1:${esc(c.color)};--c2:#00d5ff;--kb-speed:${Math.max(1.4, 7 - Number(c.speed) / 2)}s">${kbRowsHtml()}</div>
      <small class="muted">${name} · so sieht der separat eingestellte Tastatur-Effekt aus.</small></div>`;
  }

  /** Tastatur-Vorschau unter den Effekten – zeigt Farben und Bewegung des Effekts. */
  function rgbKeyboardHtml() {
    const c = orCfg();
    const effects = or.st?.effects?.length ? or.st.effects : OR_EFFECTS;
    const name = effects.find(([id]) => id === c.effect)?.[1] || c.effect;
    let n = 0;
    const rows = RGB_KB_ROWS.map((row) => `<div class="rgb-kb-row">${row.map((label) => {
      const cls = label === 'Space' ? 'space' : /^(Esc|Tab|Caps|Shift|Ctrl|Win|Alt|AltGr|Fn|Enter|⌫)$/.test(label) ? 'mod' : '';
      return `<i class="rgb-key ${cls}" style="--i:${n++}">${esc(label)}</i>`;
    }).join('')}</div>`).join('');
    return `<div class="tool-card rgb-kb-card"><div class="list-row"><div class="grow"><strong>Tastatur-Vorschau</strong><small>${esc(name)} · so sieht der Effekt auf den Tasten aus.</small></div><span class="rgb-kb-live">LIVE</span></div>
      <div class="rgb-kb" data-fx="${esc(c.effect)}" style="--c1:${esc(c.color)};--c2:${esc(c.color2)};--kb-speed:${Math.max(1.4, 7 - c.speed / 18)}s">${rows}</div></div>`;
  }

  function rgbHtml() {
    return rgbPreviewHtml() + orHtml() + effectsCard() + keyboardRgbHtml();
  }

  document.addEventListener('click', (e) => {
    if (!active() || kb.tab !== 'rgb') return;
    const d = (sel) => e.target.closest?.(sel);
    let el;
    if ((el = d('[data-or-fx]'))) {
      orCfg().effect = el.dataset.orFx;
      try {
        ctx().settings({ rgb: orCfg() });
      } catch {
        /* egal */
      }
      return ctx().render();
    }
    if (d('[data-or-auto]')) {
      orCfg().autoConnect = !orCfg().autoConnect;
      try {
        ctx().settings({ rgb: orCfg() });
      } catch {
        /* egal */
      }
      return ctx().render();
    }
    if ((el = d('[data-or-dev]'))) {
      const i = Number(el.dataset.orDev);
      const mode = Number(document.querySelector(`[data-or-mode="${i}"]`)?.value || 0);
      const color = document.querySelector(`[data-or-devcolor="${i}"]`)?.value || '#ffffff';
      return orDo(() => window.hub.rgb.mode(i, mode, { color }), 'Gerät eingestellt');
    }
    if (!(el = d('[data-or]'))) return;
    const a = el.dataset.or;
    if (a === 'install')
      return orDo(async () => {
        const st = await window.hub.rgb.install();
        return st.installed ? window.hub.rgb.connect() : st;
      }, 'PC-RGB eingerichtet');
    if (a === 'connect') return orDo(() => window.hub.rgb.connect(), 'PC-RGB verbunden');
    if (a === 'rescan') return orDo(() => window.hub.rgb.rescan(), 'Geräte neu gesucht');
    if (a === 'stop') return orDo(() => window.hub.rgb.effect({ ...orCfg(), effect: 'off' }), 'Licht aus');
    if (a === 'reload') {
      or.st = null;
      return ctx().render();
    }
    if (a === 'apply')
      return orDo(async () => {
        await window.hub.rgb.save(orCfg()).catch(() => {});
        return window.hub.rgb.effect(orCfg());
      }, 'Effekt läuft auf allen Geräten');
  });

  /* Tastatur-RGB getrennt vom Mainboard */
  document.addEventListener('click', (e) => {
    if (!active() || kb.tab !== 'rgb') return;
    const d = (sel) => e.target.closest?.(sel);
    const mode = d('[data-kb-rgb-mode]')?.dataset.kbRgbMode;
    if (mode) {
      ajCfg().mode = Number(mode);
      ajSave();
      return ctx().render();
    }
    const a = d('[data-kb-rgb]')?.dataset.kbRgb;
    if (a === 'probe') {
      aj.probe = null;
      aj.probing = false;
      return ajProbe();
    }
    if (a === 'apply') {
      ajSave();
      return ajRun('light', () => window.hub.ajazz.light(ajCfg()), 'Tastaturlicht übernommen');
    }
  });
  document.addEventListener('input', (e) => {
    if (!active() || kb.tab !== 'rgb') return;
    if (e.target.matches?.('[data-kb-rgb-color]')) {
      ajCfg().color = e.target.value;
      return ctx().render();
    }
    const kr = e.target.closest?.('[data-kb-rgb-range]');
    if (kr) {
      ajCfg()[kr.dataset.kbRgbRange] = Number(kr.value);
      const b = kr.parentElement.querySelector('b');
      if (b) b.textContent = kr.value;
      return;
    }
    const c = orCfg();
    if (e.target.matches?.('[data-or-color]')) {
      c.color = e.target.value;
      document.querySelectorAll('.rgb-stage, .rgb-kb').forEach((el) => el.style.setProperty('--c1', c.color));
      return;
    }
    if (e.target.matches?.('[data-or-color2]')) {
      c.color2 = e.target.value;
      document.querySelectorAll('.rgb-stage, .rgb-kb').forEach((el) => el.style.setProperty('--c2', c.color2));
      return;
    }
    const r = e.target.closest?.('[data-or-range]');
    if (r) {
      c[r.dataset.orRange] = Number(r.value);
      const b = r.parentElement.querySelector('b');
      if (b) b.textContent = r.value;
      if (r.dataset.orRange === 'speed') document.querySelector('.rgb-kb')?.style.setProperty('--kb-speed', `${Math.max(1.4, 7 - c.speed / 18)}s`);
    }
  });

  function lightHtml() {
    if (!kb.devs) loadDevs();
    const devs = kb.devs
      ? kb.devs.keyboards.map((k) => `<div class="list-row"><div class="grow"><strong>${esc(k.name)}</strong><small>${esc(k.vendor)} · ${k.wireless ? 'Funk (Dongle)' : 'USB'} · ${esc(k.vid)}:${esc(k.pid)}</small></div></div>`).join('') || '<p class="muted">Keine Tastatur gefunden.</p>'
      : '<p class="muted">Suche …</p>';
    return `${ajazzHtml()}
      <div class="tool-card"><div class="tool-label">Angeschlossene Tastaturen</div>${devs}<div><button class="btn small" data-kb-rescan>Neu suchen</button></div></div>`;
  }

  function keyboardHtml() {
    const tabs = `<div class="seg kb-seg">${[['light', 'Licht & Display'], ['rgb', 'PC-RGB'], ['keys', 'Tasten'], ['test', 'Test']].map(([v, n]) => `<button class="${kb.tab === v ? 'on' : ''}" data-kb-tab="${v}">${n}</button>`).join('')}</div>`;
    if (!kb.status)
      window.hub.keyboard.status().then((s) => {
        kb.status = s;
        if (active()) paintStatus();
      });
    return tabs + (kb.tab === 'test' ? testHtml() : kb.tab === 'light' ? lightHtml() : kb.tab === 'rgb' ? rgbHtml() : keysHtml());
  }

  /* ---------------------------------------------------------------- Eingaben */
  document.addEventListener(
    'keydown',
    (e) => {
      if (!active()) return;
      // Tastentest
      if (kb.tab === 'test' && !e.target.closest?.('input,select,textarea')) {
        e.preventDefault();
        const t = kb.test;
        if (!e.repeat) {
          const upAt = t.lastUp[e.code];
          if (upAt && performance.now() - upAt < 35) t.chatter.push(e.code);
          t.down.add(e.code);
          t.seen.add(e.code);
          t.last = { code: e.code, key: e.key, at: performance.now(), held: 0 };
          ctx().render();
        }
        return;
      }
      // Makro aufnehmen
      if (kb.rec && !e.repeat) {
        e.preventDefault();
        const now = performance.now();
        if (kb.rec.steps.length) kb.rec.steps.push({ wait: Math.min(10000, Math.round(now - kb.rec.at)) });
        kb.rec.steps.push({ key: e.code, act: 'down' });
        kb.rec.at = now;
        ctx().render();
        return;
      }
      // Taste zuweisen
      if (!kb.capture) return;
      e.preventDefault();
      e.stopPropagation();
      const r = prof().rules[kb.capture.i];
      if (!r) return (kb.capture = null);
      if (kb.capture.what === 'combo') {
        if (!kb.capture.keys.includes(e.code)) kb.capture.keys.push(e.code);
        r.to = [...kb.capture.keys];
        ctx().render();
        return;
      }
      if (e.code === 'Escape' && kb.capture.what === 'from') {
        kb.capture = null;
        return ctx().render();
      }
      r[kb.capture.what === 'from' ? 'from' : 'to'] = e.code;
      kb.capture = null;
      save();
      ctx().render();
    },
    true,
  );
  document.addEventListener(
    'keyup',
    (e) => {
      if (!active()) return;
      if (kb.tab === 'test') {
        const t = kb.test;
        t.down.delete(e.code);
        t.lastUp[e.code] = performance.now();
        if (t.last?.code === e.code) t.last.held = Math.round(performance.now() - t.last.at);
        const el = document.querySelector(`.kb-key[data-code="${e.code}"]`);
        if (el) {
          el.classList.remove('down');
          el.classList.add('seen');
        }
        const info = document.getElementById('kb-info');
        if (info && t.last) info.innerHTML = `Zuletzt: <b>${esc(deName(t.last.code))}</b> · Code <code>${esc(t.last.code)}</code> · Zeichen <code>${esc(t.last.key)}</code> · gehalten ${t.last.held} ms · ${t.seen.size} Tasten geprüft`;
        return;
      }
      if (kb.rec) {
        const now = performance.now();
        kb.rec.steps.push({ wait: Math.min(10000, Math.round(now - kb.rec.at)) });
        kb.rec.steps.push({ key: e.code, act: 'up' });
        kb.rec.at = now;
        return;
      }
      if (kb.capture?.what === 'combo') {
        // Kombination fertig, sobald die erste Taste losgelassen wird
        kb.capture = null;
        save();
        ctx().render();
      }
    },
    true,
  );

  document.addEventListener('change', (e) => {
    if (!active()) return;
    const ty = e.target.closest?.('[data-kb-type]');
    if (ty) {
      const r = prof().rules[Number(ty.dataset.kbType)];
      r.type = ty.value;
      r.to = r.type === 'combo' || r.type === 'macro' ? [] : r.type === 'media' ? 'play' : '';
      save();
      return ctx().render();
    }
    const to = e.target.closest?.('[data-kb-to]');
    if (to) {
      prof().rules[Number(to.dataset.kbTo)].to = to.value;
      save();
    }
  });
  document.addEventListener('input', (e) => {
    if (!active()) return;
    const to = e.target.closest?.('input[data-kb-to]');
    if (to) {
      prof().rules[Number(to.dataset.kbTo)].to = to.value;
      save();
    }
    if (e.target.id === 'kb-app') kb.newApp = e.target.value || ' ';
  });

  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const d = (sel) => e.target.closest?.(sel);
    let el;
    try {
      if ((el = d('[data-kb-tab]'))) {
        kb.tab = el.dataset.kbTab;
        kb.capture = null;
        kb.rec = null;
      } else if (d('[data-kb-master]')) {
        cfg().enabled = !cfg().enabled;
        save(true);
      } else if ((el = d('[data-kb-prof]'))) kb.prof = Number(el.dataset.kbProf);
      else if (d('[data-kb-addprof]')) kb.newApp = ' ';
      else if (d('[data-kb-cancelprof]')) kb.newApp = '';
      else if ((el = d('[data-kb-preset]'))) {
        cfg().profiles.push({ id: `p${Date.now().toString(36)}`, name: el.dataset.name, apps: [el.dataset.kbPreset], on: true, rules: [] });
        kb.prof = cfg().profiles.length - 1;
        kb.newApp = '';
        save();
      } else if (d('[data-kb-createprof]')) {
        const app = (document.getElementById('kb-app')?.value || '').trim().replace(/\.exe$/i, '');
        if (!app) return ctx().toast('Programmname eingeben', 'error');
        cfg().profiles.push({ id: `p${Date.now().toString(36)}`, name: app, apps: [app], on: true, rules: [] });
        kb.prof = cfg().profiles.length - 1;
        kb.newApp = '';
        save();
      } else if (d('[data-kb-profon]')) {
        prof().on = !prof().on;
        save();
      } else if (d('[data-kb-delprof]')) {
        cfg().profiles.splice(kb.prof, 1);
        kb.prof = 0;
        save();
      } else if (d('[data-kb-addrule]')) {
        prof().rules.push({ from: '', type: 'key', to: '', on: true });
        kb.capture = { i: prof().rules.length - 1, what: 'from' };
      } else if ((el = d('[data-kb-cap]'))) {
        const what = el.dataset.kbCap;
        kb.capture = kb.capture?.i === Number(el.dataset.i) && kb.capture?.what === what ? null : { i: Number(el.dataset.i), what, keys: [] };
      } else if ((el = d('[data-kb-ruleon]'))) {
        const r = prof().rules[Number(el.dataset.kbRuleon)];
        r.on = !r.on;
        save();
      } else if ((el = d('[data-kb-del]'))) {
        prof().rules.splice(Number(el.dataset.kbDel), 1);
        kb.capture = null;
        save();
      } else if ((el = d('[data-kb-rec]'))) {
        const i = Number(el.dataset.kbRec);
        if (kb.rec?.i === i) {
          prof().rules[i].to = kb.rec.steps.slice(0, 80);
          kb.rec = null;
          save();
        } else kb.rec = { i, steps: [], at: performance.now() };
      } else if (d('[data-kb-testreset]')) kb.test = { down: new Set(), seen: new Set(), last: null, lastUp: {}, chatter: [] };
      else if (d('[data-kb-rescan]')) {
        kb.devs = null;
      } else if ((el = d('[data-kb-tool]'))) {
        await window.hub.keyboard.openTool(el.dataset.kbTool);
        return ctx().toast('Wird geöffnet …');
      } else if (d('[data-kb-lighting]')) return window.hub.keyboard.lighting();
      else return;
    } catch (error) {
      ctx().toast(errText(error), 'error');
    }
    ctx().render();
  });

  T.register(
    'tool-keyboard',
    { nav: 'Tastatur & RGB', title: 'Tastatur & RGB', sub: 'Licht, Display, PC-RGB, Tasten', icon: 'keyboard', tint: 'linear-gradient(135deg,#a78bfa,#6d28d9)', desc: 'Licht, Display und Uhr deiner AJAZZ direkt einstellen – und jede Taste jeder Tastatur umbelegen: Taste, Kombination, Text, Programm, Medien oder Makro, mit Profilen pro Spiel und Tastentest.' },
    keyboardHtml,
  );
})();
