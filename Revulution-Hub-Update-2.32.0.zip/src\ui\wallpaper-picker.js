'use strict';

/*
 * Monitor-Auswahl für „Als Desktop“: zeigt das echte Monitor-Layout. Ausgewählte Monitore
 * leuchten blau mit Partikeln. Ergebnis: { mode: 'select'|'span'|'all', monitors: [ids] } oder null.
 */
(() => {
  let raf = 0;

  function particles(canvas) {
    const g = canvas.getContext('2d');
    const ps = Array.from({ length: 34 }, () => ({ x: Math.random(), y: Math.random(), r: 0.6 + Math.random() * 1.8, v: 0.0015 + Math.random() * 0.004, a: Math.random() * Math.PI * 2 }));
    return () => {
      const dpr = window.devicePixelRatio || 1;
      const w = (canvas.width = Math.round(canvas.clientWidth * dpr));
      const h = (canvas.height = Math.round(canvas.clientHeight * dpr));
      g.clearRect(0, 0, w, h);
      for (const p of ps) {
        p.y -= p.v;
        p.a += 0.05;
        if (p.y < -0.05) {
          p.y = 1.05;
          p.x = Math.random();
        }
        const x = (p.x + Math.sin(p.a) * 0.01) * w;
        const y = p.y * h;
        const rad = p.r * 6 * (window.devicePixelRatio || 1);
        const glow = g.createRadialGradient(x, y, 0, x, y, rad);
        glow.addColorStop(0, 'rgba(120, 190, 255, 0.95)');
        glow.addColorStop(1, 'rgba(60, 130, 255, 0)');
        g.fillStyle = glow;
        g.beginPath();
        g.arc(x, y, rad, 0, Math.PI * 2);
        g.fill();
      }
    };
  }

  window.pickWallpaperTarget = async function pickWallpaperTarget() {
    let mons = [];
    try {
      mons = await window.hub.community.monitors();
    } catch {
      mons = [];
    }
    if (mons.length <= 1) return { mode: 'all', monitors: [] };
    return new Promise((resolve) => {
      const sel = new Set(mons.map((m) => m.id));
      let span = false;
      const minX = Math.min(...mons.map((m) => m.x));
      const minY = Math.min(...mons.map((m) => m.y));
      const maxX = Math.max(...mons.map((m) => m.x + m.w));
      const maxY = Math.max(...mons.map((m) => m.y + m.h));
      const W = 560;
      const H = 230;
      const k = Math.min(W / (maxX - minX), H / (maxY - minY));
      const offX = (W - (maxX - minX) * k) / 2;
      const offY = (H - (maxY - minY) * k) / 2;
      // Nummern von links nach rechts statt Windows-interner Reihenfolge
      const order = [...mons].sort((a, b) => a.x - b.x || a.y - b.y).map((m) => m.id);
      const label = (id) => order.indexOf(id) + 1;
      const back = document.createElement('div');
      back.className = 'wp-back';
      back.innerHTML = `<div class="wp-card">
        <div class="wp-eyebrow">HINTERGRUND</div><h3>Auf welchen Monitoren?</h3>
        <div class="wp-stage" style="width:${W}px;height:${H}px">${mons
          .map((m) => `<button class="wp-mon" data-id="${m.id}" style="left:${offX + (m.x - minX) * k + 3}px;top:${offY + (m.y - minY) * k + 3}px;width:${m.w * k - 6}px;height:${m.h * k - 6}px"><canvas></canvas><b>${label(m.id)}</b><small>${m.w}×${m.h}</small></button>`)
          .join('')}</div>
        <div class="wp-opts"><button class="wp-chip" data-wp="all">Alle Monitore</button><button class="wp-chip" data-wp="span">Über alle strecken</button></div>
        <div class="wp-btns"><button class="btn" data-wp="cancel">Abbrechen</button><button class="btn primary" data-wp="ok">Anwenden</button></div></div>`;
      document.body.appendChild(back);
      const draws = new Map();
      const paint = () => {
        back.querySelectorAll('.wp-mon').forEach((b) => {
          const on = span || sel.has(Number(b.dataset.id));
          b.classList.toggle('on', on);
          if (on && !draws.has(b)) draws.set(b, particles(b.querySelector('canvas')));
          if (!on) {
            draws.delete(b);
            const c = b.querySelector('canvas');
            c.getContext('2d').clearRect(0, 0, c.width, c.height);
          }
        });
        back.querySelector('[data-wp="span"]').classList.toggle('on', span);
        back.querySelector('[data-wp="all"]').classList.toggle('on', !span && sel.size === mons.length);
        back.querySelector('.wp-stage').classList.toggle('span', span);
        back.querySelector('[data-wp="ok"]').disabled = !span && !sel.size;
        // Live auf den echten Monitoren leuchten lassen
        window.hub.community.highlight?.(mons.filter((m) => span || sel.has(m.id))).catch(() => {});
      };
      const loop = () => {
        for (const d of draws.values()) d();
        raf = requestAnimationFrame(loop);
      };
      cancelAnimationFrame(raf);
      loop();
      paint();
      const close = (result) => {
        cancelAnimationFrame(raf);
        window.hub.community.highlight?.([]).catch(() => {});
        back.classList.add('out');
        setTimeout(() => back.remove(), 220);
        resolve(result);
      };
      back.addEventListener('click', (e) => {
        const mon = e.target.closest('.wp-mon');
        if (mon) {
          span = false;
          const id = Number(mon.dataset.id);
          if (sel.has(id)) sel.delete(id);
          else sel.add(id);
          return paint();
        }
        const a = e.target.closest('[data-wp]')?.dataset.wp;
        if (a === 'all') {
          span = false;
          mons.forEach((m) => sel.add(m.id));
          paint();
        } else if (a === 'span') {
          span = !span;
          paint();
        } else if (a === 'cancel' || e.target === back) close(null);
        else if (a === 'ok') close(span ? { mode: 'span', monitors: [] } : sel.size === mons.length ? { mode: 'all', monitors: [] } : { mode: 'select', monitors: [...sel] });
      });
    });
  };
})();
