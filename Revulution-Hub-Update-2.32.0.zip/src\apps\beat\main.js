'use strict';

const fs = require('fs');
const path = require('path');
const { boot } = require('../shared/boot');

const ctx = boot('beat', __dirname);
const { app, ipcMain, dialog } = ctx.electron;
const hub = ctx.hub;

const projectFile = () => path.join(app.getPath('userData'), 'beat-project.json');

ipcMain.handle('load', () => {
  try {
    return JSON.parse(fs.readFileSync(projectFile(), 'utf8'));
  } catch {
    return null;
  }
});

ipcMain.handle('save', (_event, data) => {
  const file = projectFile();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data));
  return { ok: true, file };
});

ipcMain.handle('export', async (event, data, name) => {
  const win = require('electron').BrowserWindow.fromWebContents(event.sender);
  const options = {
    title: 'Beat als WAV speichern',
    defaultPath: path.join(app.getPath('music'), `${String(name || 'beat').replace(/[\\/:*?"<>|]/g, '-')}.wav`),
    filters: [{ name: 'WAV-Audio', extensions: ['wav'] }],
  };
  const picked = win ? await dialog.showSaveDialog(win, options) : await dialog.showSaveDialog(options);
  if (picked.canceled || !picked.filePath) return { ok: false, canceled: true };
  fs.writeFileSync(picked.filePath, Buffer.from(data));
  return { ok: true, file: picked.filePath };
});

ipcMain.handle('reveal', (_event, file) => {
  if (file) ctx.electron.shell.showItemInFolder(file);
  return true;
});

// The project lives next to the app data, like the other hub apps.
global.__revolutionHub.hub.pushState?.();
void hub;
