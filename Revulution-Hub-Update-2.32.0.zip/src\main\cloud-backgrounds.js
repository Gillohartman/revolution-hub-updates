'use strict';

/*
 * Hintergründe aus der Cloud (Firebase-Projekt der Hub-Konten):
 *   bg_submissions/{id}  – Einsendungen von angemeldeten Nutzern (nur der Admin liest sie)
 *   backgrounds/{id}     – vom Admin freigegebene Bilder (alle dürfen lesen)
 * Jedes Dokument: { name, img: "data:image/jpeg;base64,…" (max. ~900 KB), by, uid, at }
 */
const fs = require('fs');
const path = require('path');

const MAX_IMG = 950 * 1024;
const clean = (v, max = 60) => String(v ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);

function checkImage(dataUrl) {
  const img = String(dataUrl || '');
  if (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(img)) throw new Error('Ungültiges Bild.');
  if (img.length > MAX_IMG) throw new Error('Das Bild ist zu groß (max. ~900 KB nach dem Verkleinern).');
  return img;
}

class CloudBackgrounds {
  /** @param {{ fb: object, token?: () => Promise<string>, uid?: () => string, name?: () => string, dir?: string }} o */
  constructor(o) {
    this.fb = o.fb;
    this.token = o.token || (async () => '');
    this.uid = o.uid || (() => '');
    this.name = o.name || (() => 'Nutzer');
    this.dir = o.dir || '';
    this.cache = null;
    this.cacheAt = 0;
  }

  /** Freigegebene Hintergründe (öffentlich). */
  async list(force = false) {
    if (!force && this.cache && Date.now() - this.cacheAt < 5 * 60000) return this.cache;
    const docs = await this.fb.list('backgrounds');
    this.cache = docs.map((d) => ({ id: d.id, name: clean(d.name) || 'Hintergrund', by: clean(d.by, 40), at: Number(d.at) || 0, img: String(d.img || '') })).sort((a, b) => b.at - a.at);
    this.cacheAt = Date.now();
    return this.cache;
  }

  /** Einreichen (angemeldet): landet beim Admin zur Prüfung. */
  async submit({ name, img }) {
    const token = await this.token();
    if (!token) throw new Error('Bitte melde dich zuerst mit deinem Hub-Konto an.');
    const id = await this.fb.addDoc('bg_submissions', { name: clean(name) || 'Hintergrund', img: checkImage(img), by: clean(this.name(), 40) || 'Nutzer', uid: this.uid(), at: Date.now() }, token);
    return { id };
  }

  /** Als Windows-Hintergrund setzen. */
  async desktop(id, opts = {}) {
    const entry = (await this.list()).find((b) => b.id === id) || (await this.fb.getDoc(`backgrounds/${id}`));
    if (!entry?.img) throw new Error('Hintergrund nicht gefunden.');
    const m = /^data:image\/(jpeg|png|webp);base64,(.+)$/.exec(entry.img);
    if (!m) throw new Error('Bild beschädigt.');
    const dir = path.join(this.dir, 'community');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `cloud-wallpaper.${m[1] === 'jpeg' ? 'jpg' : m[1]}`);
    fs.writeFileSync(file, Buffer.from(m[2], 'base64'));
    await require('./desktop-wallpaper').applyDesktopWallpaper(file, opts);
    return true;
  }

  /* ---------------------------------------------------------------- Admin */
  async pending(token) {
    const docs = await this.fb.list('bg_submissions', token);
    return docs.map((d) => ({ id: d.id, name: clean(d.name) || 'Hintergrund', by: clean(d.by, 40), uid: String(d.uid || ''), at: Number(d.at) || 0, img: String(d.img || '') })).sort((a, b) => b.at - a.at);
  }

  async approve(id, token, name) {
    const d = await this.fb.getDoc(`bg_submissions/${id}`, token);
    if (!d) throw new Error('Einsendung nicht gefunden.');
    await this.fb.addDoc('backgrounds', { name: clean(name || d.name) || 'Hintergrund', img: checkImage(d.img), by: clean(d.by, 40), at: Date.now() }, token);
    await this.fb.delDoc(`bg_submissions/${id}`, token);
    this.cache = null;
    return true;
  }

  async reject(id, token) {
    await this.fb.delDoc(`bg_submissions/${id}`, token);
    return true;
  }

  async removePublic(id, token) {
    await this.fb.delDoc(`backgrounds/${id}`, token);
    this.cache = null;
    return true;
  }

  /** Admin lädt direkt ein freigegebenes Bild hoch (aus einer Datei, schon verkleinert). */
  async publish({ name, img }, token) {
    await this.fb.addDoc('backgrounds', { name: clean(name) || 'Hintergrund', img: checkImage(img), by: 'Revulution', at: Date.now() }, token);
    this.cache = null;
    return true;
  }
}

/** Firestore-Regeln, die der Admin einmal in der Firebase-Konsole einträgt. */
function rulesFor(adminUid) {
  return `    match /bg_submissions/{id} {
      allow create: if request.auth != null && request.resource.data.uid == request.auth.uid
                    && request.resource.data.img is string && request.resource.data.img.size() < 980000;
      allow read, delete: if request.auth != null && request.auth.uid == '${adminUid}';
    }
    match /backgrounds/{id} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == '${adminUid}';
    }`;
}

module.exports = { CloudBackgrounds, rulesFor };
