'use strict';

/*
 * Ganzes PC-RGB über SignalRGB steuern (lokale API http://127.0.0.1:16038/api/v1).
 * SignalRGB verlangt dafür SignalRGB Pro und „Einstellungen → Allgemein → Enable HTTP API“.
 */
const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');

const BASE = 'http://127.0.0.1:16038/api/v1';
const LAUNCHERS = ['%LOCALAPPDATA%\\VortxEngine\\SignalRgbLauncher.exe', '%LOCALAPPDATA%\\VortxEngine\\SignalRgb.exe'];
const expand = (p) => p.replace(/%([^%]+)%/g, (_m, v) => process.env[v] || '');

async function api(method, route, body) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  try {
    const res = await fetch(`${BASE}/${route}`, {
      method,
      signal: ctrl.signal,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    let json = null;
    try {
      json = await res.json();
    } catch {
      /* leer */
    }
    if (res.status === 403) {
      const e = new Error('SignalRGB Pro nötig');
      e.code = 'PRO';
      throw e;
    }
    if (!res.ok) throw new Error(json?.errors?.[0]?.detail || `SignalRGB meldet Fehler ${res.status}`);
    return json?.data;
  } catch (error) {
    if (error.code === 'PRO') throw error;
    if (error.name === 'AbortError' || /fetch failed|ECONNREFUSED/i.test(String(error.message) + String(error.cause?.code))) {
      const e = new Error('SignalRGB antwortet nicht');
      e.code = 'OFFLINE';
      throw e;
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

class SignalRgb {
  constructor() {
    this.effects = null;
  }

  launcher() {
    return LAUNCHERS.map(expand).find((p) => p && fs.existsSync(p)) || '';
  }

  running() {
    return new Promise((resolve) => {
      execFile('tasklist', ['/FI', 'IMAGENAME eq SignalRgb.exe', '/NH'], { windowsHide: true }, (_e, out) => resolve(/SignalRgb\.exe/i.test(String(out || ''))));
    });
  }

  async status() {
    const installed = Boolean(this.launcher());
    try {
      const d = await api('GET', 'lighting');
      let layouts = [];
      let layout = '';
      try {
        layouts = ((await api('GET', 'scenes/layouts'))?.items || []).map((x) => x.id);
        layout = (await api('GET', 'scenes/current_layout'))?.current_layout?.id || '';
      } catch {
        /* Layouts optional */
      }
      return { state: 'ok', installed, enabled: d?.attributes?.enabled !== false, brightness: Number(d?.attributes?.global_brightness) || 0, effect: d?.attributes?.name || '', effectId: d?.id || '', layouts, layout };
    } catch (error) {
      if (error.code === 'PRO') return { state: 'pro', installed };
      return { state: (await this.running()) ? 'noapi' : installed ? 'stopped' : 'missing', installed };
    }
  }

  async list(force = false) {
    if (this.effects && !force) return this.effects;
    const d = await api('GET', 'lighting/effects');
    this.effects = (d?.items || []).map((x) => ({ id: x.id, name: String(x.attributes?.name || x.id).trim(), apply: x.links?.apply || '' })).sort((a, b) => a.name.localeCompare(b.name, 'de'));
    return this.effects;
  }

  async apply(id) {
    const fx = (this.effects || []).find((x) => x.id === id);
    const route = fx?.apply ? fx.apply.replace(/^\/api\/v1\//, '') : `lighting/effects/${encodeURIComponent(id)}/apply`;
    await api('POST', route);
    return this.status();
  }

  async brightness(n) {
    await api('PATCH', 'lighting/global_brightness', { global_brightness: Math.max(0, Math.min(100, Math.round(Number(n) || 0))) });
    return this.status();
  }

  async enabled(on) {
    await api('PATCH', 'lighting/enabled', { enabled: Boolean(on) });
    return this.status();
  }

  async step(dir) {
    await api('POST', `lighting/${dir === 'prev' ? 'previous' : dir === 'shuffle' ? 'shuffle' : 'next'}`);
    return this.status();
  }

  async layout(name) {
    await api('PATCH', 'scenes/current_layout', { layout: String(name || '') });
    return this.status();
  }

  start() {
    const p = this.launcher();
    if (!p) throw new Error('SignalRGB ist nicht installiert');
    spawn(p, [], { detached: true, stdio: 'ignore', cwd: path.dirname(p) }).unref();
    return true;
  }
}

module.exports = { SignalRgb };
