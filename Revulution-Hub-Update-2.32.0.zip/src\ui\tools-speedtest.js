'use strict';

/* WLAN- und Internettest als eigene App – animierte Ringe, Live-Werte und Verlauf. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const fmt = (v) => (v == null ? '–' : String(v).replace('.', ','));
  const PHASES = { wlan: 'WLAN wird geprüft', ping: 'Ping wird gemessen', down: 'Download wird gemessen', up: 'Upload wird gemessen', done: 'Fertig' };
  const sp = { running: false, phase: '', pct: 0, live: {}, result: null, wlan: undefined, history: null, error: '', loaded: false };

  const active = () => Boolean(document.querySelector('[data-tool-page="tool-speed"]'));

  function load() {
    if (sp.loaded) return;
    sp.loaded = true;
    window.hub.speed.wlan().then((w) => { sp.wlan = w || null; if (active()) ctx().render(); }).catch(() => { sp.wlan = null; });
    window.hub.speed.history().then((h) => { sp.history = Array.isArray(h) ? h : []; if (active()) ctx().render(); }).catch(() => { sp.history = []; });
  }

  function signalBars(sig) {
    return `<span class="sp-wifi" style="--s:${sig >= 65 ? '#4ade80' : sig >= 40 ? '#fbbf24' : '#f87171'}"><i class="${sig >= 25 ? 'a' : ''}"></i><i class="${sig >= 50 ? 'a' : ''}"></i><i class="${sig >= 75 ? 'a' : ''}"></i></span>`;
  }

  function wlanLine() {
    const w = sp.running ? sp.wlan : sp.result?.wlan ?? sp.wlan;
    if (w === undefined) return '<span class="muted">WLAN wird gelesen …</span>';
    if (!w) return '<span class="muted">WLAN-Daten sind auf diesem PC nicht verfügbar.</span>';
    if (!w.connected) return '<span class="muted">Nicht per WLAN verbunden – der Test läuft trotzdem.</span>';
    const sig = Number(w.signal) || 0;
    return `${signalBars(sig)}<b>${esc(w.ssid || 'WLAN')}</b><span>${sig} % Signal</span>${w.band ? `<span>${esc(w.band)}</span>` : ''}${w.rx ? `<span>Funkrate ${fmt(w.rx)} MBit/s</span>` : ''}`;
  }

  /* Live-Verlauf: jede Messung wird ein Balken, der von rechts hereinläuft. */
  const trace = [];
  function bars() {
    return `<div class="spd-bars ${sp.running ? 'on' : ''}" data-spd-bars>${Array.from({ length: 40 }, (_, i) => `<i style="--h:${trace[i] ?? 0}"></i>`).join('')}</div>`;
  }
  /* Werte gleiten weich zum Ziel statt zu springen; der Ring füllt sich flüssig. */
  const shown = { down: 0, up: 0, ping: 0, pct: 0 };
  let raf = 0;
  const f1 = (v) => (v == null ? '–' : Number(v) >= 100 ? String(Math.round(v)) : String(Math.round(v * 10) / 10).replace('.', ','));
  function tick() {
    raf = 0;
    const root = document.querySelector('[data-tool-page="tool-speed"]');
    if (!root) return;
    let moving = false;
    for (const k of ['down', 'up', 'ping', 'pct']) {
      const target = Number(k === 'pct' ? (sp.running ? sp.pct : sp.result ? 100 : 0) : (sp.running ? sp.live[k] : sp.result?.[k]) ?? 0);
      const next = shown[k] + (target - shown[k]) * 0.1;
      shown[k] = Math.abs(target - next) < 0.02 ? target : next;
      if (shown[k] !== target) moving = true;
    }
    const big = root.querySelector('[data-spd-big]');
    const val = sp.running && sp.phase === 'up' ? shown.up : sp.running && sp.phase === 'ping' ? shown.ping : shown.down;
    if (big) big.textContent = sp.running || sp.result ? f1(val) : '–';
    const unit = root.querySelector('[data-spd-unit]');
    if (unit) unit.textContent = sp.running && sp.phase === 'ping' ? 'MS PING' : sp.running && sp.phase === 'up' ? 'MBIT/S UPLOAD' : 'MBIT/S DOWNLOAD';
    for (const k of ['down', 'up', 'ping']) {
      const el = root.querySelector(`[data-spd-v="${k}"]`);
      if (el && (sp.running ? sp.live[k] != null : sp.result)) el.textContent = f1(shown[k]);
    }
    const ring = root.querySelector('[data-spd-ring]');
    if (ring) ring.style.strokeDashoffset = String(100 - shown.pct);
    // Tacho: logarithmisch bis 1000 MBit/s
    const gauge = root.querySelector('[data-spd-gauge]');
    const gv = sp.running && sp.phase === 'ping' ? 0 : val;
    if (gauge) gauge.style.strokeDashoffset = String(75 - Math.min(75, (Math.log10(1 + gv) / 3) * 75));
    if (moving || sp.running) raf = requestAnimationFrame(tick);
  }
  function kick() {
    if (!raf) raf = requestAnimationFrame(tick);
  }
  function paint() {
    const root = document.querySelector('[data-tool-page="tool-speed"]');
    if (!root || !root.querySelector('[data-spd-big]')) return ctx().render();
    const em = root.querySelector('[data-spd-phase]');
    if (em) em.textContent = sp.running ? `${PHASES[sp.phase] || 'Messung läuft'} · ${Math.round(sp.pct)} %` : '';
    root.querySelectorAll('[data-spd-g]').forEach((g) => g.classList.toggle('on', sp.running && g.dataset.spdG === sp.phase));
    const b = root.querySelector('[data-spd-bars]');
    if (b) [...b.children].forEach((i, n) => i.style.setProperty('--h', trace[n] ?? 0));
    kick();
  }

  function html() {
    load();
    const r = sp.result;
    const live = sp.running ? sp.live : r || {};
    setTimeout(kick, 30);
    const tips = r && !sp.running
      ? r.tips?.length
        ? r.tips.map((x) => `<div class="pc-issue sev${x.sev || 1}"><b>${esc(x.title)}</b><p>${esc(x.text)}</p></div>`).join('')
        : '<div class="pc-issue ok"><b>Alles bestens</b><p>Signal, Ping und Geschwindigkeit sind gut – da bremst nichts.</p></div>'
      : '';
    const hist = (sp.history || []).slice(0, 6);
    return `<div class="spd-hero ${sp.running ? 'run' : ''}">
        <div class="spd-dial">
          <svg viewBox="0 0 200 200" aria-hidden="true">
            <circle class="spd-dots" cx="100" cy="100" r="94" pathLength="100"/>
            <circle class="spd-prog" data-spd-ring cx="100" cy="100" r="94" pathLength="100" style="stroke-dashoffset:${100 - shown.pct}"/>
            <circle class="spd-track" cx="100" cy="100" r="74" pathLength="100"/>
            <circle class="spd-gauge" data-spd-gauge cx="100" cy="100" r="74" pathLength="100"/>
          </svg>
          <div class="spd-center">
            <b data-spd-big>${r || sp.running ? f1(sp.running ? shown.down : r.down) : '–'}</b>
            <small data-spd-unit>MBIT/S DOWNLOAD</small>
            <em data-spd-phase>${sp.running ? esc(PHASES[sp.phase] || 'Messung läuft') : ''}</em>
          </div>
        </div>
        ${bars()}
      </div>
      <div class="spd-g3">
        <div class="spd-g ${sp.phase === 'down' ? 'on' : ''}" data-spd-g="down"><span>DOWNLOAD</span><b data-spd-v="down">${f1(live.down)}</b><small>MBit/s</small></div>
        <div class="spd-g ${sp.phase === 'up' ? 'on' : ''}" data-spd-g="up"><span>UPLOAD</span><b data-spd-v="up">${f1(live.up)}</b><small>MBit/s</small></div>
        <div class="spd-g ${sp.phase === 'ping' ? 'on' : ''}" data-spd-g="ping"><span>PING</span><b data-spd-v="ping">${f1(live.ping)}</b><small>ms</small></div>
      </div>
      <div class="spd-host">${wlanLine()}</div>
      ${sp.error ? `<p class="spd-error">${esc(sp.error)}</p>` : ''}
      ${r && !sp.running ? `<div class="spd-host"><span>Note</span><b>${esc(r.grade || '–')}</b>${r.jitter != null ? `<span>Schwankung</span><b>${fmt(r.jitter)} ms</b>` : ''}${r.loss ? `<span>Verlust</span><b>${fmt(r.loss)} %</b>` : ''}<button class="btn small primary" data-spd-run style="margin-left:auto">${icon('refresh', 14)} Nochmal testen</button></div>` : ''}
      ${!r && !sp.running ? `<button class="btn primary spd-run" data-spd-run>${icon('bolt', 17)} Test starten</button>` : ''}
      ${sp.running ? `<button class="btn spd-run" disabled>${icon('clock', 17)} ${esc(PHASES[sp.phase] || 'Läuft')} …</button>` : ''}
      ${tips ? `<h4 class="pc-h">Was der Test sagt</h4><div class="spd-tips">${tips}</div>` : ''}
      ${hist.length ? `<h4 class="pc-h">Letzte Tests</h4><div class="sp-history">${hist.map((h) => `<div class="sp-history-row"><span>${new Date(h.at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span><b>↓ ${fmt(h.down)}</b><b>↑ ${fmt(h.up)}</b><b>${fmt(h.ping)} ms</b></div>`).join('')}</div>` : ''}
      <p class="muted sp-note">Gemessen über speed.cloudflare.com. Der Test dauert etwa 20 Sekunden und verbraucht je nach Leitung einige MB.</p>`;
  }

  async function run() {
    if (sp.running) return;
    sp.running = true;
    sp.phase = 'wlan';
    sp.pct = 0;
    sp.live = {};
    sp.error = '';
    trace.length = 0;
    Object.assign(shown, { down: 0, up: 0, ping: 0, pct: 0 });
    ctx().render();
    try {
      const r = await window.hub.speed.run();
      sp.result = r;
      sp.wlan = r?.wlan ?? sp.wlan;
      sp.history = [{ at: r.at, down: r.down, up: r.up, ping: r.ping }, ...(sp.history || [])].slice(0, 10);
      ctx().toast?.('Speedtest fertig.');
    } catch (error) {
      sp.error = String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
    sp.running = false;
    sp.phase = '';
    if (active()) ctx().render();
  }

  window.hub.onSpeed?.((p) => {
    if (!active() && !sp.running) return;
    sp.phase = p.phase;
    sp.pct = p.pct || 0;
    if (p.phase === 'ping' && p.value != null) sp.live.ping = Math.round(p.value);
    if (p.phase === 'down' && p.value != null) sp.live.down = p.value;
    if (p.phase === 'up' && p.value != null) sp.live.up = p.value;
    if ((p.phase === 'down' || p.phase === 'up') && p.value != null) {
      trace.push(Math.min(1, Math.log10(1 + Number(p.value)) / 3));
      if (trace.length > 40) trace.shift();
    }
    // Kein komplettes Neuzeichnen mehr – sonst starten alle Animationen bei jedem Messwert neu.
    if (active()) paint();
  });

  document.addEventListener('click', (e) => {
    if (!active()) return;
    if (e.target.closest('[data-spd-run]')) run();
  });

  T.register('tool-speed', { nav: 'WLAN-Test', title: 'WLAN-Test', sub: 'Speedtest mit Live-Anzeige', icon: 'globe', tint: 'linear-gradient(135deg,#38bdf8,#0e7490)', desc: 'Download, Upload, Ping und WLAN-Signal in einer animierten Live-Ansicht – mit Verlauf und Tipps.' }, html);
})();
