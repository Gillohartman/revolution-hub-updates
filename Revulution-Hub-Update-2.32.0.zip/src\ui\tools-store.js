'use strict';

/*
 * Revolution Store: freiwillige Cosmetics gegen Revolution Coins, Coin-Pakete und freiwillige
 * Unterstützung. Bezahlt wird im Browser über Stripe Checkout – die App sieht nie Karten-
 * oder TWINT-Daten und kennt keinen Stripe-Schlüssel. Alles Wichtige entscheidet der Server.
 */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const active = () => ctx().state()?.active === 'tool-store';
  const C = () => window.RevCos;
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

  const st = { data: null, loading: false, tab: 'store', cat: 'profile', busy: '', donation: 500, custom: '', anonymous: false, showName: false, name: '', trying: null, supporters: null };

  // Kategorien wie gewünscht; leere zeigen „kommt bald“ statt erfundener Artikel
  const CATS = [
    ['profile', 'Profilbilder', ['color']],
    ['frames', 'Rahmen', ['frame']],
    ['names', 'Namensfarben', ['name']],
    ['badges', 'Titel & Badges', ['title']],
    ['fx', 'Animationen', ['effect']],
    ['chess', 'Schach', []],
    ['island', 'Dynamic Island', []],
    ['themes', 'Themes', []],
    ['widgets', 'Widget-Designs', []],
    ['walls', 'Wallpaper-Pakete', []],
    ['cursor', 'Cursor', []],
    ['sounds', 'UI-Sounds', []],
  ];
  const DESC = {
    color: 'Hintergrund deines Profilbilds',
    frame: 'Rahmen um dein Profilbild',
    name: 'Farbe deines Namens in Schach, Geo und Chats',
    title: 'Titel neben deinem Namen',
    effect: 'Effekt bei jedem Schachzug',
  };

  async function load(force = false) {
    if (st.loading || (st.data && !force)) return;
    st.loading = true;
    try {
      st.data = await window.hub.store.state();
    } catch (e) {
      st.data = { offline: true, error: errText(e), coins: 0, owned: [], transactions: [] };
    }
    st.loading = false;
    if (active()) ctx().render();
  }
  window.hub.onStore?.((s) => {
    st.data = s;
    if (active()) ctx().render();
  });

  const coins = (n) => `<span class="rs-coin"><i></i>${Number(n || 0).toLocaleString('de-DE')}</span>`;
  const chf = (rappen) => `CHF ${(rappen / 100).toFixed(2).replace('.', '.')}`;
  const owned = (slot, id) => (st.data?.owned || []).includes(`${slot}/${id}`);
  const profile = () => ctx().profile?.() || null;

  function itemCard(slot, it) {
    const P = profile();
    const eq = P?.cos?.eq || {};
    const has = owned(slot, it.id);
    const on = eq[slot] === it.id;
    const name = it.t?.de || it.id.charAt(0).toUpperCase() + it.id.slice(1);
    const trying = st.trying === `${slot}/${it.id}`;
    return `<div class="rs-item ${has ? 'owned' : ''} ${trying ? 'trying' : ''}">
      <div class="rs-prev">${C().preview(slot, it, eq, P?.name || 'Name')}</div>
      <div class="rs-meta"><b>${esc(name)}</b><small>${esc(DESC[slot] || '')}</small></div>
      <div class="rs-act">${has
        ? on ? '<span class="rs-tag">Angelegt</span>' : `<button class="btn small" data-rs-equip="${slot}/${it.id}">Anlegen</button>`
        : `<button class="btn small ghost" data-rs-try="${slot}/${it.id}">${trying ? 'Probiert …' : 'Anprobieren'}</button><button class="btn small primary" data-rs-buy="${slot}/${it.id}">${coins(it.coins)}</button>`}</div>
    </div>`;
  }

  function storeTab() {
    const cat = CATS.find((c) => c[0] === st.cat) || CATS[0];
    const items = cat[2].flatMap((slot) => (C()?.COSMETICS[slot] || []).filter((it) => it.coins).map((it) => itemCard(slot, it)));
    return `<nav class="rs-cats">${CATS.map(([id, n, slots]) => `<button class="${st.cat === id ? 'on' : ''} ${slots.length ? '' : 'soon'}" data-rs-cat="${id}">${esc(n)}</button>`).join('')}</nav>
      ${items.length ? `<div class="rs-grid">${items.join('')}</div>` : `<div class="rs-soon"><span>KOMMT BALD</span><b>${esc(cat[1])}</b><p>Hier erscheinen bald Designs. Alles, was es im Store gibt, ist rein kosmetisch – der Hub bleibt komplett kostenlos.</p></div>`}`;
  }

  function coinsTab() {
    const packs = st.data?.catalog?.packs || [
      { id: 'coins_100', coins: 100, amount: 100 },
      { id: 'coins_500', coins: 500, amount: 500 },
      { id: 'coins_1200', coins: 1200, amount: 1000 },
      { id: 'coins_2500', coins: 2500, amount: 2000 },
    ];
    const daily = st.data?.catalog?.daily || { coins: 10, cooldownMs: 72000000 };
    const next = (st.data?.dailyAt || 0) + daily.cooldownMs;
    const canDaily = Date.now() >= next;
    return `<div class="rs-packs">${packs
      .map((p, i) => `<button class="rs-pack" style="--d:${i * 60}ms" data-rs-pack="${esc(p.id)}"><span class="rs-pack-dots">${'<i></i>'.repeat(Math.min(12, Math.round(p.coins / 200) + 1))}</span><b>${coins(p.coins)}</b>${p.coins / p.amount > 1.05 ? `<em>+${Math.round((p.coins / p.amount - 1) * 100)} % Bonus</em>` : '<em>&nbsp;</em>'}<span class="rs-price">${chf(p.amount)}</span></button>`)
      .join('')}</div>
      <div class="rs-free"><div><b>Coins gratis verdienen</b><small>Jeden Tag ${daily.coins} Coins abholen. Weitere Events und Challenges folgen.</small></div><button class="btn small ${canDaily ? 'primary' : ''}" data-rs-daily ${canDaily ? '' : 'disabled'}>${canDaily ? `+${daily.coins} abholen` : `wieder ab ${new Date(next).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`}</button></div>
      <p class="rs-fine">Bezahlt wird sicher im Browser über Stripe (Karte, TWINT, Apple Pay). Coins haben keinen Geldwert, sind nicht übertragbar und nicht auszahlbar. Sie schalten nur kosmetische Designs frei – alle Funktionen des Hubs bleiben kostenlos.</p>`;
  }

  function supportTab() {
    if (!st.supporters) {
      st.supporters = [];
      window.hub.store.supporters().then((s) => { st.supporters = s || []; if (active() && st.tab === 'support') ctx().render(); }).catch(() => {});
    }
    const amt = st.custom ? Math.round(Number(String(st.custom).replace(',', '.')) * 100) || 0 : st.donation;
    return `<div class="rs-support">
      <div class="rs-heart"><svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-9.2-9C1.4 8 3.3 4.5 6.6 4.5c2 0 3.4 1.2 5.4 3.2 2-2 3.4-3.2 5.4-3.2 3.3 0 5.2 3.5 3.8 6.5C19 15.6 12 20 12 20Z"/></svg></div>
      <h3>Revulution Hub unterstützen</h3>
      <p>Freiwillig und einmalig. Deine Unterstützung schaltet nichts frei – sie hilft einfach, dass der Hub weiter kostenlos wachsen kann.</p>
      <div class="rs-amounts">${[200, 500, 1000, 2000].map((a) => `<button class="${!st.custom && st.donation === a ? 'on' : ''}" data-rs-amt="${a}">${chf(a).replace('.00', '')}</button>`).join('')}<label class="rs-custom ${st.custom ? 'on' : ''}">CHF <input data-rs-custom inputmode="decimal" placeholder="Betrag" value="${esc(st.custom)}" /></label></div>
      <div class="rs-opts">
        <label><button class="switch ${st.anonymous ? 'on' : ''}" data-rs-opt="anonymous"></button> Anonym unterstützen</label>
        ${st.anonymous ? '' : `<label><button class="switch ${st.showName ? 'on' : ''}" data-rs-opt="showName"></button> In der Unterstützer-Liste zeigen</label>${st.showName ? `<input class="input" data-rs-name placeholder="Name für die Liste" value="${esc(st.name)}" maxlength="40" />` : ''}`}
      </div>
      <button class="btn primary rs-donate" data-rs-donate ${amt >= 100 ? '' : 'disabled'}>${amt >= 100 ? `${chf(amt)} unterstützen` : 'Mindestens CHF 1'}</button>
      ${st.supporters?.length ? `<div class="rs-sup"><span>DANKE AN</span>${st.supporters.slice(0, 30).map((s) => `<i>${esc(s.name)}</i>`).join('')}</div>` : ''}
    </div>`;
  }

  function inventoryTab() {
    const d = st.data || {};
    const tx = d.transactions || [];
    const label = (t) => (t.kind === 'coins' ? `${t.coins} Coins gekauft` : t.kind === 'item' ? `Gekauft: ${t.item}` : t.kind === 'daily' ? 'Tagesbonus' : t.kind === 'donation' ? 'Unterstützung – danke!' : t.kind);
    const stat = { paid: 'bezahlt', open: 'offen', failed: 'fehlgeschlagen', refunded: 'erstattet', disputed: 'in Klärung', done: '' };
    return `<div class="rs-inv">
      <div class="rs-inv-head"><div><span>DEINE COINS</span>${coins(d.coins)}</div><div><span>COSMETICS</span><b>${(d.owned || []).length}</b></div></div>
      ${(d.owned || []).length ? `<div class="rs-owned">${(d.owned || []).map((k) => { const [slot, id] = k.split('/'); const it = C()?.COSMETICS[slot]?.find((x) => x.id === id); return it ? itemCard(slot, it) : ''; }).join('')}</div>` : '<p class="muted">Noch nichts gekauft.</p>'}
      <h4 class="pc-h">Verlauf</h4>
      ${tx.length ? `<div class="rs-tx">${tx.map((t) => `<div><span>${esc(label(t))}${stat[t.status] ? ` · ${stat[t.status]}` : ''}</span><small>${new Date(t.at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}</small><b class="${(t.coins || 0) < 0 ? 'neg' : ''}">${t.kind === 'donation' ? chf(t.amount) : `${t.coins > 0 ? '+' : ''}${t.coins || 0}`}</b></div>`).join('')}</div>` : '<p class="muted">Noch keine Transaktionen.</p>'}
    </div>`;
  }

  function html() {
    load();
    const d = st.data;
    const signedIn = d?.signedIn;
    const setup = d?.offline;
    const tabs = [['store', 'Store'], ['coins', 'Coins'], ['support', 'Unterstützen'], ['inv', 'Inventar']];
    return `<div class="rs">
      <header class="rs-head">
        <div><span class="rs-eyebrow">● REVOLUTION STORE</span><h2>Freiwillig. Kosmetisch. Fair.</h2><p>Alles im Hub bleibt kostenlos – hier gibt es nur Designs zum Personalisieren.</p></div>
        <div class="rs-wallet">${signedIn ? coins(d?.coins) : '<button class="btn small" data-open="tool-account">Anmelden</button>'}</div>
      </header>
      ${setup ? `<div class="rs-note">${icon('alert', 15)}<span>${d.error === 'setup' ? 'Der Store wird gerade eingerichtet – Käufe sind bald möglich. Anschauen und Anprobieren geht schon.' : esc(d.error || 'Store gerade nicht erreichbar.')}</span></div>` : ''}
      ${!signedIn && !setup ? `<div class="rs-note">${icon('users', 15)}<span>Mit einem Revulution-Konto bleiben deine Käufe auch nach einer Neuinstallation erhalten.</span></div>` : ''}
      <nav class="seg rs-tabs">${tabs.map(([id, n]) => `<button class="${st.tab === id ? 'on' : ''}" data-rs-tab="${id}">${n}</button>`).join('')}</nav>
      <div class="rs-body">${st.tab === 'coins' ? coinsTab() : st.tab === 'support' ? supportTab() : st.tab === 'inv' ? inventoryTab() : storeTab()}</div>
    </div>`;
  }

  async function act(fn, ok) {
    if (st.busy) return;
    st.busy = '1';
    try {
      await fn();
      if (ok) ctx().toast(ok);
    } catch (e) {
      ctx().toast(errText(e), 'error');
    }
    st.busy = '';
    if (active()) ctx().render();
  }

  document.addEventListener('click', (e) => {
    if (!active()) return;
    const q = (s) => e.target.closest?.(s);
    const tab = q('[data-rs-tab]')?.dataset.rsTab;
    if (tab) { st.tab = tab; return ctx().render(); }
    const cat = q('[data-rs-cat]')?.dataset.rsCat;
    if (cat) { st.cat = cat; return ctx().render(); }
    const pack = q('[data-rs-pack]')?.dataset.rsPack;
    if (pack) return act(() => window.hub.store.checkout(pack), 'Stripe Checkout geöffnet – nach dem Bezahlen erscheinen die Coins hier.');
    if (q('[data-rs-daily]')) return act(() => window.hub.store.daily(), 'Tagesbonus abgeholt!');
    const buy = q('[data-rs-buy]')?.dataset.rsBuy;
    if (buy) return act(async () => {
      const [slot, id] = buy.split('/');
      await window.hub.store.buy(buy);
      await window.hub.profile.equip(slot, id);
    }, 'Gekauft und angelegt!');
    const eqp = q('[data-rs-equip]')?.dataset.rsEquip;
    if (eqp) {
      const [slot, id] = eqp.split('/');
      return act(() => window.hub.profile.equip(slot, id), 'Angelegt.');
    }
    const tr = q('[data-rs-try]')?.dataset.rsTry;
    if (tr) {
      // Anprobieren: 20 s lang groß in der Vorschau zeigen
      st.trying = tr;
      clearTimeout(st.tryTimer);
      st.tryTimer = setTimeout(() => { st.trying = null; if (active()) ctx().render(); }, 20000);
      return ctx().render();
    }
    const amt = q('[data-rs-amt]')?.dataset.rsAmt;
    if (amt) { st.donation = Number(amt); st.custom = ''; return ctx().render(); }
    const opt = q('[data-rs-opt]')?.dataset.rsOpt;
    if (opt) { st[opt] = !st[opt]; return ctx().render(); }
    if (q('[data-rs-donate]')) {
      const amount = st.custom ? Math.round(Number(String(st.custom).replace(',', '.')) * 100) : st.donation;
      return act(() => window.hub.store.donate({ amount, anonymous: st.anonymous, showName: st.showName, name: st.name }), 'Danke! Die Zahlung öffnet sich im Browser.');
    }
  });
  document.addEventListener('input', (e) => {
    if (!active()) return;
    if (e.target.matches?.('[data-rs-custom]')) {
      st.custom = e.target.value.replace(/[^\d.,]/g, '');
      const b = document.querySelector('[data-rs-donate]');
      const a = Math.round(Number(st.custom.replace(',', '.')) * 100) || 0;
      if (b) { b.disabled = a < 100; b.textContent = a >= 100 ? `${chf(a)} unterstützen` : 'Mindestens CHF 1'; }
    }
    if (e.target.matches?.('[data-rs-name]')) st.name = e.target.value;
  });

  T.register(
    'tool-store',
    { nav: 'Store', title: 'Revolution Store', sub: 'Cosmetics, Coins & Unterstützung', icon: 'spark', tint: 'linear-gradient(135deg,#ff3b30,#7f1d1d)', desc: 'Freiwillige Designs für Profil, Rahmen, Namen und Effekte – mit Revolution Coins. Der Hub bleibt kostenlos.' },
    html,
  );
})();
