'use strict';

/*
 * AJAZZ AK820 Pro direkt aus dem Hub steuern (Kabelmodus, 0C45:8009/800A).
 * Protokoll nach dem offenen Projekt wsclx/ak820pro-modder (MIT, auf Hardware getestet):
 * 64-Byte-Feature-Reports auf Usage-Page 0xFF13 (Steuerung) und 4096-Byte-Output-Reports
 * auf 0xFF68 (Display). Ablauf je Änderung: START → Befehl → Daten → COMMIT → FINISH.
 * Geschrieben wird nur, wenn beide Schnittstellen genau die bekannten Größen melden.
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CS = String.raw`
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;

public static class Ajazz {
  [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
  [DllImport("setupapi.dll", CharSet=CharSet.Auto)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int f);
  [DllImport("setupapi.dll")] static extern bool SetupDiEnumDeviceInterfaces(IntPtr s, IntPtr d, ref Guid g, int i, ref SP_DEVICE_INTERFACE_DATA data);
  [DllImport("setupapi.dll", CharSet=CharSet.Auto)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr s, ref SP_DEVICE_INTERFACE_DATA d, IntPtr detail, int size, out int req, IntPtr info);
  [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr s);
  [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Auto)] static extern SafeFileHandle CreateFile(string n, uint a, uint s, IntPtr sa, uint c, uint f, IntPtr t);
  [DllImport("hid.dll")] static extern bool HidD_GetPreparsedData(SafeFileHandle h, out IntPtr p);
  [DllImport("hid.dll")] static extern bool HidD_FreePreparsedData(IntPtr p);
  [DllImport("hid.dll")] static extern int HidP_GetCaps(IntPtr p, out HIDP_CAPS c);
  [DllImport("hid.dll")] static extern bool HidD_SetFeature(SafeFileHandle h, byte[] b, int l);
  [DllImport("hid.dll")] static extern bool HidD_GetFeature(SafeFileHandle h, byte[] b, int l);
  [StructLayout(LayoutKind.Sequential)] struct SP_DEVICE_INTERFACE_DATA { public int cbSize; public Guid g; public int flags; public IntPtr r; }
  [StructLayout(LayoutKind.Sequential)] struct HIDP_CAPS { public ushort Usage, UsagePage, InLen, OutLen, FeatLen; [MarshalAs(UnmanagedType.ByValArray, SizeConst=17)] public ushort[] r; public ushort a,b,c,d,e,f,g,h,i,j; }

  class Iface { public string Path; public ushort Page, In, Out, Feat; public string Pid; }

  static List<Iface> Enum() {
    var res = new List<Iface>();
    Guid g; HidD_GetHidGuid(out g);
    IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);
    var d = new SP_DEVICE_INTERFACE_DATA(); d.cbSize = Marshal.SizeOf(d);
    for (int i = 0; SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref d); i++) {
      int req; SetupDiGetDeviceInterfaceDetail(set, ref d, IntPtr.Zero, 0, out req, IntPtr.Zero);
      IntPtr buf = Marshal.AllocHGlobal(req);
      Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
      if (SetupDiGetDeviceInterfaceDetail(set, ref d, buf, req, out req, IntPtr.Zero)) {
        string p = Marshal.PtrToStringAuto(buf + 4);
        string low = p.ToLowerInvariant();
        if (low.Contains("vid_0c45")) {
          using (var h = CreateFile(p, 0, 3, IntPtr.Zero, 3, 0, IntPtr.Zero)) {
            if (!h.IsInvalid) {
              IntPtr pp; HIDP_CAPS c = new HIDP_CAPS();
              if (HidD_GetPreparsedData(h, out pp)) { HidP_GetCaps(pp, out c); HidD_FreePreparsedData(pp); }
              int k = low.IndexOf("pid_");
              res.Add(new Iface { Path = p, Page = c.UsagePage, In = c.InLen, Out = c.OutLen, Feat = c.FeatLen, Pid = k >= 0 ? low.Substring(k + 4, 4).ToUpperInvariant() : "" });
            }
          }
        }
      }
      Marshal.FreeHGlobal(buf);
    }
    SetupDiDestroyDeviceInfoList(set);
    return res;
  }

  static Iface ctrl, tft, dongle;

  public static string Probe() {
    ctrl = null; tft = null; dongle = null;
    var all = Enum();
    foreach (var i in all) {
      if (i.Pid == "FDFD" && i.Page == 0xFF60 && i.Out == 33) dongle = i;
      if (i.Pid != "8009" && i.Pid != "800A") continue;
      if (i.Page == 0xFF13 && i.Feat == 65) ctrl = i;
      if (i.Page == 0xFF68 && i.Out == 4097) tft = i;
    }
    if (ctrl != null) return "ok " + ctrl.Pid + " " + (tft != null ? "tft" : "notft");
    if (dongle != null) return "dongle";
    foreach (var i in all) if (i.Pid == "8009" || i.Pid == "800A") return "other " + i.Pid;
    return "none";
  }

  static SafeFileHandle Open(Iface i) {
    var h = CreateFile(i.Path, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
    if (h.IsInvalid) throw new Exception("Tastatur lässt sich nicht öffnen (" + Marshal.GetLastWin32Error() + ")");
    return h;
  }

  static byte[] Exchange(SafeFileHandle h, byte[] p) {
    var wire = new byte[65];
    Array.Copy(p, 0, wire, 1, 64);
    Thread.Sleep(35);
    if (!HidD_SetFeature(h, wire, 65)) throw new Exception("Senden fehlgeschlagen (" + Marshal.GetLastWin32Error() + ")");
    Thread.Sleep(50);
    var resp = new byte[65];
    if (!HidD_GetFeature(h, resp, 65)) throw new Exception("Keine Antwort (" + Marshal.GetLastWin32Error() + ")");
    var r = new byte[64];
    Array.Copy(resp, 1, r, 0, 64);
    return r;
  }

  static byte[] Ctl(byte cmd, byte sub, int val) {
    var p = new byte[64]; p[0] = 4; p[1] = cmd; p[2] = sub; p[8] = (byte)(val & 255); p[9] = (byte)((val >> 8) & 255);
    return p;
  }

  static void Ack(byte[] r, byte cmd) {
    if (r[0] != 4 || r[1] != cmd || r[3] != 1)
      throw new Exception("Tastatur hat Befehl " + cmd.ToString("X2") + " nicht bestätigt: " + BitConverter.ToString(r, 0, 9));
  }

  static void Start(SafeFileHandle h, int flag) {
    for (int i = 0; i < 9; i++) {
      var r = Exchange(h, Ctl(0x18, 0, flag));
      bool zero = true; foreach (var b in r) if (b != 0) { zero = false; break; }
      bool busy = zero || (r[0] == 4 && r[1] == 0x18 && r[2] == 0 && r[3] == 0xFF);
      if (!busy) { Ack(r, 0x18); return; }
      Thread.Sleep(300);
    }
    Ack(Exchange(h, Ctl(0x18, 0, flag)), 0x18);
  }

  static void Transaction(SafeFileHandle h, int flag, byte[] command, List<byte[]> data) {
    Exception err = null;
    try {
      Start(h, flag);
      Ack(Exchange(h, command), command[1]);
      foreach (var p in data) Exchange(h, p);
      Ack(Exchange(h, Ctl(0x02, 0, 0)), 0x02);
    } catch (Exception e) { err = e; }
    try { Ack(Exchange(h, Ctl(0xF0, 0, flag)), 0xF0); } catch (Exception e) { if (err == null) err = e; }
    if (err != null) throw err;
  }

  static void Need() { if (ctrl == null && !Probe().StartsWith("ok")) throw new Exception("AK820 Pro nicht im Kabelmodus gefunden"); }

  /* Funk-Dongle (0C45:FDFD, Usage-Page 0xFF60): 32-Byte-Pakete [cmd, 0x10, 0, 16 Byte Daten …, Summe] */
  static bool UseDongle() {
    if (ctrl != null) return false;
    string p = Probe();
    if (p.StartsWith("ok")) return false;
    if (dongle == null) throw new Exception("AK820 Pro nicht gefunden");
    return true;
  }
  static void DongleSend(byte cmd, byte[] payload) {
    var r = new byte[33];
    r[1] = cmd; r[2] = 0x10; r[3] = 0;
    Array.Copy(payload, 0, r, 4, 16);
    int sum = 0; for (int i = 1; i < 32; i++) sum += r[i];
    r[32] = (byte)(sum & 255);
    using (var h = CreateFile(dongle.Path, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero)) {
      if (h.IsInvalid) throw new Exception("Dongle lässt sich nicht öffnen (" + Marshal.GetLastWin32Error() + ")");
      using (var fs = new FileStream(h, FileAccess.ReadWrite, 33, false)) {
        fs.Write(r, 0, 33);
        var ack = new byte[33];
        var t = fs.ReadAsync(ack, 0, 33);
        t.Wait(800);
      }
    }
    Thread.Sleep(60);
  }

  public static string Light(int mode, int r, int g, int b, int bright, int speed, int dir, int colorful) {
    if (UseDongle()) {
      if (mode < 0 || mode > 0x13 || bright < 0 || bright > 5 || speed < 0 || speed > 5 || dir < 0 || dir > 3) throw new Exception("Ungültige Lichtwerte");
      var d = new byte[16];
      d[0] = (byte)mode; d[1] = (byte)r; d[2] = (byte)g; d[3] = (byte)b;
      d[8] = (byte)(colorful != 0 ? 1 : 0); d[9] = (byte)bright; d[10] = (byte)speed; d[11] = (byte)dir;
      d[14] = 0xAA; d[15] = 0x55;
      DongleSend(0x05, d);
      return "ok";
    }
    Need();
    if (mode < 0 || mode > 0x13 || bright < 0 || bright > 5 || speed < 0 || speed > 5 || dir < 0 || dir > 3) throw new Exception("Ungültige Lichtwerte");
    int m = mode, sp = speed, br = bright;
    if (mode == 0) { m = 2; sp = 0; br = 0; }        // Aus
    else if (mode == 1) { m = 7; sp = 0; }           // Statisch = Atmen mit Tempo 0
    var p = new byte[64];
    p[0] = (byte)m; p[1] = (byte)r; p[2] = (byte)g; p[3] = (byte)b;
    p[8] = (byte)(colorful != 0 ? 1 : 0); p[9] = (byte)br; p[10] = (byte)sp; p[11] = (byte)dir;
    p[14] = 0x55; p[15] = 0xAA;
    using (var h = Open(ctrl)) Transaction(h, 1, Ctl(0x13, 0, 1), new List<byte[]> { p });
    return "ok";
  }

  public static string Clock(int yy, int mo, int dd, int hh, int mi, int ss, int wd) {
    if (UseDongle()) {
      var d = new byte[16];
      d[1] = 1; d[2] = 0x5A; d[3] = (byte)yy; d[4] = (byte)mo; d[5] = (byte)dd; d[6] = (byte)hh; d[7] = (byte)mi; d[8] = (byte)ss; d[10] = (byte)wd;
      d[14] = 0xAA; d[15] = 0x55;
      DongleSend(0x0C, d);
      return "ok";
    }
    Need();
    var p = new byte[64];
    p[1] = 1; p[2] = 0x5A; p[3] = (byte)yy; p[4] = (byte)mo; p[5] = (byte)dd; p[6] = (byte)hh; p[7] = (byte)mi; p[8] = (byte)ss;
    p[10] = 4; p[62] = 0xAA; p[63] = 0x55;
    using (var h = Open(ctrl)) Transaction(h, 1, Ctl(0x28, 0, 1), new List<byte[]> { p });
    return "ok";
  }

  public static string Sleep(int minutes) {
    Need();
    int code = minutes == 0 ? 0 : minutes == 1 ? 1 : minutes == 5 ? 2 : minutes == 30 ? 3 : -1;
    if (code < 0) throw new Exception("Schlafzeit muss 0, 1, 5 oder 30 Minuten sein");
    var p = new byte[64]; p[8] = (byte)code; p[62] = 0xAA; p[63] = 0x55;
    using (var h = Open(ctrl)) Transaction(h, 1, Ctl(0x17, 1, 1), new List<byte[]> { p });
    return "ok";
  }

  public static string Battery() {
    if (UseDongle()) {
      using (var h = CreateFile(dongle.Path, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero))
      using (var fs = new FileStream(h, FileAccess.ReadWrite, 33, false)) {
        var q = new byte[33]; q[1] = 0x20; q[2] = 1; q[32] = 0x21;
        fs.Write(q, 0, 33);
        var a = new byte[33];
        var t = fs.ReadAsync(a, 0, 33);
        if (t.Wait(800) && a[1] == 0x20 && a[2] == 1 && a[4] > 0 && a[4] <= 100) return "ok " + a[4];
      }
      return "ok -1";
    }
    Need();
    using (var h = Open(ctrl)) {
      var wire = new byte[65]; wire[1] = 0x20; wire[2] = 1;
      HidD_SetFeature(h, wire, 65); Thread.Sleep(50);
      var resp = new byte[65];
      if (!HidD_GetFeature(h, resp, 65)) return "ok -1";
      if (resp[1] == 0x20 && resp[2] == 1) return "ok " + resp[4];
      return "ok -1";
    }
  }

  public static string Tft(string file, int slot) {
    Need();
    if (tft == null) throw new Exception("Display-Schnittstelle nicht gefunden");
    if (slot < 1 || slot > 3) throw new Exception("Platz 1–3");
    byte[] data = File.ReadAllBytes(file);
    if (data.Length == 0 || data.Length % 4096 != 0 || data.Length > 4096 * 260) throw new Exception("Ungültige Bilddaten");
    int chunks = data.Length / 4096;
    using (var c = Open(ctrl))
    using (var t = Open(tft))
    using (var fs = new FileStream(t, FileAccess.ReadWrite, 4097, false)) {
      Start(c, 0);
      try {
        Ack(Exchange(c, Ctl(0x72, (byte)slot, chunks)), 0x72);
        var report = new byte[4097];
        var ack = new byte[Math.Max(65, (int)tft.In)];
        for (int i = 0; i < chunks; i++) {
          Array.Copy(data, i * 4096, report, 1, 4096);
          fs.Write(report, 0, 4097);
          var task = fs.ReadAsync(ack, 0, ack.Length);
          if (!task.Wait(1500)) throw new Exception("Keine Bestätigung für Bildteil " + (i + 1) + "/" + chunks);
          Console.Out.WriteLine("progress " + (i + 1) + " " + chunks);
        }
        Ack(Exchange(c, Ctl(0x02, 0, 0)), 0x02);
      } catch {
        try { Exchange(c, Ctl(0xF0, 0, 1)); } catch { }
        throw;
      }
    }
    return "ok";
  }

  public static void Run() {
    string line;
    while ((line = Console.In.ReadLine()) != null) {
      var a = line.Split(' ');
      string res;
      try {
        switch (a[0]) {
          case "PROBE": res = Probe(); break;
          case "LIGHT": res = Light(int.Parse(a[1]), int.Parse(a[2]), int.Parse(a[3]), int.Parse(a[4]), int.Parse(a[5]), int.Parse(a[6]), int.Parse(a[7]), int.Parse(a[8])); break;
          case "CLOCK": res = Clock(int.Parse(a[1]), int.Parse(a[2]), int.Parse(a[3]), int.Parse(a[4]), int.Parse(a[5]), int.Parse(a[6]), int.Parse(a[7])); break;
          case "SLEEP": res = Sleep(int.Parse(a[1])); break;
          case "BATT": res = Battery(); break;
          case "TFT": res = Tft(Encoding.UTF8.GetString(Convert.FromBase64String(a[1])), int.Parse(a[2])); break;
          case "QUIT": return;
          default: res = "err unbekannt"; break;
        }
      } catch (Exception e) { res = "err " + e.Message.Replace("\n", " "); }
      Console.Out.WriteLine("done " + res);
      Console.Out.Flush();
    }
  }
}
`;

const MODES = [
  [0, 'Aus'], [1, 'Statisch'], [7, 'Atmen'], [8, 'Farbwechsel'], [6, 'Bunt'], [4, 'Glitzern'], [5, 'Fallend'], [9, 'Nach außen'], [10, 'Lauflicht'], [11, 'Rollen'],
  [12, 'Drehen'], [13, 'Explosion'], [14, 'Start'], [15, 'Wellen'], [16, 'Fließen'], [17, 'Pulsieren'], [18, 'Neigen'], [19, 'Pendel'], [2, 'Taste leuchtet auf'], [3, 'Taste geht aus'],
];

class AjazzKeyboard {
  constructor({ dir, onProgress }) {
    this.dir = dir;
    this.onProgress = onProgress || (() => {});
    this.child = null;
    this.queue = [];
    this.idle = 0;
  }

  spawn() {
    const file = path.join(this.dir, 'ajazz-helper.ps1');
    fs.mkdirSync(this.dir, { recursive: true });
    fs.writeFileSync(file, `﻿$ErrorActionPreference='Stop'\r\nAdd-Type -TypeDefinition @'\r\n${CS}\r\n'@\r\n[Ajazz]::Run()\r\n`, 'utf8');
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    this.child = child;
    let buf = '';
    let err = '';
    child.stdout.on('data', (d) => {
      buf += String(d);
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (line.startsWith('progress ')) {
          const [, n, total] = line.split(' ');
          this.onProgress(Number(n) / Number(total));
        } else if (line.startsWith('done ')) {
          const job = this.queue.shift();
          const res = line.slice(5);
          if (job) res.startsWith('err ') ? job.reject(new Error(res.slice(4))) : job.resolve(res.replace(/^ok ?/, '') || 'ok');
        }
      }
    });
    child.stderr.on('data', (d) => (err += d));
    child.on('exit', () => {
      if (this.child === child) this.child = null;
      const msg = err.trim().split(/\r?\n/)[0] || 'Helfer beendet';
      for (const job of this.queue.splice(0)) job.reject(new Error(msg));
    });
    child.stdin.on('error', () => {});
  }

  send(line, timeoutMs = 20000) {
    if (!this.child) this.spawn();
    clearTimeout(this.idle);
    this.idle = setTimeout(() => this.stop(), 120000);
    return new Promise((resolve, reject) => {
      const job = { resolve, reject };
      const timer = setTimeout(() => {
        const i = this.queue.indexOf(job);
        if (i >= 0) this.queue.splice(i, 1);
        reject(new Error('Tastatur antwortet nicht'));
        this.stop();
      }, timeoutMs);
      job.resolve = (v) => (clearTimeout(timer), resolve(v));
      job.reject = (e) => (clearTimeout(timer), reject(e));
      this.queue.push(job);
      this.child.stdin.write(`${line}\n`);
    });
  }

  stop() {
    clearTimeout(this.idle);
    const c = this.child;
    this.child = null;
    if (!c) return;
    try {
      c.stdin.write('QUIT\n');
    } catch {
      /* egal */
    }
    setTimeout(() => {
      try {
        c.kill();
      } catch {
        /* egal */
      }
    }, 500);
  }

  /** 'ok 800A tft' | 'dongle' | 'none' | 'other …' */
  async probe() {
    const r = await this.send('PROBE', 30000);
    if (r.startsWith('800') || /^[0-9A-F]{4} /.test(r)) {
      const [pid, tft] = r.split(' ');
      return { mode: 'cable', pid, tft: tft === 'tft' };
    }
    const mode = r.split(' ')[0];
    return mode === 'dongle' ? { mode: 'dongle', pid: 'FDFD', tft: false } : { mode };
  }

  light({ mode = 1, color = '#ffffff', brightness = 4, speed = 3, direction = 0, colorful = false } = {}) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(color));
    const hex = m ? m[1] : 'ffffff';
    const [r, g, b] = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
    const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Math.round(Number(v) || 0)));
    return this.send(`LIGHT ${clamp(mode, 0, 19)} ${r} ${g} ${b} ${clamp(brightness, 0, 5)} ${clamp(speed, 0, 5)} ${clamp(direction, 0, 3)} ${colorful ? 1 : 0}`);
  }

  clock() {
    const d = new Date();
    return this.send(`CLOCK ${d.getFullYear() % 100} ${d.getMonth() + 1} ${d.getDate()} ${d.getHours()} ${d.getMinutes()} ${d.getSeconds()} ${d.getDay()}`);
  }

  sleep(minutes) {
    return this.send(`SLEEP ${[0, 1, 5, 30].includes(Number(minutes)) ? Number(minutes) : 5}`);
  }

  async battery() {
    const v = Number(await this.send('BATT'));
    return v >= 0 && v <= 100 ? v : null;
  }

  /**
   * Display-Animation hochladen. frames: [{ delay (ms), rgb565: Uint8Array(128*128*2) }], max. 30.
   * Format: 256-Byte-Kopf (Anzahl, Pausen in 2-ms-Schritten, FF), dann die Bilder, auf 4096 aufgefüllt.
   */
  async tft(frames, slot = 1) {
    const list = (Array.isArray(frames) ? frames : []).slice(0, 30);
    if (!list.length) throw new Error('Kein Bild');
    const size = 128 * 128 * 2;
    let data = Buffer.alloc(256 + list.length * size, 0xff);
    data[0] = list.length;
    list.forEach((f, i) => {
      if (list.length > 1) data[i + 1] = Math.max(1, Math.min(255, Math.round((Number(f.delay) || 100) / 2)));
      const px = Buffer.from(f.rgb565 || []);
      if (px.length !== size) throw new Error('Bild hat nicht 128×128 Pixel');
      px.copy(data, 256 + i * size);
    });
    if (list.length === 1) data[1] = 0;
    const padded = Math.ceil(data.length / 4096) * 4096;
    if (padded > data.length) data = Buffer.concat([data, Buffer.alloc(padded - data.length, 0xff)]);
    const file = path.join(this.dir, 'ajazz-tft.bin');
    fs.writeFileSync(file, data);
    return this.send(`TFT ${Buffer.from(file, 'utf8').toString('base64')} ${[1, 2, 3].includes(Number(slot)) ? Number(slot) : 1}`, 120000);
  }
}

module.exports = { AjazzKeyboard, MODES };
