'use strict';

/*
 * Desktop: Personalisierung mit Vorschau. Hintergrund (Blur + Dim), die
 * Revulution-Leiste und die Widgets lassen sich hier direkt an- und ausschalten.
 */
(function () {
  const T = window.HubTools;
  if (!T?.register) return;
  const ctx = () => T.ctx();
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const icon = (n, s) => window.icon(n, s);
  const fileUrl = (p) => `file:///${String(p).replace(/\\/g, '/').replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:')}`;
  const pc = { live: null, busy: false };
  let deskTab = 'overview';
  let deskBg = '';

  const settings = () => ctx().state()?.settings || {};
  const widgets = () => ({ sysLive: true, upcoming: true, screentime: true, speed: true, ...(settings().widgets || {}) });
  const blurOn = () => settings().backdropBlur !== false;
  const blurAmount = () => Math.max(0, Math.min(40, Number(settings().backdropBlurAmount ?? 18)));
  const dimAmount = () => Math.max(0, Math.min(0.75, Number(settings().backdropDim ?? 0.3)));
  const backdrop = () => ctx().state()?.desktopBackdrop || '';
  const WALL_NAMES = { nebula: 'Nebula', aurora: 'Aurora', galaxy: 'Galaxy', synthwave: 'Synthwave', liquid: 'Liquid', silk: 'Silk', waves: 'Waves', ocean: 'Ocean', clouds: 'Clouds', mountains: 'Mountains', fireflies: 'Fireflies', bokeh: 'Bokeh', lava: 'Lava', warp: 'Warp' };

  const fmtTime = () => new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const fmtDay = () => new Date().toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
  const pct = (v) => (v == null || Number.isNaN(Number(v)) ? '–' : `${Math.round(Number(v))} %`);

  function paintClock() {
    const time = document.getElementById('desk-time');
    if (time) time.textContent = fmtTime();
    const day = document.getElementById('desk-day');
    if (day) day.textContent = fmtDay();
    document.querySelectorAll('[data-desk-clock]').forEach((el) => (el.textContent = fmtTime()));
  }

  function paintSystem() {
    const l = pc.live;
    if (!l) return;
    const rows = [['cpu', l.cpu], ['ram', l.ramPct], ['gpu', l.gpu]];
    for (const [key, value] of rows) {
      const out = document.querySelector(`[data-desk-pc="${key}"]`);
      if (out) out.textContent = pct(value);
      const bar = document.querySelector(`[data-desk-bar="${key}"]`);
      if (bar) bar.style.width = `${Math.max(0, Math.min(100, Number(value) || 0))}%`;
    }
  }

  async function loadSystem() {
    if (pc.busy) return;
    pc.busy = true;
    try {
      pc.live = await window.hub.pcLive();
      paintSystem();
    } catch {
      /* Werte bleiben beim letzten Stand */
    }
    pc.busy = false;
  }

  /* ------------------------------------------------------------- Vorschauen */
  function stage(extraClass = '') {
    const bg = backdrop() ? ` style="background-image:url('${fileUrl(backdrop())}')"` : '';
    const tint = blurOn() ? dimAmount() : 0.16;
    return `<div class="desk-stage ${blurOn() ? 'is-blur' : ''} ${extraClass}" style="--blur:${blurAmount()}px;--dim:${tint}">
      <div class="desk-stage-bg"${bg}></div>
      <div class="desk-stage-tint"></div>
      <div class="desk-stage-ui">
        <div class="desk-mini-bar"><b>R</b><i></i><i></i><i></i><span></span><em data-desk-clock>${fmtTime()}</em></div>
        <div class="desk-mini-cards">
          <div class="desk-mini-card"><small>System</small><b>23 %</b><i style="width:23%"></i></div>
          <div class="desk-mini-card"><small>RAM</small><b>61 %</b><i style="width:61%"></i></div>
          <div class="desk-mini-card"><small>Netz</small><b>↓ 86</b><i style="width:72%"></i></div>
        </div>
      </div>
      <span class="desk-stage-tag">${blurOn() ? 'Blur an' : 'Klarer Desktop'}</span>
    </div>`;
  }

  function tabOverview() {
    const replace = Boolean(settings().replaceTaskbar);
    return `<div class="desk-grid">
      <section class="desk-widget desk-clock">
        <div><div class="tool-label">Jetzt</div><time id="desk-time">${fmtTime()}</time><div class="desk-day" id="desk-day">${esc(fmtDay())}</div></div>
        <small>Revulution Desktop · ${replace ? 'Revulution-Leiste aktiv' : 'Windows-Taskleiste aktiv'}</small>
      </section>
      <section class="desk-widget desk-system">
        <div class="list-row" style="padding:0"><div class="tool-label">System</div><small class="muted">live</small></div>
        ${[['cpu', 'Prozessor'], ['ram', 'Arbeitsspeicher'], ['gpu', 'Grafikkarte']].map(([key, name]) => `<div class="desk-file"><span>${esc(name)}</span><b data-desk-pc="${key}">–</b><div class="desk-bar"><i data-desk-bar="${key}" style="width:0%"></i></div></div>`).join('')}
      </section>
      <section class="desk-widget">
        <div class="tool-label">Schnellzugriff</div>
        <div class="desk-actions">
          <button class="desk-action" data-desk-open="control">${icon('control', 18)}<b>Kontrollzentrum</b></button>
          <button class="desk-action" data-desk-open="settings">${icon('settings', 18)}<b>Einstellungen</b></button>
          <button class="desk-action" data-desk-tab="background">${icon('image', 18)}<b>Hintergrund</b></button>
          <button class="desk-action" data-desk-action="lock">${icon('shield', 18)}<b>PC sperren</b></button>
        </div>
      </section>
      <section class="desk-widget desk-taskbar">
        <div class="grow"><div class="tool-label">Taskleiste</div><b>Revulution-Leiste</b><small>Ersetzt die Windows-Taskleiste am oberen Rand.</small></div>
        <button class="switch ${replace ? 'on' : ''}" data-desk-taskbar title="Revulution-Leiste ein- oder ausschalten"></button>
        <div class="desk-preview" aria-hidden="true"><i>R</i><i>K</i><i>E</i><span></span><em>${fmtTime()}</em></div>
      </section>
      <section class="desk-widget desk-quick" style="grid-column:1/-1">
        <div class="grow"><div class="tool-label">Kurz eingestellt</div><b>${blurOn() ? `Hintergrund geblurrt · ${blurAmount()} px` : 'Hintergrund klar'}</b><small>${Object.entries(widgets()).filter(([, v]) => v).length} von 4 Widgets aktiv</small></div>
        <div class="desk-pills"><span class="${blurOn() ? 'on' : ''}">Blur</span><span class="${settings().replaceTaskbar ? 'on' : ''}">Leiste</span><span class="on">Widgets</span></div>
      </section>
    </div>`;
  }

  function tabBackground() {
    const list = ctx().state()?.wallpapers || [];
    const dir = ctx().state()?.wallpaperDir || '';
    return `<div class="desk-custom">
      <section class="desk-pane">
        <div class="desk-pane-head"><div><h3>Hintergrund</h3><p>Der echte Windows-Desktop bleibt hinter dem Hub sichtbar – weichgezeichnet und leicht abgedunkelt, damit alles ruhig wirkt.</p></div></div>
        ${stage()}
        <div class="desk-controls">
          <div class="desk-control-row"><div class="grow"><b>Desktop weichzeichnen</b><small>Dein Windows-Hintergrund, weich hinter Karten und Leisten.</small></div><button class="switch ${blurOn() ? 'on' : ''}" data-desk-toggle="backdropBlur"></button></div>
          <label class="desk-control-row"><div class="grow"><b>Blur-Stärke</b><small>Wenig ist dezenter, viel nimmt alle Details raus.</small></div><div class="range"><input type="range" min="0" max="40" step="1" value="${blurAmount()}" data-desk-range="backdropBlurAmount" /><output>${blurAmount()} px</output></div></label>
          <label class="desk-control-row"><div class="grow"><b>Abdunkelung</b><small>Mehr Abdunkelung = besserer Kontrast für weiße Schrift.</small></div><div class="range"><input type="range" min="0" max="0.75" step="0.05" value="${dimAmount()}" data-desk-range="backdropDim" /><output>${Math.round(dimAmount() * 100)} %</output></div></label>
        </div>
      </section>
      <aside class="desk-pane">
        <div class="desk-pane-head"><div><h3>Windows-Hintergrund</h3><p>Ein Klick setzt das Bild als echten Windows-Hintergrund. Der Hub übernimmt es automatisch.</p></div></div>
        <div class="desk-bg-grid">${list
          .map((id) => `<button class="desk-bg-card ${deskBg === id ? 'on' : ''}" data-desk-bg="${esc(id)}" title="${esc(WALL_NAMES[id] || id)}"><img src="${fileUrl(`${dir}/thumbs/${id}.jpg`)}" alt="" loading="lazy" /><span>${esc(WALL_NAMES[id] || id)}</span><i class="desk-bg-check">${icon('check', 12)}</i></button>`)
          .join('')}</div>
      </aside>
    </div>`;
  }

  function tabTaskbar() {
    const on = Boolean(settings().replaceTaskbar);
    return `<div class="desk-custom">
      <section class="desk-pane">
        <div class="desk-pane-head"><div><h3>Taskleiste</h3><p>Die Revulution-Leiste liegt oben, ist komplett transparent und zeigt Apps, Kontrollzentrum und Uhr. Die Windows-Taskleiste übernimmt sie auf allen Monitoren.</p></div></div>
        <div class="desk-choice">
          <button class="desk-choice-card ${on ? 'on' : ''}" data-desk-taskbar-choice="on">
            <div class="desk-choice-pv rev"><div class="desk-mini-bar"><b>R</b><i></i><i></i><i></i><span></span><em>${fmtTime()}</em></div><div class="desk-choice-pop"><span></span><span></span><span></span></div></div>
            <div class="desk-choice-txt"><b>Revulution-Leiste</b><small>Oben, transparent, mit Drawer und Popups.</small></div>
            <i class="desk-choice-dot"></i>
          </button>
          <button class="desk-choice-card ${on ? '' : 'on'}" data-desk-taskbar-choice="off">
            <div class="desk-choice-pv win"><div class="desk-win-taskbar"><span>⊞</span><i></i><i></i><i></i><em>${fmtTime()}</em></div></div>
            <div class="desk-choice-txt"><b>Windows-Taskleiste</b><small>Original unten, nichts wird verändert.</small></div>
            <i class="desk-choice-dot"></i>
          </button>
        </div>
        <div class="desk-controls">
          <div class="desk-control-row"><div class="grow"><b>Revulution-Leiste verwenden</b><small>Blendet die Windows-Taskleiste aus. Im Vollbild verschwindet die Leiste automatisch.</small></div><button class="switch ${on ? 'on' : ''}" data-desk-taskbar></button></div>
          <div class="desk-control-row"><div class="grow"><b>Windows-Startmenü</b><small>Die Windows-Taste öffnet die App-Übersicht oben – nicht das normale Startmenü.</small></div><button class="btn small" data-desk-taskbar-start>Testen</button></div>
        </div>
      </section>
      <aside class="desk-pane desk-side-note">
        <div class="desk-note-ic">${icon('layers', 22)}</div>
        <h3>Was die Leiste kann</h3>
        <div class="desk-checklist">
          <span>${icon('check', 14)} Apps starten und wechseln</span>
          <span>${icon('check', 14)} Kontrollzentrum & Einstellungen</span>
          <span>${icon('check', 14)} Bildschirmzeit als Popup</span>
          <span>${icon('check', 14)} Windows-Taste öffnet den Drawer</span>
          <span>${icon('check', 14)} Vollbild reicht bis ganz nach unten</span>
        </div>
      </aside>
    </div>`;
  }

  function widgetPreview(key) {
    if (key === 'sysLive')
      return `<div class="desk-wpv w-sys"><div><small>CPU</small><b>23 %</b><i style="width:23%"></i></div><div><small>RAM</small><b>61 %</b><i style="width:61%"></i></div><div><small>GPU</small><b>8 %</b><i style="width:8%"></i></div></div>`;
    if (key === 'upcoming')
      return `<div class="desk-wpv w-agenda"><div><em>14:30</em><span>Team-Meeting</span></div><div><em>18:00</em><span>Training</span></div><div><em>Morgen</em><span>Zahnarzt</span></div></div>`;
    if (key === 'screentime')
      return `<div class="desk-wpv w-screen"><div class="w-screen-top"><small>Bildschirmzeit</small><b>2 Std. 14</b></div><div class="w-screen-row"><span>Explorer</span><i style="width:78%"></i></div><div class="w-screen-row"><span>Opera</span><i style="width:52%"></i></div><div class="w-screen-row"><span>Hub</span><i style="width:31%"></i></div></div>`;
    return `<div class="desk-wpv w-speed"><div><small>Down</small><b>86</b></div><div><small>Up</small><b>34</b></div><div><small>Ping</small><b>12</b></div></div>`;
  }

  function tabWidgets() {
    const w = widgets();
    const dw = settings().desktopWidgets || {};
    const desktopOn = dw.enabled !== false;
    const bg = backdrop() ? ` style="background-image:url('${fileUrl(backdrop())}')"` : '';
    const defs = [
      ['sysLive', 'System Live', 'CPU, RAM, GPU und Laufwerk live auf der Startseite.'],
      ['upcoming', 'Nächste Termine', 'Die nächsten Einträge aus der Agenda direkt auf der Startseite.'],
      ['screentime', 'Bildschirmzeit', 'Uhr-Symbol in der oberen Leiste mit Popup und App-Zeiten.'],
      ['speed', 'WLAN & Speedtest', 'WLAN-Symbol in der Leiste, das den Speedtest öffnet.'],
    ];
    return `<section class="desk-pane desk-desktop-pane">
      <div class="desk-control-row"><div class="grow"><b>Widgets auf dem Windows-Desktop</b><small>Uhr, System, Bildschirmzeit und Termine schweben rechts auf deinem Desktop – sie liegen hinter normalen Fenstern und stören nicht.</small></div><button class="switch ${desktopOn ? 'on' : ''}" data-desk-desktop-widgets aria-label="Widgets auf dem Desktop"></button></div>
      ${desktopOn ? `<div class="desk-dw-list">${[['clock', 'Punktmatrix-Uhr', true], ['face', 'Gesicht', true], ['music', 'Läuft gerade', true], ['system', 'System', true], ['calendar', 'Kalender', true], ['screentime', 'Bildschirmzeit', false], ['upcoming', 'Termine', false], ['eq', 'Sound-Visualizer', true], ['mixer', 'Mixer', false], ['cards', 'Mit Hintergrund', false], ['vinyl', 'Plattenspieler', true]].map(([k, n, def]) => { const on = dw[k] === undefined ? def : dw[k] !== false; return `<button class="desk-dw-chip ${on ? 'on' : ''}" data-desk-dw="${k}" data-on="${on ? 1 : 0}">${esc(n)}</button>`; }).join('')}<small>Widgets frei mit der Maus verschieben – auch auf andere Monitore.</small></div>` : ''}
      <div class="desk-desktop-pv ${desktopOn ? 'on' : ''}">
        <div class="desk-desktop-pv-bg"${bg}></div>
        <div class="desk-desktop-pv-tint"></div>
        <span class="desk-desktop-pv-label">Dein Desktop</span>
        <div class="desk-desktop-pv-stack">
          <div class="dpv-card dpv-clock"><small>Revulution</small><b data-desk-clock>${fmtTime()}</b><span>${esc(fmtDay())}</span></div>
          <div class="dpv-card"><div class="dpv-head">System <em>live</em></div><div class="dpv-row"><span>CPU</span><i><b style="width:23%"></b></i><strong>23 %</strong></div><div class="dpv-row"><span>RAM</span><i><b style="width:61%"></b></i><strong>61 %</strong></div></div>
          <div class="dpv-card"><div class="dpv-head">Bildschirmzeit</div><b class="dpv-total">2 Std. 14</b><div class="dpv-row"><span>Explorer</span><i><b style="width:78%"></b></i></div></div>
        </div>
        <span class="desk-desktop-pv-state">${desktopOn ? 'aktiv' : 'aus'}</span>
      </div>
    </section>
    <div class="desk-widget-grid">${defs
      .map(([key, name, desc]) => `<article class="desk-wcard ${w[key] ? 'on' : ''}"><div class="desk-wpv-wrap">${widgetPreview(key)}</div><div class="desk-wmeta"><div><b>${esc(name)}</b><small>${esc(desc)}</small></div><button class="switch ${w[key] ? 'on' : ''}" data-desk-widget="${key}" aria-label="${esc(name)}"></button></div></article>`)
      .join('')}</div>
      <div class="desk-widget-note">${icon('spark', 15)} Widgets erscheinen auf der Startseite und in der oberen Leiste. Änderungen sind sofort aktiv.</div>`;
  }

  function desktopHtml() {
    const tabs = [['overview', 'Übersicht', 'grid'], ['background', 'Hintergrund', 'image'], ['taskbar', 'Taskleiste', 'layers'], ['widgets', 'Widgets', 'spark']];
    const body = deskTab === 'background' ? tabBackground() : deskTab === 'taskbar' ? tabTaskbar() : deskTab === 'widgets' ? tabWidgets() : tabOverview();
    return `<div class="desk-page">
      <div class="desk-head">
        <span class="desk-hint">Hintergrund, Leiste und Widgets – alles mit Vorschau.</span>
        <nav class="desk-tabs">${tabs.map(([id, name, ic]) => `<button class="${deskTab === id ? 'on' : ''}" data-desk-tab="${id}">${icon(ic, 14)}<span>${name}</span></button>`).join('')}</nav>
      </div>
      ${body}
    </div>`;
  }

  function paintStage() {
    const stage = document.querySelector('.desk-stage');
    if (!stage) return;
    stage.classList.toggle('is-blur', blurOn());
    stage.style.setProperty('--blur', `${blurAmount()}px`);
    stage.style.setProperty('--dim', String(blurOn() ? dimAmount() : 0.16));
    const tag = stage.querySelector('.desk-stage-tag');
    if (tag) tag.textContent = blurOn() ? 'Blur an' : 'Klarer Desktop';
  }

  document.addEventListener('click', (e) => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    const tab = e.target.closest?.('[data-desk-tab]');
    if (tab) {
      deskTab = tab.dataset.deskTab;
      return ctx().render();
    }
    const open = e.target.closest?.('[data-desk-open]');
    if (open) return window.hub.open(open.dataset.deskOpen).catch(() => {});
    if (e.target.closest?.('[data-desk-action="lock"]')) return window.hub.cc.lock().catch(() => {});
    if (e.target.closest?.('[data-desk-taskbar-start]')) return window.hub.taskbar.start().catch(() => {});

    const choice = e.target.closest?.('[data-desk-taskbar-choice]');
    if (choice) {
      const on = choice.dataset.deskTaskbarChoice === 'on';
      return window.hub.taskbar.replace(on).then(() => ctx().render()).catch(() => {});
    }

    if (e.target.closest?.('[data-desk-taskbar]')) {
      const on = !settings().replaceTaskbar;
      return window.hub.taskbar.replace(on).then(() => {
        ctx().toast(on ? 'Revulution-Leiste übernimmt.' : 'Windows-Taskleiste ist wieder da.');
        ctx().render();
      }).catch(() => {});
    }

    const toggle = e.target.closest?.('[data-desk-toggle]');
    if (toggle) {
      const key = toggle.dataset.deskToggle;
      const next = key === 'backdropBlur' ? !blurOn() : true;
      return ctx().settings({ [key]: next }).then(() => paintStage());
    }

    const dwChip = e.target.closest?.('[data-desk-dw]');
    if (dwChip) return ctx().settings({ desktopWidgets: { [dwChip.dataset.deskDw]: dwChip.dataset.on !== '1' } }).then(() => ctx().render());
    if (e.target.closest?.('[data-desk-desktop-widgets]')) {
      const on = settings().desktopWidgets?.enabled === false;
      return window.hub.desktopWidgets.set(on).then(() => {
        ctx().toast(on ? 'Widgets sind jetzt auf deinem Desktop.' : 'Desktop-Widgets sind aus.');
        ctx().render();
      }).catch(() => {});
    }

    const widget = e.target.closest?.('[data-desk-widget]');
    if (widget) {
      const key = widget.dataset.deskWidget;
      const next = !widgets()[key];
      const patch = { widgets: { [key]: next } };
      if (key === 'screentime' || key === 'speed') {
        const current = settings().topbarItems || [];
        patch.topbarItems = next ? [...new Set([...current, key])] : current.filter((x) => x !== key);
      }
      return ctx().settings(patch).then(() => ctx().render());
    }

    const bg = e.target.closest?.('[data-desk-bg]');
    if (bg) {
      const id = bg.dataset.deskBg;
      bg.classList.add('busy');
      return window.pickWallpaperTarget().then((target) => target && window.hub.community.builtinDesktop(id, target)).then((done) => {
        if (!done) return bg.classList.remove('busy');
        deskBg = id;
        ctx().toast(`${WALL_NAMES[id] || 'Hintergrund'} ist jetzt dein Windows-Hintergrund.`);
        setTimeout(() => window.__hubRefreshBackdrop?.(), 1400);
        ctx().render();
      }).catch((error) => {
        bg.classList.remove('busy');
        ctx().toast(String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
      });
    }
  });

  let saveTimer = null;
  document.addEventListener('input', (e) => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    const el = e.target.closest?.('[data-desk-range]');
    if (!el) return;
    const key = el.dataset.deskRange;
    const value = Number(el.value);
    const out = el.parentElement.querySelector('output');
    if (out) out.textContent = key === 'backdropDim' ? `${Math.round(value * 100)} %` : `${value} px`;
    const stage = document.querySelector('.desk-stage');
    if (stage) stage.style.setProperty(key === 'backdropDim' ? '--dim' : '--blur', key === 'backdropDim' ? String(value) : `${value}px`);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => ctx().settings({ [key]: value }), 220);
  });

  setInterval(() => {
    if (ctx().state()?.active !== 'tool-desktop') return;
    paintClock();
  }, 1000);
  setInterval(() => {
    if (ctx().state()?.active === 'tool-desktop') loadSystem();
  }, 6000);

  T.register(
    'tool-desktop',
    {
      nav: 'Desktop',
      title: 'Desktop',
      sub: 'Hintergrund, Leiste & Widgets',
      icon: 'home',
      tint: 'linear-gradient(135deg,#e5e7eb,#6b7280)',
      desc: 'Hintergrund-Blur, Revulution-Leiste und Widgets anpassen – alles mit Vorschau.',
    },
    desktopHtml,
  );

  // Beim ersten Öffnen die Livewerte holen und die Uhr direkt stellen.
  const base = T.html;
  T.html = (id) => {
    const html = base(id);
    if (id === 'tool-desktop') setTimeout(() => { paintClock(); paintStage(); if (pc.live) paintSystem(); loadSystem(); }, 0);
    return html;
  };
})();
