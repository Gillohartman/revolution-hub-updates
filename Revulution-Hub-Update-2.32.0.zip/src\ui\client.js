'use strict';

(() => {
  const $ = (selector) => document.querySelector(selector);
  const view = new URLSearchParams(location.search).get('view') === 'settings' ? 'settings' : 'control';
  const icons = window.icon;
  let state = null;
  let cc = { volume: null, brightness: null, muted: false };
  let live = null;
  let busy = false;

  const close = () => window.hub.client?.close?.().catch(() => {});
  const setting = (key) => Boolean(state?.settings?.[key]);
  const value = (n, suffix = '%') => (n == null ? '–' : `${Math.round(n)}${suffix}`);

  function head(title, sub) {
    return `<header class="head"><div class="head-copy"><h1>${title}</h1><p>${sub}</p></div><button class="close" data-close title="Schließen">${icons('close', 14)}</button></header>`;
  }

  function controlHtml() {
    const s = state?.settings || {};
    const dnd = Boolean(s.dnd);
    const island = Boolean(state?.orbit?.running);
    const game = Boolean(state?.gameMode);
    const awake = Boolean(state?.keepAwake);
    const up = state?.upcoming?.length || 0;
    return `<section class="sheet">
      ${head('Kontrollzentrum', 'Schnellzugriff auf alles, was gerade läuft.')}
      <div class="grid">
        <button class="tile ${dnd ? 'on' : ''}" data-act="dnd">${icons('bell', 16)}<b>Nicht stören</b></button>
        <button class="tile ${island ? 'on' : ''}" data-act="island">${icons('island', 16)}<b>Island</b></button>
        <button class="tile ${game ? 'on' : ''}" data-act="game">${icons('crosshair', 16)}<b>Game-Modus</b></button>
        <button class="tile ${awake ? 'on' : ''}" data-act="awake">${icons('coffee', 16)}<b>Wach halten</b></button>
        <button class="tile" data-act="screenshot">${icons('camera', 16)}<b>Screenshot</b></button>
        <button class="tile" data-act="lock">${icons('shield', 16)}<b>Sperren</b></button>
        <button class="tile" data-act="agenda">${icons('calendar', 16)}<b>Agenda${up ? ` · ${up}` : ''}</b></button>
        <button class="tile" data-act="settings">${icons('settings', 16)}<b>Einstellungen</b></button>
      </div>
      <div class="card">
        <div class="card-label">${icons('volume', 13)} Lautstärke</div>
        <div class="row"><input type="range" min="0" max="100" value="${cc.volume ?? 50}" data-range="volume" /><span class="value">${value(cc.volume)}</span></div>
        <div class="row" style="margin-top:4px"><div class="grow"><small>Helligkeit</small></div><span class="value">${value(cc.brightness)}</span></div>
        <input type="range" min="5" max="100" value="${cc.brightness ?? 70}" data-range="brightness" ${cc.brightness == null ? 'disabled' : ''} />
      </div>
      <div class="card">
        <div class="card-label">${icons('music', 13)} Medien</div>
        <div class="media">
          <button class="mbtn" data-media="prev" title="Vorheriger Titel" style="transform:rotate(180deg)">${icons('arrow', 13)}</button>
          <button class="mbtn" data-media="playpause" title="Play/Pause">${icons('play', 13)}</button>
          <button class="mbtn" data-media="next" title="Nächster Titel">${icons('arrow', 13)}</button>
          <small>Steuert den laufenden Player</small>
        </div>
      </div>
      <div class="card">
        <div class="card-label">${icons('cpu', 13)} System</div>
        <div class="stats"><span>CPU <b data-cc-live="cpu">${live ? Math.round(live.cpu) + '%' : '–'}</b></span><span>RAM <b data-cc-live="ram">${live ? Math.round(live.ramPct) + '%' : '–'}</b></span><span>GPU <b data-cc-live="gpu">${live?.gpu != null ? Math.round(live.gpu) + '%' : '–'}</b></span></div>
      </div>
      <div class="foot"><button class="btn" data-act="settings">${icons('settings', 14)} Einstellungen</button><button class="btn primary" data-act="lock">${icons('shield', 14)} Sperren</button></div>
    </section>`;
  }

  function settingsHtml() {
    const s = state?.settings || {};
    return `<section class="sheet">
      ${head('Einstellungen', 'Schnellzugriff – die vollständigen Optionen liegen im Hub.')}
      <div class="card">
        <div class="row"><div class="grow"><b>Windows-Taskleiste ersetzen</b><small>Oben schwebt die transparente Revulution-Leiste auf allen Monitoren.</small></div><button class="switch ${s.replaceTaskbar ? 'on' : ''}" data-toggle="replaceTaskbar"></button></div>
        <div class="sep"></div>
        <div class="row"><div class="grow"><b>Revulution-Leiste</b><small>Komplett transparent, Apps oben. Windows-Taste öffnet die App-Übersicht.</small></div><span class="value">Oben</span></div>
      </div>
      <div class="card">
        <div class="row"><div class="grow"><b>Nicht stören</b><small>Meldungen bleiben still.</small></div><button class="switch ${s.dnd ? 'on' : ''}" data-toggle="dnd"></button></div>
        <div class="sep"></div>
        <div class="row"><div class="grow"><b>Klicksounds</b><small>Dezenter Ton bei Aktionen.</small></div><button class="switch ${s.sounds !== false ? 'on' : ''}" data-toggle="sounds"></button></div>
      </div>
      <div class="card">
        <div class="row"><div class="grow"><b>Kontrollzentrum</b><small>Lautstärke, Medien, Sperren und System auf einen Blick.</small></div><button class="btn" style="flex:0 0 auto;padding:0 12px" data-act="control">${icons('control', 14)} Öffnen</button></div>
      </div>
      <div class="foot"><button class="btn" data-act="fullsettings">${icons('settings', 14)} Alle Einstellungen</button><button class="btn primary" data-act="lock">${icons('shield', 14)} Sperren</button></div>
      <p class="hint">Die Leiste erscheint auf jedem Monitor. Im Vollbild blendet sie sich automatisch aus.</p>
    </section>`;
  }

  function render() {
    if (!state) return;
    $('#client').innerHTML = view === 'settings' ? settingsHtml() : controlHtml();
  }

  /** Live-Werte nur in die vorhandenen Zahlen schreiben – nicht die ganze Karte neu aufbauen. */
  function paintLive() {
    if (!live) return;
    const values = { cpu: live.cpu, ram: live.ramPct, gpu: live.gpu };
    document.querySelectorAll('[data-cc-live]').forEach((el) => {
      const value = values[el.dataset.ccLive];
      el.textContent = value == null ? '–' : `${Math.round(value)}%`;
    });
  }

  async function load() {
    state = await window.hub.state().catch(() => state);
    if (!state) return;
    render();
    if (view === 'control') {
      const [v, b] = await Promise.all([window.hub.cc.volume().catch(() => null), window.hub.cc.brightness().catch(() => null)]);
      cc.volume = v?.level ?? null;
      cc.muted = Boolean(v?.muted);
      cc.brightness = b;
      const next = await window.hub.pcLive().catch(() => null);
      if (next) live = next;
      render();
    }
  }

  let vt = 0;
  document.addEventListener('input', (event) => {
    if (event.target.dataset.range === 'volume') {
      const level = Number(event.target.value);
      cc.volume = level;
      const out = event.target.parentElement.querySelector('.value');
      if (out) out.textContent = value(level);
      clearTimeout(vt);
      vt = setTimeout(() => window.hub.cc.volume(level).catch(() => {}), 90);
    }
    if (event.target.dataset.range === 'brightness') {
      const level = Number(event.target.value);
      cc.brightness = level;
      const out = event.target.closest('.card')?.querySelector('.row .value');
      if (out) out.textContent = value(level);
      window.hub.cc.brightness(level).catch(() => {});
    }
  });

  document.addEventListener('click', async (event) => {
    if (event.target.closest('[data-close]')) return close();
    const toggle = event.target.closest('[data-toggle]');
    if (toggle && !busy) {
      busy = true;
      const key = toggle.dataset.toggle;
      try {
        if (key === 'replaceTaskbar') await window.hub.taskbar.replace(!state.settings.replaceTaskbar);
        else {
          const current = key === 'sounds' ? state.settings.sounds !== false : Boolean(state.settings[key]);
          await window.hub.setSettings({ [key]: !current });
        }
        await load();
      } finally {
        busy = false;
      }
      return;
    }
    const media = event.target.closest('[data-media]');
    if (media) return window.hub.cc.media(media.dataset.media).catch(() => {});
    const act = event.target.closest('[data-act]')?.dataset.act;
    if (!act) return;
    if (act === 'dnd') {
      await window.hub.setSettings({ dnd: !state.settings.dnd }).catch(() => {});
      return load();
    }
    if (act === 'island') {
      await (state.orbit.running ? window.hub.orbit.stop() : window.hub.orbit.start()).catch(() => {});
      return load();
    }
    if (act === 'game') {
      await window.hub.gameMode(!state.gameMode).catch(() => {});
      return load();
    }
    if (act === 'awake') {
      await window.hub.awake(!state.keepAwake, 0).catch(() => {});
      return load();
    }
    if (act === 'screenshot') return window.hub.cc.screenshot().catch(() => {});
    if (act === 'lock') return window.hub.cc.lock().catch(() => {});
    if (act === 'agenda') {
      await window.hub.open('agenda').catch(() => {});
      return close();
    }
    if (act === 'settings' || act === 'control') {
      const target = act === 'settings' ? 'settings' : 'control';
      await window.hub.client?.view?.(target).catch(() => {});
      return;
    }
    if (act === 'fullsettings') {
      await window.hub.open('settings').catch(() => {});
      return close();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') close();
  });

  load();
  setInterval(() => {
    if (view === 'control' && !document.hidden) window.hub.pcLive().then((next) => { if (next) { live = next; paintLive(); } }).catch(() => {});
  }, 5000);
})();
