(function () {
  const state = { active: 'home', opened: [], settings: { onboarded: true, seenVersion: '9.9.9', backdropBlur: true }, badges: {}, orbit: {}, account: {} };
  const special = { state: async () => state, onState: () => {}, setSettings: async (p) => p };
  const deep = () => new Proxy(function () {}, { get: (_t, k) => (k === 'then' ? undefined : deep()), apply: () => Promise.resolve(null) });
  window.hub = new Proxy(special, { get: (t, k) => (k in t ? t[k] : deep()) });
})();