'use strict';

/*
 * Ganzes PC-RGB direkt aus dem Hub: OpenRGB (GPL-2.0, openrgb.org) läuft unsichtbar als
 * Treiber-Dienst (--server), der Hub spricht dessen offenes SDK-Protokoll (TCP 6742, Version 3)
 * und rechnet gemeinsame Effekte für alle Geräte selbst (Direct-Modus, ~30 Bilder/s).
 */
const fs = require('fs');
const path = require('path');
const net = require('net');
const { spawn, execFile } = require('child_process');

const ZIP = 'https://codeberg.org/OpenRGB/OpenRGB/releases/download/release_1.1/OpenRGB_1.1_Windows_64_8e16de2.zip';
const PORT = 6742;
const PROTO = 3;
const ID = { COUNT: 0, DATA: 1, VERSION: 40, NAME: 50, LIST_UPDATED: 100, RESCAN: 140, UPDATELEDS: 1050, CUSTOM: 1100, UPDATEMODE: 1101, SAVEMODE: 1102 };
const TYPES = ['Mainboard', 'Arbeitsspeicher', 'Grafikkarte', 'Kühler', 'LED-Streifen', 'Tastatur', 'Maus', 'Mauspad', 'Headset', 'Headset-Ständer', 'Gamepad', 'Licht', 'Lautsprecher', 'Virtuell', 'Speicher', 'Gehäuse', 'Mikrofon', 'Zubehör', 'Keypad', 'Laptop', 'Monitor'];
const FLAG = { SPEED: 1, DIR_LR: 2, DIR_UD: 4, DIR_HV: 8, BRIGHTNESS: 16, PER_LED: 32, MODE_COLOR: 64, RANDOM: 128, MANUAL_SAVE: 256 };

/* ---------------------------------------------------------------- Lesen/Schreiben */
class Reader {
  constructor(buf) {
    this.b = buf;
    this.o = 0;
  }
  u16() {
    const v = this.b.readUInt16LE(this.o);
    this.o += 2;
    return v;
  }
  u32() {
    const v = this.b.readUInt32LE(this.o);
    this.o += 4;
    return v;
  }
  i32() {
    const v = this.b.readInt32LE(this.o);
    this.o += 4;
    return v;
  }
  str() {
    const n = this.u16();
    const s = this.b.toString('utf8', this.o, this.o + Math.max(0, n - 1));
    this.o += n;
    return s;
  }
  color() {
    const v = this.u32();
    return [v & 255, (v >> 8) & 255, (v >> 16) & 255];
  }
}

function parseMode(r) {
  const m = { name: r.str(), value: r.i32(), flags: r.u32(), speedMin: r.u32(), speedMax: r.u32(), brightnessMin: r.u32(), brightnessMax: r.u32(), colorsMin: r.u32(), colorsMax: r.u32(), speed: r.u32(), brightness: r.u32(), direction: r.u32(), colorMode: r.u32() };
  const n = r.u16();
  m.colors = [];
  for (let i = 0; i < n; i++) m.colors.push(r.color());
  return m;
}

function parseDevice(buf) {
  const r = new Reader(buf);
  r.u32(); // data_size
  const d = { type: r.i32(), name: r.str(), vendor: r.str(), description: r.str(), version: r.str(), serial: r.str(), location: r.str() };
  const nModes = r.u16();
  d.activeMode = r.i32();
  d.modes = [];
  for (let i = 0; i < nModes; i++) d.modes.push(parseMode(r));
  const nZones = r.u16();
  d.zones = [];
  for (let i = 0; i < nZones; i++) {
    const z = { name: r.str(), type: r.i32(), ledsMin: r.u32(), ledsMax: r.u32(), ledsCount: r.u32() };
    const ml = r.u16();
    if (ml > 0) {
      const h = r.u32();
      const w = r.u32();
      z.matrix = { h, w, map: [] };
      for (let k = 0; k < h * w; k++) z.matrix.map.push(r.u32());
    }
    d.zones.push(z);
  }
  const nLeds = r.u16();
  d.leds = [];
  for (let i = 0; i < nLeds; i++) d.leds.push({ name: r.str(), value: r.u32() });
  const nColors = r.u16();
  d.colors = [];
  for (let i = 0; i < nColors; i++) d.colors.push(r.color());
  return d;
}

const colorU32 = ([r, g, b]) => ((r & 255) | ((g & 255) << 8) | ((b & 255) << 16)) >>> 0;

function packMode(idx, m) {
  const name = Buffer.from(`${m.name}\0`, 'utf8');
  const colors = m.colors || [];
  const size = 4 + 4 + 2 + name.length + 4 * 12 + 2 + 4 * colors.length;
  const b = Buffer.alloc(size);
  let o = 0;
  b.writeUInt32LE(size, o);
  o += 4;
  b.writeInt32LE(idx, o);
  o += 4;
  b.writeUInt16LE(name.length, o);
  o += 2;
  name.copy(b, o);
  o += name.length;
  [m.value, m.flags, m.speedMin, m.speedMax, m.brightnessMin, m.brightnessMax, m.colorsMin, m.colorsMax, m.speed, m.brightness, m.direction, m.colorMode].forEach((v, k) => {
    if (k === 0) b.writeInt32LE(v | 0, o);
    else b.writeUInt32LE(v >>> 0, o);
    o += 4;
  });
  b.writeUInt16LE(colors.length, o);
  o += 2;
  for (const c of colors) {
    b.writeUInt32LE(colorU32(c), o);
    o += 4;
  }
  return b;
}

/* ---------------------------------------------------------------- Effekte */
const hsv = (h, s = 1, v = 1) => {
  const f = (n) => {
    const k = (n + h / 60) % 6;
    return Math.round(255 * (v - v * s * Math.max(0, Math.min(k, 4 - k, 1))));
  };
  return [f(5), f(3), f(1)];
};
const hex = (s) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(s || ''));
  const h = m ? m[1] : 'ffffff';
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
};
const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
const scale = (c, k) => c.map((v) => Math.round(v * k));

const EFFECTS = [
  ['static', 'Statisch'],
  ['wave', 'Regenbogenwelle'],
  ['spectrum', 'Spektrum'],
  ['breath', 'Atmen'],
  ['gradient', 'Verlauf (2 Farben)'],
  ['pulse', 'Pulsieren'],
  ['rainbow', 'Regenbogen drehen'],
  ['comet', 'Komet'],
  ['sparkle', 'Glitzer'],
  ['fire', 'Feuer'],
  ['lava', 'Lava'],
  ['ocean', 'Ozean'],
  ['aurora', 'Polarlicht'],
  ['strobe', 'Blitzlicht'],
  ['chase', 'Lauflicht'],
  ['split', 'Zweifarbig'],
  ['radar', 'Radar'],
  ['twinkle', 'Sternenfunkeln'],
  ['heartbeat', 'Herzschlag'],
  ['off', 'Aus'],
];

/* ---------------------------------------------------------------- Effekt-Mathematik */
const frac = (v) => v - Math.floor(v);
const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const hash = (a, b = 0) => frac(Math.sin(a * 127.1 + b * 311.7) * 43758.5453);
const mod360 = (v) => ((v % 360) + 360) % 360;

/**
 * Farbe einer LED für einen Effekt.
 * x: Position 0…1 auf dem Gerät, t: Sekunden, devPos: Gerät-Index (Versatz), bri: 0…1.
 */
function ledColors(effect, x, t, devPos, c1, c2, bri) {
  const tt = t + devPos * 0.37;
  let c;
  switch (effect) {
    case 'wave':
      c = hsv(mod360(x * 300 + devPos * 30 - t * 100));
      break;
    case 'spectrum':
      c = hsv(mod360(t * 70 + x * 40));
      break;
    case 'breath':
      c = scale(c1, 0.12 + 0.88 * (0.5 - 0.5 * Math.cos(tt * 2.2)));
      break;
    case 'gradient':
      c = mix(c1, c2, 0.5 - 0.5 * Math.cos((x + t * 0.25) * Math.PI * 2));
      break;
    case 'pulse':
      c = mix(c1, c2, 0.5 - 0.5 * Math.cos(tt * 3));
      break;
    case 'rainbow':
      c = hsv(mod360(t * 45 + x * 120));
      break;
    case 'comet': {
      const head = frac(tt * 0.25);
      let d = Math.abs(x - head);
      d = Math.min(d, 1 - d);
      const glow = clamp01(1 - d * 9);
      const core = clamp01(1 - d * 42);
      c = scale(mix(c1, [255, 255, 255], core * 0.75), glow * glow);
      break;
    }
    case 'sparkle': {
      const bucket = Math.floor(t * 8 + devPos * 3);
      const h = hash(Math.round(x * 97) + 1, bucket);
      c = scale(hsv(mod360(x * 300 + tt * 120)), h > 0.72 ? 0.75 + 0.25 * Math.sin(t * 9 + h * 12) : 0.05);
      break;
    }
    case 'fire': {
      const n = 0.5 + 0.5 * Math.sin(x * 17 + tt * 6) * Math.sin(x * 7 - tt * 3.4);
      const flicker = 0.6 + 0.4 * hash(Math.round(x * 61), Math.floor(t * 14));
      c = scale(mix([120, 8, 0], [255, 168, 20], clamp01(0.3 + 0.7 * n)), flicker);
      break;
    }
    case 'lava': {
      const k = 0.5 + 0.5 * Math.sin(x * 9 - tt * 1.2);
      const blob = Math.max(0, Math.sin(x * 12 + tt * 2.4)) ** 3;
      c = scale(mix(mix([40, 0, 0], [255, 60, 0], k), [255, 190, 40], blob), 0.75 + 0.25 * blob);
      break;
    }
    case 'ocean': {
      const k = 0.5 + 0.5 * Math.sin(x * 8 + tt * 1.8);
      c = mix([0, 24, 90], [0, 200, 235], k * k);
      break;
    }
    case 'aurora': {
      const band = 0.5 + 0.5 * Math.sin(x * 6 - tt * 1.1);
      c = scale(mix([20, 255, 170], [160, 60, 255], band), 0.5 + 0.5 * Math.sin(x * 3 + tt * 0.9));
      break;
    }
    case 'strobe':
      c = Math.floor(t * 8) % 2 ? c1 : c2;
      break;
    case 'chase': {
      const width = 1 / 8;
      const d = frac(x - frac(tt * 0.3) + 1);
      const lit = clamp01(1 - d / width);
      c = mix(scale(c2, 0.12), c1, lit * lit);
      break;
    }
    case 'split': {
      const s = 0.5 + 0.12 * Math.sin(t * 1.5);
      c = mix(c1, c2, clamp01((x - s + 0.06) / 0.12));
      break;
    }
    case 'radar': {
      let d = Math.abs(x - frac(tt * 0.22));
      d = Math.min(d, 1 - d);
      c = mix(scale(c1, 0.08), c2, clamp01(1 - d * 6));
      break;
    }
    case 'twinkle': {
      const h = hash(Math.round(x * 57) + 1, Math.floor(t * 2));
      const k = h > 0.7 ? 0.55 + 0.45 * Math.sin(t * 7 + h * 10) : 0.03;
      c = scale(hsv(mod360(h * 360 + tt * 30)), clamp01(k));
      break;
    }
    case 'heartbeat': {
      const ph = frac(tt * 0.85);
      const spike = (p, w) => Math.max(0, 1 - Math.abs(ph - p) / w);
      const k = Math.max(spike(0.08, 0.1), spike(0.28, 0.08) * 0.75);
      c = scale(c1, 0.12 + 0.88 * clamp01(k));
      break;
    }
    case 'off':
      return [0, 0, 0];
    default:
      c = c1;
  }
  return scale(c, bri);
}

class OpenRgb {
  constructor({ dir, onChange, getSwap }) {
    this.getSwap = getSwap || (() => ({}));
    this.dir = path.join(dir, 'openrgb');
    this.cfgDir = path.join(dir, 'openrgb-config');
    this.onChange = onChange || (() => {});
    this.proc = null;
    this.sock = null;
    this.buf = Buffer.alloc(0);
    this.waiting = new Map();
    this.devices = [];
    this.installing = 0;
    this.error = '';
    this.fx = null;
    this.fxTimer = 0;
    this.reapplyTimer = 0;
    this.connecting = null;
  }

  exe() {
    const walk = (d, depth = 0) => {
      try {
        for (const e of fs.readdirSync(d, { withFileTypes: true })) {
          const f = path.join(d, e.name);
          if (e.isFile() && e.name.toLowerCase() === 'openrgb.exe') return f;
          if (e.isDirectory() && depth < 2) {
            const r = walk(f, depth + 1);
            if (r) return r;
          }
        }
      } catch {
        /* fehlt */
      }
      return '';
    };
    return walk(this.dir);
  }

  status() {
    return { installed: Boolean(this.exe()), installing: this.installing, running: Boolean(this.sock), error: this.error, effect: this.fx, effects: EFFECTS, devices: this.devices.map((d, i) => this.publicDevice(d, i)) };
  }

  publicDevice(d, i) {
    return {
      id: i,
      name: d.name,
      vendor: d.vendor,
      type: TYPES[d.type] || 'Gerät',
      typeId: d.type,
      leds: d.leds.length,
      zones: d.zones.filter((z) => z.ledsCount > 0).map((z) => ({ name: z.name, leds: z.ledsCount, swap: this.swapped(d, z) })),
      activeMode: d.activeMode,
      color: d.colors[0] ? `#${d.colors[0].map((v) => v.toString(16).padStart(2, '0')).join('')}` : '#000000',
      modes: d.modes.map((m, k) => ({ id: k, name: m.name, speed: Boolean(m.flags & FLAG.SPEED), brightness: Boolean(m.flags & FLAG.BRIGHTNESS), color: Boolean(m.flags & (FLAG.MODE_COLOR | FLAG.PER_LED)), colorsMax: m.colorsMax, speedMin: m.speedMin, speedMax: m.speedMax, curSpeed: m.speed, brightnessMin: m.brightnessMin, brightnessMax: m.brightnessMax, curBrightness: m.brightness })),
    };
  }

  async install() {
    if (this.exe() || this.installing) return this.status();
    this.installing = 0.01;
    this.error = '';
    this.onChange(this.status());
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      const res = await require('electron').net.fetch(ZIP);
      if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
      const total = Number(res.headers.get('content-length')) || 22e6;
      const reader = res.body.getReader();
      const chunks = [];
      let got = 0;
      let last = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(Buffer.from(value));
        got += value.length;
        this.installing = Math.min(0.95, got / total);
        if (Date.now() - last > 300) {
          last = Date.now();
          this.onChange(this.status());
        }
      }
      const zip = path.join(this.dir, 'openrgb.zip');
      fs.writeFileSync(zip, Buffer.concat(chunks));
      await new Promise((resolve, reject) =>
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${this.dir.replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 180000 }, (e) => (e ? reject(new Error('Entpacken fehlgeschlagen')) : resolve())),
      );
      fs.rmSync(zip, { force: true });
      if (!this.exe()) throw new Error('RGB-Datei fehlt im Paket');
    } catch (error) {
      this.error = error.message || String(error);
    }
    this.installing = 0;
    this.onChange(this.status());
    return this.status();
  }

  /* ---------------------------------------------------------------- Verbindung */
  send(dev, id, payload = Buffer.alloc(0)) {
    if (!this.sock) throw new Error('Nicht verbunden');
    const h = Buffer.alloc(16);
    h.write('ORGB', 0, 'ascii');
    h.writeUInt32LE(dev >>> 0, 4);
    h.writeUInt32LE(id, 8);
    h.writeUInt32LE(payload.length, 12);
    this.sock.write(Buffer.concat([h, payload]));
  }

  request(dev, id, payload, timeout = 8000) {
    return new Promise((resolve, reject) => {
      const key = `${id}`;
      if (!this.waiting.has(key)) this.waiting.set(key, []);
      const job = { resolve, reject };
      job.timer = setTimeout(() => {
        const q = this.waiting.get(key) || [];
        const i = q.indexOf(job);
        if (i >= 0) q.splice(i, 1);
        reject(new Error('RGB-Schnittstelle antwortet nicht'));
      }, timeout);
      this.waiting.get(key).push(job);
      this.send(dev, id, payload);
    });
  }

  onData(chunk) {
    this.buf = Buffer.concat([this.buf, chunk]);
    while (this.buf.length >= 16) {
      if (this.buf.toString('ascii', 0, 4) !== 'ORGB') {
        this.buf = Buffer.alloc(0);
        return;
      }
      const id = this.buf.readUInt32LE(8);
      const size = this.buf.readUInt32LE(12);
      if (this.buf.length < 16 + size) return;
      const body = this.buf.subarray(16, 16 + size);
      this.buf = this.buf.subarray(16 + size);
      if (id === ID.LIST_UPDATED) {
        clearTimeout(this.reloadTimer);
        this.reloadTimer = setTimeout(() => this.reload().catch(() => {}), 500);
        continue;
      }
      const q = this.waiting.get(`${id}`);
      const job = q?.shift();
      if (job) {
        clearTimeout(job.timer);
        job.resolve(Buffer.from(body));
      }
    }
  }

  connectOnce() {
    return new Promise((resolve, reject) => {
      const sock = net.createConnection({ host: '127.0.0.1', port: PORT });
      const fail = (e) => {
        sock.destroy();
        reject(e);
      };
      sock.once('error', fail);
      sock.once('connect', () => {
        sock.off('error', fail);
        sock.on('error', () => {});
        sock.on('close', () => {
          if (this.sock === sock) {
            const want = this.fx;
            this.sock = null;
            this.onChange(this.status());
            // Verbindung weg: Effekt nicht verlieren, sondern nach kurzer Pause neu starten.
            if (want) setTimeout(() => this.startEffect(want).catch(() => {}), 2500);
            else this.stopEffect();
          }
        });
        sock.on('data', (c) => this.onData(c));
        this.sock = sock;
        resolve();
      });
    });
  }

  startServer() {
    const exe = this.exe();
    if (!exe) throw new Error('Erst einrichten');
    if (this.proc) return;
    fs.mkdirSync(this.cfgDir, { recursive: true });
    this.proc = spawn(exe, ['--server', '--server-port', String(PORT), '--config', this.cfgDir], { cwd: path.dirname(exe), windowsHide: true, stdio: 'ignore' });
    this.proc.on('exit', () => {
      this.proc = null;
    });
  }

  /** Verbinden (startet den Dienst bei Bedarf) und Geräte laden. */
  connect() {
    if (this.sock) return Promise.resolve(this.status());
    if (this.connecting) return this.connecting;
    this.connecting = (async () => {
      this.error = '';
      try {
        try {
          await this.connectOnce();
        } catch {
          this.startServer();
          let ok = false;
          for (let i = 0; i < 40 && !ok; i++) {
            await new Promise((r) => setTimeout(r, 500));
            try {
              await this.connectOnce();
              ok = true;
            } catch {
              /* Dienst startet noch */
            }
          }
          if (!ok) throw new Error('RGB-Dienst startet nicht');
        }
        const v = await this.request(0, ID.VERSION, Buffer.from(Uint32Array.of(PROTO).buffer)).catch(() => null);
        this.proto = v ? Math.min(PROTO, v.readUInt32LE(0)) : 0;
        if (this.proto < 3) throw new Error('RGB-Schnittstelle zu alt');
        this.send(0, ID.NAME, Buffer.from('Revulution Hub\0', 'utf8'));
        // Geräteerkennung abwarten: neu laden, bis die Anzahl stabil ist
        let last = -1;
        for (let i = 0; i < 12; i++) {
          await new Promise((r) => setTimeout(r, i ? 1500 : 800));
          const n = (await this.request(0, ID.COUNT)).readUInt32LE(0);
          if (n > 0 && n === last) break;
          last = n;
        }
        await this.reload();
      } catch (error) {
        this.error = error.message || String(error);
      }
      this.connecting = null;
      this.onChange(this.status());
      return this.status();
    })();
    return this.connecting;
  }

  async reload() {
    const c = await this.request(0, ID.COUNT);
    const n = c.readUInt32LE(0);
    const list = [];
    for (let i = 0; i < n; i++) {
      try {
        list.push(parseDevice(await this.request(i, ID.DATA, Buffer.from(Uint32Array.of(this.proto).buffer))));
      } catch (error) {
        this.error = `Gerät ${i}: ${error.message}`;
      }
    }
    this.devices = list;
    this.onChange(this.status());
    return this.status();
  }

  async rescan() {
    await this.connect();
    this.send(0, ID.RESCAN);
    await new Promise((r) => setTimeout(r, 4000));
    return this.reload();
  }

  /* ---------------------------------------------------------------- Steuern */
  directIndex(d) {
    const i = d.modes.findIndex((m) => /^direct$/i.test(m.name));
    if (i >= 0) return i;
    const j = d.modes.findIndex((m) => /custom|static/i.test(m.name) && m.flags & FLAG.PER_LED);
    return j >= 0 ? j : -1;
  }

  /** Zonen mit vertauschtem Rot/Grün (ASRock-Mainboard-LEDs „PCH“ ab Werk, sonst per Schalter). */
  swapped(d, z) {
    const key = `${d.name}|${z.name}`;
    const map = this.getSwap() || {};
    if (key in map) return Boolean(map[key]);
    return /asrock/i.test(d.vendor || d.name) && /^PCH$/i.test(z.name);
  }

  fixColors(d, colors) {
    let start = 0;
    const out = colors.slice();
    for (const z of d.zones) {
      if (this.swapped(d, z)) for (let k = start; k < start + z.ledsCount && k < out.length; k++) out[k] = [out[k][1], out[k][0], out[k][2]];
      start += z.ledsCount;
    }
    return out;
  }

  setLeds(i, colorsIn) {
    const d = this.devices[i];
    if (!d) return;
    const colors = this.fixColors(d, colorsIn);
    const b = Buffer.alloc(4 + 2 + 4 * colors.length);
    b.writeUInt32LE(b.length, 0);
    b.writeUInt16LE(colors.length, 4);
    colors.forEach((c, k) => b.writeUInt32LE(colorU32(c), 6 + k * 4));
    this.send(i, ID.UPDATELEDS, b);
  }

  /** Hardware-Effekt eines Geräts setzen. */
  async setMode(i, modeIdx, { color, color2, speed, brightness, save } = {}) {
    await this.connect();
    this.stopEffect();
    const d = this.devices[i];
    const m = d?.modes[modeIdx];
    if (!m) throw new Error('Effekt nicht gefunden');
    const mode = { ...m, colors: [...(m.colors || [])] };
    if (speed != null && m.flags & FLAG.SPEED) mode.speed = Math.max(Math.min(m.speedMin, m.speedMax), Math.min(Math.max(m.speedMin, m.speedMax), Math.round(Number(speed))));
    if (brightness != null && m.flags & FLAG.BRIGHTNESS) mode.brightness = Math.max(m.brightnessMin, Math.min(m.brightnessMax, Math.round(Number(brightness))));
    if (color && m.flags & FLAG.MODE_COLOR && m.colorsMax > 0) {
      mode.colorMode = 2;
      const n = Math.max(m.colorsMin, Math.min(m.colorsMax, color2 ? 2 : 1)) || 1;
      mode.colors = [hex(color), hex(color2 || color)].slice(0, n);
      while (mode.colors.length < m.colorsMin) mode.colors.push(hex(color));
    }
    this.send(i, save && m.flags & FLAG.MANUAL_SAVE ? ID.SAVEMODE : ID.UPDATEMODE, packMode(modeIdx, mode));
    d.activeMode = modeIdx;
    d.modes[modeIdx] = mode;
    if (color && m.flags & FLAG.PER_LED && !(m.flags & FLAG.MODE_COLOR)) this.setLeds(i, d.leds.map(() => hex(color)));
    if (color) d.colors = d.leds.map(() => hex(color));
    this.onChange(this.status());
    return this.status();
  }

  /** Gemeinsamer Effekt über alle (oder ausgewählte) Geräte, live berechnet. */
  async startEffect({ effect = 'static', color = '#8b6cff', color2 = '#00d5ff', speed = 50, brightness = 100, devices = null } = {}) {
    await this.connect();
    this.stopEffect();
    const ids = (devices && devices.length ? devices : this.devices.map((_d, i) => i)).filter((i) => this.devices[i]);
    if (!ids.length) throw new Error('Keine RGB-Geräte gefunden – Kabel prüfen und neu suchen.');
    // alle Geräte in den Direct-Modus
    for (const i of ids) {
      const d = this.devices[i];
      const k = this.directIndex(d);
      this.send(i, ID.CUSTOM);
      if (k >= 0) d.activeMode = k;
    }
    this.fx = { effect, color, color2, speed, brightness, devices: ids };
    const c1 = hex(color);
    const c2 = hex(color2);
    const bri = Math.max(0, Math.min(100, Number(brightness))) / 100;
    const sp = 0.2 + (Math.max(1, Math.min(100, Number(speed))) / 100) * 3;
    const t0 = Date.now();
    const frame = () => {
      const t = ((Date.now() - t0) / 1000) * sp;
      ids.forEach((i, devPos) => {
        const d = this.devices[i];
        const n = d.leds.length || 1;
        const cols = d.leds.map((_l, k) => ledColors(effect, n > 1 ? k / (n - 1) : 0, t, devPos, c1, c2, bri));
        if (cols.length) this.setLeds(i, cols);
      });
    };
    frame();
    const idle = ['static', 'off'].includes(effect);
    // 15 Bilder/s: langsame Controller (z. B. ASRock USB) kommen sonst nicht hinterher.
    // Statische Farben werden regelmäßig erneut gesendet, damit das Board sie nicht abfallen lässt.
    this.fxTimer = setInterval(() => (this.sock ? frame() : null), idle ? 5000 : 66);
    if (idle) setTimeout(() => this.sock && frame(), 350);
    // Manche Controller springen nach einiger Zeit in ihren Hardware-Modus zurück.
    this.reapplyTimer = setInterval(() => {
      if (!this.sock || !this.fx) return;
      for (const i of ids) this.send(i, ID.CUSTOM);
      frame();
    }, 18000);
    this.onChange(this.status());
    return this.status();
  }

  stopEffect() {
    clearInterval(this.fxTimer);
    clearInterval(this.reapplyTimer);
    this.fxTimer = 0;
    this.reapplyTimer = 0;
    if (this.fx) {
      this.fx = null;
      this.onChange(this.status());
    }
  }

  stop() {
    this.stopEffect();
    try {
      this.sock?.destroy();
    } catch {
      /* egal */
    }
    this.sock = null;
    try {
      this.proc?.kill();
    } catch {
      /* egal */
    }
    this.proc = null;
  }
}

module.exports = { OpenRgb, EFFECTS, parseDevice, packMode, ledColors };
