'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('beatApp', {
  load: () => ipcRenderer.invoke('load'),
  save: (data) => ipcRenderer.invoke('save', data),
  exportWav: (buffer, name) => ipcRenderer.invoke('export', buffer, name),
  reveal: (file) => ipcRenderer.invoke('reveal', file),
});
