'use strict';

/*
 * Runde 11d – Recherche (OSINT-Werkzeugkasten) für Domains, IP-Adressen, Webseiten und eigene Dateien.
 * Nur öffentliche, technische Quellen ohne API-Schlüssel:
 *   RDAP (rdap.org), DNS über HTTPS (dns.google), IP-Infos (ipwho.is), TLS direkt, HTTP direkt,
 *   Zertifikats-Logs (crt.sh), Internet Archive (archive.org).
 * Bewusst KEINE Personensuche (keine Namen, Benutzernamen, Telefonnummern oder Adressen).
 */
const tls = require('tls');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { net } = require('electron');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) RevulutionHub-Recherche';
const DOMAIN = /^(?=.{1,253}$)(?!-)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$/i;
const IPV4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
const IPV6 = /^[0-9a-f:]{2,39}$/i;

/** Eingabe erkennen: URL, Domain oder IP. */
function parseTarget(raw) {
  let s = String(raw || '').trim();
  if (!s) throw new Error('Bitte eine Domain, IP-Adresse oder URL eingeben.');
  if (s.length > 2000) throw new Error('Eingabe ist zu lang.');
  let url = null;
  if (/^https?:\/\//i.test(s)) {
    try {
      url = new URL(s);
    } catch {
      throw new Error('Das ist keine gültige URL.');
    }
    s = url.hostname;
  } else if (/[/?#]/.test(s)) {
    try {
      url = new URL(`https://${s}`);
      s = url.hostname;
    } catch {
      throw new Error('Das ist keine gültige Adresse.');
    }
  }
  s = s.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (s.startsWith('www.') && !url) s = s.slice(4) || s;
  if (IPV4.test(s) || (s.includes(':') && IPV6.test(s))) return { kind: 'ip', ip: s, host: s, url: url?.href || '' };
  let host = s;
  try {
    host = new URL(`https://${s}`).hostname; // IDN → Punycode
  } catch {
    /* bleibt */
  }
  if (!DOMAIN.test(host)) throw new Error('Das sieht nicht nach einer Domain, IP-Adresse oder URL aus.');
  return { kind: 'domain', domain: host, host: url?.hostname || host, url: url?.href || '' };
}

async function getJson(url, { timeout = 12000, accept = 'application/json' } = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const r = await net.fetch(url, { headers: { Accept: accept, 'User-Agent': UA }, signal: ctrl.signal });
    if (r.status === 404) return null;
    if (!r.ok) throw new Error(`Dienst antwortet mit ${r.status}`);
    return await r.json();
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('Zeitüberschreitung – der Dienst antwortet nicht.');
    throw e;
  } finally {
    clearTimeout(t);
  }
}

/* ------------------------------------------------------------------ RDAP (WHOIS-Nachfolger) */
const vcardName = (ent) => {
  const v = ent?.vcardArray?.[1] || [];
  const f = v.find((x) => x[0] === 'fn') || v.find((x) => x[0] === 'org');
  return f ? String(f[3] || '') : '';
};
function rdapEvents(j) {
  const ev = {};
  for (const e of j.events || []) ev[e.eventAction] = e.eventDate;
  return ev;
}
async function rdap(target) {
  const t = parseTarget(target);
  if (t.kind === 'ip') {
    const j = await getJson(`https://rdap.org/ip/${encodeURIComponent(t.ip)}`, { accept: 'application/rdap+json, application/json' });
    if (!j) throw new Error('Keine RDAP-Daten für diese IP.');
    const ev = rdapEvents(j);
    return {
      kind: 'ip', query: t.ip, name: j.name || '', handle: j.handle || '', type: j.type || '', country: j.country || '',
      range: j.startAddress && j.endAddress ? `${j.startAddress} – ${j.endAddress}` : '', cidr: (j.cidr0_cidrs || []).map((c) => `${c.v4prefix || c.v6prefix}/${c.length}`).join(', '),
      registered: ev.registration || '', changed: ev['last changed'] || '',
      orgs: (j.entities || []).map((e) => ({ role: (e.roles || []).join(', '), name: vcardName(e) })).filter((e) => e.name).slice(0, 8),
      port43: j.port43 || '',
    };
  }
  const j = await getJson(`https://rdap.org/domain/${encodeURIComponent(t.domain)}`, { accept: 'application/rdap+json, application/json' });
  if (!j) throw new Error('Für diese Domain gibt es keinen RDAP-Eintrag (manche Länder-Endungen wie .ch bieten kein öffentliches RDAP).');
  const ev = rdapEvents(j);
  const reg = (j.entities || []).find((e) => (e.roles || []).includes('registrar'));
  return {
    kind: 'domain', query: t.domain, name: j.ldhName || t.domain, handle: j.handle || '',
    registrar: vcardName(reg) || '', registrarId: (reg?.publicIds || []).map((p) => `${p.type}: ${p.identifier}`).join(', '),
    registered: ev.registration || '', expires: ev.expiration || '', changed: ev['last changed'] || ev['last update of RDAP database'] || '',
    status: j.status || [], nameservers: (j.nameservers || []).map((n) => String(n.ldhName || '').toLowerCase()).filter(Boolean),
    dnssec: j.secureDNS ? (j.secureDNS.delegationSigned ? 'signiert' : 'nicht signiert') : '',
    abuse: (() => {
      for (const e of reg?.entities || []) if ((e.roles || []).includes('abuse')) {
        const v = e.vcardArray?.[1] || [];
        const mail = v.find((x) => x[0] === 'email');
        return mail ? String(mail[3]) : '';
      }
      return '';
    })(),
  };
}

/* ------------------------------------------------------------------ DNS über HTTPS */
const DNS_TYPES = { 1: 'A', 2: 'NS', 5: 'CNAME', 6: 'SOA', 12: 'PTR', 15: 'MX', 16: 'TXT', 28: 'AAAA', 33: 'SRV', 257: 'CAA', 65: 'HTTPS', 43: 'DS' };
async function dnsQuery(name, type) {
  const j = await getJson(`https://dns.google/resolve?name=${encodeURIComponent(name)}&type=${type}`);
  return (j?.Answer || []).filter((a) => DNS_TYPES[a.type] === type || type === 'ANY').map((a) => ({ type: DNS_TYPES[a.type] || String(a.type), name: a.name, ttl: a.TTL, data: String(a.data || '').replace(/^"|"$/g, '').replace(/" "/g, '') }));
}
async function dns(target) {
  const t = parseTarget(target);
  if (t.kind === 'ip') {
    const rev = t.ip.includes(':') ? null : `${t.ip.split('.').reverse().join('.')}.in-addr.arpa`;
    return { kind: 'ip', query: t.ip, records: rev ? await dnsQuery(rev, 'PTR') : [], note: rev ? '' : 'Rückwärts-Auflösung für IPv6 wird nicht unterstützt.' };
  }
  const d = t.domain;
  const types = ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'CAA'];
  const res = await Promise.all(types.map((ty) => dnsQuery(d, ty).catch(() => [])));
  const records = res.flat();
  const dmarc = (await dnsQuery(`_dmarc.${d}`, 'TXT').catch(() => [])).map((r) => r.data).find((x) => /^v=DMARC1/i.test(x)) || '';
  const spf = records.filter((r) => r.type === 'TXT').map((r) => r.data).find((x) => /^v=spf1/i.test(x)) || '';
  const mail = {
    spf, dmarc,
    spfVerdict: !spf ? 'fehlt' : /[-~]all\b/.test(spf) ? (/-all\b/.test(spf) ? 'streng (-all)' : 'weich (~all)') : /\+all\b/.test(spf) ? 'unsicher (+all)' : 'ohne Abschluss',
    dmarcPolicy: (/\bp=(\w+)/i.exec(dmarc) || [])[1] || '',
  };
  return { kind: 'domain', query: d, records, mail };
}

/* ------------------------------------------------------------------ IP-Infos */
async function ipinfo(target) {
  let ip = '';
  if (String(target || '').trim()) {
    const t = parseTarget(target);
    if (t.kind === 'ip') ip = t.ip;
    else {
      const a = await dnsQuery(t.domain, 'A').catch(() => []);
      ip = a.find((r) => r.type === 'A')?.data || '';
      if (!ip) throw new Error('Die Domain hat keine IPv4-Adresse (A-Eintrag).');
    }
  }
  const j = await getJson(`https://ipwho.is/${encodeURIComponent(ip)}?lang=de`);
  if (!j || j.success === false) throw new Error(j?.message === 'Reserved range' ? 'Private oder reservierte IP-Adresse – dazu gibt es keine öffentlichen Infos.' : 'Keine Infos zu dieser IP.');
  const ptr = j.ip && !j.ip.includes(':') ? await dnsQuery(`${j.ip.split('.').reverse().join('.')}.in-addr.arpa`, 'PTR').catch(() => []) : [];
  return {
    ip: j.ip, type: j.type, own: !ip, continent: j.continent, country: j.country, countryCode: j.country_code, region: j.region, city: j.city, postal: j.postal,
    lat: j.latitude, lon: j.longitude, timezone: j.timezone?.id || '', asn: j.connection?.asn || '', org: j.connection?.org || '', isp: j.connection?.isp || '', domain: j.connection?.domain || '',
    ptr: ptr.map((p) => p.data.replace(/\.$/, '')),
  };
}

/* ------------------------------------------------------------------ TLS-Zertifikat */
function ssl(target) {
  const t = parseTarget(target);
  const host = t.kind === 'ip' ? t.ip : t.host;
  return new Promise((resolve, reject) => {
    const sock = tls.connect({ host, port: 443, servername: t.kind === 'ip' ? undefined : host, rejectUnauthorized: false, timeout: 10000, ALPNProtocols: ['h2', 'http/1.1'] }, () => {
      const c = sock.getPeerCertificate(true);
      if (!c || !c.subject) {
        sock.end();
        return reject(new Error('Kein Zertifikat erhalten.'));
      }
      const chain = [];
      let cur = c;
      const seen = new Set();
      while (cur && cur.fingerprint256 && !seen.has(cur.fingerprint256) && chain.length < 6) {
        seen.add(cur.fingerprint256);
        chain.push({ subject: cur.subject?.CN || cur.subject?.O || '', issuer: cur.issuer?.CN || cur.issuer?.O || '' });
        cur = cur.issuerCertificate;
      }
      const to = Date.parse(c.valid_to);
      const out = {
        host, authorized: sock.authorized, authError: sock.authorizationError ? String(sock.authorizationError) : '',
        subject: c.subject?.CN || '', org: c.subject?.O || '', issuer: c.issuer?.CN || '', issuerOrg: c.issuer?.O || '',
        validFrom: new Date(c.valid_from).toISOString(), validTo: new Date(to).toISOString(), daysLeft: Math.floor((to - Date.now()) / 86400000),
        san: String(c.subjectaltname || '').split(/,\s*/).map((x) => x.replace(/^DNS:/, '')).filter(Boolean).slice(0, 200),
        serial: c.serialNumber || '', fingerprint: c.fingerprint256 || '', bits: c.bits || 0, keyType: c.asn1Curve ? `EC ${c.asn1Curve}` : c.bits ? `RSA ${c.bits}` : '',
        protocol: sock.getProtocol(), cipher: sock.getCipher()?.name || '', alpn: sock.alpnProtocol || '', chain,
      };
      sock.end();
      resolve(out);
    });
    sock.on('timeout', () => {
      sock.destroy();
      reject(new Error('Zeitüberschreitung – Port 443 antwortet nicht.'));
    });
    sock.on('error', (e) => reject(new Error(`TLS-Verbindung fehlgeschlagen: ${e.code || e.message}`)));
  });
}

/* ------------------------------------------------------------------ HTTP: Weiterleitungen, Header, Technik */
function request(url, method = 'GET', maxBody = 600 * 1024) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'http:' ? http : https;
    const started = Date.now();
    const req = lib.request(u, { method, headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,*/*;q=0.8', 'Accept-Language': 'de-CH,de;q=0.9,en;q=0.6' }, rejectUnauthorized: false, timeout: 12000 }, (res) => {
      const ip = res.socket?.remoteAddress || '';
      const chunks = [];
      let size = 0;
      res.on('data', (d) => {
        if (size < maxBody) chunks.push(d);
        size += d.length;
        if (size > maxBody) res.destroy();
      });
      const done = () => resolve({ status: res.statusCode, statusText: res.statusMessage || '', headers: res.headers, body: Buffer.concat(chunks).toString('utf8'), ms: Date.now() - started, ip });
      res.on('end', done);
      res.on('close', done);
    });
    req.on('timeout', () => req.destroy(new Error('Zeitüberschreitung')));
    req.on('error', (e) => reject(new Error(`${e.code || e.message}`)));
    req.end();
  });
}
async function redirects(target, { body = false } = {}) {
  let url = String(target || '').trim();
  if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
  try {
    url = new URL(url).href;
  } catch {
    throw new Error('Das ist keine gültige URL.');
  }
  const hops = [];
  let last = null;
  for (let i = 0; i < 12; i++) {
    let r;
    try {
      r = await request(url, 'GET', body ? 600 * 1024 : 64 * 1024);
    } catch (e) {
      hops.push({ url, error: e.message });
      break;
    }
    last = { ...r, url };
    hops.push({ url, status: r.status, statusText: r.statusText, ms: r.ms, ip: r.ip, location: r.headers.location || '', server: r.headers.server || '' });
    // Meta-Refresh als Weiterleitung erkennen
    const meta = r.status < 300 ? /<meta[^>]+http-equiv=["']?refresh["']?[^>]+content=["']?\d+\s*;\s*url=([^"'>]+)/i.exec(r.body) : null;
    const next = r.status >= 300 && r.status < 400 && r.headers.location ? r.headers.location : meta?.[1];
    if (!next) break;
    try {
      url = new URL(next, url).href;
    } catch {
      break;
    }
    if (hops.some((h) => h.url === url)) {
      hops.push({ url, error: 'Weiterleitungs-Schleife' });
      break;
    }
  }
  return { start: hops[0]?.url || url, final: last?.url || url, hops, last };
}

const SEC_HEADERS = [
  ['strict-transport-security', 'HSTS', 'Erzwingt HTTPS'],
  ['content-security-policy', 'CSP', 'Schützt vor eingeschleusten Skripten'],
  ['x-frame-options', 'X-Frame-Options', 'Schützt vor Clickjacking'],
  ['x-content-type-options', 'X-Content-Type-Options', 'Verhindert Typ-Raten'],
  ['referrer-policy', 'Referrer-Policy', 'Begrenzt weitergegebene Adressen'],
  ['permissions-policy', 'Permissions-Policy', 'Begrenzt Kamera, Mikrofon usw.'],
];
const TECH = [
  ['WordPress', (h, b) => /wp-content|wp-includes/i.test(b)], ['Joomla', (h, b) => /\/media\/jui\/|Joomla!/i.test(b)], ['Drupal', (h, b) => /drupal-settings-json|Drupal\.settings/i.test(b) || /drupal/i.test(h['x-generator'] || '')],
  ['Shopify', (h, b) => /cdn\.shopify\.com/i.test(b) || 'x-shopid' in h], ['Wix', (h, b) => /static\.wixstatic\.com/i.test(b)], ['Squarespace', (h, b) => /static1\.squarespace\.com/i.test(b)], ['Webflow', (h, b) => /webflow\.(js|css)|data-wf-page/i.test(b)],
  ['Next.js', (h, b) => /__NEXT_DATA__|\/_next\/static/i.test(b) || /next\.js/i.test(h['x-powered-by'] || '')], ['Nuxt', (h, b) => /__NUXT__|\/_nuxt\//i.test(b)], ['Gatsby', (h, b) => /___gatsby/i.test(b)], ['Astro', (h, b) => /astro-island|data-astro/i.test(b)],
  ['React', (h, b) => /data-reactroot|react-dom|__REACT/i.test(b)], ['Vue.js', (h, b) => /data-v-[0-9a-f]{6}|vue(\.min)?\.js/i.test(b)], ['Angular', (h, b) => /ng-version=|ng-app/i.test(b)], ['Svelte', (h, b) => /svelte-[a-z0-9]{5,}/i.test(b)],
  ['jQuery', (h, b) => /jquery(\.min)?\.js|jquery-\d/i.test(b)], ['Bootstrap', (h, b) => /bootstrap(\.min)?\.(css|js)/i.test(b)], ['Tailwind CSS', (h, b) => /tailwind/i.test(b)],
  ['Cloudflare', (h) => 'cf-ray' in h || /cloudflare/i.test(h.server || '')], ['Fastly', (h) => /fastly/i.test(h['x-served-by'] || '') || 'x-fastly-request-id' in h], ['Akamai', (h) => /akamai/i.test(h.server || '') || 'x-akamai-transformed' in h],
  ['Amazon CloudFront', (h) => /cloudfront/i.test(h.via || '') || 'x-amz-cf-id' in h], ['Vercel', (h) => 'x-vercel-id' in h || /vercel/i.test(h.server || '')], ['Netlify', (h) => /netlify/i.test(h.server || '') || 'x-nf-request-id' in h], ['GitHub Pages', (h) => /github\.com/i.test(h.server || '')],
  ['nginx', (h) => /nginx/i.test(h.server || '')], ['Apache', (h) => /apache/i.test(h.server || '')], ['Microsoft IIS', (h) => /iis/i.test(h.server || '')], ['LiteSpeed', (h) => /litespeed/i.test(h.server || '')],
  ['PHP', (h) => /php/i.test(h['x-powered-by'] || '') || /PHPSESSID/.test(String(h['set-cookie'] || ''))], ['ASP.NET', (h) => 'x-aspnet-version' in h || /asp\.net/i.test(h['x-powered-by'] || '')], ['Express', (h) => /express/i.test(h['x-powered-by'] || '')],
  ['Google Analytics', (h, b) => /googletagmanager\.com\/gtag|google-analytics\.com/i.test(b)], ['Google Tag Manager', (h, b) => /googletagmanager\.com\/gtm\.js/i.test(b)], ['Matomo', (h, b) => /matomo\.js|piwik\.js/i.test(b)], ['Plausible', (h, b) => /plausible\.io\/js/i.test(b)],
  ['Meta Pixel', (h, b) => /connect\.facebook\.net\/.+fbevents/i.test(b)], ['Hotjar', (h, b) => /static\.hotjar\.com/i.test(b)], ['Cookiebot', (h, b) => /consent\.cookiebot\.com/i.test(b)], ['reCAPTCHA', (h, b) => /recaptcha/i.test(b)],
];
async function web(target) {
  const r = await redirects(target, { body: true });
  if (!r.last) throw new Error(r.hops[0]?.error ? `Seite nicht erreichbar: ${r.hops[0].error}` : 'Seite nicht erreichbar.');
  const h = r.last.headers;
  const b = r.last.body || '';
  const title = (/<title[^>]*>([^<]{0,200})/i.exec(b) || [])[1] || '';
  const meta = (n) => (new RegExp(`<meta[^>]+(?:name|property)=["']${n}["'][^>]+content=["']([^"']{0,300})`, 'i').exec(b) || new RegExp(`<meta[^>]+content=["']([^"']{0,300})["'][^>]+(?:name|property)=["']${n}["']`, 'i').exec(b) || [])[1] || '';
  const generator = meta('generator');
  const tech = TECH.filter(([, test]) => {
    try {
      return test(h, b);
    } catch {
      return false;
    }
  }).map(([n]) => n);
  if (generator && !tech.some((t) => generator.toLowerCase().includes(t.toLowerCase()))) tech.unshift(generator);
  const cookies = [].concat(h['set-cookie'] || []).map((c) => {
    const [pair, ...flags] = String(c).split(';');
    const f = flags.map((x) => x.trim().toLowerCase());
    return { name: pair.split('=')[0].trim(), secure: f.includes('secure'), httpOnly: f.includes('httponly'), sameSite: (f.find((x) => x.startsWith('samesite=')) || '').split('=')[1] || '' };
  });
  return {
    final: r.final, hops: r.hops, status: r.last.status, ms: r.last.ms, ip: r.last.ip, https: r.final.startsWith('https:'),
    title: title.trim(), description: meta('description') || meta('og:description'), generator,
    headers: Object.entries(h).filter(([k]) => k !== 'set-cookie').map(([k, v]) => [k, Array.isArray(v) ? v.join(', ') : String(v)]).sort((a, b2) => a[0].localeCompare(b2[0])),
    security: SEC_HEADERS.map(([k, name, why]) => ({ name, why, value: h[k] ? String(h[k]).slice(0, 300) : '' })),
    cookies, tech: [...new Set(tech)],
  };
}

/* ------------------------------------------------------------------ Zertifikats-Logs (Subdomains) */
async function subdomains(target) {
  const t = parseTarget(target);
  if (t.kind !== 'domain') throw new Error('Subdomains gibt es nur für Domains.');
  const j = await getJson(`https://crt.sh/?q=${encodeURIComponent(`%.${t.domain}`)}&output=json`, { timeout: 30000 });
  const names = new Map();
  for (const row of j || []) {
    for (const n of String(row.name_value || '').split('\n')) {
      const name = n.trim().toLowerCase().replace(/^\*\./, '');
      if (!name.endsWith(t.domain)) continue;
      const seen = names.get(name);
      const at = Date.parse(row.not_before) || 0;
      if (!seen || at > seen.last) names.set(name, { name, last: at, issuer: String(row.issuer_name || '').replace(/.*CN=/, '').slice(0, 60), count: (seen?.count || 0) + 1 });
      else seen.count += 1;
    }
  }
  return { domain: t.domain, list: [...names.values()].sort((a, b) => a.name.localeCompare(b.name)).slice(0, 500), total: names.size };
}

/* ------------------------------------------------------------------ Internet Archive */
async function archive(target) {
  let s = String(target || '').trim();
  if (!s) throw new Error('Bitte eine Domain oder URL eingeben.');
  s = s.replace(/^https?:\/\//i, '');
  const enc = encodeURIComponent(s);
  const [avail, years, first] = await Promise.all([
    getJson(`https://archive.org/wayback/available?url=${enc}`).catch(() => null),
    getJson(`https://web.archive.org/cdx/search/cdx?url=${enc}&output=json&fl=timestamp&collapse=timestamp:4&limit=60`, { timeout: 25000 }).catch(() => null),
    getJson(`https://web.archive.org/cdx/search/cdx?url=${enc}&output=json&fl=timestamp,statuscode,original&limit=1`, { timeout: 25000 }).catch(() => null),
  ]);
  const snap = avail?.archived_snapshots?.closest;
  const ts = (x) => (x ? `${x.slice(0, 4)}-${x.slice(4, 6)}-${x.slice(6, 8)}` : '');
  const yearList = (years || []).slice(1).map((r) => r[0].slice(0, 4));
  return {
    query: s, latest: snap ? { url: snap.url, date: ts(snap.timestamp), status: snap.status } : null,
    first: first?.[1] ? { date: ts(first[1][0]), url: `https://web.archive.org/web/${first[1][0]}/${first[1][2]}` } : null,
    years: yearList, calendar: `https://web.archive.org/web/*/${s}`,
  };
}

/* ------------------------------------------------------------------ Hashes */
function hash(bytes) {
  const buf = Buffer.from(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []));
  if (buf.length > 512 * 1024 * 1024) throw new Error('Datei zu gross (max. 512 MB).');
  const h = (alg) => crypto.createHash(alg).update(buf).digest('hex');
  return { size: buf.length, md5: h('md5'), sha1: h('sha1'), sha256: h('sha256'), sha512: h('sha512') };
}

const TOOLS = { rdap, dns, ipinfo, ssl, web, redirects: (t) => redirects(t).then(({ last: _l, ...rest }) => rest), subdomains, archive, detect: (t) => parseTarget(t) };

/** In main.js: require('./recherche').register(handle) */
function register(handle) {
  handle('rc:run', async (tool, input) => {
    const fn = TOOLS[String(tool || '')];
    if (!fn) throw new Error('Unbekanntes Werkzeug.');
    return fn(String(input ?? '').slice(0, 2000));
  });
  handle('rc:hash', (bytes) => hash(bytes));
}

module.exports = { register, parseTarget, TOOLS, hash };
