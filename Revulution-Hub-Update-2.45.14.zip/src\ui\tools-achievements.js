'use strict';

/* 2.39 Erfolge & Profil: eigene Erfolge mit Fortschrittsringen. Profile von Freunden öffnest du in den Chats. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-achievements';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const ac = { data: null, loading: false, at: 0 };

  function load(force) {
    if (ac.loading || (!force && ac.data && Date.now() - ac.at < 60000)) return;
    ac.loading = true;
    window.hub.achievements().then((d) => {
      ac.data = d;
      ac.at = Date.now();
    }).catch(() => {}).finally(() => {
      ac.loading = false;
      if (active()) ctx().render();
    });
  }
  const ring = (p, tier, tiers, icon) => `<span class="ach-ring ${tier >= tiers ? 'max' : ''}"><svg viewBox="0 0 40 40"><circle class="t" cx="20" cy="20" r="17" pathLength="100"/><circle class="p" cx="20" cy="20" r="17" pathLength="100" style="stroke-dashoffset:${(100 - p * 100).toFixed(1)}"/></svg><i>${esc(icon)}</i></span>`;
  const fmt = (n) => Number(n || 0).toLocaleString('de-CH');

  function html() {
    load();
    const prof = ctx().profile?.() || {};
    const d = ac.data;
    if (!d) return '<p class="muted">Erfolge werden berechnet …</p>';
    return `<div class="ach-hero">
        <div class="ach-me">${window.RevCos?.avatarHtml ? `<div class="ach-av-cos">${window.RevCos.avatarHtml(prof.cos?.eq || {}, 60)}</div>` : `<div class="ach-av">${esc((prof.name || '?').charAt(0).toUpperCase())}</div>`}<div><b>${esc(prof.name || 'Du')}</b><small>◆ ${fmt(prof.points)} Punkte</small></div></div>
        <div class="ach-sum"><b>${d.total}</b><small>von ${d.max} Stufen</small><i style="--p:${(d.total / Math.max(1, d.max)) * 100}%"></i></div>
      </div>
      <div class="ach-grid">${d.list.map((a, i) => `<div class="ach-card ${a.tier ? 'got' : ''}" style="--d:${i * 40}ms">
          ${ring(a.progress, a.tier, a.tiers, a.icon)}
          <div class="ach-meta"><b>${esc(a.title)}</b><small>${esc(a.desc)}</small>
            <div class="ach-tiers">${Array.from({ length: a.tiers }, (_, k) => `<i class="${k < a.tier ? 'on' : ''}"></i>`).join('')}</div>
            <em>${fmt(a.value)} ${esc(a.unit)}${a.next ? ` · nächste Stufe bei ${fmt(a.next)}` : ' · ganz geschafft!'}${a.reward ? ` · +${a.reward} ◆ pro Stufe` : ''}</em></div>
        </div>`).join('')}</div>
      <p class="muted sp-note">Profile von Freunden: in den Chats bei einem Freund auf „Profil“ tippen. Freunde sehen nur deinen Namen, deine Punkte und Erfolge.</p>`;
  }

  T.register(PAGE, { nav: 'Erfolge', title: 'Erfolge', sub: 'Dein Profil und deine Belohnungen', icon: 'spark', tint: 'linear-gradient(135deg,#ffd166,#f59e0b)', desc: 'Sammle Erfolge mit deiner Pflanze, Clips, Bildschirmzeit und mehr – jede Stufe gibt ◆ Punkte.' }, html);
})();
