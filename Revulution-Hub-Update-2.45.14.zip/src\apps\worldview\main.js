'use strict';
/**
 * Weltansicht 2.45 – schlank: eigener Globus (Canvas) statt der 216-MB-3D-Engine.
 * Drei Ebenen: Satelliten, Flüge, Live-Kameras. Daten kommen aus src/main/world-data.js
 * (gemeinsam mit dem Globus-Widget), es läuft kein eigener Server mehr.
 */
const path = require('path');
const { pathToFileURL } = require('url');
const { boot } = require('../shared/boot');
const world = require('../../main/world-data');

const ctx = boot('worldview', __dirname);
const { app, ipcMain } = ctx.electron;
const PAGE = pathToFileURL(path.join(__dirname, 'index.html')).href;

function fromPage(event) {
  const view = ctx.view;
  return Boolean(view && !view.isDestroyed() && event.sender === view.webContents && event.senderFrame === view.webContents.mainFrame && event.senderFrame.url === PAGE);
}

ipcMain.handle('data', async (event, kind) => {
  if (!fromPage(event) || !['satellites', 'flights', 'cameras'].includes(kind)) throw new Error('Ungültige Anfrage.');
  const data = await world.feed(kind);
  if (kind === 'satellites') return world.propagate(data, true);
  return data;
});

ipcMain.handle('appearance', (event) => {
  if (!fromPage(event)) throw new Error('Die Weltansicht ist nicht geöffnet.');
  const settings = ctx.hub.state().settings;
  return { widgetAccent: settings.widgetAccent || '#ff2d2d', worldviewLocation: settings.worldviewLocation === true, lang: settings.language || 'de' };
});

ipcMain.handle('location-setting', (event, enabled) => {
  if (!fromPage(event) || typeof enabled !== 'boolean') throw new Error('Ungültige Standorteinstellung.');
  ctx.hub.setWorldviewLocation(enabled);
});

app.whenReady().then(() => {
  const view = ctx.view;
  if (!view) return;
  const session = view.webContents.session;
  // Standort nur für die eigene Seite, nur wenn die Weltansicht offen ist
  session.setPermissionRequestHandler((wc, permission, callback, details) => {
    callback(wc === view.webContents && permission === 'geolocation' && details.isMainFrame && details.requestingUrl === PAGE && ctx.hub.active === 'worldview');
  });
  session.setPermissionCheckHandler((wc, permission) => wc === view.webContents && permission === 'geolocation' && ctx.hub.active === 'worldview');
  view.webContents.on('will-navigate', (event, url) => { if (url.split('#')[0] !== PAGE) event.preventDefault(); });
  view.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) require('electron').shell.openExternal(url);
    return { action: 'deny' };
  });
});
