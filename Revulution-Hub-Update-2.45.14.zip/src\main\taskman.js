'use strict';

/*
 * 2.45 Eigener Task-Manager: Prozessliste mit CPU (aus der Differenz zweier Abfragen), RAM,
 * Fenstertitel und Pfad. Beenden geht für alles – außer für den Revolution Hub selbst.
 */
const os = require('os');
const { execFile } = require('child_process');
const { app, shell } = require('electron');

const PS = '[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-Process | ForEach-Object { "$($_.Id)`t$($_.ProcessName)`t$($_.CPU)`t$($_.WorkingSet64)`t$($_.MainWindowTitle)`t$($_.Path)`t$($_.Responding)" }';
const CRITICAL = new Set(['system', 'idle', 'csrss', 'wininit', 'winlogon', 'smss', 'lsass', 'services', 'svchost', 'dwm', 'registry', 'fontdrvhost', 'memory compression', 'secure system']);

let last = { at: 0, cpu: new Map() };
let busy = null;

/** Alle eigenen Prozesse (Hauptprozess + Renderer/GPU/Utility) – die darf man nicht beenden. */
function ownPids() {
  const set = new Set([process.pid]);
  try {
    for (const m of app.getAppMetrics()) set.add(m.pid);
  } catch {
    /* egal */
  }
  return set;
}

function list() {
  if (busy) return busy;
  busy = new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', PS], { windowsHide: true, timeout: 15000, maxBuffer: 16 * 1024 * 1024 }, (err, out) => {
      busy = null;
      if (err) return reject(new Error('Prozessliste nicht verfügbar'));
      const now = Date.now();
      const dt = (now - last.at) / 1000;
      const cores = os.cpus().length || 1;
      const own = ownPids();
      const cpuNow = new Map();
      const procs = [];
      for (const line of String(out).split(/\r?\n/)) {
        const [id, name, cpu, mem, title, file, responding] = line.split('\t');
        const pid = Number(id);
        if (!pid && name !== 'Idle') continue;
        const secs = Number(String(cpu).replace(',', '.')) || 0;
        cpuNow.set(pid, secs);
        const prev = last.cpu.get(pid);
        const pct = prev != null && dt > 0.2 ? Math.max(0, Math.min(100, ((secs - prev) / dt / cores) * 100)) : 0;
        procs.push({
          pid,
          name: name || '?',
          cpu: Math.round(pct * 10) / 10,
          mem: Number(mem) || 0,
          title: title || '',
          path: file || '',
          responding: responding !== 'False',
          own: own.has(pid),
          critical: CRITICAL.has(String(name).toLowerCase()),
        });
      }
      last = { at: now, cpu: cpuNow };
      const total = os.totalmem();
      resolve({ procs, ramTotal: total, ramUsed: total - os.freemem(), cores, at: now });
    });
  });
  return busy;
}

function kill(pid, tree = false) {
  const n = Number(pid);
  if (!Number.isInteger(n) || n <= 4) throw new Error('Dieser Prozess kann nicht beendet werden.');
  if (ownPids().has(n)) throw new Error('Der Revolution Hub kann hier nicht beendet werden.');
  return new Promise((resolve, reject) => {
    execFile('taskkill.exe', ['/PID', String(n), ...(tree ? ['/T'] : []), '/F'], { windowsHide: true, timeout: 10000 }, (err, _out, errOut) => {
      if (err) {
        const msg = String(errOut || err.message || '');
        return reject(new Error(/Zugriff|denied|Access/i.test(msg) ? 'Zugriff verweigert – dieser Prozess braucht Administratorrechte.' : msg.trim().split(/\r?\n/).pop() || 'Konnte nicht beendet werden.'));
      }
      resolve(true);
    });
  });
}

function reveal(file) {
  if (typeof file === 'string' && /^[a-z]:\\/i.test(file)) shell.showItemInFolder(file);
  return true;
}

module.exports = { list, kill, reveal };
