'use strict';

/*
 * 2.45.12 Kopfhörer verbunden: Animation oben mittig im Island-Stil.
 *  - AirPods / AirPods Pro: zwei Ohrhörer drehen sich in 3D, dazu Akku links/rechts/Etui als Ringe.
 *  - Alle anderen Bluetooth-Kopfhörer/Audiogeräte: ein drehender Over-Ear-Kopfhörer, Akku als Ring.
 * Die Daten liefert der kleine Helfer vendor/RevBtAudio.exe (native/btaudio): verbundene Geräte alle 3 s,
 * AirPods-Akku aus deren Bluetooth-LE-Funkpaketen. Modelle und Grafik sind eigene (kein Fremdmaterial).
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { BrowserWindow, screen } = require('electron');

const HELPER = path.join(__dirname, 'vendor', 'RevBtAudio.exe');
const PAGE = path.join(__dirname, '..', 'ui', 'audio-connect.html');
const W = 460;
const H = 240;
const SHOW_MS = 6500;

class AudioConnect {
  constructor({ enabled = () => true } = {}) {
    this.enabled = enabled;
    this.child = null;
    this.known = null; // Geräte beim Start: dafür keine Animation
    this.win = null;
    this.current = null;
    this.pods = null;
    this.hideTimer = null;
  }

  available() {
    return process.platform === 'win32' && fs.existsSync(HELPER);
  }

  start() {
    if (this.child || !this.available()) return false;
    const child = spawn(HELPER, [], { windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'] });
    this.child = child;
    let buf = '';
    child.stdout.on('data', (chunk) => {
      buf += chunk.toString('utf8');
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (!line) continue;
        try {
          this.onMessage(JSON.parse(line));
        } catch {
          /* unvollständige Zeile */
        }
      }
    });
    child.stdin.on('error', () => {});
    child.on('error', () => {});
    child.on('exit', () => {
      if (this.child === child) this.child = null;
    });
    return true;
  }

  stop() {
    const c = this.child;
    this.child = null;
    if (c) {
      try {
        c.stdin.end('QUIT\n');
      } catch {
        /* egal */
      }
      setTimeout(() => {
        try {
          c.kill();
        } catch {
          /* schon beendet */
        }
      }, 1500);
    }
    this.close();
  }

  onMessage(msg) {
    if (msg.type === 'pods') {
      this.pods = { ...msg, at: Date.now() };
      if (this.current?.kind === 'airpods') this.push();
      return;
    }
    if (msg.type !== 'devices' || !Array.isArray(msg.list)) return;
    const ids = new Set(msg.list.map((d) => d.id));
    if (!this.known) {
      this.known = ids;
      return;
    }
    const added = msg.list.find((d) => !this.known.has(d.id));
    this.known = ids;
    if (added && this.enabled()) this.show(added);
  }

  /** Animation zeigen (auch für den Test-Knopf: kind = airpods | headphones). */
  show(device) {
    this.current = {
      id: String(device.id || ''),
      name: String(device.name || (device.kind === 'airpods' ? 'AirPods' : 'Kopfhörer')).slice(0, 60),
      kind: device.kind === 'airpods' ? 'airpods' : 'headphones',
      battery: Number.isFinite(device.battery) ? device.battery : -1,
      demo: device.demo === true,
    };
    const win = this.ensureWindow();
    clearTimeout(this.hideTimer);
    this.hideTimer = setTimeout(() => this.close(), SHOW_MS);
    if (win.webContents.isLoading()) win.webContents.once('did-finish-load', () => this.push(true));
    else this.push(true);
    return true;
  }

  data() {
    const d = { ...this.current };
    if (d.kind === 'airpods') {
      const p = this.pods && Date.now() - this.pods.at < 60000 ? this.pods : null;
      d.left = d.demo ? 92 : p ? p.left : -1;
      d.right = d.demo ? 88 : p ? p.right : -1;
      d.case = d.demo ? 64 : p ? p.case : -1;
      d.chargeCase = d.demo ? true : Boolean(p?.chargeCase);
      d.model = p?.model || '';
    } else if (d.demo && d.battery < 0) d.battery = 76;
    return d;
  }

  push(restart = false) {
    const win = this.win;
    if (!win || win.isDestroyed() || !this.current) return;
    const js = `window.revAudio && window.revAudio(${JSON.stringify(this.data())}, ${restart ? 'true' : 'false'})`;
    win.webContents.executeJavaScript(js, true).catch(() => {});
  }

  ensureWindow() {
    if (this.win && !this.win.isDestroyed()) {
      this.win.showInactive();
      return this.win;
    }
    const display = screen.getPrimaryDisplay();
    const b = display.bounds;
    const win = new BrowserWindow({
      x: Math.round(b.x + (b.width - W) / 2),
      y: b.y + 6,
      width: W,
      height: H,
      frame: false,
      transparent: true,
      resizable: false,
      movable: false,
      focusable: false,
      skipTaskbar: true,
      alwaysOnTop: true,
      hasShadow: false,
      show: false,
      backgroundColor: '#00000000',
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false },
    });
    win.setAlwaysOnTop(true, 'screen-saver');
    win.setIgnoreMouseEvents(true);
    win.loadFile(PAGE);
    win.once('ready-to-show', () => win.showInactive());
    win.on('closed', () => {
      if (this.win === win) this.win = null;
    });
    this.win = win;
    return win;
  }

  close() {
    clearTimeout(this.hideTimer);
    const win = this.win;
    this.win = null;
    this.current = null;
    if (win && !win.isDestroyed()) win.destroy();
  }
}

module.exports = { AudioConnect };
