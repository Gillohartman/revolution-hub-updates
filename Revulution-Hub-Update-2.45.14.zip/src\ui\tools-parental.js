'use strict';

/* 2.43 Kindersicherung: Eltern legen einen PIN fest und stellen Bildschirmzeit, App-Limits und gesperrte Webseiten ein. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-parental';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const fmt = (m) => (m >= 60 ? `${Math.floor(m / 60)} h${m % 60 ? ` ${m % 60} min` : ''}` : `${m} min`);
  const pc = { st: null, loading: false, tab: 'time', err: '', busy: false, intro: true };

  function load() {
    if (pc.loading) return;
    pc.loading = true;
    window.hub.parental.state().then((s) => (pc.st = s)).catch((e) => (pc.err = errText(e))).finally(() => {
      pc.loading = false;
      if (active()) ctx().render();
    });
  }
  async function act(fn, ok) {
    pc.busy = true;
    pc.err = '';
    ctx().render();
    try {
      const r = await fn();
      if (r && typeof r === 'object' && 'enabled' in r) pc.st = r;
      else await window.hub.parental.state().then((s) => (pc.st = s));
      if (ok) ctx().toast?.(ok);
    } catch (e) {
      pc.err = errText(e);
    }
    pc.busy = false;
    if (active()) ctx().render();
  }

  function ring(used, limit) {
    const p = limit ? Math.min(1, used / limit) : 0;
    return `<svg class="pc-ring" viewBox="0 0 44 44"><circle class="t" cx="22" cy="22" r="18" pathLength="100"/><circle class="p ${p >= 1 ? 'full' : ''}" cx="22" cy="22" r="18" pathLength="100" style="--off:${(100 - p * 100).toFixed(1)}"/></svg>`;
  }

  function pinGate(s) {
    const first = !s.hasPin;
    return `<div class="pc-gate"><div class="pc-shield"><svg viewBox="0 0 24 24"><path d="M12 3 4 6v6c0 4.5 3.4 8.3 8 9 4.6-.7 8-4.5 8-9V6z"/><path d="m9 12 2 2 4-4"/></svg></div>
      <h3>${first ? 'Eltern-PIN festlegen' : 'Eltern-PIN eingeben'}</h3>
      <p class="muted">${first ? 'Wähle einen PIN mit 4 bis 8 Ziffern. Nur wer ihn kennt, kann die Kindersicherung ändern, ausschalten oder den Hub beenden.' : 'Die Einstellungen sind geschützt.'}</p>
      <form class="pc-pinrow" data-pc-form="${first ? 'set' : 'unlock'}"><input class="input" id="pc-pin" type="password" inputmode="numeric" maxlength="8" placeholder="PIN" autocomplete="off" />${first ? '<input class="input" id="pc-pin2" type="password" inputmode="numeric" maxlength="8" placeholder="Wiederholen" autocomplete="off" />' : ''}<button class="btn primary" type="submit">${first ? 'Festlegen' : 'Entsperren'}</button></form>
      ${pc.err ? `<p class="err">${esc(pc.err)}</p>` : ''}</div>`;
  }

  function html() {
    if (!pc.st) {
      load();
      return '<p class="muted">Wird geladen …</p>';
    }
    const s = pc.st;
    if (!s.hasPin || !s.unlocked) return pinGate(s);
    const limit = s.dailyMin + (s.extraMin || 0);
    const intro = pc.intro;
    pc.intro = false;
    const tabs = [['time', 'Bildschirmzeit'], ['apps', 'App-Limits'], ['web', 'Webseiten'], ['safe', 'Schutz']];
    const body =
      pc.tab === 'time'
        ? `<div class="pc-card"><div class="pc-row"><div class="grow"><b>Tägliche Bildschirmzeit</b><small>Danach erscheint ein Sperrbildschirm, den nur der PIN öffnet. 0 = kein Limit.</small></div>
             <div class="pc-steps">${[0, 60, 90, 120, 180, 240].map((m) => `<button class="${s.dailyMin === m ? 'on' : ''}" data-pc-daily="${m}">${m ? fmt(m) : 'Aus'}</button>`).join('')}</div></div>
           <div class="pc-row"><div class="grow"><b>Heute Extra-Zeit geben</b><small>Nur für heute${s.extraMin ? ` · schon +${s.extraMin} min` : ''}.</small></div><div class="pc-steps">${[15, 30, 60].map((m) => `<button data-pc-extra="${m}">+${m} min</button>`).join('')}</div></div></div>`
        : pc.tab === 'apps'
          ? `<div class="pc-card"><p class="muted" style="margin:0 0 10px">Die Apps, die heute am meisten genutzt wurden. Ist das Limit erreicht, wird die App für heute geschlossen.</p>
             ${s.apps.length ? s.apps.map((a) => {
               const lim = s.appLimits[String(a.exe).toLowerCase()] || 0;
               return `<div class="pc-app"><div class="grow"><b>${esc(a.name || a.exe)}</b><small>heute ${fmt(a.min)}${lim ? ` · Limit ${fmt(lim)}` : ''}</small><i style="--w:${lim ? Math.min(100, (a.min / lim) * 100) : 0}%"></i></div>
                 <select class="input" data-pc-app="${esc(String(a.exe).toLowerCase())}">${[0, 15, 30, 45, 60, 90, 120, 180].map((m) => `<option value="${m}" ${lim === m ? 'selected' : ''}>${m ? fmt(m) : 'Kein Limit'}</option>`).join('')}</select></div>`;
             }).join('') : '<p class="muted">Noch keine Daten – die Bildschirmzeit sammelt sie im Hintergrund.</p>'}</div>`
          : pc.tab === 'web'
            ? `<div class="pc-card"><b>Kategorien sperren</b><small class="muted" style="display:block;margin-bottom:10px">Gilt in allen Browsern (Chrome, Edge, Brave, Firefox …). Beim ersten Mal fragt Windows nach Admin-Rechten.</small>
                 <div class="pc-cats">${Object.entries(s.catalog).map(([k, c]) => `<button class="${s.categories.includes(k) ? 'on' : ''}" data-pc-cat="${k}"><b>${esc(c.name)}</b><small>${c.count} Seiten</small></button>`).join('')}</div></div>
               <div class="pc-card"><b>Eigene Webseiten sperren</b><div class="pc-add"><input class="input" id="pc-block" placeholder="z. B. beispiel.com" /><button class="btn" data-pc-add="blocked">Sperren</button></div>
                 <div class="pc-chips">${s.blocked.map((d) => `<span>${esc(d)}<button data-pc-del="blocked" data-d="${esc(d)}">✕</button></span>`).join('') || '<small class="muted">Keine.</small>'}</div></div>
               <div class="pc-card"><b>Immer erlauben</b><small class="muted" style="display:block">Ausnahmen, z. B. eine Lern-Seite aus einer gesperrten Kategorie.</small><div class="pc-add"><input class="input" id="pc-allow" placeholder="z. B. youtube.com" /><button class="btn" data-pc-add="allowed">Erlauben</button></div>
                 <div class="pc-chips ok">${s.allowed.map((d) => `<span>${esc(d)}<button data-pc-del="allowed" data-d="${esc(d)}">✕</button></span>`).join('') || '<small class="muted">Keine.</small>'}</div></div>`
            : `<div class="pc-card"><div class="pc-row"><div class="grow"><b>Kindersicherung</b><small>${s.enabled ? 'An: Hub startet mit Windows, Beenden nur mit PIN, Webseiten-Sperre aktiv.' : 'Aus.'}</small></div><button class="switch ${s.enabled ? 'on' : ''}" data-pc-enable></button></div>
                 <div class="pc-row"><div class="grow"><b>PIN ändern</b><small>4 bis 8 Ziffern.</small></div><form class="pc-pinrow small" data-pc-form="change"><input class="input" id="pc-newpin" type="password" inputmode="numeric" maxlength="8" placeholder="Neuer PIN" /><button class="btn" type="submit">Ändern</button></form></div>
                 <div class="pc-row"><div class="grow"><b>Jetzt sperren</b><small>Einstellungen wieder mit PIN schützen.</small></div><button class="btn" data-pc-lock>Sperren</button></div></div>
               <p class="muted sp-note">Tipp: Gib deinem Kind ein normales Windows-Konto ohne Administrator-Rechte – sonst lässt sich jede Kindersicherung umgehen.</p>`;
    return `<div class="pc-hero ${intro ? 'intro' : ''}">
        ${ring(s.usedMin, limit)}
        <div class="pc-hero-txt"><span class="pc-eyebrow">${s.enabled ? 'KINDERSICHERUNG AN' : 'KINDERSICHERUNG AUS'}</span><b>${fmt(s.usedMin)}</b><small>${limit ? `von ${fmt(limit)} heute` : 'heute am PC – kein Tageslimit'}</small></div>
        ${s.enabled ? '' : '<button class="btn primary pc-on" data-pc-enable>Einschalten</button>'}
      </div>
      <div class="seg pc-tabs">${tabs.map(([k, n]) => `<button class="${pc.tab === k ? 'on' : ''}" data-pc-tab="${k}">${n}</button>`).join('')}</div>
      ${pc.err ? `<p class="err">${esc(pc.err)}</p>` : ''}
      ${body}`;
  }

  document.addEventListener('submit', (e) => {
    if (!active()) return;
    const f = e.target.closest('[data-pc-form]');
    if (!f) return;
    e.preventDefault();
    const kind = f.dataset.pcForm;
    if (kind === 'set') {
      const a = document.getElementById('pc-pin').value;
      const b = document.getElementById('pc-pin2').value;
      if (a !== b) {
        pc.err = 'Die beiden PINs sind verschieden.';
        return ctx().render();
      }
      return act(() => window.hub.parental.setPin(a), 'PIN festgelegt.');
    }
    if (kind === 'unlock') {
      return act(async () => {
        const r = await window.hub.parental.unlock(document.getElementById('pc-pin').value);
        if (!r.ok) throw new Error('Falscher PIN.');
        pc.intro = true;
        return r.state;
      });
    }
    if (kind === 'change') return act(() => window.hub.parental.setPin(document.getElementById('pc-newpin').value), 'PIN geändert.');
  });
  document.addEventListener('change', (e) => {
    if (!active()) return;
    const sel = e.target.closest('[data-pc-app]');
    if (!sel) return;
    const limits = { ...(pc.st.appLimits || {}) };
    const m = Number(sel.value) || 0;
    if (m) limits[sel.dataset.pcApp] = m;
    else delete limits[sel.dataset.pcApp];
    act(() => window.hub.parental.update({ appLimits: limits }), 'Gespeichert.');
  });
  document.addEventListener('click', (e) => {
    if (!active() || !pc.st) return;
    const q = (s) => e.target.closest(s);
    const s = pc.st;
    if (q('[data-pc-tab]')) {
      pc.tab = q('[data-pc-tab]').dataset.pcTab;
      return ctx().render();
    }
    if (q('[data-pc-daily]')) return act(() => window.hub.parental.update({ dailyMin: Number(q('[data-pc-daily]').dataset.pcDaily) }), 'Tageslimit gespeichert.');
    if (q('[data-pc-extra]')) return act(() => window.hub.parental.extra(Number(q('[data-pc-extra]').dataset.pcExtra)), 'Extra-Zeit gegeben.');
    if (q('[data-pc-cat]')) {
      const k = q('[data-pc-cat]').dataset.pcCat;
      const cats = s.categories.includes(k) ? s.categories.filter((x) => x !== k) : [...s.categories, k];
      return act(() => window.hub.parental.update({ categories: cats }), 'Gespeichert.');
    }
    if (q('[data-pc-add]')) {
      const kind = q('[data-pc-add]').dataset.pcAdd;
      const v = document.getElementById(kind === 'blocked' ? 'pc-block' : 'pc-allow')?.value.trim();
      if (!v) return;
      return act(() => window.hub.parental.update({ [kind]: [...s[kind], v] }), 'Gespeichert.');
    }
    if (q('[data-pc-del]')) {
      const b = q('[data-pc-del]');
      return act(() => window.hub.parental.update({ [b.dataset.pcDel]: s[b.dataset.pcDel].filter((d) => d !== b.dataset.d) }), 'Entfernt.');
    }
    if (q('[data-pc-enable]')) return act(() => window.hub.parental.enable(!s.enabled), s.enabled ? 'Kindersicherung aus.' : 'Kindersicherung an.');
    if (q('[data-pc-lock]')) return act(() => window.hub.parental.lockNow(), 'Gesperrt.');
  });

  T.register(PAGE, { nav: 'Kindersicherung', title: 'Kindersicherung', sub: 'Bildschirmzeit und Webseiten für Eltern', icon: 'shield', tint: 'linear-gradient(135deg,#0a84ff,#4f46e5)', desc: 'Eltern legen mit einem PIN die tägliche Bildschirmzeit, Limits pro App und gesperrte Webseiten fest.' }, html);
})();
