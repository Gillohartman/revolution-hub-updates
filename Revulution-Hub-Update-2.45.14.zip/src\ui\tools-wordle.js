'use strict';

/*
 * 2.45 Revolution Wordle: Wort mit 5 Buchstaben in 6 Versuchen erraten.
 * Grün = richtiger Buchstabe an richtiger Stelle, Gelb = kommt vor, Grau = kommt nicht vor.
 * Tägliches Wort (für alle gleich) und Endlos-Modus; Statistik reist mit dem Konto.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-wordle';
  const ROWS = 6;
  const LEN = 5;
  const KEYS = ['QWERTZUIOP', 'ASDFGHJKL', '+YXCVBNM-'];
  const st = { mode: 'daily', answer: '', rows: [], cur: '', done: false, won: false, stats: null, loaded: false, root: null, msgTimer: 0, reveal: -1, hard: false };

  const words = () => window.REV_WORDS_DE || [];
  const answers = () => window.REV_WORDS_DE_ANSWERS || words();
  const dayIndex = () => Math.floor((Date.parse(A.today()) - Date.parse('2026-01-01')) / 86400000);

  function score(guess, answer) {
    const res = Array(LEN).fill('miss');
    const left = {};
    for (let i = 0; i < LEN; i++) {
      if (guess[i] === answer[i]) res[i] = 'hit';
      else left[answer[i]] = (left[answer[i]] || 0) + 1;
    }
    for (let i = 0; i < LEN; i++) {
      if (res[i] === 'hit') continue;
      if (left[guess[i]] > 0) {
        res[i] = 'near';
        left[guess[i]] -= 1;
      }
    }
    return res;
  }

  async function load() {
    if (st.loaded) return;
    st.loaded = true;
    st.stats = await A.store.get('wordle', null, true);
    if (!st.stats || typeof st.stats !== 'object') st.stats = { played: 0, wins: 0, streak: 0, best: 0, dist: [0, 0, 0, 0, 0, 0], daily: null, hard: false };
    st.hard = Boolean(st.stats.hard);
    const d = st.stats.daily;
    if (d && d.day === A.today()) {
      Object.assign(st, { mode: 'daily', answer: d.answer, rows: d.rows || [], done: Boolean(d.done), won: Boolean(d.won) });
    } else newGame('daily');
  }
  const save = () => A.store.set('wordle', st.stats, true);

  function newGame(mode) {
    const list = answers();
    st.mode = mode;
    st.answer = mode === 'daily' ? list[Math.floor(A.seeded(`wordle-${dayIndex()}`)() * list.length)] : list[Math.floor(Math.random() * list.length)];
    st.rows = [];
    st.cur = '';
    st.done = false;
    st.won = false;
    st.reveal = -1;
    if (mode === 'daily') {
      const d = st.stats?.daily;
      if (d && d.day === A.today()) Object.assign(st, { answer: d.answer, rows: d.rows || [], done: Boolean(d.done), won: Boolean(d.won) });
    }
  }

  function flash(text) {
    const box = st.root?.querySelector('.wd-board-wrap');
    if (!box) return;
    box.querySelector('.wd-msg')?.remove();
    const el = A.h(`<div class="wd-msg">${esc(text)}</div>`);
    box.appendChild(el);
    clearTimeout(st.msgTimer);
    st.msgTimer = setTimeout(() => el.remove(), 1600);
  }
  function shake() {
    const row = st.root?.querySelector(`.wd-line[data-r="${st.rows.length}"]`);
    if (!row) return;
    row.classList.remove('shake');
    void row.offsetWidth;
    row.classList.add('shake');
  }

  function hardOk(guess) {
    if (!st.hard) return '';
    for (const { word, res } of st.rows) {
      for (let i = 0; i < LEN; i++) {
        if (res[i] === 'hit' && guess[i] !== word[i]) return `${i + 1}. Buchstabe muss ${word[i]} sein`;
        if (res[i] === 'near' && !guess.includes(word[i])) return `${word[i]} muss vorkommen`;
      }
    }
    return '';
  }

  function submit() {
    if (st.done) return;
    const g = st.cur;
    if (g.length < LEN) {
      shake();
      return flash('Zu wenige Buchstaben');
    }
    if (!words().includes(g)) {
      shake();
      return flash('Nicht in der Wortliste');
    }
    const h = hardOk(g);
    if (h) {
      shake();
      return flash(h);
    }
    const res = score(g, st.answer);
    st.rows.push({ word: g, res });
    st.reveal = st.rows.length - 1;
    st.cur = '';
    if (g === st.answer || st.rows.length >= ROWS) {
      st.done = true;
      st.won = g === st.answer;
      const s = st.stats;
      s.played += 1;
      if (st.won) {
        s.wins += 1;
        s.streak += 1;
        s.best = Math.max(s.best, s.streak);
        s.dist[st.rows.length - 1] += 1;
        A.earn(st.mode === 'daily' ? 30 : 10);
      } else s.streak = 0;
      setTimeout(() => flash(st.won ? ['Genial!', 'Großartig!', 'Super!', 'Stark!', 'Gut!', 'Knapp!'][st.rows.length - 1] : st.answer), 5 * 120 + 500);
    }
    if (st.mode === 'daily') st.stats.daily = { day: A.today(), answer: st.answer, rows: st.rows, done: st.done, won: st.won };
    save();
    paint();
  }

  function press(k) {
    if (st.done) return;
    if (k === 'ENTER') return submit();
    if (k === 'BACK') {
      st.cur = st.cur.slice(0, -1);
      return paintBoard();
    }
    if (/^[A-Z]$/.test(k) && st.cur.length < LEN) {
      st.cur += k;
      paintBoard();
    }
  }

  function keyState() {
    const m = {};
    const rank = { miss: 1, near: 2, hit: 3 };
    for (const { word, res } of st.rows) for (let i = 0; i < LEN; i++) if ((rank[res[i]] || 0) > (rank[m[word[i]]] || 0)) m[word[i]] = res[i];
    return m;
  }

  function boardHtml() {
    let out = '';
    for (let r = 0; r < ROWS; r++) {
      const row = st.rows[r];
      const isCur = r === st.rows.length && !st.done;
      const win = row && row.word === st.answer;
      out += `<div class="wd-line ${win && r === st.reveal ? 'win' : ''}" data-r="${r}">`;
      for (let i = 0; i < LEN; i++) {
        if (row) out += `<div class="wd-cell ${row.res[i]} ${r === st.reveal ? '' : 'still'}" style="--i:${i}">${row.word[i]}</div>`;
        else {
          const ch = isCur ? st.cur[i] || '' : '';
          out += `<div class="wd-cell ${ch ? 'filled' : ''}">${ch}</div>`;
        }
      }
      out += '</div>';
    }
    return out;
  }
  function keysHtml() {
    const ks = keyState();
    return KEYS.map((row) => `<div class="wd-krow">${[...row].map((k) => (k === '+' ? '<button class="wd-key wide" data-wd-key="ENTER">ENTER</button>' : k === '-' ? '<button class="wd-key wide" data-wd-key="BACK" aria-label="Löschen">⌫</button>' : `<button class="wd-key ${ks[k] || ''}" data-wd-key="${k}">${k}</button>`)).join('')}</div>`).join('');
  }
  function statsHtml() {
    const s = st.stats;
    const max = Math.max(1, ...s.dist);
    const pct = s.played ? Math.round((s.wins / s.played) * 100) : 0;
    return `<div class="rv-card">
      <div class="rv-row between"><b>Statistik</b><span class="rv-pill">${st.mode === 'daily' ? 'Tageswort' : 'Endlos'}</span></div>
      <div class="wd-stats" style="margin-top:12px"><div><b>${s.played}</b><small>Gespielt</small></div><div><b>${pct}</b><small>% Siege</small></div><div><b>${s.streak}</b><small>Serie</small></div><div><b>${s.best}</b><small>Beste Serie</small></div></div>
      <div class="wd-dist">${s.dist.map((n, i) => `<div><span>${i + 1}</span><i class="${st.done && st.won && st.rows.length === i + 1 ? 'cur' : ''}" style="width:${Math.max(8, (n / max) * 100)}%">${n}</i></div>`).join('')}</div>
    </div>
    <div class="rv-card" style="margin-top:12px">
      <b>Spielmodus</b>
      <div class="rv-row" style="margin-top:10px"><div class="rv-tabs"><button class="${st.mode === 'daily' ? 'on' : ''}" data-wd-mode="daily">Tageswort</button><button class="${st.mode === 'free' ? 'on' : ''}" data-wd-mode="free">Endlos</button></div></div>
      <label class="rv-row" style="margin-top:12px;cursor:pointer"><input type="checkbox" data-wd-hard ${st.hard ? 'checked' : ''}/> <span>Schwerer Modus <small class="rv-muted">(Treffer müssen weiterverwendet werden)</small></span></label>
      ${st.done ? `<div style="margin-top:14px"><p class="rv-muted" style="margin:0 0 8px">${st.won ? `Gelöst in ${st.rows.length}/6.` : `Das Wort war <b>${esc(st.answer)}</b>.`}</p><div class="rv-row"><button class="rv-btn primary" data-wd-new>${st.mode === 'daily' ? 'Endlos spielen' : 'Neues Wort'}</button><button class="rv-btn" data-wd-share>Ergebnis kopieren</button></div></div>` : ''}
    </div>
    <div class="rv-card" style="margin-top:12px"><b>So geht's</b><p class="rv-muted" style="font-size:13px;margin:6px 0 0">Errate das Wort in 6 Versuchen. <b style="color:#30d158">Grün</b>: richtige Stelle, <b style="color:#e6b422">Gelb</b>: kommt vor, Grau: kommt nicht vor. Tippe auf der Tastatur oder unten.</p></div>`;
  }

  function paintBoard() {
    const b = st.root?.querySelector('.wd-board');
    if (b) b.innerHTML = boardHtml();
  }
  function paint() {
    if (!st.root) return;
    st.root.innerHTML = `<div class="wd-scene"><div class="wd-wrap">
      <div class="wd-main" style="position:relative">
        <div class="rv-row between"><div><h2 class="rv-h">Wordle</h2><p class="rv-sub">${st.mode === 'daily' ? `Tageswort · ${new Date().toLocaleDateString('de-CH', { day: 'numeric', month: 'long' })}` : 'Endlos-Modus'}</p></div><span class="rv-pill">${answers().length.toLocaleString('de-CH')} Wörter</span></div>
        <div class="wd-board-wrap"><div class="wd-board">${boardHtml()}</div></div>
        <div class="wd-keys">${keysHtml()}</div>
      </div>
      <div>${statsHtml()}</div>
    </div></div>`;
  }

  function onKey(e) {
    if (!st.root || !document.contains(st.root) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '')) return;
    const k = e.key;
    if (k === 'Enter') press('ENTER');
    else if (k === 'Backspace') press('BACK');
    else if (/^[a-zA-Z]$/.test(k)) press(k.toUpperCase());
    else return;
    e.preventDefault();
  }
  function onClick(e) {
    if (!st.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const key = q('[data-wd-key]')?.dataset.wdKey;
    if (key) return press(key);
    const mode = q('[data-wd-mode]')?.dataset.wdMode;
    if (mode) {
      newGame(mode);
      return paint();
    }
    if (q('[data-wd-new]')) {
      newGame('free');
      return paint();
    }
    if (q('[data-wd-share]')) {
      const grid = st.rows.map((r) => r.res.map((x) => (x === 'hit' ? '🟩' : x === 'near' ? '🟨' : '⬛')).join('')).join('\n');
      navigator.clipboard?.writeText(`Revolution Wordle ${st.mode === 'daily' ? A.today() : ''} ${st.won ? st.rows.length : 'X'}/6\n\n${grid}`).catch(() => {});
      return A.toast('Ergebnis kopiert.');
    }
  }
  function onChange(e) {
    if (!st.root?.contains(e.target) || !e.target.matches('[data-wd-hard]')) return;
    if (st.rows.length && !st.done) {
      e.target.checked = st.hard;
      return A.toast('Den schweren Modus kannst du nur zwischen zwei Runden ändern.', 'error');
    }
    st.hard = e.target.checked;
    st.stats.hard = st.hard;
    save();
  }
  document.addEventListener('keydown', onKey);
  document.addEventListener('click', onClick);
  document.addEventListener('change', onChange);

  A.define(
    ID,
    { nav: 'Wordle', title: 'Wordle', sub: 'Täglich ein neues Wort', icon: 'text', tint: 'linear-gradient(135deg,#30d158,#0f766e)', desc: 'Errate das Wort mit 5 Buchstaben in 6 Versuchen – Tageswort für alle gleich oder endlos, mit Statistik im Konto.' },
    {
      game: true,
      async mount(root) {
        st.root = root;
        root.innerHTML = '<div class="rv-empty">Lädt …</div>';
        await load();
        if (st.root === root) paint();
      },
      unmount() {
        st.root = null;
      },
    },
  );
})();
