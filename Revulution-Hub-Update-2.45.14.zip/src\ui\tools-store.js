'use strict';

/*
 * Revolution Store: alle Designs an einem Ort – mit ◆ Punkten (verdient in Schach und Geo)
 * oder Revolution Coins. Coins gibt es per Stripe Checkout im Browser – die App sieht nie
 * Karten- oder TWINT-Daten und kennt keinen Stripe-Schlüssel. Besitz entscheidet der Server.
 */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const icon = (n, s) => window.icon(n, s);
  const active = () => ctx().state()?.active === 'tool-store';
  const C = () => window.RevCos;
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  // 2.45.7: Shop geschlossen – Kaufen gesperrt (hier und im Hauptprozess)
  const SHOP_CLOSED = true;

  const st = { data: null, loading: false, tab: 'store', cat: 'new', pay: 'all', busy: '', donation: 500, custom: '', anonymous: false, showName: false, name: '', trying: null, supporters: null };

  // Kategorien: [id, Name, Icon, Slots]
  const CATS = [
    ['new', 'Neu', 'spark', null],
    ['profile', 'Profil', 'users', ['avatar', 'color', 'frame']],
    ['names', 'Name & Titel', 'text', ['name', 'title']],
    ['chess', 'Schach', 'chess', ['pieces', 'board', 'effect']],
    ['island', 'Dynamic Island', 'island', ['island']],
    ['widgets', 'Widgets', 'grid', ['widget']],
    ['kbd', 'Tastatur', 'keyboard', ['kbd', 'gif']],
  ];
  const SLOT_DESC = {
    avatar: 'Dein Bild in Schach, Geo, Chats und Ranglisten.',
    color: 'Hintergrund deines Profilbilds.',
    frame: 'Rahmen um dein Profilbild.',
    name: 'Farbe deines Namens in Schach, Geo und Chats.',
    title: 'Titel neben deinem Namen.',
    pieces: 'So sehen deine Figuren aus – online sehen sie auch deine Gegner.',
    board: 'Das Brett, auf dem du spielst.',
    effect: 'Spielt bei jedem deiner Züge auf dem Zielfeld.',
    island: 'Farben und Material der Dynamic Island. Wird beim Anlegen sofort übernommen.',
    kbd: 'Animation für das 128 × 128-Display deiner AJAZZ-Tastatur.',
    gif: 'GIF von Revulution für das 128 × 128-Display deiner AJAZZ-Tastatur.',
    widget: 'Zusätzliche Widgets für deinen Desktop.',
  };
  // Erklärung einzelner Artikel – damit klar ist, was man kauft
  const ITEM_DESC = {
    'effect/sparks': 'Goldene Funken sprühen aus dem Zielfeld.',
    'effect/ice': 'Eiskristalle splittern in alle Richtungen.',
    'effect/toxic': 'Giftgrüne Spritzer beim Aufsetzen.',
    'effect/void': 'Violette Leere-Partikel saugen sich ins Feld.',
    'effect/shockwave': 'Eine blaue Druckwelle läuft über das Brett.',
    'effect/sakura': 'Rosa Kirschblüten wirbeln auf.',
    'effect/gold': 'Goldstaub glitzert um die Figur.',
    'effect/meteor': 'Orange Einschlag mit Druckwelle – das Brett wackelt.',
    'effect/supernova': 'Helle Explosion mit großer Welle und Beben.',
    'effect/glitch': 'Rote Glitch-Welle, die Figur flackert chromatisch.',
    'effect/dotburst': 'Weiße Punkte explodieren im Nothing-Stil aus dem Feld – mit kleinem Beben.',
    'effect/ripple': 'Eine ruhige blaue Welle wie ein Tropfen im Wasser.',
    'effect/confetti': 'Bunter Konfetti-Regen bei jedem Zug.',
    'widget/trading': 'Live-Kurse für Aktien, ETFs und Krypto (z. B. AAPL, TSLA, BTC) mit Mini-Chart direkt auf deinem Desktop.',
    'widget/sound': 'Acht Sound-Knöpfe auf dem Desktop – mit Rechtsklick eigene Sounds, Emojis und Namen.',
    'widget/quick': 'Lieblingsdateien und Ordner auf den Desktop legen und mit einem Klick öffnen.',
    'widget/streamchat': 'Verbinde deinen TikTok- oder Twitch-Live und sieh den Chat sauber auf dem Desktop – oder als Overlay über Spielen.',
    'kbd/matrix': 'Grüner Code-Regen läuft über das Display.',
    'kbd/eqbars': 'Punkt-Equalizer mit roten Spitzen.',
    'kbd/dotclock': 'Die aktuelle Uhrzeit aus Punkten, ein roter Sekundenpunkt kreist.',
    'kbd/fire': 'Eine lodernde Flamme.',
    'kbd/plasma': 'Fließendes Regenbogen-Plasma.',
    'kbd/radar': 'Grüner Radar-Scan mit aufleuchtenden Punkten.',
    'kbd/heart': 'Ein pochendes Herz aus Punkten.',
    'kbd/starfield': 'Sterne fliegen auf dich zu.',
  };
  const PIECES = ['♔', '♕', '♖', '♗', '♘', '♙'];

  async function load(force = false) {
    if (st.loading || (st.data && !force)) return;
    st.loading = true;
    try {
      st.data = await window.hub.store.state();
    } catch (e) {
      st.data = { offline: true, error: errText(e), coins: 0, owned: [], transactions: [] };
    }
    st.loading = false;
    if (active()) ctx().render();
  }
  // Anmelden/Abmelden: Store neu laden, damit Coins und Käufe stimmen
  window.hub.onAccount?.(() => load(true));
  window.hub.onStore?.((s) => {
    st.data = s;
    if (active()) ctx().render();
  });

  const coins = (n) => `<span class="rs-coin"><i></i>${Number(n || 0).toLocaleString('de-DE')}</span>`;
  const pts = (n) => `<span class="rs-pts">◆ ${Number(n || 0).toLocaleString('de-DE')}</span>`;
  const chf = (rappen) => `CHF ${(rappen / 100).toFixed(2)}`;
  const profile = () => ctx().profile?.() || null;
  const itemName = (it) => it.t?.de || (it.glyph ? `Symbol ${it.glyph}` : it.id.charAt(0).toUpperCase() + it.id.slice(1));
  const isCoin = (it) => Boolean(it.coins);
  /** Besitzt der Nutzer den Artikel? Coins → Server, ◆ → Profil, Preis 0 → immer. */
  function has(slot, it) {
    if (!it) return false;
    if (isCoin(it)) return (st.data?.owned || []).includes(`${slot}/${it.id}`);
    return it.price === 0 || (profile()?.cos?.owned?.[slot] || []).includes(it.id);
  }
  const find = (slot, id) => C()?.COSMETICS[slot]?.find((x) => x.id === id);
  const equipped = (slot, it) => (profile()?.cos?.eq?.[slot] || C().COSMETICS[slot][0].id) === it.id;

  // Für andere Seiten (Tastatur, Desktop-Widgets): Besitz abfragen
  window.RevStore = {
    closed: () => SHOP_CLOSED,
    owns: (slot, id) => has(slot, find(slot, id)),
    // 2.45.5: Premium (Pro-Abo) – z. B. für Premium-Hintergründe auf dem Deck
    pro: () => Boolean(st.data?.pro?.active),
    load: () => load(true),
    open: (cat) => {
      st.tab = 'store';
      if (cat) st.cat = cat;
      ctx().state() && window.hub.open?.('tool-store');
    },
  };
  load();

  function priceBtn(slot, it) {
    if (isCoin(it)) return `<button class="rs-buy coin" data-rs-buy="${slot}/${it.id}">${coins(it.coins)}</button>`;
    const P = profile();
    const short = (P?.points || 0) < it.price;
    return `<button class="rs-buy pts ${short ? 'short' : ''}" data-rs-buy="${slot}/${it.id}" title="${short ? `Dir fehlen noch ◆ ${(it.price - (P?.points || 0)).toLocaleString('de-DE')}` : 'Mit Punkten freischalten'}">${pts(it.price)}</button>`;
  }
  function ownedBtn(slot, it) {
    if (slot === 'widget') {
      const on = ctx().state()?.settings?.desktopWidgets?.[it.id] === true;
      return `<button class="btn small ${on ? '' : 'primary'}" data-rs-widget="${it.id}">${on ? 'Vom Desktop nehmen' : 'Auf den Desktop'}</button>`;
    }
    if (slot === 'kbd') return `<button class="btn small primary" data-rs-kbd="${it.id}">Aufs Display</button>`;
    if (slot === 'gif') return '<button class="btn small primary" data-rs-gifgo>Zur Tastatur</button>';
    if (equipped(slot, it)) return '<span class="rs-tag">Angelegt</span>';
    return `<button class="btn small" data-rs-equip="${slot}/${it.id}">Anlegen</button>`;
  }

  function itemCard(slot, it, i = 0) {
    const P = profile();
    const eq = P?.cos?.eq || {};
    const own = has(slot, it);
    return `<div class="rs-item ${own ? 'owned' : ''} ${it.anim ? 'anim' : ''}" style="--d:${Math.min(i, 14) * 28}ms">
      <button class="rs-prev rs-prev-${slot}" data-rs-try="${slot}/${it.id}" title="Anprobieren">${C().preview(slot, it, eq, P?.name || 'Name')}<span class="rs-try-hint">${icon('eye', 13)} Anprobieren</span></button>
      <div class="rs-meta"><b>${esc(itemName(it))}</b><small>${esc(C().SLOT_NAMES[slot]?.de || slot)}${it.anim ? ' · animiert' : ''}</small>${slot === 'kbd' ? '<small class="rs-sup">⌨ Unterstützt AJAZZ-Tastatur</small>' : ''}</div>
      <div class="rs-act">${own ? ownedBtn(slot, it) : priceBtn(slot, it)}</div>
    </div>`;
  }

  /** Alle käuflichen Artikel (ohne Gratis-Standards, außer Dynamic Island zum Zurücksetzen). */
  function listFor(slots) {
    const out = [];
    for (const slot of slots)
      for (const it of C()?.COSMETICS[slot] || []) {
        if (it.price === 0 && slot !== 'island') continue;
        if (st.pay === 'coins' && !isCoin(it)) continue;
        if (st.pay === 'pts' && isCoin(it)) continue;
        out.push([slot, it]);
      }
    return out;
  }

  function storeTab() {
    const cat = CATS.find((c) => c[0] === st.cat) || CATS[0];
    const pay = `<div class="seg rs-pay">${[['all', 'Alle'], ['coins', 'Coins'], ['pts', '◆ Punkte']].map(([v, n]) => `<button class="${st.pay === v ? 'on' : ''}" data-rs-pay="${v}">${n}</button>`).join('')}</div>`;
    const nav = `<nav class="rs-cats">${CATS.map(([id, n, ic]) => `<button class="${st.cat === id ? 'on' : ''}" data-rs-cat="${id}">${icon(ic, 15)}<span>${esc(n)}</span></button>`).join('')}</nav>`;
    let body;
    if (!cat[3]) {
      // „Neu“: die neuesten Coin-Artikel aus allen Bereichen + Premium-Widgets oben
      const all = Object.keys(C()?.COSMETICS || {}).flatMap((slot) => (C().COSMETICS[slot] || []).filter((it) => isCoin(it)).map((it) => [slot, it]));
      const feat = all.filter(([s]) => s === 'widget');
      const rest = all.filter(([s]) => s !== 'widget').reverse().slice(0, 18);
      body = `<div class="rs-feature">${feat.map(([s, it]) => featureCard(s, it)).join('')}</div>
        <h4 class="rs-sec">Neu im Store</h4><div class="rs-grid">${rest.map(([s, it], i) => itemCard(s, it, i)).join('')}</div>`;
    } else {
      body = cat[3]
        .map((slot) => {
          const items = listFor([slot]);
          if (!items.length) return '';
          return `<section class="rs-slot"><div class="rs-slot-h"><b>${esc(C().SLOT_NAMES[slot]?.de || slot)}</b><small>${esc(SLOT_DESC[slot] || '')}</small></div><div class="rs-grid">${items.map(([s, it], i) => itemCard(s, it, i)).join('')}</div></section>`;
        })
        .join('') || '<p class="muted">Hier gibt es mit diesem Filter gerade nichts.</p>';
    }
    return `<div class="rs-bar">${nav}${cat[3] ? pay : ''}</div>${body}`;
  }

  function featureCard(slot, it) {
    const own = has(slot, it);
    return `<div class="rs-feat rs-feat-${it.id}">
      <div class="rs-feat-txt"><span class="rs-eyebrow">PREMIUM-WIDGET</span><b>${esc(itemName(it))}</b><p>${esc(ITEM_DESC[`${slot}/${it.id}`] || '')}</p>
        <div class="rs-feat-act"><button class="btn small ghost" data-rs-try="${slot}/${it.id}">Ansehen</button>${own ? ownedBtn(slot, it) : priceBtn(slot, it)}</div></div>
      <div class="rs-feat-prev">${C().preview(slot, it)}</div>
    </div>`;
  }

  /* ------------------------------------------------------------ Anprobieren: große Live-Vorschau */
  function tryStage(slot, it) {
    const P = profile();
    const eq = { ...(P?.cos?.eq || {}), [slot]: it.id };
    const name = P?.name || 'Dein Name';
    if (['avatar', 'color', 'frame', 'name', 'title'].includes(slot))
      return `<div class="rt-profile">${C().avatarHtml(eq, 120)}<div><b ${C().nameStyle(eq)}>${esc(name)}</b>${C().titleHtml(eq)}<small>So sehen dich andere in Schach, Geo und Chats.</small></div></div>
        <div class="rt-row">${C().avatarHtml(eq, 40)}<span><b ${C().nameStyle(eq)}>${esc(name)}</b>${C().titleHtml(eq)}</span><em>1 820</em></div>`;
    if (slot === 'pieces' || slot === 'board') {
      const skin = slot === 'pieces' ? it.id : eq.pieces || 'classic';
      const bd = slot === 'board' ? it.id : eq.board || 'standard';
      let cells = '';
      for (let r = 0; r < 4; r++)
        for (let c = 0; c < 6; c++) {
          const g = r === 0 ? `<span class="piece b skin-${skin}"><span>${['♜', '♞', '♝', '♛', '♚', '♟'][c]}&#xFE0E;</span></span>` : r === 3 ? `<span class="piece w skin-${skin}"><span>${PIECES[c]}&#xFE0E;</span></span>` : '';
          cells += `<i class="sq ${(r + c) % 2 ? 'dark' : ''}">${g}</i>`;
        }
      return `<div class="rt-board bd-${bd}">${cells}</div>`;
    }
    if (slot === 'effect') return `<div class="rt-fx">${C().preview(slot, it)}</div>`;
    if (slot === 'island') return `<div class="rt-desk"><div class="rt-island">${C().preview(slot, it)}</div><span>So sitzt die Island oben auf deinem Bildschirm</span></div>`;
    if (slot === 'kbd') return `<div class="rt-kbd"><div class="rt-kbd-body"><canvas data-kbd="${esc(it.id)}" width="256" height="256"></canvas></div><div class="rt-keys">${'<i></i>'.repeat(28)}</div></div>`;
    if (slot === 'widget') return `<div class="rt-widget">${C().preview(slot, it)}</div>`;
    return C().preview(slot, it, eq, name);
  }
  function tryModal() {
    if (!st.trying) return '';
    const [slot, id] = st.trying.split('/');
    const it = find(slot, id);
    if (!it) return '';
    const own = has(slot, it);
    return `<div class="rs-modal" data-rs-close>
      <div class="rs-sheet" role="dialog">
        <button class="rs-x" data-rs-close title="Schließen">${icon('close', 16)}</button>
        <div class="rs-stage rs-stage-${slot}">${tryStage(slot, it)}</div>
        <div class="rs-sheet-txt"><span class="rs-eyebrow">${esc((C().SLOT_NAMES[slot]?.de || slot).toUpperCase())}</span><h3>${esc(itemName(it))}</h3><p>${esc(ITEM_DESC[`${slot}/${it.id}`] || SLOT_DESC[slot] || '')}</p>
          <div class="rs-sheet-act">${own ? ownedBtn(slot, it) : priceBtn(slot, it)}</div></div>
      </div>
    </div>`;
  }

  /* 2.37: die Revolution Coin – rote Münze mit eingeprägtem R, dreht sich in 3D */
  const coin3d = (size = 140) => `<div class="rcoin" style="--s:${size}px"><div class="rcoin-spin">${Array.from({ length: 10 }, (_, i) => `<i class="rcoin-edge" style="--z:${i - 4.5}"></i>`).join('')}<div class="rcoin-face front"><i class="rcoin-rim"></i><span>R</span></div><div class="rcoin-face back"><i class="rcoin-rim"></i><span>R</span></div></div><div class="rcoin-shadow"></div></div>`;
  /* 2.39: kleine 3D-Münzen mit R als Berg – je größer das Paket, desto größer der Haufen */
  const pile = (rows) => `<span class="rs-pile">${rows.map((n, r) => `<span class="rs-pile-row" style="--r:${r}">${'<i class="mc"><b>R</b></i>'.repeat(n)}</span>`).join('')}</span>`;
  const PILES = [[1], [2, 1], [3, 2, 1], [4, 3, 2, 1]];
  /* Freunde einladen: persönlicher Code, +20 Coins pro neuem Freund */
  function referralHtml() {
    if (!st.data?.signedIn) return '<div class="rs-free"><div><b>Freunde einladen</b><small>Melde dich an, dann bekommst du deinen persönlichen Einladungscode – 20 Coins pro neuem Freund.</small></div></div>';
    if (!st.ref && !st.refLoading) {
      st.refLoading = true;
      window.hub.store.referral().then((r) => { st.ref = r; }).catch((e) => { st.ref = { error: errText(e) }; }).finally(() => { st.refLoading = false; if (active()) ctx().render(); });
    }
    const r = st.ref || {};
    return `<div class="rs-free rs-ref"><div><b>Freunde einladen · +20 Coins</b><small>${r.error ? esc(r.error) : `Dein Code: <code class="rs-code">${esc(r.code || '…')}</code> · ${r.invited || 0} eingeladen. Dein Freund bekommt 10 Coins Startbonus.`}</small></div>
      ${r.code ? `<button class="btn small" data-rs-copyref="${esc(r.code)}">Kopieren</button>` : ''}
      ${r.redeemed ? '' : '<div class="rs-redeem"><input class="input" data-rs-refcode maxlength="10" placeholder="Code eines Freundes" /><button class="btn small primary" data-rs-redeem>Einlösen</button></div>'}</div>`;
  }
  /* 2.38 Revulution Pro – Abo-Karte (auch im Konto). Preise: CHF 2.90/Monat oder CHF 24/Jahr. */
  function proCard() {
    const d = st.data;
    if (!d && !st.loading) {
      st.loading = true;
      window.hub.store.state().then((x) => { st.data = x; }).catch(() => {}).finally(() => { st.loading = false; if (document.querySelector('[data-tool-page="tool-store"],[data-tool-page="tool-account"]')) ctx().render(); });
    }
    const pro = d?.pro || { active: false };
    const perks = ['Alle Premium-Wallpaper (125 Videos in 4K) als Desktop-Hintergrund', 'Neue Premium-Wallpaper jeden Monat', 'Pro-Abzeichen im Profil und in Chats', 'Unterstützt die Entwicklung – jederzeit kündbar'];
    if (pro.active) {
      return `<div class="rs-pro on"><div class="rs-pro-l"><span class="rs-pro-badge">PRO</span><div><b>Du hast Revulution Pro</b><small>${pro.plan === 'year' ? 'Jahresabo' : 'Monatsabo'}${pro.until ? ` · ${pro.cancelAtEnd ? 'endet' : 'verlängert sich'} am ${new Date(pro.until).toLocaleDateString('de-DE')}` : ''}</small></div></div><button class="btn small" data-pro-portal>Abo verwalten</button></div>`;
    }
    const max = ['Alles aus Pro', 'Eigene Cloud für Clips, Screenshots und Projekte', '+150 Revolution Coins jeden Monat', 'Max-Abzeichen und frühe Beta-Funktionen'];
    return `<div class="rs-subs">
      <div class="rs-pro"><div class="rs-pro-l"><span class="rs-pro-badge">PRO</span><div><b>Revulution Pro</b><small>Premium-Wallpaper und mehr</small></div></div>
        <ul>${perks.map((p) => `<li>${esc(p)}</li>`).join('')}</ul>
        <div class="rs-pro-plans">
          <button class="rs-plan" data-pro-buy="month" ${d?.signedIn ? '' : 'disabled'}><b>CHF 2.90</b><small>pro Monat</small></button>
          <button class="rs-plan best" data-pro-buy="year" ${d?.signedIn ? '' : 'disabled'}><em>2 Monate gratis</em><b>CHF 24.–</b><small>pro Jahr · CHF 2.– / Monat</small></button>
        </div>
        <small class="rs-fine">${d?.signedIn ? 'Bezahlt wird sicher über Stripe im Browser. Kündbar jederzeit unter „Abo verwalten“.' : 'Melde dich im Konto an, um Pro zu holen.'} Unter 18? Frag zuerst deine Eltern.</small></div>
      <div class="rs-pro max"><div class="rs-pro-l"><span class="rs-pro-badge max">MAX</span><div><b>Revulution Max</b><small>Bald verfügbar</small></div></div>
        <ul>${max.map((p) => `<li>${esc(p)}</li>`).join('')}</ul>
        <div class="rs-pro-plans one"><button class="rs-plan" disabled><em class="soon">Coming soon</em><b>CHF –</b><small>Preis folgt</small></button></div>
        <small class="rs-fine">Max kommt in einem späteren Update.</small></div>
    </div>`;
  }
  window.revProCard = proCard;
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-pro-buy],[data-pro-portal]');
    if (!b) return;
    const p = b.dataset.proBuy ? window.hub.store.pro(b.dataset.proBuy) : window.hub.store.proPortal();
    p.then(() => ctx().toast?.(b.dataset.proBuy ? 'Kasse im Browser geöffnet.' : 'Kundenportal im Browser geöffnet.')).catch((err) => ctx().toast?.(errText(err)));
  });
  /* 2.41 Glücksrad statt täglicher Gratis-Coins: alle 20 h einmal drehen.
     Gezogen wird auf dem Server; die guten Preise gibt es je nur einmal. */
  const WHEEL = [['none', 'Nichts', '#2a2a32'], ['coins50', '50 Coins', '#e5342b'], ['none', 'Nichts', '#1f1f26'], ['pro25', 'Pro −25 %', '#d4a017'], ['none', 'Nichts', '#2a2a32'], ['widget', 'Widget', '#7c3aed'], ['none', 'Nichts', '#1f1f26'], ['none', 'Nichts', '#2a2a32']];
  st.wheelRot = st.wheelRot || 0;
  function wheelHtml() {
    const d = st.data || {};
    const cd = d.catalog?.wheel?.cooldownMs || 72000000;
    const next = (d.wheelAt || 0) + cd;
    const can = d.signedIn && Date.now() >= next && !st.spinning;
    const won = d.wheelWon || {};
    const slice = 360 / WHEEL.length;
    return `<div class="rs-wheel-card">
      <div class="rs-wheel-wrap"><div class="rs-wheel" id="rs-wheel" style="transform:rotate(${st.wheelRot}deg);background:conic-gradient(${WHEEL.map(([, , c], i) => `${c} ${i * slice}deg ${(i + 1) * slice}deg`).join(',')})">${WHEEL.map(([id, n], i) => `<span style="--a:${i * slice + slice / 2}deg" class="${id !== 'none' && won[id] ? 'gone' : ''}">${esc(n)}</span>`).join('')}<i></i></div></div>
      <div class="rs-wheel-txt"><b>Glücksrad</b><small>Einmal am Tag drehen. Zu gewinnen: 50 Coins, ein Premium-Widget oder 25 % Rabatt auf Pro – jeder Preis nur einmal, die Chance ist klein.${d.proDiscount ? ` <br><b>Dein Pro-Rabatt: −${d.proDiscount} %</b> – gilt beim nächsten Pro-Kauf.` : ''}</small>
        <button class="btn ${can ? 'primary' : ''}" data-rs-spin ${can ? '' : 'disabled'}>${!d.signedIn ? 'Zum Drehen anmelden' : st.spinning ? 'Dreht …' : can ? 'Drehen' : `wieder ab ${new Date(next).toLocaleString('de-DE', { weekday: 'short', hour: '2-digit', minute: '2-digit' })}`}</button>
        ${st.wheelMsg ? `<div class="rs-wheel-msg ${st.wheelWin ? 'win' : ''}">${esc(st.wheelMsg)}</div>` : ''}</div></div>`;
  }
  async function spin() {
    if (st.spinning) return;
    st.spinning = true;
    st.wheelMsg = '';
    ctx().render();
    try {
      const r = await window.hub.store.spin();
      const idxs = WHEEL.map((w, i) => (w[0] === r.prize ? i : -1)).filter((i) => i >= 0);
      const idx = idxs[Math.floor(Math.random() * idxs.length)] ?? 0;
      const slice = 360 / WHEEL.length;
      // Zeiger oben: das Feld idx muss nach oben
      const target = 360 - (idx * slice + slice / 2) + (Math.random() - 0.5) * slice * 0.6;
      st.wheelRot = st.wheelRot - (st.wheelRot % 360) + 360 * 6 + target;
      const el = document.getElementById('rs-wheel');
      if (el) {
        el.style.transition = 'transform 4.6s cubic-bezier(.12,.8,.18,1)';
        el.style.transform = `rotate(${st.wheelRot}deg)`;
      }
      await new Promise((res) => setTimeout(res, 4800));
      st.wheelWin = r.prize !== 'none';
      st.wheelMsg = r.prize === 'coins50' ? 'Gewonnen: 50 Coins! 🎉' : r.prize === 'widget' ? `Gewonnen: Premium-Widget „${(r.item || '').split('/')[1] || ''}“! 🎉` : r.prize === 'pro25' ? 'Gewonnen: 25 % Rabatt auf Pro! 🎉' : 'Leider nichts – morgen wieder.';
      st.data = await window.hub.store.state().catch(() => st.data);
    } catch (e) {
      st.wheelMsg = errText(e);
      st.wheelWin = false;
    }
    st.spinning = false;
    if (active()) ctx().render();
  }
  function coinsTab() {
    // 2.41: 100 Coins = CHF 0.77, größere Pakete mit Rabatt (Preise kommen vom Server)
    const packs = st.data?.catalog?.packs || [
      { id: 'coins_100', coins: 100, amount: 77 },
      { id: 'coins_500', coins: 500, amount: 367 },
      { id: 'coins_1200', coins: 1200, amount: 847 },
      { id: 'coins_2500', coins: 2500, amount: 1637 },
    ];
    const base = st.data?.catalog?.coinBase || 0.77;
    const save = (p) => Math.round((1 - p.amount / (p.coins * base)) * 100);
    return `<div class="rs-coin-hero">${coin3d(150)}<div><span class="rs-eyebrow">REVOLUTION COIN</span><h3>Die Währung für Designs</h3><p>Mit Coins schaltest du Designs, Island-Looks, Tastatur-Displays und Premium-Widgets frei. 100 Coins = CHF 0.77. Coins haben keinen Geldwert und lassen sich nicht auszahlen oder in Punkte tauschen.</p></div></div>
      <div class="rs-packs">${packs
      .map((p, i) => `<button class="rs-pack" style="--d:${i * 60}ms" data-rs-pack="${esc(p.id)}">${pile(PILES[Math.min(3, i)])}<b>${coins(p.coins)}</b>${save(p) >= 2 ? `<em>−${save(p)} % günstiger</em>` : '<em>&nbsp;</em>'}<span class="rs-price">${chf(p.amount)}</span></button>`)
      .join('')}</div>
      ${wheelHtml()}
      ${proCard()}
      ${referralHtml()}
      <p class="rs-fine">Bezahlt wird sicher im Browser über Stripe (Karte, TWINT, Apple Pay). Coins haben keinen Geldwert, sind nicht übertragbar und nicht auszahlbar.</p>`;
  }

  function supportTab() {
    if (!st.supporters) {
      st.supporters = [];
      window.hub.store.supporters().then((s) => { st.supporters = s || []; if (active() && st.tab === 'support') ctx().render(); }).catch(() => {});
    }
    const amt = st.custom ? Math.round(Number(String(st.custom).replace(',', '.')) * 100) || 0 : st.donation;
    return `<div class="rs-support">
      <div class="rs-heart"><svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-9.2-9C1.4 8 3.3 4.5 6.6 4.5c2 0 3.4 1.2 5.4 3.2 2-2 3.4-3.2 5.4-3.2 3.3 0 5.2 3.5 3.8 6.5C19 15.6 12 20 12 20Z"/></svg></div>
      <h3>Revulution Hub unterstützen</h3>
      <p>Freiwillig und einmalig. Deine Unterstützung hilft, dass der Hub weiter wachsen kann.</p>
      <div class="rs-amounts">${[200, 500, 1000, 2000].map((a) => `<button class="${!st.custom && st.donation === a ? 'on' : ''}" data-rs-amt="${a}">${chf(a).replace('.00', '')}</button>`).join('')}<label class="rs-custom ${st.custom ? 'on' : ''}">CHF <input data-rs-custom inputmode="decimal" placeholder="Betrag" value="${esc(st.custom)}" /></label></div>
      <div class="rs-opts">
        <label><button class="switch ${st.anonymous ? 'on' : ''}" data-rs-opt="anonymous"></button> Anonym unterstützen</label>
        ${st.anonymous ? '' : `<label><button class="switch ${st.showName ? 'on' : ''}" data-rs-opt="showName"></button> In der Unterstützer-Liste zeigen</label>${st.showName ? `<input class="input" data-rs-name placeholder="Name für die Liste" value="${esc(st.name)}" maxlength="40" />` : ''}`}
      </div>
      <button class="btn primary rs-donate" data-rs-donate ${amt >= 100 ? '' : 'disabled'}>${amt >= 100 ? `${chf(amt)} unterstützen` : 'Mindestens CHF 1'}</button>
      ${st.supporters?.length ? `<div class="rs-sup"><span>DANKE AN</span>${st.supporters.slice(0, 30).map((s) => `<i>${esc(s.name)}</i>`).join('')}</div>` : ''}
    </div>`;
  }

  function inventoryTab() {
    const d = st.data || {};
    const P = profile();
    const tx = d.transactions || [];
    const label = (t) => (t.kind === 'coins' ? `${t.coins} Coins gekauft` : t.kind === 'item' ? `Gekauft: ${t.item}` : t.kind === 'daily' ? 'Tagesbonus' : t.kind === 'donation' ? 'Unterstützung – danke!' : t.kind);
    const stat = { paid: 'bezahlt', open: 'offen', failed: 'fehlgeschlagen', refunded: 'erstattet', disputed: 'in Klärung', done: '' };
    const mine = [];
    for (const [slot, list] of Object.entries(C()?.COSMETICS || {})) for (const it of list) if (it.price !== 0 && has(slot, it)) mine.push([slot, it]);
    return `<div class="rs-inv">
      <div class="rs-inv-head"><div><span>COINS</span>${coins(d.coins)}</div><div><span>PUNKTE</span>${pts(P?.points)}</div><div><span>DESIGNS</span><b>${mine.length}</b></div></div>
      ${mine.length ? `<div class="rs-grid">${mine.map(([s, it], i) => itemCard(s, it, i)).join('')}</div>` : '<p class="muted">Noch nichts freigeschaltet.</p>'}
      <h4 class="rs-sec">Verlauf</h4>
      ${tx.length ? `<div class="rs-tx">${tx.map((t) => `<div><span>${esc(label(t))}${stat[t.status] ? ` · ${stat[t.status]}` : ''}</span><small>${new Date(t.at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}</small><b class="${(t.coins || 0) < 0 ? 'neg' : ''}">${t.kind === 'donation' ? chf(t.amount) : `${t.coins > 0 ? '+' : ''}${t.coins || 0}`}</b></div>`).join('')}</div>` : '<p class="muted">Noch keine Transaktionen.</p>'}
    </div>`;
  }

  function html() {
    // nicht angemeldet erkannt? höchstens alle 8 s neu nachfragen (Anmeldung kann noch laufen)
    if (st.data && !st.data.signedIn && !st.loading && Date.now() - (st.checkedAt || 0) > 8000) {
      st.checkedAt = Date.now();
      setTimeout(() => load(true), 0);
    }
    load();
    const d = st.data;
    const P = profile();
    const signedIn = d?.signedIn;
    const setup = d?.offline;
    // 2.45.7 Shop geschlossen: nur noch das Inventar (Gekauftes anlegen/nutzen), kein Kaufen
    if (SHOP_CLOSED) {
      st.tab = 'inv';
      return `<div class="rs">
        <header class="rs-head"><div class="rs-me">${P && C() ? C().avatarHtml(P.cos.eq, 52) : ''}<div><span class="rs-eyebrow">● REVOLUTION STORE</span><h2>Inventar</h2></div></div></header>
        <div class="rs-note">${icon('alert', 15)}<span>Der Shop ist geschlossen – zurzeit kann nichts gekauft werden. Was du schon besitzt, kannst du hier weiter anlegen und nutzen.</span></div>
        <div class="rs-body">${inventoryTab()}</div>
        ${tryModal()}
      </div>`;
    }
    const tabs = [['store', 'Store'], ['coins', 'Coins'], ['support', 'Unterstützen'], ['inv', 'Inventar']];
    return `<div class="rs">
      <header class="rs-head">
        <div class="rs-me">${P && C() ? C().avatarHtml(P.cos.eq, 52) : ''}<div><span class="rs-eyebrow">● REVOLUTION STORE</span><h2>${P ? `<b ${C().nameStyle(P.cos.eq)}>${esc(P.name || 'Dein Profil')}</b>${C().titleHtml(P.cos.eq)}` : 'Revolution Store'}</h2></div></div>
        <div class="rs-wallet"><div class="rs-w"><small>Punkte</small>${pts(P?.points)}</div><div class="rs-w"><small>Coins</small>${signedIn ? coins(d?.coins) : '<button class="btn small" data-open="tool-account">Anmelden</button>'}</div></div>
      </header>
      ${setup ? `<div class="rs-note">${icon('alert', 15)}<span>${d.error === 'setup' ? 'Coin-Käufe werden gerade eingerichtet. Mit ◆ Punkten kannst du schon jetzt freischalten – Anprobieren geht immer.' : esc(d.error || 'Store gerade nicht erreichbar.')}</span></div>` : ''}
      <nav class="seg rs-tabs">${tabs.map(([id, n]) => `<button class="${st.tab === id ? 'on' : ''}" data-rs-tab="${id}">${n}</button>`).join('')}</nav>
      <div class="rs-body">${st.tab === 'coins' ? coinsTab() : st.tab === 'support' ? supportTab() : st.tab === 'inv' ? inventoryTab() : storeTab()}</div>
      ${tryModal()}
    </div>`;
  }

  async function act(fn, ok) {
    if (st.busy) return;
    st.busy = '1';
    try {
      await fn();
      if (ok) ctx().toast(ok);
    } catch (e) {
      ctx().toast(errText(e), 'error');
    }
    st.busy = '';
    if (active()) ctx().render();
  }

  /** Nach Kauf/Anlegen: Island-Design übernehmen, Widget einschalten. */
  async function applyItem(slot, it) {
    if (slot === 'island' && it.app) await window.hub.orbit?.save?.({ Appearance: { ...it.app, ThemeId: `store-${it.id}`, ThemeName: itemName(it) } });
    if (slot === 'widget' && it.feature) await window.hub.setSettings({ desktopWidgets: { [it.id]: true } });
  }

  async function buy(slot, it) {
    if (SHOP_CLOSED) throw new Error('Der Shop ist geschlossen – zurzeit kann nichts gekauft werden.');
    if (isCoin(it)) {
      await window.hub.store.buy(`${slot}/${it.id}`);
      await load(true);
    } else {
      const P = profile();
      if ((P?.points || 0) < it.price) throw new Error(`Dafür fehlen dir noch ◆ ${(it.price - (P?.points || 0)).toLocaleString('de-DE')}. Punkte gibt es in Schach und Geo.`);
      await window.hub.profile.buy(slot, it.id);
    }
    if (!['widget', 'kbd'].includes(slot)) await window.hub.profile.equip(slot, it.id);
    await applyItem(slot, it);
    window.sound?.play?.('success');
  }

  document.addEventListener('click', (e) => {
    if (!active()) return;
    const q = (s) => e.target.closest?.(s);
    if (q('[data-rs-close]') && (e.target.matches('[data-rs-close]') || q('.rs-x'))) {
      st.trying = null;
      return ctx().render();
    }
    const tab = q('[data-rs-tab]')?.dataset.rsTab;
    if (tab) { st.tab = tab; return ctx().render(); }
    const cat = q('[data-rs-cat]')?.dataset.rsCat;
    if (cat) { st.cat = cat; return ctx().render(); }
    const pay = q('[data-rs-pay]')?.dataset.rsPay;
    if (pay) { st.pay = pay; return ctx().render(); }
    const pack = q('[data-rs-pack]')?.dataset.rsPack;
    if (pack) return act(() => window.hub.store.checkout(pack), 'Stripe Checkout geöffnet – nach dem Bezahlen erscheinen die Coins hier.');
    if (q('[data-rs-spin]')) return spin();
    if (q('[data-rs-gifgo]')) return window.hub.open('tool-keyboard');
    const cref = q('[data-rs-copyref]')?.dataset.rsCopyref;
    if (cref) {
      navigator.clipboard?.writeText(cref).catch(() => {});
      return ctx().toast('Code kopiert – schick ihn deinen Freunden.');
    }
    if (q('[data-rs-redeem]')) return act(async () => { await window.hub.store.redeem(document.querySelector('[data-rs-refcode]')?.value || ''); st.ref = null; }, 'Eingelöst – 10 Coins gutgeschrieben!');
    const b = q('[data-rs-buy]')?.dataset.rsBuy;
    if (b) {
      const [slot, id] = b.split('/');
      const it = find(slot, id);
      if (!it) return;
      return act(() => buy(slot, it), slot === 'kbd' ? 'Freigeschaltet – jetzt „Aufs Display“ tippen.' : slot === 'widget' ? 'Freigeschaltet – das Widget ist jetzt auf deinem Desktop.' : 'Freigeschaltet und angelegt!');
    }
    const eqp = q('[data-rs-equip]')?.dataset.rsEquip;
    if (eqp) {
      const [slot, id] = eqp.split('/');
      const it = find(slot, id);
      return act(async () => {
        await window.hub.profile.equip(slot, id);
        await applyItem(slot, it);
      }, slot === 'island' ? 'Auf die Dynamic Island übertragen.' : 'Angelegt.');
    }
    const w = q('[data-rs-widget]')?.dataset.rsWidget;
    if (w) {
      const on = ctx().state()?.settings?.desktopWidgets?.[w] === true;
      return act(async () => {
        await window.hub.setSettings({ desktopWidgets: { enabled: true, [w]: !on } });
        if (!on) await window.hub.desktopWidgets?.set?.(true);
      }, on ? 'Widget vom Desktop genommen.' : 'Widget ist jetzt auf deinem Desktop.');
    }
    const k = q('[data-rs-kbd]')?.dataset.rsKbd;
    if (k) {
      st.trying = null;
      window.RevStore.pendingKbd = k;
      return window.hub.open?.('tool-keyboard');
    }
    const tr = q('[data-rs-try]')?.dataset.rsTry;
    if (tr) {
      st.trying = tr;
      return ctx().render();
    }
    const amt = q('[data-rs-amt]')?.dataset.rsAmt;
    if (amt) { st.donation = Number(amt); st.custom = ''; return ctx().render(); }
    const opt = q('[data-rs-opt]')?.dataset.rsOpt;
    if (opt) { st[opt] = !st[opt]; return ctx().render(); }
    if (q('[data-rs-donate]')) {
      const amount = st.custom ? Math.round(Number(String(st.custom).replace(',', '.')) * 100) : st.donation;
      return act(() => window.hub.store.donate({ amount, anonymous: st.anonymous, showName: st.showName, name: st.name }), 'Danke! Die Zahlung öffnet sich im Browser.');
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && st.trying && active()) {
      st.trying = null;
      ctx().render();
    }
  });
  document.addEventListener('input', (e) => {
    if (!active()) return;
    if (e.target.matches?.('[data-rs-custom]')) {
      st.custom = e.target.value.replace(/[^\d.,]/g, '');
      const btn = document.querySelector('[data-rs-donate]');
      const a = Math.round(Number(st.custom.replace(',', '.')) * 100) || 0;
      if (btn) { btn.disabled = a < 100; btn.textContent = a >= 100 ? `${chf(a)} unterstützen` : 'Mindestens CHF 1'; }
    }
    if (e.target.matches?.('[data-rs-name]')) st.name = e.target.value;
  });

  T.register(
    'tool-store',
    { nav: 'Store', title: 'Revolution Store', sub: 'Designs, Widgets & Coins', icon: 'spark', tint: 'linear-gradient(135deg,#ff3b30,#7f1d1d)', desc: 'Designs für Profil, Schach, Dynamic Island und Tastatur, Premium-Widgets – mit ◆ Punkten oder Revolution Coins.' },
    html,
  );
})();
