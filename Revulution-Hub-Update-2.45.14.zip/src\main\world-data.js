'use strict';
/**
 * Live-Daten für die Weltansicht und das Globus-Widget (2.45): Satelliten, Flüge, Kameras.
 * Nur feste, schlüssellose Quellen; alles wird zwischengespeichert, damit die Dienste
 * nicht öfter als nötig gefragt werden.
 *   Satelliten  CelesTrak (aktive Objekte, TLE), Bahnen 6 h im Speicher
 *   Flüge       OpenSky (weltweit, anonym ~100 Abrufe/Tag) – Ersatz: adsb.lol in 8 Regionen
 *   Kameras     TfL JamCams (London), Fintraffic Wetterkameras (Finnland), DriveBC (Kanada)
 */
const electron = require('electron');
const sat = require('./vendor/satellite.js');

const UA = 'RevolutionHub/2.45 (+https://github.com/Gillohartman/revolution-hub-updates)';
const cache = { satellites: { at: 0, data: [] }, flights: { at: 0, data: [] }, cameras: { at: 0, data: [] } };
const TTL = { satellites: 6 * 60 * 60 * 1000, flights: 90 * 1000, cameras: 60 * 60 * 1000 };
const pending = {};

async function getJson(url, headers = {}, ms = 20000) {
  const response = await electron.net.fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json', ...headers }, signal: AbortSignal.timeout(ms) });
  if (!response.ok) throw new Error(`${new URL(url).hostname} ${response.status}`);
  return response.json();
}

// CelesTrak sperrt Clients, die dieselben Daten öfter als alle ~2 h laden (HTTP 403).
// Darum liegen die Bahndaten zusätzlich auf der Festplatte und werden höchstens alle 6 h erneuert.
const fs = require('fs');
const path = require('path');
const tleFile = () => path.join(electron.app.getPath('userData'), 'world-cache', 'celestrak-active.tle');
async function satelliteText() {
  let stat = null;
  try { stat = fs.statSync(tleFile()); } catch { /* noch nicht vorhanden */ }
  if (stat && Date.now() - stat.mtimeMs < TTL.satellites) return fs.readFileSync(tleFile(), 'utf8');
  try {
    const response = await electron.net.fetch('https://celestrak.org/NORAD/elements/gp.php?GROUP=active&FORMAT=tle', { headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(30000) });
    if (!response.ok) throw new Error(`CelesTrak ${response.status}`);
    const text = await response.text();
    if (!/^1 /m.test(text)) throw new Error('CelesTrak: unerwartete Antwort');
    fs.mkdirSync(path.dirname(tleFile()), { recursive: true });
    fs.writeFileSync(tleFile(), text);
    return text;
  } catch (error) {
    if (stat) {
      // Lieber ältere Bahnen (bis ~1 Woche noch gut genug) als gar keine; nächster Versuch frühestens in 2 h
      fs.utimesSync(tleFile(), new Date(), new Date(Date.now() - TTL.satellites + 2 * 60 * 60 * 1000));
      return fs.readFileSync(tleFile(), 'utf8');
    }
    throw error;
  }
}

async function loadSatellites() {
  const lines = (await satelliteText()).split(/\r?\n/);
  const records = [];
  for (let i = 0; i + 2 < lines.length && records.length < 12000; i++) {
    if (!lines[i + 1].startsWith('1 ') || !lines[i + 2].startsWith('2 ')) continue;
    try {
      const rec = sat.twoline2satrec(lines[i + 1], lines[i + 2]);
      rec.hubName = lines[i].trim().slice(0, 40);
      records.push(rec);
    } catch { /* ungültige Bahndaten */ }
    i += 2;
  }
  if (!records.length) throw new Error('Keine Satellitenbahnen verfügbar.');
  return records;
}

async function loadFlights() {
  try {
    const j = await getJson('https://opensky-network.org/api/states/all', {}, 25000);
    const out = [];
    for (const s of j.states || []) {
      // [icao24, callsign, country, timePos, lastContact, lon, lat, baroAlt, onGround, velocity, track, vRate, sensors, geoAlt, squawk, spi, source]
      if (s[8] || !Number.isFinite(s[5]) || !Number.isFinite(s[6])) continue;
      out.push({ id: s[0], cs: String(s[1] || '').trim(), c: s[2] || '', lat: s[6], lon: s[5], alt: Math.round(s[7] ?? s[13] ?? 0), v: Math.round((s[9] || 0) * 3.6), hd: Math.round(s[10] || 0) });
    }
    if (out.length > 200) return out;
  } catch (error) {
    console.warn('[world] OpenSky:', error.message);
  }
  const areas = [[50, 10], [40, -100], [40, -75], [35, 135], [-25, 135], [25, 55], [-23, -46], [22, 110]];
  const results = await Promise.allSettled(areas.map(([lat, lon]) => getJson(`https://api.adsb.lol/v2/lat/${lat}/lon/${lon}/dist/250`, {}, 12000)));
  const unique = new Map();
  for (const r of results) {
    if (r.status !== 'fulfilled') continue;
    for (const p of r.value.ac || []) {
      if (!p.hex || !Number.isFinite(p.lat) || !Number.isFinite(p.lon) || p.alt_baro === 'ground' || !(p.seen_pos < 120)) continue;
      unique.set(p.hex, { id: p.hex, cs: String(p.flight || '').trim(), c: p.t || '', lat: p.lat, lon: p.lon, alt: Math.round((Number(p.alt_baro) || 0) * 0.3048), v: Math.round((p.gs || 0) * 1.852), hd: Math.round(p.track || 0) });
    }
  }
  if (!unique.size) throw new Error('Flugdaten vorübergehend nicht verfügbar.');
  return [...unique.values()];
}

async function loadCameras() {
  const sources = [
    // London: Standbild + kurzer Live-Clip
    getJson('https://api.tfl.gov.uk/Place/Type/JamCam').then((list) => list.map((c) => {
      const prop = (k) => (c.additionalProperties || []).find((p) => p.key === k)?.value || '';
      return { id: 'tfl-' + c.id, name: c.commonName, lat: c.lat, lon: c.lon, img: prop('imageUrl'), video: prop('videoUrl'), src: 'TfL London' };
    })),
    // Finnland: Wetterkameras an Strassen (jede Station hat mehrere Blickrichtungen)
    getJson('https://tie.digitraffic.fi/api/weathercam/v1/stations', { 'Digitraffic-User': 'RevolutionHub', 'Accept-Encoding': 'gzip' }).then((geo) => (geo.features || []).flatMap((f) => {
      const preset = (f.properties?.presets || []).find((p) => p.inCollection);
      if (!preset || f.properties?.collectionStatus !== 'GATHERING') return [];
      const [lon, lat] = f.geometry?.coordinates || [];
      return [{ id: 'fi-' + preset.id, name: String(f.properties.name || preset.id).replace(/_/g, ' '), lat, lon, img: `https://weathercam.digitraffic.fi/${preset.id}.jpg`, src: 'Fintraffic Finnland' }];
    })),
    // British Columbia
    getJson('https://www.drivebc.ca/api/webcams/').then((list) => list.filter((c) => c.is_on !== false && !c.marked_stale && Array.isArray(c.location?.coordinates)).map((c) => {
      const coords = c.location?.coordinates || [];
      return { id: 'bc-' + c.id, name: c.name, lat: coords[1], lon: coords[0], img: 'https://www.drivebc.ca' + (c.links?.imageDisplay || `/images/${c.id}.jpg`), src: 'DriveBC Kanada' };
    })),
  ];
  const results = await Promise.allSettled(sources);
  const all = [];
  for (const r of results) {
    if (r.status === 'fulfilled') all.push(...r.value);
    else console.warn('[world] Kameras:', r.reason?.message);
  }
  const ok = all.filter((c) => Number.isFinite(c.lat) && Number.isFinite(c.lon) && /^https:\/\//.test(c.img || ''));
  if (!ok.length) throw new Error('Kameras vorübergehend nicht verfügbar.');
  return ok;
}

const LOADERS = { satellites: loadSatellites, flights: loadFlights, cameras: loadCameras };

async function feed(kind) {
  const c = cache[kind];
  if (!c) throw new Error('Unbekannte Datenart.');
  if (Date.now() - c.at < TTL[kind] && c.data.length) return c.data;
  if (pending[kind]) return pending[kind];
  pending[kind] = LOADERS[kind]().then((data) => {
    c.data = data;
    c.at = Date.now();
    return data;
  }).catch((error) => {
    if (c.data.length) return c.data; // alte Daten sind besser als keine
    throw error;
  }).finally(() => { delete pending[kind]; });
  return pending[kind];
}

/** Satellitenpositionen jetzt und in 60 s – der Globus bewegt sie dazwischen flüssig weiter. */
function propagate(records, withNames) {
  const now = new Date();
  const later = new Date(now.getTime() + 60000);
  const g0 = sat.gstime(now);
  const g1 = sat.gstime(later);
  const r1 = (v) => Math.round(v * 100) / 100;
  const out = [];
  for (const rec of records) {
    try {
      const p0 = sat.propagate(rec, now).position;
      const p1 = sat.propagate(rec, later).position;
      if (!p0 || !p1 || typeof p0 !== 'object' || typeof p1 !== 'object') continue;
      const a = sat.eciToGeodetic(p0, g0);
      const b = sat.eciToGeodetic(p1, g1);
      const item = { lat: r1(sat.degreesLat(a.latitude)), lon: r1(sat.degreesLong(a.longitude)), alt: Math.round(a.height), lat2: r1(sat.degreesLat(b.latitude)), lon2: r1(sat.degreesLong(b.longitude)) };
      if (withNames) item.n = rec.hubName;
      out.push(item);
    } catch { /* Bahn nicht berechenbar */ }
  }
  return { at: now.getTime(), items: out };
}

module.exports = { feed, propagate };
