'use strict';

/*
 * Size It Up (2.45.2): Wie groß ist das? Vollbild-Spiel mit Lobby.
 * Ein Referenz-Objekt mit bekannter Größe steht daneben, das gesuchte Objekt ist eine Silhouette.
 * Die Größe schätzt man, indem man die Silhouette mit der Maus größer/kleiner zieht – wie ein
 * Fenster (Griff an der Ecke oder die Figur selbst; Mausrad geht auch). Kein Schieberegler.
 * Modi: Klassisch (10 Runden), Täglich (für alle gleich), Themenrunden.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-sizeup';
  // [Emoji, Name, Größe in Metern, was gemessen wird, Thema]
  const ITEMS = [
    ['🦠', 'Bakterium (E. coli)', 0.000002, 'Länge', 'natur'],
    ['🐜', 'Ameise', 0.005, 'Länge', 'tiere'],
    ['🐝', 'Honigbiene', 0.015, 'Länge', 'tiere'],
    ['🍓', 'Erdbeere', 0.03, 'Höhe', 'alltag'],
    ['🥚', 'Hühnerei', 0.057, 'Höhe', 'alltag'],
    ['🔑', 'Haustürschlüssel', 0.06, 'Länge', 'alltag'],
    ['🎾', 'Tennisball', 0.067, 'Durchmesser', 'alltag'],
    ['🦋', 'Tagpfauenauge', 0.06, 'Spannweite', 'tiere'],
    ['🍎', 'Apfel', 0.08, 'Durchmesser', 'alltag'],
    ['🐭', 'Hausmaus', 0.085, 'Körperlänge', 'tiere'],
    ['📱', 'Smartphone', 0.15, 'Höhe', 'alltag'],
    ['✏️', 'Bleistift', 0.175, 'Länge', 'alltag'],
    ['🍌', 'Banane', 0.19, 'Länge', 'alltag'],
    ['⚽', 'Fussball', 0.22, 'Durchmesser', 'alltag'],
    ['🏀', 'Basketball', 0.24, 'Durchmesser', 'alltag'],
    ['💻', 'Laptop (15 Zoll)', 0.36, 'Breite', 'alltag'],
    ['🍉', 'Wassermelone', 0.35, 'Länge', 'alltag'],
    ['🐇', 'Kaninchen', 0.4, 'Körperlänge', 'tiere'],
    ['🐈', 'Hauskatze', 0.46, 'Körperlänge', 'tiere'],
    ['🐕', 'Labrador', 0.57, 'Schulterhöhe', 'tiere'],
    ['🪑', 'Stuhl', 0.9, 'Höhe', 'alltag'],
    ['🎸', 'Gitarre', 1.0, 'Länge', 'alltag'],
    ['🐧', 'Kaiserpinguin', 1.15, 'Höhe', 'tiere'],
    ['🦩', 'Flamingo', 1.3, 'Höhe', 'tiere'],
    ['🐎', 'Pferd', 1.6, 'Schulterhöhe', 'tiere'],
    ['🧍', 'Erwachsener Mensch', 1.75, 'Größe', 'alltag'],
    ['🚲', 'Fahrrad', 1.75, 'Länge', 'bauten'],
    ['🐢', 'Lederschildkröte', 1.8, 'Panzerlänge', 'tiere'],
    ['🚪', 'Zimmertür', 2.0, 'Höhe', 'alltag'],
    ['🦅', 'Weißkopfseeadler', 2.0, 'Spannweite', 'tiere'],
    ['🛏️', 'Doppelbett', 2.0, 'Länge', 'alltag'],
    ['🌻', 'Sonnenblume', 2.5, 'Höhe', 'natur'],
    ['🎹', 'Konzertflügel', 2.75, 'Länge', 'alltag'],
    ['🐘', 'Afrikanischer Elefant', 3.3, 'Schulterhöhe', 'tiere'],
    ['🚗', 'Auto (Golf)', 4.3, 'Länge', 'bauten'],
    ['🦈', 'Weißer Hai', 4.5, 'Länge', 'tiere'],
    ['🐊', 'Salzwasserkrokodil', 5.0, 'Länge', 'tiere'],
    ['🦒', 'Giraffe', 5.5, 'Höhe', 'tiere'],
    ['🏠', 'Einfamilienhaus', 9, 'Höhe', 'bauten'],
    ['🚌', 'Linienbus', 12, 'Länge', 'bauten'],
    ['🦖', 'Tyrannosaurus rex', 12.3, 'Länge', 'tiere'],
    ['🚂', 'Lokomotive', 19, 'Länge', 'bauten'],
    ['🐋', 'Blauwal', 25, 'Länge', 'tiere'],
    ['✈️', 'Airbus A380', 73, 'Länge', 'bauten'],
    ['🗽', 'Freiheitsstatue (mit Sockel)', 93, 'Höhe', 'bauten'],
    ['🌲', 'Küstenmammutbaum', 100, 'Höhe', 'natur'],
    ['🏟️', 'Fussballfeld', 105, 'Länge', 'bauten'],
    ['🚀', 'Saturn-V-Rakete', 111, 'Höhe', 'bauten'],
    ['🎡', 'London Eye', 135, 'Höhe', 'bauten'],
    ['⛪', 'Kölner Dom', 157, 'Höhe', 'bauten'],
    ['🛳️', 'Titanic', 269, 'Länge', 'bauten'],
    ['🗼', 'Eiffelturm', 330, 'Höhe', 'bauten'],
    ['🏙️', 'Burj Khalifa', 828, 'Höhe', 'bauten'],
    ['🗻', 'Mount Everest', 8849, 'Höhe', 'natur'],
    ['🌕', 'Mond', 3474800, 'Durchmesser', 'natur'],
    ['🌍', 'Erde', 12742000, 'Durchmesser', 'natur'],
    ['🪐', 'Jupiter', 139820000, 'Durchmesser', 'natur'],
    ['☀️', 'Sonne', 1392700000, 'Durchmesser', 'natur'],
  ];
  const THEMES = [
    ['tiere', 'Tiere', '🐘', 'Von der Ameise bis zum Blauwal'],
    ['alltag', 'Alltag', '🪑', 'Dinge, die du jeden Tag siehst'],
    ['bauten', 'Bauwerke & Fahrzeuge', '🗼', 'Busse, Türme, Schiffe'],
    ['natur', 'Natur & Weltall', '🪐', 'Mikroben bis Sonne'],
  ];
  const ROUNDS = 10;
  const st = { phase: 'lobby', mode: 'classic', theme: '', round: 0, rounds: [], guess: 0, total: 0, root: null, loaded: false, stats: { best: 0, games: 0, sum: 0, dailyDone: '', dailyScore: 0, themeBest: {} }, drag: null };

  function fmt(m) {
    const n = (v, d = 0) => v.toLocaleString('de-CH', { maximumFractionDigits: d });
    if (m < 0.001) return `${n(m * 1e6, m < 0.00001 ? 1 : 0)} µm`;
    if (m < 0.01) return `${n(m * 1000, 1)} mm`;
    if (m < 1) return `${n(m * 100, m < 0.1 ? 1 : 0)} cm`;
    if (m < 1000) return `${n(m, m < 10 ? 2 : 0)} m`;
    return `${n(m / 1000, m < 10000 ? 2 : 0)} km`;
  }
  const n0 = (v) => Math.round(v).toLocaleString('de-CH');

  /* ------------------------------------------------------------------ Spielablauf */
  function newGame(mode, theme = '') {
    const rnd = mode === 'daily' ? A.seeded('sizeup-' + A.today()) : Math.random;
    const base = mode === 'theme' ? ITEMS.filter((i) => i[4] === theme) : ITEMS;
    const pool = [...base].map((x) => [rnd(), x]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
    st.rounds = [];
    for (const target of pool) {
      if (st.rounds.length >= ROUNDS) break;
      // Referenz: ähnliche Größenordnung (Faktor 1/40 … 40), aber nicht dasselbe Objekt
      const refs = ITEMS.filter((r) => r !== target && Math.abs(Math.log10(r[2] / target[2])) < 1.6 && Math.abs(Math.log10(r[2] / target[2])) > 0.05);
      if (!refs.length) continue;
      st.rounds.push({ target, ref: refs[Math.floor(rnd() * refs.length)], guess: null, pts: 0 });
    }
    st.mode = mode;
    st.theme = theme;
    st.round = 0;
    st.total = 0;
    startRound();
  }
  function startRound() {
    const r = st.rounds[st.round];
    st.guess = Math.log10(r.ref[2]); // startet so groß wie die Referenz
    st.phase = 'play';
  }
  const range = () => {
    const c = Math.log10(st.rounds[st.round].ref[2]);
    return [c - 2, c + 2];
  };
  const setGuess = (g) => {
    const [lo, hi] = range();
    st.guess = Math.max(lo, Math.min(hi, g));
  };
  function lock() {
    const r = st.rounds[st.round];
    const g = 10 ** st.guess;
    const err = Math.abs(Math.log10(g / r.target[2]));
    // 0 Fehler = 1000 Punkte, Faktor 2 daneben ≈ 500, Faktor 4 daneben = 0
    r.pts = Math.max(0, Math.round(1000 * (1 - err / 0.6)));
    r.guess = g;
    st.total += r.pts;
    st.phase = 'result';
  }
  function finish() {
    st.phase = 'end';
    const s = st.stats;
    s.games += 1;
    s.sum += st.total;
    if (st.total > s.best) s.best = st.total;
    if (st.mode === 'daily') { s.dailyDone = A.today(); s.dailyScore = st.total; }
    if (st.mode === 'theme') s.themeBest[st.theme] = Math.max(s.themeBest[st.theme] || 0, st.total);
    A.store.set('sizeup', s, true);
    A.earn(Math.round(st.total / 200));
  }

  /* ------------------------------------------------------------------ Bühne */
  // Pixelgrössen: das Grössere füllt die Bühnenhöhe, das Kleinere ist massstäblich kleiner
  function sizes(stageH) {
    const r = st.rounds[st.round];
    const g = st.phase === 'result' ? r.target[2] : 10 ** st.guess;
    const ratio = g / r.ref[2];
    const H = Math.max(120, stageH);
    return ratio >= 1 ? { ref: Math.max(8, H / ratio), tgt: H } : { ref: H, tgt: Math.max(8, H * ratio) };
  }
  function stageInner() {
    const r = st.rounds[st.round];
    const stage = st.root?.querySelector('.su-stage');
    // grösste Figur: so hoch wie die Bühne (minus Beschriftung), aber nie breiter als gut ein Drittel
    const H = Math.min((stage?.clientHeight || 420) - 96, (stage?.clientWidth || 900) * 0.36);
    const px = sizes(H);
    const result = st.phase === 'result';
    return `<div class="su-col">
        <div class="su-fig" style="--s:${px.ref}px"><span class="su-emo">${r.ref[0]}</span></div>
        <b>${esc(r.ref[1])}</b><small>${esc(r.ref[3])}: ${fmt(r.ref[2])}</small>
      </div>
      <div class="su-col">
        <div class="su-fig su-target ${result ? 'done' : ''}" style="--s:${px.tgt}px" ${result ? '' : 'data-su-drag title="Ziehen zum Vergrössern/Verkleinern"'}>
          <span class="su-emo">${r.target[0]}</span>
          ${result ? '' : '<i class="su-box"></i><i class="su-grip" data-su-drag></i>'}
        </div>
        <b>${esc(r.target[1])}</b><small>${result ? `${esc(r.target[3])}: ${fmt(r.target[2])}` : `${esc(r.target[3])}: <span class="su-live">${fmt(10 ** st.guess)}</span>`}</small>
      </div>`;
  }
  function paintStage() {
    const stage = st.root?.querySelector('.su-stage');
    if (stage) stage.innerHTML = stageInner();
  }

  /* ------------------------------------------------------------------ Lobby & Ergebnis */
  function lobbyHtml() {
    const s = st.stats;
    const avg = s.games ? s.sum / s.games : 0;
    const dailyDone = s.dailyDone === A.today();
    return `<div class="su-scene su-lobby">
      <div class="su-lobby-in">
        <div class="su-hero">${['🐜', '🐈', '🧍', '🦒', '🦖', '🗼', '🗻'].map((e, i) => `<span class="su-emo" style="--i:${i}">${e}</span>`).join('')}</div>
        <h1>Size It Up</h1>
        <p class="su-lead">Schätze, wie groß Dinge wirklich sind. Zieh die Silhouette so groß, wie du denkst – neben einem Objekt, dessen Größe du kennst.</p>
        <div class="su-modes">
          <button class="su-mode" data-su-mode="classic"><span>🎯</span><b>Klassisch</b><small>10 zufällige Runden</small></button>
          <button class="su-mode ${dailyDone ? 'done' : ''}" data-su-mode="daily"><span>📅</span><b>Täglich</b><small>${dailyDone ? `Heute gespielt: ${n0(s.dailyScore)} Punkte` : 'Für alle gleich – einmal pro Tag'}</small></button>
        </div>
        <h3 class="su-h3">Themenrunden</h3>
        <div class="su-themes">${THEMES.map(([k, name, emo, sub]) => `<button class="su-theme" data-su-mode="theme" data-su-theme="${k}"><span class="su-emo">${emo}</span><b>${esc(name)}</b><small>${esc(sub)}${s.themeBest[k] ? ` · Rekord ${n0(s.themeBest[k])}` : ''}</small></button>`).join('')}</div>
        <div class="su-stats">
          <div><b>${n0(s.best)}</b><small>Bestwert</small></div>
          <div><b>${n0(s.games)}</b><small>Spiele</small></div>
          <div><b>${n0(avg)}</b><small>Durchschnitt</small></div>
          <div><b>${ITEMS.length}</b><small>Objekte</small></div>
        </div>
      </div>
    </div>`;
  }
  function endHtml() {
    const label = st.mode === 'daily' ? 'Tagesrunde' : st.mode === 'theme' ? THEMES.find((t) => t[0] === st.theme)?.[1] : 'Klassisch';
    return `<div class="su-scene su-lobby">
      <div class="su-lobby-in">
        <p class="su-kicker">${esc(label)} · Ergebnis</p>
        <h1>${n0(st.total)} Punkte</h1>
        <p class="su-lead">von ${n0(ROUNDS * 1000)} möglichen · Bestwert ${n0(st.stats.best)}</p>
        <div class="su-recap">${st.rounds.map((r) => `<div><span class="su-emo mini">${r.target[0]}</span><span class="su-grow">${esc(r.target[1])}<small>${fmt(r.target[2])} · du: ${fmt(r.guess)}</small></span><b class="${r.pts >= 700 ? 'good' : r.pts >= 300 ? 'ok' : 'bad'}">${r.pts}</b></div>`).join('')}</div>
        <div class="su-actions">
          ${st.mode === 'daily' ? '' : `<button class="rv-btn primary" data-su-mode="${st.mode}" ${st.theme ? `data-su-theme="${st.theme}"` : ''}>Nochmal</button>`}
          <button class="rv-btn" data-su="lobby">Zur Lobby</button>
        </div>
      </div>
    </div>`;
  }

  function paint() {
    if (!st.root) return;
    if (st.phase === 'lobby') { st.root.innerHTML = lobbyHtml(); return; }
    if (st.phase === 'end') { st.root.innerHTML = endHtml(); return; }
    const r = st.rounds[st.round];
    const result = st.phase === 'result';
    st.root.innerHTML = `<div class="su-scene">
      <header class="su-top">
        <button class="su-back" data-su="lobby" title="Zur Lobby">‹ Lobby</button>
        <div class="su-q"><small>Runde ${st.round + 1} / ${st.rounds.length}</small><h2>Wie ${['Größe', 'Höhe', 'Schulterhöhe'].includes(r.target[3]) ? 'hoch' : 'groß'} ist: ${esc(r.target[1])}?</h2></div>
        <span class="su-score">◆ ${n0(st.total)}</span>
      </header>
      <div class="su-stage">${''}</div>
      <footer class="su-bottom">
        ${result
          ? `<div class="su-res ${r.pts >= 700 ? 'good' : r.pts >= 300 ? 'ok' : 'bad'}">+${r.pts}</div>
             <p>Richtig: <b>${fmt(r.target[2])}</b> · Deine Schätzung: ${fmt(r.guess)}</p>
             <button class="rv-btn primary big" data-su="next">${st.round + 1 >= st.rounds.length ? 'Ergebnis' : 'Weiter'}</button>`
          : `<output class="su-out">${fmt(10 ** st.guess)}</output>
             <p class="su-hint">Silhouette mit der Maus größer oder kleiner ziehen (oder Mausrad)</p>
             <button class="rv-btn primary big" data-su="lock">Einloggen</button>`}
      </footer>
    </div>`;
    paintStage();
  }

  /* ------------------------------------------------------------------ Bedienung */
  function onPointerDown(e) {
    if (!st.root?.contains(e.target) || st.phase !== 'play' || e.button !== 0) return;
    const fig = e.target.closest('[data-su-drag]');
    if (!fig) return;
    e.preventDefault();
    st.drag = { x: e.clientX, y: e.clientY, g: st.guess };
    st.root.querySelector('.su-scene')?.classList.add('dragging');
  }
  function onPointerMove(e) {
    if (!st.drag) return;
    // nach oben/rechts ziehen = größer, nach unten/links = kleiner (wie eine Fenster-Ecke)
    const d = (e.clientX - st.drag.x) - (e.clientY - st.drag.y);
    setGuess(st.drag.g + d / 260);
    live();
  }
  function onPointerUp() {
    if (!st.drag) return;
    st.drag = null;
    st.root?.querySelector('.su-scene')?.classList.remove('dragging');
  }
  function live() {
    paintStage();
    const out = st.root?.querySelector('.su-out');
    if (out) out.textContent = fmt(10 ** st.guess);
  }
  function onWheel(e) {
    if (!st.root?.contains(e.target) || st.phase !== 'play' || !e.target.closest('.su-stage')) return;
    e.preventDefault();
    setGuess(st.guess + (e.deltaY < 0 ? 0.03 : -0.03));
    live();
  }
  function onKey(e) {
    if (!st.root || !document.contains(st.root) || st.phase !== 'play') return;
    if (e.key === 'ArrowUp' || e.key === 'ArrowRight') { setGuess(st.guess + 0.02); live(); e.preventDefault(); }
    else if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') { setGuess(st.guess - 0.02); live(); e.preventDefault(); }
    else if (e.key === 'Enter') { lock(); paint(); }
  }
  function onClick(e) {
    if (!st.root?.contains(e.target)) return;
    const m = e.target.closest('[data-su-mode]');
    if (m) {
      if (m.dataset.suMode === 'daily' && st.stats.dailyDone === A.today()) return A.toast?.('Die Tagesrunde hast du heute schon gespielt – morgen gibt es eine neue.');
      newGame(m.dataset.suMode, m.dataset.suTheme || '');
      return paint();
    }
    const a = e.target.closest('[data-su]')?.dataset.su;
    if (a === 'lock') lock();
    else if (a === 'next') {
      st.round += 1;
      if (st.round >= st.rounds.length) finish();
      else startRound();
    } else if (a === 'lobby') st.phase = 'lobby';
    else return;
    paint();
  }
  document.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointermove', onPointerMove);
  window.addEventListener('pointerup', onPointerUp);
  window.addEventListener('pointercancel', onPointerUp);
  document.addEventListener('wheel', onWheel, { passive: false });
  document.addEventListener('keydown', onKey);
  document.addEventListener('click', onClick);
  window.addEventListener('resize', () => { if (st.root && st.phase !== 'lobby' && st.phase !== 'end') paintStage(); });

  A.define(
    ID,
    { nav: 'Size It Up', title: 'Size It Up', sub: 'Größen schätzen', icon: 'resize', tint: 'linear-gradient(135deg,#f59e0b,#7c3aed)', desc: 'Wie groß ist ein Blauwal neben einem Bus? Schätze echte Größen, indem du Silhouetten neben einem Referenz-Objekt größer oder kleiner ziehst.' },
    {
      game: true,
      async mount(root) {
        st.root = root;
        if (!st.loaded) {
          st.loaded = true;
          const saved = await A.store.get('sizeup', {}, true);
          st.stats = { best: Number(saved?.best) || 0, games: Number(saved?.games) || 0, sum: Number(saved?.sum) || 0, dailyDone: saved?.dailyDone || '', dailyScore: Number(saved?.dailyScore) || 0, themeBest: saved?.themeBest || {} };
        }
        paint();
      },
      unmount() {
        st.root = null;
        st.drag = null;
      },
    },
  );
})();
