'use strict';

/*
 * 2.45 Eigene durchsichtige Windows-Taskleiste (ersetzt TranslucentTB): ein kleiner C#-Helfer setzt
 * über SetWindowCompositionAttribute die Akzent-Füllung aller Taskleisten (Haupt- und Zweitmonitor)
 * und wiederholt das laufend, weil Windows die Füllung bei Startmenü, Maximieren usw. zurücksetzt.
 * Modi: clear (ganz durchsichtig), blur (verschwommen), acrylic (Acryl), normal (Windows-Standard).
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CS = String.raw`
using System;
using System.Runtime.InteropServices;
using System.Threading;
public static class RevTaskbarGlass {
  [StructLayout(LayoutKind.Sequential)] struct ACCENT { public int State; public int Flags; public uint Color; public int Anim; }
  [StructLayout(LayoutKind.Sequential)] struct WCAD { public int Attr; public IntPtr Data; public int Size; }
  [DllImport("user32.dll")] static extern int SetWindowCompositionAttribute(IntPtr h, ref WCAD d);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p, IntPtr after, string cls, string title);
  static void Apply(IntPtr h, int state, uint color) {
    var a = new ACCENT { State = state, Flags = 2, Color = color };
    int size = Marshal.SizeOf(a);
    IntPtr p = Marshal.AllocHGlobal(size);
    Marshal.StructureToPtr(a, p, false);
    var d = new WCAD { Attr = 19, Data = p, Size = size };
    SetWindowCompositionAttribute(h, ref d);
    Marshal.FreeHGlobal(p);
  }
  static void All(int state, uint color) {
    IntPtr t = FindWindowEx(IntPtr.Zero, IntPtr.Zero, "Shell_TrayWnd", null);
    if (t != IntPtr.Zero) Apply(t, state, color);
    IntPtr s = IntPtr.Zero;
    while ((s = FindWindowEx(IntPtr.Zero, s, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero) Apply(s, state, color);
  }
  public static void Run(int state, uint color) {
    var reader = new Thread(() => { string l; while ((l = Console.In.ReadLine()) != null) { if (l == "QUIT") break; } All(0, 0); Environment.Exit(0); });
    reader.IsBackground = true; reader.Start();
    Console.Out.WriteLine("ok");
    while (true) { All(state, color); Thread.Sleep(120); }
  }
}
`;
// AccentState: 2 = Verlauf (mit Alpha → ganz durchsichtig), 3 = Unschärfe, 4 = Acryl
const MODES = { clear: [2, 0x00000000], blur: [3, 0x10000000], acrylic: [4, 0x40101010] };

/*
 * 2.45.11: Unter Windows 11 zeichnet die Taskleiste ihren Hintergrund selbst (XAML) – die Akzent-Füllung
 * oben wird dort ignoriert, die Taskleiste blieb undurchsichtig. Das geht nur mit einem Eingriff in den
 * Explorer, wie ihn TranslucentTB macht. Ist TranslucentTB installiert, steuert der Hub es deshalb
 * (Stil in dessen settings.json, die es live neu liest; bei Bedarf starten) statt es zu beenden.
 */
const ttbPackage = () => {
  try {
    const dir = path.join(process.env.LOCALAPPDATA || '', 'Packages');
    return fs.readdirSync(dir).find((name) => /^28017CharlesMilette\.TranslucentTB_/i.test(name)) || '';
  } catch {
    return '';
  }
};

function useTranslucentTB(mode, tint = '') {
  // Test-Instanz (eigenes Profil): TranslucentTB des echten PCs nicht anfassen
  const pkg = process.platform === 'win32' && !process.env.REVOLUTION_HUB_PROFILE ? ttbPackage() : '';
  if (!pkg) return false;
  const file = path.join(process.env.LOCALAPPDATA, 'Packages', pkg, 'RoamingState', 'settings.json');
  try {
    const text = fs.readFileSync(file, 'utf8');
    // nur die Darstellung „Desktop“ (erster Block) ändern – Kommentar/BOM der Datei bleiben erhalten
    let next = text.replace(/("desktop_appearance"\s*:\s*\{[^}]*?"accent"\s*:\s*")[a-z]+(")/, `$1${mode}$2`);
    // 2.45.12 eigene Farbe der Taskleiste (#RRGGBBAA)
    if (/^#[0-9A-F]{8}$/i.test(tint)) next = next.replace(/("desktop_appearance"\s*:\s*\{[^}]*?"color"\s*:\s*")#[0-9A-Fa-f]{6,8}(")/, `$1${tint}$2`);
    if (next !== text) fs.writeFileSync(file, next, 'utf8');
  } catch {
    /* noch keine Einstellungen: TranslucentTB legt sie beim ersten Start an */
  }
  if (mode !== 'normal') {
    require('child_process').execFile('tasklist', ['/FI', 'IMAGENAME eq TranslucentTB.exe', '/FO', 'CSV', '/NH'], { windowsHide: true }, (error, stdout) => {
      if (!error && /TranslucentTB\.exe/i.test(String(stdout))) return;
      spawn('explorer.exe', [`shell:AppsFolder\\${pkg}!TranslucentTB`], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    });
  }
  return true;
}

class TaskbarGlass {
  constructor(dir) {
    this.dir = dir;
    this.child = null;
    this.mode = 'normal';
    this.engine = 'hub';
  }

  set(mode, tint = '') {
    this.stop();
    this.mode = MODES[mode] ? mode : 'normal';
    if (useTranslucentTB(this.mode, tint)) {
      this.engine = 'translucenttb';
      return this.mode;
    }
    this.engine = 'hub';
    if (this.mode === 'normal' || process.platform !== 'win32') return this.mode;
    const [state, base] = MODES[this.mode];
    // eigene Farbe: #RRGGBBAA → AABBGGRR (Format der Akzent-Füllung)
    const t = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(tint);
    const color = t && parseInt(t[4], 16) > 0 ? parseInt(t[4] + t[3] + t[2] + t[1], 16) >>> 0 : base;
    const file = path.join(this.dir, 'taskbar-glass.ps1');
    fs.mkdirSync(this.dir, { recursive: true });
    fs.writeFileSync(file, `﻿$ErrorActionPreference='Stop'\r\nAdd-Type -TypeDefinition @'\r\n${CS}\r\n'@\r\n[RevTaskbarGlass]::Run(${state}, ${color})\r\n`, 'utf8');
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], { windowsHide: true, stdio: ['pipe', 'ignore', 'ignore'] });
    child.stdin.on('error', () => {});
    child.on('exit', () => {
      if (this.child === child) this.child = null;
    });
    this.child = child;
    return this.mode;
  }

  stop() {
    const c = this.child;
    this.child = null;
    if (!c) return;
    try {
      c.stdin.write('QUIT\n'); // Helfer setzt die Taskleiste vor dem Beenden auf Standard zurück
    } catch {
      /* egal */
    }
    setTimeout(() => {
      try {
        c.kill();
      } catch {
        /* egal */
      }
    }, 800);
  }
}

module.exports = { TaskbarGlass, MODES };
