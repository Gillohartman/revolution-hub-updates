'use strict';
/*
 * 3D-Modell – geführte Einführungen (Schritt für Schritt mit Hervorhebung) und Tipps.
 * Ein Schritt geht automatisch weiter, sobald seine Aufgabe erledigt ist.
 */
(function () {
  const TIPS = [
    'Löcher (Loch, Bohrung) werden beim Gruppieren vom Körper abgezogen – so entstehen Bohrungen und Aussparungen.',
    'Mit „Fläche auf Bett“ (L) legst du ein Objekt mit einer beliebigen Fläche flach – wichtig für gute Druckhaftung.',
    'Umschalt beim Drehen: Schritte von 1° statt 15°. Umschalt beim Ziehen: nur eine Richtung.',
    'Im Feld „Grösse“ mit „Proportional“ bleibt das Seitenverhältnis erhalten.',
    'Pfeiltasten verschieben um das Raster, Bild auf/ab hebt und senkt das Objekt.',
    'Ein Würfel mit „Rundung“ druckt sich schöner und ist angenehmer in der Hand.',
    'Für Passungen (Deckel, Steckverbindungen) 0.2–0.4 mm Spiel einplanen.',
    'Wände unter 0.8 mm werden von vielen Slicern weggelassen – lieber 1.2 mm oder mehr.',
    'Überhänge über 45° brauchen Stützmaterial. Fasen statt waagrechter Kanten helfen.',
    '„Netz der Auswahl prüfen“ zeigt, ob ein Teil wasserdicht und druckbar ist.',
    'Im Bearbeiten-Modus (Tab) kannst du Punkte und Flächen direkt ziehen oder Flächen extrudieren.',
    'Strg+D dupliziert, Strg+G gruppiert, Strg+Umschalt+G löst eine Gruppe wieder.',
  ];
  const KEYS = [
    ['Linke Maus', 'Auswählen, ziehen, Rahmen aufziehen'], ['Rechte Maus', 'Ansicht drehen'], ['Mitte / Umschalt+Rechts', 'Ansicht verschieben'], ['Mausrad', 'Zoomen'],
    ['G / R / S', 'Verschieben / Drehen / Skalieren'], ['Tab', 'Punkte bearbeiten'], ['L', 'Fläche auf Bett'], ['M', 'Messen'], ['D', 'Auf Bett legen'], ['H', 'Körper ⇄ Loch'],
    ['F', 'Einpassen'], ['1 / 3 / 7 / 5', 'Vorne / Rechts / Oben / Ortho'], ['Strg+Z / Y', 'Rückgängig / Wiederholen'], ['Strg+D', 'Duplizieren'], ['Strg+G', 'Gruppieren'], ['Strg+E', 'STL exportieren'], ['Entf', 'Löschen'],
  ];

  function Tour(api) {
    const TOURS = {
      basics: {
        name: 'Grundlagen',
        steps: [
          { title: 'Willkommen', text: 'Mit 3D-Modell baust du druckbare Teile aus einfachen Formen. Diese Einführung dauert etwa zwei Minuten – du kannst jederzeit abbrechen.' },
          { sel: '[data-add="box"]', title: 'Eine Form hinzufügen', text: 'Klicke links auf „Würfel“. Er erscheint auf dem Druckbett.', start: () => api.count(), done: (s) => api.count() > s },
          { sel: '#stage', title: 'Verschieben und umsehen', text: 'Ziehe den Würfel mit der linken Maustaste. Mit der rechten Maustaste drehst du die Ansicht, mit dem Mausrad zoomst du.', start: () => api.stateKey(), done: (s) => api.stateKey() !== s },
          { sel: '[data-size="2"]', title: 'Genaue Masse', text: 'Gib hier eine Höhe ein, zum Beispiel 10, und drücke Enter. Alle Werte sind in Millimetern.', start: () => api.sizeKey(), done: (s) => api.sizeKey() !== s },
          { sel: '[data-add="cyl"][data-hole]', title: 'Ein Loch bohren', text: 'Klicke auf „Bohrung“. Löcher sind durchsichtig und werden später abgezogen. Schiebe die Bohrung in den Würfel.', done: () => api.hasHole() },
          { sel: '#obj-list', title: 'Gruppieren', text: 'Wähle beide aus (Strg+A) und klicke rechts auf „Gruppieren“. Das Loch wird aus dem Würfel ausgeschnitten.', done: () => api.hasGroup() },
          { sel: '.m-check-sec', title: 'Druckprüfung', text: 'Hier siehst du, ob alles im Bauraum liegt, das Volumen und ungefähr wie viel Filament das Teil braucht.' },
          { sel: '#export-btn', title: 'Fertig zum Drucken', text: 'Über „Exportieren“ speicherst du eine STL- oder 3MF-Datei und öffnest sie in deinem Slicer. Viel Spass beim Drucken!' },
        ],
      },
      edit: {
        name: 'Formen und Bearbeiten',
        steps: [
          { sel: '[data-gallery]', title: 'Fertige Formen', text: 'Unter „Formen“ findest du Stern, Herz, Zahnrad, Gewinde, Haken, Handyständer, Box mit Deckel und mehr. Öffne die Galerie.', done: () => api.galleryOpen() },
          { sel: '#gallery', title: 'Form wählen', text: 'Klicke auf eine Form. Ihre Masse kannst du danach rechts unter „Form“ anpassen.', start: () => api.count(), done: (s) => api.count() > s },
          { sel: '[data-mode="edit"]', title: 'Punkte bearbeiten', text: 'Mit einem gewählten Objekt auf „Punkte bearbeiten“ klicken (oder Tab drücken).', done: () => api.mode() === 'edit' },
          { sel: '#stage', title: 'Punkte und Flächen ziehen', text: 'Klicke einen Punkt an – oder schalte rechts auf „Flächen“ und klicke eine Fläche. Ziehen verformt das Objekt, die Pfeile bewegen genau entlang einer Achse.', done: () => api.editCount() > 0 },
          { sel: '[data-ed="extrude"]', title: 'Extrudieren', text: 'Mit gewählter Fläche: „Extrudieren“ zieht sie um den angegebenen Wert heraus. Ein negativer Wert drückt eine Tasche hinein.' },
          { sel: '#stage', title: 'Verformen', text: 'Tab beendet das Bearbeiten. Unter „Verformen“ kannst du jedes Objekt verjüngen, verdrehen, biegen oder glätten.' },
        ],
      },
    };
    let cur = null; let timer = 0;
    const box = document.createElement('div'); box.className = 't-box'; box.hidden = true;
    const ring = document.createElement('div'); ring.className = 't-ring'; ring.hidden = true;
    document.body.append(ring, box);
    function end() { cur = null; box.hidden = true; ring.hidden = true; clearInterval(timer); try { localStorage.setItem('m3d-tour-seen', '1'); } catch { /* egal */ } }
    function show() {
      const t = TOURS[cur.id]; const s = t.steps[cur.i];
      cur.start = s.start ? s.start() : null; cur.ok = false;
      box.innerHTML = `<small>${t.name} · ${cur.i + 1}/${t.steps.length}</small><b>${s.title}</b><p>${s.text}</p><div class="t-btns"><button data-t="end">Beenden</button><span></span>${cur.i ? '<button data-t="back">Zurück</button>' : ''}<button data-t="next" class="t-main">${cur.i === t.steps.length - 1 ? 'Fertig' : s.done ? 'Überspringen' : 'Weiter'}</button></div>`;
      box.hidden = false; place();
    }
    function place() {
      if (!cur) return;
      const s = TOURS[cur.id].steps[cur.i]; const el = s.sel && document.querySelector(s.sel);
      const W = window.innerWidth, H = window.innerHeight; const bw = 300, bh = box.offsetHeight || 150;
      if (!el || !el.getClientRects().length) { ring.hidden = true; box.style.left = `${(W - bw) / 2}px`; box.style.top = `${H / 2 - bh / 2}px`; return; }
      const r = el.getBoundingClientRect(); const big = r.width > W * 0.5;
      ring.hidden = false; Object.assign(ring.style, { left: `${r.left - 4}px`, top: `${r.top - 4}px`, width: `${r.width + 8}px`, height: `${r.height + 8}px` });
      let x, y;
      if (big) { x = r.left + r.width / 2 - bw / 2; y = r.top + 16; }
      else if (r.right + bw + 16 < W) { x = r.right + 14; y = r.top + r.height / 2 - bh / 2; }
      else if (r.left - bw - 16 > 0) { x = r.left - bw - 14; y = r.top + r.height / 2 - bh / 2; }
      else { x = r.left + r.width / 2 - bw / 2; y = r.bottom + 12; if (y + bh > H) y = r.top - bh - 12; }
      box.style.left = `${Math.max(8, Math.min(W - bw - 8, x))}px`; box.style.top = `${Math.max(8, Math.min(H - bh - 8, y))}px`;
    }
    function go(d) { const n = TOURS[cur.id].steps.length; cur.i += d; if (cur.i >= n) return end(); cur.i = Math.max(0, cur.i); show(); }
    box.addEventListener('click', (e) => { const b = e.target.closest('[data-t]'); if (!b) return; if (b.dataset.t === 'end') end(); else go(b.dataset.t === 'back' ? -1 : 1); });
    window.addEventListener('resize', place);
    function start(id) {
      end(); cur = { id, i: 0 }; show();
      timer = setInterval(() => {
        if (!cur) return; place();
        const s = TOURS[cur.id].steps[cur.i];
        if (s.done && !cur.ok && s.done(cur.start)) { cur.ok = true; box.classList.add('t-ok'); setTimeout(() => { box.classList.remove('t-ok'); if (cur) go(1); }, 650); }
      }, 300);
    }
    return { start, end, TOURS, active: () => !!cur };
  }
  window.M3Tour = { Tour, TIPS, KEYS };
})();
