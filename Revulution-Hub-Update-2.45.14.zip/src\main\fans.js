'use strict';

/*
 * 2.45 Lüfter: was ohne eigenen Treiber möglich ist.
 *  - Windows-Kühlrichtlinie (aktiv = erst Lüfter hochdrehen, passiv = erst CPU drosseln) – echte Wirkung auf die Lüfter.
 *  - Grafikkarte: Temperatur und Lüfter-% über nvidia-smi (NVIDIA).
 *  - Mainboard-Lüfter (Drehzahl) und Temperaturen über LibreHardwareMonitor/OpenHardwareMonitor, wenn eines davon läuft (WMI).
 * Drehzahlen selbst einstellen braucht einen Kernel-Treiber (Super-I/O) – dafür öffnet der Hub auf Wunsch „Fan Control“.
 */
const fs = require('fs');
const { execFile } = require('child_process');

const run = (file, args, timeout = 12000) => new Promise((resolve) => execFile(file, args, { windowsHide: true, timeout }, (err, out, errOut) => resolve({ err, out: String(out || ''), errOut: String(errOut || '') })));
const COOL = ['SUB_PROCESSOR', 'SYSCOOLPOL'];

async function coolingPolicy() {
  const r = await run('powercfg.exe', ['/q', 'SCHEME_CURRENT', ...COOL]);
  const ac = /(?:AC|Netz)[^:\n]*:\s*0x([0-9a-f]+)/i.exec(r.out);
  const dc = /(?:DC|Akku|Gleichstrom)[^:\n]*:\s*0x([0-9a-f]+)/i.exec(r.out);
  // Reihenfolge im Text: erst AC, dann DC – Rückfall über die beiden letzten Hex-Werte
  const hexes = [...r.out.matchAll(/:\s*0x([0-9a-f]{8})\s*$/gim)].map((m) => parseInt(m[1], 16));
  const acV = ac ? parseInt(ac[1], 16) : hexes[hexes.length - 2];
  const dcV = dc ? parseInt(dc[1], 16) : hexes[hexes.length - 1];
  return { ac: Number.isFinite(acV) ? (acV === 1 ? 'active' : 'passive') : 'unknown', dc: Number.isFinite(dcV) ? (dcV === 1 ? 'active' : 'passive') : 'unknown' };
}
async function setPolicy(mode) {
  const v = mode === 'active' ? '1' : '0';
  const a = await run('powercfg.exe', ['/setacvalueindex', 'SCHEME_CURRENT', ...COOL, v]);
  const b = await run('powercfg.exe', ['/setdcvalueindex', 'SCHEME_CURRENT', ...COOL, v]);
  await run('powercfg.exe', ['/setactive', 'SCHEME_CURRENT']);
  if (a.err && b.err) throw new Error((a.errOut || a.out || 'Windows hat die Kühlrichtlinie nicht übernommen.').trim().split(/\r?\n/)[0]);
  return coolingPolicy();
}
function nvidiaSmi() {
  for (const p of ['C:\\Windows\\System32\\nvidia-smi.exe', 'C:\\Program Files\\NVIDIA Corporation\\NVSMI\\nvidia-smi.exe']) if (fs.existsSync(p)) return p;
  return '';
}
async function gpu() {
  const exe = nvidiaSmi();
  if (!exe) return [];
  const r = await run(exe, ['--query-gpu=name,temperature.gpu,fan.speed,power.draw,utilization.gpu', '--format=csv,noheader,nounits']);
  if (r.err) return [];
  return r.out.trim().split(/\r?\n/).filter(Boolean).map((l) => {
    const [name, temp, fan, power, util] = l.split(',').map((x) => x.trim());
    return { name, temp: Number(temp), fan: Number(fan), power: Number(power), util: Number(util) };
  });
}
async function sensors() {
  const ps = `foreach ($ns in 'root\\LibreHardwareMonitor','root\\OpenHardwareMonitor') { try { $s = Get-CimInstance -Namespace $ns -ClassName Sensor -ErrorAction Stop | Where-Object { $_.SensorType -in 'Fan','Temperature','Control' }; if ($s) { $s | ForEach-Object { [pscustomobject]@{ type = [string]$_.SensorType; name = [string]$_.Name; value = [double]$_.Value; parent = [string]$_.Parent } } | ConvertTo-Json -Compress; break } } catch {} }`;
  const r = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps]);
  try {
    const j = JSON.parse(r.out || '[]');
    return (Array.isArray(j) ? j : [j]).filter((x) => x && x.name);
  } catch {
    return [];
  }
}
const FANCONTROL = ['%LOCALAPPDATA%\\Programs\\FanControl\\FanControl.exe', 'C:\\Program Files\\FanControl\\FanControl.exe', 'C:\\Program Files (x86)\\FanControl\\FanControl.exe'];
const expand = (p) => p.replace(/%([^%]+)%/g, (_m, v) => process.env[v] || '');
async function state() {
  const [policy, gpus, sens] = await Promise.all([coolingPolicy().catch(() => ({ ac: 'unknown', dc: 'unknown' })), gpu().catch(() => []), sensors().catch(() => [])]);
  const fc = FANCONTROL.map(expand).find((p) => fs.existsSync(p)) || '';
  return { policy, gpus, sensors: sens, fanControl: fc, at: Date.now() };
}

module.exports = { state, setPolicy };
