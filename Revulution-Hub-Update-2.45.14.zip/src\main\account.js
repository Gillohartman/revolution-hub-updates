'use strict';

/*
 * Revolution-Konto: Anmelden mit E-Mail + Passwort, optional mit Zwei-Faktor-Anmeldung
 * (Authenticator-App), und Profil-Sync. Gespeichert wird in Firestore unter
 * revhub_accounts/{uid}: { data: "<JSON>", updatedAt: <ms>, name: "…" }.
 * Der Anmelde-Schlüssel liegt verschlüsselt (Windows-Datenschutz) im Benutzerordner.
 */
const fs = require('fs');
const path = require('path');
const { app, safeStorage } = require('electron');
const fbase = require('./firebase');

class Account {
  constructor({ getLocal, applyRemote, onChange }) {
    this.fb = fbase.client(fbase.accountConfig());
    this.getLocal = getLocal;
    this.applyRemote = applyRemote;
    this.onChange = onChange || (() => {});
    this.session = null;
    this.pendingMfa = null; // { pending, enrollmentId, email }
    this.enroll = null; // laufende 2FA-Einrichtung
    this.status = { signedIn: false, email: '', uid: '', lastSync: 0, syncing: false, error: '', emailVerified: false, mfa: false, needCode: false, project: this.fb.cfg.projectId };
    this.pushTimer = null;
    this.file = path.join(app.getPath('userData'), 'account.bin');
  }

  saveSession() {
    try {
      if (!this.session) return fs.rmSync(this.file, { force: true });
      const raw = JSON.stringify({ email: this.session.email, uid: this.session.uid, refreshToken: this.session.refreshToken, project: this.fb.cfg.projectId });
      fs.writeFileSync(this.file, safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(raw) : Buffer.from(raw));
    } catch {
      /* ohne Speicher: beim nächsten Start neu anmelden */
    }
  }

  async restore() {
    try {
      const buf = fs.readFileSync(this.file);
      const raw = safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(buf) : buf.toString();
      const s = JSON.parse(raw);
      if (!s?.refreshToken || (s.project && s.project !== this.fb.cfg.projectId)) return;
      this.session = { ...s, ...(await this.fb.refresh(s.refreshToken)) };
      this.status = { ...this.status, signedIn: true, email: s.email, uid: this.session.uid, error: '' };
      this.saveSession();
      await this.loadInfo();
      this.onChange(this.state());
      await this.sync();
      await this.checkName();
    } catch {
      /* abgelaufen oder offline – bleibt abgemeldet */
    }
  }

  /** Firebase-Zugriff (für Bewertungen und Kommentare). */
  client() {
    return this.fb;
  }

  state() {
    return { ...this.status, needCode: Boolean(this.pendingMfa) };
  }

  async token() {
    if (!this.session) throw new Error('Nicht angemeldet');
    if (Date.now() > this.session.expires) {
      this.session = { ...this.session, ...(await this.fb.refresh(this.session.refreshToken)) };
      this.saveSession();
    }
    return this.session.idToken;
  }

  async loadInfo() {
    try {
      const info = await this.fb.lookup(await this.token());
      this.status.emailVerified = info.emailVerified;
      this.status.mfa = info.mfa.length > 0;
      this.mfaIds = info.mfa.map((m) => m.id);
    } catch {
      /* egal */
    }
  }

  async signedIn(sess, create) {
    this.session = sess;
    this.pendingMfa = null;
    this.status = { ...this.status, signedIn: true, email: sess.email || this.status.email, uid: sess.uid, error: '' };
    this.saveSession();
    if (create) this.fb.sendVerify(sess.idToken).catch(() => {});
    await this.loadInfo();
    await this.sync(create ? 'push' : 'auto');
    await this.checkName();
    return this.state();
  }

  /** Nach dem Anmelden: aktuellen Namen reservieren; ist er schon vergeben, muss ein neuer her. */
  async checkName() {
    const name = this.currentName?.() || '';
    if (!name) return;
    try {
      await this.claimName(name);
      this.status.nameConflict = '';
    } catch (e) {
      if (e.code === 'NAME_TAKEN') this.status.nameConflict = name;
    }
    this.onChange(this.state());
  }

  async login(email, password, create = false) {
    const mail = String(email || '').trim().toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail)) throw new Error('Bitte eine gültige E-Mail eingeben.');
    if (String(password || '').length < 6) throw new Error('Das Passwort braucht mindestens 6 Zeichen.');
    const r = await this.fb.signIn(mail, String(password), create);
    if (r.mfa) {
      // 2FA ist an: jetzt kommt der Code aus der Authenticator-App
      this.pendingMfa = r.mfa;
      this.status.email = mail;
      this.onChange(this.state());
      return this.state();
    }
    return this.signedIn(r, create);
  }

  async verifyCode(code) {
    if (!this.pendingMfa) throw new Error('Bitte zuerst mit E-Mail und Passwort anmelden.');
    const sess = await this.fb.finishMfa(this.pendingMfa.pending, this.pendingMfa.enrollmentId, code);
    return this.signedIn({ ...sess, email: sess.email || this.pendingMfa.email }, false);
  }

  cancelCode() {
    this.pendingMfa = null;
    this.onChange(this.state());
    return this.state();
  }

  /* ---------------- 2FA verwalten */
  async mfaStart() {
    await this.loadInfo();
    if (!this.status.emailVerified) {
      await this.fb.sendVerify(await this.token()).catch(() => {});
      throw new Error('Bestätige zuerst deine E-Mail-Adresse – wir haben dir gerade einen Link geschickt. Danach hier noch einmal klicken.');
    }
    const t = await this.fb.startTotp(await this.token());
    this.enroll = t;
    const label = encodeURIComponent(`Revulution Hub:${this.status.email}`);
    return { secret: t.secret, uri: `otpauth://totp/${label}?secret=${t.secret}&issuer=Revulution%20Hub&digits=${t.digits}&period=${t.period}&algorithm=${t.algorithm}`, digits: t.digits };
  }

  async mfaFinish(code) {
    if (!this.enroll) throw new Error('Bitte die Einrichtung neu starten.');
    const r = await this.fb.finishTotp(await this.token(), this.enroll.session, code);
    this.enroll = null;
    if (r.idToken) this.session = { ...this.session, idToken: r.idToken, refreshToken: r.refreshToken || this.session.refreshToken, expires: Date.now() + 55 * 60000 };
    this.saveSession();
    await this.loadInfo();
    this.onChange(this.state());
    return this.state();
  }

  async mfaRemove() {
    await this.loadInfo();
    for (const id of this.mfaIds || []) {
      const r = await this.fb.removeMfa(await this.token(), id);
      if (r.idToken) this.session = { ...this.session, idToken: r.idToken, refreshToken: r.refreshToken || this.session.refreshToken, expires: Date.now() + 55 * 60000 };
    }
    this.saveSession();
    await this.loadInfo();
    this.onChange(this.state());
    return this.state();
  }

  async resendVerify() {
    await this.fb.sendVerify(await this.token());
    return true;
  }

  logout() {
    this.session = null;
    this.pendingMfa = null;
    this.status = { ...this.status, signedIn: false, email: '', uid: '', lastSync: 0, syncing: false, error: '', emailVerified: false, mfa: false };
    this.saveSession();
    this.onChange(this.state());
    return this.state();
  }

  async reset(email) {
    return this.fb.resetPassword(String(email || '').trim().toLowerCase());
  }

  /** Abgleich: neuerer Stand gewinnt (Cloud → PC oder PC → Cloud). */
  async sync(mode = 'auto') {
    if (!this.session || this.status.syncing) return this.state();
    this.status.syncing = true;
    this.onChange(this.state());
    try {
      const token = await this.token();
      const docPath = `revhub_accounts/${this.session.uid}`;
      // Erste Anmeldung dieses Kontos auf diesem PC (z. B. nach Neuinstallation): nie blind
      // hochladen – sonst überschreibt ein frischer PC Name, Freunde und Punkte im Konto.
      const first = this.syncedUid?.() !== this.session.uid;
      const remote = mode === 'push' && !first ? null : await this.fb.getDoc(docPath, token);
      const local = this.getLocal();
      const localAt = Number(local.updatedAt) || 0;
      if (remote && remote.data && (first || mode === 'pull' || Number(remote.updatedAt) > localAt)) {
        this.applyRemote(JSON.parse(remote.data), Number(remote.updatedAt));
        this.markSynced?.(this.session.uid);
        // zusammengeführten Stand gleich wieder hochladen (Punkte/Freunde beider Seiten)
        if (first) {
          const now = Date.now();
          const merged = this.getLocal();
          await this.fb.setDoc(docPath, { data: JSON.stringify({ ...merged, updatedAt: now }), updatedAt: now, name: String(merged.profile?.name || '') }, token);
          this.markLocal?.(now);
        }
      } else {
        this.markSynced?.(this.session.uid);
        const now = Date.now();
        await this.fb.setDoc(docPath, { data: JSON.stringify({ ...local, updatedAt: now }), updatedAt: now, name: String(local.profile?.name || '') }, token);
        this.markLocal?.(now);
      }
      this.status = { ...this.status, lastSync: Date.now(), error: '' };
    } catch (error) {
      this.status.error = fbase.friendly(error).message;
    }
    this.status.syncing = false;
    this.onChange(this.state());
    return this.state();
  }

  /* ---------------- 2.45.9 Eindeutige Anzeigenamen
     Jeder Name gehört genau einem Konto: revhub_names/{name in Kleinbuchstaben, ohne Leerzeichen} = { uid, name }.
     Braucht die Regeln aus dem Admin-Center (match /revhub_names/{key}). */
  static nameKey(name) {
    return String(name || '').trim().toLowerCase().replace(/\s+/g, '').replace(/[/.#$[\]]/g, '_').slice(0, 40);
  }
  /** Name reservieren; wirft „vergeben“, wenn ein anderes Konto ihn hat. Ohne Konto: nichts zu prüfen. */
  async claimName(name, previous = '') {
    if (!this.session) return { checked: false };
    const key = Account.nameKey(name);
    if (key.length < 2) throw new Error('Mindestens 2 Zeichen.');
    const token = await this.token();
    const path = `revhub_names/${encodeURIComponent(key)}`;
    try {
      const cur = await this.fb.getDoc(path, token);
      if (cur?.uid && cur.uid !== this.session.uid) {
        const e = new Error(`Der Name „${String(name).trim()}“ ist schon vergeben – bitte einen anderen wählen.`);
        e.code = 'NAME_TAKEN';
        throw e;
      }
      if (!cur || cur.name !== String(name).trim()) await this.fb.setDoc(path, { uid: this.session.uid, name: String(name).trim(), at: Date.now() }, token);
      // alten Namen freigeben
      const old = Account.nameKey(previous);
      if (old && old !== key) {
        const prev = await this.fb.getDoc(`revhub_names/${encodeURIComponent(old)}`, token).catch(() => null);
        if (prev?.uid === this.session.uid) await this.fb.delDoc(`revhub_names/${encodeURIComponent(old)}`, token).catch(() => {});
      }
      this.status.nameRules = true;
      return { checked: true };
    } catch (error) {
      if (error.code === 'NAME_TAKEN') throw error;
      // Regeln noch nicht eingetragen oder offline: Name lokal übernehmen, Prüfung später
      this.status.nameRules = !/PERMISSION|denied|403/i.test(String(error?.message || error));
      return { checked: false, reason: this.status.nameRules ? 'offline' : 'rules' };
    }
  }

  changed() {
    if (!this.session) return;
    clearTimeout(this.pushTimer);
    this.pushTimer = setTimeout(() => this.sync('push').catch(() => {}), 8000);
  }
}

module.exports = { Account };
