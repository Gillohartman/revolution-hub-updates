# Revolution Hub – schneller Wächter der Kindersicherung (2.45.9)
# Wartet, bis der Hub-Prozess endet, und startet ihn sofort neu – ausser die Kindersicherung wurde
# ausgeschaltet oder der Hub mit Eltern-PIN beendet (dann steht "on": false in der Konfiguration).
param([string]$Config)
$ErrorActionPreference = 'SilentlyContinue'
function Read-Guard { try { Get-Content -LiteralPath $Config -Raw | ConvertFrom-Json } catch { $null } }
$cfg = Read-Guard
while ($cfg -and $cfg.on) {
  $p = Get-Process -Id $cfg.pid -ErrorAction SilentlyContinue
  if ($p) { $p.WaitForExit() }
  Start-Sleep -Milliseconds 600
  $cfg = Read-Guard
  if (-not $cfg -or -not $cfg.on) { break }
  # schon wieder da (z. B. selbst neu gestartet)?
  if (Get-Process -Id $cfg.pid -ErrorAction SilentlyContinue) { continue }
  if ($cfg.dry) {
    Add-Content -LiteralPath $cfg.log -Value ("Neustart noetig: Hub " + $cfg.pid + " beendet um " + (Get-Date -Format o))
    break
  }
  Start-Process -FilePath $cfg.exe -ArgumentList $cfg.args
  # warten, bis der neue Hub seine Prozess-ID einträgt
  $old = $cfg.pid
  for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Milliseconds 500
    $cfg = Read-Guard
    if (-not $cfg -or -not $cfg.on -or $cfg.pid -ne $old) { break }
  }
}
