'use strict';

/*
 * Updates über das Internet.
 * Der Hub liest eine kleine Datei „update.json“ von einer Adresse, die du in den Optionen
 * einträgst (z. B. aus einem GitHub-Repository):
 *   { "version": "2.6.0", "url": "https://…/Revolution-Hub-Update-2.6.0.zip", "sha256": "…", "notes": "…" }
 * Ist die Version neuer, lädt er das Paket, prüft die Prüfsumme, ersetzt die App-Dateien
 * und startet neu. Erstellt wird beides mit scripts\publish-update.ps1.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { app, net } = require('electron');
const { applyPendingIsland } = require('./orbit');

/** .NET-Version aus OrbitIsland.runtimeconfig.json (z. B. „10.0.13“). */
const islandRuntime = (dir) => {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(dir, 'OrbitIsland.runtimeconfig.json'), 'utf8').replace(/^﻿/, ''));
    return String(j.runtimeOptions?.includedFrameworks?.[0]?.version || '');
  } catch {
    return '';
  }
};
/**
 * Ein Paket mit nur den Island-Programmdateien (ohne .NET-Laufzeit) passt nur zur gleichen Laufzeit.
 * island.json im Paket nennt sie; weicht die installierte ab, bleibt die Island unverändert.
 */
const islandRuntimeMismatch = (pkgDir, installDir) => {
  if (fs.existsSync(path.join(pkgDir, 'coreclr.dll'))) return ''; // vollständige Island mit Laufzeit
  let wanted = '';
  try {
    wanted = String(JSON.parse(fs.readFileSync(path.join(pkgDir, 'island.json'), 'utf8').replace(/^﻿/, '')).runtime || '');
  } catch {
    return '';
  }
  const have = islandRuntime(installDir);
  return wanted && have && wanted !== have ? `Island braucht .NET ${wanted}, installiert ist ${have} – bitte mit -WithIsland veröffentlichen.` : '';
};

const newer = (a, b) => {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0), pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i += 1) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
};
const httpsUrl = (value) => {
  try {
    const u = new URL(String(value || '').trim());
    return u.protocol === 'https:' ? u.toString() : '';
  } catch {
    return '';
  }
};

class Updater {
  constructor({ getUrl, onProgress, beforeIsland }) {
    this.beforeIsland = beforeIsland;
    this.getUrl = getUrl;
    this.onProgress = onProgress || (() => {});
    this.found = null;
    this.busy = false;
  }

  /** Nachsehen, ob es eine neuere Version gibt. */
  async check() {
    const url = httpsUrl(this.getUrl());
    const current = app.getVersion();
    if (!url) return { ok: false, current, error: 'Noch keine Update-Adresse eingetragen.' };
    try {
      const res = await net.fetch(`${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`, { headers: { 'User-Agent': 'Revolution-Hub', 'Cache-Control': 'no-cache' } });
      if (!res.ok) throw new Error(`Adresse nicht erreichbar (${res.status})`);
      let m = await res.json();
      // 2.45.10: raw.githubusercontent.com liefert update.json bis zu 5 Minuten aus dem Zwischenspeicher –
      // dann fand der Hub ein gerade veröffentlichtes Update nicht. Zusätzlich direkt über die GitHub-API
      // fragen (nicht zwischengespeichert) und die neuere Angabe nehmen.
      const raw = /^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+?)(\?|$)/.exec(url);
      if (raw) {
        try {
          const api = await net.fetch(`https://api.github.com/repos/${raw[1]}/${raw[2]}/contents/${raw[4]}?ref=${raw[3]}&t=${Date.now()}`, { headers: { 'User-Agent': 'Revolution-Hub', Accept: 'application/vnd.github.raw+json' } });
          if (api.ok) {
            const fresh = await api.json();
            if (/^\d+\.\d+\.\d+$/.test(String(fresh?.version || '')) && newer(fresh.version, String(m.version || '0.0.0'))) m = fresh;
          }
        } catch { /* API nicht erreichbar: dann eben die zwischengespeicherte Angabe */ }
      }
      const version = String(m.version || '').trim();
      const zip = httpsUrl(new URL(String(m.url || ''), url).toString());
      if (!/^\d+\.\d+\.\d+$/.test(version) || !zip) throw new Error('Die Update-Datei ist unvollständig (version/url fehlen).');
      const available = newer(version, current);
      this.found = available ? { version, url: zip, sha256: String(m.sha256 || '').toLowerCase(), notes: String(m.notes || '').slice(0, 600) } : null;
      return { ok: true, current, available, version, notes: this.found?.notes || '' };
    } catch (error) {
      return { ok: false, current, error: String(error?.message || error) };
    }
  }

  /** Paket laden, prüfen, entpacken und neu starten. */
  async install() {
    if (this.busy) throw new Error('Ein Update läuft bereits.');
    if (!this.found) throw new Error('Kein Update gefunden – bitte zuerst suchen.');
    if (!app.isPackaged) throw new Error('Updates gibt es nur in der installierten App (nicht im Entwicklungsmodus).');
    this.busy = true;
    const f = this.found;
    const tmp = path.join(os.tmpdir(), `revhub-update-${Date.now()}`);
    try {
      this.onProgress({ step: 'download', pct: 0 });
      const res = await net.fetch(f.url, { headers: { 'User-Agent': 'Revolution-Hub' } });
      if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
      const total = Number(res.headers.get('content-length')) || 0;
      const chunks = [];
      let got = 0;
      const reader = res.body.getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(Buffer.from(value));
        got += value.length;
        if (got > 400 * 1024 * 1024) throw new Error('Das Paket ist zu groß.');
        this.onProgress({ step: 'download', pct: total ? Math.round((got / total) * 100) : 0 });
      }
      const data = Buffer.concat(chunks);
      const hash = crypto.createHash('sha256').update(data).digest('hex');
      if (f.sha256 && f.sha256 !== hash) throw new Error('Die Prüfsumme stimmt nicht – das Paket wurde nicht eingespielt.');
      fs.mkdirSync(tmp, { recursive: true });
      const zip = path.join(tmp, 'update.zip');
      const out = path.join(tmp, 'app');
      fs.writeFileSync(zip, data);
      this.onProgress({ step: 'unpack', pct: 100 });
      await new Promise((resolve, reject) => {
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${out.replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 120000 }, (error) => (error ? reject(new Error('Entpacken fehlgeschlagen.')) : resolve()));
      });
      // Nur einspielen, wenn das Paket wirklich wie die App aussieht
      const pkgFile = path.join(out, 'package.json');
      if (!fs.existsSync(path.join(out, 'src', 'main', 'main.js')) || !fs.existsSync(pkgFile)) throw new Error('Das Paket enthält keine gültige App.');
      const pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf8'));
      if (pkg.name !== 'revolution-hub' || pkg.version !== f.version) throw new Error('Das Paket passt nicht zur angekündigten Version.');
      const appDir = path.join(process.resourcesPath, 'app');
      const backup = path.join(appDir, `src.old-${Date.now()}`);
      this.onProgress({ step: 'install', pct: 100 });
      fs.renameSync(path.join(appDir, 'src'), backup);
      try {
        fs.cpSync(path.join(out, 'src'), path.join(appDir, 'src'), { recursive: true });
        fs.copyFileSync(pkgFile, path.join(appDir, 'package.json'));
        if (fs.existsSync(path.join(out, 'modules'))) fs.cpSync(path.join(out, 'modules'), path.join(appDir, 'modules'), { recursive: true, force: true });
        // 2.45: entfernte Module (z. B. die alte 216-MB-Weltansicht) auch auf dem PC löschen
        for (const gone of ['worldview']) {
          if (!fs.existsSync(path.join(out, 'modules', gone))) fs.rmSync(path.join(appDir, 'modules', gone), { recursive: true, force: true });
        }
      } catch (error) {
        // zurück zum alten Stand
        fs.rmSync(path.join(appDir, 'src'), { recursive: true, force: true });
        fs.renameSync(backup, path.join(appDir, 'src'));
        throw error;
      }
      fs.rmSync(backup, { recursive: true, force: true });
      // 2.45.11: Admin-Center nicht mehr im öffentlichen Paket → altes Startmenü-Symbol entfernen
      if (!fs.existsSync(path.join(out, 'src', 'admin'))) {
        try { fs.rmSync(path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Revulution Admin-Center.lnk'), { force: true }); } catch { /* egal */ }
      }
      // 2.45.3 Lüfter-Helfer (RevFans) mitliefern, wenn das Paket ihn enthält
      if (fs.existsSync(path.join(out, 'fans', 'RevFans.exe'))) {
        try {
          fs.cpSync(path.join(out, 'fans'), path.join(process.resourcesPath, 'fans'), { recursive: true, force: true });
        } catch (error) {
          console.error('[update] Lüfter-Helfer nicht ersetzt (läuft er gerade?):', error.message);
        }
      }
      // Island (eigene Windows-App) mitliefern, wenn das Paket sie enthält.
      // 2.45.11: Seit 2.45.0 enthielten die Pakete keine Island mehr – Laptops, die nur über Updates
      // liefen, behielten die alte. Jetzt liegen die Island-Dateien in jedem Paket. Sie kommen zuerst
      // nach resources\orbit-pending; ist eine Datei gesperrt, spielt der Hub sie beim nächsten
      // Island-Start ein (statt still die alte Island weiterlaufen zu lassen).
      if (fs.existsSync(path.join(out, 'orbit', 'OrbitIsland.exe'))) {
        try {
          const skip = islandRuntimeMismatch(path.join(out, 'orbit'), path.join(process.resourcesPath, 'orbit'));
          if (skip) throw new Error(skip);
          const pending = path.join(process.resourcesPath, 'orbit-pending');
          fs.rmSync(pending, { recursive: true, force: true });
          fs.cpSync(path.join(out, 'orbit'), pending, { recursive: true, force: true });
          await this.beforeIsland?.();
          await new Promise((r) => setTimeout(r, 1200));
          const result = applyPendingIsland(process.resourcesPath);
          if (!result.applied) console.error('[update] Island wird beim nächsten Start ersetzt:', result.error);
        } catch (error) {
          console.error('[update] Island nicht ersetzt:', error.message);
        }
      }
      fs.rmSync(tmp, { recursive: true, force: true });
      this.onProgress({ step: 'restart', pct: 100 });
      setTimeout(() => {
        app.relaunch();
        app.exit(0);
      }, 900);
      return { ok: true, version: f.version };
    } catch (error) {
      try {
        fs.rmSync(tmp, { recursive: true, force: true });
      } catch {
        /* egal */
      }
      throw error;
    } finally {
      this.busy = false;
    }
  }
}

module.exports = { Updater, newer, httpsUrl };
