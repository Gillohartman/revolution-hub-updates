'use strict';

/* 2.44 Full Gaming Mode
   Der Hub hat sich komplett beendet (Island, Widgets, Module, Hintergrunddienste). Dieser Prozess
   zeigt nur noch das Crosshair und einen kleinen Knopf auf dem Desktop, der den Hub mit allem,
   was vorher offen war, wieder startet. Sonst läuft hier nichts – so bleibt der Arbeitsspeicher frei. */
const { app, BrowserWindow, Tray, Menu, nativeImage, screen, protocol, net, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { execFile } = require('child_process');

const APP_ROOT = path.join(__dirname, '..', '..');
const STATE_FILE = path.join(app.getPath('userData'), 'gaming-mode.json');
const GAME_EXE = 'FortniteClient-Win64-Shipping.exe';

let snap = {};
try {
  snap = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) || {};
} catch {
  snap = {};
}
const xh = snap.crosshair || null;

app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=64');
protocol.registerSchemesAsPrivileged([{ scheme: 'xh', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }]);

if (!app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}

let overlay = null;
let button = null;
let tray = null;
let gameRunning = false;
let leaving = false;

/** Hub wieder starten – mit der Seite, die vorher offen war. */
function restore() {
  if (leaving) return;
  leaving = true;
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify({ ...snap, active: false, endedAt: Date.now() }));
  } catch {
    /* egal */
  }
  const args = process.argv.slice(1).filter((a) => a !== '--gaming-mode' && !a.startsWith('--page='));
  if (snap.page) args.push(`--page=${snap.page}`);
  args.push('--from-gaming-mode');
  app.releaseSingleInstanceLock();
  app.relaunch({ args });
  app.exit(0);
}
// Startet jemand den Hub ganz normal (Startmenü, Taskleiste), endet der Gaming Mode
app.on('second-instance', () => restore());

const visible = () => Boolean(xh && xh.enabled !== false && (xh.alwaysOn || !xh.onlyInGame || gameRunning));

function pushConfig() {
  if (!overlay || overlay.isDestroyed() || overlay.webContents.isLoading() || !xh) return;
  overlay.webContents.send('xh:config', { profile: xh.profile, scale: xh.scale || 1, offsetX: xh.offsetX || 0, offsetY: xh.offsetY || 0, visible: visible() });
  if (visible()) {
    if (!overlay.isVisible()) overlay.showInactive();
    overlay.setAlwaysOnTop(true, 'screen-saver');
  } else if (overlay.isVisible()) overlay.hide();
}

function targetBounds() {
  const b = xh?.bounds;
  if (b && screen.getAllDisplays().some((d) => d.bounds.x === b.x && d.bounds.y === b.y && d.bounds.width === b.width && d.bounds.height === b.height)) return b;
  return screen.getPrimaryDisplay().bounds;
}

function createOverlay() {
  if (!xh) return;
  const bounds = targetBounds();
  overlay = new BrowserWindow({
    ...bounds,
    frame: false, transparent: true, resizable: false, movable: false, minimizable: false, maximizable: false, fullscreenable: false,
    skipTaskbar: true, focusable: false, hasShadow: false, show: false, backgroundColor: '#00000000',
    webPreferences: { preload: path.join(APP_ROOT, 'modules', 'gaming-hub', 'app', 'overlay-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false, backgroundThrottling: false, spellcheck: false },
  });
  overlay.setAlwaysOnTop(true, 'screen-saver');
  overlay.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  overlay.setIgnoreMouseEvents(true, { forward: false });
  try {
    overlay.setContentProtection(!xh.captureVisible);
  } catch {
    /* ältere Windows-Versionen */
  }
  overlay.loadFile(path.join(APP_ROOT, 'modules', 'gaming-hub', 'renderer', 'crosshair-overlay.html'));
  overlay.webContents.on('did-finish-load', pushConfig);
  ipcMain.on('xh:overlayReady', pushConfig);
  ipcMain.on('xh:overlayHide', () => overlay?.hide());
  // Vollbild-Spiele schieben sich sonst davor
  setInterval(() => {
    if (overlay && !overlay.isDestroyed() && overlay.isVisible()) overlay.setAlwaysOnTop(true, 'screen-saver');
  }, 5000);
}

/** Läuft Fortnite? Nur nötig, wenn das Crosshair nur im Spiel erscheinen soll. */
function watchGame() {
  if (!xh?.onlyInGame || xh.alwaysOn) return;
  const check = () =>
    execFile('tasklist', ['/FI', `IMAGENAME eq ${GAME_EXE}`, '/NH', '/FO', 'CSV'], { windowsHide: true }, (_e, out) => {
      const now = String(out || '').toLowerCase().includes(GAME_EXE.toLowerCase());
      if (now !== gameRunning) {
        gameRunning = now;
        pushConfig();
      }
    });
  check();
  setInterval(check, 5000);
}

/** Der Knopf auf dem Desktop: klein, rund, unten rechts über der Taskleiste – kommt nie über Spiele. */
function createButton() {
  const wa = screen.getPrimaryDisplay().workArea;
  const W = 84;
  const H = 84;
  button = new BrowserWindow({
    x: wa.x + wa.width - W - 14, y: wa.y + wa.height - H - 14, width: W, height: H,
    frame: false, transparent: true, resizable: false, movable: false, minimizable: false, maximizable: false, fullscreenable: false,
    skipTaskbar: true, alwaysOnTop: false, hasShadow: false, show: false, backgroundColor: '#00000000',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: true, spellcheck: false },
  });
  // 2.44: rundes Liquid-Glass-Logo – durchsichtig, mit Lichtkante; Klick startet den Hub
  let logo = '';
  try {
    logo = `data:image/png;base64,${nativeImage.createFromPath(path.join(APP_ROOT, 'src', 'ui', 'assets', 'logo-mark.png')).resize({ width: 96 }).toPNG().toString('base64')}`;
  } catch {
    logo = '';
  }
  const html = `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:">
<style>html,body{margin:0;height:100%;background:transparent;overflow:hidden;user-select:none}
a{position:absolute;left:8px;top:8px;width:68px;height:68px;display:grid;place-items:center;border-radius:50%;cursor:default;text-decoration:none;
background:radial-gradient(120% 90% at 50% -10%,rgba(255,255,255,.34),transparent 55%),radial-gradient(90% 60% at 50% 120%,rgba(255,255,255,.14),transparent 60%),rgba(255,255,255,.06);
box-shadow:inset 0 0 0 1px rgba(255,255,255,.28),inset 0 1.5px 0 rgba(255,255,255,.55),inset 0 -1px 0 rgba(255,255,255,.12),0 10px 24px -10px rgba(0,0,0,.6);
transition:transform .45s cubic-bezier(.34,1.56,.64,1),background .3s}
a:hover{transform:scale(1.08);background:radial-gradient(120% 90% at 50% -10%,rgba(255,255,255,.42),transparent 55%),radial-gradient(90% 60% at 50% 120%,rgba(255,255,255,.18),transparent 60%),rgba(255,255,255,.1)}
a:active{transform:scale(.92)}
img{width:34px;height:34px;object-fit:contain;filter:drop-shadow(0 1px 2px rgba(0,0,0,.45));pointer-events:none}
b{color:#fff;font:800 26px 'Segoe UI',sans-serif}</style></head>
<body><a href="revhub://start" title="Revulution Hub wieder starten">${logo ? `<img src="${logo}" alt="">` : '<b>R</b>'}</a></body></html>`;
  button.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
  button.webContents.on('will-navigate', (e, url) => {
    e.preventDefault();
    if (url.startsWith('revhub://start')) restore();
  });
  button.once('ready-to-show', () => button.showInactive());
}

function createTray() {
  try {
    const icon = nativeImage.createFromPath(path.join(APP_ROOT, 'src', 'ui', 'assets', 'logo.png')).resize({ width: 16, height: 16 });
    tray = new Tray(icon);
    tray.setToolTip('Revulution Hub – Gaming Mode (nur Crosshair)');
    tray.setContextMenu(Menu.buildFromTemplate([{ label: 'Hub wieder starten', click: restore }, { type: 'separator' }, { label: 'Ganz beenden', click: () => app.exit(0) }]));
    tray.on('click', restore);
  } catch {
    /* ohne Symbol geht es auch */
  }
}

app.whenReady().then(() => {
  protocol.handle('xh', (request) => {
    try {
      const url = new URL(request.url);
      const name = path.basename(decodeURIComponent(url.pathname).replace(/^\/+/, ''));
      if (!name) return new Response('', { status: 404 });
      if (url.hostname === 'rank') {
        const file = path.join(APP_ROOT, 'modules', 'gaming-hub', 'assets', 'ranks', name);
        if (!fs.existsSync(file)) return new Response('', { status: 404 });
        return new Response(fs.readFileSync(file), { headers: { 'content-type': 'image/png' } });
      }
      if (!xh?.crosshairDir) return new Response('', { status: 404 });
      return net.fetch(pathToFileURL(path.join(xh.crosshairDir, name)).toString());
    } catch {
      return new Response('', { status: 404 });
    }
  });
  createOverlay();
  watchGame();
  createButton();
  createTray();
  screen.on('display-metrics-changed', () => overlay && !overlay.isDestroyed() && overlay.setBounds(targetBounds()));
});
app.on('window-all-closed', () => {
  /* weiterlaufen – der Knopf oder das Tray-Symbol startet den Hub */
});
