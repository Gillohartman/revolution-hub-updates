'use strict';
/**
 * Hintergrund fürs Ulanzi-Deck aus der Live-Bibliothek des Hubs.
 * 2.45.6: nur noch als Standbild (erstes Bild des Videos) – das Live-Abspielen auf dem Deck ruckelte.
 * Das Studio schneidet das Bild wie jedes andere Hintergrundbild auf die 13 Tasten zu.
 */
const { spawn } = require('child_process');

/** Ganzes erstes Bild (nicht zugeschnitten) als JPEG-Data-URL. */
function thumb(ffmpeg, video) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-i', video, '-vf', 'scale=1280:-2', '-frames:v', '1', '-q:v', '3', '-f', 'image2pipe', '-vcodec', 'mjpeg', 'pipe:1'], { windowsHide: true });
    const chunks = [];
    p.stdout.on('data', (d) => chunks.push(d));
    p.on('error', reject);
    p.on('close', () => {
      const b = Buffer.concat(chunks);
      if (!b.length) return reject(new Error('Standbild des Hintergrunds konnte nicht gelesen werden.'));
      resolve(`data:image/jpeg;base64,${b.toString('base64')}`);
    });
  });
}

module.exports = { thumb };
