'use strict';

/*
 * 2.45.1 Showtime → PowerPoint (.pptx). Schreibt Office-Open-XML selbst (ohne Bibliothek):
 * Folien mit Hintergrundfarbe, Textfeldern (Schrift, Größe, Farbe, F/K/U, Ausrichtung, Aufzählung),
 * Formen (Rechteck, abgerundet, Ellipse, Dreieck, Pfeil, Stern, Linie, Sprechblase) und Bildern.
 * Modell (vom Renderer): { title, slides: [{ bg, els: [...] }] }, Maße in Folien-Pixeln (1600×900).
 */
const zlib = require('zlib');

const EMU = 7620; // 1600 px → 12 192 000 EMU (16:9)
const e = (px) => Math.round((Number(px) || 0) * EMU);
const x = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
const hex = (c, fallback = '000000') => {
  const m = /#([0-9a-f]{6})/i.exec(String(c || '')) || /#([0-9a-f]{3})\b/i.exec(String(c || ''));
  if (!m) {
    const rgb = /rgba?\((\d+),\s*(\d+),\s*(\d+)/i.exec(String(c || ''));
    return rgb ? rgb.slice(1, 4).map((v) => Number(v).toString(16).padStart(2, '0')).join('').toUpperCase() : fallback;
  }
  const h = m[1].length === 3 ? m[1].split('').map((ch) => ch + ch).join('') : m[1];
  return h.toUpperCase();
};
const NS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';
const XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
const GRP = '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>';
const PRST = { rect: 'rect', round: 'roundRect', ellipse: 'ellipse', triangle: 'triangle', arrow: 'rightArrow', star: 'star5', line: 'line', bubble: 'wedgeRoundRectCallout' };

/* ----------------------------------------------------------------- ZIP (Deflate) */
const CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buf) >>> 0;
  let c = 0xffffffff;
  for (const b of buf) c = CRC[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function zip(files) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const [name, content] of files) {
    const data = Buffer.isBuffer(content) ? content : Buffer.from(content, 'utf8');
    const packed = zlib.deflateRawSync(data, { level: 9 });
    const nb = Buffer.from(name, 'utf8');
    const crc = crc32(data);
    const l = Buffer.alloc(30);
    l.writeUInt32LE(0x04034b50, 0); l.writeUInt16LE(20, 4); l.writeUInt16LE(0x0800, 6); l.writeUInt16LE(8, 8);
    l.writeUInt32LE(crc, 14); l.writeUInt32LE(packed.length, 18); l.writeUInt32LE(data.length, 22); l.writeUInt16LE(nb.length, 26);
    locals.push(l, nb, packed);
    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10);
    c.writeUInt32LE(crc, 16); c.writeUInt32LE(packed.length, 20); c.writeUInt32LE(data.length, 24); c.writeUInt16LE(nb.length, 28); c.writeUInt32LE(offset, 42);
    centrals.push(c, nb);
    offset += 30 + nb.length + packed.length;
  }
  const size = centrals.reduce((s, b) => s + b.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(size, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, ...centrals, end]);
}

/* ----------------------------------------------------------------- feste Teile */
const THEME = `${XML}<a:theme ${NS} name="Showtime"><a:themeElements><a:clrScheme name="Showtime"><a:dk1><a:srgbClr val="000000"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F1F1F"/></a:dk2><a:lt2><a:srgbClr val="EEEEEE"/></a:lt2><a:accent1><a:srgbClr val="7C6CFF"/></a:accent1><a:accent2><a:srgbClr val="0A84FF"/></a:accent2><a:accent3><a:srgbClr val="30D158"/></a:accent3><a:accent4><a:srgbClr val="FF9F0A"/></a:accent4><a:accent5><a:srgbClr val="FF375F"/></a:accent5><a:accent6><a:srgbClr val="64D2FF"/></a:accent6><a:hlink><a:srgbClr val="0A84FF"/></a:hlink><a:folHlink><a:srgbClr val="BF5AF2"/></a:folHlink></a:clrScheme><a:fontScheme name="Showtime"><a:majorFont><a:latin typeface="Segoe UI"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Segoe UI"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="Showtime"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="28575"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>`;
const MASTER = `${XML}<p:sldMaster ${NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>${GRP}</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz="4400"/></a:lvl1pPr></p:titleStyle><p:bodyStyle><a:lvl1pPr><a:defRPr sz="2800"/></a:lvl1pPr></p:bodyStyle><p:otherStyle><a:lvl1pPr><a:defRPr sz="1800"/></a:lvl1pPr></p:otherStyle></p:txStyles></p:sldMaster>`;
const LAYOUT = `${XML}<p:sldLayout ${NS} type="blank" preserve="1"><p:cSld name="Leer"><p:spTree>${GRP}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`;
const rels = (list) => `${XML}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${list.map(([id, type, target]) => `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/${type}" Target="${target}"/>`).join('')}</Relationships>`;

/* ----------------------------------------------------------------- Folie */
function textBody(el) {
  const s = el.style || {};
  const anchor = s.valign === 'middle' ? 'ctr' : s.valign === 'bottom' ? 'b' : 't';
  const algn = s.align === 'center' ? 'ctr' : s.align === 'right' ? 'r' : 'l';
  const sz = Math.max(100, Math.round((Number(s.size) || 32) * 0.6 * 100));
  const rpr = `<a:rPr lang="de-DE" sz="${sz}"${s.bold ? ' b="1"' : ''}${s.italic ? ' i="1"' : ''}${s.underline ? ' u="sng"' : ''} dirty="0"><a:solidFill><a:srgbClr val="${hex(s.color, '222222')}"/></a:solidFill><a:latin typeface="${x(s.font || 'Segoe UI')}"/></a:rPr>`;
  const paras = (el.paras && el.paras.length ? el.paras : [{ text: el.text || '' }]).map((p) => {
    const ppr = p.bullet ? `<a:pPr marL="457200" indent="-342900" algn="${algn}">${p.bullet === 'num' ? '<a:buAutoNum type="arabicPeriod"/>' : '<a:buChar char="•"/>'}</a:pPr>` : `<a:pPr algn="${algn}"/>`;
    return `<a:p>${ppr}${p.text ? `<a:r>${rpr}<a:t>${x(p.text)}</a:t></a:r>` : `<a:endParaRPr lang="de-DE" sz="${sz}"/>`}</a:p>`;
  }).join('');
  return `<p:txBody><a:bodyPr wrap="square" lIns="91440" tIns="45720" rIns="91440" bIns="45720" anchor="${anchor}"><a:normAutofit/></a:bodyPr><a:lstStyle/>${paras}</p:txBody>`;
}
function xfrm(el) {
  const rot = Math.round(((Number(el.rot) || 0) % 360) * 60000);
  return `<a:xfrm${rot ? ` rot="${rot}"` : ''}><a:off x="${e(el.x)}" y="${e(el.y)}"/><a:ext cx="${Math.max(1, e(el.w))}" cy="${Math.max(1, e(el.h))}"/></a:xfrm>`;
}
function slideXml(sl, idBase, mediaRels) {
  let id = 2;
  const shapes = [];
  for (const el of sl.els || []) {
    const s = el.style || {};
    const n = id++;
    const alpha = s.opacity != null && s.opacity < 1 ? `<a:alpha val="${Math.round(s.opacity * 100000)}"/>` : '';
    if (el.type === 'image' && el.rel) {
      shapes.push(`<p:pic><p:nvPicPr><p:cNvPr id="${n}" name="Bild ${n}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="${el.rel}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr>${xfrm(el)}<a:prstGeom prst="${s.radius ? 'roundRect' : 'rect'}"><a:avLst/></a:prstGeom></p:spPr></p:pic>`);
      continue;
    }
    const prst = el.type === 'shape' ? PRST[s.shape] || 'rect' : s.radius ? 'roundRect' : 'rect';
    const fillCol = el.type === 'shape' ? (s.fill === 'transparent' ? '' : hex(s.fill || el.accent, '7C6CFF')) : s.fill ? hex(s.fill) : '';
    const fill = fillCol && prst !== 'line' ? `<a:solidFill><a:srgbClr val="${fillCol}">${alpha}</a:srgbClr></a:solidFill>` : '<a:noFill/>';
    const lnCol = prst === 'line' ? hex(s.fill || s.stroke || el.accent, '7C6CFF') : s.stroke ? hex(s.stroke) : '';
    const lnW = prst === 'line' ? Math.max(2, Number(s.strokeW) || 6) : Number(s.strokeW) || 0;
    const ln = lnCol && lnW ? `<a:ln w="${Math.round(lnW * EMU)}"><a:solidFill><a:srgbClr val="${lnCol}"/></a:solidFill></a:ln>` : '<a:ln><a:noFill/></a:ln>';
    const body = el.type === 'text' ? textBody(el) : s.text ? textBody({ ...el, style: { ...s, align: 'center', valign: 'middle', size: s.size || 32, color: s.color || 'FFFFFF' }, paras: [{ text: s.text }] }) : '';
    shapes.push(`<p:sp><p:nvSpPr><p:cNvPr id="${n}" name="${el.type === 'text' ? 'Textfeld' : 'Form'} ${n}"/><p:cNvSpPr${el.type === 'text' ? ' txBox="1"' : ''}/><p:nvPr/></p:nvSpPr><p:spPr>${xfrm(el)}<a:prstGeom prst="${prst}"><a:avLst/></a:prstGeom>${fill}${ln}</p:spPr>${body}</p:sp>`);
  }
  const bg = `<p:bg><p:bgPr><a:solidFill><a:srgbClr val="${hex(sl.bg, 'FFFFFF')}"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>`;
  return `${XML}<p:sld ${NS}><p:cSld>${bg}<p:spTree>${GRP}${shapes.join('')}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`;
}

/** Ganze Präsentation als .pptx-Buffer. */
function build(model) {
  const slides = Array.isArray(model?.slides) ? model.slides.slice(0, 300) : [];
  if (!slides.length) throw new Error('Keine Folien');
  const files = [];
  const media = [];
  slides.forEach((sl, i) => {
    const slideRels = [['rId1', 'slideLayout', '../slideLayouts/slideLayout1.xml']];
    for (const el of sl.els || []) {
      if (el.type !== 'image' || typeof el.src !== 'string') continue;
      const m = /^data:image\/(png|jpe?g|gif|webp);base64,(.+)$/i.exec(el.src);
      if (!m) continue;
      const ext = m[1].toLowerCase() === 'png' ? 'png' : 'jpeg';
      const name = `image${media.length + 1}.${ext}`;
      media.push([`ppt/media/${name}`, Buffer.from(m[2], 'base64')]);
      el.rel = `rId${slideRels.length + 1}`;
      slideRels.push([el.rel, 'image', `../media/${name}`]);
    }
    files.push([`ppt/slides/slide${i + 1}.xml`, slideXml(sl, i)]);
    files.push([`ppt/slides/_rels/slide${i + 1}.xml.rels`, rels(slideRels)]);
  });
  const ct = `${XML}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpeg" ContentType="image/jpeg"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>${slides.map((_, i) => `<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`).join('')}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`;
  const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  const pres = `${XML}<p:presentation ${NS} saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>${slides.map((_, i) => `<p:sldId id="${256 + i}" r:id="rId${i + 3}"/>`).join('')}</p:sldIdLst><p:sldSz cx="12192000" cy="6858000"/><p:notesSz cx="6858000" cy="9144000"/><p:defaultTextStyle><a:lvl1pPr><a:defRPr lang="de-DE"/></a:lvl1pPr></p:defaultTextStyle></p:presentation>`;
  return zip([
    ['[Content_Types].xml', ct],
    ['_rels/.rels', rels([['rId1', 'officeDocument', 'ppt/presentation.xml'], ['rId2', 'metadata/core-properties', 'docProps/core.xml'], ['rId3', 'extended-properties', 'docProps/app.xml']]).replace('http://schemas.openxmlformats.org/officeDocument/2006/relationships/metadata/core-properties', 'http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties')],
    ['docProps/core.xml', `${XML}<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${x(model.title || 'Präsentation')}</dc:title><dc:creator>Showtime (Revulution Hub)</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified></cp:coreProperties>`],
    ['docProps/app.xml', `${XML}<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Showtime</Application><Slides>${slides.length}</Slides></Properties>`],
    ['ppt/presentation.xml', pres],
    ['ppt/_rels/presentation.xml.rels', rels([['rId1', 'slideMaster', 'slideMasters/slideMaster1.xml'], ['rId2', 'theme', 'theme/theme1.xml'], ...slides.map((_, i) => [`rId${i + 3}`, 'slide', `slides/slide${i + 1}.xml`])])],
    ['ppt/slideMasters/slideMaster1.xml', MASTER],
    ['ppt/slideMasters/_rels/slideMaster1.xml.rels', rels([['rId1', 'slideLayout', '../slideLayouts/slideLayout1.xml'], ['rId2', 'theme', '../theme/theme1.xml']])],
    ['ppt/slideLayouts/slideLayout1.xml', LAYOUT],
    ['ppt/slideLayouts/_rels/slideLayout1.xml.rels', rels([['rId1', 'slideMaster', '../slideMasters/slideMaster1.xml']])],
    ['ppt/theme/theme1.xml', THEME],
    ...files,
    ...media,
  ]);
}

module.exports = { build };
