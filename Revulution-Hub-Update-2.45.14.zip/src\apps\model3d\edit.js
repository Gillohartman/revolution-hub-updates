'use strict';
/*
 * 3D-Modell – Netzbearbeitung: Punkte verschweissen, Flächenbereiche, Extrudieren,
 * Glätten (Unterteilen + Taubin-Glättung), Verjüngen / Verdrehen / Biegen.
 * Alle Funktionen arbeiten in lokalen Koordinaten und liefern neue, geschlossene Netze.
 */
(function () {
  const G = window.M3G;
  const cache = new WeakMap();

  // gleiche Positionen → ein Punkt. idx[ecke] = Punktnummer
  function weld(a) {
    let w = cache.get(a); if (w) return w;
    const ids = new Map(); const pos = []; const idx = new Uint32Array(a.length / 3);
    for (let i = 0; i < a.length; i += 3) {
      const k = `${Math.round(a[i] * 1e4)},${Math.round(a[i + 1] * 1e4)},${Math.round(a[i + 2] * 1e4)}`;
      let v = ids.get(k); if (v === undefined) { v = pos.length / 3; ids.set(k, v); pos.push(a[i], a[i + 1], a[i + 2]); }
      idx[i / 3] = v;
    }
    w = { pos: new Float32Array(pos), idx, count: pos.length / 3 };
    cache.set(a, w); return w;
  }
  const fromIndexed = (pos, tris) => { const r = new Float32Array(tris.length * 9); tris.forEach((t, i) => { for (let k = 0; k < 3; k += 1) { r[i * 9 + k * 3] = pos[t[k] * 3]; r[i * 9 + k * 3 + 1] = pos[t[k] * 3 + 1]; r[i * 9 + k * 3 + 2] = pos[t[k] * 3 + 2]; } }); return r; };
  const toTris = (w) => { const t = []; for (let i = 0; i < w.idx.length; i += 3) t.push([w.idx[i], w.idx[i + 1], w.idx[i + 2]]); return t; };

  // Punkte verschieben: sel = Set von Punktnummern, d = lokaler Versatz
  function moveVerts(a, sel, d) {
    const w = weld(a); const r = new Float32Array(a);
    for (let c = 0; c < w.idx.length; c += 1) if (sel.has(w.idx[c])) { r[c * 3] += d[0]; r[c * 3 + 1] += d[1]; r[c * 3 + 2] += d[2]; }
    return r;
  }
  // zusammenhängende, ebene Fläche um Dreieck t (gleiche Normale)
  function flatRegion(a, t, deg = 2) {
    const w = weld(a); const tris = toTris(w); const n0 = G.normal(a, t * 9); const cos = Math.cos((deg * Math.PI) / 180);
    const byEdge = new Map(); tris.forEach((q, i) => { for (let k = 0; k < 3; k += 1) { const p = q[k], s = q[(k + 1) % 3]; const e = p < s ? `${p}_${s}` : `${s}_${p}`; (byEdge.get(e) || byEdge.set(e, []).get(e)).push(i); } });
    const seen = new Set([t]); const st = [t];
    while (st.length) {
      const i = st.pop(); const q = tris[i];
      for (let k = 0; k < 3; k += 1) { const p = q[k], s = q[(k + 1) % 3]; const e = p < s ? `${p}_${s}` : `${s}_${p}`; for (const j of byEdge.get(e)) { if (seen.has(j)) continue; const n = G.normal(a, j * 9); if (n[0] * n0[0] + n[1] * n0[1] + n[2] * n0[2] >= cos) { seen.add(j); st.push(j); } } }
    }
    const verts = new Set(); for (const i of seen) for (const v of tris[i]) verts.add(v);
    return { tris: seen, verts, normal: n0 };
  }
  // Dreiecke, deren drei Punkte gewählt sind, und ihre mittlere Normale
  function regionOf(a, sel) {
    const w = weld(a); const out = []; const n = [0, 0, 0];
    for (let i = 0; i < w.idx.length; i += 3) if (sel.has(w.idx[i]) && sel.has(w.idx[i + 1]) && sel.has(w.idx[i + 2])) {
      out.push(i / 3); const o = i * 3; const ux = a[o + 3] - a[o], uy = a[o + 4] - a[o + 1], uz = a[o + 5] - a[o + 2], vx = a[o + 6] - a[o], vy = a[o + 7] - a[o + 1], vz = a[o + 8] - a[o + 2];
      n[0] += uy * vz - uz * vy; n[1] += uz * vx - ux * vz; n[2] += ux * vy - uy * vx;
    }
    const l = Math.hypot(...n) || 1;
    return { tris: out, normal: n.map((v) => v / l) };
  }
  // Fläche extrudieren: neue Punkte um dist entlang der Normalen, Seitenwände an der Randkante
  function extrude(a, sel, dist) {
    const w = weld(a); const { tris: R, normal } = regionOf(a, sel);
    if (!R.length) return null;
    const tris = toTris(w); const pos = Array.from(w.pos); const inR = new Set(R);
    const dir = new Set(); for (const i of R) { const q = tris[i]; for (let k = 0; k < 3; k += 1) dir.add(`${q[k]}_${q[(k + 1) % 3]}`); }
    const dup = new Map(); const nv = (v) => { let d = dup.get(v); if (d === undefined) { d = pos.length / 3; dup.set(v, d); pos.push(pos[v * 3] + normal[0] * dist, pos[v * 3 + 1] + normal[1] * dist, pos[v * 3 + 2] + normal[2] * dist); } return d; };
    const out = [];
    tris.forEach((q, i) => {
      if (!inR.has(i)) { out.push(q); return; }
      for (let k = 0; k < 3; k += 1) { const p = q[k], s = q[(k + 1) % 3]; if (!dir.has(`${s}_${p}`)) { out.push([p, s, nv(s)]); out.push([p, nv(s), nv(p)]); } }
      out.push([nv(q[0]), nv(q[1]), nv(q[2])]);
    });
    const mesh = fromIndexed(pos, out);
    const w2 = weld(mesh); const key = (Q, v) => `${Math.round(Q[v * 3] * 1e4)},${Math.round(Q[v * 3 + 1] * 1e4)},${Math.round(Q[v * 3 + 2] * 1e4)}`;
    const look = new Map(); for (let v = 0; v < w2.count; v += 1) look.set(key(w2.pos, v), v);
    const P = new Float32Array(pos); const newSel = new Set(); for (const d of dup.values()) { const v = look.get(key(P, d)); if (v !== undefined) newSel.add(v); }
    return { mesh, sel: newSel };
  }
  // jedes Dreieck in vier (Kantenmitten geteilt, rissfrei)
  function subdivide(a) {
    const w = weld(a); const pos = Array.from(w.pos); const mid = new Map();
    const m = (p, q) => { const k = p < q ? `${p}_${q}` : `${q}_${p}`; let v = mid.get(k); if (v === undefined) { v = pos.length / 3; mid.set(k, v); pos.push((pos[p * 3] + pos[q * 3]) / 2, (pos[p * 3 + 1] + pos[q * 3 + 1]) / 2, (pos[p * 3 + 2] + pos[q * 3 + 2]) / 2); } return v; };
    const out = [];
    for (const [x, y, z] of toTris(w)) { const a1 = m(x, y), b1 = m(y, z), c1 = m(z, x); out.push([x, a1, c1], [a1, y, b1], [c1, b1, z], [a1, b1, c1]); }
    return fromIndexed(pos, out);
  }
  // Glätten: unterteilen und Taubin-Glättung (schrumpft kaum), danach wieder auf z = 0
  function smooth(a, levels = 1, iters = 8) {
    let m = a; for (let i = 0; i < levels && m.length / 9 < 60000; i += 1) m = subdivide(m);
    const w = weld(m); const n = w.count; const P = Float64Array.from(w.pos);
    const nb = Array.from({ length: n }, () => new Set());
    for (const [x, y, z] of toTris(w)) { nb[x].add(y).add(z); nb[y].add(x).add(z); nb[z].add(x).add(y); }
    const step = (f) => { const Q = new Float64Array(P); for (let v = 0; v < n; v += 1) { let sx = 0, sy = 0, sz = 0; for (const u of nb[v]) { sx += P[u * 3]; sy += P[u * 3 + 1]; sz += P[u * 3 + 2]; } const c = nb[v].size || 1; Q[v * 3] += f * (sx / c - P[v * 3]); Q[v * 3 + 1] += f * (sy / c - P[v * 3 + 1]); Q[v * 3 + 2] += f * (sz / c - P[v * 3 + 2]); } P.set(Q); };
    for (let i = 0; i < iters; i += 1) { step(0.5); step(-0.53); }
    return G.center(fromIndexed(P, toTris(w)));
  }
  // in waagrechte Scheiben schneiden (für weiche Verformung), rissfrei
  function sliceZ(a, layers) {
    const bb = G.bbox(a); const z0 = bb.min[2], h = bb.max[2] - z0; if (h <= 1e-6) return a;
    const dz = h / layers; const out = [];
    const clip = (poly, z, keepAbove) => { const r = []; for (let i = 0; i < poly.length; i += 1) { const p = poly[i], q = poly[(i + 1) % poly.length]; const pi = keepAbove ? p[2] >= z : p[2] <= z, qi = keepAbove ? q[2] >= z : q[2] <= z; if (pi) r.push(p); if (pi !== qi) { const t = (z - p[2]) / (q[2] - p[2]); r.push([p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, z]); } } return r; };
    for (let i = 0; i < a.length; i += 9) {
      const tri = [[a[i], a[i + 1], a[i + 2]], [a[i + 3], a[i + 4], a[i + 5]], [a[i + 6], a[i + 7], a[i + 8]]];
      const lo = Math.min(tri[0][2], tri[1][2], tri[2][2]), hi = Math.max(tri[0][2], tri[1][2], tri[2][2]);
      const k0 = Math.max(0, Math.floor((lo - z0) / dz - 1e-9)), k1 = Math.min(layers - 1, Math.ceil((hi - z0) / dz + 1e-9) - 1);
      if (k1 <= k0) { out.push(...tri.flat()); continue; }
      for (let k = k0; k <= k1; k += 1) {
        let poly = tri; if (k > 0) poly = clip(poly, z0 + k * dz, true); if (poly.length >= 3 && k < layers - 1) poly = clip(poly, z0 + (k + 1) * dz, false);
        for (let j = 1; j < poly.length - 1; j += 1) out.push(...poly[0], ...poly[j], ...poly[j + 1]);
      }
    }
    return G.fixTJunctions(new Float32Array(out));
  }
  // Verjüngen (Skalierung oben in %), Verdrehen (Grad über die Höhe), Biegen (Grad um die Y-Achse)
  function deform(a, { taper = 100, twist = 0, bend = 0 }, layers = 40) {
    taper = Math.max(1, taper);
    const m = sliceZ(a, layers); const bb = G.bbox(m); const z0 = bb.min[2], h = bb.max[2] - z0 || 1;
    const cx = (bb.min[0] + bb.max[0]) / 2, cy = (bb.min[1] + bb.max[1]) / 2; const r = new Float32Array(m.length);
    const bendRad = (bend * Math.PI) / 180; const Rb = Math.abs(bendRad) > 1e-4 ? h / bendRad : 0;
    for (let i = 0; i < m.length; i += 3) {
      const t = (m[i + 2] - z0) / h; let x = m[i] - cx, y = m[i + 1] - cy, z = m[i + 2] - z0;
      const s = 1 + (taper / 100 - 1) * t; x *= s; y *= s;
      const ang = (twist * Math.PI * t) / 180; const c = Math.cos(ang), sn = Math.sin(ang); [x, y] = [x * c - y * sn, x * sn + y * c];
      if (Rb) { const th = z / Rb; const rr = Rb - x; x = Rb - rr * Math.cos(th); z = rr * Math.sin(th); }
      r[i] = x + cx; r[i + 1] = y + cy; r[i + 2] = z + z0;
    }
    return G.center(r);
  }

  window.M3E = { weld, moveVerts, flatRegion, regionOf, extrude, subdivide, smooth, sliceZ, deform };
})();
