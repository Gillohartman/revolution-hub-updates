'use strict';

/**
 * Preload wrapper for every module window/view inside Revolution Hub.
 * It prefixes outgoing IPC channels with the module id (matching src/main/shim.js),
 * adds the hub's click sounds to the main views and then runs the module's own preload.
 */
const { ipcRenderer } = require('electron');
const path = require('path');

function arg(name) {
  const hit = process.argv.find((value) => value.startsWith(`--${name}=`));
  return hit ? hit.slice(name.length + 3) : '';
}

const moduleId = arg('hub-module');
const original = arg('hub-preload');
const isMainView = process.argv.includes('--hub-view');

// Captured before the prefixing below: hub channels are not module channels.
const hubInvoke = ipcRenderer.invoke.bind(ipcRenderer);
const hubSend = ipcRenderer.send.bind(ipcRenderer);

if (moduleId) {
  const prefix = `${moduleId}:`;
  for (const method of ['invoke', 'send', 'sendSync']) {
    const call = ipcRenderer[method].bind(ipcRenderer);
    ipcRenderer[method] = (channel, ...args) => call(prefix + channel, ...args);
  }
}

/* Kamera-Wächter (im Seitenkontext): merkt sich Kamera-Streams, damit der Hub sie auf
   Wunsch ausschalten kann – und schaltet sie selbst aus, wenn nichts sie mehr zeigt oder aufnimmt. */
try {
  require('electron').webFrame.executeJavaScript(`(() => {
    const md = navigator.mediaDevices;
    if (!md || window.__revCam) return;
    const live = new Set();
    let recs = 0;
    const orig = md.getUserMedia.bind(md);
    md.getUserMedia = async function (c) {
      const s = await orig(c);
      try { if (c && c.video && !(c.video.mandatory && c.video.mandatory.chromeMediaSource)) live.add(s); } catch (e) {}
      return s;
    };
    const MR = window.MediaRecorder;
    if (MR) {
      window.MediaRecorder = class extends MR {
        constructor(...a) { super(...a); this.addEventListener('start', () => recs++); this.addEventListener('stop', () => { recs = Math.max(0, recs - 1); }); }
      };
    }
    const tracks = () => { const out = []; for (const s of live) { const v = s.getVideoTracks().filter((t) => t.readyState === 'live'); if (!v.length) live.delete(s); out.push(...v); } return out; };
    const shown = () => [...document.querySelectorAll('video')].some((v) => v.srcObject && live.has(v.srcObject) && !v.paused && v.offsetParent !== null);
    let idle = 0;
    setInterval(() => {
      const ts = tracks();
      if (!ts.length || recs > 0 || (!document.hidden && shown())) { idle = 0; return; }
      idle += 5;
      if (idle >= 20) { ts.forEach((t) => t.stop()); idle = 0; }
    }, 5000);
    window.__revCam = { count: () => tracks().length, stop: () => { const ts = tracks(); ts.forEach((t) => t.stop()); return ts.length; } };
  })()`).catch(() => {});
} catch {
  /* ohne Wächter */
}

if (isMainView) {
  const { createClickSound } = require(path.join(__dirname, '..', 'shared', 'sound.js'));
  const sound = createClickSound();
  ipcRenderer.on('hub:appearance', (_event, appearance) => sound.configure({ enabled: appearance.sounds, volume: appearance.volume, style: appearance.clickSound, clip: appearance.clickClip, pack: appearance.clickPack }));
  window.addEventListener('DOMContentLoaded', () => {
    sound.attach(document);
    hubInvoke('hub-view:appearance').then((appearance) => sound.configure({ enabled: appearance.sounds, volume: appearance.volume, style: appearance.clickSound, clip: appearance.clickClip, pack: appearance.clickPack })).catch(() => {});
  });
}

if (original) require(original);
