'use strict';
/**
 * 3D-Modell – Hauptprozess: Dateidialoge, Schreiben (STL/OBJ/3MF/PNG/Projekt), Lesen, Entwurf.
 * Die ganze Geometrie läuft im Fenster (geo.js); hier wird nur gespeichert und geladen.
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { pathToFileURL } = require('url');
const { boot } = require('../shared/boot');

const ctx = boot('model3d', __dirname);
const { app, ipcMain, dialog } = ctx.electron;
const hub = ctx.hub;
const PAGE = pathToFileURL(path.join(__dirname, 'index.html')).href;

function fromPage(event) {
  const view = ctx.view;
  if (!(view && !view.isDestroyed() && event.sender === view.webContents && event.senderFrame?.url === PAGE)) throw new Error('Ungültige Anfrage.');
}

/* ----------------------------------------------------------------------- zip */
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n += 1) { let c = n; for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buf) >>> 0;
  let c = 0xffffffff; for (const b of buf) c = CRC[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0;
}
function zip(files) {
  const locals = [], centrals = []; let offset = 0;
  for (const [name, content] of Object.entries(files)) {
    const data = Buffer.from(content, 'utf8'); const comp = zlib.deflateRawSync(data); const nameBuf = Buffer.from(name, 'utf8'); const crc = crc32(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(8, 8);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nameBuf.length, 26);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(8, 10);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(comp.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nameBuf.length, 28); ch.writeUInt32LE(offset, 42);
    locals.push(lh, nameBuf, comp); centrals.push(ch, nameBuf);
    offset += lh.length + nameBuf.length + comp.length;
  }
  const cd = Buffer.concat(centrals); const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(centrals.length / 2, 8); end.writeUInt16LE(centrals.length / 2, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, end]);
}
// 3MF lesen: erste .model-Datei aus dem Archiv
function unzipModel(buf) {
  let eocd = -1; for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i -= 1) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Keine gültige 3MF-Datei.');
  const count = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  for (let i = 0; i < count; i += 1) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const method = buf.readUInt16LE(p + 10), size = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl);
    if (/\.model$/i.test(name)) {
      const start = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28);
      const data = buf.subarray(start, start + size);
      return (method === 8 ? zlib.inflateRawSync(data) : data).toString('utf8');
    }
    p += 46 + nl + xl + cl;
  }
  throw new Error('Die 3MF-Datei enthält kein Modell.');
}

/* -------------------------------------------------------------------- Dateien */
const FILTERS = {
  stl: { name: 'STL (3D-Druck)', extensions: ['stl'] },
  obj: { name: 'OBJ', extensions: ['obj'] },
  '3mf': { name: '3MF (3D-Druck)', extensions: ['3mf'] },
  png: { name: 'PNG-Bild', extensions: ['png'] },
  r3d: { name: '3D-Modell-Projekt', extensions: ['r3d'] },
};
let lastDir = null;
const startDir = () => lastDir || app.getPath('documents');
const safeName = (n) => String(n || '3D-Modell').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 80) || '3D-Modell';

ipcMain.handle('save', async (event, req) => {
  fromPage(event);
  const ext = String(req?.ext || '');
  if (!FILTERS[ext]) throw new Error('Unbekanntes Format.');
  const result = await dialog.showSaveDialog(hub.window, { title: ext === 'r3d' ? 'Projekt speichern' : `Als ${ext.toUpperCase()} exportieren`, defaultPath: path.join(startDir(), `${safeName(req.name)}.${ext}`), filters: [FILTERS[ext]] });
  if (result.canceled || !result.filePath) return null;
  let data;
  if (ext === '3mf') data = zip(req.zip || {});
  else if (req.bytes) data = Buffer.from(req.bytes);
  else if (req.base64) data = Buffer.from(String(req.base64), 'base64');
  else data = Buffer.from(String(req.text ?? ''), 'utf8');
  fs.writeFileSync(result.filePath, data);
  lastDir = path.dirname(result.filePath);
  return { file: result.filePath, name: path.basename(result.filePath), size: data.length };
});

ipcMain.handle('open', async (event, req) => {
  fromPage(event);
  const project = req?.kind === 'project';
  const result = await dialog.showOpenDialog(hub.window, {
    title: project ? 'Projekt öffnen' : 'Modell importieren',
    defaultPath: startDir(),
    properties: ['openFile'],
    filters: project ? [FILTERS.r3d] : [{ name: '3D-Modelle (STL, OBJ, 3MF)', extensions: ['stl', 'obj', '3mf'] }],
  });
  if (result.canceled || !result.filePaths[0]) return null;
  const file = result.filePaths[0];
  const stat = fs.statSync(file);
  if (stat.size > 300 * 1024 * 1024) throw new Error('Die Datei ist grösser als 300 MB.');
  lastDir = path.dirname(file);
  const ext = path.extname(file).slice(1).toLowerCase();
  const buf = fs.readFileSync(file);
  if (ext === '3mf') return { name: path.basename(file), ext, text: unzipModel(buf) };
  return { name: path.basename(file), ext, bytes: new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength) };
});

ipcMain.handle('unzip3mf', (event, bytes) => {
  fromPage(event);
  return unzipModel(Buffer.from(bytes));
});

const draftFile = () => path.join(app.getPath('userData'), 'model3d-entwurf.json');
ipcMain.handle('draft:save', (event, text) => {
  fromPage(event);
  if (typeof text !== 'string' || text.length > 150 * 1024 * 1024) return false;
  fs.mkdirSync(path.dirname(draftFile()), { recursive: true });
  fs.writeFileSync(`${draftFile()}.tmp`, text, 'utf8');
  fs.renameSync(`${draftFile()}.tmp`, draftFile());
  return true;
});
ipcMain.handle('draft:load', (event) => {
  fromPage(event);
  try { return fs.readFileSync(draftFile(), 'utf8'); } catch { return null; }
});

app.whenReady().then(() => {
  const view = ctx.view;
  if (!view) return;
  view.webContents.on('will-navigate', (event, url) => { if (url.split('#')[0] !== PAGE) event.preventDefault(); });
  view.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
});
