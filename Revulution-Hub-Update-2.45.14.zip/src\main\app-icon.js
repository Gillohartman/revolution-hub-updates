'use strict';
/**
 * Echtes Programm-Logo für Deck-Tasten (2.45.7), z. B. Epic Games Launcher statt eines Emojis.
 * Windows liefert für jeden Startmenü-Eintrag (shell:AppsFolder\<AppID>) das Symbol in 256 px –
 * für normale Programme und Store-Apps gleich. Ergebnis: PNG mit Transparenz als Data-URL, im Speicher zwischengespeichert.
 */
const { execFile } = require('child_process');

const CS = `
using System; using System.Drawing; using System.Drawing.Imaging; using System.IO; using System.Runtime.InteropServices;
public static class RevIcon {
  [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IShellItemImageFactory { [PreserveSig] int GetImage(SIZE size, int flags, out IntPtr phbm); }
  [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; public SIZE(int x, int y) { cx = x; cy = y; } }
  [StructLayout(LayoutKind.Sequential)] struct BITMAP { public int bmType, bmWidth, bmHeight, bmWidthBytes; public ushort bmPlanes, bmBitsPixel; public IntPtr bmBits; }
  [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
  static extern void SHCreateItemFromParsingName(string path, IntPtr pbc, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.Interface)] out IShellItemImageFactory item);
  [DllImport("gdi32.dll")] static extern int GetObject(IntPtr h, int size, out BITMAP bm);
  [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr h);
  public static string Get(string aumid, int px) {
    IShellItemImageFactory f;
    SHCreateItemFromParsingName("shell:AppsFolder\\\\" + aumid, IntPtr.Zero, typeof(IShellItemImageFactory).GUID, out f);
    IntPtr hbm;
    // 0x4 = SIIGBF_ICONONLY (kein Vorschaubild), 0x0 = grösste passende Grösse
    if (f.GetImage(new SIZE(px, px), 0x4, out hbm) != 0) return "";
    try {
      BITMAP bm; GetObject(hbm, Marshal.SizeOf(typeof(BITMAP)), out bm);
      if (bm.bmBits == IntPtr.Zero || bm.bmBitsPixel != 32) { using (var b = Image.FromHbitmap(hbm)) return Png(b); }
      // DIB mit Alpha (von unten nach oben gespeichert, vormultipliziert)
      using (var b = new Bitmap(bm.bmWidth, bm.bmHeight, PixelFormat.Format32bppPArgb)) {
        var data = b.LockBits(new Rectangle(0, 0, bm.bmWidth, bm.bmHeight), ImageLockMode.WriteOnly, PixelFormat.Format32bppPArgb);
        var row = new byte[bm.bmWidthBytes];
        for (int y = 0; y < bm.bmHeight; y++) {
          Marshal.Copy(new IntPtr(bm.bmBits.ToInt64() + (long)(bm.bmHeight - 1 - y) * bm.bmWidthBytes), row, 0, bm.bmWidthBytes);
          Marshal.Copy(row, 0, new IntPtr(data.Scan0.ToInt64() + (long)y * data.Stride), Math.Min(row.Length, data.Stride));
        }
        b.UnlockBits(data);
        return Png(b);
      }
    } finally { DeleteObject(hbm); }
  }
  static string Png(Image b) { using (var ms = new MemoryStream()) { b.Save(ms, ImageFormat.Png); return Convert.ToBase64String(ms.ToArray()); } }
}`;

const cache = new Map();
function appIcon(appId, size = 256) {
  const id = String(appId || '');
  if (!id || id.length > 400 || /['"\r\n`$]/.test(id)) return Promise.reject(new Error('Ungültiges Programm.'));
  if (cache.has(id)) return Promise.resolve(cache.get(id));
  const script = `$ErrorActionPreference='Stop'; Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'\n${CS}\n'@\n[Console]::Out.Write([RevIcon]::Get('${id}', ${Math.round(size)}))`;
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout: 20000, maxBuffer: 8 * 1024 * 1024 }, (err, out) => {
      const b64 = String(out || '').trim();
      const url = !err && /^[A-Za-z0-9+/=]{100,}$/.test(b64) ? `data:image/png;base64,${b64}` : null;
      if (url) cache.set(id, url);
      resolve(url);
    });
  });
}

module.exports = { appIcon };
