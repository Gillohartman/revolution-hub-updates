'use strict';

/*
 * 2.45 Tiefgang – Tiefsee-Quiz. Zu jeder Frage gibt es viele richtige Antworten; je seltener
 * deine Antwort, desto mehr Punkte (6 Stufen). 25 Sekunden pro Frage. Mit jedem Punkt taucht
 * der kleine Taucher tiefer. Modi: Daily Dive (7 Fragen, für alle gleich), Endlos (3 Leben),
 * Themenpakete und Mehrspieler in privaten Räumen (Echtzeit über RevNet, wie Schach/Geo).
 */
(() => {
  const A = window.RevApp;
  const D = window.DEEPDIVE_DATA;
  if (!A || !D) return;
  const { esc, norm, lev } = A;
  const ID = 'tool-deepdive';
  const TIME = 25;
  const TIERS = [
    { name: 'Plankton', pts: 10, color: '#7dd3fc', icon: '·' },
    { name: 'Krill', pts: 15, color: '#5eead4', icon: '❋' },
    { name: 'Schwarm', pts: 30, color: '#a3e635', icon: '≋' },
    { name: 'Rar', pts: 60, color: '#facc15', icon: '◆' },
    { name: 'Deep Cut', pts: 85, color: '#c084fc', icon: '✦' },
    { name: 'One in a Trillion', pts: 100, color: '#fb7185', icon: '✺' },
  ];
  const PACKS = [
    ['all', 'Alle Themen', '🌊'],
    ['geo', 'Geografie', '🗺️'],
    ['sport', 'Sport', '⚽'],
    ['film', 'Filme & TV', '🎬'],
    ['music', 'Musik', '🎵'],
    ['science', 'Wissenschaft', '🔬'],
    ['history', 'Geschichte', '🏛️'],
    ['animals', 'Tiere', '🐙'],
    ['gaming', 'Gaming', '🎮'],
    ['general', 'Allerlei', '🧺'],
  ];

  /* ------------------------------------------------------------ Fragen erzeugen */
  // 2.45.1: englische (und weitere) Schreibweisen werden überall mit akzeptiert
  const ALIAS = {};
  for (const pair of String(D.aliases || '').split(';')) {
    const [de, more] = pair.split('=');
    if (de && more) ALIAS[de.trim()] = more.split('|').map((x) => x.trim()).filter(Boolean);
  }
  const withAlias = (names) => {
    const out = [...names];
    for (const n of names) for (const a of ALIAS[n] || []) if (!out.includes(a)) out.push(a);
    return out;
  };
  const parse = (s) => String(s || '').split(';').map((e) => withAlias(e.split('|').map((x) => x.trim()).filter(Boolean))).filter((e) => e.length);
  const first = (names) => {
    const n = norm(names[0]);
    return n ? n[0].toUpperCase() : '';
  };
  const letters = (name) => name.replace(/[^A-Za-zÄÖÜäöüß]/g, '').length;
  function tierOf(i, n) {
    const p = n <= 1 ? 0 : i / (n - 1);
    return p < 0.12 ? 0 : p < 0.26 ? 1 : p < 0.46 ? 2 : p < 0.66 ? 3 : p < 0.9 ? 4 : 5;
  }
  const QS = [];
  function add(pack, q, entries, min = 4) {
    if (!entries || entries.length < min) return;
    const id = `${pack}-${QS.length}`;
    QS.push({ id, pack, q, answers: entries.map((names, i) => ({ names, tier: tierOf(i, entries.length) })) });
  }
  function byLetter(pack, entries, make, min = 4) {
    const groups = new Map();
    for (const e of entries) {
      const L = first(e);
      if (!/^[A-Z]$/.test(L)) continue;
      if (!groups.has(L)) groups.set(L, []);
      groups.get(L).push(e);
    }
    for (const [L, list] of [...groups].sort()) add(pack, make(L), list, min);
  }
  function byLength(pack, entries, make, min = 5) {
    const groups = new Map();
    for (const e of entries) {
      if (/[\s-]/.test(e[0])) continue;
      const n = letters(e[0]);
      if (!groups.has(n)) groups.set(n, []);
      groups.get(n).push(e);
    }
    for (const [n, list] of [...groups].sort((a, b) => a[0] - b[0])) add(pack, make(n), list, min);
  }
  function simple(pack, key, q, opts = {}) {
    const list = parse(D[key]);
    add(pack, q, list, opts.min || 4);
    if (opts.letter) byLetter(pack, list, opts.letter, opts.letterMin || 4);
    if (opts.len) byLength(pack, list, opts.len, opts.lenMin || 5);
    return list;
  }

  // Geografie
  const CONT = { EU: 'Europa', AS: 'Asien', AF: 'Afrika', NA: 'Nord- und Mittelamerika', SA: 'Südamerika', OC: 'Ozeanien' };
  const countries = D.countries.split(';').map((s) => s.trim()).filter(Boolean).map((row) => {
    const [n, c, cap] = row.split(':');
    return { names: withAlias(n.split('|')), cont: c, cap: withAlias((cap || '').split('|')) };
  });
  // Bekanntheit: Rang innerhalb des Kontinents → Mischung über alle Kontinente
  const contRank = (c) => countries.filter((x) => x.cont === c.cont).indexOf(c) / Math.max(1, countries.filter((x) => x.cont === c.cont).length);
  const allCountries = [...countries].sort((a, b) => contRank(a) - contRank(b));
  add('geo', 'Nenne ein Land der Erde', allCountries.map((c) => c.names));
  for (const [k, name] of Object.entries(CONT)) {
    add('geo', `Nenne ein Land in ${name}`, countries.filter((c) => c.cont === k).map((c) => c.names));
    add('geo', `Nenne eine Hauptstadt in ${name}`, countries.filter((c) => c.cont === k).map((c) => c.cap));
  }
  byLetter('geo', allCountries.map((c) => c.names), (L) => `Nenne ein Land, das mit „${L}“ beginnt`, 3);
  byLetter('geo', allCountries.map((c) => c.cap), (L) => `Nenne eine Hauptstadt, die mit „${L}“ beginnt`, 3);
  byLength('geo', allCountries.map((c) => c.names), (n) => `Nenne ein Land mit genau ${n} Buchstaben`, 4);
  for (const [k, name] of Object.entries(CONT)) byLetter('geo', countries.filter((c) => c.cont === k).map((c) => c.names), (L) => `Nenne ein Land in ${name}, das mit „${L}“ beginnt`, 4);
  for (const [suf, label] of [['land', '„-land“'], ['stan', '„-stan“'], ['ien', '„-ien“'], ['a', '„a“'], ['o', '„o“'], ['e', '„e“']]) add('geo', `Nenne ein Land, das auf ${label} endet`, allCountries.map((c) => c.names).filter((n) => norm(n[0]).endsWith(suf)));
  add('geo', 'Nenne ein Mitgliedsland der Europäischen Union', parse(D.eu));
  add('geo', 'Nenne ein Land ohne Zugang zum Meer', parse(D.landlocked));
  simple('geo', 'bundeslaender', 'Nenne ein deutsches Bundesland');
  simple('geo', 'kantone', 'Nenne einen Schweizer Kanton', { letter: (L) => `Nenne einen Schweizer Kanton mit „${L}“`, letterMin: 3 });
  simple('geo', 'usStates', 'Nenne einen US-Bundesstaat', { letter: (L) => `Nenne einen US-Bundesstaat, der mit „${L}“ beginnt`, letterMin: 3 });
  simple('geo', 'deCities', 'Nenne eine deutsche Großstadt', { letter: (L) => `Nenne eine deutsche Stadt, die mit „${L}“ beginnt` });
  simple('geo', 'rivers', 'Nenne einen Fluss in Deutschland', { letter: (L) => `Nenne einen deutschen Fluss mit „${L}“`, letterMin: 4 });
  simple('geo', 'alps', 'Nenne einen Berg in den Alpen');
  simple('geo', 'oceans', 'Nenne einen Ozean', { min: 4 });
  simple('geo', 'seas', 'Nenne ein Meer oder einen Meeresteil');
  simple('geo', 'deserts', 'Nenne eine Wüste');
  simple('geo', 'continents', 'Nenne einen Kontinent', { min: 5 });
  simple('geo', 'languagesEu', 'Nenne eine Amtssprache der EU');

  // Wissenschaft
  simple('science', 'elements', 'Nenne ein chemisches Element', { letter: (L) => `Nenne ein chemisches Element, das mit „${L}“ beginnt`, letterMin: 3, len: (n) => `Nenne ein chemisches Element mit genau ${n} Buchstaben` });
  simple('science', 'nobleGases', 'Nenne ein Edelgas');
  simple('science', 'planets', 'Nenne einen Planeten oder Zwergplaneten unseres Sonnensystems');
  simple('science', 'moons', 'Nenne einen Mond in unserem Sonnensystem');
  simple('science', 'bones', 'Nenne einen Knochen des menschlichen Körpers', { letter: (L) => `Nenne einen Knochen mit „${L}“`, letterMin: 4 });
  simple('science', 'organs', 'Nenne ein Organ des Menschen', { letter: (L) => `Nenne ein Organ, das mit „${L}“ beginnt`, letterMin: 3 });
  simple('science', 'constellations', 'Nenne ein Sternbild', { letter: (L) => `Nenne ein Sternbild mit „${L}“`, letterMin: 4 });
  simple('science', 'siUnits', 'Nenne eine physikalische SI-Einheit');
  simple('science', 'scientists', 'Nenne einen berühmten Wissenschaftler oder eine Wissenschaftlerin', { letter: (L) => `Nenne eine Forscherin/einen Forscher mit „${L}“` });
  simple('science', 'programming', 'Nenne eine Programmiersprache', { letter: (L) => `Nenne eine Programmiersprache mit „${L}“`, letterMin: 3 });

  // Tiere
  const mam = simple('animals', 'mammals', 'Nenne ein Säugetier', { letter: (L) => `Nenne ein Säugetier, das mit „${L}“ beginnt`, len: (n) => `Nenne ein Säugetier mit genau ${n} Buchstaben` });
  const bir = simple('animals', 'birds', 'Nenne eine Vogelart', { letter: (L) => `Nenne einen Vogel, der mit „${L}“ beginnt` });
  const fis = simple('animals', 'fish', 'Nenne einen Fisch', { letter: (L) => `Nenne einen Fisch mit „${L}“`, letterMin: 4 });
  simple('animals', 'seaLife', 'Nenne ein Tier, das im Meer lebt', { letter: (L) => `Nenne ein Meerestier mit „${L}“`, letterMin: 4 });
  const rep = simple('animals', 'reptiles', 'Nenne ein Reptil', { letter: (L) => `Nenne ein Reptil mit „${L}“`, letterMin: 3 });
  const ins = simple('animals', 'insects', 'Nenne ein Insekt', { letter: (L) => `Nenne ein Insekt mit „${L}“`, letterMin: 3 });
  const allAnimals = [];
  const seen = new Set();
  for (let i = 0; i < 120; i++) for (const list of [mam, bir, fis, rep, ins]) if (list[i] && !seen.has(norm(list[i][0]))) {
    seen.add(norm(list[i][0]));
    allAnimals.push(list[i]);
  }
  add('animals', 'Nenne irgendein Tier', allAnimals);
  byLetter('animals', allAnimals, (L) => `Nenne ein Tier, das mit „${L}“ beginnt`, 5);
  byLength('animals', allAnimals, (n) => `Nenne ein Tier mit genau ${n} Buchstaben`, 6);

  // Sport
  simple('sport', 'sports', 'Nenne eine Sportart', { letter: (L) => `Nenne eine Sportart, die mit „${L}“ beginnt`, letterMin: 3 });
  simple('sport', 'winterSports', 'Nenne eine Wintersportart');
  simple('sport', 'bundesliga', 'Nenne einen (ehemaligen) Bundesliga-Club', { letter: (L) => `Nenne einen deutschen Fussballclub mit „${L}“` });
  simple('sport', 'premier', 'Nenne einen englischen Fussballclub', { letter: (L) => `Nenne einen englischen Club mit „${L}“`, letterMin: 3 });
  simple('sport', 'laliga', 'Nenne einen spanischen Fussballclub');
  simple('sport', 'seriea', 'Nenne einen italienischen Fussballclub');
  simple('sport', 'worldChampions', 'Nenne einen Fussball-Weltmeister (Land)');
  simple('sport', 'nba', 'Nenne ein NBA-Team', { letter: (L) => `Nenne ein NBA-Team aus einer Stadt mit „${L}“`, letterMin: 3 });
  simple('sport', 'f1Champions', 'Nenne einen Formel-1-Weltmeister');
  simple('sport', 'tennis', 'Nenne einen Grand-Slam-Sieger im Herren-Tennis');

  // Musik
  simple('music', 'instruments', 'Nenne ein Musikinstrument', { letter: (L) => `Nenne ein Instrument, das mit „${L}“ beginnt` });
  simple('music', 'genres', 'Nenne ein Musikgenre', { letter: (L) => `Nenne ein Musikgenre mit „${L}“` });
  simple('music', 'beatles', 'Nenne einen Song der Beatles');
  simple('music', 'queen', 'Nenne einen Song von Queen');
  simple('music', 'mj', 'Nenne einen Song von Michael Jackson');
  simple('music', 'taylor', 'Nenne einen Song von Taylor Swift');
  simple('music', 'rappersDe', 'Nenne einen deutschsprachigen Rapper oder eine Rapperin', { letter: (L) => `Nenne einen Deutschrapper mit „${L}“` });
  simple('music', 'eurovision', 'Nenne ein Land, das den Eurovision Song Contest gewonnen hat');
  simple('music', 'dances', 'Nenne einen Tanz', { letter: (L) => `Nenne einen Tanz mit „${L}“` });

  // Filme & TV
  simple('film', 'marvel', 'Nenne einen Film aus dem Marvel Cinematic Universe');
  simple('film', 'pixar', 'Nenne einen Pixar-Film');
  simple('film', 'disney', 'Nenne einen Disney-Zeichentrickfilm', { letter: (L) => `Nenne einen Disney-Film mit „${L}“` });
  simple('film', 'hp', 'Nenne eine Figur aus Harry Potter', { letter: (L) => `Nenne eine Harry-Potter-Figur mit „${L}“` });
  simple('film', 'starwars', 'Nenne eine Figur aus Star Wars', { letter: (L) => `Nenne eine Star-Wars-Figur mit „${L}“` });
  simple('film', 'simpsons', 'Nenne eine Figur aus den Simpsons', { letter: (L) => `Nenne eine Simpsons-Figur mit „${L}“` });
  simple('film', 'netflix', 'Nenne eine Netflix-Serie', { letter: (L) => `Nenne eine Netflix-Serie mit „${L}“` });
  simple('film', 'superheroes', 'Nenne einen Superhelden oder eine Superheldin', { letter: (L) => `Nenne einen Superhelden mit „${L}“` });

  // Geschichte
  simple('history', 'presidents', 'Nenne einen US-Präsidenten', { letter: (L) => `Nenne einen US-Präsidenten mit „${L}“`, letterMin: 3 });
  simple('history', 'chancellors', 'Nenne einen deutschen Bundeskanzler oder eine Bundeskanzlerin');
  simple('history', 'romans', 'Nenne einen römischen Kaiser', { letter: (L) => `Nenne einen römischen Kaiser mit „${L}“`, letterMin: 3 });
  simple('history', 'pharaohs', 'Nenne einen ägyptischen Pharao');
  simple('history', 'wonders', 'Nenne eines der sieben Weltwunder der Antike', { min: 6 });
  simple('history', 'newWonders', 'Nenne eines der neuen sieben Weltwunder', { min: 6 });
  simple('history', 'philosophers', 'Nenne einen Philosophen oder eine Philosophin', { letter: (L) => `Nenne einen Philosophen mit „${L}“` });
  simple('history', 'inventors', 'Nenne einen Erfinder oder eine Erfinderin', { letter: (L) => `Nenne eine Erfinderin/einen Erfinder mit „${L}“`, letterMin: 3 });

  // Gaming
  const popular = parse(D.pokemonPopular).map((e) => e[0]);
  const pkm = D.pokemon.split(';').map((s) => s.split(':')).filter((x) => x[0]).map(([n, t], i) => ({ n: n.trim(), types: (t || '').split('/'), rank: popular.includes(n.trim()) ? popular.indexOf(n.trim()) : 50 + i }));
  pkm.sort((a, b) => a.rank - b.rank);
  add('gaming', 'Nenne ein Pokémon der ersten Generation', pkm.map((p) => [p.n]));
  const TYPE = { pflanze: 'Pflanze', feuer: 'Feuer', wasser: 'Wasser', käfer: 'Käfer', normal: 'Normal', flug: 'Flug', gift: 'Gift', elektro: 'Elektro', boden: 'Boden', fee: 'Fee', kampf: 'Kampf', psycho: 'Psycho', gestein: 'Gestein', geist: 'Geist', eis: 'Eis', drache: 'Drache', stahl: 'Stahl' };
  for (const [t, label] of Object.entries(TYPE)) add('gaming', `Nenne ein Pokémon (1. Gen.) vom Typ ${label}`, pkm.filter((p) => p.types.includes(t)).map((p) => [p.n]), 3);
  byLetter('gaming', pkm.map((p) => [p.n]), (L) => `Nenne ein Pokémon (1. Gen.), das mit „${L}“ beginnt`, 3);
  simple('gaming', 'consoles', 'Nenne eine Spielkonsole', { letter: (L) => `Nenne eine Konsole mit „${L}“`, letterMin: 3 });
  simple('gaming', 'mario', 'Nenne eine Figur aus dem Mario-Universum', { letter: (L) => `Nenne eine Mario-Figur mit „${L}“`, letterMin: 3 });
  simple('gaming', 'zelda', 'Nenne ein Spiel der Zelda-Reihe');
  simple('gaming', 'gta', 'Nenne ein Spiel der GTA-Reihe');
  simple('gaming', 'minecraft', 'Nenne einen Mob aus Minecraft', { letter: (L) => `Nenne einen Minecraft-Mob mit „${L}“` });
  simple('gaming', 'studios', 'Nenne ein Videospiel-Studio oder einen Publisher', { letter: (L) => `Nenne ein Spielestudio mit „${L}“`, letterMin: 3 });

  // Allerlei
  simple('general', 'fruits', 'Nenne eine Obstsorte', { letter: (L) => `Nenne eine Frucht, die mit „${L}“ beginnt`, letterMin: 3 });
  simple('general', 'vegetables', 'Nenne ein Gemüse', { letter: (L) => `Nenne ein Gemüse mit „${L}“`, letterMin: 3 });
  simple('general', 'colors', 'Nenne eine Farbe', { letter: (L) => `Nenne eine Farbe mit „${L}“`, letterMin: 3 });
  simple('general', 'carBrands', 'Nenne eine Automarke', { letter: (L) => `Nenne eine Automarke, die mit „${L}“ beginnt`, letterMin: 3 });
  simple('general', 'carBrandsDe', 'Nenne eine deutsche Automarke (auch historisch)');
  simple('general', 'apps', 'Nenne ein soziales Netzwerk oder eine Messenger-App');
  simple('general', 'pizzas', 'Nenne eine Pizza-Sorte');
  simple('general', 'cheese', 'Nenne eine Käsesorte', { letter: (L) => `Nenne einen Käse mit „${L}“`, letterMin: 3 });
  simple('general', 'pasta', 'Nenne eine Nudelsorte', { letter: (L) => `Nenne eine Nudelsorte mit „${L}“`, letterMin: 3 });
  simple('general', 'flowers', 'Nenne eine Blume', { letter: (L) => `Nenne eine Blume mit „${L}“` });
  simple('general', 'trees', 'Nenne eine Baumart', { letter: (L) => `Nenne einen Baum mit „${L}“`, letterMin: 3 });
  simple('general', 'spices', 'Nenne ein Gewürz oder Küchenkraut', { letter: (L) => `Nenne ein Gewürz mit „${L}“` });
  simple('general', 'boardGames', 'Nenne ein Brettspiel oder Gesellschaftsspiel', { letter: (L) => `Nenne ein Gesellschaftsspiel mit „${L}“` });
  simple('general', 'cardGames', 'Nenne ein Kartenspiel', { letter: (L) => `Nenne ein Kartenspiel mit „${L}“`, letterMin: 3 });
  simple('general', 'weekdays', 'Nenne einen Wochentag', { min: 7 });
  simple('general', 'zodiac', 'Nenne ein Sternzeichen');
  simple('general', 'chessPieces', 'Nenne eine Schachfigur');
  simple('general', 'months31', 'Nenne einen Monat mit 31 Tagen');

  const POOL = (pack) => (pack === 'all' ? QS : QS.filter((q) => q.pack === pack));

  /* ------------------------------------------------------------ Antwort prüfen */
  const indexCache = new Map();
  function check(q, input) {
    const n = norm(input);
    if (!n) return null;
    let idx = indexCache.get(q.id);
    if (!idx) {
      idx = [];
      q.answers.forEach((a, i) => a.names.forEach((name) => idx.push([norm(name), i])));
      indexCache.set(q.id, idx);
    }
    const exact = idx.find(([k]) => k === n);
    if (exact) return { ...q.answers[exact[1]], i: exact[1] };
    // 2.45.1: Teiltreffer („Republik Kongo“ ↔ „Kongo“, „Stadt Bern“ ↔ „Bern“)
    const part = idx.find(([k]) => k.length >= 4 && n.length >= 4 && (n.includes(k) || (k.includes(n) && n.length / k.length >= 0.6)));
    if (part) return { ...q.answers[part[1]], i: part[1] };
    // Tippfehler verzeihen: 1 Fehler ab 4 Buchstaben, 2 ab 8, 3 ab 13
    let best = null;
    for (const [k, i] of idx) {
      if (k.length < 4) continue;
      const tol = k.length >= 13 ? 3 : k.length >= 8 ? 2 : 1;
      if (Math.abs(k.length - n.length) > tol) continue;
      const d = lev(n, k);
      if (d <= tol && (!best || d < best.d)) best = { d, i };
    }
    return best ? { ...q.answers[best.i], i: best.i } : null;
  }

  /* ------------------------------------------------------------ Zustand */
  const st = {
    root: null, view: 'menu', mode: '', pack: 'all', qs: [], qi: 0, score: 0, lives: 3, left: TIME, timer: 0, answer: null, given: '', results: [],
    stats: null, loaded: false, mp: null, err: '',
  };
  const blankStats = () => ({ games: 0, answers: 0, tiers: [0, 0, 0, 0, 0, 0], best: { daily: 0, unlimited: 0, pack: 0, mp: 0 }, maxDepth: 0, daily: null, streak: 0 });
  async function loadStats() {
    if (st.loaded) return;
    st.loaded = true;
    const s = await A.store.get('deepdive', null, true);
    st.stats = { ...blankStats(), ...(s && typeof s === 'object' ? s : {}) };
    st.stats.best = { ...blankStats().best, ...(st.stats.best || {}) };
  }
  const saveStats = () => A.store.set('deepdive', st.stats, true);
  const depthOf = (pts) => Math.round(pts * 2.2);
  const ZONES = [[0, 'Sonnenlichtzone'], [200, 'Dämmerzone'], [1000, 'Mitternachtszone'], [4000, 'Abyssal'], [6000, 'Hadal']];
  const zoneOf = (m) => [...ZONES].reverse().find(([d]) => m >= d)[1];

  function pick(pack, n, rnd = Math.random) {
    const pool = [...POOL(pack)];
    const out = [];
    while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
    return out;
  }
  function start(mode, pack = 'all', seed = null) {
    st.mode = mode;
    st.pack = pack;
    st.qi = 0;
    st.score = 0;
    st.lives = mode === 'unlimited' ? 3 : 0;
    st.results = [];
    if (mode === 'daily') st.qs = pick('all', 7, A.seeded(`deepdive-${A.today()}`));
    else if (mode === 'pack') st.qs = pick(pack, 10);
    else if (mode === 'mp') st.qs = pick(pack, st.mp.count, A.seeded(seed));
    else st.qs = pick(pack, 400);
    st.view = 'play';
    ask();
  }
  function ask() {
    st.answer = null;
    st.given = '';
    st.left = TIME;
    clearInterval(st.timer);
    const t0 = Date.now();
    st.timer = setInterval(() => {
      st.left = Math.max(0, TIME - (Date.now() - t0) / 1000);
      const bar = st.root?.querySelector('.dd-time i');
      if (bar) bar.style.transform = `scaleX(${st.left / TIME})`;
      const num = st.root?.querySelector('.dd-time b');
      if (num) num.textContent = Math.ceil(st.left);
      if (st.left <= 0) answer('');
    }, 100);
    paint();
    setTimeout(() => st.root?.querySelector('#dd-in')?.focus(), 30);
  }
  function answer(text) {
    if (st.answer) return;
    clearInterval(st.timer);
    const q = st.qs[st.qi];
    const hit = text ? check(q, text) : null;
    st.given = text;
    // Dieselbe Antwort zweimal in einer Runde zählt nicht nochmal
    const dup = hit && st.results.some((r) => r.q.id === q.id && r.hit?.i === hit.i);
    st.answer = { hit: dup ? null : hit, timeout: !text };
    const pts = st.answer.hit ? TIERS[hit.tier].pts : 0;
    st.score += pts;
    if (!st.answer.hit && st.mode === 'unlimited') st.lives -= 1;
    st.results.push({ q, hit: st.answer.hit, text, pts });
    if (st.answer.hit) {
      st.stats.answers += 1;
      st.stats.tiers[hit.tier] += 1;
    }
    if (st.mode === 'mp') st.mp.room?.send('ans', { i: st.qi, pts, tier: hit ? hit.tier : -1, text: String(text).slice(0, 40), score: st.score });
    if (st.mode === 'mp') {
      const me = st.mp.players.get('me');
      if (me) Object.assign(me, { score: st.score, done: st.qi, last: hit ? hit.tier : -1 });
    }
    paint();
    if (st.answer.hit && hit.tier >= 3) burst(hit.tier);
    if (st.mode === 'mp' && st.mp.host) mpMaybeReveal();
  }
  function next() {
    if (st.mode === 'mp') return;
    const over = (st.mode === 'unlimited' && st.lives <= 0) || st.qi + 1 >= st.qs.length;
    if (over) return finish();
    st.qi += 1;
    ask();
  }
  function finish() {
    clearInterval(st.timer);
    st.view = 'end';
    const s = st.stats;
    s.games += 1;
    const key = st.mode === 'pack' ? 'pack' : st.mode;
    s.best[key] = Math.max(s.best[key] || 0, st.score);
    s.maxDepth = Math.max(s.maxDepth || 0, depthOf(st.score));
    if (st.mode === 'daily') s.daily = { day: A.today(), score: st.score, tiers: st.results.map((r) => (r.hit ? r.hit.tier : -1)) };
    saveStats();
    A.earn(Math.min(100, Math.round(st.score / 10)));
    paint();
  }

  /* ------------------------------------------------------------ Mehrspieler (RevNet) */
  function mpCreate(host, code) {
    mpLeave();
    if (!window.RevNet) return A.toast('Mehrspieler ist gerade nicht verfügbar.', 'error');
    const mp = { host, code: code || window.RevNet.newCode(), room: null, players: new Map(), pack: 'all', count: 8, phase: 'lobby', qi: -1, revealTimer: 0, status: 'Verbinde …' };
    st.mp = mp;
    st.view = 'lobby';
    paint();
    A.me().then((me) => {
      mp.players.set('me', { name: me.name || 'Ich', score: 0, done: -1, last: -1, me: true });
      const room = new window.RevNet.Room({ app: 'deepdive', code: mp.code, name: me.name || 'Taucher' });
      mp.room = room;
      room.on('peer', (p) => {
        if (!mp.players.has(p.id)) mp.players.set(p.id, { name: p.name || 'Taucher', score: 0, done: -1, last: -1 });
        if (mp.host && mp.phase !== 'lobby') room.send('sync', { phase: mp.phase, seed: mp.seed, pack: mp.pack, count: mp.count, qi: mp.qi });
        paint();
      });
      room.on('left', (id) => {
        mp.players.delete(id);
        paint();
      });
      room.on('disconnect', () => {
        mp.status = 'Verbindung verloren.';
        paint();
      });
      room.on('msg', (m) => mpMsg(m));
      room.join().then(() => {
        mp.status = '';
        paint();
      }).catch((e) => {
        mp.status = `Keine Verbindung: ${A.errText(e)}`;
        paint();
      });
    });
  }
  function mpMsg(m) {
    const mp = st.mp;
    if (!mp) return;
    const p = mp.players.get(m.from) || { name: m.name || 'Taucher', score: 0, done: -1, last: -1 };
    mp.players.set(m.from, p);
    if ((m.t === 'start' || (m.t === 'sync' && mp.phase === 'lobby' && m.phase !== 'lobby')) && !mp.host) {
      Object.assign(mp, { seed: m.seed, pack: m.pack, count: m.count, phase: 'play' });
      for (const pl of mp.players.values()) Object.assign(pl, { score: 0, done: -1, last: -1 });
      start('mp', m.pack, m.seed);
      if (m.t === 'sync' && m.qi > 0) {
        st.qi = Math.min(m.qi, st.qs.length - 1);
        ask();
      }
    } else if (m.t === 'q' && !mp.host && st.mode === 'mp') {
      if (m.i !== st.qi) {
        st.qi = m.i;
        ask();
      }
    } else if (m.t === 'ans') {
      Object.assign(p, { score: Number(m.score) || 0, done: m.i, last: m.tier, text: m.text });
      paint();
      if (mp.host) mpMaybeReveal();
    } else if (m.t === 'end' && !mp.host) {
      mp.phase = 'end';
      finish();
    }
  }
  function mpStart() {
    const mp = st.mp;
    if (!mp?.host) return;
    mp.seed = `${mp.code}-${Date.now()}`;
    mp.phase = 'play';
    mp.qi = 0;
    for (const pl of mp.players.values()) Object.assign(pl, { score: 0, done: -1, last: -1 });
    mp.room?.send('start', { seed: mp.seed, pack: mp.pack, count: mp.count });
    start('mp', mp.pack, mp.seed);
    mpWatch();
  }
  // Host: wenn alle geantwortet haben oder die Zeit um ist → kurz zeigen, dann nächste Frage
  function mpWatch() {
    const mp = st.mp;
    clearTimeout(mp.revealTimer);
    mp.revealTimer = setTimeout(() => mpAdvance(), (TIME + 1.5) * 1000);
  }
  function mpMaybeReveal() {
    const mp = st.mp;
    if (!mp?.host) return;
    const all = [...mp.players.values()].every((p) => p.done >= st.qi);
    if (all) {
      clearTimeout(mp.revealTimer);
      mp.revealTimer = setTimeout(() => mpAdvance(), 4500);
    }
  }
  function mpAdvance() {
    const mp = st.mp;
    if (!mp?.host || st.mode !== 'mp') return;
    if (!st.answer) answer('');
    if (st.qi + 1 >= st.qs.length) {
      mp.phase = 'end';
      mp.room?.send('end', {});
      return finish();
    }
    st.qi += 1;
    mp.qi = st.qi;
    mp.room?.send('q', { i: st.qi });
    ask();
    mpWatch();
  }
  function mpLeave() {
    if (!st.mp) return;
    clearTimeout(st.mp.revealTimer);
    try {
      st.mp.room?.leave();
    } catch {
      /* egal */
    }
    st.mp = null;
  }

  /* ------------------------------------------------------------ Effekte */
  function burst(tier) {
    const sea = st.root?.querySelector('.dd-sea');
    if (!sea) return;
    const c = TIERS[tier].color;
    const n = tier === 5 ? 70 : tier === 4 ? 40 : 24;
    for (let i = 0; i < n; i++) {
      const p = document.createElement('i');
      p.className = 'dd-spark';
      const a = Math.random() * Math.PI * 2;
      const r = 80 + Math.random() * (tier === 5 ? 320 : 200);
      p.style.cssText = `--x:${Math.cos(a) * r}px;--y:${Math.sin(a) * r}px;--c:${c};--s:${4 + Math.random() * 7}px;animation-delay:${Math.random() * 120}ms`;
      sea.appendChild(p);
      setTimeout(() => p.remove(), 1400);
    }
    if (tier === 5) {
      const f = A.h(`<div class="dd-trillion"><b>ONE IN A TRILLION</b><span>+100</span></div>`);
      sea.appendChild(f);
      setTimeout(() => f.remove(), 2600);
    }
  }

  /* ------------------------------------------------------------ Darstellung */
  const DIVER = `<svg viewBox="0 0 64 64" class="dd-diver-svg" aria-hidden="true"><g fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M14 30c6-4 20-5 30 0" stroke="#fde047" stroke-width="7"/><circle cx="48" cy="28" r="8" fill="#1e293b" stroke="#fde047" stroke-width="3"/><circle cx="50" cy="27" r="4" fill="#38bdf8"/><path d="M18 26l-4-10h8" stroke="#94a3b8" stroke-width="3"/><path d="M14 31l-10 6M14 31l-9-2" stroke="#fde047" stroke-width="4"/><path d="M4 37l-3 4M5 29l-4-2" stroke="#0ea5e9" stroke-width="4"/><path d="M38 33l4 8" stroke="#fde047" stroke-width="4"/></g></svg>`;
  const FISH_BY_ZONE = [['🐠', '🐟', '🐡', '🐢'], ['🦑', '🐟', '🪼', '🐠'], ['🪼', '🦑', '🐙', '🦐'], ['🐙', '🦈', '🪼', '🐋'], ['🦐', '🐙', '🪼', '🦀']];
  function seaHtml(inner) {
    const m = depthOf(st.score);
    const z = ZONES.findIndex(([d], i) => m >= d && (!ZONES[i + 1] || m < ZONES[i + 1][0]));
    const fish = FISH_BY_ZONE[Math.max(0, z)];
    const dark = Math.min(1, m / 3000);
    const diverY = 12 + Math.min(70, (m / Math.max(300, (st.stats?.maxDepth || 0) + 300)) * 70);
    let fx = '';
    for (let i = 0; i < 6; i++) fx += `<span class="dd-fish" style="--t:${14 + i * 3}s;--y:${10 + i * 14}%;--dl:${-i * 2.7}s;--dir:${i % 2 ? -1 : 1}">${fish[i % fish.length]}</span>`;
    let bub = '';
    for (let i = 0; i < 14; i++) bub += `<i class="dd-bub" style="--x:${(i * 37) % 100}%;--t:${5 + (i % 5) * 1.4}s;--dl:${-i * 0.9}s;--s:${4 + (i % 4) * 3}px"></i>`;
    return `<div class="dd-sea" style="--dark:${dark}">
      <div class="dd-rays"></div>${bub}${fx}
      <div class="dd-diver" style="top:${diverY}%">${DIVER}</div>
      <div class="dd-gauge"><div class="dd-gauge-bar"><i style="height:${Math.min(100, (m / 6500) * 100)}%"></i></div><b>${m.toLocaleString('de-CH')} m</b><small>${zoneOf(m)}</small></div>
      <div class="dd-inner">${inner}</div>
    </div>`;
  }
  function menuHtml() {
    const s = st.stats;
    const dailyDone = s.daily?.day === A.today();
    const counts = Object.fromEntries(PACKS.map(([k]) => [k, POOL(k).length]));
    return seaHtml(`<div class="dd-menu">
      <div class="dd-title"><h2>Tiefgang</h2><p>Je seltener deine Antwort, desto tiefer tauchst du. ${QS.length.toLocaleString('de-CH')} Fragen · 25 Sekunden pro Frage.</p></div>
      <div class="dd-modes">
        <button class="dd-mode" data-dd="daily" ${dailyDone ? 'disabled' : ''}><span>🌅</span><b>Daily Dive</b><small>${dailyDone ? `Heute geschafft: ${s.daily.score} Punkte` : '7 Fragen – heute für alle gleich'}</small></button>
        <button class="dd-mode" data-dd="unlimited"><span>♾️</span><b>Endlos</b><small>Unbegrenzt mit 3 Leben · Rekord ${s.best.unlimited}</small></button>
        <button class="dd-mode" data-dd="mp-host"><span>🤿</span><b>Mehrspieler</b><small>Privater Raum mit Einladungscode</small></button>
      </div>
      <div class="dd-sec"><b>Themenpakete</b><small>10 Fragen aus einem Thema · Rekord ${s.best.pack}</small></div>
      <div class="dd-packs">${PACKS.slice(1).map(([k, n, e]) => `<button class="dd-pack" data-dd-pack="${k}"><span>${e}</span><b>${esc(n)}</b><small>${counts[k]} Fragen</small></button>`).join('')}</div>
      <div class="dd-join"><input class="rv-input" id="dd-code" maxlength="6" placeholder="Code eingeben" autocomplete="off" spellcheck="false"/><button class="rv-btn" data-dd="mp-join">Raum beitreten</button></div>
      <div class="dd-stats"><div><b>${s.games}</b><small>Spiele</small></div><div><b>${s.answers}</b><small>Treffer</small></div><div><b>${(s.maxDepth || 0).toLocaleString('de-CH')} m</b><small>Tiefster Tauchgang</small></div>${TIERS.map((t, i) => `<div title="${esc(t.name)}"><b style="color:${t.color}">${s.tiers[i] || 0}</b><small>${esc(t.name)}</small></div>`).join('')}</div>
    </div>`);
  }
  function sampleAnswers(q) {
    // Pro Stufe ein paar Beispiele zeigen (wie die Auflösung bei Quizshows)
    const out = [];
    for (let t = 0; t < 6; t++) {
      const list = q.answers.filter((a) => a.tier === t).slice(0, t < 2 ? 2 : 1);
      for (const a of list) out.push(a);
    }
    return out;
  }
  function playHtml() {
    const q = st.qs[st.qi];
    const a = st.answer;
    const tier = a?.hit ? TIERS[a.hit.tier] : null;
    const head = `<div class="dd-head">
      <span class="rv-pill">${st.mode === 'daily' ? 'Daily Dive' : st.mode === 'unlimited' ? 'Endlos' : st.mode === 'mp' ? `Raum ${esc(st.mp?.code || '')}` : esc(PACKS.find((p) => p[0] === st.pack)?.[1] || '')} · ${st.mode === 'unlimited' ? `Frage ${st.qi + 1}` : `${st.qi + 1}/${st.qs.length}`}</span>
      ${st.mode === 'unlimited' ? `<span class="dd-lives">${'❤️'.repeat(Math.max(0, st.lives))}${'🖤'.repeat(Math.max(0, 3 - st.lives))}</span>` : ''}
      <span class="rv-pill">◆ ${st.score}</span>
    </div>`;
    const board = st.mode === 'mp' ? `<div class="dd-board">${[...st.mp.players.values()].sort((x, y) => y.score - x.score).map((p) => `<div class="${p.me ? 'me' : ''}"><span>${esc(p.name)}</span>${p.done >= st.qi ? `<i style="background:${p.last >= 0 ? TIERS[p.last].color : '#64748b'}"></i>` : '<i class="wait"></i>'}<b>${p.score}</b></div>`).join('')}</div>` : '';
    if (!a) {
      return seaHtml(`${head}${board}<div class="dd-q"><small>${esc(PACKS.find((p) => p[0] === q.pack)?.[1] || '')}</small><h3>${esc(q.q)}</h3>
        <div class="dd-time"><i style="transform:scaleX(${st.left / TIME})"></i><b>${Math.ceil(st.left)}</b></div>
        <form class="dd-form" data-dd-form><input class="rv-input" id="dd-in" autocomplete="off" spellcheck="false" placeholder="Deine Antwort …" maxlength="60"/><button class="rv-btn primary">Abtauchen</button></form>
        <div class="dd-tiers">${TIERS.map((t) => `<span style="--c:${t.color}">${esc(t.name)} <b>${t.pts}</b></span>`).join('')}</div></div>`);
    }
    const res = a.hit
      ? `<div class="dd-res" style="--c:${tier.color}"><span class="dd-res-ic">${tier.icon}</span><div><small>${esc(tier.name)}</small><b>${esc(a.hit.names[0])}</b></div><em>+${tier.pts}</em></div>`
      : `<div class="dd-res miss"><span class="dd-res-ic">✕</span><div><small>${a.timeout ? 'Zeit abgelaufen' : 'Nicht in der Liste'}</small><b>${esc(st.given || '—')}</b></div><em>${st.mode === 'unlimited' ? '−1 ❤' : '0'}</em></div>`;
    // 2.45.1: dein Wort sinkt an den Tiefenlinien vorbei – je seltener, desto tiefer
    const sinkTo = a.hit ? 14 + a.hit.tier * 15 : 4;
    const sink = `<div class="dd-sink" style="--to:${sinkTo}%">${TIERS.map((t, i) => `<div class="dd-line ${a.hit && a.hit.tier >= i ? 'passed' : ''}" style="top:${14 + i * 15}%;--c:${t.color};--dl:${i * 180}ms"><span>${esc(t.name)}</span><em>${(i + 1) * 200} m</em></div>`).join('')}<span class="dd-sword ${a.hit ? '' : 'float'}" style="--c:${tier ? tier.color : '#94a3b8'}">${esc(a.hit ? a.hit.names[0] : st.given || '…')}<i></i><i></i><i></i></span></div>`;
    const samples = sampleAnswers(q).map((x) => `<span style="--c:${TIERS[x.tier].color}" class="${a.hit && a.hit.names[0] === x.names[0] ? 'mine' : ''}">${esc(x.names[0])}<i>${esc(TIERS[x.tier].name)}</i></span>`).join('');
    const nextBtn = st.mode === 'mp' ? `<p class="rv-muted" style="margin:12px 0 0;text-align:center">${st.mp.host ? 'Nächste Frage startet automatisch …' : 'Warte auf die anderen Taucher …'}</p>` : `<div class="rv-row" style="justify-content:center;margin-top:14px"><button class="rv-btn primary" data-dd="next">${(st.mode === 'unlimited' && st.lives <= 0) || st.qi + 1 >= st.qs.length ? 'Ergebnis' : 'Weiter'}</button></div>`;
    return seaHtml(`${head}${board}<div class="dd-q"><h3>${esc(q.q)}</h3>${res}${sink}<div class="dd-samples"><small>${q.answers.length} mögliche Antworten, zum Beispiel:</small><div>${samples}</div></div>${nextBtn}</div>`);
  }
  function endHtml() {
    const best = st.stats.best[st.mode === 'pack' ? 'pack' : st.mode] || 0;
    const rows = st.results.map((r) => `<div><span class="dd-dot" style="background:${r.hit ? TIERS[r.hit.tier].color : '#475569'}"></span><span class="rv-grow">${esc(r.q.q)}<small>${r.hit ? `${esc(r.hit.names[0])} · ${esc(TIERS[r.hit.tier].name)}` : r.text ? `„${esc(r.text)}“ – nicht gezählt` : 'keine Antwort'}</small></span><b>+${r.pts}</b></div>`).join('');
    const board = st.mode === 'mp' && st.mp ? `<div class="dd-final">${[...st.mp.players.values()].sort((x, y) => y.score - x.score).map((p, i) => `<div class="${p.me ? 'me' : ''}"><em>${i + 1}.</em><span>${esc(p.name)}</span><b>${p.score}</b></div>`).join('')}</div>` : '';
    return seaHtml(`<div class="dd-end"><small>Aufgetaucht aus</small><h2>${depthOf(st.score).toLocaleString('de-CH')} m</h2><p>${st.score} Punkte · ${zoneOf(depthOf(st.score))}${st.score >= best && st.score > 0 ? ' · Neuer Rekord!' : ` · Rekord ${best}`}</p>${board}<div class="dd-recap">${rows}</div>
      <div class="rv-row" style="justify-content:center;margin-top:14px">${st.mode === 'mp' ? (st.mp?.host ? '<button class="rv-btn primary" data-dd="mp-again">Neue Runde im Raum</button>' : '') : st.mode !== 'daily' ? `<button class="rv-btn primary" data-dd="again">Nochmal</button>` : ''}<button class="rv-btn" data-dd="share">Ergebnis kopieren</button><button class="rv-btn ghost" data-dd="menu">Menü</button></div></div>`);
  }
  function lobbyHtml() {
    const mp = st.mp;
    const players = [...mp.players.values()];
    return seaHtml(`<div class="dd-lobby"><small>Privater Raum</small><h2 class="dd-code">${esc(mp.code)}</h2>
      <p class="rv-muted">${mp.status ? esc(mp.status) : 'Teile den Code mit Freunden – sie geben ihn im Menü unter „Raum beitreten“ ein.'}</p>
      <div class="rv-row" style="justify-content:center"><button class="rv-btn sm" data-dd="copy">Einladung kopieren</button></div>
      <div class="dd-players">${players.map((p) => `<span class="${p.me ? 'me' : ''}">🤿 ${esc(p.name)}</span>`).join('') || '<span>…</span>'}</div>
      ${mp.host ? `<div class="dd-sec"><b>Thema</b></div><div class="dd-packs small">${PACKS.map(([k, n, e]) => `<button class="dd-pack ${mp.pack === k ? 'on' : ''}" data-dd-mppack="${k}"><span>${e}</span><b>${esc(n)}</b></button>`).join('')}</div>
        <div class="rv-row" style="justify-content:center;margin-top:10px"><span class="rv-muted">Fragen:</span>${[5, 8, 12].map((n) => `<button class="rv-btn sm ${mp.count === n ? 'on' : ''}" data-dd-count="${n}">${n}</button>`).join('')}</div>
        <div class="rv-row" style="justify-content:center;margin-top:14px"><button class="rv-btn primary" data-dd="mp-start" ${mp.room ? '' : 'disabled'}>Tauchgang starten (${players.length} ${players.length === 1 ? 'Spieler' : 'Spieler'})</button></div>`
        : '<p class="rv-muted" style="text-align:center">Warte, bis der Gastgeber startet …</p>'}
      <div class="rv-row" style="justify-content:center;margin-top:8px"><button class="rv-btn ghost" data-dd="menu">Raum verlassen</button></div></div>`);
  }
  function paint() {
    if (!st.root) return;
    const focus = document.activeElement?.id === 'dd-in' ? document.activeElement.value : null;
    st.root.innerHTML = st.view === 'menu' ? menuHtml() : st.view === 'lobby' ? lobbyHtml() : st.view === 'end' ? endHtml() : playHtml();
    if (focus !== null) {
      const el = st.root.querySelector('#dd-in');
      if (el) {
        el.value = focus;
        el.focus();
      }
    }
  }

  /* ------------------------------------------------------------ Eingaben */
  document.addEventListener('submit', (e) => {
    if (!st.root?.contains(e.target) || !e.target.matches('[data-dd-form]')) return;
    e.preventDefault();
    const v = st.root.querySelector('#dd-in')?.value || '';
    if (v.trim()) answer(v.trim());
  });
  document.addEventListener('click', (e) => {
    if (!st.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const pack = q('[data-dd-pack]')?.dataset.ddPack;
    if (pack) return start('pack', pack);
    const mpp = q('[data-dd-mppack]')?.dataset.ddMppack;
    if (mpp && st.mp) {
      st.mp.pack = mpp;
      return paint();
    }
    const cnt = q('[data-dd-count]')?.dataset.ddCount;
    if (cnt && st.mp) {
      st.mp.count = Number(cnt);
      return paint();
    }
    const a = q('[data-dd]')?.dataset.dd;
    if (!a) return;
    if (a === 'daily') return start('daily');
    if (a === 'unlimited') return start('unlimited', 'all');
    if (a === 'next') return next();
    if (a === 'again') return start(st.mode, st.pack);
    if (a === 'menu') {
      clearInterval(st.timer);
      mpLeave();
      st.view = 'menu';
      return paint();
    }
    if (a === 'mp-host') return mpCreate(true);
    if (a === 'mp-join') {
      const code = (st.root.querySelector('#dd-code')?.value || '').trim().toUpperCase();
      if (!/^[A-Z0-9]{4,8}$/.test(code)) return A.toast('Bitte den Raum-Code eingeben.', 'error');
      return mpCreate(false, code);
    }
    if (a === 'mp-start') return mpStart();
    if (a === 'mp-again') {
      st.view = 'lobby';
      st.mp.phase = 'lobby';
      return paint();
    }
    if (a === 'copy') {
      navigator.clipboard?.writeText(`Tauch mit mir in „Tiefgang“ im Revolution Hub! Raum-Code: ${st.mp.code}`).catch(() => {});
      return A.toast('Einladung kopiert – schick sie deinen Freunden.');
    }
    if (a === 'share') {
      const dots = st.results.map((r) => (r.hit ? ['🟦', '🟩', '🟢', '🟨', '🟪', '🟥'][r.hit.tier] : '⬛')).join('');
      navigator.clipboard?.writeText(`Tiefgang ${st.mode === 'daily' ? `Daily Dive ${A.today()}` : ''}\n${dots}\n${st.score} Punkte · ${depthOf(st.score)} m tief`).catch(() => {});
      return A.toast('Ergebnis kopiert.');
    }
  });

  A.define(
    ID,
    { nav: 'Tiefgang', title: 'Tiefgang', sub: 'Tiefsee-Quiz – je seltener, desto tiefer', icon: 'globe', tint: 'linear-gradient(135deg,#0ea5e9,#1e1b4b)', desc: 'Quiz mit vielen richtigen Antworten: Seltene Antworten bringen mehr Punkte und lassen deinen Taucher tiefer sinken. Daily Dive, Endlos, Themenpakete und Mehrspieler.' },
    {
      game: true,
      async mount(root) {
        st.root = root;
        await loadStats();
        if (st.root === root) paint();
      },
      unmount() {
        // Laufende Runde bleibt erhalten (Timer läuft weiter) – nur die Ansicht ist weg
        st.root = null;
      },
    },
  );
  window.DeepDive = { QS, check, TIERS };
})();
