'use strict';

/*
 * 2.45 Makro-Editor (für Tastatur und Maus): Ablauf aus Schritten mit frei wählbaren Abständen.
 * Schritte: { key, act: 'press'|'down'|'up' } · { click: 'left'|'right'|'middle'|'back'|'forward' } · { wait: ms }
 * Optional am Anfang { repeat: n }. Aufnahme misst die echten Abstände zwischen den Tasten.
 */
(() => {
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const CLICKS = [['left', 'Linksklick'], ['right', 'Rechtsklick'], ['middle', 'Mittelklick'], ['back', 'Maustaste Zurück'], ['forward', 'Maustaste Vor']];
  const keyName = (code) => {
    if (!code) return 'Taste wählen';
    let m;
    if ((m = /^Key([A-Z])$/.exec(code))) return code === 'KeyZ' ? 'Y' : code === 'KeyY' ? 'Z' : m[1];
    if ((m = /^Digit(\d)$/.exec(code))) return m[1];
    if ((m = /^Numpad(\d)$/.exec(code))) return `Num ${m[1]}`;
    const N = { Space: 'Leertaste', Enter: 'Enter', Escape: 'Esc', Backspace: '⌫', ShiftLeft: 'Shift', ShiftRight: 'Shift R', ControlLeft: 'Strg', ControlRight: 'Strg R', AltLeft: 'Alt', AltRight: 'AltGr', MetaLeft: 'Win', Tab: 'Tab', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', CapsLock: 'Feststell' };
    return N[code] || code;
  };

  function open({ steps = [], title = 'Makro bearbeiten', onSave }) {
    let list = JSON.parse(JSON.stringify(Array.isArray(steps) ? steps : []));
    let repeat = 1;
    if (list[0] && Number(list[0].repeat) > 1) repeat = Number(list.shift().repeat);
    let gap = 50;
    let capture = -1;
    let rec = null;
    const modal = document.createElement('div');
    modal.className = 'rv-modal me-modal';
    document.body.appendChild(modal);
    const total = () => list.reduce((s, x) => s + (Number(x.wait) || 0) + (x.key && x.act === 'press' ? 15 : 0) + (x.click ? 15 : 0), 0) * repeat;

    function stepHtml(s, i) {
      const kind = s.wait != null ? 'wait' : s.click ? 'click' : s.act === 'down' ? 'down' : s.act === 'up' ? 'up' : 'press';
      let val = '';
      if (kind === 'wait') val = `<input class="rv-input sm" type="number" min="1" max="60000" step="10" value="${Number(s.wait) || 0}" data-me-wait="${i}" style="width:100px"/> <span class="rv-muted">ms</span>`;
      else if (kind === 'click') val = `<select class="rv-input sm" data-me-click="${i}">${CLICKS.map(([v, n]) => `<option value="${v}" ${s.click === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
      else val = `<button class="rv-btn sm ${capture === i ? 'on' : ''}" data-me-cap="${i}">${capture === i ? 'Taste drücken …' : esc(keyName(s.key))}</button>`;
      return `<div class="me-step" data-i="${i}"><span class="me-n">${i + 1}</span>
        <select class="rv-input sm" data-me-kind="${i}">${[['press', 'Taste drücken'], ['down', 'Taste halten'], ['up', 'Taste loslassen'], ['click', 'Mausklick'], ['wait', 'Warten']].map(([v, n]) => `<option value="${v}" ${kind === v ? 'selected' : ''}>${n}</option>`).join('')}</select>
        <span class="me-val">${val}</span>
        <span class="me-tools"><button class="rv-btn sm ghost" data-me-up="${i}" ${i ? '' : 'disabled'}>↑</button><button class="rv-btn sm ghost" data-me-down="${i}" ${i < list.length - 1 ? '' : 'disabled'}>↓</button><button class="rv-btn sm ghost" data-me-del="${i}">✕</button></span></div>`;
    }
    function paint() {
      modal.innerHTML = `<div class="rv-card me">
        <div class="rv-row between"><b>${esc(title)}</b><span class="rv-pill">≈ ${(total() / 1000).toFixed(2).replace('.', ',')} s</span></div>
        <p class="rv-muted" style="font-size:12.5px;margin:6px 0 10px">Die Schritte laufen genau so ab, wie du sie hier festlegst – mit den Wartezeiten dazwischen. Ideal für Tastenabfolgen und Klickserien.</p>
        <div class="me-list">${list.length ? list.map(stepHtml).join('') : '<div class="rv-empty" style="padding:18px">Noch keine Schritte – füge welche hinzu oder nimm auf.</div>'}</div>
        <div class="rv-row" style="margin-top:10px"><button class="rv-btn sm" data-me-add="press">＋ Taste</button><button class="rv-btn sm" data-me-add="click">＋ Klick</button><button class="rv-btn sm" data-me-add="wait">＋ Warten</button>
          <button class="rv-btn sm ${rec ? 'danger' : ''}" data-me-rec>${rec ? `■ Aufnahme stoppen (${rec.steps.length})` : '● Aufnehmen'}</button></div>
        <div class="me-opts">
          <label>Abstand zwischen allen Schritten <input class="rv-input sm" type="number" min="0" max="10000" step="5" value="${gap}" data-me-gap style="width:90px"/> ms <button class="rv-btn sm" data-me-applygap>Überall einsetzen</button></label>
          <label>Wiederholen <input class="rv-input sm" type="number" min="1" max="500" value="${repeat}" data-me-repeat style="width:80px"/> ×</label>
        </div>
        ${rec ? '<p class="me-recinfo">Aufnahme läuft: Drück Tasten oder klick in dieses Feld – die echten Abstände werden als Wartezeiten gespeichert.</p><div class="me-recpad" data-me-pad>Hier klicken für Mausklicks</div>' : ''}
        <div class="rv-row end" style="margin-top:14px"><button class="rv-btn ghost" data-me-cancel>Abbrechen</button><button class="rv-btn primary" data-me-save>Speichern</button></div>
      </div>`;
    }
    const recordWait = () => {
      const now = performance.now();
      const dt = Math.round(now - rec.at);
      rec.at = now;
      if (rec.steps.length && dt > 5) rec.steps.push({ wait: dt });
    };
    function onKey(e) {
      if (capture >= 0 && e.type === 'keydown') {
        e.preventDefault();
        e.stopPropagation();
        list[capture].key = e.code;
        capture = -1;
        return paint();
      }
      if (!rec || e.repeat) return;
      if (/^(INPUT|SELECT)$/.test(e.target.tagName)) return;
      e.preventDefault();
      e.stopPropagation();
      recordWait();
      rec.steps.push({ key: e.code, act: e.type === 'keydown' ? 'down' : 'up' });
      paint();
    }
    function close() {
      document.removeEventListener('keydown', onKey, true);
      document.removeEventListener('keyup', onKey, true);
      modal.remove();
    }
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('keyup', onKey, true);
    modal.addEventListener('mousedown', (e) => {
      if (!rec || !e.target.closest('[data-me-pad]')) return;
      e.preventDefault();
      recordWait();
      rec.steps.push({ click: ['left', 'middle', 'right', 'back', 'forward'][e.button] || 'left' });
      paint();
    });
    modal.addEventListener('contextmenu', (e) => rec && e.target.closest('[data-me-pad]') && e.preventDefault());
    modal.addEventListener('click', (e) => {
      const q = (s) => e.target.closest(s);
      if (e.target === modal || q('[data-me-cancel]')) return close();
      if (q('[data-me-save]')) {
        const out = list.filter((s) => s.wait != null || s.click || s.key);
        onSave?.(repeat > 1 ? [{ repeat }, ...out] : out);
        return close();
      }
      const add = q('[data-me-add]')?.dataset.meAdd;
      if (add) {
        list.push(add === 'wait' ? { wait: gap || 50 } : add === 'click' ? { click: 'left' } : { key: '', act: 'press' });
        if (add === 'press') capture = list.length - 1;
        return paint();
      }
      if (q('[data-me-rec]')) {
        if (rec) {
          list = [...list, ...rec.steps];
          rec = null;
        } else rec = { steps: [], at: performance.now() };
        return paint();
      }
      const cap = q('[data-me-cap]')?.dataset.meCap;
      if (cap != null) {
        capture = capture === Number(cap) ? -1 : Number(cap);
        return paint();
      }
      const up = q('[data-me-up]')?.dataset.meUp;
      if (up != null) {
        const i = Number(up);
        [list[i - 1], list[i]] = [list[i], list[i - 1]];
        return paint();
      }
      const dn = q('[data-me-down]')?.dataset.meDown;
      if (dn != null) {
        const i = Number(dn);
        [list[i + 1], list[i]] = [list[i], list[i + 1]];
        return paint();
      }
      const del = q('[data-me-del]')?.dataset.meDel;
      if (del != null) {
        list.splice(Number(del), 1);
        return paint();
      }
      if (q('[data-me-applygap]')) {
        const actions = list.filter((s) => s.wait == null);
        list = [];
        actions.forEach((s, i) => {
          list.push(s);
          if (i < actions.length - 1 && gap > 0) list.push({ wait: gap });
        });
        return paint();
      }
    });
    modal.addEventListener('change', (e) => {
      const t = e.target;
      const kind = t.dataset.meKind;
      if (kind != null) {
        const i = Number(kind);
        list[i] = t.value === 'wait' ? { wait: gap || 50 } : t.value === 'click' ? { click: 'left' } : { key: list[i].key || '', act: t.value };
        return paint();
      }
      if (t.dataset.meWait != null) list[Number(t.dataset.meWait)].wait = Math.max(1, Math.min(60000, Number(t.value) || 1));
      if (t.dataset.meClick != null) list[Number(t.dataset.meClick)].click = t.value;
      if (t.matches('[data-me-gap]')) gap = Math.max(0, Math.min(10000, Number(t.value) || 0));
      if (t.matches('[data-me-repeat]')) repeat = Math.max(1, Math.min(500, Number(t.value) || 1));
      paint();
    });
    paint();
  }

  /** Kurzbeschreibung eines Makros für Listen. */
  function summary(steps) {
    const s = Array.isArray(steps) ? steps : [];
    const rep = s[0]?.repeat > 1 ? ` · ${s[0].repeat}×` : '';
    const acts = s.filter((x) => (x.key && x.act !== 'up') || x.click);
    const waits = s.reduce((t, x) => t + (Number(x.wait) || 0), 0);
    if (!acts.length) return 'Noch leer';
    return `${acts.slice(0, 6).map((x) => (x.click ? CLICKS.find((c) => c[0] === x.click)?.[1] || 'Klick' : keyName(x.key))).join(' · ')}${acts.length > 6 ? ' …' : ''}${waits ? ` · ${waits} ms Pausen` : ''}${rep}`;
  }

  window.RevMacroEditor = { open, summary, keyName };
})();
