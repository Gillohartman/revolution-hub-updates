'use strict';

/* Runde 11d – Autoclicker: „Klick zur Uhrzeit“.
   Zu einer festen Uhrzeit (z. B. 14:30:05) einmal an eine gewählte Stelle klicken und/oder Enter drücken –
   z. B. einen vorbereiteten KI-Prompt automatisch absenden. Wird von tools-extra.js im Autoclicker eingeblendet. */
(() => {
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const PAGE = 'tool-autoclick';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const KEYS = [['Enter', 'Enter'], ['Space', 'Leertaste'], ['Tab', 'Tab'], ['F5', 'F5'], ['Escape', 'Esc']];
  const load = () => {
    try {
      return { at: '', action: 'both', button: 'left', key: 'Enter', pos: null, ...JSON.parse(localStorage.getItem('rev-ac-timer') || '{}') };
    } catch {
      return { at: '', action: 'both', button: 'left', key: 'Enter', pos: null };
    }
  };
  const cfg = load();
  const st = { timer: null, picking: false, err: '' };
  const save = () => localStorage.setItem('rev-ac-timer', JSON.stringify(cfg));
  const pad = (n) => String(n).padStart(2, '0');
  const nowPlus = (sec) => {
    const d = new Date(Date.now() + sec * 1000);
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };
  function countdown(ms) {
    if (ms <= 0) return 'jetzt';
    const s = Math.ceil(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    return h ? `${h}:${pad(m)}:${pad(s % 60)}` : `${m}:${pad(s % 60)}`;
  }
  const actionText = (a, key) => (a === 'key' ? `${keyName(key)} drücken` : a === 'both' ? `klicken, dann ${keyName(key)}` : 'klicken');
  const keyName = (k) => KEYS.find((x) => x[0] === k)?.[1] || k;
  const seg = (name, val, opts) => `<div class="seg act-seg">${opts.map(([v, n]) => `<button class="${String(val) === v ? 'on' : ''}" data-act-set="${name}" data-v="${v}">${esc(n)}</button>`).join('')}</div>`;

  function html() {
    const t = st.timer;
    const pending = t?.pending;
    const needPos = cfg.action !== 'key';
    const head = pending
      ? `<div class="act-live"><small>Geplant für ${esc(t.at)} Uhr · ${esc(actionText(t.action, t.key))}${t.pos ? ` bei ${t.pos.x} × ${t.pos.y}` : ''}</small><b data-act-count>${countdown(t.target - Date.now())}</b></div><button class="btn act-cancel" data-act="cancel">Abbrechen</button>`
      : `<div class="act-live"><small>${t?.done ? `Zuletzt ausgeführt um ${new Date(t.done).toLocaleTimeString('de-CH')}` : t?.cancelled ? 'Abgebrochen.' : 'Bereit'}</small><b>${esc(cfg.at || '--:--:--')}</b></div><button class="btn primary act-go" data-act="start" ${cfg.at && (!needPos || cfg.pos) ? '' : 'disabled'}>Planen</button>`;
    return `<section class="tool-card act ${pending ? 'pending' : ''}">
      <div class="act-head"><div><span class="tool-label">Klick zur Uhrzeit</span><p class="muted">Einmal zu einer festen Uhrzeit klicken und/oder eine Taste drücken – z. B. einen vorbereiteten KI-Prompt pünktlich absenden.</p></div>${head}</div>
      <div class="act-grid">
        <div class="act-f"><label>Uhrzeit</label><div class="act-row"><input class="input act-time" type="time" step="1" data-act-time value="${esc(cfg.at)}" ${pending ? 'disabled' : ''} />
          ${[[60, '+1 min'], [300, '+5 min'], [1800, '+30 min']].map(([s, n]) => `<button class="chip" data-act-plus="${s}" ${pending ? 'disabled' : ''}>${n}</button>`).join('')}</div>
          <small class="muted">Heute – ist die Zeit schon vorbei, dann morgen.</small></div>
        <div class="act-f"><label>Was passiert</label>${seg('action', cfg.action, [['click', 'Klicken'], ['both', 'Klicken + Taste'], ['key', 'Nur Taste']])}</div>
        ${needPos ? `<div class="act-f"><label>Stelle</label><div class="act-row"><button class="btn" data-act="pick" ${pending || st.picking ? 'disabled' : ''}>${st.picking ? 'Klick auf die Stelle …' : cfg.pos ? 'Neu wählen' : 'Stelle per Klick wählen'}</button><span class="act-pos ${cfg.pos ? 'on' : ''}">${cfg.pos ? `${cfg.pos.x} × ${cfg.pos.y}` : 'noch keine'}</span></div>
          ${seg('button', cfg.button, [['left', 'Links'], ['right', 'Rechts']])}</div>` : ''}
        ${cfg.action !== 'click' ? `<div class="act-f"><label>Taste</label>${seg('key', cfg.key, KEYS)}<small class="muted">${cfg.action === 'key' ? 'Geht an das Fenster, das zu dem Zeitpunkt aktiv ist.' : 'Erst Klick ins Feld, kurz danach die Taste.'}</small></div>` : ''}
      </div>
      ${st.err ? `<p class="err">${esc(st.err)}</p>` : ''}
      <p class="muted act-tip">Tipp: Prompt im KI-Chat fertig schreiben, Stelle auf das Eingabefeld legen, „Klicken + Taste“ mit Enter – das Fenster darf im Hintergrund offen bleiben, der Hub muss laufen.</p>
    </section>`;
  }
  window.revAcTimer = { html };

  const rerender = () => window.HubTools?.ctx().render();
  const apply = (s) => {
    if (!s) return;
    const was = st.timer?.pending;
    st.timer = s.timer || null;
    if (was && st.timer && !st.timer.pending && st.timer.done) window.HubTools?.ctx().toast?.(`Klick zur Uhrzeit ausgeführt (${st.timer.at}).`);
  };
  window.hub?.autoclick?.status().then(apply).catch(() => {});
  window.hub?.onAutoclick?.((s) => {
    apply(s);
    if (active()) rerender();
  });
  setInterval(() => {
    const el = document.querySelector('[data-act-count]');
    if (el && st.timer?.pending) el.textContent = countdown(st.timer.target - Date.now());
  }, 250);

  document.addEventListener('change', (e) => {
    if (!active() || !e.target.hasAttribute?.('data-act-time')) return;
    cfg.at = e.target.value && e.target.value.length === 5 ? `${e.target.value}:00` : e.target.value;
    save();
    rerender();
  });
  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const set = e.target.closest('[data-act-set]');
    if (set) {
      cfg[set.dataset.actSet] = set.dataset.v;
      save();
      return rerender();
    }
    const plus = e.target.closest('[data-act-plus]');
    if (plus) {
      cfg.at = nowPlus(Number(plus.dataset.actPlus));
      save();
      return rerender();
    }
    const a = e.target.closest('[data-act]')?.dataset.act;
    if (!a) return;
    st.err = '';
    try {
      if (a === 'pick') {
        st.picking = true;
        rerender();
        const p = await window.hub.autoclick.pickClick();
        st.picking = false;
        if (p) {
          cfg.pos = p;
          save();
        }
      } else if (a === 'start') {
        apply(await window.hub.autoclick.schedule({ at: cfg.at, action: cfg.action, button: cfg.button, key: cfg.key, pos: cfg.action === 'key' ? null : cfg.pos }));
        window.HubTools?.ctx().toast?.(`Geplant für ${cfg.at} Uhr.`);
      } else if (a === 'cancel') {
        apply(await window.hub.autoclick.unschedule());
      }
    } catch (err) {
      st.picking = false;
      st.err = errText(err);
    }
    rerender();
  });
})();
