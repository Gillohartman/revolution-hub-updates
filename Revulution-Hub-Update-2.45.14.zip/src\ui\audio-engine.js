'use strict';
/*
 * Audio-Engine des Hubs (2.45.8) – unsichtbares Fenster, das alle Soundboard-Sounds abspielt
 * (Desktop-Widget und Stream-Deck-Tasten) und auf Wunsch dein echtes Mikrofon mit dem Soundboard mischt.
 *
 *   Soundboard ──┬─► Lautsprecher (du hörst mit, abschaltbar)
 *                └─► Mikrofon-Mix ─► virtuelles Mikrofon (z. B. für Discord)
 *   echtes Mikrofon ─────────────┘
 *
 * Gesteuert wird alles vom Hauptprozess über window.__engine (executeJavaScript) – diese Seite hat
 * keinen Zugriff auf Node oder Dateien; Sounds kommen als Data-URL herein.
 */
(() => {
  const ctx = new AudioContext({ latencyHint: 'interactive' });
  const sb = ctx.createGain(); // Soundboard-Sammelschiene
  const monitor = ctx.createGain(); // zum Mithören auf den Lautsprechern
  sb.connect(monitor).connect(ctx.destination);
  const mixDest = ctx.createMediaStreamDestination(); // Mikrofon-Mix
  const sbToMic = ctx.createGain();
  const micGain = ctx.createGain();
  sb.connect(sbToMic).connect(mixDest);
  micGain.connect(mixDest);

  const st = { muted: false, mix: { on: false, micId: '', outId: '', micVol: 1, sbVol: 1, monitor: true }, micStream: null, micSrc: null, out: null, outLabel: '', micLabel: '', error: '' };
  const buffers = new Map(); // pad → { ver, buf }
  const playing = new Set();

  /* ---------- eingebaute Sounds (wie im Soundboard-Widget) */
  function noise(c, dur) {
    const b = c.createBuffer(1, Math.round(c.sampleRate * dur), c.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource();
    s.buffer = b;
    return s;
  }
  function env(c, node, t, a, dur, peak, out) {
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    node.connect(g).connect(out);
    return g;
  }
  const SYNTH = [
    (c, t, o) => { const x = c.createOscillator(); x.frequency.setValueAtTime(150, t); x.frequency.exponentialRampToValueAtTime(40, t + 0.4); env(c, x, t, 0.005, 0.45, 1, o); x.start(t); x.stop(t + 0.5); return 0.5; },
    (c, t, o) => { for (let i = 0; i < 3; i++) { const n = noise(c, 0.2); const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1400; n.connect(f); env(c, f, t + i * 0.012, 0.002, 0.18, 0.7, o); n.start(t + i * 0.012); } return 0.3; },
    (c, t, o) => { for (const fr of [440, 554, 659]) { const x = c.createOscillator(); x.type = 'sawtooth'; x.frequency.value = fr; env(c, x, t, 0.03, 1.1, 0.18, o); x.start(t); x.stop(t + 1.2); } return 1.2; },
    (c, t, o) => { for (const [fr, v] of [[1320, 0.4], [2640, 0.15]]) { const x = c.createOscillator(); x.frequency.value = fr; env(c, x, t, 0.004, 1.4, v, o); x.start(t); x.stop(t + 1.5); } return 1.5; },
    (c, t, o) => { const x = c.createOscillator(); x.type = 'triangle'; x.frequency.setValueAtTime(180, t); x.frequency.exponentialRampToValueAtTime(700, t + 0.25); x.frequency.exponentialRampToValueAtTime(260, t + 0.6); env(c, x, t, 0.01, 0.65, 0.6, o); x.start(t); x.stop(t + 0.7); return 0.7; },
    (c, t, o) => { const n = noise(c, 1.2); const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(60, t + 1.1); n.connect(f); env(c, f, t, 0.005, 1.15, 1, o); n.start(t); return 1.2; },
    (c, t, o) => { [392, 370, 349, 330].forEach((fr, i) => { const x = c.createOscillator(); x.type = 'square'; x.frequency.value = fr; env(c, x, t + i * 0.32, 0.02, i === 3 ? 0.9 : 0.3, 0.12, o); x.start(t + i * 0.32); x.stop(t + i * 0.32 + (i === 3 ? 0.95 : 0.32)); }); return 2; },
    (c, t, o) => { [523, 659, 784, 1047].forEach((fr, i) => { const x = c.createOscillator(); x.type = 'triangle'; x.frequency.value = fr; env(c, x, t + i * 0.07, 0.01, 0.9, 0.25, o); x.start(t + i * 0.07); x.stop(t + 1.1); }); return 1.1; },
  ];

  async function decode(dataUrl) {
    const b64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return ctx.decodeAudioData(bytes.buffer);
  }

  /** Sound abspielen: pad 0–7, data = eigener Sound (Data-URL) oder leer → eingebauter Sound, ver = Version für den Zwischenspeicher. */
  async function play({ pad = 0, volume = 1, data = '', ver = 0 } = {}) {
    if (st.muted) return { played: false, muted: true };
    if (ctx.state !== 'running') await ctx.resume().catch(() => {});
    const out = ctx.createGain();
    out.gain.value = Math.max(0, Math.min(1.5, Number(volume) || 1));
    out.connect(sb);
    const t = ctx.currentTime + 0.01;
    if (data) {
      let e = buffers.get(pad);
      if (!e || e.ver !== ver) { e = { ver, buf: await decode(data) }; buffers.set(pad, e); }
      const s = ctx.createBufferSource();
      s.buffer = e.buf;
      s.connect(out);
      s.start(t);
      playing.add(out);
      s.onended = () => { playing.delete(out); out.disconnect(); };
      return { played: true, custom: true, seconds: Math.round(e.buf.duration * 10) / 10 };
    }
    const dur = (SYNTH[pad % SYNTH.length] || SYNTH[0])(ctx, t, out);
    playing.add(out);
    setTimeout(() => { playing.delete(out); out.disconnect(); }, (dur + 0.3) * 1000);
    return { played: true, custom: false };
  }
  function stop() {
    for (const g of playing) { try { g.gain.setValueAtTime(0, ctx.currentTime); g.disconnect(); } catch { /* egal */ } }
    playing.clear();
    return true;
  }

  /* ---------- Mikrofon-Mix */
  async function stopMix() {
    if (st.micStream) st.micStream.getTracks().forEach((t) => t.stop());
    st.micStream = null;
    try { st.micSrc?.disconnect(); } catch { /* egal */ }
    st.micSrc = null;
    if (st.out) { st.out.pause(); st.out.srcObject = null; }
    st.out = null;
    st.outLabel = '';
    st.micLabel = '';
  }
  // 2.45.8: kein Schritt darf ewig hängen (Gerät belegt/weg)
  const within = (p, ms, what) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(`${what} antwortet nicht – Gerät belegt oder nicht angeschlossen.`)), ms))]);
  async function applyMix() {
    const m = st.mix;
    monitor.gain.value = m.monitor === false ? 0 : 1;
    sbToMic.gain.value = Math.max(0, Math.min(1.5, Number(m.sbVol ?? 1)));
    micGain.gain.value = Math.max(0, Math.min(2, Number(m.micVol ?? 1)));
    st.error = '';
    if (!m.on) { await stopMix(); return status(); }
    try {
      // echtes Mikrofon (ohne Echo-/Rauschfilter – das macht Discord selbst)
      const wantMic = m.micId || 'default';
      if (!st.micStream || st.micStream._id !== wantMic) {
        if (st.micStream) st.micStream.getTracks().forEach((t) => t.stop());
        try { st.micSrc?.disconnect(); } catch { /* egal */ }
        st.micStream = await within(navigator.mediaDevices.getUserMedia({ audio: { deviceId: m.micId ? { exact: m.micId } : undefined, echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 2 } }), 6000, "Mikrofon");
        st.micStream._id = wantMic;
        st.micSrc = ctx.createMediaStreamSource(st.micStream);
        st.micSrc.connect(micGain);
        st.micLabel = st.micStream.getAudioTracks()[0]?.label || '';
      }
      // Ausgabe auf das virtuelle Mikrofon (bzw. das gewählte Wiedergabegerät)
      if (!st.out) { st.out = new Audio(); st.out.srcObject = mixDest.stream; }
      if (m.outId && st.out.sinkId !== m.outId) await within(st.out.setSinkId(m.outId), 4000, "Ausgabe");
      await within(st.out.play(), 4000, "Ausgabe");
      const outs = await navigator.mediaDevices.enumerateDevices();
      st.outLabel = outs.find((d) => d.kind === 'audiooutput' && d.deviceId === (m.outId || 'default'))?.label || '';
      if (ctx.state !== 'running') await ctx.resume().catch(() => {});
    } catch (e) {
      st.error = e?.name === 'NotFoundError' || e?.name === 'OverconstrainedError' ? 'Gerät nicht gefunden – bitte neu wählen.' : e?.name === 'NotAllowedError' ? 'Kein Zugriff aufs Mikrofon (Windows-Datenschutz → Mikrofon).' : String(e?.message || e);
      await stopMix();
    }
    return status();
  }
  async function devices() {
    // Gerätenamen gibt es erst nach einmaligem Mikrofon-Zugriff
    let list = await navigator.mediaDevices.enumerateDevices();
    if (!list.some((d) => d.label)) {
      try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach((t) => t.stop()); list = await navigator.mediaDevices.enumerateDevices(); } catch { /* ohne Namen */ }
    }
    const clean = (d) => ({ id: d.deviceId, label: d.label || (d.kind === 'audioinput' ? 'Mikrofon' : 'Lautsprecher') });
    const skip = (d) => d.deviceId === 'communications';
    return {
      mics: list.filter((d) => d.kind === 'audioinput' && !skip(d)).map(clean),
      outs: list.filter((d) => d.kind === 'audiooutput' && !skip(d)).map(clean),
    };
  }
  // Pegel des Mixes (für die Anzeige im Studio)
  const an = ctx.createAnalyser();
  an.fftSize = 512;
  sb.connect(an);
  micGain.connect(an);
  const lvBuf = new Float32Array(an.fftSize);
  function level() {
    an.getFloatTimeDomainData(lvBuf);
    let p = 0;
    for (const v of lvBuf) p = Math.max(p, Math.abs(v));
    return Math.round(Math.min(1, p) * 100);
  }
  function status() {
    return { muted: st.muted, mix: st.mix, active: Boolean(st.out && st.micStream), micLabel: st.micLabel, outLabel: st.outLabel, error: st.error, level: level(), ctx: ctx.state };
  }

  window.__engine = {
    play,
    stop,
    mute: (on) => { st.muted = Boolean(on); if (st.muted) stop(); return status(); },
    config: (m) => { st.mix = { ...st.mix, ...(m || {}) }; return applyMix(); },
    devices,
    status,
  };
})();
