'use strict';
/* Weltansicht 2.45 – eigener, leichter Globus: Satelliten, Flüge, Live-Kameras.
   Orthografische Projektion auf einem Canvas, echte Tag/Nacht-Grenze, ziehen = drehen/kippen,
   Mausrad = zoomen, Klick auf ein Objekt = Details. */
(() => {
  const api = window.worldview;
  const canvas = document.getElementById('globe');
  const ctx = canvas.getContext('2d');
  const $ = (id) => document.getElementById(id);
  const DEG = Math.PI / 180;
  const EARTH_KM = 6371;

  const view = { lon: 0, lat: 18 * DEG, zoom: 1, spin: true };
  const layers = { satellites: true, flights: true, cameras: true };
  const data = { satellites: { at: 0, items: [] }, flights: [], cameras: [] };
  const hits = { satellites: null, flights: null, cameras: null };
  let accent = '#ff2d2d';
  let location = null;
  let locationOn = false;
  let locationWatch = null;
  let texture = null;
  let selected = null;
  let W = 0, H = 0, DPR = 1;
  let geo = null; // vorberechnete Geometrie des Globus (gilt, solange Grösse/Zoom/Neigung gleich bleiben)

  // ---------- Erdtextur ----------
  const img = new Image();
  img.onload = () => {
    const c = document.createElement('canvas');
    c.width = img.width; c.height = img.height;
    const t = c.getContext('2d', { willReadFrequently: true });
    t.drawImage(img, 0, 0);
    texture = { w: img.width, h: img.height, px: t.getImageData(0, 0, img.width, img.height).data };
  };
  img.src = '../../ui/assets/earth.jpg';

  // ---------- Grösse ----------
  // Sternenhimmel einmal pro Grösse vorzeichnen (die Seite selbst ist im Hub durchsichtig)
  const sky = document.createElement('canvas');
  function paintSky() {
    sky.width = canvas.width; sky.height = canvas.height;
    const g = sky.getContext('2d');
    const bg = g.createRadialGradient(sky.width / 2, sky.height * 0.55, 0, sky.width / 2, sky.height * 0.55, Math.max(sky.width, sky.height) * 0.75);
    bg.addColorStop(0, '#0d1730'); bg.addColorStop(0.55, '#070b16'); bg.addColorStop(1, '#03050a');
    g.fillStyle = bg; g.fillRect(0, 0, sky.width, sky.height);
    const rnd = seeded(7);
    const n = Math.round(sky.width * sky.height / 5200);
    for (let i = 0; i < n; i++) {
      g.globalAlpha = 0.15 + rnd() * 0.6;
      g.fillStyle = rnd() > 0.85 ? '#cfe0ff' : '#fff';
      const s = rnd() > 0.93 ? 1.6 * DPR : 0.9 * DPR;
      g.fillRect(rnd() * sky.width, rnd() * sky.height, s, s);
    }
    g.globalAlpha = 1;
  }
  function seeded(seed) { let s = seed; return () => ((s = (s * 16807) % 2147483647) - 1) / 2147483646; }
  function resize() {
    DPR = Math.min(2, window.devicePixelRatio || 1);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    paintSky();
    geo = null;
  }
  window.addEventListener('resize', resize);
  resize();
  const radius = () => Math.min(W, H) * 0.36 * view.zoom;
  const center = () => ({ x: W / 2, y: H / 2 + 10 });

  // ---------- Sonne ----------
  function sun(now) {
    const d = new Date(now);
    const doy = (now - Date.UTC(d.getUTCFullYear(), 0, 0)) / 86400000;
    const decl = -23.44 * Math.cos((2 * Math.PI / 365) * (doy + 10)) * DEG;
    const utcH = d.getUTCHours() + d.getUTCMinutes() / 60 + d.getUTCSeconds() / 3600;
    return { decl, lon: (12 - utcH) * 15 * DEG };
  }

  // ---------- Projektion ----------
  // Punkt (Breite, Länge, Radiusfaktor) → Bildschirm; z < 0 = Rückseite
  function project(lat, lon, k, R, c) {
    const sl = Math.sin(lat), cl = Math.cos(lat), dl = lon - view.lon;
    const sp = Math.sin(view.lat), cp = Math.cos(view.lat);
    const x = cl * Math.sin(dl);
    const y = cp * sl - sp * cl * Math.cos(dl);
    const z = sp * sl + cp * cl * Math.cos(dl);
    return { x: c.x + R * k * x, y: c.y - R * k * y, z };
  }

  // Bildschirm → Breite/Länge (null = neben dem Globus)
  function unproject(x, y, R, c) {
    const nx = (x - c.x) / R, ny = (y - c.y) / R, r2 = nx * nx + ny * ny;
    if (r2 > 1) return null;
    const z = Math.sqrt(1 - r2), yy = -ny, sp = Math.sin(view.lat), cp = Math.cos(view.lat);
    const wy = yy * cp + z * sp, wz = -yy * sp + z * cp;
    return { lat: Math.asin(Math.max(-1, Math.min(1, wy))), lon: Math.atan2(nx, wz) + view.lon };
  }

  // ---------- Kartenkacheln: hineinzoomen bis auf einzelne Häuser (Esri World Imagery + Ortsnamen/Strassen) ----------
  const ESRI = 'https://server.arcgisonline.com/ArcGIS/rest/services/';
  const TILE_URL = {
    img: (z, x, y) => `${ESRI}World_Imagery/MapServer/tile/${z}/${y}/${x}`,
    roads: (z, x, y) => `${ESRI}Reference/World_Transportation/MapServer/tile/${z}/${y}/${x}`,
    places: (z, x, y) => `${ESRI}Reference/World_Boundaries_and_Places/MapServer/tile/${z}/${y}/${x}`,
  };
  const MAX_TILE_Z = 19;
  const tileCache = new Map();
  let tileFrame = 0;
  function tileImg(kind, z, x, y) {
    const key = `${kind}/${z}/${x}/${y}`;
    let e = tileCache.get(key);
    if (!e) {
      e = { img: new Image(), ok: false, used: 0 };
      e.img.crossOrigin = 'anonymous';
      e.img.onload = () => {
        // Esri liefert für Gebiete ohne Daten eine graue „Map data not yet available“-Kachel → wie fehlend behandeln
        if (kind === 'img' && z >= 8) {
          try {
            const t = document.createElement('canvas'); t.width = 16; t.height = 16;
            const g = t.getContext('2d', { willReadFrequently: true });
            g.drawImage(e.img, 0, 0, 16, 16);
            const px = g.getImageData(0, 0, 16, 16).data;
            let grey = 0;
            for (let i = 0; i < px.length; i += 4) if (Math.abs(px[i] - 204) < 14 && Math.abs(px[i + 1] - 204) < 14 && Math.abs(px[i + 2] - 204) < 14) grey++;
            if (grey > 200) { e.bad = true; return; }
          } catch { /* egal */ }
        }
        e.ok = true;
      };
      e.img.onerror = () => { e.bad = true; };
      e.img.src = TILE_URL[kind](z, x, y);
      tileCache.set(key, e);
    }
    e.used = tileFrame;
    return e.ok ? e.img : null;
  }
  // Kachel oder – solange sie lädt bzw. fehlt – ein vergrösserter Ausschnitt der nächstgröberen
  function tileSource(kind, z, x, y) {
    const own = tileImg(kind, z, x, y);
    if (own) return { img: own, sx: 0, sy: 0, sw: 256 };
    if (kind !== 'img') return null;
    for (let dz = 1; dz <= 8 && z - dz >= 1; dz++) {
      const k = 2 ** dz, ax = Math.floor(x / k), ay = Math.floor(y / k);
      const e = tileCache.get(`img/${z - dz}/${ax}/${ay}`);
      if (e?.ok) {
        e.used = tileFrame;
        const sw = 256 / k;
        return { img: e.img, sx: (x - ax * k) * sw, sy: (y - ay * k) * sw, sw };
      }
    }
    return null;
  }
  function pruneTiles() {
    if (tileCache.size < 700) return;
    const old = [...tileCache.entries()].filter(([, e]) => e.used < tileFrame - 2).sort((a, b) => a[1].used - b[1].used);
    for (const [k] of old.slice(0, tileCache.size - 500)) tileCache.delete(k);
  }
  const lat2ty = (lat, n) => ((1 - Math.log(Math.tan(lat) + 1 / Math.cos(lat)) / Math.PI) / 2) * n;
  const ty2lat = (y, n) => Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / n)));
  const lon2tx = (lon, n) => (((lon / (2 * Math.PI) + 0.5) % 1 + 1) % 1) * n;
  const attribution = document.getElementById('attrib');
  function drawTiles(R, c) {
    tileFrame++;
    const zf = Math.log2((2 * Math.PI * R * Math.max(0.05, Math.cos(view.lat))) / 256);
    const visible = R > Math.min(W, H) * 0.9 && zf >= 3.2;
    if (attribution) attribution.hidden = !visible;
    if (!visible) return;
    let z = Math.max(3, Math.min(MAX_TILE_Z, Math.round(zf)));
    // sichtbaren Ausschnitt abtasten
    let minLat = Infinity, maxLat = -Infinity, lons = [];
    for (let i = 0; i <= 6; i++) for (let j = 0; j <= 6; j++) {
      const p = unproject((W * i) / 6, (H * j) / 6, R, c);
      if (!p) continue;
      minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat);
      lons.push(p.lon);
    }
    if (!lons.length) return;
    const lon0 = view.lon;
    const rel = lons.map((l) => { let d = l - lon0; d = ((d + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI; return d; });
    let minLon = lon0 + Math.min(...rel), maxLon = lon0 + Math.max(...rel);
    const lim = 85.05 * DEG;
    minLat = Math.max(-lim, minLat); maxLat = Math.min(lim, maxLat);
    let n, x0, x1, y0, y1;
    for (;;) {
      n = 2 ** z;
      x0 = Math.floor(((minLon / (2 * Math.PI)) + 0.5) * n); x1 = Math.floor(((maxLon / (2 * Math.PI)) + 0.5) * n);
      y0 = Math.floor(lat2ty(maxLat, n)); y1 = Math.floor(lat2ty(minLat, n));
      if ((x1 - x0 + 1) * (y1 - y0 + 1) <= 70 || z <= 3) break;
      z--;
    }
    const sub = z < 6 ? 4 : z < 9 ? 2 : 1; // bei kleinen Zoomstufen Kacheln unterteilen (Erdkrümmung)
    const kinds = z >= 10 ? ['img', 'roads', 'places'] : z >= 5 ? ['img', 'places'] : ['img'];
    for (const kind of kinds) {
      for (let ty = Math.max(0, y0); ty <= Math.min(n - 1, y1); ty++) {
        for (let tx = x0; tx <= x1; tx++) {
          const wx = ((tx % n) + n) % n;
          const src = tileSource(kind, z, wx, ty);
          if (!src) continue;
          // gröbere Stufe im Hintergrund laden, damit beim Verschieben sofort etwas da ist
          if (kind === 'img' && z > 4) tileImg('img', z - 3, wx >> 3, ty >> 3);
          for (let si = 0; si < sub; si++) for (let sj = 0; sj < sub; sj++) {
            const la0 = ty2lat(ty + sj / sub, n), la1 = ty2lat(ty + (sj + 1) / sub, n);
            const lo0 = ((tx + si / sub) / n - 0.5) * 2 * Math.PI, lo1 = ((tx + (si + 1) / sub) / n - 0.5) * 2 * Math.PI;
            const p00 = project(la0, lo0, 1, R, c), p10 = project(la0, lo1, 1, R, c), p01 = project(la1, lo0, 1, R, c), p11 = project(la1, lo1, 1, R, c);
            if (p00.z < 0 && p10.z < 0 && p01.z < 0 && p11.z < 0) continue;
            const qx = [p00.x, p10.x, p01.x, p11.x], qy = [p00.y, p10.y, p01.y, p11.y];
            if (Math.max(...qx) < 0 || Math.min(...qx) > W || Math.max(...qy) < 0 || Math.min(...qy) > H) continue;
            const s = src.sw / sub, sx = src.sx + si * s, sy = src.sy + sj * s;
            ctx.save();
            ctx.beginPath();
            // Quadrat minimal grösser – sonst feine Fugen zwischen den Kacheln
            const cxm = (p00.x + p11.x) / 2, cym = (p00.y + p11.y) / 2, grow = (px, py) => [px + Math.sign(px - cxm) * 0.8, py + Math.sign(py - cym) * 0.8];
            ctx.moveTo(...grow(p00.x, p00.y)); ctx.lineTo(...grow(p10.x, p10.y)); ctx.lineTo(...grow(p11.x, p11.y)); ctx.lineTo(...grow(p01.x, p01.y)); ctx.closePath();
            ctx.clip();
            const a = (p10.x - p00.x) / s, b = (p10.y - p00.y) / s, cc = (p01.x - p00.x) / s, d = (p01.y - p00.y) / s;
            ctx.setTransform(DPR * a, DPR * b, DPR * cc, DPR * d, DPR * (p00.x - a * sx - cc * sy), DPR * (p00.y - b * sx - d * sy));
            // Bild über den Zellrand hinaus zeichnen (der Ausschnitt begrenzt es), damit keine Lücke bleibt
            const e = Math.min(s * 0.05, 1.2 / Math.max(1e-6, Math.hypot(a, b)));
            const x0s = Math.max(0, sx - e), y0s = Math.max(0, sy - e), x1s = Math.min(256, sx + s + e), y1s = Math.min(256, sy + s + e);
            ctx.drawImage(src.img, x0s, y0s, x1s - x0s, y1s - y0s, x0s, y0s, x1s - x0s, y1s - y0s);
            ctx.restore();
          }
        }
      }
    }
    pruneTiles();
  }

  // Flugzeug von oben, schattiert (Rumpf, gepfeilte Flügel, Triebwerke, Leitwerk) + Schatten am Boden
  function drawPlane(x, y, angle, len, shadow, sel) {
    const shape = (g) => {
      const L = len, w = L * 0.12;
      g.beginPath();
      g.moveTo(L * 0.5, 0); // Nase
      g.bezierCurveTo(L * 0.46, w * 0.55, L * 0.38, w * 0.6, L * 0.3, w * 0.6);
      g.lineTo(L * 0.06, w * 0.62); g.lineTo(-L * 0.18, L * 0.5); g.lineTo(-L * 0.27, L * 0.5); g.lineTo(-L * 0.12, w * 0.62);
      g.lineTo(-L * 0.36, w * 0.5); g.lineTo(-L * 0.47, L * 0.19); g.lineTo(-L * 0.52, L * 0.19); g.lineTo(-L * 0.48, 0);
      g.lineTo(-L * 0.52, -L * 0.19); g.lineTo(-L * 0.47, -L * 0.19); g.lineTo(-L * 0.36, -w * 0.5);
      g.lineTo(-L * 0.12, -w * 0.62); g.lineTo(-L * 0.27, -L * 0.5); g.lineTo(-L * 0.18, -L * 0.5); g.lineTo(L * 0.06, -w * 0.62);
      g.lineTo(L * 0.3, -w * 0.6); g.bezierCurveTo(L * 0.38, -w * 0.6, L * 0.46, -w * 0.55, L * 0.5, 0);
      g.closePath();
    };
    ctx.save();
    // Schatten (Sonne von oben links → nach rechts unten versetzt)
    ctx.translate(x + shadow * 0.7, y + shadow);
    ctx.rotate(angle);
    shape(ctx);
    ctx.fillStyle = 'rgba(0,0,0,.35)';
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    const g = ctx.createLinearGradient(0, -len * 0.5, 0, len * 0.5);
    g.addColorStop(0, '#c9d1dc'); g.addColorStop(0.45, '#ffffff'); g.addColorStop(0.55, '#f1f4f8'); g.addColorStop(1, '#9aa5b4');
    shape(ctx);
    ctx.fillStyle = g;
    ctx.fill();
    ctx.lineWidth = Math.max(0.8, len / 60);
    ctx.strokeStyle = sel ? '#ffd166' : 'rgba(40,50,70,.55)';
    ctx.stroke();
    // Triebwerke
    ctx.fillStyle = '#6b7685';
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.ellipse(len * 0.02, s * len * 0.24, len * 0.07, len * 0.03, 0, 0, Math.PI * 2); ctx.fill(); }
    // Cockpitfenster
    ctx.fillStyle = '#1e293b';
    ctx.beginPath(); ctx.ellipse(len * 0.43, 0, len * 0.03, len * 0.035, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  // Flugposition jetzt (zwischen zwei Abrufen mit Kurs und Tempo weitergerechnet)
  function fpos(f, now) {
    const dt = Math.max(0, Math.min(240, (now - (data.flightsAt || now)) / 1000));
    const dist = ((f.v || 0) / 3.6) * dt; // m
    const hd = (f.hd || 0) * DEG;
    const lat = f.lat + (dist * Math.cos(hd)) / 111320;
    const lon = f.lon + (dist * Math.sin(hd)) / (111320 * Math.max(0.05, Math.cos(f.lat * DEG)));
    return { lat, lon };
  }

  // ---------- Globus (pixelweise, nur sichtbarer Ausschnitt, begrenzte Auflösung) ----------
  const buf = document.createElement('canvas');
  const bctx = buf.getContext('2d');
  function drawEarth(R, c, now) {
    if (!texture) return;
    const x0 = Math.max(0, c.x - R), x1 = Math.min(W, c.x + R);
    const y0 = Math.max(0, c.y - R), y1 = Math.min(H, c.y + R);
    if (x1 <= x0 || y1 <= y0) return;
    const bw = x1 - x0, bh = y1 - y0;
    const tw = texture.w, th = texture.h;
    const key = [Math.round(R * 100), Math.round(c.x), Math.round(c.y), view.lat.toFixed(5), W, H, DPR, tw].join('|');
    if (!geo || geo.key !== key) {
      // Einmal pro Ansicht: Breite, relative Länge und Randhelligkeit jedes Pixels
      const scale = Math.min(DPR, Math.sqrt(380000 / (bw * bh))); // höchstens ~380k Pixel
      const pw = Math.max(1, Math.round(bw * scale)), ph = Math.max(1, Math.round(bh * scale));
      const n = pw * ph;
      const g = { key, pw, ph, idx: new Int32Array(n), count: 0, relU: new Float32Array(n), row: new Int32Array(n), sinLat: new Float32Array(n), cosLat: new Float32Array(n), cosRel: new Float32Array(n), sinRel: new Float32Array(n), rim: new Float32Array(n), alpha: new Uint8Array(n) };
      const sp = Math.sin(view.lat), cp = Math.cos(view.lat);
      let k = 0;
      for (let py = 0; py < ph; py++) {
        const ny = (y0 + (py + 0.5) / scale - c.y) / R;
        for (let px = 0; px < pw; px++) {
          const nx = (x0 + (px + 0.5) / scale - c.x) / R;
          const r2 = nx * nx + ny * ny;
          if (r2 > 1) continue;
          const z = Math.sqrt(1 - r2), yy = -ny;
          const wy = yy * cp + z * sp, wz = -yy * sp + z * cp; // Bildschirm → Welt
          const lat = Math.asin(Math.max(-1, Math.min(1, wy)));
          const rel = Math.atan2(nx, wz);
          g.idx[k] = py * pw + px;
          g.relU[k] = rel / (2 * Math.PI) + 0.5;
          g.row[k] = Math.max(0, Math.min(th - 1, ((0.5 - lat / Math.PI) * th) | 0)) * tw;
          g.sinLat[k] = Math.sin(lat); g.cosLat[k] = Math.cos(lat);
          g.cosRel[k] = Math.cos(rel); g.sinRel[k] = Math.sin(rel);
          g.rim[k] = 0.78 + 0.22 * z;
          g.alpha[k] = r2 > 0.985 ? 255 * (1 - r2) / 0.015 : 255;
          k++;
        }
      }
      g.count = k;
      g.frame = bctx.createImageData(pw, ph);
      geo = g;
    }
    const g = geo;
    if (buf.width !== g.pw || buf.height !== g.ph) { buf.width = g.pw; buf.height = g.ph; }
    const out = g.frame.data, tex = texture.px;
    const s = sun(now), sinD = Math.sin(s.decl), cosD = Math.cos(s.decl);
    const K = view.lon - s.lon, cosK = Math.cos(K), sinK = Math.sin(K);
    const off = view.lon / (2 * Math.PI);
    for (let k = 0; k < g.count; k++) {
      let u = g.relU[k] + off; u -= Math.floor(u);
      const si = (g.row[k] + ((u * tw) | 0)) * 4, o = g.idx[k] * 4;
      const cosLon = g.cosRel[k] * cosK - g.sinRel[k] * sinK; // cos(Länge − Sonnenlänge)
      const cosZ = g.sinLat[k] * sinD + g.cosLat[k] * cosD * cosLon;
      const day = cosZ < -0.1 ? 0 : cosZ > 0.15 ? 1 : (cosZ + 0.1) / 0.25;
      const light = (0.3 + 0.7 * day) * g.rim[k]; // Nachtseite gedämpft, Kontinente bleiben erkennbar
      const night = 1 - day;
      out[o] = tex[si] * light * (1 - 0.25 * night);
      out[o + 1] = tex[si + 1] * light * (1 - 0.12 * night) + 6 * night;
      out[o + 2] = tex[si + 2] * light + 22 * night;
      out[o + 3] = g.alpha[k];
    }
    bctx.putImageData(g.frame, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(buf, x0, y0, bw, bh);
  }

  function drawAtmosphere(R, c) {
    const g = ctx.createRadialGradient(c.x, c.y, R * 0.99, c.x, c.y, R * 1.06);
    g.addColorStop(0, 'rgba(120,185,255,.3)');
    g.addColorStop(0.4, 'rgba(90,150,255,.08)');
    g.addColorStop(1, 'rgba(90,150,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(c.x, c.y, R * 1.06, 0, Math.PI * 2); ctx.fill();
  }

  // Satellitenhöhe: bis 2000 km massstabsgetreu, darüber gestaucht (geostationär ≈ 1.75 × Erdradius)
  const satK = (alt) => {
    const a = Math.max(0, alt || 400);
    if (a <= 2000) return 1 + a / EARTH_KM;
    return 1 + 2000 / EARTH_KM + 0.44 * Math.log10(a / 2000) / Math.log10(36000 / 2000);
  };

  function lerpLon(a, b, t) {
    let d = b - a;
    if (d > 180) d -= 360; else if (d < -180) d += 360;
    return a + d * t;
  }

  // Punkte (bis ~20 000 pro Bild) direkt in einen Pixelpuffer schreiben – ein einziger Zeichenaufruf statt tausender
  const dots = document.createElement('canvas');
  const dctx = dots.getContext('2d');
  let dotImg = null, dot32 = null;
  const rgba = (r, g, b, a) => ((a << 24) | (b << 16) | (g << 8) | r) >>> 0; // ImageData ist RGBA, little endian
  function dotsBegin() {
    const w = Math.max(1, Math.round(W * DPR)), h = Math.max(1, Math.round(H * DPR));
    if (!dotImg || dotImg.width !== w || dotImg.height !== h) {
      dots.width = w; dots.height = h;
      dotImg = dctx.createImageData(w, h);
      dot32 = new Uint32Array(dotImg.data.buffer);
    } else dot32.fill(0);
  }
  function plot(x, y, size, color) {
    const w = dotImg.width, h = dotImg.height;
    const s = Math.max(1, Math.round(size * DPR));
    const x0 = Math.round(x * DPR - s / 2), y0 = Math.round(y * DPR - s / 2);
    if (x0 < 0 || y0 < 0 || x0 + s > w || y0 + s > h) return;
    for (let yy = 0; yy < s; yy++) dot32.fill(color, (y0 + yy) * w + x0, (y0 + yy) * w + x0 + s);
  }
  function dotsEnd() {
    dctx.putImageData(dotImg, 0, 0);
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(dots, 0, 0); ctx.restore();
  }
  const SAT_FRONT = rgba(255, 170, 160, 205), SAT_FRONT_FEW = rgba(255, 170, 160, 245), SAT_BACK = rgba(255, 157, 148, 60);
  const FLIGHT = rgba(255, 209, 102, 255), CAM = rgba(52, 211, 153, 255), CAM_EDGE = rgba(6, 40, 30, 255);

  function drawLayers(R, c, now) {
    dotsBegin();
    // Kameras
    if (layers.cameras && data.cameras.length) {
      const list = data.cameras, pos = new Float32Array(list.length * 2).fill(NaN);
      const size = Math.max(3, Math.min(8, R / 85));
      for (let i = 0; i < list.length; i++) {
        const p = project(list[i].lat * DEG, list[i].lon * DEG, 1.002, R, c);
        if (p.z < 0.02 || p.x < -10 || p.y < -10 || p.x > W + 10 || p.y > H + 10) continue;
        pos[i * 2] = p.x; pos[i * 2 + 1] = p.y;
        plot(p.x, p.y, size + 1.5, CAM_EDGE);
        plot(p.x, p.y, size, CAM);
      }
      hits.cameras = pos;
    } else hits.cameras = null;

    // Flüge
    if (layers.flights && data.flights.length) {
      const list = data.flights, pos = new Float32Array(list.length * 2).fill(NaN);
      ctx.fillStyle = '#ffd166';
      const s = Math.max(2.6, Math.min(6, R / 140));
      const arrows = R > 650; // herausgezoomt: Punkte (schnell), hineingezoomt: Pfeile in Flugrichtung
      const planes = R > 9000; // ganz nah: schattierte Flugzeuge mit Schatten am Boden
      const mPerPx = (EARTH_KM * 1000) / R;
      if (arrows && !planes) ctx.beginPath();
      for (let i = 0; i < list.length; i++) {
        const f = list[i];
        const fp = fpos(f, now);
        const p = project(fp.lat * DEG, fp.lon * DEG, planes ? 1 : 1.01, R, c);
        if (p.z < 0.02 || p.x < -60 || p.y < -60 || p.x > W + 60 || p.y > H + 60) continue;
        pos[i * 2] = p.x; pos[i * 2 + 1] = p.y;
        if (!arrows) { plot(p.x, p.y, 2.6, FLIGHT); continue; }
        // Flugrichtung auf dem Bildschirm: kleiner Schritt in Kursrichtung
        const hd = (f.hd || 0) * DEG;
        const q = project((fp.lat + Math.cos(hd) * 0.05) * DEG, (fp.lon + Math.sin(hd) * 0.05 / Math.max(0.2, Math.cos(fp.lat * DEG))) * DEG, 1, R, c);
        const a = Math.atan2(q.y - p.y, q.x - p.x), ca = Math.cos(a), sa = Math.sin(a);
        if (planes) {
          const len = Math.max(18, Math.min(120, 45 / mPerPx)); // ~45 m Flugzeug, mindestens gut sichtbar
          const shadow = Math.min(len * 1.6, ((f.alt || 3000) / mPerPx) * 0.05 + 6);
          drawPlane(p.x, p.y, a, len, shadow, selected?.item === f);
          continue;
        }
        const pt = (u, v) => [p.x + u * ca - v * sa, p.y + u * sa + v * ca];
        const [ax, ay] = pt(s * 1.6, 0), [bx, by] = pt(-s, s * 0.9), [cx2, cy2] = pt(-s * 0.45, 0), [dx, dy] = pt(-s, -s * 0.9);
        ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.lineTo(cx2, cy2); ctx.lineTo(dx, dy); ctx.closePath();
      }
      if (arrows && !planes) ctx.fill();
      hits.flights = pos;
    } else hits.flights = null;

    // Satelliten (zwischen zwei Bahnpunkten flüssig weiterbewegt)
    if (layers.satellites && data.satellites.items.length) {
      const list = data.satellites.items, pos = new Float32Array(list.length * 2).fill(NaN);
      const t = Math.max(0, Math.min(2, (now - data.satellites.at) / 60000));
      const dot = Math.max(1.6, Math.min(3, R / 200));
      const front = list.length > 3000 ? SAT_FRONT : SAT_FRONT_FEW;
      const sp = Math.sin(view.lat), cp = Math.cos(view.lat);
      for (let i = 0; i < list.length; i++) {
        const s = list[i];
        const lat = (s.lat + (s.lat2 - s.lat) * t) * DEG;
        const lon = lerpLon(s.lon, s.lon2, t) * DEG;
        // Projektion inline (12 000 × pro Bild)
        const sl = Math.sin(lat), cl = Math.cos(lat), dl = lon - view.lon, cd = Math.cos(dl);
        const k = R * (s.k || (s.k = satK(s.alt)));
        const x = c.x + k * cl * Math.sin(dl), y = c.y - k * (cp * sl - sp * cl * cd), z = sp * sl + cp * cl * cd;
        if (x < -4 || y < -4 || x > W + 4 || y > H + 4) continue;
        const dx = x - c.x, dy = y - c.y;
        if (z < 0 && dx * dx + dy * dy < R * R) continue; // hinter der Erde
        pos[i * 2] = x; pos[i * 2 + 1] = y;
        plot(x, y, dot, z < 0 ? SAT_BACK : front);
      }
      hits.satellites = pos;
    } else hits.satellites = null;
    dotsEnd();

    // Auswahl markieren
    if (selected) {
      const item = selected.item;
      let p = null;
      if (selected.kind === 'satellites') {
        const t = Math.max(0, Math.min(2, (now - data.satellites.at) / 60000));
        p = project((item.lat + (item.lat2 - item.lat) * t) * DEG, lerpLon(item.lon, item.lon2, t) * DEG, satK(item.alt), R, c);
      } else if (selected.kind === 'flights') {
        const fp = fpos(item, now);
        p = project(fp.lat * DEG, fp.lon * DEG, R > 9000 ? 1 : 1.01, R, c);
      } else p = project(item.lat * DEG, item.lon * DEG, 1.002, R, c);
      if (p && (p.z >= 0 || Math.hypot(p.x - c.x, p.y - c.y) >= R)) {
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(p.x, p.y, 9 + Math.sin(now / 250) * 1.5, 0, Math.PI * 2); ctx.stroke();
      }
    }

    // Standort
    if (locationOn && location) {
      const p = project(location.lat * DEG, location.lon * DEG, 1.003, R, c);
      if (p.z >= 0) {
        const pulse = (now / 1400) % 1;
        ctx.fillStyle = accent; ctx.globalAlpha = 0.35 * (1 - pulse);
        ctx.beginPath(); ctx.arc(p.x, p.y, 8 + pulse * 18, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(p.x, p.y, 6.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = accent; ctx.beginPath(); ctx.arc(p.x, p.y, 4.5, 0, Math.PI * 2); ctx.fill();
      }
    }
  }

  // ---------- Hauptschleife (~30 Bilder/s, pausiert im Hintergrund) ----------
  let last = 0, prev = 0, dragging = null;
  function frame(t) {
    requestAnimationFrame(frame);
    if (document.hidden || t - prev < 33) return;
    const now = Date.now();
    if (prev && view.spin && !dragging && view.zoom < 2.5) view.lon += Math.min(t - prev, 100) * 0.000012 / Math.sqrt(view.zoom); // ~1 Umdrehung in 9 min
    prev = t;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.drawImage(sky, 0, 0);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const R = radius(), c = center();
    drawAtmosphere(R, c);
    drawEarth(R, c, now);
    drawTiles(R, c);
    drawLayers(R, c, now);
    last = now;
  }
  requestAnimationFrame(frame);

  // ---------- Bedienung ----------
  canvas.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    dragging = { x: e.clientX, y: e.clientY, lon: view.lon, lat: view.lat, moved: false };
    canvas.setPointerCapture(e.pointerId);
    canvas.classList.add('grabbing');
  });
  canvas.addEventListener('pointermove', (e) => {
    if (dragging) {
      const R = radius();
      const dx = e.clientX - dragging.x, dy = e.clientY - dragging.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) dragging.moved = true;
      // nah dran: Karte verschieben wie bei Google Maps (Längengrade werden zu den Polen hin schmaler)
      const k = view.zoom > 3 ? Math.max(0.1, Math.cos(view.lat)) : 1;
      view.lon = dragging.lon - dx / (R * k);
      view.lat = Math.max(-84 * DEG, Math.min(84 * DEG, dragging.lat + dy / R));
      hideTip();
      return;
    }
    hover(e.clientX, e.clientY);
  });
  const endDrag = (e) => {
    if (!dragging) return;
    const wasClick = !dragging.moved;
    dragging = null;
    canvas.classList.remove('grabbing');
    if (wasClick && e.type === 'pointerup') click(e.clientX, e.clientY);
  };
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);
  canvas.addEventListener('pointerleave', hideTip);
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    // zur Mausposition hin zoomen: der Punkt unter dem Mauszeiger bleibt stehen
    const c = center();
    const before = unproject(e.clientX, e.clientY, radius(), c);
    setZoom(view.zoom * Math.exp(-e.deltaY * 0.0016));
    if (!before) return;
    for (let i = 0; i < 2; i++) {
      const after = unproject(e.clientX, e.clientY, radius(), c);
      if (!after) break;
      let d = before.lon - after.lon;
      d = ((d + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
      view.lon += d;
      view.lat = Math.max(-84 * DEG, Math.min(84 * DEG, view.lat + (before.lat - after.lat)));
    }
  }, { passive: false });
  // Doppelklick = an dieser Stelle 2× hineinzoomen (wie Google Maps)
  canvas.addEventListener('dblclick', (e) => {
    canvas.dispatchEvent(new WheelEvent('wheel', { clientX: e.clientX, clientY: e.clientY, deltaY: -433, bubbles: true, cancelable: true }));
  });
  // bis Strassen-/Häuser-Ebene (Kachel-Zoom 19)
  const maxZoom = () => (256 * 2 ** MAX_TILE_Z) / (2 * Math.PI) / (Math.min(W, H) * 0.36);
  function setZoom(z) { view.zoom = Math.max(0.55, Math.min(maxZoom(), z)); }
  // Für automatische Tests: Ansicht auf einen Ort setzen (Grad) und Kachel-Zoomstufe wählen
  window.__wvGoto = (lat, lon, tileZ) => {
    view.lat = lat * DEG; view.lon = lon * DEG; view.spin = false;
    setZoom((256 * 2 ** tileZ) / (2 * Math.PI * Math.cos(lat * DEG)) / (Math.min(W, H) * 0.36));
  };
  document.querySelectorAll('[data-zoom]').forEach((b) => b.addEventListener('click', () => {
    const k = Number(b.dataset.zoom);
    if (k) setZoom(view.zoom * k);
    else { view.zoom = 1; view.lat = 18 * DEG; }
  }));

  function nearest(x, y) {
    let best = null, bestD = 11 * 11;
    for (const kind of ['cameras', 'flights', 'satellites']) {
      const pos = hits[kind];
      if (!pos) continue;
      const list = kind === 'satellites' ? data.satellites.items : data[kind];
      for (let i = 0; i < pos.length; i += 2) {
        const dx = pos[i] - x, dy = pos[i + 1] - y;
        if (!(dx === dx)) continue; // NaN = nicht sichtbar
        const d = dx * dx + dy * dy;
        if (d < bestD) { bestD = d; best = { kind, item: list[i / 2] }; }
      }
      if (best && kind !== 'satellites') break; // Kameras/Flüge haben Vorrang vor Satelliten
    }
    return best;
  }

  const tip = $('tip');
  function hideTip() { tip.hidden = true; canvas.classList.remove('pointing'); }
  function hover(x, y) {
    const hit = nearest(x, y);
    if (!hit) return hideTip();
    canvas.classList.add('pointing');
    tip.textContent = label(hit);
    tip.style.left = Math.min(W - 240, x + 14) + 'px';
    tip.style.top = Math.max(8, y - 34) + 'px';
    tip.hidden = false;
  }
  function label({ kind, item }) {
    if (kind === 'cameras') return '📷 ' + item.name;
    if (kind === 'flights') return '✈️ ' + (item.cs || item.id.toUpperCase()) + (item.alt ? ` · ${Math.round(item.alt).toLocaleString('de-CH')} m` : '');
    return '🛰️ ' + (item.n || 'Satellit') + ` · ${Math.round(item.alt).toLocaleString('de-CH')} km`;
  }

  // ---------- Detailfenster ----------
  const panel = $('panel');
  const body = $('panel-body');
  let camTimer = 0;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  function closePanel() { panel.hidden = true; selected = null; clearInterval(camTimer); body.innerHTML = ''; }
  $('panel-close').addEventListener('click', closePanel);
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanel(); });

  function click(x, y) {
    const hit = nearest(x, y);
    if (!hit) return closePanel();
    selected = hit;
    // Etwas angeklickt: Globus anhalten, damit man es in Ruhe ansehen kann
    view.spin = false;
    spinBtn.classList.remove('on');
    clearInterval(camTimer);
    const it = hit.item;
    if (hit.kind === 'cameras') {
      const media = it.video
        ? `<video src="${esc(it.video)}" poster="${esc(it.img)}" autoplay muted loop playsinline></video>`
        : `<img id="cam-img" src="${esc(it.img)}${it.img.includes('?') ? '&' : '?'}t=${Date.now()}" alt="">`;
      body.innerHTML = `<p class="wv-kind">📷 Live-Kamera</p><h2>${esc(it.name)}</h2><div class="wv-media">${media}</div><p class="wv-meta">${esc(it.src)} · ${it.lat.toFixed(3)}°, ${it.lon.toFixed(3)}°</p><p class="wv-hint">Bild wird alle 30 s neu geladen.</p>`;
      const el = $('cam-img');
      if (el) {
        el.addEventListener('error', () => { el.replaceWith(Object.assign(document.createElement('p'), { className: 'wv-hint', textContent: 'Diese Kamera liefert gerade kein Bild.' })); }, { once: true });
        camTimer = setInterval(() => { el.src = it.img + (it.img.includes('?') ? '&' : '?') + 't=' + Date.now(); }, 30000);
      }
    } else if (hit.kind === 'flights') {
      const cs = it.cs || it.id.toUpperCase();
      body.innerHTML = `<p class="wv-kind">✈️ Flug</p><h2>${esc(cs)}</h2><dl>
        <dt>Höhe</dt><dd>${it.alt ? Math.round(it.alt).toLocaleString('de-CH') + ' m' : '–'}</dd>
        <dt>Geschwindigkeit</dt><dd>${it.v ? it.v + ' km/h' : '–'}</dd>
        <dt>Kurs</dt><dd>${it.hd}°</dd>
        <dt>${it.c && it.c.length <= 5 ? 'Typ' : 'Land'}</dt><dd>${esc(it.c || '–')}</dd>
        <dt>Transponder</dt><dd>${esc(it.id.toUpperCase())}</dd></dl>
        <div class="wv-fly"><button class="wv-flybtn" data-fly="cockpit">🛩️ Ins Cockpit</button><button class="wv-flybtn" data-fly="chase">✈️ 3D-Ansicht</button></div>
        ${it.cs ? `<a class="wv-link" href="https://www.flightradar24.com/${encodeURIComponent(it.cs)}" target="_blank" rel="noopener">Auf Flightradar24 ansehen ↗</a>` : ''}`;
      body.querySelectorAll('[data-fly]').forEach((b) => b.addEventListener('click', () => {
        window.WVCockpit?.open({ flight: it, mode: b.dataset.fly, getFlight: () => data.flights.find((x) => x.id === it.id) || it, flightsAt: () => data.flightsAt || Date.now() });
      }));
    } else {
      const speed = Math.sqrt(398600 / (EARTH_KM + it.alt)); // km/s, Kreisbahn
      body.innerHTML = `<p class="wv-kind">🛰️ Satellit</p><h2>${esc(it.n || 'Satellit')}</h2><dl>
        <dt>Höhe</dt><dd>${Math.round(it.alt).toLocaleString('de-CH')} km</dd>
        <dt>Geschwindigkeit</dt><dd>≈ ${(speed * 3600).toLocaleString('de-CH', { maximumFractionDigits: 0 })} km/h</dd>
        <dt>Bahn</dt><dd>${it.alt < 2000 ? 'Niedrige Erdbahn (LEO)' : it.alt < 34000 ? 'Mittlere Erdbahn (MEO)' : 'Geostationär (GEO)'}</dd>
        <dt>Position</dt><dd>${it.lat.toFixed(1)}°, ${it.lon.toFixed(1)}°</dd></dl>`;
    }
    panel.hidden = false;
    hideTip();
  }

  // ---------- Ebenen & Knöpfe ----------
  document.querySelectorAll('[data-layer]').forEach((b) => b.addEventListener('click', () => {
    const k = b.dataset.layer;
    layers[k] = !layers[k];
    b.classList.toggle('on', layers[k]);
    if (layers[k]) load(k);
    if (selected?.kind === k && !layers[k]) closePanel();
  }));
  const spinBtn = document.querySelector('[data-act="spin"]');
  spinBtn.classList.toggle('on', view.spin);
  spinBtn.addEventListener('click', () => { view.spin = !view.spin; spinBtn.classList.toggle('on', view.spin); });
  const locBtn = document.querySelector('[data-act="location"]');
  locBtn.addEventListener('click', () => {
    api.setLocationEnabled(!locationOn).catch(() => {});
    setLocation(!locationOn, true);
  });

  function setLocation(on, focus) {
    locationOn = on;
    locBtn.classList.toggle('on', on);
    if (!on) {
      if (locationWatch !== null) navigator.geolocation?.clearWatch(locationWatch);
      locationWatch = null; location = null;
      return;
    }
    if (locationWatch !== null || !navigator.geolocation) return;
    locationWatch = navigator.geolocation.watchPosition((r) => {
      const first = !location;
      location = { lat: r.coords.latitude, lon: r.coords.longitude };
      if (first && focus) { view.lon = location.lon * DEG; view.lat = Math.max(-60, Math.min(60, location.lat)) * DEG; }
    }, () => status('Standort nicht verfügbar – Windows-Standortdienste prüfen.'), { timeout: 15000, maximumAge: 300000 });
  }

  // ---------- Daten ----------
  const statusEl = $('status');
  let statusTimer = 0;
  function status(text) {
    statusEl.textContent = text;
    statusEl.classList.toggle('show', Boolean(text));
    clearTimeout(statusTimer);
    if (text) statusTimer = setTimeout(() => statusEl.classList.remove('show'), 6000);
  }
  const loading = {};
  const lastLoad = {};
  const EVERY = { satellites: 60000, flights: 120000, cameras: 60 * 60 * 1000 };
  async function load(kind, force) {
    if (!layers[kind] || loading[kind] || document.hidden) return;
    if (!force && Date.now() - (lastLoad[kind] || 0) < EVERY[kind]) return;
    loading[kind] = true;
    lastLoad[kind] = Date.now();
    $('n-' + kind).textContent = '…';
    try {
      const result = await api.data(kind);
      if (kind === 'satellites') data.satellites = { at: result.at, items: result.items };
      else data[kind] = result;
      if (kind === 'flights') data.flightsAt = Date.now();
      const n = kind === 'satellites' ? result.items.length : result.length;
      $('n-' + kind).textContent = n.toLocaleString('de-CH');
      if (selected?.kind === kind) {
        const fresh = (kind === 'satellites' ? data.satellites.items : data[kind]).find((x) => (x.id ?? x.n) === (selected.item.id ?? selected.item.n));
        if (fresh) selected.item = fresh;
      }
    } catch (error) {
      $('n-' + kind).textContent = '!';
      status((kind === 'satellites' ? 'Satelliten' : kind === 'flights' ? 'Flüge' : 'Kameras') + ': ' + (error?.message || 'nicht verfügbar').replace(/^Error invoking remote method '[^']+': (Error: )?/, ''));
    } finally {
      loading[kind] = false;
    }
  }
  setInterval(() => { for (const k of Object.keys(layers)) load(k); }, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) for (const k of Object.keys(layers)) load(k); });

  // ---------- Start ----------
  view.lon = sun(Date.now()).lon; // Tagseite zuerst
  api.appearance().then((a) => {
    accent = a.widgetAccent || accent;
    if (a.worldviewLocation) setLocation(true, true);
  }).catch(() => {});
  api.onAppearance?.((a) => { if (a?.widgetAccent) accent = a.widgetAccent; if (typeof a?.worldviewLocation === 'boolean' && a.worldviewLocation !== locationOn) setLocation(a.worldviewLocation, false); });
  for (const k of Object.keys(layers)) load(k, true);
})();
