﻿# Liest, was auf dem PC gerade abgespielt wird (Spotify, Browser, Player).
# Gibt pro Durchlauf eine JSON-Zeile aus; das Cover wird nur bei Titelwechsel
# mitgeschickt, damit die Ausgabe klein bleibt.
$ErrorActionPreference = 'SilentlyContinue'
# Ohne UTF-8 macht PowerShell aus Emojis im Titel „?????“.
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime | Out-Null

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  })[0]

function Await($WinRtTask, $ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  $netTask.Wait(-1) | Out-Null
  $netTask.Result
}

$managerType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$streamType = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = $managerType
$null = $streamType

$lastArtKey = ''
$artKey = ''        # Song, für den gerade ein Cover gesucht wird
$artTries = 0
$prevArt = ''       # Cover des vorherigen Songs (Spotify meldet den neuen Titel oft vor dem neuen Bild)
$prevAlbum = ''
$manager = $null
$lastPayload = ''
$playing = $false
$rasType = [Windows.Storage.Streams.IRandomAccessStream]
$null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]

# Cover lesen. Der Stream ist in PowerShell 5.1 ein nacktes COM-Objekt (Cast schlägt fehl) –
# über Reflection auf die WinRT-Schnittstelle klappt es zuverlässig (~50 ms).
function Read-Thumbnail($thumb) {
  $stream = Await ($thumb.OpenReadAsync()) ($streamType)
  $size = [uint32]$rasType.GetProperty('Size').GetValue($stream)
  if ($size -le 0) { return $null }
  $in = $rasType.GetMethod('GetInputStreamAt').Invoke($stream, @([uint64]0))
  $reader = [Windows.Storage.Streams.DataReader]::new($in)
  $loaded = Await ($reader.LoadAsync($size)) ([uint32])
  $bytes = New-Object byte[] $loaded
  $reader.ReadBytes($bytes)
  try { $stream.Dispose() } catch { }
  return ,$bytes
}

while ($true) {
  $payload = '{"playing":false}'
  $playing = $false
  try {
    # Den Manager nur einmal holen – das war der teuerste Teil jeder Runde.
    if ($null -eq $manager) { $manager = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]) }
    $session = $manager.GetCurrentSession()
    if ($null -ne $session) {
      $props = Await ($session.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
      $info = $session.GetPlaybackInfo()
      $timeline = $session.GetTimelineProperties()

      $art = ''
      $key = ([string]$props.Title) + '|' + ([string]$props.Artist) + '|' + ([string]$props.AlbumTitle)
      if ($key -ne $artKey) { $artKey = $key; $artTries = 0 }
      # Solange für diesen Song noch kein Cover gesendet wurde: bis zu 10 Versuche (~4 s)
      if ($key -ne $lastArtKey -and $artTries -lt 10 -and $null -ne $props.Thumbnail) {
        $artTries++
        $bytes = $null
        try { $bytes = Read-Thumbnail $props.Thumbnail } catch { [Console]::Error.WriteLine('art: ' + $_.Exception.Message) }
        if ($null -ne $bytes -and $bytes.Length -gt 0) {
          $b64 = [Convert]::ToBase64String($bytes)
          # Noch das Bild vom letzten Song (anderes Album)? Dann kurz warten und neu lesen.
          $stale = ($b64 -eq $prevArt) -and ([string]$props.AlbumTitle -ne $prevAlbum) -and ($artTries -lt 5)
          if (-not $stale) {
            $art = $b64
            $lastArtKey = $key
            $prevArt = $b64
            $prevAlbum = [string]$props.AlbumTitle
          }
        }
      }

      $obj = [ordered]@{
        playing  = ($info.PlaybackStatus -eq 'Playing')
        title    = [string]$props.Title
        artist   = [string]$props.Artist
        album    = [string]$props.AlbumTitle
        app      = [string]$session.SourceAppUserModelId
        position = [math]::Round([double]$timeline.Position.TotalSeconds, 2)
        duration = [math]::Round([double]$timeline.EndTime.TotalSeconds, 2)
        art      = $art
      }
      $payload = ($obj | ConvertTo-Json -Compress)
      $playing = [bool]$obj.playing
    }
  } catch {
    $payload = '{"playing":false}'
    $manager = $null
  }
  # Nur bei Änderung senden; beim Abspielen ändert sich die Position ohnehin.
  if ($payload -ne $lastPayload) {
    [Console]::Out.WriteLine($payload)
    [Console]::Out.Flush()
    $lastPayload = $payload
  }
  # Beim Abspielen 2,5×/s (Songtext bleibt synchron), sonst alle 0,6 s (Play/Songwechsel schnell erkannt).
  if ($playing) { Start-Sleep -Milliseconds 400 } else { Start-Sleep -Milliseconds 600 }
}
