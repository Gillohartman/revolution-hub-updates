'use strict';
/*
 * 3D-Modell – einfacher CAD-Modellierer für den 3D-Druck.
 * Objekte: { id, name, kind, p (Parameter), pos, rot (Grad), scl, color, hole, hidden, mesh?, src? }
 * kind ist ein Grundkörper aus M3G.SHAPES oder 'mesh' (Import / boolesches Ergebnis, Netz in mesh).
 */
(function () {
  const G = window.M3G;
  const { M, SHAPES } = G;
  const api = window.model3d;
  const $ = (s) => document.querySelector(s);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const fmt = (n, d = 1) => (Math.abs(n) < 1e-9 ? 0 : n).toFixed(d).replace(/\.0+$|(\.\d*?)0+$/, '$1');
  const num = (s) => parseFloat(String(s).replace(',', '.'));

  const BEDS = [
    ['p1', 'Bambu Lab P1S / X1C', 256, 256, 256], ['a1', 'Bambu Lab A1', 256, 256, 256], ['a1mini', 'Bambu Lab A1 mini', 180, 180, 180],
    ['mk4', 'Prusa MK4', 250, 210, 220], ['mini', 'Prusa MINI', 180, 180, 180], ['ender3', 'Creality Ender-3', 220, 220, 250],
    ['k1', 'Creality K1', 220, 220, 250], ['neptune', 'Elegoo Neptune 4 Pro', 225, 225, 265], ['kobra', 'Anycubic Kobra 2', 220, 220, 250],
    ['custom', 'Eigene Grösse …', 200, 200, 200],
  ];
  const COLORS = ['#ff5a4f', '#ff9f43', '#ffd43b', '#51cf66', '#22b8cf', '#4c7bf5', '#9b5de5', '#f06595', '#e9ecef', '#5c636e'];
  const AX = ['#ff5a52', '#5fd46a', '#4f8dff'];
  const AXN = ['X', 'Y', 'Z'];

  /* --------------------------------------------------------------- Symbole */
  const S = (d, extra = '') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" ${extra}>${d}</svg>`;
  const I = {
    box: S('<path d="M12 3 20 7.5v9L12 21l-8-4.5v-9Z"/><path d="M4 7.5 12 12l8-4.5M12 12v9"/>'),
    cyl: S('<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6"/>'),
    sphere: S('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12c0 1.9 3.8 3.4 8.5 3.4s8.5-1.5 8.5-3.4"/>'),
    hemi: S('<path d="M3.5 16a8.5 8.5 0 0 1 17 0"/><ellipse cx="12" cy="16" rx="8.5" ry="3"/>'),
    cone: S('<path d="M12 3 5 18M12 3l7 15"/><ellipse cx="12" cy="18" rx="7" ry="2.6"/>'),
    pyramid: S('<path d="M12 3 3.5 16.5 11 21l9.5-4.5Z"/><path d="M12 3l-1 18"/>'),
    prism: S('<path d="M4 19 8.5 7 13 19Z"/><path d="M8.5 7h7L20 19h-7"/>'),
    wedge: S('<path d="M3 19V9l14 10Z"/><path d="M3 9l4-3 14 10-4 3"/><path d="M3 19l4-3h14"/>'),
    torus: S('<ellipse cx="12" cy="12" rx="9" ry="5.5"/><ellipse cx="12" cy="11.5" rx="3.6" ry="1.7"/>'),
    tube: S('<ellipse cx="12" cy="6" rx="7" ry="2.8"/><ellipse cx="12" cy="6" rx="3.4" ry="1.3"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6"/>'),
    text: S('<path d="M5 7V4.5h14V7M12 4.5v15M9 19.5h6"/>'),
    holeBox: S('<path d="M12 3 20 7.5v9L12 21l-8-4.5v-9Z" stroke-dasharray="2.4 2"/><path d="M4 7.5 12 12l8-4.5M12 12v9" stroke-dasharray="2.4 2"/>'),
    holeCyl: S('<ellipse cx="12" cy="6" rx="7" ry="2.8" stroke-dasharray="2.4 2"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6" stroke-dasharray="2.4 2"/>'),
    neu: S('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5M12 11v6M9 14h6"/>'),
    open: S('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>'),
    save: S('<path d="M5 4h11l3 3v12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1Z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>'),
    import: S('<path d="M12 3v11M7.5 9.5 12 14l4.5-4.5"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>'),
    undo: S('<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>'),
    redo: S('<path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>'),
    select: S('<path d="M5 3.5 18.5 12l-6 1.4-3 5.6Z"/>'),
    move: S('<path d="M12 3v18M3 12h18M12 3 9.5 5.5M12 3l2.5 2.5M12 21l-2.5-2.5M12 21l2.5-2.5M3 12l2.5-2.5M3 12l2.5 2.5M21 12l-2.5-2.5M21 12l-2.5 2.5"/>'),
    rotate: S('<path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/>'),
    scale: S('<rect x="3.5" y="10.5" width="10" height="10" rx="1"/><path d="M13 11 20.5 3.5M15 3.5h5.5V9"/>'),
    measure: S('<path d="m3 16.5 13.5-13.5 4.5 4.5L7.5 21Z"/><path d="m7 12.5 2 2M10 9.5l2 2M13 6.5l2 2"/>'),
    flat: S('<path d="M3 20h18"/><path d="M7 16.5 12 8l5 8.5Z"/><path d="M12 3v2"/>'),
    edit: S('<path d="M4 18 9 6l11 4-7 10Z"/><circle cx="4" cy="18" r="1.8" fill="currentColor"/><circle cx="9" cy="6" r="1.8" fill="currentColor"/><circle cx="20" cy="10" r="1.8" fill="currentColor"/><circle cx="13" cy="20" r="1.8" fill="currentColor"/>'),
    gallery: S('<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><circle cx="17" cy="7" r="3.5"/><path d="M7 13.5 10.5 20h-7Z"/><path d="m17 13 1.2 2.6 2.8.3-2.1 1.9.6 2.8-2.5-1.4-2.5 1.4.6-2.8-2.1-1.9 2.8-.3Z"/>'),
    eye: S('<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/>'),
    eyeOff: S('<path d="M3 3l18 18M10.6 5.6A9.9 9.9 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-3 3.7M6.5 6.9C4 8.6 2.5 12 2.5 12S6 18.5 12 18.5a9 9 0 0 0 4-.9"/>'),
  };

  /* ---------------------------------------------------------------- Zustand */
  let objs = [];
  let sel = [];
  let nextId = 1;
  let mode = 'move';
  let snap = 1;
  let bed = { id: 'p1', w: 256, d: 256, h: 256 };
  let measure = null;
  let lockRatio = true;
  let clip = null;
  let ed = null; // Bearbeiten: { id, sub: 'vert' | 'face', sel: Set(Punktnummern) }
  let edScreen = [];
  let extrudeDist = 5;
  const deformVals = { taper: 100, twist: 0, bend: 0 };
  const E = window.M3E;
  const undoStack = [], redoStack = [];
  const view = window.M3View($('#gl'));
  const ov = $('#ov');
  const og = ov.getContext('2d');

  const byId = (id) => objs.find((o) => o.id === id);
  const selected = () => sel.map(byId).filter(Boolean);
  const visible = () => objs.filter((o) => !o.hidden);
  const clone = (o) => ({ ...o, p: { ...o.p }, pos: [...o.pos], rot: [...o.rot], scl: [...o.scl], src: o.src ? o.src.map(clone) : null });

  const memo = new Map();
  function geom(o) {
    if (o.mesh) return o.mesh;
    const k = o.kind + JSON.stringify(o.p);
    let m = memo.get(k);
    if (!m) { m = SHAPES[o.kind].make(o.p); memo.set(k, m); if (memo.size > 150) memo.delete(memo.keys().next().value); }
    return m;
  }
  const mat = (o) => M.trs(o.pos, o.rot, o.scl);
  const wc = new Map();
  function world(o) {
    const g = geom(o); const k = `${o.pos}|${o.rot}|${o.scl}`;
    let e = wc.get(o.id);
    if (!e || e.g !== g || e.k !== k) { const arr = G.transform(g, mat(o)); e = { g, k, arr, bb: G.bbox(arr) }; wc.set(o.id, e); }
    return e;
  }
  function unionBox(list) {
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (const o of list) { const { bb } = world(o); for (let k = 0; k < 3; k += 1) { mn[k] = Math.min(mn[k], bb.min[k]); mx[k] = Math.max(mx[k], bb.max[k]); } }
    return list.length ? { min: mn, max: mx, c: mn.map((v, k) => (v + mx[k]) / 2), s: mn.map((v, k) => mx[k] - v) } : null;
  }
  const localSize = (o) => { const bb = G.bbox(geom(o)); return [0, 1, 2].map((k) => (bb.max[k] - bb.min[k]) * Math.abs(o.scl[k])); };
  const snapV = (v, step = snap) => (step > 0 ? Math.round(v / step) * step : v);

  /* ------------------------------------------------------------- Verlauf */
  const snapshot = () => ({ objs: objs.map(clone), sel: [...sel], nextId });
  function checkpoint() { undoStack.push(snapshot()); if (undoStack.length > 100) undoStack.shift(); redoStack.length = 0; }
  function restore(s) {
    objs = s.objs.map(clone); sel = s.sel.filter((id) => objs.some((o) => o.id === id)); nextId = Math.max(nextId, s.nextId);
    if (ed) { const o = byId(ed.id); if (!o || !o.mesh) { ed = null; setMode('move'); } else ed.sel = new Set(); }
    refresh();
  }
  function undo() { if (!undoStack.length) return; redoStack.push(snapshot()); restore(undoStack.pop()); }
  function redo() { if (!redoStack.length) return; undoStack.push(snapshot()); restore(redoStack.pop()); }

  /* ------------------------------------------------------------- Meldung */
  function toast(msg, kind = '') {
    const el = $('#toast'); el.textContent = msg; el.className = `m-toast ${kind}`; el.hidden = false;
    clearTimeout(toast.t); toast.t = setTimeout(() => { el.hidden = true; }, kind === 'error' ? 6000 : 3200);
  }

  /* --------------------------------------------------------- Objekte anlegen */
  function uniqueName(base) {
    const names = new Set(objs.map((o) => o.name));
    if (!names.has(base)) return base;
    for (let i = 2; ; i += 1) if (!names.has(`${base} ${i}`)) return `${base} ${i}`;
  }
  // freien Platz nahe der Bettmitte suchen
  function freeSpot(o) {
    const s = localSize(o); const others = visible().map((x) => world(x).bb);
    const step = Math.max(10, snapV(Math.max(s[0], s[1]) + 6, 1));
    for (let r = 0; r < 8; r += 1) for (let i = -r; i <= r; i += 1) for (let j = -r; j <= r; j += 1) {
      if (Math.max(Math.abs(i), Math.abs(j)) !== r) continue;
      const x = i * step, y = j * step;
      if (Math.abs(x) + s[0] / 2 > bed.w / 2 || Math.abs(y) + s[1] / 2 > bed.d / 2) continue;
      const hit = others.some((b) => x + s[0] / 2 > b.min[0] && x - s[0] / 2 < b.max[0] && y + s[1] / 2 > b.min[1] && y - s[1] / 2 < b.max[1]);
      if (!hit) return [x, y];
    }
    return [0, 0];
  }
  function makeObj(kind, extra = {}) {
    const p = {}; if (SHAPES[kind]) for (const [k, , d] of SHAPES[kind].params) p[k] = d;
    const o = { id: nextId++, name: uniqueName(extra.name || SHAPES[kind]?.name || 'Netz'), kind, pos: [0, 0, 0], rot: [0, 0, 0], scl: [1, 1, 1], color: COLORS[objs.length % 8], hole: false, hidden: false, mesh: null, src: null, ...extra, p: { ...p, ...(extra.p || {}) } };
    if (o.hole) o.name = uniqueName(`Loch ${SHAPES[kind]?.name || ''}`.trim());
    return o;
  }
  // Galerie-Vorlage (eine oder mehrere Formen, relative Lage über `at`)
  function addPreset(item) {
    toast(`${item.name} wird erstellt …`);
    setTimeout(() => {
      try {
        const list = item.parts.map((pt) => makeObj(pt.kind, { p: pt.p, ...(pt.color ? { color: pt.color } : {}), ...(item.parts.length > 1 ? {} : { name: item.name }) }));
        list.forEach((o) => geom(o));
        const [x, y] = freeSpot(list[0]);
        checkpoint();
        list.forEach((o, i) => { const at = item.parts[i].at || [0, 0, 0]; o.pos = [x + at[0], y + at[1], at[2]]; objs.push(o); });
        sel = list.map((o) => o.id); refresh();
        $('#toast').hidden = true;
      } catch (e) { toast(`Form konnte nicht erstellt werden: ${e.message || e}`, 'error'); }
    }, 20);
  }
  function add(kind, extra = {}) {
    const o = makeObj(kind, extra);
    const [x, y] = extra.pos ? extra.pos : freeSpot(o);
    o.pos = [x, y, extra.pos ? extra.pos[2] : 0];
    checkpoint();
    objs.push(o); sel = [o.id];
    refresh();
    return o;
  }

  /* ----------------------------------------------------------- Bearbeiten */
  function edit(fn, list = selected()) { if (!list.length) return; checkpoint(); list.forEach(fn); refresh(); }
  function remove() { if (!sel.length) return; checkpoint(); objs = objs.filter((o) => !sel.includes(o.id)); sel = []; refresh(); }
  function duplicate(offset = true) {
    const list = selected(); if (!list.length) return;
    checkpoint();
    const off = offset ? Math.max(10, snapV(10, snap || 1)) : 0;
    sel = list.map((o) => { const c = clone(o); c.id = nextId++; c.name = uniqueName(o.name.replace(/ \d+$/, '')); c.pos[0] += off; c.pos[1] += off; objs.push(c); return c.id; });
    refresh();
  }
  function dropToBed(list = selected()) { edit((o) => { o.pos[2] -= world(o).bb.min[2]; }, list); }
  function centerOnBed() {
    const list = selected(); const b = unionBox(list); if (!b) return;
    edit((o) => { o.pos[0] -= b.c[0]; o.pos[1] -= b.c[1]; }, list);
  }
  function mirror(axis) {
    edit((o) => {
      const before = world(o).bb; o.scl[axis] *= -1;
      const after = world(o).bb;
      for (let k = 0; k < 3; k += 1) o.pos[k] += (before.min[k] + before.max[k]) / 2 - (after.min[k] + after.max[k]) / 2;
    });
  }
  function align(axis, where) {
    const list = selected(); if (list.length < 2) return;
    const b = unionBox(list);
    edit((o) => {
      const bb = world(o).bb;
      const d = where === 0 ? b.min[axis] - bb.min[axis] : where === 2 ? b.max[axis] - bb.max[axis] : b.c[axis] - (bb.min[axis] + bb.max[axis]) / 2;
      o.pos[axis] += d;
    }, list);
  }
  function setHole(flag) { edit((o) => { o.hole = flag; }); }

  // Boolesche Operationen; 'group' = Körper vereinigen und Löcher abziehen (wie Tinkercad)
  function combine(op) {
    const list = selected();
    if (list.length < 2) return toast('Mindestens zwei Objekte auswählen.');
    const tris = list.reduce((s, o) => s + geom(o).length / 9, 0);
    toast(tris > 20000 ? 'Berechne … (grosse Netze brauchen etwas Zeit)' : 'Berechne …');
    setTimeout(() => {
      let res;
      try {
        const W = (o) => world(o).arr;
        if (op === 'group') {
          const solids = list.filter((o) => !o.hole), holes = list.filter((o) => o.hole);
          if (!solids.length) { toast('Die Gruppe braucht mindestens einen Körper (nicht nur Löcher).', 'error'); return; }
          res = solids.map(W).reduce((a, b) => G.csg('union', a, b));
          for (const h of holes) res = G.csg('subtract', res, W(h));
        } else if (op === 'subtract') {
          res = W(list[0]); for (const o of list.slice(1)) res = G.csg('subtract', res, W(o));
        } else res = list.map(W).reduce((a, b) => G.csg(op, a, b));
      } catch (e) {
        toast(`Berechnung fehlgeschlagen: ${e.message || e}`, 'error'); return;
      }
      if (!res || !res.length) { toast('Das Ergebnis ist leer – die Objekte überschneiden sich nicht.', 'error'); return; }
      const off = []; const mesh = G.center(res, off);
      checkpoint();
      objs = objs.filter((o) => !sel.includes(o.id));
      const first = list.find((o) => !o.hole) || list[0];
      const name = { group: 'Gruppe', union: 'Vereinigung', subtract: 'Differenz', intersect: 'Schnittmenge' }[op];
      const o = { id: nextId++, name: uniqueName(name), kind: 'mesh', p: {}, pos: off, rot: [0, 0, 0], scl: [1, 1, 1], color: first.color, hole: false, hidden: false, mesh, src: list.map(clone) };
      objs.push(o); sel = [o.id];
      refresh();
      toast(`${name} erstellt · ${(mesh.length / 9).toLocaleString('de-CH')} Dreiecke`);
    }, 30);
  }
  function ungroup() {
    const list = selected().filter((o) => o.src); if (!list.length) return;
    checkpoint();
    const ids = [];
    for (const o of list) {
      objs = objs.filter((x) => x !== o);
      for (const s of o.src) { const c = clone(s); c.id = nextId++; objs.push(c); ids.push(c.id); }
    }
    sel = ids; refresh();
  }
  // gewählte Fläche nach unten drehen und auf das Bett legen
  function layFlat(o, n) {
    const t = [0, 0, -1]; const d = Math.max(-1, Math.min(1, G.dot(n, t)));
    let axis = G.cross(n, t); const len = Math.hypot(...axis);
    let R;
    if (len < 1e-6) R = d > 0 ? [[1, 0, 0], [0, 1, 0], [0, 0, 1]] : [[1, 0, 0], [0, -1, 0], [0, 0, -1]];
    else {
      axis = axis.map((v) => v / len); const a = Math.acos(d), c = Math.cos(a), s = Math.sin(a), C = 1 - c; const [x, y, z] = axis;
      R = [[c + x * x * C, x * y * C - z * s, x * z * C + y * s], [y * x * C + z * s, c + y * y * C, y * z * C - x * s], [z * x * C - y * s, z * y * C + x * s, c + z * z * C]];
    }
    checkpoint();
    const b0 = world(o).bb; const cx = (b0.min[0] + b0.max[0]) / 2, cy = (b0.min[1] + b0.max[1]) / 2;
    o.rot = M.euler(M.m3mul(R, M.rot(...o.rot))).map((v) => Math.round(v * 1e4) / 1e4);
    const b1 = world(o).bb;
    o.pos[0] += cx - (b1.min[0] + b1.max[0]) / 2; o.pos[1] += cy - (b1.min[1] + b1.max[1]) / 2; o.pos[2] -= b1.min[2];
    refresh();
    toast(`„${o.name}“ liegt jetzt mit dieser Fläche auf dem Bett.`);
  }

  /* ------------------------------------------------- Punkte & Flächen bearbeiten */
  function toMesh(o, why) {
    if (o.mesh) return;
    o.mesh = geom(o); o.kind = 'mesh'; o.p = {}; o.src = null;
    if (why) toast(`${why} – die Formparameter von „${o.name}“ entfallen dabei.`);
  }
  function enterEdit() {
    const list = selected();
    if (list.length !== 1) { toast('Zum Bearbeiten genau ein Objekt auswählen.'); return false; }
    const o = list[0];
    if (!o.mesh) { checkpoint(); toMesh(o, 'In ein bearbeitbares Netz umgewandelt'); }
    ed = { id: o.id, sub: ed?.sub || 'vert', sel: new Set() };
    return true;
  }
  const edObj = () => (ed ? byId(ed.id) : null);
  function edCentroid(o) {
    const w = E.weld(o.mesh); const m = mat(o); const c = [0, 0, 0]; let n = 0;
    for (const v of ed.sel) { const p = M.pt(m, [w.pos[v * 3], w.pos[v * 3 + 1], w.pos[v * 3 + 2]]); c[0] += p[0]; c[1] += p[1]; c[2] += p[2]; n += 1; }
    return n ? c.map((v) => v / n) : null;
  }
  function edMoveTo(axis, value) {
    const o = edObj(); const c = o && edCentroid(o); if (!c) return;
    const d = [0, 0, 0]; d[axis] = value - c[axis];
    checkpoint(); o.mesh = E.moveVerts(o.mesh, ed.sel, M.dir(M.inv(mat(o)), d)); refresh();
  }
  function edExtrude() {
    const o = edObj(); if (!o || !ed.sel.size) { toast('Zuerst eine Fläche wählen (rechts auf „Flächen“ schalten).'); return; }
    const s = Math.abs(o.scl[0] * o.scl[1] * o.scl[2]) ** (1 / 3) || 1;
    const r = E.extrude(o.mesh, ed.sel, extrudeDist / s);
    if (!r) { toast('Die Auswahl enthält keine ganze Fläche – alle Ecken einer Fläche wählen.', 'error'); return; }
    checkpoint(); o.mesh = r.mesh; ed.sel = r.sel; refresh();
    toast(`Fläche um ${fmt(extrudeDist, 2)} mm extrudiert.`);
  }
  function edSelectAll() { const o = edObj(); if (!o) return; ed.sel = new Set(Array.from({ length: E.weld(o.mesh).count }, (_, i) => i)); refresh(); }
  function smoothObj() {
    const o = selected()[0]; if (!o) return;
    if (geom(o).length / 9 > 60000) { toast('Das Netz ist zum Glätten zu gross (über 60 000 Dreiecke).', 'error'); return; }
    checkpoint(); const was = !o.mesh; toMesh(o); o.mesh = E.smooth(o.mesh, 1, 8);
    if (ed) ed.sel = new Set();
    refresh(); toast(was ? 'Geglättet (in ein Netz umgewandelt).' : 'Geglättet.');
  }
  function subdivideObj() {
    const o = selected()[0]; if (!o) return;
    if (geom(o).length / 9 > 100000) { toast('Das Netz ist bereits sehr fein.', 'error'); return; }
    checkpoint(); toMesh(o); o.mesh = E.subdivide(o.mesh); if (ed) ed.sel = new Set(); refresh();
  }
  function deformObj() {
    const o = selected()[0]; if (!o) return;
    const { taper, twist, bend } = deformVals;
    if (taper === 100 && !twist && !bend) { toast('Zuerst Verjüngen, Verdrehen oder Biegen einstellen.'); return; }
    toast('Verforme …');
    setTimeout(() => {
      try {
        checkpoint(); toMesh(o); o.mesh = E.deform(o.mesh, deformVals);
        deformVals.taper = 100; deformVals.twist = 0; deformVals.bend = 0;
        refresh(); toast(`„${o.name}“ verformt · ${(o.mesh.length / 9).toLocaleString('de-CH')} Dreiecke`);
      } catch (e) { toast(`Verformen fehlgeschlagen: ${e.message || e}`, 'error'); }
    }, 20);
  }

  /* ------------------------------------------------------------- Galerie */
  const thumbs = new Map();
  let galCat = 0;
  function renderGallery() {
    const G2 = window.M3S.GALLERY;
    $('#gal-tabs').innerHTML = G2.map((g, i) => `<button data-gcat="${i}" class="${i === galCat ? 'on' : ''}">${g.cat}</button>`).join('');
    const items = G2[galCat].items;
    $('#gal-grid').innerHTML = items.map((it, i) => { const t = thumbs.get(it.name); return `<button data-gitem="${i}" title="${esc(it.name)} hinzufügen">${t ? `<img src="${t}" alt=""/>` : '<i></i>'}<span>${esc(it.name)}</span></button>`; }).join('');
    // Vorschaubilder nach und nach berechnen
    const todo = items.filter((it) => !thumbs.has(it.name));
    const next = () => {
      const it = todo.shift(); if (!it || $('#gallery').hidden) return;
      try {
        const meshes = it.parts.map((pt) => { const o = makeObj(pt.kind, { p: pt.p }); nextId -= 1; const at = pt.at || [0, 0, 0]; return G.transform(geom(o), M.trs(at, [0, 0, 0], [1, 1, 1])); });
        thumbs.set(it.name, window.M3S.thumb(G.merge(meshes)));
        const i = G2[galCat].items.indexOf(it); const b = document.querySelector(`[data-gitem="${i}"] i`);
        if (b) b.outerHTML = `<img src="${thumbs.get(it.name)}" alt=""/>`;
      } catch { thumbs.set(it.name, ''); }
      setTimeout(next, 0);
    };
    setTimeout(next, 30);
  }
  function toggleGallery(show = $('#gallery').hidden) {
    $('#gallery').hidden = !show; document.querySelector('[data-gallery]')?.classList.toggle('on', show);
    if (show) renderGallery();
  }
  $('#gallery').addEventListener('click', (e) => {
    const c = e.target.closest('[data-gcat]'); if (c) { galCat = +c.dataset.gcat; renderGallery(); return; }
    if (e.target.closest('#gal-close')) { toggleGallery(false); return; }
    const it = e.target.closest('[data-gitem]'); if (it) addPreset(window.M3S.GALLERY[galCat].items[+it.dataset.gitem]);
  });

  /* --------------------------------------------------------- Ansicht/Kamera */
  const cam = view.cam;
  let anim = null;
  function setView(yaw, pitch, target, dist) {
    const from = { yaw: cam.yaw, pitch: cam.pitch, t: [...cam.target], dist: cam.dist };
    let dy = ((yaw - from.yaw + 540) % 360) - 180;
    const to = { yaw: from.yaw + dy, pitch, t: target || from.t, dist: dist || from.dist };
    const t0 = performance.now();
    cancelAnimationFrame(anim);
    const step = () => {
      const k = Math.min(1, (performance.now() - t0) / 260); const e = 1 - (1 - k) ** 3;
      cam.yaw = from.yaw + (to.yaw - from.yaw) * e; cam.pitch = from.pitch + (to.pitch - from.pitch) * e; cam.dist = from.dist + (to.dist - from.dist) * e;
      cam.target = from.t.map((v, i) => v + (to.t[i] - v) * e);
      draw();
      if (k < 1) anim = requestAnimationFrame(step);
    };
    step();
  }
  function fit() {
    const list = selected().length ? selected() : visible();
    const b = list.length ? unionBox(list) : { c: [0, 0, 0], s: [bed.w, bed.d, 20] };
    const r = Math.max(12, Math.hypot(...b.s) / 2);
    setView(cam.yaw, cam.pitch, b.c, (r / Math.sin((cam.fov * Math.PI) / 360)) * 1.1);
  }
  const home = () => setView(-60, 32, [0, 0, 10], Math.max(bed.w, bed.d) * 1.55);
  const VIEWS = { top: [-90, 90], bottom: [-90, -90], front: [-90, 0], back: [90, 0], right: [0, 0], left: [180, 0] };

  /* ------------------------------------------------------------ Zeichnen */
  let pending = false;
  function draw() { if (pending) return; pending = true; requestAnimationFrame(() => { pending = false; paint(); }); }
  let handles = [];
  let drag = null;
  let cubeFaces = [];

  function outsideBed(o) {
    const { bb } = world(o); const t = 0.01;
    return bb.min[0] < -bed.w / 2 - t || bb.max[0] > bed.w / 2 + t || bb.min[1] < -bed.d / 2 - t || bb.max[1] > bed.d / 2 + t || bb.max[2] > bed.h + t || bb.min[2] < -t;
  }
  function paint() {
    const items = visible().map((o) => ({ mesh: geom(o), model: mat(o), color: o.color, hole: o.hole, sel: sel.includes(o.id) }));
    const lines = [];
    const sb = unionBox(selected().filter((o) => !o.hidden));
    let footprint = null;
    if (sb) {
      const [a, b] = [sb.min, sb.max]; const z = 0.06;
      footprint = new Float32Array([a[0], a[1], z, b[0], a[1], z, b[0], a[1], z, b[0], b[1], z, b[0], b[1], z, a[0], b[1], z, a[0], b[1], z, a[0], a[1], z]);
      if (sb.min[2] > 0.05) lines.push([new Float32Array([sb.c[0], sb.c[1], z, sb.c[0], sb.c[1], sb.min[2]]), [1, 0.42, 0.36, 0.6]]);
    }
    if (measure?.a) { const b = measure.b || measure.hover || measure.a; lines.push([new Float32Array([...measure.a, ...b]), [1, 0.85, 0.2, 1]]); }
    view.render(items, bed, { footprint, lines, outside: visible().some((o) => !o.hole && outsideBed(o)) });
    paintOverlay(sb);
    $('#empty').hidden = objs.length > 0;
  }

  function label(x, y, text, color = '#fff', bg = 'rgba(14,15,19,.82)') {
    og.font = '600 11px "Segoe UI", system-ui, sans-serif';
    const w = og.measureText(text).width + 10;
    og.fillStyle = bg; og.beginPath(); og.roundRect(x - w / 2, y - 9, w, 18, 5); og.fill();
    og.fillStyle = color; og.textAlign = 'center'; og.textBaseline = 'middle'; og.fillText(text, x, y + 0.5);
  }
  function paintOverlay(sb) {
    const dpr = window.devicePixelRatio || 1; const W = ov.clientWidth, H = ov.clientHeight;
    if (ov.width !== Math.round(W * dpr) || ov.height !== Math.round(H * dpr)) { ov.width = Math.round(W * dpr); ov.height = Math.round(H * dpr); }
    og.setTransform(dpr, 0, 0, dpr, 0, 0); og.clearRect(0, 0, W, H);
    handles = [];
    const P = (p) => view.project(p);
    // Masse der Auswahl
    if (sb && !(drag && drag.kind === 'orbit')) {
      const { min: a, max: b, c } = sb;
      const lx = P([c[0], a[1], a[2]]), ly = P([b[0], c[1], a[2]]), lz = P([b[0], a[1], c[2]]);
      if (lx[2] > 0) label(lx[0], lx[1] + 14, `${fmt(sb.s[0])} mm`, AX[0]);
      if (ly[2] > 0) label(ly[0] + 26, ly[1], `${fmt(sb.s[1])} mm`, AX[1]);
      if (lz[2] > 0 && sb.s[2] > 0) label(lz[0] + 28, lz[1], `${fmt(sb.s[2])} mm`, AX[2]);
    }
    // Gizmo
    const list = selected().filter((o) => !o.hidden);
    if (sb && list.length && ['move', 'rotate', 'scale'].includes(mode)) {
      const c = drag?.gizmo ? drag.c : sb.c; const L = 78 * view.pxSize(c);
      const pc = P(c);
      if (pc[2] > 0) {
        og.lineCap = 'round';
        if (mode === 'move') moveArrows(c, L, 'move');
        else if (mode === 'rotate') {
          const R = L * 0.95;
          for (let k = 0; k < 3; k += 1) {
            const [e1, e2] = basis(k); const pts = [];
            for (let i = 0; i <= 72; i += 1) { const t = (i / 72) * Math.PI * 2; pts.push(P(c.map((v, j) => v + (e1[j] * Math.cos(t) + e2[j] * Math.sin(t)) * R))); }
            const act = drag?.axis === k || hoverH?.axis === k && hoverH.type === 'rotate';
            og.strokeStyle = AX[k]; og.lineWidth = act ? 3.6 : 2.2; og.globalAlpha = drag?.gizmo && drag.axis !== k ? 0.2 : 0.95;
            og.beginPath(); pts.forEach((p, i) => (i ? og.lineTo(p[0], p[1]) : og.moveTo(p[0], p[1]))); og.stroke(); og.globalAlpha = 1;
            handles.push({ type: 'rotate', axis: k, poly: pts });
          }
        } else {
          const o = list[0]; const Rm = M.rot(...o.rot); const single = list.length === 1;
          for (let k = 0; single && k < 3; k += 1) {
            const u = [Rm[0][k], Rm[1][k], Rm[2][k]];
            const p1 = P(c.map((v, i) => v + u[i] * L)); const p0 = P(c.map((v, i) => v + u[i] * L * 0.18));
            og.strokeStyle = AX[k]; og.lineWidth = 2.4; og.globalAlpha = drag?.gizmo && drag.axis !== k ? 0.25 : 1;
            og.beginPath(); og.moveTo(p0[0], p0[1]); og.lineTo(p1[0], p1[1]); og.stroke();
            og.fillStyle = AX[k]; og.fillRect(p1[0] - 6, p1[1] - 6, 12, 12); og.globalAlpha = 1;
            handles.push({ type: 'scale', axis: k, u, pt: p1, r: 10 });
          }
          og.fillStyle = '#fff'; og.strokeStyle = 'rgba(0,0,0,.5)'; og.lineWidth = 1;
          og.fillRect(pc[0] - 7, pc[1] - 7, 14, 14); og.strokeRect(pc[0] - 7, pc[1] - 7, 14, 14);
          handles.push({ type: 'scale', axis: -1, pt: pc, r: 11 });
        }
      }
    }
    // Bearbeiten: Punkte und Pfeile für die Auswahl
    edScreen = [];
    const eo = mode === 'edit' ? edObj() : null;
    if (eo && !eo.hidden) {
      const w = E.weld(eo.mesh); const m = mat(eo); const many = w.count > 6000;
      for (let v = 0; v < w.count; v += 1) {
        const on = ed.sel.has(v); if (many && !on) { edScreen.push(null); continue; }
        const s = P(M.pt(m, [w.pos[v * 3], w.pos[v * 3 + 1], w.pos[v * 3 + 2]])); edScreen.push(s);
        if (s[2] <= 0) continue;
        if (on) { og.fillStyle = '#ffb020'; og.fillRect(s[0] - 3.5, s[1] - 3.5, 7, 7); }
        else if (ed.sub === 'vert') { og.fillStyle = 'rgba(235,240,255,.85)'; og.fillRect(s[0] - 2, s[1] - 2, 4, 4); }
      }
      if (many && ed.sub === 'vert') label(W / 2, 20, `${w.count.toLocaleString('de-CH')} Punkte – zu viele zum Anzeigen, „Flächen“ verwenden`, '#ffc874');
      const c = drag?.edit ? drag.c : edCentroid(eo);
      if (c && P(c)[2] > 0) moveArrows(c, 70 * view.pxSize(c), 'emove');
    }
    if (drag?.info) label(drag.mx, drag.my - 26, drag.info, '#fff', 'rgba(255,59,48,.92)');
    // Messung
    if (measure?.a) {
      const b = measure.b || measure.hover;
      const pa = P(measure.a);
      og.fillStyle = '#ffd43b'; og.beginPath(); og.arc(pa[0], pa[1], 4, 0, 7); og.fill();
      if (b) {
        const pb = P(b); og.beginPath(); og.arc(pb[0], pb[1], 4, 0, 7); og.fill();
        const d = b.map((v, i) => v - measure.a[i]);
        label((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2 - 14, `${fmt(Math.hypot(...d), 2)} mm`, '#ffd43b');
        label((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2 + 8, `ΔX ${fmt(d[0], 2)}  ΔY ${fmt(d[1], 2)}  ΔZ ${fmt(d[2], 2)}`, '#ddd');
      }
    }
    // Aufziehrahmen
    if (drag?.kind === 'box' && drag.moved) {
      og.strokeStyle = 'rgba(255,90,80,.9)'; og.fillStyle = 'rgba(255,90,80,.08)'; og.lineWidth = 1;
      const x = Math.min(drag.x0, drag.mx), y = Math.min(drag.y0, drag.my), w = Math.abs(drag.mx - drag.x0), h = Math.abs(drag.my - drag.y0);
      og.fillRect(x, y, w, h); og.strokeRect(x + 0.5, y + 0.5, w, h);
    }
    paintCube(W);
  }
  function moveArrows(c, L, type) {
    const P = (p) => view.project(p);
    for (let k = 0; k < 3; k += 1) {
      const e = [0, 0, 0]; e[k] = 1;
      const p1 = P(c.map((v, i) => v + e[i] * L)); const p0 = P(c.map((v, i) => v + e[i] * L * 0.18));
      const act = drag?.axis === k || (hoverH?.axis === k && hoverH.type === type);
      og.strokeStyle = AX[k]; og.lineWidth = act ? 4 : 2.6; og.globalAlpha = drag?.gizmo && drag.axis !== k ? 0.25 : 1;
      og.beginPath(); og.moveTo(p0[0], p0[1]); og.lineTo(p1[0], p1[1]); og.stroke();
      const ang = Math.atan2(p1[1] - p0[1], p1[0] - p0[0]);
      og.fillStyle = AX[k]; og.beginPath(); og.moveTo(p1[0] + Math.cos(ang) * 11, p1[1] + Math.sin(ang) * 11);
      og.lineTo(p1[0] + Math.cos(ang + 2.5) * 8, p1[1] + Math.sin(ang + 2.5) * 8); og.lineTo(p1[0] + Math.cos(ang - 2.5) * 8, p1[1] + Math.sin(ang - 2.5) * 8); og.fill();
      og.globalAlpha = 1;
      handles.push({ type, axis: k, seg: [p0, [p1[0] + Math.cos(ang) * 11, p1[1] + Math.sin(ang) * 11]] });
    }
  }
  function basis(k) { return k === 0 ? [[0, 1, 0], [0, 0, 1]] : k === 1 ? [[0, 0, 1], [1, 0, 0]] : [[1, 0, 0], [0, 1, 0]]; }

  // Ansichtswürfel oben rechts
  function paintCube(W) {
    const m = view.view; const r = [m[0], m[4], m[8]], u = [m[1], m[5], m[9]], f = [m[2], m[6], m[10]];
    const cx = W - 52, cy = 54, s = 26;
    const pt = (p) => [cx + s * G.dot(r, p), cy - s * G.dot(u, p)];
    const F = [
      ['top', 'Oben', [0, 0, 1]], ['bottom', 'Unten', [0, 0, -1]], ['front', 'Vorne', [0, -1, 0]],
      ['back', 'Hinten', [0, 1, 0]], ['right', 'Rechts', [1, 0, 0]], ['left', 'Links', [-1, 0, 0]],
    ];
    cubeFaces = [];
    const faces = F.map(([id, name, n]) => {
      const a = n.findIndex((v) => v !== 0); const b = (a + 1) % 3, c = (a + 2) % 3;
      const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([x, y]) => { const p = [0, 0, 0]; p[a] = n[a]; p[b] = x; p[c] = y; return pt(p); });
      return { id, name, n, corners, depth: G.dot(f, n) };
    }).filter((x) => x.depth > 0.02).sort((a, b) => a.depth - b.depth);
    og.lineWidth = 1;
    for (const fc of faces) {
      const hov = hoverCube === fc.id;
      og.fillStyle = hov ? 'rgba(255,59,48,.85)' : `rgba(${38 + fc.depth * 22},${40 + fc.depth * 22},${48 + fc.depth * 24},.94)`;
      og.strokeStyle = 'rgba(255,255,255,.22)';
      og.beginPath(); fc.corners.forEach((p, i) => (i ? og.lineTo(p[0], p[1]) : og.moveTo(p[0], p[1]))); og.closePath(); og.fill(); og.stroke();
      if (fc.depth > 0.3) {
        const mx = fc.corners.reduce((s, p) => s + p[0], 0) / 4, my = fc.corners.reduce((s, p) => s + p[1], 0) / 4;
        og.globalAlpha = Math.min(1, (fc.depth - 0.3) * 2.5); og.fillStyle = '#e8e8ee'; og.font = '600 9.5px "Segoe UI", sans-serif'; og.textAlign = 'center'; og.textBaseline = 'middle';
        og.fillText(fc.name, mx, my); og.globalAlpha = 1;
      }
      cubeFaces.push(fc);
    }
    // Achsen am Würfel
    for (let k = 0; k < 3; k += 1) {
      const e = [0, 0, 0]; e[k] = 1.55; const o = pt([-1.15, -1.15, -1.15]); const p = pt(e.map((v, i) => v - 1.15 + (i === k ? 0 : 0)));
      og.strokeStyle = AX[k]; og.lineWidth = 2; og.beginPath(); og.moveTo(o[0], o[1]); og.lineTo(p[0], p[1]); og.stroke();
    }
  }
  const inPoly = (x, y, pts) => { let c = false; for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) { const [xi, yi] = pts[i], [xj, yj] = pts[j]; if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c; } return c; };
  const segDist = (x, y, a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1]; const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / (dx * dx + dy * dy || 1))); return Math.hypot(x - a[0] - t * dx, y - a[1] - t * dy); };

  /* -------------------------------------------------------------- Picking */
  function pick(x, y) {
    const { o, d } = view.ray(x, y); let best = null;
    for (const ob of visible()) {
      const e = world(ob); const bb = e.bb;
      if (!rayBox(o, d, bb)) continue;
      const t = G.raycast(e.arr, o, d);
      if (t < Infinity && (!best || t < best.t)) best = { obj: ob, t };
    }
    if (best) best.p = o.map((v, i) => v + d[i] * best.t);
    return best;
  }
  function rayBox(o, d, bb) {
    let t0 = -Infinity, t1 = Infinity;
    for (let k = 0; k < 3; k += 1) {
      if (Math.abs(d[k]) < 1e-12) { if (o[k] < bb.min[k] - 1e-3 || o[k] > bb.max[k] + 1e-3) return false; continue; }
      let a = (bb.min[k] - 1e-3 - o[k]) / d[k], b = (bb.max[k] + 1e-3 - o[k]) / d[k]; if (a > b) [a, b] = [b, a];
      t0 = Math.max(t0, a); t1 = Math.min(t1, b);
    }
    return t1 >= Math.max(t0, 0);
  }
  function planeHit(x, y, z = 0) { const { o, d } = view.ray(x, y); if (Math.abs(d[2]) < 1e-9) return null; const t = (z - o[2]) / d[2]; return t > 0 ? o.map((v, i) => v + d[i] * t) : null; }
  function faceNormal(x, y, obj) {
    const { o, d } = view.ray(x, y); const a = world(obj).arr; let best = Infinity, n = null;
    for (let i = 0; i < a.length; i += 9) {
      const t = G.raycast(a.subarray(i, i + 9), o, d);
      if (t < best) { best = t; const u = [a[i + 3] - a[i], a[i + 4] - a[i + 1], a[i + 5] - a[i + 2]], v = [a[i + 6] - a[i], a[i + 7] - a[i + 1], a[i + 8] - a[i + 2]]; n = G.nrm(G.cross(u, v)); }
    }
    return n;
  }
  // Parameter s auf Achse (c + s·a), der dem Mausstrahl am nächsten liegt
  function axisParam(c, a, x, y) {
    const { o, d } = view.ray(x, y); const w = c.map((v, i) => v - o[i]);
    const b = G.dot(a, d), e = G.dot(a, w), f = G.dot(d, w); const den = 1 - b * b;
    if (den < 1e-6) return null;
    return (b * f - e) / den;
  }

  /* ---------------------------------------------------------------- Maus */
  let hoverH = null, hoverCube = null;
  function handleAt(x, y) {
    for (const h of handles) {
      if (h.seg && segDist(x, y, h.seg[0], h.seg[1]) < 9) return h;
      if (h.poly) { for (let i = 1; i < h.poly.length; i += 1) if (segDist(x, y, h.poly[i - 1], h.poly[i]) < 7) return h; }
      if (h.pt && Math.hypot(x - h.pt[0], y - h.pt[1]) < h.r) return h;
    }
    return null;
  }
  const cubeAt = (x, y) => { for (let i = cubeFaces.length - 1; i >= 0; i -= 1) if (inPoly(x, y, cubeFaces[i].corners)) return cubeFaces[i].id; return null; };
  const pos = (e) => { const r = ov.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };

  ov.addEventListener('contextmenu', (e) => e.preventDefault());
  ov.addEventListener('pointerdown', (e) => {
    const [x, y] = pos(e);
    ov.setPointerCapture(e.pointerId);
    $('#export-menu').hidden = true;
    if (e.button === 1 || (e.button === 2 && e.shiftKey)) { drag = { kind: 'pan', lx: x, ly: y }; return; }
    if (e.button === 2 || (e.button === 0 && e.altKey)) { drag = { kind: 'orbit', lx: x, ly: y }; return; }
    if (e.button !== 0) return;
    const face = cubeAt(x, y);
    if (face) { const [yw, pt] = VIEWS[face]; setView(yw, pt); return; }
    if (mode === 'measure') {
      const h = pick(x, y); const p = h ? h.p : planeHit(x, y);
      if (!p) return;
      if (!measure || measure.b) measure = { a: p }; else measure.b = p;
      draw(); return;
    }
    const h = handleAt(x, y);
    if (h) return startGizmo(h, x, y);
    if (mode === 'edit' && ed) return editDown(e, x, y);
    const hit = pick(x, y);
    if (mode === 'flat') {
      if (hit) { const n = faceNormal(x, y, hit.obj); if (n) { sel = [hit.obj.id]; layFlat(hit.obj, n); } }
      return;
    }
    if (hit) {
      if (e.shiftKey || e.ctrlKey) { sel = sel.includes(hit.obj.id) ? sel.filter((i) => i !== hit.obj.id) : [...sel, hit.obj.id]; refresh(); }
      else if (!sel.includes(hit.obj.id)) { sel = [hit.obj.id]; refresh(); }
      if (!sel.includes(hit.obj.id)) return;
      const list = selected();
      drag = { kind: 'plane', z: hit.p[2], p0: hit.p, x0: x, y0: y, hit: hit.obj.id, add: e.shiftKey || e.ctrlKey, start: list.map((o) => [o, [...o.pos]]) };
    } else {
      drag = { kind: 'box', x0: x, y0: y, mx: x, my: y, add: e.shiftKey || e.ctrlKey };
    }
  });
  function pickTri(o, x, y) {
    const { o: ro, d } = view.ray(x, y); const a = world(o).arr; let best = Infinity, ti = -1;
    for (let i = 0; i < a.length; i += 9) { const t = G.raycast(a.subarray(i, i + 9), ro, d); if (t < best) { best = t; ti = i / 9; } }
    return ti;
  }
  function editDown(e, x, y) {
    const o = edObj(); if (!o) return;
    const add = e.shiftKey || e.ctrlKey;
    if (ed.sub === 'vert') {
      let best = -1, bd = 9;
      edScreen.forEach((s, v) => { if (s && s[2] > 0) { const d = Math.hypot(s[0] - x, s[1] - y); if (d < bd) { bd = d; best = v; } } });
      if (best >= 0) {
        if (add) { if (ed.sel.has(best)) ed.sel.delete(best); else ed.sel.add(best); } else if (!ed.sel.has(best)) ed.sel = new Set([best]);
        refresh(true); draw();
        if (!ed.sel.has(best)) return;
        const w = E.weld(o.mesh); const m = view.view;
        drag = { kind: 'evert', edit: true, x0: x, y0: y, p0: M.pt(mat(o), [w.pos[best * 3], w.pos[best * 3 + 1], w.pos[best * 3 + 2]]), f: [m[2], m[6], m[10]], mesh0: o.mesh, c: edCentroid(o) };
        return;
      }
    } else {
      const t = pickTri(o, x, y);
      if (t >= 0) {
        const r = E.flatRegion(o.mesh, t);
        if (add) for (const v of r.verts) ed.sel.add(v); else ed.sel = new Set(r.verts);
        refresh(true); draw();
        const n = G.nrm(M.dir(mat(o), r.normal)); const c = edCentroid(o);
        drag = { kind: 'eface', edit: true, x0: x, y0: y, a: n, c, s0: axisParam(c, n, x, y) ?? 0, mesh0: o.mesh };
        return;
      }
    }
    drag = { kind: 'box', x0: x, y0: y, mx: x, my: y, add, edit: true };
  }
  function startGizmo(h, x, y) {
    if (h.type === 'emove') {
      const o = edObj(); const c = edCentroid(o); const a = [0, 0, 0]; a[h.axis] = 1;
      drag = { kind: 'emove', gizmo: true, edit: true, axis: h.axis, a, c, x0: x, y0: y, s0: axisParam(c, a, x, y) ?? 0, mesh0: o.mesh };
      return;
    }
    const list = selected(); const sb = unionBox(list); const c = [...sb.c];
    const d = { kind: h.type, gizmo: true, axis: h.axis, c, x0: x, y0: y, start: list.map((o) => [o, clone(o)]), sb };
    if (h.type === 'move') { const a = [0, 0, 0]; a[h.axis] = 1; d.a = a; d.s0 = axisParam(c, a, x, y) ?? 0; }
    if (h.type === 'rotate') { d.ang0 = ringAngle(h.axis, c, x, y); d.acc = 0; }
    if (h.type === 'scale') {
      if (h.axis >= 0) { d.a = h.u; d.s0 = axisParam(c, h.u, x, y) || 1; } else { d.py = y; }
      d.size0 = list.length === 1 ? localSize(list[0]) : null; d.pivot = [sb.c[0], sb.c[1], sb.min[2]];
    }
    drag = d;
  }
  function ringAngle(k, c, x, y) {
    const { o, d } = view.ray(x, y); const n = [0, 0, 0]; n[k] = 1;
    const den = G.dot(n, d); let q;
    if (Math.abs(den) < 1e-4) { const t = G.dot(c.map((v, i) => v - o[i]), d); q = o.map((v, i) => v + d[i] * t); }
    else { const t = G.dot(c.map((v, i) => v - o[i]), n) / den; q = o.map((v, i) => v + d[i] * t); }
    const [e1, e2] = basis(k); const w = q.map((v, i) => v - c[i]);
    return (Math.atan2(G.dot(w, e2), G.dot(w, e1)) * 180) / Math.PI;
  }

  ov.addEventListener('pointermove', (e) => {
    const [x, y] = pos(e);
    if (!drag) {
      const hc = cubeAt(x, y); const hh = hc ? null : handleAt(x, y);
      if (hc !== hoverCube || hh?.axis !== hoverH?.axis || hh?.type !== hoverH?.type) { hoverCube = hc; hoverH = hh; draw(); }
      if (mode === 'measure' && measure?.a && !measure.b) { const h = pick(x, y); measure.hover = h ? h.p : planeHit(x, y); draw(); }
      ov.style.cursor = hc || hh ? 'pointer' : mode === 'measure' || mode === 'flat' ? 'crosshair' : 'default';
      return;
    }
    drag.mx = x; drag.my = y;
    const dx = x - (drag.lx ?? x), dy = y - (drag.ly ?? y); drag.lx = x; drag.ly = y;
    if (drag.kind === 'orbit') { cancelAnimationFrame(anim); cam.yaw -= dx * 0.4; cam.pitch = Math.max(-89.9, Math.min(89.9, cam.pitch + dy * 0.4)); draw(); return; }
    if (drag.kind === 'pan') {
      cancelAnimationFrame(anim);
      const m = view.view; const px = view.pxSize(cam.target); const r = [m[0], m[4], m[8]], u = [m[1], m[5], m[9]];
      cam.target = cam.target.map((v, i) => v - r[i] * dx * px + u[i] * dy * px); draw(); return;
    }
    if (drag.kind === 'box') { drag.moved = Math.hypot(x - drag.x0, y - drag.y0) > 3; draw(); return; }
    if (!drag.moved) { if (Math.hypot(x - drag.x0, y - drag.y0) < 3) return; drag.moved = true; checkpoint(); }
    if (drag.edit) {
      const o = edObj(); if (!o) return;
      let dw;
      if (drag.kind === 'evert') {
        const { o: ro, d } = view.ray(x, y); const den = G.dot(d, drag.f); if (Math.abs(den) < 1e-9) return;
        const t = G.dot(drag.p0.map((v, i) => v - ro[i]), drag.f) / den; dw = ro.map((v, i) => snapV(v + d[i] * t - drag.p0[i]));
      } else {
        const s = axisParam(drag.c, drag.a, x, y); if (s == null) return; const dd = snapV(s - drag.s0); dw = drag.a.map((v) => v * dd);
      }
      o.mesh = E.moveVerts(drag.mesh0, ed.sel, M.dir(M.inv(mat(o)), dw));
      drag.c2 = dw; drag.info = drag.kind === 'eface' ? `${fmt(Math.hypot(...dw) * Math.sign(G.dot(dw, drag.a) || 1), 2)} mm` : `ΔX ${fmt(dw[0], 2)}  ΔY ${fmt(dw[1], 2)}  ΔZ ${fmt(dw[2], 2)}`;
      refresh(true); return;
    }
    if (drag.kind === 'plane') {
      const p = planeHit(x, y, drag.z); if (!p) return;
      let ddx = snapV(p[0] - drag.p0[0]), ddy = snapV(p[1] - drag.p0[1]);
      if (e.shiftKey) { if (Math.abs(ddx) > Math.abs(ddy)) ddy = 0; else ddx = 0; }
      for (const [o, s] of drag.start) { o.pos[0] = s[0] + ddx; o.pos[1] = s[1] + ddy; }
      drag.info = `ΔX ${fmt(ddx, 2)}  ΔY ${fmt(ddy, 2)} mm`;
    } else if (drag.kind === 'move') {
      const s = axisParam(drag.c, drag.a, x, y); if (s == null) return;
      const dd = snapV(s - drag.s0);
      for (const [o, s0] of drag.start) { o.pos = [...s0.pos]; o.pos[drag.axis] += dd; }
      drag.info = `${AXN[drag.axis]} ${dd >= 0 ? '+' : ''}${fmt(dd, 2)} mm`;
    } else if (drag.kind === 'rotate') {
      const a = ringAngle(drag.axis, drag.c, x, y); let da = ((a - drag.ang0 + 540) % 360) - 180; drag.ang0 = a; drag.acc += da;
      const step = e.shiftKey ? 1 : 15; const ang = Math.round(drag.acc / step) * step;
      const Rk = M.axisRot(drag.axis, ang);
      for (const [o, s0] of drag.start) {
        o.rot = M.euler(M.m3mul(Rk, M.rot(...s0.rot))).map((v) => Math.round(v * 1e4) / 1e4);
        const w = s0.pos.map((v, i) => v - drag.c[i]);
        o.pos = [0, 1, 2].map((i) => drag.c[i] + Rk[i][0] * w[0] + Rk[i][1] * w[1] + Rk[i][2] * w[2]);
      }
      drag.info = `${AXN[drag.axis]} ${ang}°`;
    } else if (drag.kind === 'scale') {
      let f;
      if (drag.axis >= 0) { const s = axisParam(drag.c, drag.a, x, y); if (s == null) return; f = Math.max(0.01, s / drag.s0); }
      else f = Math.max(0.01, Math.exp(-(y - drag.y0) / 120) * Math.exp((x - drag.x0) / 240));
      if (drag.size0 && snap > 0) {
        const k = drag.axis >= 0 ? drag.axis : 2; const target = Math.max(snap, snapV(drag.size0[k] * f)); f = target / drag.size0[k];
      }
      for (const [o, s0] of drag.start) {
        o.scl = [...s0.scl];
        if (drag.axis >= 0) o.scl[drag.axis] = s0.scl[drag.axis] * f;
        else {
          o.scl = s0.scl.map((v) => v * f);
          if (drag.start.length > 1) o.pos = s0.pos.map((v, i) => drag.pivot[i] + (v - drag.pivot[i]) * f);
        }
      }
      const o = drag.start[0][0];
      drag.info = drag.start.length === 1 ? localSize(o).map((v) => fmt(v, 2)).join(' × ') + ' mm' : `${fmt(f * 100, 1)} %`;
    }
    refresh(true);
  });
  ov.addEventListener('pointerup', (e) => {
    const [x, y] = pos(e);
    const d = drag; drag = null;
    if (!d) return;
    if (d.kind === 'box' && d.edit) {
      if (d.moved) {
        const x0 = Math.min(d.x0, x), x1 = Math.max(d.x0, x), y0 = Math.min(d.y0, y), y1 = Math.max(d.y0, y); const hits = [];
        edScreen.forEach((s, v) => { if (s && s[2] > 0 && s[0] >= x0 && s[0] <= x1 && s[1] >= y0 && s[1] <= y1) hits.push(v); });
        ed.sel = d.add ? new Set([...ed.sel, ...hits]) : new Set(hits);
      } else if (!d.add) ed.sel = new Set();
      refresh(); return;
    }
    if (d.kind === 'box') {
      if (d.moved) {
        const x0 = Math.min(d.x0, x), x1 = Math.max(d.x0, x), y0 = Math.min(d.y0, y), y1 = Math.max(d.y0, y);
        const hits = visible().filter((o) => { const { bb } = world(o); const p = view.project(bb.min.map((v, i) => (v + bb.max[i]) / 2)); return p[2] > 0 && p[0] >= x0 && p[0] <= x1 && p[1] >= y0 && p[1] <= y1; }).map((o) => o.id);
        sel = d.add ? [...new Set([...sel, ...hits])] : hits;
      } else if (!d.add) sel = [];
      refresh(); return;
    }
    if (d.kind === 'plane' && !d.moved && !d.add && sel.length > 1) sel = [d.hit];
    refresh();
  });
  ov.addEventListener('wheel', (e) => {
    e.preventDefault(); cancelAnimationFrame(anim);
    const [x, y] = pos(e); const f = Math.exp(Math.max(-0.5, Math.min(0.5, e.deltaY * 0.0012)));
    const nd = Math.max(4, Math.min(8000, cam.dist * f)); const k = nd / cam.dist;
    const h = pick(x, y); const p = h ? h.p : planeHit(x, y);
    if (p && Math.hypot(...p.map((v, i) => v - cam.target[i])) < cam.dist * 6) cam.target = cam.target.map((v, i) => p[i] + (v - p[i]) * k);
    cam.dist = nd; draw();
  }, { passive: false });
  new ResizeObserver(() => draw()).observe($('#stage'));

  /* ---------------------------------------------------------- Oberfläche */
  const FILE_BTNS = [['neu', 'Neues Projekt (Strg+N)', () => newProject()], ['open', 'Projekt öffnen (Strg+O)', () => openProject()], ['save', 'Projekt speichern (Strg+S)', () => saveProject()], ['import', 'STL / OBJ / 3MF importieren (Strg+I)', () => importFile()]];
  const HIST_BTNS = [['undo', 'Rückgängig (Strg+Z)', undo], ['redo', 'Wiederholen (Strg+Y)', redo]];
  const MODES = [['select', 'Auswählen (Q)'], ['move', 'Verschieben (G / W)'], ['rotate', 'Drehen (R / E)'], ['scale', 'Skalieren (S)'], ['edit', 'Punkte und Flächen bearbeiten (Tab)'], ['flat', 'Fläche auf Bett legen (L)'], ['measure', 'Messen (M)']];
  const HINTS = {
    select: 'Klicken zum Auswählen, Umschalt + Klick für mehrere, auf leerer Fläche aufziehen für einen Rahmen.',
    move: 'Objekt auf dem Bett ziehen oder an den Pfeilen X / Y / Z ziehen. Umschalt sperrt eine Richtung. Pfeiltasten verschieben um das Raster.',
    rotate: 'An einem Ring ziehen: dreht in 15°-Schritten, mit Umschalt in 1°-Schritten.',
    scale: 'An den farbigen Griffen ziehen (eine Achse) oder am weissen Griff (gleichmässig).',
    edit: 'Punkte oder Flächen anklicken und ziehen (Umschalt: mehrere, Rahmen aufziehen). Pfeile bewegen genau entlang einer Achse. Tab beendet.',
    flat: 'Auf eine Fläche eines Objekts klicken – das Objekt wird so gedreht, dass diese Fläche auf dem Bett liegt.',
    measure: 'Zwei Punkte anklicken, um den Abstand zu messen. Esc beendet die Messung.',
  };
  function buildChrome() {
    $('#file-btns').innerHTML = FILE_BTNS.map(([k, t]) => `<button data-file="${k}" title="${t}">${I[k]}</button>`).join('');
    $('#hist-btns').innerHTML = HIST_BTNS.map(([k, t]) => `<button data-hist="${k}" title="${t}">${I[k]}</button>`).join('');
    $('#mode-btns').innerHTML = MODES.map(([k, t]) => `<button data-mode="${k}" title="${t}" role="radio">${I[k]}</button>`).join('');
    const shapes = Object.entries(SHAPES).filter(([, s]) => !s.cat).map(([k, s]) => `<button data-add="${k}" title="${s.name} hinzufügen">${I[k]}<span>${s.name}</span></button>`).join('');
    $('#shapes').innerHTML = `${shapes}<hr/><button data-add="box" data-hole="1" class="hole" title="Loch (Würfel) – wird beim Gruppieren abgezogen">${I.holeBox}<span>Loch</span></button><button data-add="cyl" data-hole="1" class="hole" title="Loch (Zylinder) – wird beim Gruppieren abgezogen">${I.holeCyl}<span>Bohrung</span></button><hr/><button data-gallery title="Formen-Galerie: Zahnrad, Stern, Gewinde, Haken, Box mit Deckel …">${I.gallery}<span>Formen</span></button>`;
    const T = window.M3Tour;
    $('#help-menu').innerHTML = `<button data-tour="basics"><b>Einführung: Grundlagen</b><small>Form, Masse, Loch, Gruppieren, Export · 2 Min.</small></button>
      <button data-tour="edit"><b>Einführung: Formen und Bearbeiten</b><small>Galerie, Punkte, Flächen, Extrudieren, Verformen</small></button>
      <h4>Tastenkürzel</h4><div class="m-keys">${T.KEYS.map(([k, v]) => `<kbd>${esc(k)}</kbd><span>${esc(v)}</span>`).join('')}</div>
      <h4>Tipps für den 3D-Druck</h4><ul>${T.TIPS.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>`;
    $('#empty-tip').textContent = `Tipp: ${T.TIPS[Math.floor(Math.random() * T.TIPS.length)]}`;
    $('#bed').innerHTML = BEDS.map(([id, n, w, d, h]) => `<option value="${id}">${esc(n)}${id === 'custom' ? '' : ` · ${w}×${d}`}</option>`).join('');
    document.addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) { if (!e.target.closest('.m-export')) { $('#export-menu').hidden = true; $('#help-menu').hidden = true; } return; }
      if (!b.closest('.m-help')) $('#help-menu').hidden = true;
      if (b.id === 'help-btn') { $('#help-menu').hidden = !$('#help-menu').hidden; return; }
      if (b.dataset.tour) { $('#help-menu').hidden = true; tour.start(b.dataset.tour); return; }
      if (b.id === 'empty-tour') { tour.start('basics'); return; }
      if (b.hasAttribute('data-gallery')) { toggleGallery(); return; }
      if (b.dataset.file) FILE_BTNS.find((f) => f[0] === b.dataset.file)[2]();
      else if (b.dataset.hist) HIST_BTNS.find((f) => f[0] === b.dataset.hist)[2]();
      else if (b.dataset.mode) setMode(b.dataset.mode);
      else if (b.dataset.add) { const o = add(b.dataset.add, b.dataset.hole ? { hole: true, color: '#9aa6bd' } : {}); if (o.kind === 'text') setTimeout(() => document.querySelector('[data-param="t"]')?.select(), 30); }
      else if (b.dataset.view) { const v = b.dataset.view; if (v === 'home') home(); else if (v === 'fit') fit(); else { cam.ortho = !cam.ortho; $('#ortho-btn').textContent = cam.ortho ? 'Ortho.' : 'Persp.'; draw(); } }
      else if (b.id === 'export-btn') $('#export-menu').hidden = !$('#export-menu').hidden;
      else if (b.dataset.export) { $('#export-menu').hidden = true; exportAs(b.dataset.export); }
      if (!b.closest('.m-export')) $('#export-menu').hidden = true;
    });
    $('#snap').addEventListener('change', (e) => { snap = num(e.target.value) || 0; saveSettings(); });
    $('#bed').addEventListener('change', (e) => { setBed(e.target.value); saveSettings(); });
    for (const k of ['w', 'd', 'h']) $(`#bed-${k}`).addEventListener('change', (e) => { const v = num(e.target.value); if (v >= 20 && v <= 2000) { bed[k] = v; saveSettings(); refresh(); } });
  }
  function setBed(id, dims) {
    const b = BEDS.find((x) => x[0] === id) || BEDS[0];
    bed = { id: b[0], w: dims?.w || b[2], d: dims?.d || b[3], h: dims?.h || b[4] };
    if (id !== 'custom') bed = { id: b[0], w: b[2], d: b[3], h: b[4] };
    $('#bed').value = bed.id; $('#bed-custom').hidden = bed.id !== 'custom';
    for (const k of ['w', 'd', 'h']) $(`#bed-${k}`).value = bed[k];
    refresh();
  }
  function setMode(m) {
    if (m === 'edit' && mode !== 'edit' && !enterEdit()) return;
    if (m !== 'edit') ed = null;
    const changed = (mode === 'edit') !== (m === 'edit');
    mode = m; if (m !== 'measure') measure = null;
    if (changed) renderProps();
    document.querySelectorAll('[data-mode]').forEach((b) => { b.classList.toggle('on', b.dataset.mode === m); b.setAttribute('aria-checked', b.dataset.mode === m); });
    $('#hint').textContent = HINTS[m];
    draw();
  }

  // Seitenleiste
  function renderList() {
    $('#obj-count').textContent = objs.length ? `${objs.length}` : '';
    $('#obj-list').innerHTML = objs.length ? objs.map((o) => `<div class="m-row${sel.includes(o.id) ? ' on' : ''}${o.hidden ? ' off' : ''}" data-obj="${o.id}"><i class="${o.hole ? 'hole' : ''}" style="background:${esc(o.color)}"></i><span>${esc(o.name)}</span>${o.hole ? '<em>Loch</em>' : ''}${outsideBed(o) && !o.hole && !o.hidden ? '<em style="color:#ff8a80">ausserhalb</em>' : ''}<button data-eye="${o.id}" title="${o.hidden ? 'Einblenden' : 'Ausblenden'}">${o.hidden ? I.eyeOff : I.eye}</button></div>`).join('') : '<div class="m-none">Noch keine Objekte.</div>';
  }
  $('#obj-list').addEventListener('click', (e) => {
    const eye = e.target.closest('[data-eye]');
    if (eye) { const o = byId(+eye.dataset.eye); checkpoint(); o.hidden = !o.hidden; if (o.hidden) sel = sel.filter((i) => i !== o.id); refresh(); return; }
    const row = e.target.closest('[data-obj]'); if (!row) return;
    const id = +row.dataset.obj;
    if (e.shiftKey || e.ctrlKey) sel = sel.includes(id) ? sel.filter((i) => i !== id) : [...sel, id]; else sel = [id];
    refresh();
  });
  $('#obj-list').addEventListener('dblclick', (e) => { if (e.target.closest('[data-obj]')) setTimeout(() => $('#f-name')?.select(), 10); });

  const xyz = (key, vals, step, unit) => `<div class="m-xyz">${vals.map((v, k) => `<label><b class="ax${k}">${AXN[k]}</b><input data-${key}="${k}" type="text" inputmode="decimal" value="${fmt(v, 2)}" title="${AXN[k]} (${unit})" /></label>`).join('')}</div>`;
  function renderEditProps() {
    const o = edObj(); const w = E.weld(o.mesh); const c = edCentroid(o); const n = ed.sel.size;
    $('#props').innerHTML = `<h3>Bearbeiten <small>${esc(o.name)} · ${w.count.toLocaleString('de-CH')} Punkte</small></h3>
      <div class="m-field"><span>Auswahl</span><div class="m-seg"><button data-esub="vert" class="${ed.sub === 'vert' ? 'on' : ''}">Punkte</button><button data-esub="face" class="${ed.sub === 'face' ? 'on' : ''}">Flächen</button></div></div>
      <div class="m-edinfo">${n ? `<b>${n}</b> Punkt${n > 1 ? 'e' : ''} gewählt. Ziehen verschiebt sie, die Pfeile bewegen genau entlang X, Y oder Z.` : ed.sub === 'vert' ? 'Punkt anklicken (Umschalt für mehrere) oder einen Rahmen aufziehen.' : 'Fläche anklicken – zusammenhängende ebene Flächen werden ganz gewählt. Ziehen schiebt die Fläche entlang ihrer Richtung.'}</div>
      ${c ? `<div class="m-field"><span>Mitte</span>${xyz('epos', c, snap, 'mm')}</div>` : ''}
      <div class="m-sub">Extrudieren</div>
      <div class="m-inline"><input id="e-dist" type="text" inputmode="decimal" value="${fmt(extrudeDist, 2)}" title="Abstand in mm – negativ drückt eine Tasche hinein"/><button class="m-act main" data-ed="extrude"${n ? '' : ' disabled'}>Fläche extrudieren</button></div>
      <div class="m-sub">Ganzes Objekt</div>
      <div class="m-acts">
        <button class="m-act" data-ed="all" title="Strg+A">Alle Punkte</button><button class="m-act" data-ed="none">Keine</button><button class="m-act" data-ed="subdiv" title="Jedes Dreieck in vier teilen – mehr Punkte zum Formen">Unterteilen</button>
        <button class="m-act" data-ed="smooth" title="Unterteilen und weich machen">Glätten</button><button class="m-act" data-ed="drop">Auf Bett</button><button class="m-act main" data-ed="done" title="Tab">Fertig</button>
      </div>`;
  }
  function renderProps() {
    const list = selected();
    const el = $('#props');
    if (mode === 'edit' && ed && edObj()) { renderEditProps(); return; }
    if (!list.length) { el.innerHTML = '<h3>Eigenschaften</h3><div class="m-none">Nichts ausgewählt. Klicke ein Objekt an oder wähle links einen Grundkörper.</div>'; return; }
    if (list.length > 1) {
      const b = unionBox(list);
      el.innerHTML = `<h3>${list.length} Objekte</h3>
        <div class="m-dims">Gesamt <b>${fmt(b.s[0])} × ${fmt(b.s[1])} × ${fmt(b.s[2])} mm</b></div>
        <div class="m-sub">Kombinieren</div>
        <div class="m-acts">
          <button class="m-act main wide" data-do="group" title="Körper vereinigen und Löcher abziehen (Strg+G)">Gruppieren (Löcher abziehen)</button>
          <button class="m-act" data-do="union" title="Alle zu einem Körper verschmelzen">Vereinigen</button>
          <button class="m-act" data-do="subtract" title="Alle weiteren vom zuerst gewählten Objekt abziehen">Abziehen</button>
          <button class="m-act" data-do="intersect" title="Nur den gemeinsamen Teil behalten">Schnittmenge</button>
        </div>
        <div class="m-sub">Ausrichten</div>
        ${[0, 1, 2].map((k) => `<div class="m-field"><span class="ax${k}">${AXN[k]}</span><div class="m-seg">${(k === 2 ? ['Unten', 'Mitte', 'Oben'] : ['Min', 'Mitte', 'Max']).map((n, w) => `<button data-align="${k},${w}">${n}</button>`).join('')}</div></div>`).join('')}
        <div class="m-acts">
          <button class="m-act" data-do="dup">Duplizieren</button><button class="m-act" data-do="drop">Auf Bett</button><button class="m-act" data-do="center">Zentrieren</button>
          <button class="m-act" data-do="solid">Als Körper</button><button class="m-act" data-do="hole">Als Loch</button><button class="m-act danger" data-do="del">Löschen</button>
        </div>`;
      return;
    }
    const o = list[0]; const s = localSize(o); const shape = SHAPES[o.kind];
    const params = shape ? shape.params.map(([k, n, , type]) => {
      const v = o.p[k];
      if (type === 'text') return `<div class="m-field"><span>${n}</span><textarea data-param="${k}" rows="2">${esc(v)}</textarea></div>`;
      if (type === 'font') return `<div class="m-field"><span>${n}</span><select data-param="${k}">${G.FONTS.map((f) => `<option${f === v ? ' selected' : ''}>${esc(f)}</option>`).join('')}</select></div>`;
      if (type === 'bool') return `<div class="m-field"><span>${n}</span><label class="m-check" style="padding:0;border:0;margin:0"><input type="checkbox" data-param="${k}"${v ? ' checked' : ''}/> ja</label></div>`;
      return `<div class="m-field"><span>${n}</span><input data-param="${k}" type="text" inputmode="decimal" value="${fmt(v, 2)}"/></div>`;
    }).join('') : '';
    el.innerHTML = `<h3>Eigenschaften <small>${esc(shape ? shape.name : o.src ? 'Gruppe' : 'Netz')} · ${(geom(o).length / 9).toLocaleString('de-CH')} Dreiecke</small></h3>
      <div class="m-field"><span>Name</span><input id="f-name" type="text" value="${esc(o.name)}" maxlength="60"/></div>
      <div class="m-field"><span>Art</span><div class="m-seg"><button data-do="solid" class="${o.hole ? '' : 'on'}">Körper</button><button data-do="hole" class="${o.hole ? 'on' : ''}">Loch</button></div></div>
      <div class="m-field"><span>Farbe</span><div class="m-colors">${COLORS.map((c) => `<button data-color="${c}" class="${c === o.color ? 'on' : ''}" style="background:${c}" title="${c}"></button>`).join('')}<input type="color" id="f-color" value="${esc(o.color)}" title="Eigene Farbe"/></div></div>
      <div class="m-field"><span>Position</span>${xyz('pos', o.pos, snap, 'mm')}</div>
      <div class="m-field"><span>Drehung</span>${xyz('rot', o.rot, 15, 'Grad')}</div>
      <div class="m-field"><span>Grösse</span>${xyz('size', s, snap, 'mm')}</div>
      <label class="m-lock"><input type="checkbox" id="f-lock"${lockRatio ? ' checked' : ''}/> Proportional</label>
      ${params ? `<div class="m-sub">Form</div>${params}` : ''}
      <div class="m-sub">Werkzeuge</div>
      <div class="m-acts">
        <button class="m-act" data-do="dup" title="Strg+D">Duplizieren</button><button class="m-act" data-do="drop" title="D">Auf Bett</button><button class="m-act" data-do="center">Zentrieren</button>
        <button class="m-act" data-mirror="0" title="An X spiegeln">Spiegeln X</button><button class="m-act" data-mirror="1">Spiegeln Y</button><button class="m-act" data-mirror="2">Spiegeln Z</button>
        <button class="m-act" data-do="resetrot">Drehung 0</button><button class="m-act" data-do="resetscl">Grösse 100 %</button><button class="m-act danger" data-do="del" title="Entf">Löschen</button>
        ${o.src ? '<button class="m-act wide" data-do="ungroup" title="Strg+Umschalt+G">Gruppierung lösen</button>' : ''}
        <button class="m-act wide" data-do="editmode" title="Tab">Punkte und Flächen bearbeiten</button>
      </div>
      <div class="m-sub" id="deform">Verformen</div>
      <div class="m-field"><span>Verjüngen</span><input data-def="taper" type="text" inputmode="decimal" value="${fmt(deformVals.taper)}" title="Grösse oben in Prozent (100 = unverändert)"/></div>
      <div class="m-field"><span>Verdrehen</span><input data-def="twist" type="text" inputmode="decimal" value="${fmt(deformVals.twist)}" title="Drehung über die Höhe in Grad"/></div>
      <div class="m-field"><span>Biegen</span><input data-def="bend" type="text" inputmode="decimal" value="${fmt(deformVals.bend)}" title="Biegung über die Höhe in Grad (um die Y-Achse)"/></div>
      <div class="m-acts"><button class="m-act main" data-do="deform">Verformen</button><button class="m-act" data-do="smooth" title="Unterteilen und weich machen">Glätten</button><button class="m-act" data-do="subdiv" title="Mehr Punkte für feinere Bearbeitung">Unterteilen</button></div>`;
  }
  $('#props').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.esub) { ed.sub = b.dataset.esub; ed.sel = new Set(); refresh(); return; }
    if (b.dataset.ed) {
      ({
        extrude: edExtrude, all: edSelectAll, none: () => { ed.sel = new Set(); refresh(); }, subdiv: subdivideObj, smooth: smoothObj,
        drop: () => dropToBed(), done: () => setMode('move'),
      })[b.dataset.ed]?.();
      return;
    }
    if (b.dataset.color) { edit((o) => { o.color = b.dataset.color; }); return; }
    if (b.dataset.mirror) { mirror(+b.dataset.mirror); return; }
    if (b.dataset.align) { const [k, w] = b.dataset.align.split(',').map(Number); align(k, w); return; }
    const act = b.dataset.do; if (!act) return;
    ({
      group: () => combine('group'), union: () => combine('union'), subtract: () => combine('subtract'), intersect: () => combine('intersect'),
      dup: () => duplicate(), drop: () => dropToBed(), center: centerOnBed, del: remove, ungroup,
      solid: () => setHole(false), hole: () => setHole(true),
      deform: deformObj, smooth: smoothObj, subdiv: subdivideObj, editmode: () => setMode('edit'),
      resetrot: () => edit((o) => { o.rot = [0, 0, 0]; }), resetscl: () => edit((o) => { o.scl = o.scl.map((v) => Math.sign(v) || 1); }),
    })[act]?.();
  });
  $('#props').addEventListener('change', (e) => {
    const t = e.target; const o = selected()[0]; if (!o) return;
    if (t.id === 'e-dist') { const v = num(t.value); if (Number.isFinite(v) && v !== 0) extrudeDist = v; t.value = fmt(extrudeDist, 2); return; }
    if (t.dataset.def) { const v = num(t.value); if (Number.isFinite(v)) deformVals[t.dataset.def] = t.dataset.def === 'taper' ? Math.max(1, Math.min(1000, v)) : Math.max(-3600, Math.min(3600, v)); t.value = fmt(deformVals[t.dataset.def]); return; }
    if (t.dataset.epos) { const v = num(t.value); if (Number.isFinite(v)) edMoveTo(+t.dataset.epos, v); return; }
    if (t.id === 'f-name') { const n = t.value.trim(); if (n) edit((x) => { x.name = n; }, [o]); return; }
    if (t.id === 'f-color') { edit((x) => { x.color = t.value; }, [o]); return; }
    if (t.id === 'f-lock') { lockRatio = t.checked; return; }
    if (t.dataset.param) {
      const k = t.dataset.param; const def = SHAPES[o.kind].params.find((p) => p[0] === k);
      let v = def[3] === 'bool' ? t.checked : def[3] === 'text' || def[3] === 'font' ? t.value : num(t.value);
      if (typeof v === 'number' && !(v >= 0)) { renderProps(); return; }
      edit((x) => { x.p = { ...x.p, [k]: v }; }, [o]);
      return;
    }
    const v = num(t.value); if (!Number.isFinite(v)) { renderProps(); return; }
    if (t.dataset.pos) edit((x) => { x.pos[+t.dataset.pos] = v; }, [o]);
    else if (t.dataset.rot) edit((x) => { x.rot[+t.dataset.rot] = v; }, [o]);
    else if (t.dataset.size) {
      const k = +t.dataset.size; const s = localSize(o); if (!(v > 0) || !(s[k] > 0)) { renderProps(); return; }
      const f = v / s[k];
      edit((x) => { if (lockRatio) x.scl = x.scl.map((q) => q * f); else x.scl[k] *= f; }, [o]);
    }
  });
  $('#props').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.tagName === 'INPUT') e.target.blur();
    // Pfeil hoch/runter in Zahlenfeldern
    if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && e.target.tagName === 'INPUT' && e.target.inputMode === 'decimal') {
      e.preventDefault(); const st = e.target.dataset.rot ? (e.shiftKey ? 45 : 5) : (e.shiftKey ? 10 : snap || 1);
      e.target.value = fmt(num(e.target.value) + (e.key === 'ArrowUp' ? st : -st), 2);
      e.target.dispatchEvent(new Event('change', { bubbles: true }));
      setTimeout(() => document.querySelector(`[data-${Object.keys(e.target.dataset)[0]}="${Object.values(e.target.dataset)[0]}"]`)?.focus(), 0);
    }
  });

  function renderPrint() {
    const list = visible().filter((o) => !o.hole);
    let tris = 0, vol = 0; const warn = [];
    for (const o of list) {
      const e = world(o); tris += e.arr.length / 9; vol += Math.abs(G.volume(e.arr));
      const bb = e.bb;
      if (bb.min[0] < -bed.w / 2 - 0.01 || bb.max[0] > bed.w / 2 + 0.01 || bb.min[1] < -bed.d / 2 - 0.01 || bb.max[1] > bed.d / 2 + 0.01) warn.push(['bad', `„${o.name}“ liegt (teilweise) ausserhalb des Druckbetts.`]);
      if (bb.max[2] > bed.h + 0.01) warn.push(['bad', `„${o.name}“ ist höher als der Bauraum (${bed.h} mm).`]);
      if (bb.min[2] < -0.01) warn.push(['bad', `„${o.name}“ ragt ${fmt(-bb.min[2], 2)} mm unter das Bett – „Auf Bett“ verwenden.`]);
      else if (bb.min[2] > 0.01 && !list.some((p) => p !== o && world(p).bb.max[2] >= bb.min[2] - 0.01 && world(p).bb.min[2] < bb.min[2])) warn.push(['', `„${o.name}“ schwebt ${fmt(bb.min[2], 2)} mm über dem Bett.`]);
    }
    const holes = visible().filter((o) => o.hole).length;
    if (holes) warn.push(['', `${holes} Loch${holes > 1 ? 'objekte werden' : ' wird'} nicht exportiert – zuerst mit einem Körper gruppieren.`]);
    const grams = (vol / 1000) * 1.24;
    $('#print-info').innerHTML = `
      <div class="m-pi"><span>Druckbett</span><b>${bed.w} × ${bed.d} × ${bed.h} mm</b></div>
      <div class="m-pi"><span>Körper</span><b>${list.length}</b></div>
      <div class="m-pi"><span>Dreiecke</span><b>${tris.toLocaleString('de-CH')}</b></div>
      <div class="m-pi"><span>Volumen</span><b>${fmt(vol / 1000, 2)} cm³</b></div>
      <div class="m-pi"><span>PLA massiv ca.</span><b>${fmt(grams, 1)} g</b></div>
      ${warn.map(([k, t]) => `<div class="m-warn ${k}">${esc(t)}</div>`).join('')}
      ${list.length && !warn.some((w) => w[0] === 'bad') ? '<div class="m-ok">Alles liegt im Bauraum.</div>' : ''}
      ${sel.length ? '<div class="m-acts"><button class="m-act wide" id="check-mesh">Netz der Auswahl prüfen</button></div>' : ''}`;
    $('#stats').textContent = `${objs.length} Objekt${objs.length === 1 ? '' : 'e'} · ${tris.toLocaleString('de-CH')} Dreiecke · Raster ${snap ? `${snap} mm` : 'aus'}`;
  }
  $('#print-info').addEventListener('click', (e) => {
    if (e.target.id !== 'check-mesh') return;
    const res = selected().map((o) => [o, G.manifold(world(o).arr)]);
    const bad = res.filter(([, r]) => r.open || r.multi);
    toast(bad.length ? bad.map(([o, r]) => `„${o.name}“: ${r.open} offene, ${r.multi} mehrfache Kanten`).join(' · ') : 'Netz geschlossen (wasserdicht) – bereit zum Drucken.', bad.length ? 'error' : '');
  });

  let refreshPending = false;
  function refresh(light) {
    if (ed && (!sel.includes(ed.id) || !edObj())) setMode('move');
    $('[data-hist="undo"]').disabled = !undoStack.length;
    $('[data-hist="redo"]').disabled = !redoStack.length;
    draw();
    if (light) { if (!refreshPending) { refreshPending = true; setTimeout(() => { refreshPending = false; renderProps(); }, 60); } return; }
    renderList(); renderProps(); renderPrint();
    scheduleDraft();
  }

  /* -------------------------------------------------------------- Dateien */
  const exportParts = (onlySel) => (onlySel ? selected() : visible()).filter((o) => !o.hole && !o.hidden).map((o) => ({ name: o.name, mesh: world(o).arr }));
  const fileBase = () => (objs.length === 1 ? objs[0].name : projectName || '3D-Modell').replace(/[\\/:*?"<>|]+/g, '_');
  let projectName = '';
  async function exportAs(kind) {
    try {
      if (kind === 'png') { paint(); const data = view.snapshot(); await api.save({ name: fileBase(), ext: 'png', base64: data.split(',')[1] }); return; }
      const parts = exportParts($('#export-sel').checked && sel.length);
      if (!parts.length) { toast('Nichts zu exportieren – füge zuerst einen Körper hinzu.', 'error'); return; }
      let res;
      if (kind === 'stl') res = await api.save({ name: fileBase(), ext: 'stl', bytes: G.toSTL(G.merge(parts.map((p) => p.mesh))) });
      else if (kind === 'obj') res = await api.save({ name: fileBase(), ext: 'obj', text: G.toOBJ(parts) });
      else res = await api.save({ name: fileBase(), ext: '3mf', zip: G.to3MF(parts) });
      if (res) toast(`Exportiert: ${res.name}`);
    } catch (e) { toast(`Export fehlgeschlagen: ${e.message || e}`, 'error'); }
  }
  async function importFile() {
    try {
      const f = await api.open({ kind: 'mesh' }); if (!f) return;
      let mesh;
      if (f.ext === 'stl') mesh = G.parseSTL(f.bytes);
      else if (f.ext === 'obj') mesh = G.parseOBJ(new TextDecoder().decode(f.bytes));
      else if (f.ext === '3mf') mesh = G.parse3MF(f.text);
      else throw new Error('Dateityp nicht unterstützt.');
      const m = G.center(mesh);
      const o = add('mesh', { name: f.name.replace(/\.[^.]+$/, ''), mesh: m });
      const s = localSize(o);
      toast(s[0] > bed.w || s[1] > bed.d || s[2] > bed.h ? `Importiert – grösser als das Druckbett (${s.map((v) => fmt(v)).join(' × ')} mm). Mit „Grösse“ verkleinern.` : `Importiert: ${(m.length / 9).toLocaleString('de-CH')} Dreiecke`);
      fit();
    } catch (e) { toast(`Import fehlgeschlagen: ${e.message || e}`, 'error'); }
  }
  function serialize() {
    return JSON.stringify({ app: 'revolution-hub-3d', v: 1, bed, snap, nextId, objs: objs.map((o) => ({ ...o, mesh: o.mesh ? G.b64.enc(o.mesh) : null, src: o.src ? o.src.map((s) => ({ ...s, mesh: s.mesh ? G.b64.enc(s.mesh) : null, src: null })) : null })) });
  }
  function deserialize(text) {
    const d = JSON.parse(text);
    if (d.app !== 'revolution-hub-3d') throw new Error('Keine 3D-Modell-Projektdatei.');
    const fix = (o) => ({ ...o, mesh: o.mesh ? G.b64.dec(o.mesh) : null, src: o.src ? o.src.map(fix) : null });
    return { ...d, objs: d.objs.map(fix) };
  }
  function load(d) {
    objs = d.objs; sel = []; nextId = Math.max(d.nextId || 1, ...objs.map((o) => o.id + 1), 1);
    if (d.bed) setBed(d.bed.id, d.bed);
    refresh();
  }
  async function saveProject() {
    try { const r = await api.save({ name: fileBase(), ext: 'r3d', text: serialize() }); if (r) { projectName = r.name.replace(/\.[^.]+$/, ''); toast(`Gespeichert: ${r.name}`); } }
    catch (e) { toast(`Speichern fehlgeschlagen: ${e.message || e}`, 'error'); }
  }
  async function openProject() {
    try {
      const f = await api.open({ kind: 'project' }); if (!f) return;
      if (f.ext !== 'r3d') { const ext = f.ext; if (['stl', 'obj', '3mf'].includes(ext)) { toast('Netzdateien bitte über „Importieren“ laden.'); } return; }
      const d = deserialize(new TextDecoder().decode(f.bytes));
      checkpoint(); load(d); projectName = f.name.replace(/\.[^.]+$/, ''); fit();
      toast(`Geöffnet: ${f.name}`);
    } catch (e) { toast(`Öffnen fehlgeschlagen: ${e.message || e}`, 'error'); }
  }
  function newProject() {
    if (!objs.length) return;
    checkpoint(); objs = []; sel = []; projectName = ''; measure = null; refresh();
    toast('Neues Projekt – mit Strg+Z kommt das alte zurück.');
  }
  let draftTimer = 0;
  function scheduleDraft() { clearTimeout(draftTimer); draftTimer = setTimeout(() => api.draftSave(serialize()).catch(() => {}), 1200); }
  function saveSettings() { try { localStorage.setItem('m3d-settings', JSON.stringify({ bed, snap })); } catch { /* egal */ } }

  /* ------------------------------------------------------------- Tastatur */
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F1') { e.preventDefault(); $('#help-menu').hidden = !$('#help-menu').hidden; return; }
    if (e.target.closest('input, textarea, select')) return;
    const k = e.key.toLowerCase(); const ctrl = e.ctrlKey || e.metaKey;
    if (k === 'tab') { e.preventDefault(); setMode(mode === 'edit' ? 'move' : 'edit'); return; }
    if (mode === 'edit' && ed) {
      if (ctrl && k === 'a') { e.preventDefault(); edSelectAll(); return; }
      if (k === 'escape') { e.preventDefault(); if (ed.sel.size) { ed.sel = new Set(); refresh(); } else setMode('move'); return; }
      if (k === 'delete' || k === 'backspace') { toast('Im Bearbeiten-Modus werden keine Punkte gelöscht – Tab beendet das Bearbeiten.'); return; }
      if (k === 'e' && !ctrl) { e.preventDefault(); edExtrude(); return; }
    }
    if (ctrl) {
      const fn = { z: e.shiftKey ? redo : undo, y: redo, d: () => duplicate(), s: saveProject, o: openProject, i: importFile, n: newProject, e: () => exportAs('stl'), a: () => { sel = visible().map((o) => o.id); refresh(); }, c: () => { clip = selected().map(clone); }, v: () => { if (!clip?.length) return; checkpoint(); sel = clip.map((c) => { const n = clone(c); n.id = nextId++; n.pos[0] += 10; n.pos[1] += 10; objs.push(n); return n.id; }); clip = clip.map((c) => { const n = clone(c); n.pos[0] += 10; n.pos[1] += 10; return n; }); refresh(); }, g: () => (e.shiftKey ? ungroup() : combine('group')) }[k];
      if (fn) { e.preventDefault(); fn(); }
      return;
    }
    const arrows = { arrowleft: [0, -1], arrowright: [0, 1], arrowup: [1, 1], arrowdown: [1, -1], pageup: [2, 1], pagedown: [2, -1] };
    if (arrows[k] && sel.length) {
      e.preventDefault(); const [ax, s] = arrows[k]; let a = ax, sg = s;
      if (ax < 2) { // relativ zur Blickrichtung verschieben
        const m = view.view; const dir = ax === 0 ? [m[0], m[4]] : [-m[2], -m[6]];
        a = Math.abs(dir[0]) > Math.abs(dir[1]) ? 0 : 1; sg = s * Math.sign(dir[a]);
      }
      const st = (snap || 1) * (e.shiftKey ? 10 : 1);
      edit((o) => { o.pos[a] += sg * st; });
      return;
    }
    const map = {
      delete: remove, backspace: remove, escape: () => { if (measure) { measure = null; draw(); } else { sel = []; refresh(); } },
      q: () => setMode('select'), g: () => setMode('move'), w: () => setMode('move'), r: () => setMode('rotate'), e: () => setMode('rotate'), s: () => setMode('scale'), m: () => setMode('measure'), l: () => setMode('flat'),
      f: fit, home, d: () => dropToBed(), h: () => setHole(!(selected()[0]?.hole)),
      1: () => setView(...VIEWS.front), 3: () => setView(...VIEWS.right), 7: () => setView(...VIEWS.top), 5: () => { cam.ortho = !cam.ortho; $('#ortho-btn').textContent = cam.ortho ? 'Ortho.' : 'Persp.'; draw(); },
    };
    const fn = map[k]; if (fn) { e.preventDefault(); fn(); }
  });
  // Dateien hineinziehen
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', async (e) => {
    e.preventDefault();
    for (const file of e.dataTransfer.files) {
      const ext = file.name.split('.').pop().toLowerCase();
      try {
        const buf = new Uint8Array(await file.arrayBuffer());
        if (ext === 'r3d') { checkpoint(); load(deserialize(new TextDecoder().decode(buf))); continue; }
        let mesh = ext === 'stl' ? G.parseSTL(buf) : ext === 'obj' ? G.parseOBJ(new TextDecoder().decode(buf)) : null;
        if (ext === '3mf') { const r = await api.unzip3mf(buf); mesh = G.parse3MF(r); }
        if (!mesh) { toast(`${file.name}: Dateityp nicht unterstützt.`, 'error'); continue; }
        add('mesh', { name: file.name.replace(/\.[^.]+$/, ''), mesh: G.center(mesh) });
      } catch (err) { toast(`${file.name}: ${err.message || err}`, 'error'); }
    }
  });

  /* ---------------------------------------------------------------- Start */
  const tour = window.M3Tour.Tour({
    count: () => objs.length,
    stateKey: () => `${objs.map((o) => o.pos.join()).join('|')}|${Math.round(cam.yaw)}|${Math.round(cam.pitch)}|${Math.round(cam.dist)}`,
    sizeKey: () => { const o = selected()[0]; return o ? localSize(o).map((v) => v.toFixed(2)).join() : ''; },
    hasHole: () => objs.some((o) => o.hole), hasGroup: () => objs.some((o) => o.src),
    galleryOpen: () => !$('#gallery').hidden, mode: () => mode, editCount: () => (ed ? ed.sel.size : 0),
  });
  buildChrome();
  let settings = {}; try { settings = JSON.parse(localStorage.getItem('m3d-settings') || '{}'); } catch { /* egal */ }
  snap = typeof settings.snap === 'number' ? settings.snap : 1; $('#snap').value = String(snap);
  setBed(settings.bed?.id || 'p1', settings.bed);
  setMode('move');
  cam.dist = Math.max(bed.w, bed.d) * 1.55;
  api.draftLoad().then((txt) => { if (txt) { try { load(deserialize(txt)); } catch { /* kaputter Entwurf */ } } refresh(); }).catch(() => refresh());
  // für Tests / Fernsteuerung
  window.M3D = { add, combine, objs: () => objs, select: (ids) => { sel = ids; refresh(); }, world: (o) => world(o).arr, exportParts, setView, fit, dropToBed, layFlat, undo, redo, setMode, bed: () => bed, serialize, deserialize, load, mirror, align, duplicate, setHole, project: (p) => view.project(p), selected: () => [...sel], addPreset, ed: () => ed, edExtrude, setExtrude: (v) => { extrudeDist = v; }, deform: (v) => { Object.assign(deformVals, v); deformObj(); }, smoothObj, toggleGallery, tour, edSelect: (ids) => { ed.sel = new Set(ids); refresh(); } };
  try { if (!localStorage.getItem('m3d-tour-seen') && !objs.length) setTimeout(() => { if (!objs.length) $('#empty-tour').classList.add('pulse'); }, 800); } catch { /* egal */ }
})();
