'use strict';
/*
 * 3D-Modell – Formen-Galerie: fertige, parametrische Druckformen.
 * Jede Form erzeugt ein geschlossenes Netz (mittig, auf z = 0). Kategorien über `cat`.
 * Mehrteilige Vorlagen (z. B. Box mit Deckel) stehen in PRESETS.
 */
(function () {
  const G = window.M3G;
  const { SHAPES, builder, lathe, arc, roundedBox } = G;
  const TAU = Math.PI * 2;
  const num = (v, d) => (Number(v) > 0 ? Number(v) : d);
  const int = (v, lo, hi, d) => Math.max(lo, Math.min(hi, Math.round(Number(v)) || d));

  /* -------------------------------------------------------------- 2D-Werkzeuge */
  const area = (p) => { let a = 0; for (let i = 0; i < p.length; i += 1) { const [x1, y1] = p[i], [x2, y2] = p[(i + 1) % p.length]; a += x1 * y2 - x2 * y1; } return a / 2; };
  // Ohrenschneiden für einfache Polygone (ohne Löcher), gibt Indexdreiecke zurück
  function earClip(pts) {
    const idx = pts.map((_, i) => i); const out = [];
    const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
    const inside = (p, a, b, c) => cross(a, b, p) >= -1e-12 && cross(b, c, p) >= -1e-12 && cross(c, a, p) >= -1e-12;
    let guard = 0;
    while (idx.length > 3 && guard < 100000) {
      guard += 1; let cut = false;
      for (let i = 0; i < idx.length; i += 1) {
        const ia = idx[(i + idx.length - 1) % idx.length], ib = idx[i], ic = idx[(i + 1) % idx.length];
        const a = pts[ia], b = pts[ib], c = pts[ic];
        if (cross(a, b, c) <= 1e-12) continue;
        let ok = true;
        for (const j of idx) { if (j === ia || j === ib || j === ic) continue; if (inside(pts[j], a, b, c)) { ok = false; break; } }
        if (!ok) continue;
        out.push([ia, ib, ic]); idx.splice(i, 1); cut = true; break;
      }
      if (!cut) { // Notfall: Fächer (bei fast entarteten Polygonen)
        for (let i = 1; i < idx.length - 1; i += 1) out.push([idx[0], idx[i], idx[i + 1]]);
        return out;
      }
    }
    if (idx.length === 3) out.push([idx[0], idx[1], idx[2]]);
    return out;
  }
  const dedupe = (p) => p.filter((q, i) => { const r = p[(i + 1) % p.length]; return Math.hypot(q[0] - r[0], q[1] - r[1]) > 1e-6; });
  // 2D-Umriss → Prisma der Höhe h (Umriss wird auf gegen den Uhrzeigersinn gebracht)
  function extrude(poly, h) {
    let p = dedupe(poly); if (area(p) < 0) p = p.slice().reverse();
    const b = builder(); const tris = earClip(p);
    const L = (q) => [q[0], q[1], 0], U = (q) => [q[0], q[1], h];
    for (const [i, j, k] of tris) { b.tri(U(p[i]), U(p[j]), U(p[k])); b.tri(L(p[i]), L(p[k]), L(p[j])); }
    for (let i = 0; i < p.length; i += 1) { const a = p[i], c = p[(i + 1) % p.length]; b.quad(L(a), L(c), U(c), U(a)); }
    return G.center(b.done());
  }
  // Umriss in der X-Z-Ebene, Breite w entlang Y (Seitenprofile wie Halter und Haken)
  function extrudeSide(poly, w) {
    const m = extrude(poly, w); const r = new Float32Array(m.length);
    for (let i = 0; i < m.length; i += 3) { r[i] = m[i]; r[i + 1] = -m[i + 2] + w / 2; r[i + 2] = m[i + 1]; }
    return G.center(r);
  }
  // Linienzug → geschlossener Umriss mit Dicke t
  function stroke(path, t) {
    const L = [], R = [];
    for (let i = 0; i < path.length; i += 1) {
      const p = path[i], a = path[Math.max(0, i - 1)], c = path[Math.min(path.length - 1, i + 1)];
      let dx = c[0] - a[0], dy = c[1] - a[1]; const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l;
      L.push([p[0] - dy * t / 2, p[1] + dx * t / 2]); R.push([p[0] + dy * t / 2, p[1] - dx * t / 2]);
    }
    return [...R, ...L.reverse()];
  }
  const circle = (r, n = 64, cx = 0, cy = 0, a0 = 0) => Array.from({ length: n }, (_, i) => [cx + r * Math.cos(a0 + (i / n) * TAU), cy + r * Math.sin(a0 + (i / n) * TAU)]);
  const arcPts = (r, a0, a1, n, cx = 0, cy = 0) => Array.from({ length: n + 1 }, (_, i) => { const t = ((a0 + ((a1 - a0) * i) / n) * Math.PI) / 180; return [cx + r * Math.cos(t), cy + r * Math.sin(t)]; });
  function roundRect(w, d, r, k = 8) {
    r = Math.max(0, Math.min(r, w / 2 - 0.01, d / 2 - 0.01)); if (r < 0.01) return [[-w / 2, -d / 2], [w / 2, -d / 2], [w / 2, d / 2], [-w / 2, d / 2]];
    return [...arcPts(r, 270, 360, k, w / 2 - r, -d / 2 + r), ...arcPts(r, 0, 90, k, w / 2 - r, d / 2 - r), ...arcPts(r, 90, 180, k, -w / 2 + r, d / 2 - r), ...arcPts(r, 180, 270, k, -w / 2 + r, -d / 2 + r)];
  }
  const cyl = (r, h, n = 48, z = 0) => G.transform(SHAPES.cyl.make({ r, h, n }), G.M.trs([0, 0, z], [0, 0, 0], [1, 1, 1]));
  const boxAt = (w, d, h, x = 0, y = 0, z = 0) => G.transform(SHAPES.box.make({ w, d, h }), G.M.trs([x, y, z], [0, 0, 0], [1, 1, 1]));

  /* ------------------------------------------------------------------ Formen */
  const add = (key, def) => { SHAPES[key] = def; };
  add('star', { name: 'Stern', cat: 'Flach', params: [['k', 'Zacken', 5], ['ro', 'Aussenradius', 20], ['ri', 'Innenradius', 9], ['h', 'Höhe', 5]],
    make: (p) => { const k = int(p.k, 3, 40, 5), ro = num(p.ro, 20), ri = Math.min(num(p.ri, 9), ro); return extrude(Array.from({ length: k * 2 }, (_, i) => { const r = i % 2 ? ri : ro; const t = Math.PI / 2 + (i / (k * 2)) * TAU; return [r * Math.cos(t), r * Math.sin(t)]; }), num(p.h, 5)); } });
  add('heart', { name: 'Herz', cat: 'Flach', params: [['s', 'Breite', 30], ['h', 'Höhe', 5]],
    make: (p) => { const s = num(p.s, 30) / 34; return extrude(Array.from({ length: 96 }, (_, i) => { const t = (i / 96) * TAU; return [16 * Math.sin(t) ** 3 * s, (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) * s]; }), num(p.h, 5)); } });
  add('arrow', { name: 'Pfeil', cat: 'Flach', params: [['l', 'Länge', 50], ['w', 'Breite', 24], ['s', 'Schaftbreite', 9], ['h', 'Höhe', 5]],
    make: (p) => { const l = num(p.l, 50), w = num(p.w, 24), s = Math.min(num(p.s, 9), w), hl = Math.min(l * 0.45, w * 0.9); return extrude([[-l / 2, -s / 2], [l / 2 - hl, -s / 2], [l / 2 - hl, -w / 2], [l / 2, 0], [l / 2 - hl, w / 2], [l / 2 - hl, s / 2], [-l / 2, s / 2]], num(p.h, 5)); } });
  add('cross', { name: 'Kreuz', cat: 'Flach', params: [['s', 'Grösse', 30], ['t', 'Balken', 10], ['h', 'Höhe', 5]],
    make: (p) => { const a = num(p.s, 30) / 2, t = Math.min(num(p.t, 10), a * 2) / 2; return extrude([[-t, -a], [t, -a], [t, -t], [a, -t], [a, t], [t, t], [t, a], [-t, a], [-t, t], [-a, t], [-a, -t], [-t, -t]], num(p.h, 5)); } });
  add('crescent', { name: 'Halbmond', cat: 'Flach', params: [['r', 'Radius', 20], ['c', 'Ausschnitt', 0.45], ['h', 'Höhe', 5]],
    make: (p) => { const r = num(p.r, 20), c = Math.min(0.95, num(p.c, 0.45)), h = num(p.h, 5); return G.center(G.csg('subtract', cyl(r, h, 64), G.transform(cyl(r * 0.85, h + 2, 64, -1), G.M.trs([r * c, r * 0.1, 0], [0, 0, 0], [1, 1, 1])))); } });
  add('polyplate', { name: 'Vieleck-Platte', cat: 'Flach', params: [['k', 'Ecken', 6], ['r', 'Radius', 20], ['f', 'Eckenrundung', 3], ['h', 'Höhe', 3]],
    make: (p) => { const k = int(p.k, 3, 24, 6), r = num(p.r, 20), f = Math.max(0, Number(p.f) || 0); const pts = []; for (let i = 0; i < k; i += 1) { const t = (i / k) * TAU + Math.PI / 2; const cr = r - f / Math.cos(Math.PI / k); if (f > 0.01) pts.push(...arcPts(f, (t * 180) / Math.PI - 180 / k, (t * 180) / Math.PI + 180 / k, 6, cr * Math.cos(t), cr * Math.sin(t))); else pts.push([r * Math.cos(t), r * Math.sin(t)]); } return extrude(pts, num(p.h, 3)); } });

  add('gear', { name: 'Zahnrad', cat: 'Technik', params: [['z', 'Zähne', 20], ['m', 'Modul', 2], ['h', 'Dicke', 6], ['bore', 'Bohrung', 5]],
    make: (p) => {
      const z = int(p.z, 6, 120, 20), m = num(p.m, 2), h = num(p.h, 6), bore = Math.max(0, Number(p.bore) || 0);
      const r = (m * z) / 2, ra = r + m, rf = Math.max(r - 1.25 * m, m); const pts = [];
      for (let i = 0; i < z; i += 1) {
        const a = (i / z) * TAU, q = TAU / z;
        for (const [rr, f] of [[rf, -0.5], [rf, -0.26], [r, -0.19], [ra, -0.1], [ra, 0.1], [r, 0.19], [rf, 0.26]]) pts.push([rr * Math.cos(a + f * q), rr * Math.sin(a + f * q)]);
      }
      const g = extrude(pts, h);
      return bore > 0.1 ? G.center(G.csg('subtract', g, cyl(bore / 2, h + 2, 48, -1))) : g;
    } });
  // Gewindestange: Radius folgt einem Dreiecksprofil, das sich mit der Steigung um die Achse windet
  add('thread', { name: 'Gewindestange', cat: 'Technik', params: [['d', 'Durchmesser', 10], ['p', 'Steigung', 1.5], ['l', 'Länge', 30], ['n', 'Segmente', 48]],
    make: (p) => {
      const d = num(p.d, 10), pitch = Math.max(0.4, num(p.p, 1.5)), l = num(p.l, 30), n = int(p.n, 12, 128, 48);
      const depth = Math.min(pitch * 0.6, d * 0.2), rc = d / 2 - depth; const rows = Math.ceil((l / pitch) * 8);
      const R = (t, z) => { const f = ((z / pitch - t / TAU) % 1 + 1) % 1; const tri = 1 - Math.abs(f * 2 - 1); const fade = Math.min(1, z / (pitch * 0.6), (l - z) / (pitch * 0.6)); return rc + depth * Math.min(1, tri * 1.6) * Math.max(0, fade); };
      const P = (j, i) => { const t = (j / n) * TAU, z = (i / rows) * l, r = R(t, z); return [r * Math.cos(t), r * Math.sin(t), z]; };
      const b = builder();
      for (let i = 0; i < rows; i += 1) for (let j = 0; j < n; j += 1) b.quad(P(j, i), P(j + 1, i), P(j + 1, i + 1), P(j, i + 1));
      for (let j = 0; j < n; j += 1) { b.tri([0, 0, 0], P(j + 1, 0), P(j, 0)); b.tri([0, 0, l], P(j, rows), P(j + 1, rows)); }
      return b.done();
    } });
  add('nut', { name: 'Mutter', cat: 'Technik', params: [['d', 'Gewinde-Ø', 10], ['s', 'Schlüsselweite', 17], ['h', 'Höhe', 8], ['c', 'Spiel', 0.4]],
    make: (p) => { const s = num(p.s, 17), h = num(p.h, 8); const hex = extrude(Array.from({ length: 6 }, (_, i) => { const t = (i / 6) * TAU; const r = s / Math.sqrt(3); return [r * Math.cos(t), r * Math.sin(t)]; }), h); return G.center(G.csg('subtract', hex, cyl((num(p.d, 10) + (Number(p.c) || 0)) / 2, h + 2, 48, -1))); } });
  add('bolthead', { name: 'Schraubenkopf', cat: 'Technik', params: [['s', 'Schlüsselweite', 17], ['h', 'Höhe', 7]],
    make: (p) => extrude(Array.from({ length: 6 }, (_, i) => { const t = (i / 6) * TAU; const r = num(p.s, 17) / Math.sqrt(3); return [r * Math.cos(t), r * Math.sin(t)]; }), num(p.h, 7)) });
  add('elbow', { name: 'Rohrbogen', cat: 'Technik', params: [['R', 'Biegeradius', 25], ['ro', 'Aussenradius', 8], ['ri', 'Innenradius', 6], ['a', 'Winkel', 90], ['n', 'Segmente', 32]],
    make: (p) => {
      const R = num(p.R, 25), ro = Math.min(num(p.ro, 8), R * 0.95), ri = Math.min(Math.max(0, Number(p.ri) || 0), ro - 0.2), ang = Math.min(359, num(p.a, 90)), n = int(p.n, 8, 128, 32), m = 32;
      const steps = Math.max(2, Math.round((n * ang) / 90)); const b = builder();
      const Q = (i, k, r) => { const u = ((i / steps) * ang * Math.PI) / 180, v = (k / m) * TAU; const q = R + r * Math.cos(v); return [q * Math.cos(u), q * Math.sin(u), ro + r * Math.sin(v)]; };
      for (let i = 0; i < steps; i += 1) for (let k = 0; k < m; k += 1) {
        b.quad(Q(i, k, ro), Q(i + 1, k, ro), Q(i + 1, k + 1, ro), Q(i, k + 1, ro));
        if (ri > 0.05) b.quad(Q(i, k + 1, ri), Q(i + 1, k + 1, ri), Q(i + 1, k, ri), Q(i, k, ri));
      }
      for (let k = 0; k < m; k += 1) {
        if (ri > 0.05) { b.quad(Q(0, k, ri), Q(0, k + 1, ri), Q(0, k + 1, ro), Q(0, k, ro)); b.quad(Q(steps, k, ro), Q(steps, k + 1, ro), Q(steps, k + 1, ri), Q(steps, k, ri)); }
        else { const c0 = Q(0, 0, 0), c1 = Q(steps, 0, 0); b.tri(c0, Q(0, k + 1, ro), Q(0, k, ro)); b.tri(c1, Q(steps, k, ro), Q(steps, k + 1, ro)); }
      }
      return G.center(b.done());
    } });
  add('clip', { name: 'Kabelclip', cat: 'Technik', params: [['d', 'Kabel-Ø', 8], ['t', 'Wand', 1.8], ['w', 'Breite', 8], ['o', 'Öffnung', 70]],
    make: (p) => { const d = num(p.d, 8), t = num(p.t, 1.8), o = Math.min(160, num(p.o, 70)); const a0 = -90 + o / 2, a1 = 270 - o / 2; const r = d / 2 + t / 2; return extrude(stroke(arcPts(r, a0, a1, 48), t), num(p.w, 8)); } });
  add('hook', { name: 'Haken', cat: 'Alltag', params: [['h', 'Höhe', 60], ['r', 'Bogenradius', 12], ['t', 'Dicke', 5], ['w', 'Breite', 15]],
    make: (p) => { const h = num(p.h, 60), r = num(p.r, 12), t = num(p.t, 5); const path = [[0, h], [0, r], ...arcPts(r, 180, 360, 24, r, r).slice(1), [2 * r, r + r * 0.9]]; return extrudeSide(stroke(path, t), num(p.w, 15)); } });
  add('stand', { name: 'Handyständer', cat: 'Alltag', params: [['w', 'Breite', 70], ['a', 'Neigung', 65], ['l', 'Rückenlänge', 90], ['t', 'Dicke', 5], ['lip', 'Ablage', 12]],
    make: (p) => {
      const t = num(p.t, 5), a = (Math.min(85, Math.max(30, num(p.a, 65))) * Math.PI) / 180, l = num(p.l, 90), lip = num(p.lip, 12);
      // Profil (Seitenansicht): Boden, schräge Lehne nach hinten, vorne eine Lippe für das Handy
      const s = t / Math.sin(a), lx = l * Math.cos(a), lz = l * Math.sin(a), B = lx + s + 8;
      const P = [[-22 - t, 0], [B, 0], [B, t], [s, t], [s + lx, t + lz], [lx, t + lz], [0, t], [-22, t], [-22, t + lip], [-22 - t, t + lip]];
      return extrudeSide(P, num(p.w, 70));
    } });
  add('keytag', { name: 'Schlüsselanhänger', cat: 'Alltag', params: [['w', 'Breite', 50], ['d', 'Tiefe', 22], ['h', 'Dicke', 3], ['r', 'Eckenradius', 5], ['hole', 'Loch-Ø', 5]],
    make: (p) => { const w = num(p.w, 50), d = num(p.d, 22), h = num(p.h, 3), hole = num(p.hole, 5); const plate = extrude(roundRect(w, d, num(p.r, 5)), h); return G.center(G.csg('subtract', plate, G.transform(cyl(hole / 2, h + 2, 40, -1), G.M.trs([-w / 2 + hole / 2 + 3, 0, 0], [0, 0, 0], [1, 1, 1])))); } });
  add('plate', { name: 'Platte (rund)', cat: 'Alltag', params: [['w', 'Breite', 80], ['d', 'Tiefe', 25], ['h', 'Dicke', 3], ['r', 'Eckenradius', 4]],
    make: (p) => extrude(roundRect(num(p.w, 80), num(p.d, 25), num(p.r, 4)), num(p.h, 3)) });
  add('openbox', { name: 'Box (offen)', cat: 'Alltag', params: [['w', 'Breite', 60], ['d', 'Tiefe', 40], ['h', 'Höhe', 30], ['t', 'Wand', 2]],
    make: (p) => { const w = num(p.w, 60), d = num(p.d, 40), h = num(p.h, 30), t = Math.min(num(p.t, 2), w / 3, d / 3, h / 2); return G.center(G.csg('subtract', boxAt(w, d, h), boxAt(w - 2 * t, d - 2 * t, h, 0, 0, t))); } });
  add('lid', { name: 'Deckel', cat: 'Alltag', params: [['w', 'Breite', 60], ['d', 'Tiefe', 40], ['t', 'Wand', 2], ['lip', 'Rand', 4], ['c', 'Spiel', 0.3]],
    make: (p) => {
      const w = num(p.w, 60), d = num(p.d, 40), t = num(p.t, 2), lip = num(p.lip, 4), c = Number(p.c) || 0.3;
      const iw = w - 2 * t - 2 * c, id = d - 2 * t - 2 * c;
      const rim = G.csg('subtract', boxAt(iw, id, lip, 0, 0, t - 0.01), boxAt(iw - 2 * t, id - 2 * t, lip + 1, 0, 0, t));
      return G.center(G.csg('union', boxAt(w, d, t), rim));
    } });
  add('vase', { name: 'Vase', cat: 'Alltag', params: [['r', 'Radius', 30], ['h', 'Höhe', 90], ['t', 'Wand', 1.6], ['b', 'Bauch', 1.25], ['n', 'Segmente', 64]],
    make: (p) => {
      const r = num(p.r, 30), h = num(p.h, 90), t = Math.min(num(p.t, 1.6), r / 3), bb = num(p.b, 1.25), k = 24;
      const R = (z) => r * (1 + (bb - 1) * Math.sin(Math.PI * Math.min(1, z / (h * 0.75)))) * (z > h * 0.75 ? 1 - 0.25 * ((z - h * 0.75) / (h * 0.25)) : 1);
      const out = Array.from({ length: k + 1 }, (_, i) => [R((i / k) * h), (i / k) * h]);
      const inn = Array.from({ length: k + 1 }, (_, i) => { const z = t + ((k - i) / k) * (h - t); return [Math.max(0.5, R(z) - t), z]; });
      return lathe([[0, 0], ...out, ...inn, [0, t]], int(p.n, 12, 160, 64));
    } });
  add('bowl', { name: 'Schale', cat: 'Alltag', params: [['r', 'Radius', 40], ['h', 'Höhe', 25], ['t', 'Wand', 2], ['n', 'Segmente', 64]],
    make: (p) => {
      const r = num(p.r, 40), h = num(p.h, 25), t = Math.min(num(p.t, 2), h / 2), k = 20; const rb = r * 0.55;
      const out = Array.from({ length: k + 1 }, (_, i) => { const a = (i / k) * Math.PI / 2; return [rb + (r - rb) * Math.sin(a), h * (1 - Math.cos(a))]; });
      const inn = out.slice().reverse().map(([x, z]) => [Math.max(0.5, x - t), Math.max(t, z)]).filter((q, i, s) => i === 0 || q[1] !== s[i - 1][1] || q[0] !== s[i - 1][0]);
      return lathe([[0, 0], ...out, ...inn, [0, t]], int(p.n, 12, 160, 64));
    } });
  add('ring', { name: 'Fingerring', cat: 'Alltag', params: [['d', 'Innen-Ø', 18], ['w', 'Breite', 5], ['t', 'Stärke', 1.8], ['n', 'Segmente', 96]],
    make: (p) => {
      const ri = num(p.d, 18) / 2, w = num(p.w, 5), t = num(p.t, 1.8), e = Math.min(0.4, t / 4, w / 4), k = 10;
      const outer = Array.from({ length: k + 1 }, (_, i) => { const z = (i / k) * w; return [ri + t * (0.7 + 0.3 * Math.sin((Math.PI * z) / w)), z]; });
      return lathe([[ri + e, 0], ...outer, [ri + e, w], [ri, w - e], [ri, e]], int(p.n, 24, 256, 96), true);
    } });
  add('capsule', { name: 'Kapsel', cat: 'Grund', params: [['r', 'Radius', 8], ['l', 'Länge', 40], ['n', 'Segmente', 48]],
    make: (p) => { const r = num(p.r, 8), l = Math.max(num(p.l, 40), 2 * r); return lathe([[0, 0], ...arc(0, r, r, -90, 0, 12).slice(1), ...arc(0, l - r, r, 0, 90, 12).slice(0, -1), [0, l]], int(p.n, 12, 160, 48)); } });
  add('rbox', { name: 'Abgerundeter Würfel', cat: 'Grund', params: [['w', 'Breite', 30], ['d', 'Tiefe', 30], ['h', 'Höhe', 30], ['r', 'Rundung', 4]],
    make: (p) => roundedBox(num(p.w, 30), num(p.d, 30), num(p.h, 30), Math.min(num(p.r, 4), num(p.w, 30) / 2, num(p.d, 30) / 2, num(p.h, 30) / 2)) });

  // Vorlagen aus mehreren Teilen (Teile bleiben einzeln editierbar)
  const PRESETS = [
    { name: 'Box mit Deckel', cat: 'Alltag', parts: [{ kind: 'openbox', p: {} }, { kind: 'lid', p: {}, at: [70, 0, 0] }] },
    { name: 'Namensschild', cat: 'Text', parts: [{ kind: 'plate', p: { w: 80, d: 24, h: 3, r: 4 }, color: '#4c7bf5' }, { kind: 'text', p: { t: 'Name', size: 14, h: 2 }, at: [0, 0, 3], color: '#e9ecef' }] },
    { name: 'Schraube', cat: 'Technik', parts: [{ kind: 'bolthead', p: {} }, { kind: 'thread', p: {}, at: [0, 0, 6.9] }] },
    { name: 'Buchstabe', cat: 'Text', parts: [{ kind: 'text', p: { t: 'A', size: 40, h: 8, bold: true, font: 'Arial Black' } }] },
    { name: 'Zahl', cat: 'Text', parts: [{ kind: 'text', p: { t: '7', size: 40, h: 8, bold: true, font: 'Arial Black' } }] },
    { name: 'Sechskant-Prisma', cat: 'Grund', parts: [{ kind: 'prism', p: { k: 6, r: 12, h: 20 } }] },
    { name: 'Unterlegscheibe', cat: 'Technik', parts: [{ kind: 'tube', p: { ro: 10, ri: 5.3, h: 2 } }] },
    { name: 'Kegelstumpf', cat: 'Grund', parts: [{ kind: 'cone', p: { r1: 12, r2: 6, h: 20, n: 64 } }] },
  ];
  // Galerie: Einzelformen + Vorlagen, nach Kategorie
  const CATS = ['Grund', 'Flach', 'Technik', 'Alltag', 'Text'];
  const GALLERY = CATS.map((c) => ({
    cat: c,
    items: [...Object.entries(SHAPES).filter(([, s]) => s.cat === c).map(([k, s]) => ({ name: s.name, parts: [{ kind: k, p: {} }] })), ...PRESETS.filter((p) => p.cat === c)],
  }));

  // kleine Vorschaubilder (Maler-Algorithmus auf 2D-Canvas)
  function thumb(mesh, size = 64) {
    const cv = document.createElement('canvas'); cv.width = cv.height = size * 2; const g = cv.getContext('2d');
    const bb = G.bbox(mesh); const c = bb.min.map((v, i) => (v + bb.max[i]) / 2); const s = Math.max(...bb.max.map((v, i) => v - bb.min[i])) || 1;
    const yaw = (-55 * Math.PI) / 180, pit = (28 * Math.PI) / 180;
    const P = (x, y, z) => { x -= c[0]; y -= c[1]; z -= c[2]; const X = x * Math.cos(yaw) - y * Math.sin(yaw); const Y = x * Math.sin(yaw) + y * Math.cos(yaw); return [X, z * Math.cos(pit) - Y * Math.sin(pit), Y * Math.cos(pit) + z * Math.sin(pit)]; };
    const tris = [];
    for (let i = 0; i < mesh.length; i += 9) {
      const a = P(mesh[i], mesh[i + 1], mesh[i + 2]), b = P(mesh[i + 3], mesh[i + 4], mesh[i + 5]), d = P(mesh[i + 6], mesh[i + 7], mesh[i + 8]);
      const nz = (b[0] - a[0]) * (d[1] - a[1]) - (b[1] - a[1]) * (d[0] - a[0]); if (nz <= 0) continue;
      const n = G.normal(mesh, i); tris.push([a, b, d, (a[2] + b[2] + d[2]) / 3, 0.35 + 0.45 * Math.max(0, n[2] * 0.7 + n[0] * 0.3 - n[1] * 0.2) + 0.2 * Math.abs(n[0])]);
    }
    tris.sort((m, n) => m[3] - n[3]);
    const k = (size * 2 * 0.8) / s, o = size;
    for (const [a, b, d, , l] of tris) {
      const v = Math.round(110 + 140 * Math.min(1, l)); g.fillStyle = g.strokeStyle = `rgb(${v * 0.55},${v * 0.85},${v})`;
      g.beginPath(); g.moveTo(o + a[0] * k, o - a[1] * k); g.lineTo(o + b[0] * k, o - b[1] * k); g.lineTo(o + d[0] * k, o - d[1] * k); g.closePath(); g.fill(); g.stroke();
    }
    return cv.toDataURL();
  }

  window.M3S = { GALLERY, PRESETS, thumb, extrude, earClip, stroke };
})();
