'use strict';

/* Sperrbildschirm der Kindersicherung: Tageslimit erreicht – nur der Eltern-PIN entsperrt. */
(() => {
  const q = new URLSearchParams(location.search);
  const used = Number(q.get('used')) || 0;
  const limit = Number(q.get('limit')) || 0;
  const fmt = (m) => (m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')} min` : `${m} min`);
  if (limit) document.getElementById('info').textContent = `Heute ${fmt(used)} von ${fmt(limit)} genutzt. Morgen geht es weiter – ein Elternteil kann mit dem PIN entsperren.`;
  const pin = document.getElementById('pin');
  const err = document.getElementById('err');
  setInterval(() => document.activeElement !== pin && pin.focus(), 1500);
  document.getElementById('f').addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    try {
      const r = await window.hub.parental.unlock(pin.value);
      if (!r?.ok) {
        err.textContent = 'Falscher PIN.';
        pin.value = '';
        const c = document.querySelector('.c');
        c.classList.remove('shake');
        void c.offsetWidth;
        c.classList.add('shake');
      }
    } catch (x) {
      err.textContent = String(x?.message || x).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
    }
  });
})();
