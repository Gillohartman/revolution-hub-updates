'use strict';

/*
 * 2.43 Kindersicherung – eingerichtet von einem Elternteil mit eigenem PIN.
 *
 *  - PIN: nur als gesalzener scrypt-Hash gespeichert, nie im Klartext.
 *  - Bildschirmzeit: Tageslimit für den PC (danach Sperrbildschirm mit PIN) und Limits pro App
 *    (danach wird die App für heute geschlossen). Gemessen mit der Bildschirmzeit des Hubs.
 *  - Webseiten: in allen Browsern über die Windows-hosts-Datei gesperrt (einmal Admin-Bestätigung),
 *    mit Kategorien und erlaubten Ausnahmen.
 *  - Schutz: startet mit Windows, Beenden nur mit PIN, Wächter-Aufgabe startet den Hub neu, wenn er beendet wird.
 *
 * Grenzen (ehrlich): Wer auf dem PC Administrator ist, kann das umgehen. Das Kind sollte darum ein
 * normales Windows-Konto (ohne Admin-Rechte) haben.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile, spawn } = require('child_process');

const HOSTS = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'drivers', 'etc', 'hosts');
const BEGIN = '# >>> Revulution Kindersicherung (nicht von Hand ändern) >>>';
const END = '# <<< Revulution Kindersicherung <<<';
const TASK = 'RevulutionHubWaechter';

// Kategorien zum schnellen Sperren
const CATEGORIES = {
  social: { name: 'Soziale Netzwerke', domains: ['tiktok.com', 'instagram.com', 'facebook.com', 'snapchat.com', 'x.com', 'twitter.com', 'reddit.com', 'pinterest.com', 'threads.net', 'bereal.com'] },
  video: { name: 'Videos & Streaming', domains: ['youtube.com', 'twitch.tv', 'netflix.com', 'disneyplus.com', 'primevideo.com', 'kick.com', 'dailymotion.com'] },
  games: { name: 'Spiele-Seiten', domains: ['roblox.com', 'poki.com', 'crazygames.com', 'miniclip.com', 'friv.com', 'epicgames.com', 'store.steampowered.com'] },
  chat: { name: 'Chat & Messenger', domains: ['discord.com', 'discord.gg', 'web.whatsapp.com', 'web.telegram.org', 'omegle.com', 'ome.tv', 'chatroulette.com'] },
  // 2.45.9: über 130 Seiten für Erwachsene (immer gesperrt, sobald die Kindersicherung an ist)
  adult: { name: 'Nicht jugendfrei', domains: [
    'pornhub.com', 'pornhub.org', 'pornhubpremium.com', 'xvideos.com', 'xvideos2.com', 'xvideos.red', 'xnxx.com', 'xnxx.tv', 'xhamster.com', 'xhamster.desi', 'xhamster2.com', 'xhamsterlive.com',
    'onlyfans.com', 'fansly.com', 'redtube.com', 'youporn.com', 'tube8.com', 'spankbang.com', 'eporner.com', 'tnaflix.com', 'empflix.com', 'beeg.com', 'porn.com', 'porntrex.com',
    'pornone.com', 'porn300.com', 'porndig.com', 'pornhat.com', 'pornmd.com', 'pornzog.com', 'pornoxo.com', 'porndoe.com', 'pornerbros.com', 'pornktube.com', 'pornflip.com', 'porngo.com',
    'youjizz.com', 'motherless.com', 'heavy-r.com', 'thumbzilla.com', 'drtuber.com', 'nuvid.com', 'sunporno.com', 'txxx.com', 'hclips.com', 'hdzog.com', 'upornia.com', 'voyeurhit.com',
    'vjav.com', 'javhd.com', 'javmost.com', 'javlibrary.com', 'jav.guru', 'missav.com', 'hentaihaven.xxx', 'hanime.tv', 'nhentai.net', 'rule34.xxx', 'rule34video.com', 'e-hentai.org',
    'gelbooru.com', 'hentai2read.com', 'tsumino.com', 'fakku.net', 'chaturbate.com', 'stripchat.com', 'bongacams.com', 'livejasmin.com', 'cam4.com', 'camsoda.com', 'myfreecams.com', 'flirt4free.com',
    'imlive.com', 'streamate.com', 'jerkmate.com', 'cams.com', 'camster.com', 'brazzers.com', 'realitykings.com', 'naughtyamerica.com', 'bangbros.com', 'mofos.com', 'digitalplayground.com', 'twistys.com',
    'babes.com', 'evilangel.com', 'vixen.com', 'tushy.com', 'blacked.com', 'deeper.com', 'kink.com', 'teamskeet.com', 'nubiles.net', 'metart.com', 'playboy.com', 'penthouse.com',
    'hustler.com', 'manyvids.com', 'clips4sale.com', 'iwantclips.com', 'modelhub.com', 'pornpics.com', 'pichunter.com', 'imagefap.com', 'sex.com', 'literotica.com', 'xart.com', 'adultfriendfinder.com',
    'fling.com', 'ashleymadison.com', 'xxxbunker.com', 'xbabe.com', 'fapster.xxx', 'fapdu.com', 'fuq.com', 'tube.xxx', 'ixxx.com', 'porntube.com', 'pornburst.xxx', 'perfectgirls.net',
    'definebabe.com', 'anysex.com', 'alphaporno.com', 'xxxymovies.com', 'gotporn.com', 'yourporn.sexy', 'sxyprn.com', 'daftsex.com', 'pornhd.com', 'hqporner.com', 'porntop.com', 'shooshtime.com',
    'xcafe.com', 'zbporn.com', 'faphouse.com', 'fapello.com', 'thothub.to', 'coomer.su', 'kemono.su', 'erome.com', 'redgifs.com', 'scrolller.com', 'reddxxx.com', 'xfantazy.com',
    'adultempire.com', 'aebn.com', 'hotmovies.com', 'pornpros.com', 'letsjerk.tv', 'cumlouder.com', 'vporn.com', 'porn00.org', 'whoreshub.com', 'fpo.xxx', 'pornwhite.com', 'xozilla.com',
  ] },
  gambling: { name: 'Glücksspiel', domains: ['stake.com', 'bet365.com', 'pokerstars.com', 'betway.com', 'unibet.com', 'roobet.com'] },
};

// 2.45: bei aktiver Kindersicherung gesperrte Programme (Terminal, Ausführen, Task-Manager, Registry)
const BLOCKED_EXE = ['cmd.exe', 'powershell.exe', 'pwsh.exe', 'powershell_ise.exe', 'WindowsTerminal.exe', 'wt.exe', 'OpenConsole.exe', 'Taskmgr.exe', 'regedit.exe', 'mmc.exe', 'ProcessHacker.exe', 'procexp.exe', 'procexp64.exe', 'SystemInformer.exe', 'bash.exe', 'wsl.exe'];

const DOH_KEYS = ['HKCU\\Software\\Policies\\Google\\Chrome', 'HKCU\\Software\\Policies\\Microsoft\\Edge', 'HKCU\\Software\\Policies\\BraveSoftware\\Brave'];
const cleanDomain = (d) => String(d || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/[/?#].*$/, '').replace(/[^a-z0-9.-]/g, '').slice(0, 120);
const hashPin = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString('hex');

class Parental {
  /** @param {{ settings: () => any, save: (p: any) => void, screen: () => any, notify: (t: string, b: string) => void, onLock: (on: boolean, info: any) => void, exePath: string, appRoot: string, packaged: boolean }} o */
  constructor(o) {
    this.o = o;
    this.unlockedUntil = 0; // nach richtiger PIN-Eingabe kurz entsperrt (Einstellungen ändern, Beenden)
    this.allowQuit = false;
    this.killed = {}; // heute geschlossene Apps
    this.timer = null;
  }

  cfg() {
    return { enabled: false, pinHash: '', pinSalt: '', dailyMin: 0, appLimits: {}, categories: [], blocked: [], allowed: [], extraMin: 0, extraDay: '', ...(this.o.settings().parental || {}) };
  }
  save(patch) {
    const c = { ...this.cfg(), ...patch };
    this.o.save({ parental: c });
    return c;
  }
  hasPin() {
    const c = this.cfg();
    return Boolean(c.pinHash && c.pinSalt);
  }
  unlocked() {
    return !this.cfg().enabled || Date.now() < this.unlockedUntil;
  }

  /** PIN prüfen (mit kleiner Bremse gegen Durchprobieren) */
  checkPin(pin) {
    const c = this.cfg();
    if (!this.hasPin()) return true;
    const now = Date.now();
    if (this.blockUntil && now < this.blockUntil) throw new Error(`Zu viele Versuche – warte ${Math.ceil((this.blockUntil - now) / 1000)} s.`);
    const ok = crypto.timingSafeEqual(Buffer.from(hashPin(pin, c.pinSalt), 'hex'), Buffer.from(c.pinHash, 'hex'));
    if (!ok) {
      this.fails = (this.fails || 0) + 1;
      if (this.fails >= 5) {
        this.blockUntil = now + 60000;
        this.fails = 0;
      }
      return false;
    }
    this.fails = 0;
    this.unlockedUntil = now + 10 * 60000;
    return true;
  }
  setPin(pin) {
    if (!/^\d{4,8}$/.test(String(pin))) throw new Error('Der PIN hat 4 bis 8 Ziffern.');
    if (this.hasPin() && !this.unlocked()) throw new Error('Erst mit dem alten PIN entsperren.');
    const salt = crypto.randomBytes(16).toString('hex');
    this.save({ pinHash: hashPin(pin, salt), pinSalt: salt });
    this.unlockedUntil = Date.now() + 10 * 60000;
    return true;
  }
  requireUnlocked() {
    if (!this.unlocked()) throw new Error('Gesperrt – bitte zuerst den Eltern-PIN eingeben.');
  }

  state() {
    const c = this.cfg();
    const sum = this.usage();
    return {
      enabled: c.enabled, hasPin: this.hasPin(), unlocked: this.unlocked(), dailyMin: c.dailyMin, appLimits: c.appLimits, categories: c.categories, blocked: c.blocked, allowed: c.allowed,
      catalog: Object.fromEntries(Object.entries(CATEGORIES).map(([k, v]) => [k, { name: v.name, count: v.domains.length }])),
      usedMin: Math.floor(sum.total / 60), apps: sum.apps, extraMin: c.extraDay === today() ? c.extraMin : 0, locked: Boolean(this.lockOn),
    };
  }
  usage() {
    try {
      const s = this.o.screen()?.summary?.();
      return { total: Number(s?.total) || 0, apps: (s?.apps || []).slice(0, 12).map((a) => ({ exe: a.exe, name: a.name, min: Math.floor((a.secs || 0) / 60) })) };
    } catch {
      return { total: 0, apps: [] };
    }
  }

  async update(patch = {}) {
    this.requireUnlocked();
    const c = this.cfg();
    const next = {};
    if (typeof patch.dailyMin === 'number') next.dailyMin = Math.max(0, Math.min(24 * 60, Math.round(patch.dailyMin)));
    if (patch.appLimits && typeof patch.appLimits === 'object') {
      next.appLimits = {};
      for (const [exe, min] of Object.entries(patch.appLimits)) {
        const e = String(exe).toLowerCase().replace(/[^a-z0-9._ -]/g, '').slice(0, 80);
        const m = Math.round(Number(min) || 0);
        if (e && m > 0) next.appLimits[e] = Math.min(24 * 60, m);
      }
    }
    if (Array.isArray(patch.categories)) next.categories = patch.categories.filter((k) => CATEGORIES[k]);
    if (Array.isArray(patch.blocked)) next.blocked = [...new Set(patch.blocked.map(cleanDomain).filter((d) => d.includes('.')))].slice(0, 300);
    if (Array.isArray(patch.allowed)) next.allowed = [...new Set(patch.allowed.map(cleanDomain).filter((d) => d.includes('.')))].slice(0, 300);
    const saved = this.save(next);
    const webChanged = ['categories', 'blocked', 'allowed'].some((k) => k in next);
    if (saved.enabled && webChanged) await this.applyHosts();
    return this.state();
  }

  /** Kindersicherung ein/aus (braucht PIN). Einschalten: Autostart, Wächter, Webseiten-Sperre. */
  async setEnabled(on) {
    if (!this.hasPin()) throw new Error('Lege zuerst einen Eltern-PIN fest.');
    this.requireUnlocked();
    this.save({ enabled: Boolean(on) });
    if (on) {
      this.autostart(true);
      await this.watchdog(true).catch(() => {});
      await this.applyHosts();
      this.start();
    } else {
      this.guardOff();
      await this.watchdog(false).catch(() => {});
      await this.applyHosts(true);
      clearInterval(this.procTimer);
      await this.systemLocks(false).catch(() => {});
      this.setLock(false);
    }
    return this.state();
  }
  /** Eltern geben heute Extra-Zeit */
  extraTime(min) {
    this.requireUnlocked();
    const c = this.cfg();
    const base = c.extraDay === today() ? c.extraMin : 0;
    this.save({ extraMin: base + Math.max(0, Math.min(600, Math.round(Number(min) || 0))), extraDay: today() });
    this.killed = {};
    this.setLock(false);
    return this.state();
  }

  autostart(on) {
    if (!this.o.packaged || process.platform !== 'win32') return;
    require('electron').app.setLoginItemSettings({ openAtLogin: Boolean(on), path: this.o.exePath, args: ['--hidden'] });
  }
  /* -------- 2.45.9 Schneller Wächter
     Ein kleiner, unsichtbarer PowerShell-Prozess wartet darauf, dass der Hub endet, und startet ihn
     sofort neu (statt erst nach bis zu einer Minute über die geplante Aufgabe). Er wird über WMI gestartet,
     gehört also nicht zum Prozessbaum des Hubs („Prozessstruktur beenden“ erwischt ihn nicht).
     Umgekehrt startet der Hub den Wächter alle paar Sekunden neu, falls er beendet wurde.
     Beenden mit Eltern-PIN oder Ausschalten der Kindersicherung schreibt „on: false“ → kein Neustart. */
  guardFile() { return path.join(this.o.userData, 'parental-guard.json'); }
  guardWrite(patch) {
    let cur = {};
    try { cur = JSON.parse(fs.readFileSync(this.guardFile(), 'utf8')); } catch { cur = {}; }
    const next = { ...cur, ...patch };
    fs.writeFileSync(this.guardFile(), JSON.stringify(next));
    return next;
  }
  guardOn() {
    if (process.platform !== 'win32') return;
    const dry = !this.o.packaged; // Entwicklung/Test: nur protokollieren statt neu starten
    const args = this.o.packaged ? ['--hidden'] : [this.o.appRoot, '--hidden'];
    this.guardWrite({ on: true, pid: process.pid, exe: this.o.exePath, args, dry, log: path.join(this.o.userData, 'parental-guard.log') });
    this.guardTick();
    clearInterval(this.guardTimer);
    this.guardTimer = setInterval(() => this.guardTick(), 5000);
  }
  guardOff() {
    clearInterval(this.guardTimer);
    try { this.guardWrite({ on: false }); } catch { /* egal */ }
  }
  guardTick() {
    let cur = {};
    try { cur = JSON.parse(fs.readFileSync(this.guardFile(), 'utf8')); } catch { return; }
    if (!cur.on) return;
    if (cur.gpid) { try { process.kill(cur.gpid, 0); return; } catch { /* Wächter weg → neu starten */ } }
    if (this.guardStarting) return;
    this.guardStarting = true;
    // Skript aus dem App-Paket (asar) in den Benutzerordner kopieren – PowerShell kann nicht ins Paket schauen
    const script = path.join(this.o.userData, 'parental-guard.ps1');
    try { fs.writeFileSync(script, fs.readFileSync(path.join(__dirname, 'parental-guard.ps1'))); } catch { this.guardStarting = false; return; }
    const cmd = `powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "${script}" -Config "${this.guardFile()}"`;
    const ps = `$si = New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ ShowWindow = [uint16]0 }; $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = '${cmd.replace(/'/g, "''")}'; ProcessStartupInformation = $si }; $r.ProcessId`;
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 15000 }, (err, out) => {
      this.guardStarting = false;
      const gpid = Number(String(out || '').trim());
      if (!err && gpid > 0) this.guardWrite({ gpid });
    });
  }

  /** Geplante Aufgabe: jede Minute den Hub starten (läuft er schon, passiert nichts). */
  watchdog(on) {
    if (process.platform !== 'win32' || !this.o.packaged) return Promise.resolve();
    const args = on
      ? ['/Create', '/F', '/SC', 'MINUTE', '/MO', '1', '/TN', TASK, '/TR', `"${this.o.exePath}" --hidden`]
      : ['/Delete', '/F', '/TN', TASK];
    return new Promise((resolve) => execFile('schtasks.exe', args, { windowsHide: true }, () => resolve()));
  }

  /** hosts-Datei: eigener Block zwischen BEGIN/END. Schreiben braucht einmal die Admin-Bestätigung (UAC). */
  domains() {
    const c = this.cfg();
    const set = new Set(c.blocked);
    // 2.45.9: Seiten für Erwachsene sind immer gesperrt, sobald die Kindersicherung an ist
    for (const k of new Set([...c.categories, 'adult'])) for (const d of CATEGORIES[k]?.domains || []) set.add(d);
    for (const a of c.allowed) set.delete(a);
    const out = [];
    for (const d of set) {
      out.push(d);
      if (!d.startsWith('www.')) out.push(`www.${d}`);
    }
    return out;
  }
  async applyHosts(remove = false) {
    if (process.platform !== 'win32') return false;
    let text = '';
    try {
      text = fs.readFileSync(HOSTS, 'utf8');
    } catch {
      text = '';
    }
    const re = new RegExp(`\\r?\\n?${BEGIN.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[\\s\\S]*?${END.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\r?\\n?`, 'g');
    let base = text.replace(re, '\r\n').replace(/\s+$/, '');
    const list = remove || !this.cfg().enabled ? [] : this.domains();
    const next = list.length ? `${base}\r\n\r\n${BEGIN}\r\n${list.map((d) => `0.0.0.0 ${d}`).join('\r\n')}\r\n${END}\r\n` : `${base}\r\n`;
    if (next === text) return true;
    try {
      fs.writeFileSync(HOSTS, next, 'utf8');
    } catch {
      // keine Rechte: einmal als Administrator schreiben (Windows fragt nach)
      const tmp = path.join(os.tmpdir(), `rev-hosts-${Date.now()}.txt`);
      fs.writeFileSync(tmp, next, 'utf8');
      const ps = `Start-Process -FilePath powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-Command',"Copy-Item -LiteralPath '${tmp.replace(/'/g, "''")}' -Destination '${HOSTS}' -Force; ipconfig /flushdns | Out-Null"`;
      await new Promise((resolve) => execFile('powershell.exe', ['-NoProfile', '-Command', ps], { windowsHide: true }, () => resolve()));
      try {
        fs.rmSync(tmp, { force: true });
      } catch {
        /* egal */
      }
      return fs.readFileSync(HOSTS, 'utf8') === next;
    }
    execFile('ipconfig', ['/flushdns'], { windowsHide: true }, () => {});
    return true;
  }

  /* -------- 2.45 System-Sperren: Task-Manager, Ausführen (Win+R), Terminals
     Alles über Benutzer-Richtlinien (HKCU) – kein Admin nötig, beim Ausschalten wieder entfernt. */
  async systemLocks(on) {
    if (process.platform !== 'win32') return;
    const reg = (args) => new Promise((resolve) => execFile('reg.exe', args, { windowsHide: true }, (e) => resolve(!e)));
    const SYS = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System';
    const EXP = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer';
    if (on) {
      await reg(['add', SYS, '/v', 'DisableTaskMgr', '/t', 'REG_DWORD', '/d', '1', '/f']);
      await reg(['add', EXP, '/v', 'NoRun', '/t', 'REG_DWORD', '/d', '1', '/f']);
      await reg(['add', EXP, '/v', 'DisallowRun', '/t', 'REG_DWORD', '/d', '1', '/f']);
      let i = 1;
      for (const exe of BLOCKED_EXE) await reg(['add', `${EXP}\\DisallowRun`, '/v', `rev${i++}`, '/t', 'REG_SZ', '/d', exe, '/f']);
      // 2.45.9: „Sicheres DNS“ in Chrome/Edge aus – sonst umgehen die Browser die Seiten-Sperre der hosts-Datei
      for (const b of DOH_KEYS) await reg(['add', b, '/v', 'DnsOverHttpsMode', '/t', 'REG_SZ', '/d', 'off', '/f']);
    } else {
      for (const b of DOH_KEYS) await reg(['delete', b, '/v', 'DnsOverHttpsMode', '/f']);
      await reg(['delete', SYS, '/v', 'DisableTaskMgr', '/f']);
      await reg(['delete', EXP, '/v', 'NoRun', '/f']);
      await reg(['delete', EXP, '/v', 'DisallowRun', '/f']);
      await reg(['delete', `${EXP}\\DisallowRun`, '/f']);
    }
    // Explorer sofort über die geänderten Richtlinien informieren (sonst erst nach Neuanmeldung)
    const ps = 'Add-Type -Namespace W -Name U -MemberDefinition \'[DllImport("user32.dll",CharSet=CharSet.Auto)] public static extern System.IntPtr SendMessageTimeout(System.IntPtr h,uint m,System.UIntPtr w,string l,uint f,uint t,out System.UIntPtr r);\'; $r=[UIntPtr]::Zero; [W.U]::SendMessageTimeout([IntPtr]0xffff,0x1A,[UIntPtr]::Zero,"Policy",2,3000,[ref]$r) | Out-Null';
    await new Promise((resolve) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 8000 }, () => resolve()));
  }

  /** Wächter: sichtbare Terminal-/Task-Manager-Fenster sofort schließen (die eigenen, versteckten
      PowerShell-Helfer des Hubs haben kein Fenster und bleiben unberührt). */
  watchProcs() {
    clearInterval(this.procTimer);
    if (!this.cfg().enabled || process.platform !== 'win32') return;
    const names = new Set(BLOCKED_EXE.map((x) => x.toLowerCase()));
    this.procTimer = setInterval(() => {
      if (!this.cfg().enabled || this.unlocked()) return;
      execFile('tasklist.exe', ['/FI', 'WINDOWTITLE ne N/A', '/FO', 'CSV', '/NH'], { windowsHide: true, timeout: 4000 }, (err, out) => {
        if (err) return;
        const hits = [];
        for (const line of String(out).split(/\r?\n/)) {
          const m = /^"([^"]+)","(\d+)"/.exec(line);
          if (m && names.has(m[1].toLowerCase())) hits.push({ name: m[1], pid: Number(m[2]) });
        }
        if (!hits.length) return;
        // Eltern-Prozess prüfen: alles, was der Hub selbst gestartet hat, bleibt verschont
        const filter = hits.map((h) => `ProcessId=${h.pid}`).join(' OR ');
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Get-CimInstance Win32_Process -Filter '${filter}' | ForEach-Object { "$($_.ProcessId) $($_.ParentProcessId)" }`], { windowsHide: true, timeout: 6000 }, (e2, out2) => {
          const parent = new Map(String(out2 || '').split(/\r?\n/).map((l) => l.trim().split(' ').map(Number)).filter((p) => p.length === 2));
          for (const h of hits) {
            if (!parent.has(h.pid) || parent.get(h.pid) === process.pid) continue;
            execFile('taskkill.exe', ['/PID', String(h.pid), '/T', '/F'], { windowsHide: true }, () => {});
            if (!this.warnedAt || Date.now() - this.warnedAt > 20000) {
              this.warnedAt = Date.now();
              this.o.notify('Kindersicherung', `${h.name} ist gesperrt. Den Task-Manager des Hubs findest du unter „Task-Manager“.`);
            }
          }
        });
      });
    }, 1500);
  }

  /* -------- laufende Prüfung (alle 30 s) */
  start() {
    clearInterval(this.timer);
    if (!this.cfg().enabled) {
      clearInterval(this.procTimer);
      return;
    }
    this.timer = setInterval(() => this.check(), 30000);
    setTimeout(() => this.check(), 3000);
    this.systemLocks(true).catch(() => {});
    this.watchProcs();
    this.guardOn();
  }
  check() {
    const c = this.cfg();
    if (!c.enabled) return this.setLock(false);
    if (this.day !== today()) {
      this.day = today();
      this.killed = {};
    }
    const u = this.usage();
    const extra = c.extraDay === today() ? c.extraMin : 0;
    // Tageslimit für den ganzen PC
    if (c.dailyMin > 0 && u.total / 60 >= c.dailyMin + extra && !this.unlocked()) this.setLock(true, { usedMin: Math.floor(u.total / 60), limit: c.dailyMin + extra });
    else if (this.lockOn && (c.dailyMin === 0 || u.total / 60 < c.dailyMin + extra || this.unlocked())) this.setLock(false);
    // Limits pro App
    for (const [exe, min] of Object.entries(c.appLimits || {})) {
      const a = u.apps.find((x) => String(x.exe).toLowerCase() === exe);
      if (!a || a.min < min + extra || this.unlocked()) continue;
      execFile('taskkill.exe', ['/IM', exe, '/F'], { windowsHide: true }, () => {});
      if (!this.killed[exe]) {
        this.killed[exe] = true;
        this.o.notify('Zeit aufgebraucht', `${a.name || exe}: Das Limit von ${min} min für heute ist erreicht.`);
      }
    }
  }
  setLock(on, info = {}) {
    if (Boolean(this.lockOn) === Boolean(on)) return;
    this.lockOn = Boolean(on);
    this.o.onLock(this.lockOn, info);
  }
}

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

module.exports = { Parental, CATEGORIES };
