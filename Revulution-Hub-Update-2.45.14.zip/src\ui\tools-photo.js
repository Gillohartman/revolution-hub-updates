'use strict';

/*
 * Runde 11a – Foto: Bildbearbeitung im Stil von Photoshop.
 *   • Dokumente in Registerkarten: Neu, Öffnen (Datei, Einfügen, Hineinziehen), Export PNG/JPG/WebP, eigenes Projektformat .rvfoto (mit Ebenen)
 *   • Ebenen: Pixel-, Text- und Einstellungsebenen, Deckkraft, Füllmethoden, Ebenenmasken, Reihenfolge, Auf eine Ebene reduzieren
 *   • Werkzeuge: Verschieben, Auswahlrechteck/-ellipse, Lasso, Zauberstab, Freistellen, Pipette, Kopierstempel, Pinsel,
 *     Radiergummi, Füllen, Verlauf, Text, Formen, Hand, Zoom – und Frei transformieren (Strg+T)
 *   • Bild: Bildgrösse (neu berechnen), Arbeitsfläche, Drehen/Spiegeln; Korrekturen nicht-destruktiv als Einstellungsebenen
 *   • Filter: Gaussscher Weichzeichner, Bewegungsunschärfe, Unscharf maskieren, Rauschen hinzufügen/entfernen, Mosaik
 *   • Protokoll (Rückgängig in Schritten) und Tastaturbefehle wie in Photoshop
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-photo';
  // 11c: Verschieben-Zeiger (Pfeil + kleines Kreuz) statt des groben Windows-Kreuzpfeils
  const MOVE_CURSOR = `url("data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><path d="M3 2v15l3.6-3.4 2.6 5.6 2.2-1-2.6-5.4H14Z" fill="#111" stroke="#fff" stroke-width="1.2" stroke-linejoin="round"/><g stroke="#fff" stroke-width="3" stroke-linecap="round"><path d="M18 13v9M13.5 17.5h9"/></g><g stroke="#111" stroke-width="1.3" stroke-linecap="round"><path d="M18 13v9M13.5 17.5h9"/></g></svg>')}") 3 2, default`;

  /* ================================================================ Symbole */
  const P = (d, extra = '') => `<path d="${d}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
  const IC = {
    move: P('M12 6v12M6 12h12') + '<path d="M12 2.6 9.2 5.8h5.6ZM12 21.4l-2.8-3.2h5.6ZM2.6 12l3.2-2.8v5.6ZM21.4 12l-3.2-2.8v5.6Z" fill="currentColor"/>', // 11c: klare, gefüllte Pfeilspitzen
    marquee: P('M4 5h16v14H4z', 'stroke-dasharray="2.6 2.2"'),
    ellipse: `<ellipse cx="12" cy="12" rx="8.5" ry="6.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-dasharray="2.6 2.2"/>`,
    lasso: P('M8.5 15.5C4.5 14.6 3 12 4.3 9.3 6 5.6 12.5 4.4 16.8 6c4.3 1.6 4.3 5.7.6 7.6-2.8 1.5-6.4 1.6-8.9 1.9z M8.5 15.5c-1.6.9-1.7 2.9-.4 3.8 1 .7 2.2.3 2.6-.6'),
    wand: P('M4 20l10-10 M14 10l2-2 M17 3v2.5 M17 10.5V13 M11.5 8H14 M20 8h2.5 M13 4l1.5 1.5 M21 4l-1.5 1.5 M21 12l-1.5-1.5'),
    crop: P('M7 2v15h15 M2 7h15v15'),
    eyedropper: P('M14.5 5.5l4 4 M16.6 2.9a2 2 0 0 1 2.9 0l1.6 1.6a2 2 0 0 1 0 2.9l-2.5 2.5-4.5-4.5z M13.5 7.5L5 16v3h3l8.5-8.5'),
    clone: P('M9.5 3.5h5v3.5l-1 4.5h5.5v3.5H5V11.5h5.5l-1-4.5z M5 19h14 M7 21.5h10'),
    brush: P('M19 3.2a2 2 0 0 1 2.8 2.8L12.5 15.3l-2.8-2.8z M9 13.2c-2.6-.2-4.3 1.4-4.4 3.9 0 1.6-.9 2.4-2.1 2.9 4.6 1.4 8.4-.4 8.9-3.8z'),
    eraser: P('M8 20h12 M5.5 16.5l9-9 5 5-6.5 6.5H9z M10 12l5 5'),
    bucket: P('M5 11.5l7-7 7 7-7 7z M5 11.5h14 M20.5 15.5s1.8 2.1 1.8 3.2a1.8 1.8 0 0 1-3.6 0c0-1.1 1.8-3.2 1.8-3.2'),
    gradient: `<defs><linearGradient id="phIcG" x1="0" x2="1"><stop offset="0" stop-color="currentColor"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs><rect x="3.5" y="5.5" width="17" height="13" rx="1.5" fill="url(#phIcG)" stroke="currentColor" stroke-width="1.4"/>`,
    text: P('M5 6.5V4h14v2.5 M12 4v16 M9 20h6'),
    shape: P('M3.5 3.5h10v10h-10z') + `<circle cx="15.5" cy="15.5" r="5" fill="currentColor" opacity=".85"/>`,
    hand: P('M8 13V5.5a1.5 1.5 0 0 1 3 0V12 M11 11V4.5a1.5 1.5 0 0 1 3 0V12 M14 11.5V6a1.5 1.5 0 0 1 3 0v7.5 M8 12.5L6.5 11a1.6 1.6 0 0 0-2.3 2.2L8 18c1.5 2 3 3 6 3a5 5 0 0 0 5-5V9.5a1.5 1.5 0 0 0-3 0'),
    zoom: P('M10.5 17.5a7 7 0 1 0 0-14 7 7 0 0 0 0 14z M20.5 20.5l-5-5 M7.5 10.5h6 M10.5 7.5v6'),
    zoomout: P('M10.5 17.5a7 7 0 1 0 0-14 7 7 0 0 0 0 14z M20.5 20.5l-5-5 M7.5 10.5h6'),
    swap: P('M14 4h4.5a1.5 1.5 0 0 1 1.5 1.5V10 M17.5 7.5L20 10l2.5-2.5 M10 20H5.5A1.5 1.5 0 0 1 4 18.5V14 M1.5 16.5L4 14l2.5 2.5'),
    eye: P('M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z M12 14.8a2.8 2.8 0 1 0 0-5.6 2.8 2.8 0 0 0 0 5.6z'),
    plus: P('M4.5 4.5h15v15h-15z M12 8.5v7 M8.5 12h7'),
    trash: P('M4 7h16 M9 7V4.5h6V7 M6 7l1 13h10l1-13 M10 11v6 M14 11v6'),
    mask: P('M4 4h16v16H4z') + `<circle cx="12" cy="12" r="4.6" fill="currentColor"/>`,
    adjust: `<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/>`,
    link: P('M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1 M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1'),
    chain: P('M9 3.5h6v6H9z M9 14.5h6v6H9z M12 9.5v5'),
    close: P('M6 6l12 12M18 6L6 18'),
    check: P('M5 12.5l4.5 4.5L19 7.5'),
    newdoc: P('M6 3h8l5 5v13H6z M14 3v5h5 M12.5 11v7 M9 14.5h7'),
    open: P('M3 7V5.5A1.5 1.5 0 0 1 4.5 4H9l2 2.5h8.5A1.5 1.5 0 0 1 21 8v1 M3 7v11.5A1.5 1.5 0 0 0 4.5 20h13.8a1.5 1.5 0 0 0 1.5-1.2L21.5 11a1.5 1.5 0 0 0-1.5-1.8H7a1.5 1.5 0 0 0-1.5 1.2L3 20'),
    paste: P('M9 4h6v3H9z M9 5.5H6.5A1.5 1.5 0 0 0 5 7v12.5A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5V7a1.5 1.5 0 0 0-1.5-1.5H15'),
    textlayer: P('M6 7V5h12v2 M12 5v14 M9.5 19h5'),
    sel_new: `<rect x="5" y="5" width="14" height="14" fill="currentColor" opacity=".9"/>`,
    sel_add: `<rect x="3" y="3" width="11" height="11" fill="currentColor" opacity=".9"/><rect x="10" y="10" width="11" height="11" fill="currentColor" opacity=".9"/>`,
    sel_sub: `<rect x="3" y="3" width="11" height="11" fill="currentColor" opacity=".9"/><rect x="10" y="10" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.4"/>`,
    sel_int: `<rect x="3" y="3" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.4"/><rect x="10" y="10" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.4"/><rect x="10" y="10" width="4" height="4" fill="currentColor"/>`,
    // Korrekturen
    bc: `<circle cx="12" cy="12" r="4" fill="currentColor"/>${P('M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8')}`,
    levels: `<path d="M3 20V15l2-3 2 2 2-6 2 4 2-7 2 5 2-2 2 4 2 1v7z" fill="currentColor" opacity=".9"/>`,
    curves: `${P('M4 4h16v16H4z', 'opacity=".5"')}${P('M4 20C9 19 10 13 12 11s4-6 8-7')}`,
    hsl: `<path d="M12 3l8.5 15h-17z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 9l4.3 7.6H7.7z" fill="currentColor"/>`,
    balance: P('M12 4v16 M7 20h10 M4 8h16 M4 8l-2 6a2.5 2.5 0 0 0 4 0z M20 8l-2 6a2.5 2.5 0 0 0 4 0z'),
    bw: `<rect x="4" y="4" width="16" height="16" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4 20L20 4v16z" fill="currentColor"/>`,
    invert: `<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12 4a8 8 0 0 0 0 16z" fill="currentColor"/><path d="M12 8a4 4 0 0 1 0 8z" fill="currentColor"/>`,
    pixel: P('M4 4h16v16H4z') + `<path d="M4 16l5-5 4 4 2-2 5 5" fill="none" stroke="currentColor" stroke-width="1.4"/>`,
  };
  const svg = (n, s = 18) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" aria-hidden="true">${IC[n] || ''}</svg>`;

  /* ================================================================ Werkzeuge & Optionen */
  const TOOLS = [
    ['move', 'Verschieben-Werkzeug', 'V'], '-',
    ['marquee', 'Auswahlrechteck-Werkzeug', 'M'], ['ellipse', 'Auswahlellipse-Werkzeug', 'M'], ['lasso', 'Lasso-Werkzeug', 'L'], ['wand', 'Zauberstab-Werkzeug', 'W'], '-',
    ['crop', 'Freistellungswerkzeug', 'C'], ['eyedropper', 'Pipette', 'I'], '-',
    ['clone', 'Kopierstempel', 'S'], ['brush', 'Pinsel', 'B'], ['eraser', 'Radiergummi', 'E'], ['bucket', 'Füllwerkzeug', 'G'], ['gradient', 'Verlaufswerkzeug', 'G'], '-',
    ['text', 'Horizontales Textwerkzeug', 'T'], ['shape', 'Form-Werkzeug', 'U'], '-',
    ['hand', 'Hand-Werkzeug', 'H'], ['zoom', 'Zoom-Werkzeug', 'Z'],
  ];
  const TOOL_NAME = Object.fromEntries(TOOLS.filter(Array.isArray).map((t) => [t[0], t[1]]));
  const PAINT = new Set(['brush', 'eraser', 'clone']);
  const BLENDS = [
    ['source-over', 'Normal'], '-', ['darken', 'Abdunkeln'], ['multiply', 'Multiplizieren'], ['color-burn', 'Farbig nachbelichten'], '-',
    ['lighten', 'Aufhellen'], ['screen', 'Negativ multiplizieren'], ['color-dodge', 'Farbig abwedeln'], '-',
    ['overlay', 'Ineinanderkopieren'], ['soft-light', 'Weiches Licht'], ['hard-light', 'Hartes Licht'], '-',
    ['difference', 'Differenz'], ['exclusion', 'Ausschluss'], '-', ['hue', 'Farbton'], ['saturation', 'Sättigung'], ['color', 'Farbe'], ['luminosity', 'Luminanz'],
  ];
  const FONTS = ['Segoe UI', 'Arial', 'Helvetica', 'Calibri', 'Verdana', 'Tahoma', 'Georgia', 'Times New Roman', 'Garamond', 'Trebuchet MS', 'Impact', 'Consolas', 'Courier New', 'Comic Sans MS', 'Segoe Script'];
  const SWATCHES = ['#000000', '#ffffff', '#808080', '#c0c0c0', '#ff0000', '#ff8000', '#ffff00', '#80ff00', '#00ff00', '#00ff80', '#00ffff', '#0080ff', '#0000ff', '#8000ff', '#ff00ff', '#ff0080',
    '#7f1d1d', '#9a3412', '#a16207', '#3f6212', '#166534', '#115e59', '#155e75', '#1e3a8a', '#3730a3', '#6b21a8', '#9d174d', '#f5d0a9', '#d2a679', '#8b5a2b', '#5c3a1e', '#2b1d14'];
  const ZOOMS = [0.03125, 0.0625, 0.0833, 0.125, 0.1667, 0.25, 0.3333, 0.5, 0.6667, 1, 2, 3, 4, 5, 6, 7, 8, 12, 16, 32];

  const st = {
    root: null, el: {}, docs: [], doc: null, tool: 'brush', prevTool: null, fg: '#000000', bg: '#ffffff', colorTarget: 'fg', hue: 0,
    opt: {
      size: 30, hardness: 80, opacity: 100, flow: 100, pressure: true, tolerance: 32, contiguous: true, antialias: true, sampleAll: false,
      selMode: 'new', feather: 0, gradType: 'linear', gradMode: 'fgbg', gradReverse: false, shape: 'rect', shapeFill: true, shapeStroke: 0,
      shapeStrokeColor: '#000000', radius: 16, font: 'Segoe UI', fontSize: 48, bold: false, italic: false, align: 'left',
      autoSelect: false, cropRatio: 'free', cloneAligned: true, sample: 1, zoomOut: false,
    },
    drag: null, space: false, mouse: null, antsOff: 0, timer: 0, raf: 0, needComp: true, dlg: null, menu: null, clip: null,
    crop: null, xf: null, textEdit: null, cloneSrc: null, lastPt: null, ro: null, dpr: 1, colorTab: 'color', adjTab: 'adjust', layerSeq: 0,
  };
  const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
  const clone = (o) => (o == null ? o : JSON.parse(JSON.stringify(o)));
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const fmt = (v, d = 0) => Number(v).toLocaleString('de-CH', { maximumFractionDigits: d, minimumFractionDigits: 0 });
  const toast = (m, k) => A.toast(m, k);

  /* ================================================================ Farben */
  const hex2rgb = (h) => {
    h = String(h || '#000').replace('#', '');
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    const n = parseInt(h.slice(0, 6), 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  };
  const rgb2hex = (r, g, b) => '#' + [r, g, b].map((v) => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
  function rgb2hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return [(h * 60 + 360) % 360, mx ? d / mx : 0, mx];
  }
  function hsv2rgb(h, s, v) {
    const f = (n) => { const k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
    return [f(5) * 255, f(3) * 255, f(1) * 255];
  }
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    if (!d) return [0, 0, l];
    const s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    let h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return [h * 60, s, l];
  }
  function hsl2rgb(h, s, l) {
    if (!s) return [l * 255, l * 255, l * 255];
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const t = (x) => {
      x = ((x % 1) + 1) % 1;
      return 255 * (x < 1 / 6 ? p + (q - p) * 6 * x : x < 0.5 ? q : x < 2 / 3 ? p + (q - p) * (2 / 3 - x) * 6 : p);
    };
    h /= 360;
    return [t(h + 1 / 3), t(h), t(h - 1 / 3)];
  }
  const lum = (hex) => { const [r, g, b] = hex2rgb(hex); return 0.299 * r + 0.587 * g + 0.114 * b; };
  const rgba = (hex, a) => { const [r, g, b] = hex2rgb(hex); return `rgba(${r},${g},${b},${a})`; };

  /* ================================================================ Leinwand-Helfer */
  function mk(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    return c;
  }
  const g2 = (c) => c.getContext('2d');
  function copyC(src) {
    const c = mk(src.width, src.height);
    g2(c).drawImage(src, 0, 0);
    return c;
  }
  const pool = [];
  /** Wiederverwendbare Arbeitsfläche Nr. i (geleert, Standard-Zustand). */
  function tmp(i, w, h) {
    let c = pool[i];
    if (!c) c = pool[i] = mk(w, h);
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    const g = g2(c);
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
    g.filter = 'none';
    g.imageSmoothingEnabled = true;
    g.clearRect(0, 0, w, h);
    return c;
  }
  function reset(g) {
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
    g.filter = 'none';
  }
  /** dst = dst·(1 − m·a) + src·m·a  (m = Maske oder überall 1) – exaktes Überblenden in vormultiplizierten Farben. */
  function mixInto(dst, src, mask, a = 1) {
    const w = dst.width, h = dst.height;
    const t = tmp(2, w, h), tg = g2(t);
    tg.drawImage(src, 0, 0);
    if (mask) { tg.globalCompositeOperation = 'destination-in'; tg.drawImage(mask, 0, 0); }
    const g = g2(dst);
    g.save();
    reset(g);
    g.globalAlpha = a;
    g.globalCompositeOperation = 'destination-out';
    if (mask) g.drawImage(mask, 0, 0); else { g.fillStyle = '#000'; g.fillRect(0, 0, w, h); }
    g.globalCompositeOperation = 'lighter';
    g.drawImage(t, 0, 0);
    g.restore();
  }
  /** Begrenzungsrahmen der sichtbaren Pixel (oder null). */
  function contentBox(c) {
    const w = c.width, h = c.height, d = g2(c).getImageData(0, 0, w, h).data;
    let x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (let y = 0; y < h; y++) {
      const row = y * w * 4;
      for (let x = 0; x < w; x++) {
        if (d[row + x * 4 + 3]) {
          if (x < x0) x0 = x;
          if (x > x1) x1 = x;
          if (y < y0) y0 = y;
          y1 = y;
        }
      }
    }
    return x1 < 0 ? null : { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 };
  }
  /** Hochwertig neu berechnen (beim Verkleinern in Halbierungs-Schritten). */
  function resample(src, nw, nh, method = 'auto') {
    nw = Math.max(1, Math.round(nw));
    nh = Math.max(1, Math.round(nh));
    if (method === 'nearest') {
      const c = mk(nw, nh), g = g2(c);
      g.imageSmoothingEnabled = false;
      g.drawImage(src, 0, 0, nw, nh);
      return c;
    }
    let cur = src, cw = src.width, ch = src.height;
    if (method !== 'bilinear') {
      while (cw / 2 >= nw && ch / 2 >= nh) {
        cw = Math.round(cw / 2); ch = Math.round(ch / 2);
        const c = mk(cw, ch), g = g2(c);
        g.imageSmoothingQuality = 'high';
        g.drawImage(cur, 0, 0, cw, ch);
        cur = c;
      }
    }
    const c = mk(nw, nh), g = g2(c);
    g.imageSmoothingEnabled = true;
    g.imageSmoothingQuality = method === 'bilinear' ? 'low' : 'high';
    g.drawImage(cur, 0, 0, nw, nh);
    return c;
  }
  let checkerPat = null;
  function checker(g) {
    if (!checkerPat) {
      const c = mk(16, 16), cg = g2(c);
      cg.fillStyle = '#ffffff'; cg.fillRect(0, 0, 16, 16);
      cg.fillStyle = '#cccccc'; cg.fillRect(0, 0, 8, 8); cg.fillRect(8, 8, 8, 8);
      checkerPat = c;
    }
    return g.createPattern(checkerPat, 'repeat');
  }

  /* ================================================================ Dokument & Ebenen */
  function newLayer(doc, props = {}) {
    const l = {
      id: uid(), name: props.name || `Ebene ${++doc.seq}`, kind: 'pixel', visible: true, opacity: 1, blend: 'source-over',
      canvas: null, mask: null, maskOn: true, editMask: false, adj: null, text: null, rev: 0, snap: null, msnap: null, snapRev: -1, temp: null, preview: null,
      ...props,
    };
    if (l.kind !== 'adj' && !l.canvas) l.canvas = mk(doc.w, doc.h);
    return l;
  }
  function makeDoc({ name = 'Unbenannt-1', w = 1920, h = 1080, dpi = 72, fill = '#ffffff' } = {}) {
    const doc = { id: uid(), name, w: Math.round(w), h: Math.round(h), dpi, layers: [], active: null, sel: null, lastSel: null, hist: [], hi: -1, zoom: 1, px: 0, py: 0, seq: 0, dirty: false, file: null, comp: null };
    if (fill) {
      const l = newLayer(doc, { name: 'Hintergrund' });
      const g = g2(l.canvas);
      g.fillStyle = fill;
      g.fillRect(0, 0, doc.w, doc.h);
      doc.layers.push(l);
      doc.active = l.id;
    } else {
      const l = newLayer(doc);
      doc.layers.push(l);
      doc.active = l.id;
    }
    return doc;
  }
  const D = () => st.doc;
  const active = (doc = D()) => doc && (doc.layers.find((l) => l.id === doc.active) || doc.layers[doc.layers.length - 1]);
  const touch = (l) => { if (l) l.rev++; };

  /* ================================================================ Protokoll (Rückgängig) */
  const HIST_MAX = 40;
  function snapshot(doc, label) {
    const layers = doc.layers.map((l) => {
      if (l.snapRev !== l.rev) {
        l.snap = l.canvas ? copyC(l.canvas) : null;
        l.msnap = l.mask ? copyC(l.mask) : null;
        l.snapRev = l.rev;
      }
      return { id: l.id, name: l.name, kind: l.kind, visible: l.visible, opacity: l.opacity, blend: l.blend, maskOn: l.maskOn, adj: clone(l.adj), text: clone(l.text), canvas: l.snap, mask: l.msnap, rev: l.rev };
    });
    return { label, w: doc.w, h: doc.h, dpi: doc.dpi, layers, active: doc.active, sel: doc.sel ? doc.sel.mask : null, seq: doc.seq };
  }
  /** Neuen Schritt ins Protokoll schreiben (nach einer Änderung). */
  function commit(label, doc = D()) {
    if (!doc) return;
    doc.hist = doc.hist.slice(0, doc.hi + 1);
    doc.hist.push(snapshot(doc, label));
    if (doc.hist.length > HIST_MAX) doc.hist.splice(1, doc.hist.length - HIST_MAX);
    doc.hi = doc.hist.length - 1;
    if (doc.hist.length > 1) doc.dirty = true;
    refresh();
  }
  function restore(doc, s) {
    const old = new Map(doc.layers.map((l) => [l.id, l]));
    doc.w = s.w; doc.h = s.h; doc.dpi = s.dpi; doc.seq = s.seq;
    doc.layers = s.layers.map((x) => {
      const o = old.get(x.id);
      const l = { ...x, editMask: o?.editMask && !!x.mask, temp: null, preview: null, snap: x.canvas, msnap: x.mask, snapRev: x.rev, canvas: x.canvas ? copyC(x.canvas) : null, mask: x.mask ? copyC(x.mask) : null, adj: clone(x.adj), text: clone(x.text) };
      return l;
    });
    doc.active = s.active;
    setSel(s.sel, null, doc);
    st.crop = null; st.xf = null;
    st.needComp = true;
  }
  function undo() {
    const doc = D();
    if (!doc || st.drag) return;
    if (st.xf) return cancelTransform();
    if (doc.hi <= 0) return;
    doc.hi--;
    restore(doc, doc.hist[doc.hi]);
    doc.dirty = true;
    refresh();
  }
  function redo() {
    const doc = D();
    if (!doc || st.drag || doc.hi >= doc.hist.length - 1) return;
    doc.hi++;
    restore(doc, doc.hist[doc.hi]);
    refresh();
  }
  function jumpHistory(i) {
    const doc = D();
    if (!doc || i < 0 || i >= doc.hist.length) return;
    doc.hi = i;
    restore(doc, doc.hist[i]);
    refresh();
  }

  /* ================================================================ Auswahl */
  /** Auswahl setzen (Maske = Alpha-Kanal einer Leinwand). Rechnet Rand-Pfad für die „laufenden Ameisen“. */
  function setSel(mask, label, doc = D()) {
    if (!doc) return;
    if (!mask) {
      if (doc.sel) doc.lastSel = doc.sel.mask;
      doc.sel = null;
    } else {
      const info = selInfo(mask);
      if (!info) {
        if (doc.sel) doc.lastSel = doc.sel.mask;
        doc.sel = null;
      } else doc.sel = { mask, ...info };
    }
    if (label) commit(label, doc);
  }
  function selInfo(mask) {
    const w = mask.width, h = mask.height, d = g2(mask).getImageData(0, 0, w, h).data;
    const a = new Uint8Array(w * h);
    let x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (let y = 0, i = 0; y < h; y++) {
      for (let x = 0; x < w; x++, i++) {
        if (d[i * 4 + 3] >= 128) {
          a[i] = 1;
          if (x < x0) x0 = x;
          if (x > x1) x1 = x;
          if (y < y0) y0 = y;
          y1 = y;
        }
      }
    }
    if (x1 < 0) return null;
    const A_ = (x, y) => (x < 0 || y < 0 || x >= w || y >= h ? 0 : a[y * w + x]);
    const path = new Path2D();
    for (let y = y0; y <= y1 + 1; y++) {
      let run = -1;
      for (let x = x0; x <= x1 + 1; x++) {
        const edge = x <= x1 && A_(x, y - 1) !== A_(x, y);
        if (edge) { if (run < 0) run = x; } else if (run >= 0) { path.moveTo(run, y); path.lineTo(x, y); run = -1; }
      }
    }
    for (let x = x0; x <= x1 + 1; x++) {
      let run = -1;
      for (let y = y0; y <= y1 + 1; y++) {
        const edge = y <= y1 && A_(x - 1, y) !== A_(x, y);
        if (edge) { if (run < 0) run = y; } else if (run >= 0) { path.moveTo(x, run); path.lineTo(x, y); run = -1; }
      }
    }
    return { path, box: { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 } };
  }
  /** Form-Maske mit dem Auswahl-Modus (neu/hinzufügen/subtrahieren/Schnittmenge) verrechnen. */
  function combineSel(shape, mode, label) {
    const doc = D();
    if (st.opt.feather > 0) {
      const f = tmp(3, doc.w, doc.h), fg = g2(f);
      fg.filter = `blur(${st.opt.feather / 2}px)`;
      fg.drawImage(shape, 0, 0);
      fg.filter = 'none';
      shape = copyC(f);
    }
    let m;
    if (mode === 'new' || !doc.sel) {
      if ((mode === 'sub' || mode === 'int') && !doc.sel) return;
      m = shape;
    } else {
      m = copyC(doc.sel.mask);
      const g = g2(m);
      g.globalCompositeOperation = mode === 'add' ? 'source-over' : mode === 'sub' ? 'destination-out' : 'destination-in';
      g.drawImage(shape, 0, 0);
    }
    setSel(m, label);
  }
  function selectAll() {
    const doc = D();
    if (!doc) return;
    const m = mk(doc.w, doc.h), g = g2(m);
    g.fillRect(0, 0, doc.w, doc.h);
    setSel(m, 'Alles auswählen');
  }
  function deselect() {
    const doc = D();
    if (doc?.sel) setSel(null, 'Auswahl aufheben');
  }
  function reselect() {
    const doc = D();
    if (doc?.lastSel) setSel(doc.lastSel, 'Erneut wählen');
  }
  function invertSel() {
    const doc = D();
    if (!doc) return;
    const m = mk(doc.w, doc.h), g = g2(m);
    g.fillRect(0, 0, doc.w, doc.h);
    if (doc.sel) { g.globalCompositeOperation = 'destination-out'; g.drawImage(doc.sel.mask, 0, 0); }
    setSel(m, 'Auswahl umkehren');
  }
  /** Auswahl weicher / grösser / kleiner (über Weichzeichnen + Schwelle). */
  function modifySel(kind, r) {
    const doc = D();
    if (!doc?.sel || !(r > 0)) return;
    const m = mk(doc.w, doc.h), g = g2(m);
    g.filter = `blur(${kind === 'feather' ? r / 2 : r / 2.2}px)`;
    g.drawImage(doc.sel.mask, 0, 0);
    g.filter = 'none';
    if (kind !== 'feather') {
      const id = g.getImageData(0, 0, doc.w, doc.h), d = id.data;
      const th = kind === 'expand' ? 6 : 249;
      for (let i = 3; i < d.length; i += 4) d[i] = d[i] >= th ? 255 : 0;
      g.putImageData(id, 0, 0);
    }
    setSel(m, kind === 'feather' ? 'Weiche Auswahlkante' : kind === 'expand' ? 'Auswahl erweitern' : 'Auswahl verkleinern');
  }
  /** Bereich gleicher Farbe (Zauberstab/Füllwerkzeug) → Maske. */
  function regionMask(src, x, y, tol, contiguous, antialias) {
    const w = src.width, h = src.height;
    x = Math.floor(x); y = Math.floor(y);
    if (x < 0 || y < 0 || x >= w || y >= h) return null;
    const d = g2(src).getImageData(0, 0, w, h).data;
    const i0 = (y * w + x) * 4, r0 = d[i0], g0 = d[i0 + 1], b0 = d[i0 + 2], a0 = d[i0 + 3];
    const same = (i) => {
      const j = i * 4;
      if (a0 === 0 && d[j + 3] === 0) return true;
      return Math.abs(d[j] - r0) <= tol && Math.abs(d[j + 1] - g0) <= tol && Math.abs(d[j + 2] - b0) <= tol && Math.abs(d[j + 3] - a0) <= tol;
    };
    const out = new Uint8Array(w * h);
    if (!contiguous) {
      for (let i = 0; i < w * h; i++) if (same(i)) out[i] = 1;
    } else {
      const stack = [x, y];
      while (stack.length) {
        const sy = stack.pop(), sx0 = stack.pop();
        let sx = sx0;
        let i = sy * w + sx;
        if (out[i] || !same(i)) continue;
        while (sx > 0 && !out[i - 1] && same(i - 1)) { sx--; i--; }
        let up = false, dn = false;
        for (; sx < w && !out[i] && same(i); sx++, i++) {
          out[i] = 1;
          if (sy > 0) {
            const u = i - w;
            if (!out[u] && same(u)) { if (!up) { stack.push(sx, sy - 1); up = true; } } else up = false;
          }
          if (sy < h - 1) {
            const v = i + w;
            if (!out[v] && same(v)) { if (!dn) { stack.push(sx, sy + 1); dn = true; } } else dn = false;
          }
        }
      }
    }
    const m = mk(w, h), mg = g2(m), id = mg.createImageData(w, h), md = id.data;
    for (let i = 0; i < w * h; i++) if (out[i]) md[i * 4 + 3] = 255;
    mg.putImageData(id, 0, 0);
    if (!antialias) return m;
    const s = mk(w, h), sg = g2(s);
    sg.filter = 'blur(0.6px)';
    sg.drawImage(m, 0, 0);
    sg.filter = 'none';
    sg.drawImage(m, 0, 0);
    return s;
  }

  /* ================================================================ Korrekturen & Filter */
  /** Monotone kubische Kurve durch die Punkte → Tabelle 0…255. */
  function curveLut(pts) {
    const p = [...pts].sort((a, b) => a[0] - b[0]);
    const n = p.length, lut = new Uint8ClampedArray(256);
    if (n < 2) { for (let i = 0; i < 256; i++) lut[i] = i; return lut; }
    const xs = p.map((q) => q[0]), ys = p.map((q) => q[1]);
    const dx = [], m = [], sl = [];
    for (let i = 0; i < n - 1; i++) { dx[i] = Math.max(1e-6, xs[i + 1] - xs[i]); sl[i] = (ys[i + 1] - ys[i]) / dx[i]; }
    m[0] = sl[0]; m[n - 1] = sl[n - 2];
    for (let i = 1; i < n - 1; i++) m[i] = sl[i - 1] * sl[i] <= 0 ? 0 : (sl[i - 1] + sl[i]) / 2;
    for (let i = 0; i < n - 1; i++) {
      if (sl[i] === 0) { m[i] = m[i + 1] = 0; continue; }
      const a = m[i] / sl[i], b = m[i + 1] / sl[i], s = a * a + b * b;
      if (s > 9) { const t = 3 / Math.sqrt(s); m[i] = t * a * sl[i]; m[i + 1] = t * b * sl[i]; }
    }
    for (let v = 0; v < 256; v++) {
      if (v <= xs[0]) { lut[v] = ys[0]; continue; }
      if (v >= xs[n - 1]) { lut[v] = ys[n - 1]; continue; }
      let k = 0;
      while (v > xs[k + 1]) k++;
      const hh = dx[k], t = (v - xs[k]) / hh, t2 = t * t, t3 = t2 * t;
      lut[v] = (2 * t3 - 3 * t2 + 1) * ys[k] + (t3 - 2 * t2 + t) * hh * m[k] + (-2 * t3 + 3 * t2) * ys[k + 1] + (t3 - t2) * hh * m[k + 1];
    }
    return lut;
  }
  function lutApply(d, lr, lg = lr, lb = lr) {
    for (let i = 0; i < d.length; i += 4) { d[i] = lr[d[i]]; d[i + 1] = lg[d[i + 1]]; d[i + 2] = lb[d[i + 2]]; }
  }
  function rand(seed) {
    let s = seed | 0;
    return () => {
      s = (s + 0x6d2b79f5) | 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function padBlur(src, out, r) {
    const w = src.width, h = src.height, p = Math.ceil(r * 3) + 1;
    const pad = tmp(7, w + 2 * p, h + 2 * p), pg = g2(pad);
    pg.drawImage(src, p, p);
    pg.drawImage(src, 0, 0, w, 1, p, 0, w, p);
    pg.drawImage(src, 0, h - 1, w, 1, p, h + p, w, p);
    pg.drawImage(pad, p, 0, 1, h + 2 * p, 0, 0, p, h + 2 * p);
    pg.drawImage(pad, w + p - 1, 0, 1, h + 2 * p, w + p, 0, p, h + 2 * p);
    const og = g2(out);
    og.clearRect(0, 0, w, h);
    og.filter = `blur(${r}px)`;
    og.drawImage(pad, -p, -p);
    og.filter = 'none';
    // Transparenz der Quelle behalten (sonst würde der Rand nach aussen verlaufen)
    og.globalCompositeOperation = 'destination-in';
    og.drawImage(src, 0, 0);
    og.globalCompositeOperation = 'source-over';
  }
  const DEF_CURVE = () => [[0, 0], [255, 255]];
  /** Alle Korrekturen/Filter: px = Pixel-Funktion (RGBA-Daten), cv = Leinwand-Funktion. */
  const ADJ = {
    bc: { name: 'Helligkeit/Kontrast', icon: 'bc', key: 'bc', def: () => ({ b: 0, c: 0 }),
      px(d, p) {
        const lut = new Uint8ClampedArray(256), b = p.b / 100, k = Math.tan((clamp(p.c, -100, 100) / 100 * 0.98 + 1) * Math.PI / 4);
        for (let v = 0; v < 256; v++) {
          let x = v / 255;
          x = b >= 0 ? 1 - Math.pow(1 - x, 1 + b * 1.2) : Math.pow(x, 1 - b * 1.2);
          lut[v] = (x - 0.5) * k * 255 + 127.5;
        }
        lutApply(d, lut);
      } },
    levels: { name: 'Tonwerte', icon: 'levels', def: () => ({ ib: 0, ig: 1, iw: 255, ob: 0, ow: 255 }),
      px(d, p) {
        const lut = new Uint8ClampedArray(256), span = Math.max(1, p.iw - p.ib);
        for (let v = 0; v < 256; v++) lut[v] = Math.pow(clamp((v - p.ib) / span, 0, 1), 1 / Math.max(0.01, p.ig)) * (p.ow - p.ob) + p.ob;
        lutApply(d, lut);
      } },
    curves: { name: 'Gradationskurven', icon: 'curves', def: () => ({ ch: 'rgb', rgb: DEF_CURVE(), r: DEF_CURVE(), g: DEF_CURVE(), b: DEF_CURVE() }),
      px(d, p) {
        const c = curveLut(p.rgb), r = curveLut(p.r), g = curveLut(p.g), b = curveLut(p.b);
        const lr = new Uint8ClampedArray(256), lg = new Uint8ClampedArray(256), lb = new Uint8ClampedArray(256);
        for (let v = 0; v < 256; v++) { lr[v] = c[r[v]]; lg[v] = c[g[v]]; lb[v] = c[b[v]]; }
        lutApply(d, lr, lg, lb);
      } },
    hsl: { name: 'Farbton/Sättigung', icon: 'hsl', def: () => ({ h: 0, s: 0, l: 0, colorize: false }),
      px(d, p) {
        const sk = p.s / 100, lk = p.l / 100;
        for (let i = 0; i < d.length; i += 4) {
          if (!d[i + 3]) continue;
          let [h, s, l] = rgb2hsl(d[i], d[i + 1], d[i + 2]);
          if (p.colorize) { h = (p.h + 360) % 360; s = clamp(0.25 + sk * 0.75, 0, 1); } else {
            h = (h + p.h + 360) % 360;
            s = sk >= 0 ? s + (1 - s) * sk * s * 1.4 + s * sk * 0.4 : s * (1 + sk);
            s = clamp(s, 0, 1);
          }
          l = lk >= 0 ? l + (1 - l) * lk : l * (1 + lk);
          const [r, g, b] = hsl2rgb(h, s, l);
          d[i] = r; d[i + 1] = g; d[i + 2] = b;
        }
      } },
    balance: { name: 'Farbbalance', icon: 'balance', def: () => ({ tone: 'mid', sh: [0, 0, 0], mid: [0, 0, 0], hi: [0, 0, 0], keep: true }),
      px(d, p) {
        const a = 64, bb = 85, sc = 1.785;
        const luts = [0, 1, 2].map((ch) => {
          const lut = new Uint8ClampedArray(256);
          for (let v = 0; v < 256; v++) {
            const low = clamp((v - bb) / -a + 0.5, 0, 1) * sc;
            const mid = clamp((v - bb) / a + 0.5, 0, 1) * clamp((v + bb - 255) / -a + 0.5, 0, 1) * sc;
            const high = clamp((v + bb - 255) / a + 0.5, 0, 1) * sc;
            lut[v] = v + p.sh[ch] * low * 0.7 + p.mid[ch] * mid * 0.7 + p.hi[ch] * high * 0.7;
          }
          return lut;
        });
        for (let i = 0; i < d.length; i += 4) {
          const r = d[i], g = d[i + 1], b = d[i + 2];
          let nr = luts[0][r], ng = luts[1][g], nb = luts[2][b];
          if (p.keep) {
            const l0 = (Math.max(r, g, b) + Math.min(r, g, b)) / 2, l1 = (Math.max(nr, ng, nb) + Math.min(nr, ng, nb)) / 2, dl = l0 - l1;
            nr += dl; ng += dl; nb += dl;
          }
          d[i] = nr; d[i + 1] = ng; d[i + 2] = nb;
        }
      } },
    bw: { name: 'Schwarzweiss', icon: 'bw', def: () => ({ r: 40, y: 60, g: 40, c: 60, b: 20, m: 80, tint: false, tc: '#e1d3b3' }),
      px(d, p) {
        const [tr, tg, tb] = hex2rgb(p.tc);
        const th = p.tint ? rgb2hsl(tr, tg, tb) : null;
        for (let i = 0; i < d.length; i += 4) {
          const r = d[i], g = d[i + 1], b = d[i + 2];
          let mx, md, mn, wp, ws;
          if (r >= g && r >= b) { mx = r; if (g >= b) { md = g; mn = b; ws = p.y; } else { md = b; mn = g; ws = p.m; } wp = p.r; } else if (g >= r && g >= b) { mx = g; if (r >= b) { md = r; mn = b; ws = p.y; } else { md = b; mn = r; ws = p.c; } wp = p.g; } else { mx = b; if (r >= g) { md = r; mn = g; ws = p.m; } else { md = g; mn = r; ws = p.c; } wp = p.b; }
          const v = clamp(mn + ((md - mn) * ws + (mx - md) * wp) / 100, 0, 255);
          if (th) { const [cr, cg, cb] = hsl2rgb(th[0], th[1] * 0.8, v / 255); d[i] = cr; d[i + 1] = cg; d[i + 2] = cb; } else d[i] = d[i + 1] = d[i + 2] = v;
        }
      } },
    invert: { name: 'Umkehren', icon: 'invert', def: () => ({}),
      px(d) { for (let i = 0; i < d.length; i += 4) { d[i] = 255 - d[i]; d[i + 1] = 255 - d[i + 1]; d[i + 2] = 255 - d[i + 2]; } } },
    desat: { name: 'Sättigung verringern', filter: true, def: () => ({}),
      px(d) { for (let i = 0; i < d.length; i += 4) { const v = (Math.max(d[i], d[i + 1], d[i + 2]) + Math.min(d[i], d[i + 1], d[i + 2])) / 2; d[i] = d[i + 1] = d[i + 2] = v; } } },
    blur: { name: 'Gaussscher Weichzeichner', filter: true, def: () => ({ r: 4 }), cv(src, out, p) { if (p.r > 0) padBlur(src, out, p.r); else g2(out).drawImage(src, 0, 0); } },
    motion: { name: 'Bewegungsunschärfe', filter: true, def: () => ({ a: 0, dist: 20 }),
      cv(src, out, p) {
        const g = g2(out), n = Math.max(1, Math.round(p.dist)), rad = (p.a * Math.PI) / 180;
        const steps = Math.min(n, 64);
        for (let i = 0; i < steps; i++) {
          const t = steps === 1 ? 0 : (i / (steps - 1) - 0.5) * n;
          g.globalAlpha = 1 / (i + 1);
          g.drawImage(src, Math.cos(rad) * t, -Math.sin(rad) * t);
        }
        g.globalAlpha = 1;
      } },
    sharpen: { name: 'Unscharf maskieren', filter: true, def: () => ({ amount: 100, r: 1.5, th: 0 }),
      cv(src, out, p) {
        const w = src.width, h = src.height, bl = tmp(8, w, h);
        padBlur(src, bl, Math.max(0.3, p.r));
        const s = g2(src).getImageData(0, 0, w, h), b = g2(bl).getImageData(0, 0, w, h).data, d = s.data, k = p.amount / 100;
        for (let i = 0; i < d.length; i += 4) {
          for (let c = 0; c < 3; c++) { const diff = d[i + c] - b[i + c]; if (Math.abs(diff) >= p.th) d[i + c] = d[i + c] + diff * k; }
        }
        g2(out).putImageData(s, 0, 0);
      } },
    noise: { name: 'Rauschen hinzufügen', filter: true, def: () => ({ amount: 12, gauss: true, mono: false, seed: 7 }),
      px(d, p) {
        const rnd = rand(p.seed || 7), amt = p.amount * 2.55;
        const n = () => (p.gauss ? (rnd() + rnd() + rnd() - 1.5) * 1.4 : rnd() * 2 - 1) * amt;
        for (let i = 0; i < d.length; i += 4) {
          if (p.mono) { const v = n(); d[i] += v; d[i + 1] += v; d[i + 2] += v; } else { d[i] += n(); d[i + 1] += n(); d[i + 2] += n(); }
        }
      } },
    median: { name: 'Rauschen entfernen', filter: true, def: () => ({ r: 1 }),
      cv(src, out, p) {
        const w = src.width, h = src.height, s = g2(src).getImageData(0, 0, w, h).data;
        const o = new ImageData(w, h), d = o.data, r = clamp(Math.round(p.r), 1, 3), buf = [];
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const i = (y * w + x) * 4;
            for (let c = 0; c < 3; c++) {
              buf.length = 0;
              for (let yy = Math.max(0, y - r); yy <= Math.min(h - 1, y + r); yy++) for (let xx = Math.max(0, x - r); xx <= Math.min(w - 1, x + r); xx++) buf.push(s[(yy * w + xx) * 4 + c]);
              buf.sort((a, b) => a - b);
              d[i + c] = buf[buf.length >> 1];
            }
            d[i + 3] = s[i + 3];
          }
        }
        g2(out).putImageData(o, 0, 0);
      } },
    mosaic: { name: 'Mosaik', filter: true, def: () => ({ s: 12 }),
      cv(src, out, p) {
        const w = src.width, h = src.height, s = Math.max(2, Math.round(p.s));
        const small = resample(src, Math.ceil(w / s), Math.ceil(h / s), 'auto');
        const g = g2(out);
        g.imageSmoothingEnabled = false;
        g.drawImage(small, 0, 0, small.width * s, small.height * s);
        g.imageSmoothingEnabled = true;
      } },
  };
  const ADJ_LAYER_TYPES = ['bc', 'levels', 'curves', 'hsl', 'balance', 'bw', 'invert'];
  /** Korrektur auf eine Leinwand anwenden → Ergebnis in Arbeitsfläche Nr. slot. */
  function runAdj(src, adj, slot) {
    const w = src.width, h = src.height, out = tmp(slot, w, h), def = ADJ[adj.type];
    if (!def) { g2(out).drawImage(src, 0, 0); return out; }
    if (def.px) {
      const id = g2(src).getImageData(0, 0, w, h);
      def.px(id.data, adj.p, w, h);
      g2(out).putImageData(id, 0, 0);
    } else def.cv(src, out, adj.p);
    return out;
  }

  /* ================================================================ Zusammensetzen */
  function renderText(l) {
    const t = l.text, c = l.canvas, g = g2(c);
    g.clearRect(0, 0, c.width, c.height);
    g.font = `${t.italic ? 'italic ' : ''}${t.bold ? 700 : 400} ${t.size}px "${t.font}", sans-serif`;
    g.fillStyle = t.color;
    g.textBaseline = 'top';
    g.textAlign = t.align;
    const lines = String(t.str).split('\n'), lh = t.size * 1.2;
    let wmax = 0;
    lines.forEach((ln, i) => { g.fillText(ln, t.x, t.y + i * lh); wmax = Math.max(wmax, g.measureText(ln).width); });
    const x0 = t.align === 'center' ? t.x - wmax / 2 : t.align === 'right' ? t.x - wmax : t.x;
    t.box = { x: x0, y: t.y, w: Math.max(4, wmax), h: lines.length * lh };
    touch(l);
  }
  /** Alle sichtbaren Ebenen zu einem Bild zusammensetzen (bis „upto“, ohne sie). */
  function composite(doc, { upto = null, into = null, skipHidden = true } = {}) {
    const w = doc.w, h = doc.h;
    let comp = into;
    if (!comp) {
      if (!doc.comp) doc.comp = mk(w, h);
      comp = doc.comp;
    }
    if (comp.width !== w || comp.height !== h) { comp.width = w; comp.height = h; }
    const g = g2(comp);
    reset(g);
    g.clearRect(0, 0, w, h);
    for (const l of doc.layers) {
      if (upto && l === upto) break;
      if ((skipHidden && !l.visible) || l.editing) continue;
      const mask = l.mask && l.maskOn ? l.maskTemp || l.mask : null;
      if (l.kind === 'adj') {
        const res = runAdj(comp, l.adj, 1);
        mixInto(comp, res, mask, l.opacity);
        continue;
      }
      let src = l.temp || l.canvas;
      if (l.preview) {
        const res = runAdj(src, l.preview, 3);
        const o = tmp(5, w, h);
        g2(o).drawImage(src, 0, 0);
        mixInto(o, res, doc.sel ? doc.sel.mask : null, 1);
        src = o;
      }
      if (mask) {
        const t = tmp(4, w, h), tg = g2(t);
        tg.drawImage(src, 0, 0);
        tg.globalCompositeOperation = 'destination-in';
        tg.drawImage(mask, 0, 0);
        src = t;
      }
      g.globalAlpha = l.opacity;
      g.globalCompositeOperation = l.blend;
      g.drawImage(src, 0, 0);
      reset(g);
    }
    return comp;
  }
  function flatCanvas(doc, bg = null) {
    const c = mk(doc.w, doc.h);
    composite(doc, { into: c });
    if (!bg) return c;
    const o = mk(doc.w, doc.h), g = g2(o);
    g.fillStyle = bg;
    g.fillRect(0, 0, doc.w, doc.h);
    g.drawImage(c, 0, 0);
    return o;
  }

  /* ================================================================ Ansicht */
  const viewSize = () => {
    const v = st.el.stage;
    return v ? { w: v.clientWidth, h: v.clientHeight } : { w: 800, h: 600 };
  };
  function fit(doc = D()) {
    if (!doc) return;
    const { w, h } = viewSize();
    doc.zoom = Math.min((w - 48) / doc.w, (h - 48) / doc.h, 1);
    if (!(doc.zoom > 0)) doc.zoom = 1;
    center(doc);
  }
  function center(doc = D()) {
    const { w, h } = viewSize();
    doc.px = Math.round((w - doc.w * doc.zoom) / 2);
    doc.py = Math.round((h - doc.h * doc.zoom) / 2);
    draw();
  }
  function zoomAt(z, sx, sy) {
    const doc = D();
    if (!doc) return;
    z = clamp(z, 0.02, 32);
    const { w, h } = viewSize();
    if (sx == null) { sx = w / 2; sy = h / 2; }
    const dx = (sx - doc.px) / doc.zoom, dy = (sy - doc.py) / doc.zoom;
    doc.zoom = z;
    doc.px = sx - dx * z;
    doc.py = sy - dy * z;
    draw();
    renderStatus();
  }
  const zoomStep = (dir, sx, sy) => {
    const z = D()?.zoom || 1;
    const next = dir > 0 ? ZOOMS.find((v) => v > z * 1.001) || 32 : [...ZOOMS].reverse().find((v) => v < z * 0.999) || 0.02;
    zoomAt(next, sx, sy);
  };
  const toDoc = (e) => {
    const r = st.el.view.getBoundingClientRect(), doc = D();
    return { x: (e.clientX - r.left - doc.px) / doc.zoom, y: (e.clientY - r.top - doc.py) / doc.zoom, sx: e.clientX - r.left, sy: e.clientY - r.top };
  };
  const toScr = (x, y) => { const doc = D(); return { x: x * doc.zoom + doc.px, y: y * doc.zoom + doc.py }; };

  function schedule() {
    if (st.raf) return;
    st.raf = requestAnimationFrame(() => { st.raf = 0; paint(); });
  }
  const draw = () => schedule();
  function requestComp() { st.needComp = true; schedule(); }
  function paint() {
    const doc = D(), v = st.el.view;
    if (!v || !st.root) return;
    const dpr = (st.dpr = window.devicePixelRatio || 1);
    const { w, h } = viewSize();
    if (v.width !== Math.round(w * dpr) || v.height !== Math.round(h * dpr)) { v.width = Math.round(w * dpr); v.height = Math.round(h * dpr); }
    const g = g2(v);
    reset(g);
    g.fillStyle = '#202020';
    g.fillRect(0, 0, v.width, v.height);
    if (!doc) return;
    if (st.needComp) { composite(doc); st.needComp = false; }
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const z = doc.zoom, x = doc.px, y = doc.py, dw = doc.w * z, dh = doc.h * z;
    g.save();
    g.shadowColor = 'rgba(0,0,0,.55)';
    g.shadowBlur = 14;
    g.fillStyle = '#fff';
    g.fillRect(x, y, dw, dh);
    g.restore();
    g.fillStyle = checker(g);
    g.save();
    g.translate(x, y);
    g.fillRect(0, 0, dw, dh);
    g.restore();
    g.imageSmoothingEnabled = z < 2;
    g.imageSmoothingQuality = 'high';
    g.drawImage(doc.comp, x, y, dw, dh);
    g.imageSmoothingEnabled = true;
    // Pixelraster ab 800 %
    if (z >= 8) {
      g.strokeStyle = 'rgba(128,128,128,.25)';
      g.lineWidth = 1;
      g.beginPath();
      const { w: vw, h: vh } = viewSize();
      const x0 = Math.max(0, Math.floor(-x / z)), x1 = Math.min(doc.w, Math.ceil((vw - x) / z));
      const y0 = Math.max(0, Math.floor(-y / z)), y1 = Math.min(doc.h, Math.ceil((vh - y) / z));
      for (let i = x0; i <= x1; i++) { g.moveTo(Math.round(x + i * z) + 0.5, y + y0 * z); g.lineTo(Math.round(x + i * z) + 0.5, y + y1 * z); }
      for (let j = y0; j <= y1; j++) { g.moveTo(x + x0 * z, Math.round(y + j * z) + 0.5); g.lineTo(x + x1 * z, Math.round(y + j * z) + 0.5); }
      g.stroke();
    }
    overlays(g, doc);
  }
  function overlays(g, doc) {
    const z = doc.zoom;
    const docT = () => g.setTransform(st.dpr * z, 0, 0, st.dpr * z, st.dpr * doc.px, st.dpr * doc.py);
    const scrT = () => g.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
    // Auswahl: laufende Ameisen
    if (doc.sel && !st.crop) {
      g.save();
      docT();
      if (st.drag?.selOff) g.translate(st.drag.selOff.x, st.drag.selOff.y);
      g.lineWidth = 1 / z;
      g.strokeStyle = '#fff';
      g.setLineDash([]);
      g.stroke(doc.sel.path);
      g.strokeStyle = '#000';
      g.setLineDash([4 / z, 4 / z]);
      g.lineDashOffset = -st.antsOff / z;
      g.stroke(doc.sel.path);
      g.restore();
    }
    const d = st.drag;
    // Auswahl wird gerade aufgezogen
    if (d?.kind === 'sel' && d.shape) {
      g.save();
      docT();
      g.lineWidth = 1 / z;
      g.strokeStyle = '#fff';
      g.stroke(d.shape);
      g.strokeStyle = '#000';
      g.setLineDash([4 / z, 4 / z]);
      g.lineDashOffset = -st.antsOff / z;
      g.stroke(d.shape);
      g.restore();
    }
    if (d?.kind === 'gradient') {
      scrT();
      const a = toScr(d.p0.x, d.p0.y), b = toScr(d.p.x, d.p.y);
      g.lineWidth = 3; g.strokeStyle = 'rgba(0,0,0,.6)';
      g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
      g.lineWidth = 1.2; g.strokeStyle = '#fff'; g.stroke();
      for (const q of [a, b]) { g.beginPath(); g.arc(q.x, q.y, 3.5, 0, Math.PI * 2); g.fillStyle = '#fff'; g.fill(); g.stroke(); }
    }
    if (d?.kind === 'shape' && d.path) {
      g.save();
      docT();
      g.globalAlpha = 0.9;
      if (st.opt.shapeFill && st.opt.shape !== 'line') { g.fillStyle = st.fg; g.fill(d.path); }
      if (st.opt.shapeStroke > 0 || st.opt.shape === 'line') { g.lineWidth = Math.max(1, st.opt.shapeStroke || 4); g.strokeStyle = st.opt.shape === 'line' ? st.fg : st.opt.shapeStrokeColor; g.stroke(d.path); }
      g.globalAlpha = 1;
      g.lineWidth = 1 / z; g.strokeStyle = '#2d8ceb'; g.stroke(d.path);
      g.restore();
    }
    // Freistellen
    if (st.crop) {
      const c = st.crop, a = toScr(c.x, c.y), b = toScr(c.x + c.w, c.y + c.h);
      scrT();
      const { w: vw, h: vh } = viewSize();
      g.fillStyle = 'rgba(0,0,0,.55)';
      g.beginPath();
      g.rect(0, 0, vw, vh);
      g.rect(a.x, a.y, b.x - a.x, b.y - a.y);
      g.fill('evenodd');
      g.strokeStyle = 'rgba(255,255,255,.45)';
      g.lineWidth = 1;
      g.beginPath();
      for (let i = 1; i < 3; i++) {
        const xx = a.x + ((b.x - a.x) * i) / 3, yy = a.y + ((b.y - a.y) * i) / 3;
        g.moveTo(xx, a.y); g.lineTo(xx, b.y); g.moveTo(a.x, yy); g.lineTo(b.x, yy);
      }
      g.stroke();
      g.strokeStyle = '#fff';
      g.strokeRect(a.x + 0.5, a.y + 0.5, b.x - a.x - 1, b.y - a.y - 1);
      g.fillStyle = '#fff';
      for (const [hx, hy] of HANDLES) {
        const px = a.x + ((b.x - a.x) * (hx + 1)) / 2, py = a.y + ((b.y - a.y) * (hy + 1)) / 2;
        g.fillRect(px - 4, py - 4, 8, 8);
      }
    }
    // Frei transformieren
    if (st.xf) {
      scrT();
      const pts = xfCorners(st.xf).map((p) => toScr(p.x, p.y));
      g.strokeStyle = '#2d8ceb';
      g.lineWidth = 1;
      g.beginPath();
      pts.forEach((p, i) => (i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y)));
      g.closePath();
      g.stroke();
      for (const hd of xfHandles(st.xf)) {
        const p = toScr(hd.x, hd.y);
        g.fillStyle = '#fff';
        g.fillRect(p.x - 4, p.y - 4, 8, 8);
        g.strokeRect(p.x - 4 + 0.5, p.y - 4 + 0.5, 7, 7);
      }
      const c = toScr(st.xf.cx, st.xf.cy);
      g.beginPath(); g.arc(c.x, c.y, 4, 0, Math.PI * 2); g.stroke();
    }
    // Lasso im Gang
    if (d?.kind === 'lasso' && d.pts.length > 1) {
      g.save();
      docT();
      g.lineWidth = 1 / z;
      g.beginPath();
      d.pts.forEach((p, i) => (i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y)));
      g.strokeStyle = '#fff'; g.stroke();
      g.setLineDash([4 / z, 4 / z]); g.strokeStyle = '#000'; g.stroke();
      g.restore();
    }
    // Pinselspitze
    const m = st.mouse;
    if (m && m.in && PAINT.has(st.tool) && !st.space && !st.dlg) {
      scrT();
      const r = Math.max(1, (st.opt.size * z) / 2);
      g.lineWidth = 1;
      g.strokeStyle = 'rgba(0,0,0,.7)';
      g.beginPath(); g.arc(m.sx, m.sy, r + 0.5, 0, Math.PI * 2); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.9)';
      g.beginPath(); g.arc(m.sx, m.sy, Math.max(0.5, r - 0.5), 0, Math.PI * 2); g.stroke();
      if (r < 4) { g.beginPath(); g.moveTo(m.sx - 6, m.sy); g.lineTo(m.sx + 6, m.sy); g.moveTo(m.sx, m.sy - 6); g.lineTo(m.sx, m.sy + 6); g.stroke(); }
    }
    if (st.tool === 'clone' && st.cloneSrc) {
      let sp = st.cloneSrc;
      if (st.drag?.kind === 'paint' && st.drag.off) sp = { x: st.drag.p.x + st.drag.off.x, y: st.drag.p.y + st.drag.off.y };
      else if (m && st.opt.cloneAligned && st.cloneOff) sp = { x: m.x + st.cloneOff.x, y: m.y + st.cloneOff.y };
      const p = toScr(sp.x, sp.y);
      scrT();
      g.strokeStyle = '#fff'; g.lineWidth = 1.5;
      g.beginPath(); g.moveTo(p.x - 7, p.y); g.lineTo(p.x + 7, p.y); g.moveTo(p.x, p.y - 7); g.lineTo(p.x, p.y + 7); g.stroke();
    }
  }
  const HANDLES = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]];

  /* ================================================================ Malen */
  let stampCache = null;
  function stamp(size, hard, color) {
    const key = `${size}|${hard}|${color}`;
    if (stampCache?.key === key) return stampCache.c;
    const d = Math.max(1, Math.ceil(size)) + 2, c = mk(d, d), g = g2(c), r = size / 2, m = d / 2;
    if (size <= 1.5) { g.fillStyle = color; g.fillRect(m - size / 2, m - size / 2, size, size); } else {
      const gr = g.createRadialGradient(m, m, 0, m, m, r);
      const hs = clamp(hard / 100, 0, 0.98);
      gr.addColorStop(0, color);
      gr.addColorStop(hs, color);
      gr.addColorStop(1, rgba(color, 0));
      g.fillStyle = gr;
      g.beginPath(); g.arc(m, m, r, 0, Math.PI * 2); g.fill();
    }
    stampCache = { key, c };
    return c;
  }
  /** Ziel zum Malen: Maske (wenn sie bearbeitet wird) oder die Pixel der Ebene. Textebenen werden gerastert. */
  function paintTarget(l, what = 'Malen') {
    if (!l) return null;
    if (!l.visible) { toast('Die Ebene ist ausgeblendet.', 'error'); return null; }
    if (l.mask && l.editMask) return { c: l.mask, mask: true };
    if (l.kind === 'adj') { toast(`${what}: Bei Einstellungsebenen nur die Maske bearbeiten.`, 'error'); return null; }
    if (l.kind === 'text') { rasterize(l, false); toast('Textebene wurde gerastert.'); }
    return { c: l.canvas, mask: false };
  }
  function paintStart(e, p) {
    const doc = D(), l = active(doc), tool = st.tool;
    if (tool === 'clone' && e.altKey) {
      st.cloneSrc = { x: p.x, y: p.y };
      st.cloneOff = null;
      toast('Kopierquelle festgelegt.');
      return draw();
    }
    if ((tool === 'brush') && e.altKey) return pickColor(p, false);
    if (tool === 'clone' && !st.cloneSrc) { toast('Zuerst mit Alt-Klick eine Quelle festlegen.', 'error'); return; }
    const t = paintTarget(l, TOOL_NAME[tool]);
    if (!t) return;
    const buf = mk(doc.w, doc.h);
    let color = st.fg, op = 'source-over';
    if (t.mask) {
      const reveal = tool === 'eraser' ? lum(st.bg) >= 128 : lum(st.fg) >= 128;
      color = '#ffffff';
      op = reveal ? 'source-over' : 'destination-out';
    } else if (tool === 'eraser') op = 'destination-out';
    const drag = { kind: 'paint', tool, l, t, snap: copyC(t.c), buf, color, op, p, last: p, rest: 0, box: null, pressure: e.pressure || 0.5, pen: e.pointerType === 'pen' };
    if (tool === 'clone') {
      if (st.opt.cloneAligned && st.cloneOff) drag.off = st.cloneOff;
      else drag.off = { x: st.cloneSrc.x - p.x, y: st.cloneSrc.y - p.y };
      st.cloneOff = drag.off;
      drag.src = st.opt.sampleAll ? flatCanvas(doc) : copyC(t.c);
    }
    st.drag = drag;
    if (e.shiftKey && st.lastPt && st.lastPt.layer === l.id) { drag.last = st.lastPt; dabLine(drag, st.lastPt, p, drag.pressure); } else dab(drag, p.x, p.y, drag.pressure);
    paintApply(drag);
  }
  function dab(d, x, y, pr) {
    const size = st.opt.size * (d.pen && st.opt.pressure ? clamp(pr, 0.05, 1) : 1);
    const g = g2(d.buf);
    g.globalAlpha = st.opt.flow / 100;
    const s = stamp(Math.max(1, size), st.opt.hardness, d.color);
    const r = s.width / 2;
    if (d.tool === 'clone') {
      const dd = tmp(9, s.width, s.height), dg = g2(dd);
      dg.drawImage(s, 0, 0);
      dg.globalCompositeOperation = 'source-in';
      dg.drawImage(d.src, x + d.off.x - r, y + d.off.y - r, s.width, s.height, 0, 0, s.width, s.height);
      g.drawImage(dd, x - r, y - r);
    } else g.drawImage(s, x - r, y - r);
    g.globalAlpha = 1;
    const b = { x: Math.floor(x - r - 2), y: Math.floor(y - r - 2), x2: Math.ceil(x + r + 2), y2: Math.ceil(y + r + 2) };
    if (!d.box) d.box = b; else { d.box.x = Math.min(d.box.x, b.x); d.box.y = Math.min(d.box.y, b.y); d.box.x2 = Math.max(d.box.x2, b.x2); d.box.y2 = Math.max(d.box.y2, b.y2); }
  }
  function dabLine(d, a, b, pr) {
    const step = Math.max(1, st.opt.size * 0.12);
    const dx = b.x - a.x, dy = b.y - a.y, dist = Math.hypot(dx, dy);
    let t = d.rest ? step - d.rest : step;
    if (!dist) return;
    for (; t <= dist; t += step) dab(d, a.x + (dx * t) / dist, a.y + (dy * t) / dist, pr);
    d.rest = dist - (t - step);
  }
  function paintMove(e, p) {
    const d = st.drag;
    const pr = e.pressure || 0.5;
    dabLine(d, d.last, p, pr);
    d.last = p;
    d.p = p;
    paintApply(d);
  }
  function paintApply(d) {
    const doc = D(), c = d.t.c, g = g2(c);
    if (!d.box) return;
    const x = clamp(d.box.x, 0, doc.w), y = clamp(d.box.y, 0, doc.h), w = clamp(d.box.x2, 0, doc.w) - x, h = clamp(d.box.y2, 0, doc.h) - y;
    if (w <= 0 || h <= 0) return;
    reset(g);
    g.clearRect(x, y, w, h);
    g.drawImage(d.snap, x, y, w, h, x, y, w, h);
    let src = d.buf;
    if (doc.sel) {
      src = tmp(6, doc.w, doc.h);
      const sg = g2(src);
      sg.drawImage(d.buf, x, y, w, h, x, y, w, h);
      sg.globalCompositeOperation = 'destination-in';
      sg.drawImage(doc.sel.mask, 0, 0);
    }
    g.globalAlpha = st.opt.opacity / 100;
    g.globalCompositeOperation = d.op;
    g.drawImage(src, x, y, w, h, x, y, w, h);
    reset(g);
    touch(d.l);
    requestComp();
  }
  function paintEnd(d) {
    st.lastPt = { x: d.last.x, y: d.last.y, layer: d.l.id };
    commit(d.t.mask ? `${TOOL_NAME[d.tool]} (Maske)` : TOOL_NAME[d.tool]);
  }

  /* ================================================================ Pipette, Füllen, Verlauf, Formen */
  function pickColor(p, toBg) {
    const doc = D();
    const src = st.opt.sampleAll || st.tool !== 'eyedropper' ? doc.comp : active(doc)?.canvas || doc.comp;
    const n = st.opt.sample, x = Math.floor(p.x) - (n >> 1), y = Math.floor(p.y) - (n >> 1);
    if (p.x < 0 || p.y < 0 || p.x >= doc.w || p.y >= doc.h) return;
    const id = g2(src).getImageData(clamp(x, 0, doc.w - 1), clamp(y, 0, doc.h - 1), n, n).data;
    let r = 0, g = 0, b = 0, a = 0;
    for (let i = 0; i < id.length; i += 4) { const al = id[i + 3]; r += id[i] * al; g += id[i + 1] * al; b += id[i + 2] * al; a += al; }
    if (!a) return;
    const hex = rgb2hex(r / a, g / a, b / a);
    if (toBg) st.bg = hex; else st.fg = hex;
    renderColorChips();
    renderColorPanel();
  }
  function bucketFill(p) {
    const doc = D(), l = active(doc), t = paintTarget(l, 'Füllen');
    if (!t) return;
    const src = st.opt.sampleAll ? doc.comp : t.c;
    const region = regionMask(src, p.x, p.y, st.opt.tolerance, st.opt.contiguous, st.opt.antialias);
    if (!region) return;
    const rg = g2(region);
    if (doc.sel) { rg.globalCompositeOperation = 'destination-in'; rg.drawImage(doc.sel.mask, 0, 0); rg.globalCompositeOperation = 'source-over'; }
    const fill = tmp(6, doc.w, doc.h), fg = g2(fill);
    fg.fillStyle = t.mask ? '#fff' : st.fg;
    fg.fillRect(0, 0, doc.w, doc.h);
    fg.globalCompositeOperation = 'destination-in';
    fg.drawImage(region, 0, 0);
    const g = g2(t.c);
    g.globalAlpha = st.opt.opacity / 100;
    g.globalCompositeOperation = t.mask && lum(st.fg) < 128 ? 'destination-out' : 'source-over';
    g.drawImage(fill, 0, 0);
    reset(g);
    touch(l);
    requestComp();
    commit(t.mask ? 'Füllen (Maske)' : 'Füllen');
  }
  function fillWith(color, opacity = 1, label = 'Fläche füllen') {
    const doc = D(), l = active(doc), t = paintTarget(l, 'Füllen');
    if (!t) return;
    const f = tmp(6, doc.w, doc.h), fg = g2(f);
    fg.fillStyle = t.mask ? '#fff' : color;
    fg.fillRect(0, 0, doc.w, doc.h);
    if (doc.sel) { fg.globalCompositeOperation = 'destination-in'; fg.drawImage(doc.sel.mask, 0, 0); }
    if (t.mask) {
      const v = lum(color) / 255;
      const m = tmp(8, doc.w, doc.h), mg = g2(m);
      mg.globalAlpha = v;
      mg.drawImage(f, 0, 0);
      mixInto(t.c, m, doc.sel?.mask || null, opacity);
    } else {
      const g = g2(t.c);
      g.globalAlpha = opacity;
      g.drawImage(f, 0, 0);
      reset(g);
    }
    touch(l);
    requestComp();
    commit(label);
  }
  function gradientApply(a, b) {
    const doc = D(), l = active(doc), t = paintTarget(l, 'Verlauf');
    if (!t) return;
    let c1 = st.fg, c2 = st.opt.gradMode === 'fgbg' ? st.bg : rgba(st.fg, 0);
    if (t.mask) { c1 = lum(st.fg) >= 128 ? '#fff' : 'rgba(255,255,255,0)'; c2 = st.opt.gradMode === 'fgbg' ? (lum(st.bg) >= 128 ? '#fff' : 'rgba(255,255,255,0)') : 'rgba(255,255,255,0)'; }
    if (st.opt.gradReverse) [c1, c2] = [c2, c1];
    const f = tmp(6, doc.w, doc.h), g = g2(f);
    const gr = st.opt.gradType === 'radial' ? g.createRadialGradient(a.x, a.y, 0, a.x, a.y, Math.max(1, Math.hypot(b.x - a.x, b.y - a.y))) : g.createLinearGradient(a.x, a.y, b.x, b.y);
    gr.addColorStop(0, c1);
    gr.addColorStop(1, c2);
    g.fillStyle = gr;
    g.fillRect(0, 0, doc.w, doc.h);
    if (t.mask) mixInto(t.c, f, doc.sel?.mask || null, st.opt.opacity / 100);
    else {
      if (doc.sel) { g.globalCompositeOperation = 'destination-in'; g.drawImage(doc.sel.mask, 0, 0); }
      const lg = g2(t.c);
      lg.globalAlpha = st.opt.opacity / 100;
      lg.drawImage(f, 0, 0);
      reset(lg);
    }
    touch(l);
    requestComp();
    commit(t.mask ? 'Verlauf (Maske)' : 'Verlauf');
  }
  function shapePath(kind, a, b, shift) {
    let x = Math.min(a.x, b.x), y = Math.min(a.y, b.y), w = Math.abs(b.x - a.x), h = Math.abs(b.y - a.y);
    const p = new Path2D();
    if (kind === 'line') {
      let bx = b.x, by = b.y;
      if (shift) { const ang = Math.round(Math.atan2(by - a.y, bx - a.x) / (Math.PI / 4)) * (Math.PI / 4), len = Math.hypot(bx - a.x, by - a.y); bx = a.x + Math.cos(ang) * len; by = a.y + Math.sin(ang) * len; }
      p.moveTo(a.x, a.y);
      p.lineTo(bx, by);
      return p;
    }
    if (shift) { const s = Math.max(w, h); w = h = s; x = b.x < a.x ? a.x - s : a.x; y = b.y < a.y ? a.y - s : a.y; }
    if (kind === 'ellipse') p.ellipse(x + w / 2, y + h / 2, Math.max(0.5, w / 2), Math.max(0.5, h / 2), 0, 0, Math.PI * 2);
    else if (kind === 'round') p.roundRect(x, y, w, h, Math.min(st.opt.radius, w / 2, h / 2));
    else p.rect(x, y, w, h);
    return p;
  }
  function shapeCommit(path) {
    const doc = D();
    const names = { rect: 'Rechteck', round: 'Abgerundetes Rechteck', ellipse: 'Ellipse', line: 'Linie' };
    const l = newLayer(doc, { name: `${names[st.opt.shape]} ${++st.layerSeq}` });
    const g = g2(l.canvas);
    if (st.opt.shape === 'line') {
      g.lineCap = 'round';
      g.lineWidth = Math.max(1, st.opt.shapeStroke || 4);
      g.strokeStyle = st.fg;
      g.stroke(path);
    } else {
      if (st.opt.shapeFill) { g.fillStyle = st.fg; g.fill(path); }
      if (st.opt.shapeStroke > 0) { g.lineWidth = st.opt.shapeStroke; g.strokeStyle = st.opt.shapeStrokeColor; g.stroke(path); }
    }
    insertAbove(l);
    commit(`Form: ${names[st.opt.shape]}`);
  }

  /* ================================================================ Verschieben & Transformieren */
  function moveStart(e, p) {
    const doc = D();
    let l = active(doc);
    if (st.opt.autoSelect || e.ctrlKey) {
      const x = Math.floor(p.x), y = Math.floor(p.y);
      if (x >= 0 && y >= 0 && x < doc.w && y < doc.h) {
        for (let i = doc.layers.length - 1; i >= 0; i--) {
          const c = doc.layers[i];
          if (!c.visible || c.kind === 'adj') continue;
          if (g2(c.canvas).getImageData(x, y, 1, 1).data[3] > 10) { l = c; doc.active = c.id; renderLayers(); renderProps(); break; }
        }
      }
    }
    if (!l || (l.kind === 'adj' && !l.mask)) return;
    const d = { kind: 'move', l, p0: p, dx: 0, dy: 0 };
    if (l.kind === 'text') d.text0 = { x: l.text.x, y: l.text.y };
    else if (doc.sel && l.kind === 'pixel' && !l.editMask) {
      // Auswahl ausschneiden und schwebend verschieben
      const fl = mk(doc.w, doc.h), fg = g2(fl);
      fg.drawImage(l.canvas, 0, 0);
      fg.globalCompositeOperation = 'destination-in';
      fg.drawImage(doc.sel.mask, 0, 0);
      const base = copyC(l.canvas), bg = g2(base);
      bg.globalCompositeOperation = 'destination-out';
      bg.drawImage(doc.sel.mask, 0, 0);
      d.float = fl;
      d.base = base;
      d.dup = e.altKey;
      if (d.dup) d.base = copyC(l.canvas);
    } else {
      d.base = l.kind === 'adj' ? null : copyC(l.editMask ? l.mask : l.canvas);
      d.mbase = l.mask && !l.editMask ? copyC(l.mask) : null;
      if (l.editMask) { d.base = copyC(l.mask); d.onlyMask = true; }
      if (l.kind === 'adj') { d.base = null; d.mbase = copyC(l.mask); }
    }
    st.drag = d;
  }
  function moveUpdate(d, dx, dy) {
    const doc = D(), l = d.l;
    d.dx = Math.round(dx); d.dy = Math.round(dy);
    if (d.text0) { l.text.x = d.text0.x + d.dx; l.text.y = d.text0.y + d.dy; renderText(l); requestComp(); return; }
    const shifted = (src, fillWhite) => {
      const t = mk(doc.w, doc.h), g = g2(t);
      if (fillWhite) { g.fillStyle = '#fff'; g.fillRect(0, 0, doc.w, doc.h); g.clearRect(d.dx, d.dy, doc.w, doc.h); }
      g.drawImage(src, d.dx, d.dy);
      return t;
    };
    if (d.float) {
      const t = copyC(d.base), g = g2(t);
      g.drawImage(d.float, d.dx, d.dy);
      l.temp = t;
      d.selOff = { x: d.dx, y: d.dy };
    } else if (d.onlyMask) l.maskTemp = shifted(d.base, true);
    else {
      if (d.base) l.temp = shifted(d.base, false);
      if (d.mbase) l.maskTemp = shifted(d.mbase, true);
    }
    requestComp();
  }
  function moveEnd(d) {
    const doc = D(), l = d.l;
    if (!d.dx && !d.dy && !d.text0) { l.temp = null; l.maskTemp = null; return requestComp(); }
    if (d.text0) { touch(l); return commit('Verschieben'); }
    if (l.temp) { const g = g2(l.canvas); g.clearRect(0, 0, doc.w, doc.h); g.drawImage(l.temp, 0, 0); l.temp = null; }
    if (l.maskTemp) { const g = g2(l.mask); g.clearRect(0, 0, doc.w, doc.h); g.drawImage(l.maskTemp, 0, 0); l.maskTemp = null; }
    touch(l);
    if (d.float && doc.sel) {
      const m = mk(doc.w, doc.h);
      g2(m).drawImage(doc.sel.mask, d.dx, d.dy);
      setSel(m, null);
    }
    requestComp();
    commit('Verschieben');
  }
  function nudge(dx, dy) {
    const doc = D(), l = active(doc);
    if (!l) return;
    moveStart({ altKey: false, ctrlKey: false }, { x: 0, y: 0 });
    const d = st.drag;
    st.drag = null;
    if (!d) return;
    moveUpdate(d, dx, dy);
    moveEnd(d);
  }
  // Frei transformieren: Quelle = Inhalt der Ebene (oder der Auswahl), Rahmen mit Griffen
  function startTransform() {
    const doc = D(), l = active(doc);
    if (!l || l.kind === 'adj') return toast('Diese Ebene kann nicht transformiert werden.', 'error');
    if (!l.visible) return toast('Die Ebene ist ausgeblendet.', 'error');
    if (st.xf) return;
    if (l.kind === 'text') rasterize(l, false);
    const base = copyC(l.canvas);
    let src = l.canvas;
    if (doc.sel) {
      const f = mk(doc.w, doc.h), fg = g2(f);
      fg.drawImage(l.canvas, 0, 0);
      fg.globalCompositeOperation = 'destination-in';
      fg.drawImage(doc.sel.mask, 0, 0);
      src = f;
      const bg = g2(base);
      bg.globalCompositeOperation = 'destination-out';
      bg.drawImage(doc.sel.mask, 0, 0);
    } else g2(base).clearRect(0, 0, doc.w, doc.h);
    const box = contentBox(src);
    if (!box) return toast('Die Ebene ist leer.', 'error');
    const piece = mk(box.w, box.h);
    g2(piece).drawImage(src, -box.x, -box.y);
    st.xf = { l, base, piece, w: box.w, h: box.h, cx: box.x + box.w / 2, cy: box.y + box.h / 2, sx: 1, sy: 1, rot: 0, hadSel: !!doc.sel };
    if (st.tool !== 'move') setTool('move', true);
    xfPreview();
    renderOptions();
  }
  function xfLocalToDoc(xf, lx, ly) {
    const c = Math.cos(xf.rot), s = Math.sin(xf.rot);
    return { x: xf.cx + lx * c - ly * s, y: xf.cy + lx * s + ly * c };
  }
  function xfDocToLocal(xf, x, y) {
    const c = Math.cos(-xf.rot), s = Math.sin(-xf.rot), dx = x - xf.cx, dy = y - xf.cy;
    return { x: dx * c - dy * s, y: dx * s + dy * c };
  }
  const xfCorners = (xf) => [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, b]) => xfLocalToDoc(xf, (a * xf.w * xf.sx) / 2, (b * xf.h * xf.sy) / 2));
  const xfHandles = (xf) => HANDLES.map(([a, b]) => ({ ...xfLocalToDoc(xf, (a * xf.w * xf.sx) / 2, (b * xf.h * xf.sy) / 2), hx: a, hy: b }));
  function xfPreview() {
    const xf = st.xf, doc = D(), t = copyC(xf.base), g = g2(t);
    g.translate(xf.cx, xf.cy);
    g.rotate(xf.rot);
    g.scale(xf.sx, xf.sy);
    g.imageSmoothingQuality = 'high';
    g.drawImage(xf.piece, -xf.w / 2, -xf.h / 2);
    xf.l.temp = t;
    if (doc) requestComp();
  }
  function xfDown(e, p) {
    const xf = st.xf, z = D().zoom;
    for (const hd of xfHandles(xf)) {
      if (Math.hypot(hd.x - p.x, hd.y - p.y) * z <= 7) { st.drag = { kind: 'xf-scale', hx: hd.hx, hy: hd.hy, start: { ...xf } }; return; }
    }
    const lp = xfDocToLocal(xf, p.x, p.y);
    if (Math.abs(lp.x) <= Math.abs(xf.w * xf.sx) / 2 && Math.abs(lp.y) <= Math.abs(xf.h * xf.sy) / 2) { st.drag = { kind: 'xf-move', p0: p, start: { ...xf } }; return; }
    st.drag = { kind: 'xf-rot', a0: Math.atan2(p.y - xf.cy, p.x - xf.cx), start: { ...xf } };
  }
  function xfMove(e, p) {
    const xf = st.xf, d = st.drag, s0 = d.start;
    if (d.kind === 'xf-move') { xf.cx = s0.cx + p.x - d.p0.x; xf.cy = s0.cy + p.y - d.p0.y; } else if (d.kind === 'xf-rot') {
      let a = s0.rot + Math.atan2(p.y - s0.cy, p.x - s0.cx) - d.a0;
      if (e.shiftKey) a = Math.round(a / (Math.PI / 12)) * (Math.PI / 12);
      xf.rot = a;
    } else {
      // Skalieren mit festem Gegenpunkt (Alt = von der Mitte aus)
      const tmpXf = { ...s0 };
      const m = xfDocToLocal(tmpXf, p.x, p.y);
      const hw = (s0.w * s0.sx) / 2, hh = (s0.h * s0.sy) / 2;
      const ax = e.altKey ? 0 : -d.hx * hw, ay = e.altKey ? 0 : -d.hy * hh;
      let nsx = s0.sx, nsy = s0.sy;
      if (d.hx) nsx = ((m.x - ax) * d.hx * (e.altKey ? 2 : 1)) / s0.w;
      if (d.hy) nsy = ((m.y - ay) * d.hy * (e.altKey ? 2 : 1)) / s0.h;
      if (d.hx && d.hy && !e.shiftKey) {
        const k = Math.max(nsx / s0.sx, nsy / s0.sy);
        nsx = s0.sx * k; nsy = s0.sy * k;
      }
      if (Math.abs(nsx) < 0.01) nsx = 0.01 * Math.sign(nsx || 1);
      if (Math.abs(nsy) < 0.01) nsy = 0.01 * Math.sign(nsy || 1);
      xf.sx = nsx; xf.sy = nsy;
      if (!e.altKey) {
        const lcx = d.hx ? ax + (d.hx * s0.w * nsx) / 2 : 0, lcy = d.hy ? ay + (d.hy * s0.h * nsy) / 2 : 0;
        const c = xfLocalToDoc(s0, lcx, lcy);
        xf.cx = c.x; xf.cy = c.y;
      }
    }
    xfPreview();
    renderOptions(true);
  }
  function applyTransform() {
    const xf = st.xf;
    if (!xf) return;
    xfPreview();
    const doc = D(), l = xf.l, g = g2(l.canvas);
    g.clearRect(0, 0, doc.w, doc.h);
    g.drawImage(l.temp, 0, 0);
    l.temp = null;
    touch(l);
    st.xf = null;
    if (xf.hadSel) setSel(null, null);
    requestComp();
    commit('Frei transformieren');
    renderOptions();
  }
  function cancelTransform() {
    const xf = st.xf;
    if (!xf) return;
    xf.l.temp = null;
    st.xf = null;
    requestComp();
    renderOptions();
  }

  /* ================================================================ Freistellen */
  function cropInit() {
    const doc = D();
    if (!doc) return;
    st.crop = doc.sel ? { ...doc.sel.box } : { x: 0, y: 0, w: doc.w, h: doc.h };
    draw();
  }
  function cropRatio() {
    const doc = D(), r = st.opt.cropRatio;
    return r === 'free' ? 0 : r === 'orig' ? doc.w / doc.h : r.split(':').reduce((a, b) => a / b);
  }
  function cropDown(e, p) {
    const c = st.crop, z = D().zoom;
    for (const [hx, hy] of HANDLES) {
      const x = c.x + (c.w * (hx + 1)) / 2, y = c.y + (c.h * (hy + 1)) / 2;
      if (Math.hypot(x - p.x, y - p.y) * z <= 8) { st.drag = { kind: 'crop-h', hx, hy, c0: { ...c } }; return; }
    }
    if (p.x > c.x && p.x < c.x + c.w && p.y > c.y && p.y < c.y + c.h) { st.drag = { kind: 'crop-move', p0: p, c0: { ...c } }; return; }
    st.drag = { kind: 'crop-new', p0: p };
  }
  function cropMove(e, p) {
    const d = st.drag, c = st.crop, ratio = cropRatio();
    if (d.kind === 'crop-move') { c.x = Math.round(d.c0.x + p.x - d.p0.x); c.y = Math.round(d.c0.y + p.y - d.p0.y); } else if (d.kind === 'crop-new') {
      let w = p.x - d.p0.x, h = p.y - d.p0.y;
      if (ratio) h = (Math.sign(h || 1) * Math.abs(w)) / ratio;
      c.x = Math.round(Math.min(d.p0.x, d.p0.x + w)); c.y = Math.round(Math.min(d.p0.y, d.p0.y + h));
      c.w = Math.round(Math.abs(w)); c.h = Math.round(Math.abs(h));
    } else {
      const c0 = d.c0;
      let x0 = c0.x, y0 = c0.y, x1 = c0.x + c0.w, y1 = c0.y + c0.h;
      if (d.hx < 0) x0 = p.x; if (d.hx > 0) x1 = p.x;
      if (d.hy < 0) y0 = p.y; if (d.hy > 0) y1 = p.y;
      if (ratio) {
        const w = Math.abs(x1 - x0);
        if (d.hy && !d.hx) { const nw = Math.abs(y1 - y0) * ratio; x1 = x0 + nw; } else {
          const nh = w / ratio;
          if (d.hy < 0) y0 = y1 - nh; else y1 = y0 + nh;
        }
      }
      c.x = Math.round(Math.min(x0, x1)); c.y = Math.round(Math.min(y0, y1)); c.w = Math.round(Math.abs(x1 - x0)); c.h = Math.round(Math.abs(y1 - y0));
    }
    draw();
    renderOptions(true);
  }
  function cropApply() {
    const doc = D(), c = st.crop;
    if (!doc || !c || c.w < 1 || c.h < 1) return;
    resizeCanvasTo(c.w, c.h, -c.x, -c.y, null);
    st.crop = null;
    commit('Freistellen');
    fit();
    if (st.tool === 'crop') cropInit();
  }
  function cropCancel() {
    st.crop = null;
    if (st.tool === 'crop') setTool('move');
    draw();
  }

  /* ================================================================ Bild- und Ebenen-Befehle */
  /** Alle Ebenen auf neue Arbeitsfläche setzen (Verschiebung ox/oy). fill = Farbe für die unterste Pixel-Ebene. */
  function resizeCanvasTo(nw, nh, ox, oy, fill) {
    const doc = D();
    nw = Math.round(nw); nh = Math.round(nh);
    const bottom = doc.layers.find((l) => l.kind === 'pixel');
    for (const l of doc.layers) {
      if (l.canvas) {
        const c = mk(nw, nh), g = g2(c);
        if (fill && l === bottom) { g.fillStyle = fill; g.fillRect(0, 0, nw, nh); g.clearRect(ox, oy, doc.w, doc.h); }
        g.drawImage(l.canvas, ox, oy);
        l.canvas = c;
      }
      if (l.mask) {
        const c = mk(nw, nh), g = g2(c);
        g.fillStyle = '#fff'; g.fillRect(0, 0, nw, nh); g.clearRect(ox, oy, doc.w, doc.h);
        g.drawImage(l.mask, ox, oy);
        l.mask = c;
      }
      if (l.kind === 'text') { l.text.x += ox; l.text.y += oy; }
      touch(l);
    }
    if (doc.sel) {
      const m = mk(nw, nh);
      g2(m).drawImage(doc.sel.mask, ox, oy);
      doc.w = nw; doc.h = nh;
      setSel(m, null);
    }
    doc.w = nw; doc.h = nh;
    doc.lastSel = null;
    for (const l of doc.layers) if (l.kind === 'text') renderText(l);
    requestComp();
  }
  function resizeImage(nw, nh, dpi, method) {
    const doc = D();
    nw = Math.round(nw); nh = Math.round(nh);
    const kx = nw / doc.w, ky = nh / doc.h;
    for (const l of doc.layers) {
      if (l.canvas) l.canvas = resample(l.canvas, nw, nh, method);
      if (l.mask) l.mask = resample(l.mask, nw, nh, method);
      if (l.kind === 'text') { l.text.x *= kx; l.text.y *= ky; l.text.size = Math.max(1, l.text.size * Math.sqrt(kx * ky)); }
      touch(l);
    }
    doc.w = nw; doc.h = nh; doc.dpi = dpi;
    setSel(null, null, doc);
    doc.lastSel = null;
    for (const l of doc.layers) if (l.kind === 'text') renderText(l);
    requestComp();
    commit('Bildgrösse');
    fit();
  }
  /** Ganzes Bild drehen (90/180/-90) oder spiegeln ('h'/'v'). Textebenen werden gerastert. */
  function rotateImage(kind) {
    const doc = D();
    if (!doc) return;
    const swap = kind === 90 || kind === -90;
    const nw = swap ? doc.h : doc.w, nh = swap ? doc.w : doc.h;
    const tf = (src) => {
      const c = mk(nw, nh), g = g2(c);
      if (kind === 'h') { g.translate(nw, 0); g.scale(-1, 1); } else if (kind === 'v') { g.translate(0, nh); g.scale(1, -1); } else if (kind === 180) { g.translate(nw, nh); g.rotate(Math.PI); } else if (kind === 90) { g.translate(nw, 0); g.rotate(Math.PI / 2); } else { g.translate(0, nh); g.rotate(-Math.PI / 2); }
      g.drawImage(src, 0, 0);
      return c;
    };
    for (const l of doc.layers) {
      if (l.kind === 'text') rasterize(l, false);
      if (l.canvas) l.canvas = tf(l.canvas);
      if (l.mask) l.mask = tf(l.mask);
      touch(l);
    }
    const sel = doc.sel ? tf(doc.sel.mask) : null;
    doc.w = nw; doc.h = nh;
    setSel(sel, null);
    requestComp();
    const names = { 90: 'Bilddrehung 90° im UZS', '-90': 'Bilddrehung 90° gegen UZS', 180: 'Bilddrehung 180°', h: 'Arbeitsfläche horizontal spiegeln', v: 'Arbeitsfläche vertikal spiegeln' };
    commit(names[kind]);
    fit();
  }
  function flipLayer(kind) {
    const doc = D(), l = active(doc);
    if (!l || l.kind === 'adj') return;
    if (l.kind === 'text') rasterize(l, false);
    const t = (src) => {
      const c = mk(doc.w, doc.h), g = g2(c);
      if (kind === 'h') { g.translate(doc.w, 0); g.scale(-1, 1); } else if (kind === 'v') { g.translate(0, doc.h); g.scale(1, -1); } else { g.translate(doc.w, doc.h); g.rotate(Math.PI); }
      g.drawImage(src, 0, 0);
      return c;
    };
    l.canvas = t(l.canvas);
    if (l.mask) l.mask = t(l.mask);
    touch(l);
    requestComp();
    commit(kind === 'h' ? 'Horizontal spiegeln' : kind === 'v' ? 'Vertikal spiegeln' : '180° drehen');
  }
  function rasterize(l, doCommit = true) {
    if (!l || l.kind !== 'text') return;
    l.kind = 'pixel';
    l.text = null;
    touch(l);
    if (doCommit) commit('Ebene rastern');
  }
  function insertAbove(l, doc = D()) {
    const i = doc.layers.findIndex((x) => x.id === doc.active);
    doc.layers.splice(i < 0 ? doc.layers.length : i + 1, 0, l);
    doc.active = l.id;
    touch(l);
    requestComp();
  }
  function addLayer() {
    const doc = D();
    if (!doc) return;
    insertAbove(newLayer(doc));
    commit('Neue Ebene');
  }
  function addAdjLayer(type) {
    const doc = D();
    if (!doc) return;
    const def = ADJ[type], mask = mk(doc.w, doc.h), g = g2(mask);
    if (doc.sel) g.drawImage(doc.sel.mask, 0, 0); else { g.fillStyle = '#fff'; g.fillRect(0, 0, doc.w, doc.h); }
    const n = doc.layers.filter((l) => l.adj?.type === type).length + 1;
    const l = newLayer(doc, { kind: 'adj', name: `${def.name} ${n}`, adj: { type, p: def.def() }, mask });
    insertAbove(l);
    commit(`Neue Einstellungsebene: ${def.name}`);
    st.adjTab = 'props';
    renderAdjPanel();
  }
  function duplicateLayer() {
    const doc = D(), l = active(doc);
    if (!l) return;
    let n;
    if (doc.sel && l.kind === 'pixel') {
      // Ebene durch Kopie (nur die Auswahl)
      n = newLayer(doc, { name: `${l.name} Kopie` });
      const g = g2(n.canvas);
      g.drawImage(l.canvas, 0, 0);
      g.globalCompositeOperation = 'destination-in';
      g.drawImage(doc.sel.mask, 0, 0);
    } else {
      n = newLayer(doc, { name: `${l.name} Kopie`, kind: l.kind, opacity: l.opacity, blend: l.blend, visible: l.visible, adj: clone(l.adj), text: clone(l.text), maskOn: l.maskOn, canvas: l.canvas ? copyC(l.canvas) : null, mask: l.mask ? copyC(l.mask) : null });
    }
    insertAbove(n);
    commit('Ebene duplizieren');
  }
  function deleteLayer() {
    const doc = D(), l = active(doc);
    if (!l) return;
    if (doc.layers.length === 1) { toast('Die letzte Ebene kann nicht gelöscht werden.', 'error'); return; }
    const i = doc.layers.indexOf(l);
    doc.layers.splice(i, 1);
    doc.active = doc.layers[Math.max(0, i - 1)].id;
    requestComp();
    commit('Ebene löschen');
  }
  function moveLayer(dir) {
    const doc = D(), l = active(doc);
    if (!l) return;
    const i = doc.layers.indexOf(l), j = clamp(dir === 'top' ? doc.layers.length - 1 : dir === 'bottom' ? 0 : i + dir, 0, doc.layers.length - 1);
    if (i === j) return;
    doc.layers.splice(i, 1);
    doc.layers.splice(j, 0, l);
    requestComp();
    commit('Ebenenreihenfolge');
  }
  /** Ebene in die darunterliegende einrechnen (Strg+E). */
  function mergeDown() {
    const doc = D(), l = active(doc);
    if (!l) return;
    const i = doc.layers.indexOf(l);
    if (i <= 0) return toast('Keine Ebene darunter.', 'error');
    const below = doc.layers[i - 1];
    if (below.kind === 'adj') return toast('Darunter liegt eine Einstellungsebene.', 'error');
    if (!below.visible) return toast('Die Ebene darunter ist ausgeblendet.', 'error');
    if (below.kind === 'text') rasterize(below, false);
    // Untere Ebene samt ihrer Maske „backen“
    const base = mk(doc.w, doc.h), bg = g2(base);
    bg.drawImage(below.canvas, 0, 0);
    if (below.mask && below.maskOn) { bg.globalCompositeOperation = 'destination-in'; bg.drawImage(below.mask, 0, 0); bg.globalCompositeOperation = 'source-over'; }
    if (l.visible) {
      const mask = l.mask && l.maskOn ? l.mask : null;
      if (l.kind === 'adj') {
        const res = runAdj(base, l.adj, 1);
        mixInto(base, res, mask, l.opacity);
      } else {
        let src = l.canvas;
        if (mask) { const t = tmp(4, doc.w, doc.h), tg = g2(t); tg.drawImage(src, 0, 0); tg.globalCompositeOperation = 'destination-in'; tg.drawImage(mask, 0, 0); src = t; }
        // Füllmethode in einer Kopie anwenden, Transparenz der unteren Ebene beachten
        const out = copyC(base), og = g2(out);
        og.globalAlpha = l.opacity;
        og.globalCompositeOperation = l.blend;
        og.drawImage(src, 0, 0);
        g2(base).clearRect(0, 0, doc.w, doc.h);
        g2(base).drawImage(out, 0, 0);
      }
    }
    below.canvas = base;
    below.mask = null;
    touch(below);
    doc.layers.splice(i, 1);
    doc.active = below.id;
    requestComp();
    commit('Auf eine Ebene reduzieren');
  }
  function mergeVisible() {
    const doc = D();
    if (!doc) return;
    const c = flatCanvas(doc);
    const vis = doc.layers.filter((l) => l.visible);
    if (vis.length < 2) return;
    const firstIdx = doc.layers.indexOf(vis[0]);
    const n = newLayer(doc, { name: vis[0].name, canvas: c });
    doc.layers = doc.layers.filter((l) => !l.visible);
    doc.layers.splice(Math.min(firstIdx, doc.layers.length), 0, n);
    doc.active = n.id;
    requestComp();
    commit('Sichtbare auf eine Ebene reduzieren');
  }
  function flatten() {
    const doc = D();
    if (!doc) return;
    const c = flatCanvas(doc, '#ffffff');
    const n = newLayer(doc, { name: 'Hintergrund', canvas: c });
    doc.layers = [n];
    doc.active = n.id;
    requestComp();
    commit('Auf Hintergrundebene reduzieren');
  }
  function addMask(fromSel = true) {
    const doc = D(), l = active(doc);
    if (!l) return;
    if (l.mask) { l.editMask = true; renderLayers(); return; }
    const m = mk(doc.w, doc.h), g = g2(m);
    if (fromSel && doc.sel) g.drawImage(doc.sel.mask, 0, 0); else { g.fillStyle = '#fff'; g.fillRect(0, 0, doc.w, doc.h); }
    l.mask = m;
    l.maskOn = true;
    l.editMask = true;
    touch(l);
    if (fromSel && doc.sel) setSel(null, null);
    requestComp();
    commit('Ebenenmaske hinzufügen');
  }
  function maskCmd(kind) {
    const doc = D(), l = active(doc);
    if (!l?.mask) return toast('Die Ebene hat keine Maske.', 'error');
    if (kind === 'delete') { l.mask = null; l.editMask = false; touch(l); requestComp(); return commit('Ebenenmaske löschen'); }
    if (kind === 'toggle') { l.maskOn = !l.maskOn; touch(l); requestComp(); return commit(l.maskOn ? 'Ebenenmaske aktivieren' : 'Ebenenmaske deaktivieren'); }
    if (kind === 'invert') {
      const g = g2(l.mask), c = mk(doc.w, doc.h), cg = g2(c);
      cg.fillStyle = '#fff'; cg.fillRect(0, 0, doc.w, doc.h);
      cg.globalCompositeOperation = 'destination-out'; cg.drawImage(l.mask, 0, 0);
      g.clearRect(0, 0, doc.w, doc.h); g.drawImage(c, 0, 0);
      touch(l); requestComp(); return commit('Maske umkehren');
    }
    if (kind === 'apply') {
      if (l.kind !== 'pixel') return toast('Nur bei Pixelebenen möglich.', 'error');
      const g = g2(l.canvas);
      g.globalCompositeOperation = 'destination-in';
      g.drawImage(l.mask, 0, 0);
      reset(g);
      l.mask = null; l.editMask = false;
      touch(l); requestComp(); return commit('Ebenenmaske anwenden');
    }
  }
  function clearSelection() {
    const doc = D(), l = active(doc);
    if (!l || !doc.sel) return;
    const t = paintTarget(l, 'Löschen');
    if (!t) return;
    if (t.mask) { const g = g2(t.c); g.globalCompositeOperation = 'destination-out'; g.drawImage(doc.sel.mask, 0, 0); reset(g); } else {
      const g = g2(t.c);
      g.globalCompositeOperation = 'destination-out';
      g.drawImage(doc.sel.mask, 0, 0);
      reset(g);
    }
    touch(l);
    requestComp();
    commit('Löschen');
  }
  /** Destruktive Korrektur/Filter auf die aktive Ebene (nur Auswahl, falls vorhanden). */
  function applyFilter(adj, label) {
    const doc = D(), l = active(doc);
    const t = paintTarget(l, label);
    if (!t) return;
    const res = runAdj(t.c, adj, 3);
    const out = copyC(t.c);
    mixInto(out, res, doc.sel ? doc.sel.mask : null, 1);
    const g = g2(t.c);
    g.clearRect(0, 0, doc.w, doc.h);
    g.drawImage(out, 0, 0);
    touch(l);
    requestComp();
    commit(label);
  }
  function autoLevels() {
    const doc = D(), l = active(doc);
    if (!l?.canvas || l.kind !== 'pixel') return;
    const h = histogram(l.canvas).lum, total = h.reduce((a, b) => a + b, 0), cut = total * 0.001;
    let lo = 0, hi = 255, acc = 0;
    while (lo < 254 && (acc += h[lo]) <= cut) lo++;
    acc = 0;
    while (hi > lo + 1 && (acc += h[hi]) <= cut) hi--;
    applyFilter({ type: 'levels', p: { ib: lo, ig: 1, iw: hi, ob: 0, ow: 255 } }, 'Auto-Tonwert');
  }
  function histogram(c) {
    const d = g2(c).getImageData(0, 0, c.width, c.height).data;
    const lumH = new Uint32Array(256), r = new Uint32Array(256), g = new Uint32Array(256), b = new Uint32Array(256);
    const step = d.length > 16e6 ? 16 : d.length > 4e6 ? 8 : 4;
    for (let i = 0; i < d.length; i += step) {
      if (!d[i + 3]) continue;
      r[d[i]]++; g[d[i + 1]]++; b[d[i + 2]]++;
      lumH[(d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8]++;
    }
    return { lum: lumH, r, g, b };
  }

  /* ================================================================ Zwischenablage */
  function copySel(merged, cut) {
    const doc = D(), l = active(doc);
    if (!doc) return;
    const src = merged ? flatCanvas(doc) : l?.canvas;
    if (!src) return;
    const box = doc.sel ? doc.sel.box : { x: 0, y: 0, w: doc.w, h: doc.h };
    const c = mk(box.w, box.h), g = g2(c);
    g.drawImage(src, -box.x, -box.y);
    if (doc.sel) { g.globalCompositeOperation = 'destination-in'; g.drawImage(doc.sel.mask, -box.x, -box.y); }
    st.clip = { c, x: box.x, y: box.y };
    try {
      c.toBlob((b) => { if (b && window.ClipboardItem) navigator.clipboard.write([new ClipboardItem({ 'image/png': b })]).catch(() => {}); }, 'image/png');
    } catch { /* nur intern */ }
    if (cut && !merged) clearSelection();
    toast(cut ? 'Ausgeschnitten.' : 'Kopiert.');
  }
  async function paste() {
    let img = null;
    try {
      const items = await navigator.clipboard.read();
      for (const it of items) {
        const type = it.types.find((t) => t.startsWith('image/'));
        if (type) { img = await createImageBitmap(await it.getType(type)); break; }
      }
    } catch { /* kein Bild */ }
    // Eigenes Kopiertes hat Vorrang, wenn es gleich gross ist (behält die Position)
    if (st.clip && (!img || (img.width === st.clip.c.width && img.height === st.clip.c.height))) return placeImage(st.clip.c, 'Eingefügte Ebene', st.clip.x, st.clip.y);
    if (img) return placeImage(img, 'Eingefügte Ebene');
    toast('Die Zwischenablage enthält kein Bild.', 'error');
  }
  /** Bild als neue Ebene (oder neues Dokument, falls keins offen ist). */
  function placeImage(img, name, x, y) {
    let doc = D();
    if (!doc) { openImageAsDoc(img, name || 'Eingefügt'); return; }
    const l = newLayer(doc, { name: `${name} ${++st.layerSeq}` });
    const k = Math.min(1, doc.w / img.width, doc.h / img.height);
    const w = img.width * (x == null ? k : 1), h = img.height * (x == null ? k : 1);
    const px = x == null ? (doc.w - w) / 2 : x, py = y == null ? (doc.h - h) / 2 : y;
    g2(l.canvas).drawImage(img, px, py, w, h);
    insertAbove(l);
    setSel(null, null);
    commit('Einfügen');
  }

  /* ================================================================ Dateien */
  function addDoc(doc, label = 'Öffnen') {
    st.docs.push(doc);
    st.doc = doc;
    st.crop = null; st.xf = null;
    commit(label, doc);
    doc.dirty = false;
    requestAnimationFrame(() => { fit(doc); refresh(); });
    refresh();
  }
  function openImageAsDoc(img, name) {
    const doc = makeDoc({ name: name || 'Bild', w: img.width, h: img.height, fill: null });
    const l = doc.layers[0];
    l.name = 'Hintergrund';
    g2(l.canvas).drawImage(img, 0, 0);
    touch(l);
    addDoc(doc, 'Öffnen');
  }
  const readDataUrl = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });
  const imgFromUrl = (url) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
  async function loadImg(blob) {
    try { return await createImageBitmap(blob); } catch { return imgFromUrl(await readDataUrl(blob)); }
  }
  function openDialog(asLayer = false) {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.multiple = !asLayer;
    inp.accept = asLayer ? 'image/*' : 'image/*,.rvfoto';
    inp.onchange = () => openFiles([...inp.files], asLayer);
    inp.click();
  }
  async function openFiles(files, asLayer) {
    for (const f of files) {
      try {
        if (/\.rvfoto$/i.test(f.name)) { await loadProject(await f.text(), f.name.replace(/\.rvfoto$/i, '')); continue; }
        if (!/^image\//.test(f.type) && !/\.(png|jpe?g|webp|gif|bmp|avif|ico|svg)$/i.test(f.name)) { toast(`${f.name}: Dieses Format wird nicht unterstützt.`, 'error'); continue; }
        const img = await loadImg(f);
        const name = f.name.replace(/\.[^.]+$/, '');
        if (asLayer && D()) placeImage(img, name); else openImageAsDoc(img, name);
      } catch (e) {
        console.error(e);
        toast(`${f.name} konnte nicht geöffnet werden.`, 'error');
      }
    }
  }
  async function projectBlob(doc) {
    const layers = doc.layers.map((l) => ({
      name: l.name, kind: l.kind, visible: l.visible, opacity: l.opacity, blend: l.blend, maskOn: l.maskOn, adj: l.adj,
      text: l.text ? { ...l.text, box: undefined } : null,
      png: l.canvas && l.kind !== 'adj' ? l.canvas.toDataURL('image/png') : null,
      mask: l.mask ? l.mask.toDataURL('image/png') : null,
    }));
    const data = { app: 'Revolution Hub Foto', v: 1, name: doc.name, w: doc.w, h: doc.h, dpi: doc.dpi, active: doc.layers.findIndex((l) => l.id === doc.active), layers };
    return new Blob([JSON.stringify(data)], { type: 'application/json' });
  }
  async function loadProject(text, fallback) {
    const data = JSON.parse(text);
    if (!data || !Array.isArray(data.layers) || !data.w) throw new Error('Kein Foto-Projekt');
    const doc = makeDoc({ name: data.name || fallback, w: data.w, h: data.h, dpi: data.dpi || 72, fill: null });
    doc.layers = [];
    for (const x of data.layers) {
      const l = newLayer(doc, { name: x.name, kind: x.kind || 'pixel', visible: x.visible !== false, opacity: x.opacity ?? 1, blend: x.blend || 'source-over', maskOn: x.maskOn !== false, adj: x.adj || null, text: x.text || null });
      if (x.png && l.canvas) g2(l.canvas).drawImage(await imgFromUrl(x.png), 0, 0);
      if (x.mask) { l.mask = mk(doc.w, doc.h); g2(l.mask).drawImage(await imgFromUrl(x.mask), 0, 0); }
      if (l.kind === 'text' && l.text) renderText(l);
      doc.layers.push(l);
    }
    if (!doc.layers.length) doc.layers.push(newLayer(doc));
    doc.seq = doc.layers.length;
    doc.active = (doc.layers[data.active] || doc.layers[doc.layers.length - 1]).id;
    addDoc(doc, 'Öffnen');
  }
  /** Datei speichern: mit Speichern-Dialog von Windows (File System Access), sonst als Download. */
  async function saveBlob(blob, name, desc, accept, handle) {
    if (window.showSaveFilePicker) {
      try {
        const h = handle || (await window.showSaveFilePicker({ suggestedName: name, types: [{ description: desc, accept }] }));
        const w = await h.createWritable();
        await w.write(blob);
        await w.close();
        return { handle: h, name: h.name };
      } catch (e) {
        if (e?.name === 'AbortError') return null;
        console.warn('Speichern-Dialog nicht verfügbar', e);
      }
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 8000);
    return { name };
  }
  async function saveProject(as) {
    const doc = D();
    if (!doc) return;
    const res = await saveBlob(await projectBlob(doc), `${doc.name}.rvfoto`, 'Revolution-Foto-Projekt', { 'application/json': ['.rvfoto'] }, as ? null : doc.file);
    if (!res) return;
    if (res.handle) doc.file = res.handle;
    if (res.name) doc.name = res.name.replace(/\.rvfoto$/i, '');
    doc.dirty = false;
    renderTabs();
    toast('Projekt gespeichert.');
  }
  const MIME = { png: ['image/png', 'PNG-Bild', '.png'], jpg: ['image/jpeg', 'JPEG-Bild', '.jpg'], webp: ['image/webp', 'WebP-Bild', '.webp'] };
  const toBlob = (c, type, q) => new Promise((res) => c.toBlob(res, type, q));
  async function exportImage(fmt, q, w, h) {
    const doc = D();
    let c = flatCanvas(doc, fmt === 'jpg' ? '#ffffff' : null);
    if (w !== doc.w || h !== doc.h) c = resample(c, w, h);
    const [mime, desc, ext] = MIME[fmt];
    const blob = await toBlob(c, mime, q);
    const res = await saveBlob(blob, `${doc.name}${ext}`, desc, { [mime]: [ext] });
    if (res) toast(`Exportiert: ${res.name}`);
  }
  async function closeDoc(doc = D(), force = false) {
    if (!doc) return;
    if (doc.dirty && !force) {
      const r = await ask('Revolution Foto', `Änderungen an „${doc.name}“ vor dem Schliessen speichern?`, [['save', 'Speichern', true], ['drop', 'Nicht speichern'], ['cancel', 'Abbrechen']]);
      if (r === 'cancel' || !r) return;
      if (r === 'save') { st.doc = doc; await saveProject(false); if (doc.dirty) return; }
    }
    const i = st.docs.indexOf(doc);
    st.docs.splice(i, 1);
    if (st.doc === doc) st.doc = st.docs[Math.min(i, st.docs.length - 1)] || null;
    st.crop = null; st.xf = null;
    refresh();
  }
  function switchDoc(doc) {
    if (st.textEdit) commitText();
    if (st.xf) applyTransform();
    st.crop = null;
    st.doc = doc;
    if (st.tool === 'crop') cropInit();
    refresh();
  }

  /* ================================================================ Text */
  function textClick(p) {
    const doc = D();
    const hit = [...doc.layers].reverse().find((l) => l.kind === 'text' && l.visible && l.text.box && p.x >= l.text.box.x - 4 && p.x <= l.text.box.x + l.text.box.w + 4 && p.y >= l.text.box.y - 4 && p.y <= l.text.box.y + l.text.box.h + 4);
    if (hit) {
      doc.active = hit.id;
      Object.assign(st.opt, { font: hit.text.font, fontSize: Math.round(hit.text.size), bold: hit.text.bold, italic: hit.text.italic, align: hit.text.align });
      st.fg = hit.text.color;
      openTextEditor(hit, hit.text.x, hit.text.y);
    } else openTextEditor(null, p.x, p.y);
    renderOptions();
    renderLayers();
    renderColorChips();
  }
  function openTextEditor(layer, x, y) {
    const doc = D(), o = st.opt;
    const ta = document.createElement('textarea');
    ta.className = 'ph-textedit';
    ta.spellcheck = false;
    ta.value = layer ? layer.text.str : '';
    st.el.stage.append(ta);
    st.textEdit = { layer, x, y, ta };
    if (layer) { layer.editing = true; requestComp(); }
    const place = () => {
      const z = doc.zoom, s = toScr(x, y), fs = o.fontSize * z;
      Object.assign(ta.style, { font: `${o.italic ? 'italic ' : ''}${o.bold ? 700 : 400} ${fs}px "${o.font}", sans-serif`, color: st.fg, lineHeight: '1.2', textAlign: o.align });
      ta.style.height = '0px';
      ta.style.width = '0px';
      const w = Math.max(fs * 2, ta.scrollWidth + fs * 0.6), h = Math.max(fs * 1.25, ta.scrollHeight);
      ta.style.width = `${w}px`;
      ta.style.height = `${h}px`;
      const left = o.align === 'center' ? s.x - w / 2 : o.align === 'right' ? s.x - w : s.x;
      ta.style.left = `${left}px`;
      ta.style.top = `${s.y}px`;
    };
    st.textEdit.place = place;
    ta.addEventListener('input', place);
    ta.addEventListener('pointerdown', (e) => e.stopPropagation());
    place();
    setTimeout(() => ta.focus(), 0);
    renderOptions();
  }
  function commitText() {
    const te = st.textEdit;
    if (!te) return;
    st.textEdit = null;
    te.ta.remove();
    const doc = D(), str = te.ta.value.replace(/\s+$/, '');
    const props = { str, x: te.x, y: te.y, font: st.opt.font, size: st.opt.fontSize, bold: st.opt.bold, italic: st.opt.italic, align: st.opt.align, color: st.fg };
    if (te.layer) {
      te.layer.editing = false;
      if (!str) { requestComp(); return; }
      te.layer.text = props;
      te.layer.name = str.split('\n')[0].slice(0, 30);
      renderText(te.layer);
      requestComp();
      commit('Text bearbeiten');
    } else if (str) {
      const l = newLayer(doc, { kind: 'text', name: str.split('\n')[0].slice(0, 30), text: props });
      renderText(l);
      insertAbove(l);
      commit('Textebene');
    }
    renderOptions();
  }
  function cancelText() {
    const te = st.textEdit;
    if (!te) return;
    st.textEdit = null;
    te.ta.remove();
    if (te.layer) te.layer.editing = false;
    requestComp();
    renderOptions();
  }
  /** Optionen der Textleiste auf die aktive Textebene übertragen. */
  function textOptsToLayer() {
    if (st.textEdit) { st.textEdit.place(); return; }
    const l = active();
    if (l?.kind !== 'text' || st.tool !== 'text') return;
    Object.assign(l.text, { font: st.opt.font, size: st.opt.fontSize, bold: st.opt.bold, italic: st.opt.italic, align: st.opt.align, color: st.fg });
    renderText(l);
    requestComp();
    commit('Textformat');
  }

  /* ================================================================ Zeiger auf der Leinwand */
  function onDown(e) {
    const doc = D();
    if (!doc || st.dlg) return;
    closeMenu();
    if (st.textEdit) { commitText(); if (st.tool === 'text') return; }
    const p = toDoc(e);
    try { st.el.view.setPointerCapture(e.pointerId); } catch { /* egal */ }
    if (e.button === 1 || st.space || st.tool === 'hand') { st.drag = { kind: 'pan', x: e.clientX, y: e.clientY, px: doc.px, py: doc.py }; updateCursor(); return; }
    if (e.button !== 0) return;
    if (st.xf) return xfDown(e, p);
    const mode = e.shiftKey && e.altKey ? 'int' : e.shiftKey ? 'add' : e.altKey ? 'sub' : st.opt.selMode;
    switch (st.tool) {
      case 'move': return moveStart(e, p);
      case 'marquee': case 'ellipse': st.drag = { kind: 'sel', tool: st.tool, p0: p, p, mode, shape: null }; return;
      case 'lasso': st.drag = { kind: 'lasso', pts: [p], mode }; return;
      case 'wand': {
        const l = active(doc), src = st.opt.sampleAll || !l?.canvas ? doc.comp : l.canvas;
        const m = regionMask(src, p.x, p.y, st.opt.tolerance, st.opt.contiguous, st.opt.antialias);
        if (m) combineSel(m, mode, 'Zauberstab');
        return draw();
      }
      case 'crop': if (!st.crop) cropInit(); return cropDown(e, p);
      case 'eyedropper': pickColor(p, e.altKey); st.drag = { kind: 'pick' }; return;
      case 'brush': case 'eraser': case 'clone': return paintStart(e, p);
      case 'bucket': if (e.altKey) return pickColor(p, false); return bucketFill(p);
      case 'gradient': st.drag = { kind: 'gradient', p0: p, p }; return;
      case 'text': return textClick(p);
      case 'shape': if (e.altKey) return pickColor(p, false); st.drag = { kind: 'shape', p0: p, p, path: null }; return;
      case 'zoom': return zoomStep(e.altKey !== st.opt.zoomOut ? -1 : 1, p.sx, p.sy);
      default:
    }
  }
  function selShape(d, e) {
    let { x: ax, y: ay } = d.p0, { x: bx, y: by } = d.p;
    let w = bx - ax, h = by - ay;
    if (e.shiftKey && d.mode === 'new') { const s = Math.max(Math.abs(w), Math.abs(h)); w = Math.sign(w || 1) * s; h = Math.sign(h || 1) * s; }
    let x = ax, y = ay;
    if (e.altKey && d.mode === 'new') { x = ax - w; y = ay - h; w *= 2; h *= 2; }
    const rx = Math.round(Math.min(x, x + w)), ry = Math.round(Math.min(y, y + h)), rw = Math.round(Math.abs(w)), rh = Math.round(Math.abs(h));
    const p = new Path2D();
    if (d.tool === 'ellipse') p.ellipse(rx + rw / 2, ry + rh / 2, Math.max(0.5, rw / 2), Math.max(0.5, rh / 2), 0, 0, Math.PI * 2); else p.rect(rx, ry, rw, rh);
    d.shape = p;
    d.box = { x: rx, y: ry, w: rw, h: rh };
  }
  function onMove(e) {
    const doc = D();
    if (!doc) return;
    const p = toDoc(e);
    st.mouse = { ...p, in: true };
    const d = st.drag;
    if (!d) {
      renderStatus(p);
      if (st.xf) {
        const near = xfHandles(st.xf).some((h) => Math.hypot(h.x - p.x, h.y - p.y) * doc.zoom <= 7);
        const lp = xfDocToLocal(st.xf, p.x, p.y), inside = Math.abs(lp.x) <= Math.abs(st.xf.w * st.xf.sx) / 2 && Math.abs(lp.y) <= Math.abs(st.xf.h * st.xf.sy) / 2;
        st.el.view.style.cursor = near ? 'nwse-resize' : inside ? MOVE_CURSOR : 'alias';
      }
      if (PAINT.has(st.tool) || st.tool === 'clone') draw();
      return;
    }
    switch (d.kind) {
      case 'pan': doc.px = d.px + e.clientX - d.x; doc.py = d.py + e.clientY - d.y; draw(); break;
      case 'sel': d.p = p; selShape(d, e); draw(); break;
      case 'lasso': { const q = d.pts[d.pts.length - 1]; if (Math.hypot(q.x - p.x, q.y - p.y) * doc.zoom > 2) d.pts.push(p); draw(); break; }
      case 'paint': paintMove(e, p); break;
      case 'move': {
        let dx = p.x - d.p0.x, dy = p.y - d.p0.y;
        if (e.shiftKey) { if (Math.abs(dx) > Math.abs(dy)) dy = 0; else dx = 0; }
        moveUpdate(d, dx, dy);
        break;
      }
      case 'xf-move': case 'xf-rot': case 'xf-scale': xfMove(e, p); break;
      case 'crop-new': case 'crop-move': case 'crop-h': cropMove(e, p); break;
      case 'gradient': {
        let q = p;
        if (e.shiftKey) { const a = Math.round(Math.atan2(p.y - d.p0.y, p.x - d.p0.x) / (Math.PI / 4)) * (Math.PI / 4), r = Math.hypot(p.x - d.p0.x, p.y - d.p0.y); q = { x: d.p0.x + Math.cos(a) * r, y: d.p0.y + Math.sin(a) * r }; }
        d.p = q;
        draw();
        break;
      }
      case 'shape': d.p = p; d.path = shapePath(st.opt.shape, d.p0, p, e.shiftKey); draw(); break;
      case 'pick': pickColor(p, e.altKey); break;
      default:
    }
  }
  function onUp(e) {
    const d = st.drag, doc = D();
    if (!d || !doc) return;
    st.drag = null;
    try { st.el.view.releasePointerCapture(e.pointerId); } catch { /* egal */ }
    switch (d.kind) {
      case 'sel': {
        if (!d.box || (d.box.w < 1 && d.box.h < 1) || d.box.w < 1 || d.box.h < 1) { if (d.mode === 'new' && doc.sel) deselect(); break; }
        const m = mk(doc.w, doc.h), g = g2(m);
        g.fill(d.shape);
        combineSel(m, d.mode, d.tool === 'ellipse' ? 'Auswahlellipse' : 'Auswahlrechteck');
        break;
      }
      case 'lasso': {
        if (d.pts.length < 3) { if (d.mode === 'new' && doc.sel) deselect(); break; }
        const m = mk(doc.w, doc.h), g = g2(m);
        g.beginPath();
        d.pts.forEach((q, i) => (i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)));
        g.closePath();
        g.fill();
        combineSel(m, d.mode, 'Lasso');
        break;
      }
      case 'paint': paintEnd(d); break;
      case 'move': moveEnd(d); break;
      case 'gradient': if (Math.hypot(d.p.x - d.p0.x, d.p.y - d.p0.y) > 1) gradientApply(d.p0, d.p); break;
      case 'shape': if (d.path && Math.hypot(d.p.x - d.p0.x, d.p.y - d.p0.y) > 1) shapeCommit(d.path); break;
      case 'xf-move': case 'xf-rot': case 'xf-scale': renderOptions(); break;
      case 'crop-new': if (st.crop.w < 2 || st.crop.h < 2) cropInit(); break;
      default:
    }
    updateCursor();
    draw();
  }
  function onWheel(e) {
    const doc = D();
    if (!doc) return;
    e.preventDefault();
    const r = st.el.view.getBoundingClientRect();
    if (e.ctrlKey || e.altKey || e.metaKey) {
      const f = Math.exp(-e.deltaY * (e.deltaMode ? 0.05 : 0.0018));
      zoomAt(doc.zoom * f, e.clientX - r.left, e.clientY - r.top);
    } else {
      const k = e.deltaMode ? 30 : 1;
      if (e.shiftKey) doc.px -= (e.deltaY || e.deltaX) * k; else { doc.px -= e.deltaX * k; doc.py -= e.deltaY * k; }
      draw();
    }
  }
  function updateCursor() {
    const v = st.el.view;
    if (!v) return;
    const t = st.tool;
    v.style.cursor = st.drag?.kind === 'pan' ? 'grabbing' : st.space || t === 'hand' ? 'grab' : st.xf ? 'default' : t === 'zoom' ? (st.opt.zoomOut ? 'zoom-out' : 'zoom-in') : PAINT.has(t) ? 'none' : t === 'move' ? MOVE_CURSOR : t === 'text' ? 'text' : t === 'eyedropper' ? 'copy' : 'crosshair';
  }

  /* ================================================================ Oberfläche */
  const hasDoc = () => !!D();
  const hasSel = () => !!D()?.sel;
  const hasMask = () => !!active()?.mask;
  const isText = () => active()?.kind === 'text';
  const MENUS = [
    ['Datei', [
      ['Neu …', 'ctrl+n', () => newDialog()],
      ['Öffnen …', 'ctrl+o', () => openDialog()],
      ['Als Ebene platzieren …', '', () => openDialog(true), hasDoc],
      '-',
      ['Schliessen', 'ctrl+w', () => closeDoc(), hasDoc],
      ['Alle schliessen', 'ctrl+alt+w', async () => { for (const d of [...st.docs]) { st.doc = d; await closeDoc(d); if (st.docs.includes(d)) break; } refresh(); }, hasDoc],
      '-',
      ['Speichern', 'ctrl+s', () => saveProject(false), hasDoc],
      ['Speichern unter …', 'ctrl+shift+s', () => saveProject(true), hasDoc],
      '-',
      ['Exportieren als …', 'ctrl+alt+shift+w', () => exportDialog(), hasDoc],
      ['Schnell als PNG exportieren', '', () => exportImage('png', 1, D().w, D().h), hasDoc],
    ]],
    ['Bearbeiten', [
      ['Rückgängig', 'ctrl+z', undo, () => !!st.xf || D()?.hi > 0],
      ['Wiederholen', 'ctrl+shift+z', redo, () => !!D() && D().hi < D().hist.length - 1],
      '-',
      ['Ausschneiden', 'ctrl+x', () => copySel(false, true), hasDoc],
      ['Kopieren', 'ctrl+c', () => copySel(false), hasDoc],
      ['Auf eine Ebene reduziert kopieren', 'ctrl+shift+c', () => copySel(true), hasDoc],
      ['Einfügen', 'ctrl+v', () => paste()],
      ['Löschen', 'delete', () => clearSelection(), hasSel],
      '-',
      ['Fläche füllen …', 'shift+f5', () => fillDialog(), hasDoc],
      '-',
      ['Frei transformieren', 'ctrl+t', () => startTransform(), hasDoc],
      ['Ebene horizontal spiegeln', '', () => flipLayer('h'), hasDoc],
      ['Ebene vertikal spiegeln', '', () => flipLayer('v'), hasDoc],
      ['Ebene um 180° drehen', '', () => flipLayer('r'), hasDoc],
      '-',
      ['Tastaturbefehle …', 'ctrl+alt+shift+k', () => shortcutsDialog()],
    ]],
    ['Bild', [
      ['#Korrekturen'],
      ...['bc', 'levels', 'curves', 'hsl', 'balance', 'bw'].map((t) => [`${ADJ[t].name} …`, { levels: 'ctrl+l', curves: 'ctrl+m', hsl: 'ctrl+u', balance: 'ctrl+b', bw: 'ctrl+alt+shift+b' }[t] || '', () => adjDialog(t), hasDoc]),
      ['Umkehren', 'ctrl+i', () => applyFilter({ type: 'invert', p: {} }, 'Umkehren'), hasDoc],
      ['Sättigung verringern', 'ctrl+shift+u', () => applyFilter({ type: 'desat', p: {} }, 'Sättigung verringern'), hasDoc],
      ['Auto-Tonwert', 'ctrl+shift+l', () => autoLevels(), hasDoc],
      '-',
      ['Bildgrösse …', 'ctrl+alt+i', () => imageSizeDialog(), hasDoc],
      ['Arbeitsfläche …', 'ctrl+alt+c', () => canvasSizeDialog(), hasDoc],
      '-',
      ['#Bilddrehung'],
      ['180°', '', () => rotateImage(180), hasDoc],
      ['90° im UZS', '', () => rotateImage(90), hasDoc],
      ['90° gegen UZS', '', () => rotateImage(-90), hasDoc],
      ['Arbeitsfläche horizontal spiegeln', '', () => rotateImage('h'), hasDoc],
      ['Arbeitsfläche vertikal spiegeln', '', () => rotateImage('v'), hasDoc],
      '-',
      ['Freistellen (Auswahl)', '', () => { const b = D().sel.box; st.crop = { ...b }; cropApply(); }, hasSel],
      ['Zuschneiden (transparente Pixel)', '', () => trim(), hasDoc],
    ]],
    ['Ebene', [
      ['Neue Ebene', 'ctrl+shift+n', () => addLayer(), hasDoc],
      ['Ebene duplizieren', 'ctrl+j', () => duplicateLayer(), hasDoc],
      ['Ebene löschen', '', () => deleteLayer(), hasDoc],
      ['Ebene umbenennen …', '', () => renameActive(), hasDoc],
      '-',
      ['#Neue Einstellungsebene'],
      ...ADJ_LAYER_TYPES.map((t) => [`${ADJ[t].name} …`, '', () => addAdjLayer(t), hasDoc]),
      '-',
      ['#Ebenenmaske'],
      ['Alles einblenden', '', () => addMask(false), () => hasDoc() && !hasMask()],
      ['Auswahl einblenden', '', () => addMask(true), () => hasSel() && !hasMask()],
      ['Maske aktivieren/deaktivieren', '', () => maskCmd('toggle'), hasMask],
      ['Maske umkehren', '', () => maskCmd('invert'), hasMask],
      ['Maske anwenden', '', () => maskCmd('apply'), hasMask],
      ['Maske löschen', '', () => maskCmd('delete'), hasMask],
      '-',
      ['Ebene rastern', '', () => rasterize(active()), isText],
      '-',
      ['#Anordnen'],
      ['In den Vordergrund', 'ctrl+shift+]', () => moveLayer('top'), hasDoc],
      ['Schrittweise vorwärts', 'ctrl+]', () => moveLayer(1), hasDoc],
      ['Schrittweise rückwärts', 'ctrl+[', () => moveLayer(-1), hasDoc],
      ['In den Hintergrund', 'ctrl+shift+[', () => moveLayer('bottom'), hasDoc],
      '-',
      ['Auf eine Ebene reduzieren', 'ctrl+e', () => mergeDown(), hasDoc],
      ['Sichtbare auf eine Ebene reduzieren', 'ctrl+shift+e', () => mergeVisible(), hasDoc],
      ['Auf Hintergrundebene reduzieren', '', () => flatten(), hasDoc],
    ]],
    ['Auswahl', [
      ['Alles auswählen', 'ctrl+a', () => selectAll(), hasDoc],
      ['Auswahl aufheben', 'ctrl+d', () => deselect(), hasSel],
      ['Erneut wählen', 'ctrl+shift+d', () => reselect(), () => !!D()?.lastSel],
      ['Auswahl umkehren', 'ctrl+shift+i', () => invertSel(), hasDoc],
      '-',
      ['Weiche Kante …', 'shift+f6', () => numDialog('Weiche Auswahlkante', 'Radius', 5, 'Pixel', (v) => modifySel('feather', v)), hasSel],
      ['Erweitern …', '', () => numDialog('Auswahl erweitern', 'Erweitern um', 4, 'Pixel', (v) => modifySel('expand', v)), hasSel],
      ['Verkleinern …', '', () => numDialog('Auswahl verkleinern', 'Verkleinern um', 4, 'Pixel', (v) => modifySel('contract', v)), hasSel],
      '-',
      ['Ebenentransparenz laden', '', () => loadTransparency(active()), hasDoc],
    ]],
    ['Filter', [
      ['#Weichzeichnungsfilter'],
      ['Gaussscher Weichzeichner …', '', () => adjDialog('blur'), hasDoc],
      ['Bewegungsunschärfe …', '', () => adjDialog('motion'), hasDoc],
      ['#Scharfzeichnungsfilter'],
      ['Unscharf maskieren …', '', () => adjDialog('sharpen'), hasDoc],
      ['Scharfzeichnen', '', () => applyFilter({ type: 'sharpen', p: { amount: 60, r: 1, th: 0 } }, 'Scharfzeichnen'), hasDoc],
      ['#Rauschfilter'],
      ['Rauschen hinzufügen …', '', () => adjDialog('noise'), hasDoc],
      ['Rauschen entfernen …', '', () => adjDialog('median'), hasDoc],
      ['#Vergröberungsfilter'],
      ['Mosaik …', '', () => adjDialog('mosaic'), hasDoc],
    ]],
    ['Ansicht', [
      ['Einzoomen', 'ctrl+plus', () => zoomStep(1), hasDoc],
      ['Auszoomen', 'ctrl+minus', () => zoomStep(-1), hasDoc],
      ['Ganzes Bild', 'ctrl+0', () => fit(), hasDoc],
      ['100 %', 'ctrl+1', () => zoomAt(1), hasDoc],
      '-',
      ['Bedienfelder ein/aus', 'tab', () => togglePanels()],
    ]],
  ];
  const normKey = (k) => {
    const parts = k.split('+'), key = parts.pop();
    const mods = ['ctrl', 'alt', 'shift'].filter((m) => parts.includes(m));
    return [...mods, key].join('+');
  };
  const KEYMAP = new Map();
  for (const [, items] of MENUS) for (const it of items) if (Array.isArray(it) && it[1]) KEYMAP.set(normKey(it[1]), { run: it[2], en: it[3], label: it[0] });
  const keyLabel = (k) => k.split('+').map((p) => ({ ctrl: 'Strg', alt: 'Alt', shift: 'Umschalt', plus: '+', minus: '-', delete: 'Entf', tab: 'Tab' })[p] || p.toUpperCase()).join('+');
  function combo(e) {
    let k = e.key || '';
    const code = e.code || '';
    if (k.length === 1 && /[a-zäöü]/i.test(k)) k = k.toLowerCase();
    else if (/^Key[A-Z]$/.test(code) && (e.ctrlKey || e.altKey)) k = code.slice(3).toLowerCase();
    if (/^Digit\d$/.test(code)) k = code.slice(5);
    else if (/^Numpad\d$/.test(code)) k = code.slice(6);
    if (k === '+' || k === '=' || code === 'NumpadAdd') k = 'plus';
    else if (k === '-' || k === '_' || code === 'NumpadSubtract') k = 'minus';
    else if (k === ' ') k = 'space';
    else if (k.length > 1) k = k.toLowerCase();
    let ctrl = e.ctrlKey || e.metaKey, alt = e.altKey;
    if (e.getModifierState?.('AltGraph') || (ctrl && alt && /^[[\]{}\\|@~]$/.test(k))) { ctrl = false; alt = false; }
    return [ctrl && 'ctrl', alt && 'alt', e.shiftKey && k !== 'plus' && 'shift', k].filter(Boolean).join('+');
  }

  function mountUi(root) {
    root.innerHTML = `
      <div class="ph" tabindex="-1">
        <div class="ph-menubar"><span class="ph-logo">${svg('pixel', 15)}</span>${MENUS.map((m, i) => `<button class="ph-mb" data-menu="${i}">${m[0]}</button>`).join('')}<span class="ph-grow"></span><span class="ph-menuhint">Revolution Foto</span></div>
        <div class="ph-opts"></div>
        <div class="ph-tools"></div>
        <div class="ph-center">
          <div class="ph-tabs"></div>
          <div class="ph-stage"><canvas class="ph-view"></canvas><div class="ph-home" hidden></div></div>
          <div class="ph-status"></div>
        </div>
        <div class="ph-side">
          <section class="ph-pn" data-pn="color"></section>
          <section class="ph-pn" data-pn="adj"></section>
          <section class="ph-pn grow" data-pn="layers"></section>
          <section class="ph-pn" data-pn="hist"></section>
        </div>
        <div class="ph-pop" hidden></div>
        <div class="ph-dlgs" hidden></div>
      </div>`;
    const q = (s) => root.querySelector(s);
    st.el = {
      ph: q('.ph'), bar: q('.ph-menubar'), opts: q('.ph-opts'), tools: q('.ph-tools'), tabs: q('.ph-tabs'), stage: q('.ph-stage'), view: q('.ph-view'), home: q('.ph-home'), status: q('.ph-status'),
      color: q('[data-pn="color"]'), adj: q('[data-pn="adj"]'), layers: q('[data-pn="layers"]'), hist: q('[data-pn="hist"]'), pop: q('.ph-pop'), dlgs: q('.ph-dlgs'),
    };
    const v = st.el.view;
    v.addEventListener('pointerdown', onDown);
    v.addEventListener('pointermove', onMove);
    v.addEventListener('pointerup', onUp);
    v.addEventListener('pointercancel', onUp);
    v.addEventListener('pointerleave', () => { if (st.mouse) st.mouse.in = false; draw(); });
    v.addEventListener('wheel', onWheel, { passive: false });
    v.addEventListener('contextmenu', (e) => e.preventDefault());
    v.addEventListener('dblclick', () => { if (st.tool === 'crop' && st.crop) cropApply(); else if (st.xf) applyTransform(); });
    // Menüleiste
    st.el.bar.addEventListener('click', (e) => {
      const b = e.target.closest('[data-menu]');
      if (!b) return;
      if (st.menu?.btn === b) return closeMenu();
      openMenu(b, MENUS[+b.dataset.menu][1]);
    });
    st.el.bar.addEventListener('pointerover', (e) => {
      const b = e.target.closest('[data-menu]');
      if (b && st.menu && st.menu.btn !== b && st.menu.btn?.dataset.menu) openMenu(b, MENUS[+b.dataset.menu][1]);
    });
    st.el.pop.addEventListener('click', (e) => {
      const it = e.target.closest('[data-mi]');
      if (!it || it.classList.contains('off')) return;
      const fn = st.menu?.items[+it.dataset.mi]?.[2];
      closeMenu();
      fn?.();
    });
    root.addEventListener('pointerdown', (e) => { if (st.menu && !e.target.closest('.ph-pop, .ph-mb, [data-pop]')) closeMenu(); }, true);
    // Werkzeuge
    st.el.tools.addEventListener('click', (e) => {
      const b = e.target.closest('[data-tool]');
      if (b) return setTool(b.dataset.tool);
      const a = e.target.closest('[data-ta]')?.dataset.ta;
      if (a === 'swap') swapColors();
      else if (a === 'reset') { st.fg = '#000000'; st.bg = '#ffffff'; renderColorChips(); renderColorPanel(); }
      else if (a === 'fg' || a === 'bg') colorDialog(a);
    });
    // Optionen
    st.el.opts.addEventListener('input', onOptInput);
    st.el.opts.addEventListener('change', onOptInput);
    st.el.opts.addEventListener('click', onOptClick);
    // Ebenen, Protokoll, Farbe, Korrekturen
    bindLayerPanel();
    st.el.hist.addEventListener('click', (e) => {
      const r = e.target.closest('[data-h]');
      if (r) jumpHistory(+r.dataset.h);
      if (e.target.closest('[data-pn-toggle]')) { st.el.hist.classList.toggle('min'); }
    });
    st.el.adj.addEventListener('click', (e) => {
      const t = e.target.closest('[data-tab]');
      if (t) { st.adjTab = t.dataset.tab; renderAdjPanel(); return; }
      const a = e.target.closest('[data-addadj]');
      if (a) addAdjLayer(a.dataset.addadj);
    });
    st.el.color.addEventListener('click', (e) => {
      const t = e.target.closest('[data-tab]');
      if (t) { st.colorTab = t.dataset.tab; renderColorPanel(); return; }
      const sw = e.target.closest('[data-sw]');
      if (sw) { if (e.ctrlKey || e.altKey) st.bg = sw.dataset.sw; else st.fg = sw.dataset.sw; renderColorChips(); renderColorPanel(); if (st.tool === 'text') textOptsToLayer(); return; }
      const ct = e.target.closest('[data-ct]');
      if (ct) { st.colorTarget = ct.dataset.ct; renderColorPanel(); }
    });
    // Dateien hineinziehen
    st.el.ph.addEventListener('dragover', (e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { e.preventDefault(); st.el.stage.classList.add('drop'); } });
    st.el.ph.addEventListener('dragleave', (e) => { if (!st.el.ph.contains(e.relatedTarget)) st.el.stage.classList.remove('drop'); });
    st.el.ph.addEventListener('drop', (e) => {
      if (!e.dataTransfer?.files?.length) return;
      e.preventDefault();
      st.el.stage.classList.remove('drop');
      const onStage = !!e.target.closest('.ph-stage') && !!D();
      openFiles([...e.dataTransfer.files], onStage);
    });
    st.el.home.addEventListener('click', (e) => {
      const a = e.target.closest('[data-home]')?.dataset.home;
      if (a === 'new') newDialog();
      else if (a === 'open') openDialog();
      else if (a === 'paste') paste();
      else if (a?.startsWith('preset:')) { const [w, h] = a.slice(7).split('x').map(Number); addDoc(makeDoc({ name: `Unbenannt-${st.docs.length + 1}`, w, h, dpi: 72, fill: '#ffffff' }), 'Neu'); }
    });
    st.el.tabs.addEventListener('pointerdown', (e) => {
      const x = e.target.closest('[data-close]');
      if (x) { e.stopPropagation(); closeDoc(st.docs.find((d) => d.id === x.dataset.close)); return; }
      const t = e.target.closest('[data-doc]');
      if (!t) return;
      const doc = st.docs.find((d) => d.id === t.dataset.doc);
      if (e.button === 1) { e.preventDefault(); closeDoc(doc); } else if (doc && doc !== D()) switchDoc(doc);
    });
    st.el.status.addEventListener('change', (e) => {
      if (e.target.matches('[data-zoom]')) { const z = parseFloat(String(e.target.value).replace(',', '.')); if (z > 0) zoomAt(z / 100); }
    });
    st.ro = new ResizeObserver(() => { draw(); if (st.textEdit) st.textEdit.place(); });
    st.ro.observe(st.el.stage);
    renderTools();
    refresh();
    updateCursor();
    if (D() && !D().fitted) { D().fitted = true; requestAnimationFrame(() => fit()); }
  }
  function togglePanels() {
    st.el.ph?.classList.toggle('nopanels');
    setTimeout(draw, 30);
  }
  function refresh() {
    if (!st.root || !st.el.ph) return;
    renderTabs();
    renderLayers();
    renderHistory();
    renderAdjPanel();
    renderOptions();
    renderStatus();
    renderHome();
    renderColorChips();
    if (!st.el.color.firstChild) renderColorPanel(); else panelPicker?.redraw();
    requestComp();
  }

  /* ---------- Menüs ---------- */
  function openMenu(btn, items, x, y) {
    closeMenu();
    const pop = st.el.pop;
    pop.innerHTML = items.map((it, i) => {
      if (it === '-') return '<div class="ph-sep"></div>';
      if (it[0].startsWith('#')) return `<div class="ph-mh">${esc(it[0].slice(1))}</div>`;
      const off = it[3] && !it[3]();
      return `<div class="ph-mi${off ? ' off' : ''}" data-mi="${i}"><span>${esc(it[0])}</span><kbd>${it[1] ? keyLabel(it[1]) : ''}</kbd></div>`;
    }).join('');
    pop.hidden = false;
    const r = (btn || st.el.ph).getBoundingClientRect(), pr = st.el.ph.getBoundingClientRect();
    const left = x != null ? x - pr.left : r.left - pr.left, top = y != null ? y - pr.top : r.bottom - pr.top;
    pop.style.left = `${Math.max(0, Math.min(left, pr.width - pop.offsetWidth - 4))}px`;
    pop.style.top = `${Math.max(0, Math.min(top, pr.height - pop.offsetHeight - 4))}px`;
    st.menu = { btn, items };
    btn?.classList.add('on');
  }
  function closeMenu() {
    if (!st.menu) return;
    st.menu.btn?.classList.remove('on');
    st.menu = null;
    if (st.el.pop) st.el.pop.hidden = true;
  }

  /* ---------- Werkzeugleiste ---------- */
  function renderTools() {
    st.el.tools.innerHTML = `${TOOLS.map((t) => (t === '-' ? '<i class="ph-tsep"></i>' : `<button class="ph-tool${st.tool === t[0] ? ' on' : ''}" data-tool="${t[0]}" title="${esc(t[1])} (${t[2]})">${svg(t[0], 17)}</button>`)).join('')}
      <i class="ph-tsep"></i>
      <div class="ph-chips"><button class="ph-chip bg" data-ta="bg" title="Hintergrundfarbe festlegen"></button><button class="ph-chip fg" data-ta="fg" title="Vordergrundfarbe festlegen"></button>
      <button class="ph-mini sw" data-ta="swap" title="Farben tauschen (X)">${svg('swap', 11)}</button><button class="ph-mini rs" data-ta="reset" title="Standardfarben (D)"><i></i><i></i></button></div>`;
    renderColorChips();
  }
  function renderColorChips() {
    const fg = st.el.tools?.querySelector('.ph-chip.fg'), bg = st.el.tools?.querySelector('.ph-chip.bg');
    if (fg) fg.style.background = st.fg;
    if (bg) bg.style.background = st.bg;
    st.el.color?.querySelectorAll('[data-ct]').forEach((b) => { b.style.background = b.dataset.ct === 'fg' ? st.fg : st.bg; });
  }
  function setTool(t, keep = false) {
    if (st.textEdit) commitText();
    if (st.xf && !keep && t !== 'move') applyTransform();
    if (st.crop && t !== 'crop') st.crop = null;
    st.tool = t;
    if (t === 'crop') cropInit();
    st.el.tools?.querySelectorAll('[data-tool]').forEach((b) => b.classList.toggle('on', b.dataset.tool === t));
    renderOptions();
    updateCursor();
    draw();
  }
  function swapColors() {
    [st.fg, st.bg] = [st.bg, st.fg];
    renderColorChips();
    renderColorPanel();
  }

  /* ---------- Optionsleiste ---------- */
  const oChk = (k, label) => `<label class="ph-o"><input type="checkbox" data-o="${k}" ${st.opt[k] ? 'checked' : ''}>${label}</label>`;
  const oNum = (k, label, min, max, unit = '', step = 1) => `<label class="ph-o">${label}<input class="ph-num" type="number" data-o="${k}" value="${st.opt[k]}" min="${min}" max="${max}" step="${step}">${unit ? `<em>${unit}</em>` : ''}</label>`;
  const oSl = (k, label, min, max, unit = '') => `<label class="ph-o">${label}<input class="ph-num" type="number" data-o="${k}" value="${st.opt[k]}" min="${min}" max="${max}"><em>${unit}</em><input type="range" class="ph-rng" data-o="${k}" value="${st.opt[k]}" min="${min}" max="${max}"></label>`;
  const oSel = (k, label, opts) => `<label class="ph-o">${label}<select class="ph-sel" data-o="${k}">${opts.map(([v, n]) => `<option value="${v}" ${String(st.opt[k]) === String(v) ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>`;
  const oSep = '<i class="ph-osep"></i>';
  const selModes = () => `<span class="ph-seg">${[['new', 'Neue Auswahl'], ['add', 'Der Auswahl hinzufügen (Umschalt)'], ['sub', 'Von Auswahl subtrahieren (Alt)'], ['int', 'Schnittmenge mit Auswahl bilden']].map(([m, t]) => `<button class="${st.opt.selMode === m ? 'on' : ''}" data-oa="selmode:${m}" title="${t}">${svg(`sel_${m}`, 14)}</button>`).join('')}</span>`;
  function renderOptions(soft = false) {
    const el = st.el.opts;
    if (!el) return;
    if (soft && el.contains(document.activeElement) && document.activeElement !== document.body) return;
    const t = st.tool, o = st.opt;
    let h = `<span class="ph-otool" title="${esc(TOOL_NAME[t] || '')}">${svg(t, 18)}</span>${oSep}`;
    if (st.xf) {
      const xf = st.xf;
      h += `<span class="ph-oinfo">Frei transformieren:</span><span class="ph-oinfo">B: <b>${fmt(Math.abs(xf.sx) * 100, 1)} %</b></span><span class="ph-oinfo">H: <b>${fmt(Math.abs(xf.sy) * 100, 1)} %</b></span><span class="ph-oinfo">Winkel: <b>${fmt((xf.rot * 180) / Math.PI, 1)}°</b></span>${oSep}
        <button class="ph-btn sm" data-oa="xf-flip-h">Horizontal spiegeln</button><button class="ph-btn sm" data-oa="xf-flip-v">Vertikal spiegeln</button><span class="ph-grow"></span>
        <span class="ph-oinfo dim">Ecken ziehen = skalieren (Umschalt = frei), aussen ziehen = drehen</span>
        <button class="ph-ibtn" data-oa="xf-cancel" title="Abbrechen (Esc)">${svg('close', 16)}</button><button class="ph-ibtn ok" data-oa="xf-apply" title="Bestätigen (Enter)">${svg('check', 16)}</button>`;
      el.innerHTML = h;
      return;
    }
    if (t === 'move') h += `${oChk('autoSelect', 'Automatisch auswählen')}${oSep}<button class="ph-btn sm" data-oa="transform">Transformieren (Strg+T)</button>${oSep}<span class="ph-oinfo dim">Pfeiltasten verschieben 1 px (Umschalt 10 px) · Alt+Ziehen dupliziert die Auswahl</span>`;
    else if (t === 'marquee' || t === 'ellipse' || t === 'lasso') h += `${selModes()}${oSep}${oNum('feather', 'Weiche Kante:', 0, 250, 'Px')}${oSep}<span class="ph-oinfo dim">Umschalt = hinzufügen/Quadrat · Alt = subtrahieren/aus der Mitte</span>`;
    else if (t === 'wand') h += `${selModes()}${oSep}${oNum('tolerance', 'Toleranz:', 0, 255)}${oChk('antialias', 'Glätten')}${oChk('contiguous', 'Benachbart')}${oChk('sampleAll', 'Alle Ebenen aufnehmen')}`;
    else if (t === 'crop') {
      const c = st.crop;
      h += `${oSel('cropRatio', 'Verhältnis:', [['free', 'Frei'], ['orig', 'Original'], ['1:1', '1:1 (Quadrat)'], ['4:3', '4:3'], ['3:2', '3:2'], ['16:9', '16:9'], ['9:16', '9:16'], ['4:5', '4:5']])}${oSep}${c ? `<span class="ph-oinfo">${c.w} × ${c.h} Px</span>` : ''}<span class="ph-grow"></span><button class="ph-ibtn" data-oa="crop-cancel" title="Abbrechen (Esc)">${svg('close', 16)}</button><button class="ph-ibtn ok" data-oa="crop-apply" title="Freistellen (Enter)">${svg('check', 16)}</button>`;
    } else if (t === 'eyedropper') h += `${oSel('sample', 'Aufnahmebereich:', [[1, '1 Pixel'], [3, '3 × 3 Durchschnitt'], [5, '5 × 5 Durchschnitt'], [11, '11 × 11 Durchschnitt']])}${oChk('sampleAll', 'Alle Ebenen')}<span class="ph-oinfo dim">Alt+Klick = Hintergrundfarbe</span>`;
    else if (t === 'brush' || t === 'eraser' || t === 'clone') {
      h += `${oSl('size', 'Grösse:', 1, 500, 'Px')}${oSl('hardness', 'Härte:', 0, 100, '%')}${oSep}${oSl('opacity', 'Deckkr.:', 1, 100, '%')}${oSl('flow', 'Fluss:', 1, 100, '%')}${oChk('pressure', 'Stiftdruck')}`;
      if (t === 'clone') h += `${oSep}${oChk('cloneAligned', 'Ausger.')}${oChk('sampleAll', 'Alle Ebenen')}<span class="ph-oinfo dim">Alt+Klick = Quelle</span>`;
    } else if (t === 'bucket') h += `${oSl('opacity', 'Deckkr.:', 1, 100, '%')}${oNum('tolerance', 'Toleranz:', 0, 255)}${oChk('antialias', 'Glätten')}${oChk('contiguous', 'Benachbart')}${oChk('sampleAll', 'Alle Ebenen')}`;
    else if (t === 'gradient') h += `<span class="ph-gprev" style="background:linear-gradient(90deg,${st.fg},${o.gradMode === 'fgbg' ? st.bg : rgba(st.fg, 0)})"></span>${oSel('gradMode', '', [['fgbg', 'Vordergrund → Hintergrund'], ['fgtr', 'Vordergrund → Transparent']])}${oSel('gradType', '', [['linear', 'Linear'], ['radial', 'Radial']])}${oSep}${oSl('opacity', 'Deckkr.:', 1, 100, '%')}${oChk('gradReverse', 'Umkehren')}`;
    else if (t === 'text') {
      h += `${oSel('font', '', FONTS.map((f) => [f, f]))}<span class="ph-seg"><button class="${o.bold ? 'on' : ''}" data-oa="bold" title="Fett"><b>F</b></button><button class="${o.italic ? 'on' : ''}" data-oa="italic" title="Kursiv"><i>K</i></button></span>${oNum('fontSize', '', 1, 2000, 'Pt')}${oSep}<span class="ph-seg">${['left', 'center', 'right'].map((a) => `<button class="${o.align === a ? 'on' : ''}" data-oa="align:${a}" title="${{ left: 'Text links ausrichten', center: 'Text zentrieren', right: 'Text rechts ausrichten' }[a]}">${svg('textlayer', 1).replace('width="1"', 'width="0"')}<span class="ph-al ${a}"><i></i><i></i><i></i></span></button>`).join('')}</span><button class="ph-chip inline" data-oa="textcolor" title="Textfarbe" style="background:${st.fg}"></button>`;
      if (st.textEdit) h += `<span class="ph-grow"></span><button class="ph-ibtn" data-oa="text-cancel" title="Abbrechen (Esc)">${svg('close', 16)}</button><button class="ph-ibtn ok" data-oa="text-ok" title="Bestätigen (Strg+Enter)">${svg('check', 16)}</button>`;
    } else if (t === 'shape') h += `${oSel('shape', 'Form:', [['rect', 'Rechteck'], ['round', 'Abgerundetes Rechteck'], ['ellipse', 'Ellipse'], ['line', 'Linie']])}${oChk('shapeFill', 'Fläche (VG-Farbe)')}${oNum('shapeStroke', 'Kontur:', 0, 200, 'Px')}<label class="ph-o"><input type="color" class="ph-col" data-o="shapeStrokeColor" value="${o.shapeStrokeColor}"></label>${o.shape === 'round' ? oNum('radius', 'Radius:', 0, 1000, 'Px') : ''}<span class="ph-oinfo dim">Umschalt = Quadrat/Kreis</span>`;
    else if (t === 'hand' || t === 'zoom') {
      if (t === 'zoom') h += `<span class="ph-seg"><button class="${!o.zoomOut ? 'on' : ''}" data-oa="zoomin" title="Einzoomen">${svg('zoom', 14)}</button><button class="${o.zoomOut ? 'on' : ''}" data-oa="zoomout" title="Auszoomen (Alt)">${svg('zoomout', 14)}</button></span>${oSep}`;
      h += `<button class="ph-btn sm" data-oa="z100">100 %</button><button class="ph-btn sm" data-oa="zfit">Ganzes Bild</button>`;
    }
    el.innerHTML = h;
  }
  function onOptInput(e) {
    const k = e.target.dataset.o;
    if (!k) return;
    const t = e.target;
    let v = t.type === 'checkbox' ? t.checked : t.type === 'number' || t.type === 'range' ? Number(t.value) : t.value;
    if (typeof st.opt[k] === 'number' && typeof v === 'string') v = Number(v);
    if (typeof v === 'number' && !Number.isFinite(v)) return;
    if (t.type === 'number' && e.type === 'change') { v = clamp(v, Number(t.min), Number(t.max)); t.value = v; }
    st.opt[k] = v;
    st.el.opts.querySelectorAll(`[data-o="${k}"]`).forEach((x) => { if (x !== t && x.type !== 'checkbox') x.value = v; });
    if (k === 'shape' || k === 'gradMode') renderOptions();
    if (st.tool === 'text' && e.type === 'change') textOptsToLayer();
    else if (st.textEdit) st.textEdit.place();
    if (k === 'cropRatio' && st.crop) { const r = cropRatio(); if (r) { st.crop.h = Math.round(st.crop.w / r); draw(); } }
    draw();
  }
  function onOptClick(e) {
    const a = e.target.closest('[data-oa]')?.dataset.oa;
    if (!a) return;
    const o = st.opt;
    if (a.startsWith('selmode:')) o.selMode = a.slice(8);
    else if (a === 'bold' || a === 'italic') { o[a] = !o[a]; textOptsToLayer(); } else if (a.startsWith('align:')) { o.align = a.slice(6); textOptsToLayer(); } else if (a === 'textcolor') return colorDialog('fg');
    else if (a === 'text-ok') return commitText();
    else if (a === 'text-cancel') return cancelText();
    else if (a === 'transform') return startTransform();
    else if (a === 'xf-apply') return applyTransform();
    else if (a === 'xf-cancel') return cancelTransform();
    else if (a === 'xf-flip-h') { st.xf.sx *= -1; xfPreview(); } else if (a === 'xf-flip-v') { st.xf.sy *= -1; xfPreview(); } else if (a === 'crop-apply') return cropApply();
    else if (a === 'crop-cancel') return cropCancel();
    else if (a === 'zoomin' || a === 'zoomout') { o.zoomOut = a === 'zoomout'; updateCursor(); } else if (a === 'z100') zoomAt(1);
    else if (a === 'zfit') fit();
    renderOptions();
  }

  /* ---------- Register & Status ---------- */
  function renderTabs() {
    const el = st.el.tabs;
    if (!el) return;
    el.innerHTML = st.docs.map((d) => `<div class="ph-tab${d === D() ? ' on' : ''}" data-doc="${d.id}" title="${esc(d.name)}"><span>${esc(d.name)} @ ${fmt(d.zoom * 100, 1)}%${d.dirty ? '*' : ''}</span><button data-close="${d.id}" title="Schliessen">${svg('close', 11)}</button></div>`).join('');
  }
  function renderHome() {
    const el = st.el.home;
    if (!el) return;
    el.hidden = !!D();
    st.el.view.hidden = !D();
    if (D()) return;
    const pre = [['1920x1080', 'Full HD', '1920 × 1080 Px'], ['3840x2160', '4K UHD', '3840 × 2160 Px'], ['1080x1080', 'Quadrat', '1080 × 1080 Px'], ['1080x1920', 'Story', '1080 × 1920 Px'], ['2480x3508', 'A4', '2480 × 3508 Px · 300 ppi'], ['800x600', 'Web', '800 × 600 Px']];
    el.innerHTML = `<div class="ph-home-in">
      <div class="ph-home-h"><span class="ph-home-logo">${svg('pixel', 30)}</span><div><b>Revolution Foto</b><small>Bilder bearbeiten mit Ebenen, Masken, Korrekturen und Filtern</small></div></div>
      <div class="ph-home-btns"><button class="ph-btn pri" data-home="new">${svg('newdoc', 15)} Neue Datei</button><button class="ph-btn" data-home="open">${svg('open', 15)} Öffnen …</button><button class="ph-btn" data-home="paste">${svg('paste', 15)} Aus Zwischenablage</button></div>
      <div class="ph-home-sub">Schnell anlegen</div>
      <div class="ph-home-grid">${pre.map(([k, n, s]) => { const [w, h] = k.split('x').map(Number), r = Math.min(54 / w, 40 / h); return `<button class="ph-preset" data-home="preset:${k}"><i style="width:${Math.round(w * r)}px;height:${Math.round(h * r)}px"></i><b>${n}</b><small>${s}</small></button>`; }).join('')}</div>
      <div class="ph-home-drop">Bilder oder .rvfoto-Projekte hierher ziehen</div></div>`;
  }
  function renderStatus(p) {
    const el = st.el.status, doc = D();
    if (!el) return;
    if (!doc) { el.innerHTML = ''; return; }
    const mb = (doc.w * doc.h * 3) / 1048576, mbl = (doc.w * doc.h * 4 * doc.layers.length) / 1048576;
    let pos = '';
    if (p && p.x >= 0 && p.y >= 0 && p.x < doc.w && p.y < doc.h && doc.comp && !st.drag) {
      const d = g2(doc.comp).getImageData(Math.floor(p.x), Math.floor(p.y), 1, 1).data;
      pos = `<span>X: ${Math.floor(p.x)} Y: ${Math.floor(p.y)}</span><span class="ph-sw" style="background:rgba(${d[0]},${d[1]},${d[2]},${d[3] / 255})"></span><span>R ${d[0]} G ${d[1]} B ${d[2]}${d[3] < 255 ? ` A ${Math.round((d[3] / 255) * 100)} %` : ''}</span>`;
    }
    const zi = el.querySelector('[data-zoom]');
    if (zi && document.activeElement === zi) return;
    el.innerHTML = `<input class="ph-zoom" data-zoom value="${fmt(doc.zoom * 100, 2)} %" title="Zoomstufe"><span>Dok: ${fmt(mb, 2)} MB/${fmt(mbl, 2)} MB</span><span>${doc.w} × ${doc.h} Px (${doc.dpi} ppi)</span>${pos}`;
  }

  /* ---------- Ebenen ---------- */
  function renderLayers() {
    const el = st.el.layers, doc = D();
    if (!el) return;
    const l = active(doc);
    const head = `<header class="ph-ph"><span class="ph-pt on">Ebenen</span></header>`;
    if (!doc) { el.innerHTML = `${head}<div class="ph-empty">Kein Dokument geöffnet.</div>`; return; }
    const blendSel = `<select class="ph-sel" data-lc="blend" ${l.kind === 'adj' ? '' : ''}>${BLENDS.map((b) => (b === '-' ? '<option disabled>──────────</option>' : `<option value="${b[0]}" ${l.blend === b[0] ? 'selected' : ''}>${b[1]}</option>`)).join('')}</select>`;
    el.innerHTML = `${head}
      <div class="ph-lctl">${blendSel}<label class="ph-o">Deckkraft:<input class="ph-num" type="number" data-lc="opacity" min="0" max="100" value="${Math.round(l.opacity * 100)}"><em>%</em></label></div>
      <div class="ph-lctl sm"><span class="dim">Art:</span><span class="dim">${l.kind === 'adj' ? 'Einstellungsebene' : l.kind === 'text' ? 'Textebene' : 'Pixelebene'}${l.mask ? (l.editMask ? ' · Maske wird bearbeitet' : ' · mit Maske') : ''}</span></div>
      <div class="ph-llist">${[...doc.layers].reverse().map((x) => `
        <div class="ph-layer${x.id === doc.active ? ' on' : ''}${x.visible ? '' : ' hid'}" data-l="${x.id}" draggable="true">
          <button class="ph-eye" data-la="eye" title="Sichtbarkeit (Alt+Klick = nur diese)">${x.visible ? svg('eye', 14) : ''}</button>
          ${x.kind === 'adj' ? `<span class="ph-lthumb adj${!x.editMask && x.id === doc.active ? ' edit' : ''}" data-la="thumb" title="${esc(ADJ[x.adj.type]?.name || '')}">${svg(ADJ[x.adj.type]?.icon || 'adjust', 16)}</span>` : `<canvas class="ph-lthumb${!x.editMask && x.id === doc.active ? ' edit' : ''}" data-la="thumb" data-th="${x.id}" title="Strg+Klick = Transparenz als Auswahl laden"></canvas>`}
          ${x.mask ? `<span class="ph-chain">${svg('chain', 10)}</span><canvas class="ph-lthumb mask${x.editMask && x.id === doc.active ? ' edit' : ''}${x.maskOn ? '' : ' off'}" data-la="mthumb" data-mth="${x.id}" title="Maske bearbeiten · Umschalt+Klick = deaktivieren"></canvas>` : ''}
          <span class="ph-lname" data-la="name">${x.kind === 'text' ? `<i class="ph-tbadge">T</i>` : ''}${esc(x.name)}</span>
        </div>`).join('')}</div>
      <footer class="ph-lfoot">
        <button class="ph-ibtn" data-lf="mask" title="Ebenenmaske hinzufügen">${svg('mask', 15)}</button>
        <button class="ph-ibtn" data-lf="adj" data-pop title="Neue Einstellungsebene erstellen">${svg('adjust', 15)}</button>
        <button class="ph-ibtn" data-lf="new" title="Neue Ebene erstellen (Umschalt+Strg+N)">${svg('plus', 15)}</button>
        <button class="ph-ibtn" data-lf="del" title="Ebene löschen">${svg('trash', 15)}</button>
      </footer>`;
    for (const c of el.querySelectorAll('canvas[data-th]')) drawThumb(c, doc.layers.find((x) => x.id === c.dataset.th)?.canvas, false);
    for (const c of el.querySelectorAll('canvas[data-mth]')) drawThumb(c, doc.layers.find((x) => x.id === c.dataset.mth)?.mask, true);
  }
  function drawThumb(c, src, mask) {
    if (!src) return;
    const doc = D(), dpr = window.devicePixelRatio || 1, W = 40, H = 28;
    c.width = W * dpr; c.height = H * dpr;
    const g = g2(c), k = Math.min(W / doc.w, H / doc.h), w = doc.w * k, h = doc.h * k, x = (W - w) / 2, y = (H - h) / 2;
    g.scale(dpr, dpr);
    if (mask) { g.fillStyle = '#000'; g.fillRect(x, y, w, h); } else { g.fillStyle = checker(g); g.fillRect(x, y, w, h); }
    g.imageSmoothingQuality = 'high';
    if (mask) {
      const t = tmp(10, Math.max(1, Math.round(w * dpr)), Math.max(1, Math.round(h * dpr))), tg = g2(t);
      tg.fillStyle = '#fff'; tg.fillRect(0, 0, t.width, t.height);
      tg.globalCompositeOperation = 'destination-in';
      tg.drawImage(src, 0, 0, t.width, t.height);
      g.drawImage(t, x, y, w, h);
    } else g.drawImage(src, x, y, w, h);
  }
  function bindLayerPanel() {
    const el = st.el.layers;
    el.addEventListener('click', (e) => {
      const doc = D();
      if (!doc) return;
      const f = e.target.closest('[data-lf]')?.dataset.lf;
      if (f === 'mask') return addMask(true);
      if (f === 'new') return addLayer();
      if (f === 'del') return deleteLayer();
      if (f === 'adj') { const b = e.target.closest('[data-lf]'), r = b.getBoundingClientRect(); return openMenu(null, ADJ_LAYER_TYPES.map((t) => [`${ADJ[t].name} …`, '', () => addAdjLayer(t)]), r.left, r.top - ADJ_LAYER_TYPES.length * 24 - 10); }
      const row = e.target.closest('[data-l]');
      if (!row) return;
      const l = doc.layers.find((x) => x.id === row.dataset.l);
      const a = e.target.closest('[data-la]')?.dataset.la;
      if (a === 'eye') {
        if (e.altKey) { const solo = doc.layers.every((x) => x === l || !x.visible); doc.layers.forEach((x) => { x.visible = solo ? true : x === l; }); } else l.visible = !l.visible;
        requestComp();
        return commit('Ebenensichtbarkeit');
      }
      if (st.textEdit) commitText();
      if (a === 'thumb' && (e.ctrlKey || e.metaKey)) return loadTransparency(l);
      if (a === 'mthumb' && e.shiftKey) { doc.active = l.id; return maskCmd('toggle'); }
      doc.active = l.id;
      l.editMask = a === 'mthumb';
      if (a !== 'mthumb') l.editMask = false;
      if (l.kind === 'adj' && a !== 'mthumb') st.adjTab = 'props';
      renderLayers();
      renderAdjPanel();
      renderOptions();
    });
    el.addEventListener('dblclick', (e) => {
      const row = e.target.closest('[data-l]');
      if (!row) return;
      const a = e.target.closest('[data-la]')?.dataset.la;
      if (a === 'name') renameInline(row);
      else if (a === 'thumb') { const l = D().layers.find((x) => x.id === row.dataset.l); if (l?.kind === 'adj') { st.adjTab = 'props'; renderAdjPanel(); } else if (l?.kind === 'text') { setTool('text'); textClick({ x: l.text.box.x + 1, y: l.text.box.y + 1 }); } }
    });
    el.addEventListener('input', (e) => {
      const l = active(), k = e.target.dataset.lc;
      if (!l || !k) return;
      if (k === 'opacity') l.opacity = clamp(Number(e.target.value) || 0, 0, 100) / 100;
      if (k === 'blend') l.blend = e.target.value;
      requestComp();
    });
    el.addEventListener('change', (e) => {
      const k = e.target.dataset.lc;
      if (k) commit(k === 'opacity' ? 'Deckkraft' : 'Füllmethode');
    });
    let dragId = null;
    el.addEventListener('dragstart', (e) => { const row = e.target.closest('[data-l]'); if (!row) return; dragId = row.dataset.l; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', dragId); });
    el.addEventListener('dragover', (e) => {
      if (!dragId) return;
      const row = e.target.closest('[data-l]');
      el.querySelectorAll('.drop-a,.drop-b').forEach((x) => x.classList.remove('drop-a', 'drop-b'));
      if (!row) return;
      e.preventDefault();
      const r = row.getBoundingClientRect();
      row.classList.add(e.clientY < r.top + r.height / 2 ? 'drop-a' : 'drop-b');
    });
    el.addEventListener('drop', (e) => {
      if (!dragId) return;
      e.preventDefault();
      e.stopPropagation();
      const row = e.target.closest('[data-l]'), doc = D();
      if (!row || row.dataset.l === dragId) { dragId = null; return renderLayers(); }
      const r = row.getBoundingClientRect(), above = e.clientY < r.top + r.height / 2;
      const l = doc.layers.find((x) => x.id === dragId);
      doc.layers.splice(doc.layers.indexOf(l), 1);
      let j = doc.layers.findIndex((x) => x.id === row.dataset.l);
      if (above) j += 1;
      doc.layers.splice(j, 0, l);
      dragId = null;
      requestComp();
      commit('Ebenenreihenfolge');
    });
    el.addEventListener('dragend', () => { dragId = null; el.querySelectorAll('.drop-a,.drop-b').forEach((x) => x.classList.remove('drop-a', 'drop-b')); });
  }
  function renameInline(row) {
    const l = D().layers.find((x) => x.id === row.dataset.l), nm = row.querySelector('.ph-lname');
    if (!l || !nm) return;
    nm.innerHTML = `<input class="ph-rename" value="${esc(l.name)}">`;
    const inp = nm.firstChild;
    inp.focus();
    inp.select();
    const done = (ok) => {
      if (ok && inp.value.trim() && inp.value.trim() !== l.name) { l.name = inp.value.trim(); commit('Ebene umbenennen'); } else renderLayers();
    };
    inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); });
    inp.addEventListener('blur', () => done(true), { once: true });
  }
  function renameActive() {
    const row = st.el.layers.querySelector('.ph-layer.on');
    if (row) renameInline(row);
  }
  function loadTransparency(l) {
    const doc = D();
    if (!l?.canvas) return;
    setSel(copyC(l.canvas), 'Transparenz laden');
  }
  function trim() {
    const doc = D(), b = contentBox(flatCanvas(doc));
    if (!b) return toast('Das Bild ist leer.', 'error');
    st.crop = b;
    cropApply();
    st.crop = null;
  }

  /* ---------- Protokoll ---------- */
  function renderHistory() {
    const el = st.el.hist, doc = D();
    if (!el) return;
    const min = el.classList.contains('min');
    el.innerHTML = `<header class="ph-ph"><span class="ph-pt on">Protokoll</span><span class="ph-grow"></span><button class="ph-ibtn xs" data-pn-toggle title="Ein-/Ausklappen">${min ? '▸' : '▾'}</button></header>
      <div class="ph-hlist">${doc ? doc.hist.map((h, i) => `<div class="ph-hrow${i === doc.hi ? ' on' : ''}${i > doc.hi ? ' fut' : ''}" data-h="${i}">${svg(i === 0 ? 'pixel' : 'brush', 13)}<span>${esc(h.label)}</span></div>`).join('') : ''}</div>`;
    const cur = el.querySelector('.ph-hrow.on');
    cur?.scrollIntoView({ block: 'nearest' });
  }

  /* ---------- Farbe ---------- */
  function pickerHtml() {
    return `<div class="ph-picker"><canvas class="ph-sv"></canvas><canvas class="ph-hue"></canvas></div>
      <div class="ph-crow"><label>R<input class="ph-num" data-c="r" type="number" min="0" max="255"></label><label>G<input class="ph-num" data-c="g" type="number" min="0" max="255"></label><label>B<input class="ph-num" data-c="b" type="number" min="0" max="255"></label><label>#<input class="ph-hex" data-c="hex" maxlength="7"></label></div>`;
  }
  /** Farbwähler (Sättigung/Helligkeit-Feld + Farbton-Streifen) an Element binden. */
  function bindPicker(root, get, set) {
    const sv = root.querySelector('.ph-sv'), hue = root.querySelector('.ph-hue');
    const state = { h: 0, s: 0, v: 0 };
    const fromHex = () => { const [r, g, b] = hex2rgb(get()); const [h, s, v] = rgb2hsv(r, g, b); if (s > 0 && v > 0) state.h = h; else if (!state.h) state.h = st.hue; state.s = s; state.v = v; };
    const drawP = () => {
      const dpr = window.devicePixelRatio || 1;
      for (const c of [sv, hue]) { const w = c.clientWidth || 180, h = c.clientHeight || 110; if (c.width !== w * dpr) { c.width = w * dpr; c.height = h * dpr; } }
      const g = g2(sv), W = sv.width, H = sv.height;
      g.fillStyle = rgb2hex(...hsv2rgb(state.h, 1, 1));
      g.fillRect(0, 0, W, H);
      let gr = g.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, '#fff'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
      gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, '#000');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
      const mx = state.s * W, my = (1 - state.v) * H;
      g.lineWidth = 1.5 * dpr;
      g.strokeStyle = state.v > 0.5 && state.s < 0.5 ? '#000' : '#fff';
      g.beginPath(); g.arc(mx, my, 5 * dpr, 0, Math.PI * 2); g.stroke();
      const hg = g2(hue), HW = hue.width, HH = hue.height;
      gr = hg.createLinearGradient(0, 0, 0, HH);
      for (let i = 0; i <= 6; i++) gr.addColorStop(i / 6, rgb2hex(...hsv2rgb(360 - i * 60, 1, 1)));
      hg.fillStyle = gr; hg.fillRect(0, 0, HW, HH);
      const hy = (1 - state.h / 360) * HH;
      hg.fillStyle = '#fff'; hg.fillRect(0, hy - 1.5 * dpr, HW, 3 * dpr);
      hg.strokeStyle = '#000'; hg.lineWidth = dpr; hg.strokeRect(0, hy - 2 * dpr, HW, 4 * dpr);
      const [r, gg, b] = hex2rgb(get());
      for (const inp of root.querySelectorAll('[data-c]')) {
        if (document.activeElement === inp) continue;
        inp.value = { r, g: gg, b, hex: get().replace('#', '') }[inp.dataset.c];
      }
    };
    const apply = () => { st.hue = state.h; set(rgb2hex(...hsv2rgb(state.h, state.s, state.v))); drawP(); };
    const drag = (c, fn) => c.addEventListener('pointerdown', (e) => {
      try { c.setPointerCapture(e.pointerId); } catch { /* egal */ }
      const mv = (ev) => { const r = c.getBoundingClientRect(); fn(clamp((ev.clientX - r.left) / r.width, 0, 1), clamp((ev.clientY - r.top) / r.height, 0, 1)); apply(); };
      mv(e);
      c.onpointermove = mv;
      c.onpointerup = () => { c.onpointermove = null; c.onpointerup = null; root.dispatchEvent(new Event('pickdone')); };
    });
    drag(sv, (x, y) => { state.s = x; state.v = 1 - y; });
    drag(hue, (x, y) => { state.h = (1 - y) * 360; if (state.h >= 360) state.h = 359.9; });
    root.addEventListener('input', (e) => {
      const k = e.target.dataset.c;
      if (!k) return;
      if (k === 'hex') { const v = e.target.value.replace('#', ''); if (/^[0-9a-f]{6}$/i.test(v) || /^[0-9a-f]{3}$/i.test(v)) { set(rgb2hex(...hex2rgb(v))); fromHex(); drawP(); } return; }
      const vals = ['r', 'g', 'b'].map((c) => clamp(Number(root.querySelector(`[data-c="${c}"]`).value) || 0, 0, 255));
      set(rgb2hex(...vals));
      fromHex();
      drawP();
    });
    fromHex();
    requestAnimationFrame(drawP);
    return { redraw: () => { fromHex(); drawP(); } };
  }
  let panelPicker = null;
  function renderColorPanel() {
    const el = st.el.color;
    if (!el) return;
    const tabs = `<header class="ph-ph"><span class="ph-pt${st.colorTab === 'color' ? ' on' : ''}" data-tab="color">Farbe</span><span class="ph-pt${st.colorTab === 'swatch' ? ' on' : ''}" data-tab="swatch">Farbfelder</span></header>`;
    if (st.colorTab === 'swatch') {
      panelPicker = null;
      el.innerHTML = `${tabs}<div class="ph-swatches">${SWATCHES.map((c) => `<button data-sw="${c}" style="background:${c}" title="${c} · Klick = Vordergrund, Strg+Klick = Hintergrund"></button>`).join('')}</div>`;
      return;
    }
    if (panelPicker && el.querySelector('.ph-picker')) { panelPicker.redraw(); renderColorChips(); el.querySelectorAll('[data-ct]').forEach((b) => b.classList.toggle('on', b.dataset.ct === st.colorTarget)); return; }
    el.innerHTML = `${tabs}<div class="ph-cpanel"><div class="ph-cchips"><button class="ph-chip big${st.colorTarget === 'bg' ? ' on' : ''}" data-ct="bg" title="Hintergrundfarbe bearbeiten"></button><button class="ph-chip big fgc${st.colorTarget === 'fg' ? ' on' : ''}" data-ct="fg" title="Vordergrundfarbe bearbeiten"></button></div><div class="ph-cpick">${pickerHtml()}</div></div>`;
    panelPicker = bindPicker(el.querySelector('.ph-cpick'), () => (st.colorTarget === 'bg' ? st.bg : st.fg), (hex) => { if (st.colorTarget === 'bg') st.bg = hex; else st.fg = hex; renderColorChips(); if (st.textEdit) st.textEdit.place(); });
    el.querySelector('.ph-cpick').addEventListener('pickdone', () => { if (st.tool === 'text') textOptsToLayer(); if (st.tool === 'gradient') renderOptions(); });
    renderColorChips();
  }
  function colorDialog(which) {
    const old = which === 'bg' ? st.bg : st.fg;
    let cur = old;
    const dlg = openDlg({
      title: `Farbwähler (${which === 'bg' ? 'Hintergrundfarbe' : 'Vordergrundfarbe'})`, width: 420,
      body: `<div class="ph-cdlg"><div class="ph-cpick big">${pickerHtml()}</div><div class="ph-cprev"><span>neu</span><i class="nw" style="background:${old}"></i><i class="od" style="background:${old}"></i><span>aktuell</span></div></div>`,
      onOk: () => { if (which === 'bg') st.bg = cur; else st.fg = cur; renderColorChips(); renderColorPanel(); if (st.tool === 'text') textOptsToLayer(); renderOptions(); },
    });
    const nw = dlg.el.querySelector('.nw');
    bindPicker(dlg.el.querySelector('.ph-cpick'), () => cur, (h) => { cur = h; nw.style.background = h; });
  }

  /* ---------- Korrekturen & Eigenschaften ---------- */
  function renderAdjPanel() {
    const el = st.el.adj, doc = D();
    if (!el) return;
    const l = active(doc);
    const tabs = `<header class="ph-ph"><span class="ph-pt${st.adjTab === 'adjust' ? ' on' : ''}" data-tab="adjust">Korrekturen</span><span class="ph-pt${st.adjTab === 'props' ? ' on' : ''}" data-tab="props">Eigenschaften</span></header>`;
    if (st.adjTab === 'adjust') {
      el.innerHTML = `${tabs}<div class="ph-adjhint">Einstellungsebene hinzufügen</div><div class="ph-adjgrid">${ADJ_LAYER_TYPES.map((t) => `<button class="ph-ibtn" data-addadj="${t}" title="${esc(ADJ[t].name)}" ${doc ? '' : 'disabled'}>${svg(ADJ[t].icon, 17)}</button>`).join('')}</div>`;
      return;
    }
    if (!doc || !l) { el.innerHTML = `${tabs}<div class="ph-empty">Keine Eigenschaften.</div>`; return; }
    if (l.kind === 'adj') {
      el.innerHTML = `${tabs}<div class="ph-props"><div class="ph-proph">${svg(ADJ[l.adj.type].icon, 15)}<b>${esc(ADJ[l.adj.type].name)}</b></div><div class="ph-adjbody"></div><div class="ph-row"><button class="ph-btn sm" data-pa="reset">Zurücksetzen</button></div></div>`;
      const body = el.querySelector('.ph-adjbody');
      const src = mk(doc.w, doc.h);
      composite(doc, { upto: l, into: src });
      st.needComp = true;
      let tm = 0;
      buildAdjControls(body, l.adj, src, () => { requestComp(); }, () => { clearTimeout(tm); tm = setTimeout(() => commit('Eigenschaften ändern'), 250); });
      el.querySelector('[data-pa="reset"]').onclick = () => { l.adj.p = ADJ[l.adj.type].def(); requestComp(); commit('Eigenschaften zurücksetzen'); };
      return;
    }
    const kind = l.kind === 'text' ? 'Textebene' : 'Pixelebene';
    el.innerHTML = `${tabs}<div class="ph-props"><div class="ph-proph">${svg(l.kind === 'text' ? 'textlayer' : 'pixel', 15)}<b>${kind}</b></div>
      <div class="ph-kv"><span>Dokument</span><b>${doc.w} × ${doc.h} Px</b><span>Auflösung</span><b>${doc.dpi} ppi</b><span>Ebene</span><b>${esc(l.name)}</b>${l.kind === 'text' ? `<span>Schrift</span><b>${esc(l.text.font)}, ${Math.round(l.text.size)} Pt</b>` : ''}${l.mask ? `<span>Maske</span><b>${l.maskOn ? 'aktiv' : 'deaktiviert'}</b>` : ''}</div>
      <div class="ph-row">${l.mask ? '' : '<button class="ph-btn sm" data-pa="mask">Maske hinzufügen</button>'}<button class="ph-btn sm" data-pa="xf">Transformieren</button>${l.kind === 'text' ? '<button class="ph-btn sm" data-pa="raster">Rastern</button>' : ''}</div></div>`;
    el.querySelector('[data-pa="mask"]')?.addEventListener('click', () => addMask(true));
    el.querySelector('[data-pa="xf"]')?.addEventListener('click', () => startTransform());
    el.querySelector('[data-pa="raster"]')?.addEventListener('click', () => rasterize(l));
  }
  const sl = (k, label, v, min, max, step = 1, unit = '') => `<div class="ph-sl"><div class="ph-slh"><label>${label}</label><input class="ph-num" type="number" data-k="${k}" value="${v}" min="${min}" max="${max}" step="${step}"><em>${unit}</em></div><input type="range" class="ph-rng" data-k="${k}" value="${v}" min="${min}" max="${max}" step="${step}"></div>`;
  /** Regler für eine Korrektur/einen Filter. onInput = Live-Vorschau, onDone = fertig (Protokoll). */
  function buildAdjControls(el, adj, src, onInput, onDone = () => {}) {
    const p = adj.p, t = adj.type;
    let html = '';
    let after = null;
    if (t === 'bc') html = sl('b', 'Helligkeit', p.b, -150, 150) + sl('c', 'Kontrast', p.c, -50, 100);
    else if (t === 'hsl') html = sl('h', 'Farbton', p.h, -180, 180) + sl('s', 'Sättigung', p.s, -100, 100) + sl('l', 'Helligkeit', p.l, -100, 100) + `<label class="ph-chk"><input type="checkbox" data-k="colorize" ${p.colorize ? 'checked' : ''}> Färben</label>`;
    else if (t === 'balance') {
      const tone = p.tone;
      html = `<div class="ph-seg wide">${[['sh', 'Tiefen'], ['mid', 'Mitteltöne'], ['hi', 'Lichter']].map(([k, n]) => `<button class="${tone === k ? 'on' : ''}" data-tone="${k}">${n}</button>`).join('')}</div>
        ${[['Cyan', 'Rot'], ['Magenta', 'Grün'], ['Gelb', 'Blau']].map(([a, b], i) => `<div class="ph-sl"><div class="ph-slh"><label>${a}</label><input class="ph-num" type="number" data-bal="${i}" value="${p[tone][i]}" min="-100" max="100"><label class="r">${b}</label></div><input type="range" class="ph-rng bal${i}" data-bal="${i}" value="${p[tone][i]}" min="-100" max="100"></div>`).join('')}
        <label class="ph-chk"><input type="checkbox" data-k="keep" ${p.keep ? 'checked' : ''}> Luminanz erhalten</label>`;
    } else if (t === 'bw') html = [['r', 'Rottöne'], ['y', 'Gelbtöne'], ['g', 'Grüntöne'], ['c', 'Cyantöne'], ['b', 'Blautöne'], ['m', 'Magentatöne']].map(([k, n]) => sl(k, n, p[k], -200, 300, 1, '%')).join('') + `<div class="ph-row"><label class="ph-chk"><input type="checkbox" data-k="tint" ${p.tint ? 'checked' : ''}> Farbton</label><input type="color" class="ph-col" data-k="tc" value="${p.tc}"></div>`;
    else if (t === 'invert') html = '<div class="ph-empty sm">Keine Einstellungen – kehrt alle Farben um.</div>';
    else if (t === 'levels') {
      html = `<canvas class="ph-histo"></canvas><div class="ph-lvl"><input type="range" class="ph-rng" data-k="ib" min="0" max="253" value="${p.ib}"><input type="range" class="ph-rng" data-k="iw" min="2" max="255" value="${p.iw}"></div>
        <div class="ph-row3"><input class="ph-num" type="number" data-k="ib" min="0" max="253" value="${p.ib}" title="Tiefen"><input class="ph-num" type="number" data-k="ig" min="0.1" max="9.99" step="0.01" value="${p.ig}" title="Mitteltöne (Gamma)"><input class="ph-num" type="number" data-k="iw" min="2" max="255" value="${p.iw}" title="Lichter"></div>
        <input type="range" class="ph-rng" data-k="ig" min="0.1" max="3" step="0.01" value="${p.ig}" title="Gamma">
        <div class="ph-sub">Tonwertumfang</div><div class="ph-lvl out"><input type="range" class="ph-rng" data-k="ob" min="0" max="255" value="${p.ob}"><input type="range" class="ph-rng" data-k="ow" min="0" max="255" value="${p.ow}"></div>
        <div class="ph-row3"><input class="ph-num" type="number" data-k="ob" min="0" max="255" value="${p.ob}"><span></span><input class="ph-num" type="number" data-k="ow" min="0" max="255" value="${p.ow}"></div>
        <div class="ph-row"><button class="ph-btn sm" data-auto>Auto</button></div>`;
      after = () => {
        const hc = el.querySelector('.ph-histo'), hist = histogram(src).lum;
        drawHisto(hc, hist);
        el.querySelector('[data-auto]').onclick = () => {
          const total = hist.reduce((a, b) => a + b, 0), cut = total * 0.001;
          let lo = 0, hi = 255, acc = 0;
          while (lo < 254 && (acc += hist[lo]) <= cut) lo++;
          acc = 0;
          while (hi > lo + 1 && (acc += hist[hi]) <= cut) hi--;
          Object.assign(p, { ib: lo, iw: hi, ig: 1 });
          sync();
          onInput();
          onDone();
        };
      };
    } else if (t === 'curves') {
      html = `<div class="ph-row"><label class="ph-o">Kanal:<select class="ph-sel" data-curvech>${[['rgb', 'RGB'], ['r', 'Rot'], ['g', 'Grün'], ['b', 'Blau']].map(([k, n]) => `<option value="${k}" ${p.ch === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label><button class="ph-btn sm" data-curvereset>Kurve zurücksetzen</button></div>
        <canvas class="ph-curve"></canvas><div class="ph-cinfo dim">Klicken = Punkt setzen · Punkt aus dem Feld ziehen = löschen</div>`;
      after = () => curveEditor(el.querySelector('.ph-curve'), p, src, () => { onInput(); }, onDone, el);
    } else if (t === 'blur') html = sl('r', 'Radius', p.r, 0.1, 250, 0.1, 'Pixel');
    else if (t === 'motion') html = sl('a', 'Winkel', p.a, -90, 90, 1, '°') + sl('dist', 'Distanz', p.dist, 1, 300, 1, 'Pixel');
    else if (t === 'sharpen') html = sl('amount', 'Stärke', p.amount, 1, 500, 1, '%') + sl('r', 'Radius', p.r, 0.1, 64, 0.1, 'Pixel') + sl('th', 'Schwellenwert', p.th, 0, 255, 1, 'Stufen');
    else if (t === 'noise') html = sl('amount', 'Stärke', p.amount, 0.1, 100, 0.1, '%') + `<div class="ph-row"><label class="ph-chk"><input type="radio" name="phnd" data-k="gauss" data-v="false" ${!p.gauss ? 'checked' : ''}> Gleichmässig</label><label class="ph-chk"><input type="radio" name="phnd" data-k="gauss" data-v="true" ${p.gauss ? 'checked' : ''}> Gausssche Normalverteilung</label></div><label class="ph-chk"><input type="checkbox" data-k="mono" ${p.mono ? 'checked' : ''}> Monochromatisch</label>`;
    else if (t === 'median') html = sl('r', 'Radius', p.r, 1, 3, 1, 'Pixel');
    else if (t === 'mosaic') html = sl('s', 'Zellengrösse', p.s, 2, 200, 1, 'Quadrat');
    el.innerHTML = html;
    function sync() {
      for (const inp of el.querySelectorAll('[data-k]')) {
        if (inp.type === 'checkbox') inp.checked = !!p[inp.dataset.k];
        else if (inp.type === 'radio') inp.checked = String(p[inp.dataset.k]) === inp.dataset.v;
        else if (document.activeElement !== inp) inp.value = p[inp.dataset.k];
      }
      if (t === 'balance') for (const inp of el.querySelectorAll('[data-bal]')) if (document.activeElement !== inp) inp.value = p[p.tone][+inp.dataset.bal];
    }
    el.addEventListener('input', (e) => {
      const x = e.target, k = x.dataset.k;
      if (x.dataset.bal != null) { p[p.tone][+x.dataset.bal] = clamp(Number(x.value) || 0, -100, 100); sync(); onInput(); return; }
      if (!k) return;
      if (x.type === 'checkbox') p[k] = x.checked;
      else if (x.type === 'radio') p[k] = x.dataset.v === 'true';
      else if (x.type === 'color') p[k] = x.value;
      else { const v = Number(x.value); if (!Number.isFinite(v)) return; p[k] = v; }
      if (t === 'levels') { if (p.iw <= p.ib + 1) { if (k === 'ib') p.iw = Math.min(255, p.ib + 2); else p.ib = Math.max(0, p.iw - 2); } }
      sync();
      onInput();
    });
    el.addEventListener('change', (e) => { if (e.target.closest('[data-k],[data-bal]')) onDone(); });
    el.addEventListener('click', (e) => {
      const tone = e.target.closest('[data-tone]')?.dataset.tone;
      if (tone) { p.tone = tone; el.querySelectorAll('[data-tone]').forEach((b) => b.classList.toggle('on', b.dataset.tone === tone)); sync(); }
    });
    after?.();
  }
  function drawHisto(c, hist, color = '#bbb') {
    const dpr = window.devicePixelRatio || 1, W = c.clientWidth || 240, H = c.clientHeight || 80;
    c.width = W * dpr; c.height = H * dpr;
    const g = g2(c);
    g.scale(dpr, dpr);
    g.fillStyle = '#1b1b1b';
    g.fillRect(0, 0, W, H);
    const sorted = [...hist].sort((a, b) => a - b), mx = Math.max(1, sorted[Math.floor(sorted.length * 0.985)]);
    g.fillStyle = color;
    for (let i = 0; i < 256; i++) { const h = Math.min(H, (hist[i] / mx) * H); g.fillRect((i / 256) * W, H - h, W / 256 + 0.5, h); }
  }
  function curveEditor(c, p, src, onInput, onDone, host) {
    const hist = histogram(src);
    const W = 240;
    const dpr = window.devicePixelRatio || 1;
    c.style.width = `${W}px`; c.style.height = `${W}px`;
    c.width = W * dpr; c.height = W * dpr;
    const g = g2(c);
    const toPx = (v) => (v / 255) * W, fromPx = (x) => clamp(Math.round((x / W) * 255), 0, 255);
    const col = { rgb: '#ddd', r: '#ff5a5a', g: '#5ad65a', b: '#5a8cff' };
    function render() {
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.fillStyle = '#1b1b1b'; g.fillRect(0, 0, W, W);
      const h = p.ch === 'rgb' ? hist.lum : hist[p.ch];
      const sorted = [...h].sort((a, b) => a - b), mx = Math.max(1, sorted[Math.floor(sorted.length * 0.985)]);
      g.fillStyle = 'rgba(255,255,255,.12)';
      for (let i = 0; i < 256; i++) { const hh = Math.min(W, (h[i] / mx) * W * 0.9); g.fillRect(toPx(i), W - hh, W / 256 + 0.5, hh); }
      g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1;
      g.beginPath();
      for (let i = 1; i < 4; i++) { g.moveTo((W * i) / 4, 0); g.lineTo((W * i) / 4, W); g.moveTo(0, (W * i) / 4); g.lineTo(W, (W * i) / 4); }
      g.moveTo(0, W); g.lineTo(W, 0);
      g.stroke();
      const lut = curveLut(p[p.ch]);
      g.strokeStyle = col[p.ch]; g.lineWidth = 1.6;
      g.beginPath();
      for (let i = 0; i < 256; i++) { const x = toPx(i), y = W - toPx(lut[i]); if (i) g.lineTo(x, y); else g.moveTo(x, y); }
      g.stroke();
      for (const [x, y] of p[p.ch]) { g.fillStyle = '#fff'; g.fillRect(toPx(x) - 3.5, W - toPx(y) - 3.5, 7, 7); g.strokeStyle = '#000'; g.strokeRect(toPx(x) - 3.5, W - toPx(y) - 3.5, 7, 7); }
    }
    c.addEventListener('pointerdown', (e) => {
      const r = c.getBoundingClientRect(), pts = p[p.ch];
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      let idx = pts.findIndex(([x, y]) => Math.hypot(toPx(x) - mx, W - toPx(y) - my) < 9);
      if (idx < 0) {
        const x = fromPx(mx), y = fromPx(W - my);
        pts.push([x, y]);
        pts.sort((a, b) => a[0] - b[0]);
        idx = pts.findIndex((q) => q[0] === x && q[1] === y);
      }
      const pt = pts[idx];
      try { c.setPointerCapture(e.pointerId); } catch { /* egal */ }
      c.onpointermove = (ev) => {
        const ex = ev.clientX - r.left, ey = ev.clientY - r.top;
        const i = pts.indexOf(pt);
        const out = (ey < -24 || ey > W + 24 || ex < -24 || ex > W + 24) && pts.length > 2;
        if (out) { if (i >= 0) pts.splice(i, 1); } else {
          if (i < 0) { pts.push(pt); pts.sort((a, b) => a[0] - b[0]); }
          const j = pts.indexOf(pt), lo = j > 0 ? pts[j - 1][0] + 1 : 0, hi = j < pts.length - 1 ? pts[j + 1][0] - 1 : 255;
          pt[0] = clamp(fromPx(ex), lo, hi);
          pt[1] = fromPx(W - ey);
        }
        render();
        onInput();
      };
      c.onpointerup = () => { c.onpointermove = null; c.onpointerup = null; onDone(); };
      render();
      onInput();
    });
    host.querySelector('[data-curvech]').addEventListener('change', (e) => { p.ch = e.target.value; render(); });
    host.querySelector('[data-curvereset]').addEventListener('click', () => { p[p.ch] = DEF_CURVE(); render(); onInput(); onDone(); });
    render();
  }

  /* ---------- Dialoge ---------- */
  function openDlg({ title, body, width = 380, ok = 'OK', cancel = 'Abbrechen', onOk, onCancel, preview = null, extra = '' }) {
    closeDlg(false, true);
    closeMenu();
    const wrap = st.el.dlgs;
    wrap.hidden = false;
    wrap.innerHTML = `<div class="ph-dlg" style="width:${width}px"><header class="ph-dlgh"><b>${esc(title)}</b><button class="ph-x" data-dlg="cancel" title="Schliessen">${svg('close', 13)}</button></header>
      <div class="ph-dlgb">${body}</div>
      <footer class="ph-dlgf">${preview ? `<label class="ph-chk"><input type="checkbox" data-dlg-prev checked> Vorschau</label>` : ''}${extra}<span class="ph-grow"></span>${ok ? `<button class="ph-btn pri" data-dlg="ok">${esc(ok)}</button>` : ''}${cancel ? `<button class="ph-btn" data-dlg="cancel">${esc(cancel)}</button>` : ''}</footer></div>`;
    const el = wrap.firstElementChild;
    const dlg = { el, onOk, onCancel, preview };
    st.dlg = dlg;
    el.addEventListener('click', (e) => {
      const a = e.target.closest('[data-dlg]')?.dataset.dlg;
      if (a === 'ok') closeDlg(true);
      else if (a === 'cancel') closeDlg(false);
    });
    el.querySelector('[data-dlg-prev]')?.addEventListener('change', (e) => preview?.(e.target.checked));
    const hd = el.querySelector('.ph-dlgh');
    hd.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      const r = el.getBoundingClientRect(), pr = wrap.getBoundingClientRect(), ox = e.clientX - r.left, oy = e.clientY - r.top;
      try { hd.setPointerCapture(e.pointerId); } catch { /* egal */ }
      hd.onpointermove = (ev) => { el.style.position = 'absolute'; el.style.margin = '0'; el.style.left = `${clamp(ev.clientX - pr.left - ox, 0, pr.width - 60)}px`; el.style.top = `${clamp(ev.clientY - pr.top - oy, 0, pr.height - 30)}px`; };
      hd.onpointerup = () => { hd.onpointermove = null; };
    });
    setTimeout(() => el.querySelector('input:not([type=checkbox]):not([type=range]), select, .ph-btn.pri')?.focus(), 0);
    return dlg;
  }
  function closeDlg(ok, silent = false) {
    const d = st.dlg;
    if (!d) return;
    st.dlg = null;
    if (!silent) {
      try { if (ok) d.onOk?.(); else d.onCancel?.(); } catch (e) { console.error(e); toast(A.errText(e), 'error'); }
    }
    if (st.dlg) return; // onOk hat einen neuen Dialog geöffnet
    st.el.dlgs.hidden = true;
    st.el.dlgs.innerHTML = '';
    draw();
  }
  function ask(title, text, buttons) {
    return new Promise((res) => {
      const dlg = openDlg({ title, body: `<p class="ph-ask">${esc(text)}</p>`, ok: '', cancel: '', width: 420, extra: buttons.map(([k, n, pri]) => `<button class="ph-btn${pri ? ' pri' : ''}" data-ask="${k}">${esc(n)}</button>`).join(''), onCancel: () => res('cancel') });
      dlg.el.querySelector('.ph-dlgf .ph-grow')?.remove();
      dlg.el.querySelector('.ph-dlgf').style.justifyContent = 'flex-end';
      dlg.el.addEventListener('click', (e) => { const k = e.target.closest('[data-ask]')?.dataset.ask; if (k) { dlg.onCancel = null; closeDlg(false); res(k); } });
    });
  }
  function numDialog(title, label, def, unit, fn) {
    const dlg = openDlg({ title, width: 300, body: `<label class="ph-f"><span>${esc(label)}:</span><input class="ph-num w" type="number" value="${def}" min="0" max="500" step="0.1"><em>${esc(unit)}</em></label>`, onOk: () => fn(Number(dlg.el.querySelector('input').value) || 0) });
  }
  /** Korrektur/Filter als Dialog mit Live-Vorschau (destruktiv auf die aktive Ebene). */
  function adjDialog(type) {
    const doc = D(), l = active(doc);
    if (!l) return;
    if (l.kind === 'adj' && !l.editMask) return toast('Bitte eine Pixelebene wählen (oder die Korrektur als Einstellungsebene anlegen).', 'error');
    if (l.kind === 'text') { rasterize(l, false); toast('Textebene wurde gerastert.'); }
    const def = ADJ[type], adj = { type, p: def.def() };
    const target = l.editMask && l.mask ? l.mask : l.canvas;
    const live = !(l.editMask && l.mask);
    let on = true, tm = 0;
    const show = () => {
      if (!live) return;
      clearTimeout(tm);
      tm = setTimeout(() => { l.preview = on ? adj : null; requestComp(); }, def.filter && type !== 'desat' ? 120 : 0);
    };
    const dlg = openDlg({
      title: def.name, width: type === 'curves' ? 300 : type === 'levels' ? 300 : 340, body: '<div class="ph-adjbody"></div>', preview: live ? (v) => { on = v; show(); } : null,
      onOk: () => { clearTimeout(tm); l.preview = null; applyFilter(adj, def.name); },
      onCancel: () => { clearTimeout(tm); l.preview = null; requestComp(); },
    });
    buildAdjControls(dlg.el.querySelector('.ph-adjbody'), adj, target, show);
    show();
  }
  function newDialog() {
    const pre = [['Eigene', 0, 0, 72], ['Standard (1920 × 1080)', 1920, 1080, 72], ['4K UHD (3840 × 2160)', 3840, 2160, 72], ['Quadrat (1080 × 1080)', 1080, 1080, 72], ['Story (1080 × 1920)', 1080, 1920, 72], ['A4 (300 ppi)', 2480, 3508, 300], ['A5 (300 ppi)', 1748, 2480, 300], ['Web (800 × 600)', 800, 600, 72], ['Symbol (512 × 512)', 512, 512, 72]];
    const n = st.docs.length + 1;
    const dlg = openDlg({
      title: 'Neu', width: 460, ok: 'Erstellen',
      body: `<div class="ph-form">
        <label class="ph-f"><span>Name:</span><input class="ph-txt w" data-n="name" value="Unbenannt-${n}"></label>
        <label class="ph-f"><span>Vorgabe:</span><select class="ph-sel w" data-n="pre">${pre.map((p, i) => `<option value="${i}" ${i === 1 ? 'selected' : ''}>${p[0]}</option>`).join('')}</select></label>
        <label class="ph-f"><span>Breite:</span><input class="ph-num w" type="number" data-n="w" value="1920" min="1" max="16000"><em>Pixel</em></label>
        <label class="ph-f"><span>Höhe:</span><input class="ph-num w" type="number" data-n="h" value="1080" min="1" max="16000"><em>Pixel</em></label>
        <label class="ph-f"><span>Auflösung:</span><input class="ph-num w" type="number" data-n="dpi" value="72" min="1" max="2400"><em>Pixel/Zoll</em></label>
        <label class="ph-f"><span>Hintergrundinhalt:</span><select class="ph-sel w" data-n="bg"><option value="#ffffff">Weiss</option><option value="#000000">Schwarz</option><option value="bgc">Hintergrundfarbe</option><option value="">Transparent</option></select></label>
        <div class="ph-f"><span></span><small class="dim" data-n="info"></small></div></div>`,
      onOk: () => {
        const v = (k) => dlg.el.querySelector(`[data-n="${k}"]`).value;
        const w = clamp(Math.round(Number(v('w'))), 1, 16000), h = clamp(Math.round(Number(v('h'))), 1, 16000);
        const bg = v('bg') === 'bgc' ? st.bg : v('bg') || null;
        addDoc(makeDoc({ name: v('name') || `Unbenannt-${n}`, w, h, dpi: Number(v('dpi')) || 72, fill: bg }), 'Neu');
      },
    });
    const info = () => { const w = +dlg.el.querySelector('[data-n="w"]').value, h = +dlg.el.querySelector('[data-n="h"]').value; dlg.el.querySelector('[data-n="info"]').textContent = `Bildgrösse: ${fmt((w * h * 3) / 1048576, 2)} MB`; };
    dlg.el.addEventListener('input', (e) => {
      if (e.target.dataset.n === 'pre') { const p = pre[+e.target.value]; if (p[1]) { dlg.el.querySelector('[data-n="w"]').value = p[1]; dlg.el.querySelector('[data-n="h"]').value = p[2]; dlg.el.querySelector('[data-n="dpi"]').value = p[3]; } } else if (/^(w|h|dpi)$/.test(e.target.dataset.n)) dlg.el.querySelector('[data-n="pre"]').value = '0';
      info();
    });
    info();
  }
  const UNITS = [['px', 'Pixel'], ['pct', 'Prozent'], ['cm', 'Zentimeter'], ['mm', 'Millimeter'], ['in', 'Zoll']];
  function imageSizeDialog() {
    const doc = D();
    const s = { w: doc.w, h: doc.h, dpi: doc.dpi, link: true, resample: true, method: 'auto', uw: 'px', uh: 'px' };
    const toU = (px, u, base) => (u === 'px' ? px : u === 'pct' ? (px / base) * 100 : u === 'in' ? px / s.dpi : u === 'cm' ? (px / s.dpi) * 2.54 : (px / s.dpi) * 25.4);
    const fromU = (v, u, base) => (u === 'px' ? v : u === 'pct' ? (v / 100) * base : u === 'in' ? v * s.dpi : u === 'cm' ? (v / 2.54) * s.dpi : (v / 25.4) * s.dpi);
    const unitSel = (k) => `<select class="ph-sel" data-is="${k}">${UNITS.map(([u, n]) => `<option value="${u}">${n}</option>`).join('')}</select>`;
    const fits = [['orig', 'Originalgrösse'], ['640x480', '640 × 480 Px'], ['800x600', '800 × 600 Px'], ['1024x768', '1024 × 768 Px'], ['1280x720', '1280 × 720 Px (HD)'], ['1920x1080', '1920 × 1080 Px (Full HD)'], ['2560x1440', '2560 × 1440 Px (QHD)'], ['3840x2160', '3840 × 2160 Px (4K)']];
    const dlg = openDlg({
      title: 'Bildgrösse', width: 640,
      body: `<div class="ph-isz"><canvas class="ph-isz-prev"></canvas><div class="ph-form">
        <div class="ph-f"><span>Bildgrösse:</span><b data-is="mb"></b></div>
        <div class="ph-f"><span>Masse:</span><b data-is="dims"></b></div>
        <label class="ph-f"><span>Einpassen:</span><select class="ph-sel w" data-is="fit">${fits.map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
        <div class="ph-linkgrp"><button class="ph-link on" data-is="link" title="Proportionen beibehalten">${svg('link', 14)}</button><div>
          <label class="ph-f"><span>Breite:</span><input class="ph-num w" type="number" data-is="w" step="any">${unitSel('uw')}</label>
          <label class="ph-f"><span>Höhe:</span><input class="ph-num w" type="number" data-is="h" step="any">${unitSel('uh')}</label></div></div>
        <label class="ph-f"><span>Auflösung:</span><input class="ph-num w" type="number" data-is="dpi" step="any" min="1"><em>Pixel/Zoll</em></label>
        <label class="ph-f"><span><input type="checkbox" data-is="resample" checked> Neu berechnen:</span><select class="ph-sel w" data-is="method"><option value="auto">Automatisch</option><option value="hq">Bikubisch (glatter)</option><option value="bilinear">Bilinear</option><option value="nearest">Pixelwiederholung (harte Kanten)</option></select></label>
      </div></div>`,
      onOk: () => {
        const nw = Math.round(s.w), nh = Math.round(s.h);
        if (nw < 1 || nh < 1 || nw > 20000 || nh > 20000) { toast('Ungültige Grösse (1 bis 20000 Pixel).', 'error'); return; }
        if (nw === doc.w && nh === doc.h) { if (s.dpi !== doc.dpi) { doc.dpi = Math.round(s.dpi * 100) / 100; commit('Bildgrösse'); } return; }
        resizeImage(nw, nh, Math.round(s.dpi * 100) / 100, s.method === 'hq' ? 'auto' : s.method);
      },
    });
    const el = dlg.el, $ = (k) => el.querySelector(`[data-is="${k}"]`);
    const prev = $('mb').closest('.ph-isz').querySelector('.ph-isz-prev');
    prev.width = 180; prev.height = 140;
    const pg = g2(prev), k = Math.min(180 / doc.w, 140 / doc.h);
    pg.fillStyle = checker(pg); pg.fillRect(0, 0, 180, 140);
    pg.drawImage(flatCanvas(doc), (180 - doc.w * k) / 2, (140 - doc.h * k) / 2, doc.w * k, doc.h * k);
    const round = (v) => Math.round(v * 100) / 100;
    function upd() {
      const mb0 = (doc.w * doc.h * 3) / 1048576, mb = (Math.round(s.w) * Math.round(s.h) * 3) / 1048576;
      $('mb').innerHTML = `${fmt(mb, 2)} MB${Math.abs(mb - mb0) > 0.001 ? ` <span class="dim">(vorher: ${fmt(mb0, 2)} MB)</span>` : ''}`;
      $('dims').textContent = `${Math.round(s.w)} Px × ${Math.round(s.h)} Px`;
      if (document.activeElement !== $('w')) $('w').value = s.uw === 'px' ? Math.round(s.w) : round(toU(s.w, s.uw, doc.w));
      if (document.activeElement !== $('h')) $('h').value = s.uh === 'px' ? Math.round(s.h) : round(toU(s.h, s.uh, doc.h));
      if (document.activeElement !== $('dpi')) $('dpi').value = round(s.dpi);
      $('link').classList.toggle('on', s.link);
      $('method').disabled = !s.resample;
      const physOnly = !s.resample;
      for (const u of ['uw', 'uh']) for (const o of $(u).options) o.disabled = physOnly && (o.value === 'px' || o.value === 'pct');
    }
    el.addEventListener('input', (e) => {
      const kk = e.target.dataset.is;
      const ratio = doc.w / doc.h;
      if (kk === 'w' || kk === 'h') {
        const v = Number(e.target.value);
        if (!(v > 0)) return;
        if (!s.resample) {
          // Ohne Neuberechnung: Pixel bleiben, die Auflösung ändert sich
          const inch = fromU(v, s[kk === 'w' ? 'uw' : 'uh'], 1) / s.dpi;
          s.dpi = (kk === 'w' ? doc.w : doc.h) / inch;
        } else {
          s[kk] = fromU(v, s[kk === 'w' ? 'uw' : 'uh'], kk === 'w' ? doc.w : doc.h);
          if (s.link) { if (kk === 'w') s.h = s.w / ratio; else s.w = s.h * ratio; }
        }
        $('fit').value = 'orig';
      } else if (kk === 'dpi') {
        const v = Number(e.target.value);
        if (!(v > 0)) return;
        if (s.resample) {
          // Masse in cm/Zoll bleiben → Pixel ändern sich
          const kx = v / s.dpi;
          if (s.uw !== 'px' && s.uw !== 'pct') s.w *= kx;
          if (s.uh !== 'px' && s.uh !== 'pct') s.h *= kx;
        }
        s.dpi = v;
      } else if (kk === 'resample') {
        s.resample = e.target.checked;
        if (!s.resample) { s.w = doc.w; s.h = doc.h; s.link = true; if (s.uw === 'px' || s.uw === 'pct') s.uw = 'cm'; if (s.uh === 'px' || s.uh === 'pct') s.uh = 'cm'; $('uw').value = s.uw; $('uh').value = s.uh; }
      } else if (kk === 'method') s.method = e.target.value;
      else if (kk === 'uw' || kk === 'uh') s[kk] = e.target.value;
      else if (kk === 'fit') {
        const v = e.target.value;
        if (v === 'orig') { s.w = doc.w; s.h = doc.h; s.dpi = doc.dpi; } else {
          const [fw, fh] = v.split('x').map(Number), kf = Math.min(fw / doc.w, fh / doc.h);
          s.resample = true; $('resample').checked = true;
          s.w = doc.w * kf; s.h = doc.h * kf;
        }
      }
      upd();
    });
    el.addEventListener('click', (e) => { if (e.target.closest('[data-is="link"]')) { if (s.resample) { s.link = !s.link; if (s.link) s.h = s.w / (doc.w / doc.h); } upd(); } });
    upd();
  }
  function canvasSizeDialog() {
    const doc = D();
    const s = { w: doc.w, h: doc.h, rel: false, ax: 1, ay: 1, u: 'px', fill: 'bg' };
    const dlg = openDlg({
      title: 'Arbeitsfläche', width: 400,
      body: `<div class="ph-form"><div class="ph-f"><span>Aktuelle Grösse:</span><b>${doc.w} × ${doc.h} Px</b></div>
        <label class="ph-f"><span>Breite:</span><input class="ph-num w" type="number" data-cs="w" step="any"><select class="ph-sel" data-cs="u"><option value="px">Pixel</option><option value="pct">Prozent</option></select></label>
        <label class="ph-f"><span>Höhe:</span><input class="ph-num w" type="number" data-cs="h" step="any"></label>
        <label class="ph-f"><span></span><span><input type="checkbox" data-cs="rel"> Relativ</span></label>
        <div class="ph-f"><span>Anker:</span><div class="ph-anchor">${[0, 1, 2].flatMap((y) => [0, 1, 2].map((x) => `<button data-anc="${x},${y}"></button>`)).join('')}</div></div>
        <label class="ph-f"><span>Erweiterungsfarbe:</span><select class="ph-sel w" data-cs="fill"><option value="bg">Hintergrundfarbe</option><option value="#ffffff">Weiss</option><option value="#000000">Schwarz</option><option value="#808080">Grau</option><option value="">Transparent</option></select></label>
        <div class="ph-f"><span>Neue Grösse:</span><b data-cs="new"></b></div></div>`,
      onOk: () => {
        const nw = Math.round(s.w), nh = Math.round(s.h);
        if (nw < 1 || nh < 1 || nw > 20000 || nh > 20000) { toast('Ungültige Grösse.', 'error'); return; }
        if (nw === doc.w && nh === doc.h) return;
        const ox = Math.round(((nw - doc.w) * s.ax) / 2), oy = Math.round(((nh - doc.h) * s.ay) / 2);
        resizeCanvasTo(nw, nh, ox, oy, s.fill === 'bg' ? st.bg : s.fill || null);
        commit('Arbeitsfläche');
        fit();
      },
    });
    const el = dlg.el, $ = (k) => el.querySelector(`[data-cs="${k}"]`);
    const shown = (px, base) => (s.u === 'pct' ? ((s.rel ? px - base : px) / base) * 100 : s.rel ? px - base : px);
    function upd() {
      if (document.activeElement !== $('w')) $('w').value = Math.round(shown(s.w, doc.w) * 100) / 100;
      if (document.activeElement !== $('h')) $('h').value = Math.round(shown(s.h, doc.h) * 100) / 100;
      $('new').textContent = `${Math.round(s.w)} × ${Math.round(s.h)} Px`;
      el.querySelectorAll('[data-anc]').forEach((b) => b.classList.toggle('on', b.dataset.anc === `${s.ax},${s.ay}`));
    }
    el.addEventListener('input', (e) => {
      const k = e.target.dataset.cs;
      if (k === 'w' || k === 'h') {
        const v = Number(e.target.value), base = k === 'w' ? doc.w : doc.h;
        if (!Number.isFinite(v)) return;
        let px = s.u === 'pct' ? (v / 100) * base : v;
        if (s.rel) px += base;
        s[k] = px;
      } else if (k === 'rel') s.rel = e.target.checked;
      else if (k === 'u') s.u = e.target.value;
      else if (k === 'fill') s.fill = e.target.value;
      upd();
    });
    el.addEventListener('click', (e) => { const a = e.target.closest('[data-anc]'); if (a) { [s.ax, s.ay] = a.dataset.anc.split(',').map(Number); upd(); } });
    upd();
  }
  function fillDialog() {
    const dlg = openDlg({
      title: 'Fläche füllen', width: 340,
      body: `<div class="ph-form"><label class="ph-f"><span>Inhalt:</span><select class="ph-sel w" data-fl="c"><option value="fg">Vordergrundfarbe</option><option value="bg">Hintergrundfarbe</option><option value="#000000">Schwarz</option><option value="#808080">50 % Grau</option><option value="#ffffff">Weiss</option></select></label>
        <label class="ph-f"><span>Deckkraft:</span><input class="ph-num w" type="number" data-fl="o" value="100" min="1" max="100"><em>%</em></label></div>`,
      onOk: () => {
        const c = dlg.el.querySelector('[data-fl="c"]').value;
        fillWith(c === 'fg' ? st.fg : c === 'bg' ? st.bg : c, clamp(Number(dlg.el.querySelector('[data-fl="o"]').value) || 100, 1, 100) / 100);
      },
    });
  }
  function exportDialog() {
    const doc = D();
    const s = { fmt: 'png', q: 90, w: doc.w, h: doc.h };
    const dlg = openDlg({
      title: 'Exportieren als', width: 440, ok: 'Exportieren',
      body: `<div class="ph-form">
        <label class="ph-f"><span>Format:</span><select class="ph-sel w" data-ex="fmt"><option value="png">PNG</option><option value="jpg">JPG</option><option value="webp">WebP</option></select></label>
        <label class="ph-f" data-exq><span>Qualität:</span><input type="range" class="ph-rng w" data-ex="q" min="1" max="100" value="90"><b data-ex="qv">90</b></label>
        <label class="ph-f"><span>Breite:</span><input class="ph-num w" type="number" data-ex="w" value="${doc.w}" min="1" max="20000"><em>Px</em></label>
        <label class="ph-f"><span>Höhe:</span><input class="ph-num w" type="number" data-ex="h" value="${doc.h}" min="1" max="20000"><em>Px</em></label>
        <div class="ph-f"><span>Dateigrösse:</span><b data-ex="size">wird berechnet …</b></div>
        <div class="ph-f"><span></span><small class="dim" data-ex="note">PNG behält die Transparenz.</small></div></div>`,
      onOk: () => exportImage(s.fmt, s.q / 100, Math.round(s.w), Math.round(s.h)),
    });
    const el = dlg.el, $ = (k) => el.querySelector(`[data-ex="${k}"]`);
    let tm = 0, flat = null;
    const est = () => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        if (!st.dlg || st.dlg.el !== el) return;
        flat = flat || flatCanvas(doc);
        let c = flat;
        if (s.fmt === 'jpg') { const o = mk(doc.w, doc.h), g = g2(o); g.fillStyle = '#fff'; g.fillRect(0, 0, doc.w, doc.h); g.drawImage(flat, 0, 0); c = o; }
        if (Math.round(s.w) !== doc.w || Math.round(s.h) !== doc.h) c = resample(c, s.w, s.h);
        const b = await toBlob(c, MIME[s.fmt][0], s.q / 100);
        if (st.dlg?.el === el && b) $('size').textContent = b.size > 1048576 ? `${fmt(b.size / 1048576, 2)} MB` : `${fmt(b.size / 1024, 1)} KB`;
      }, 200);
    };
    const upd = () => {
      el.querySelector('[data-exq]').style.display = s.fmt === 'png' ? 'none' : '';
      $('qv').textContent = s.q;
      $('note').textContent = s.fmt === 'png' ? 'PNG behält die Transparenz.' : s.fmt === 'jpg' ? 'JPG hat keine Transparenz – transparente Stellen werden weiss.' : 'WebP: klein und mit Transparenz.';
      est();
    };
    el.addEventListener('input', (e) => {
      const k = e.target.dataset.ex;
      if (k === 'fmt') s.fmt = e.target.value;
      else if (k === 'q') s.q = +e.target.value;
      else if (k === 'w') { s.w = Math.max(1, +e.target.value || 1); s.h = Math.round((s.w * doc.h) / doc.w); $('h').value = s.h; } else if (k === 'h') { s.h = Math.max(1, +e.target.value || 1); s.w = Math.round((s.h * doc.w) / doc.h); $('w').value = s.w; }
      upd();
    });
    upd();
  }
  function shortcutsDialog() {
    const rows = [];
    for (const [m, items] of MENUS) for (const it of items) if (Array.isArray(it) && it[1]) rows.push([`${m} › ${it[0].replace(' …', '')}`, keyLabel(it[1])]);
    const tools = TOOLS.filter(Array.isArray).map((t) => [t[1], t[2]]);
    const extra = [['Pinsel kleiner / grösser', '[ / ]  oder  , / .'], ['Härte −/+ 25 %', 'Umschalt+[ / ]'], ['Deckkraft 10 … 100 %', '1 … 0'], ['Vorder-/Hintergrundfarbe tauschen', 'X'], ['Standardfarben', 'D'], ['Hand (temporär)', 'Leertaste halten'], ['Mit Vordergrundfarbe füllen', 'Alt+Rücktaste'], ['Mit Hintergrundfarbe füllen', 'Strg+Rücktaste'], ['Zoomen', 'Strg/Alt + Mausrad'], ['Pipette im Pinsel', 'Alt+Klick'], ['Gerade Linie', 'Umschalt+Klick'], ['Freistellen/Transformieren bestätigen', 'Enter'], ['Abbrechen', 'Esc']];
    openDlg({
      title: 'Tastaturbefehle', width: 640, ok: 'Schliessen', cancel: '',
      body: `<div class="ph-keys"><div><div class="ph-sub">Werkzeuge</div>${tools.map(([a, b]) => `<div class="ph-krow"><span>${esc(a)}</span><kbd>${esc(b)}</kbd></div>`).join('')}<div class="ph-sub">Weitere</div>${extra.map(([a, b]) => `<div class="ph-krow"><span>${esc(a)}</span><kbd>${esc(b)}</kbd></div>`).join('')}</div><div><div class="ph-sub">Menübefehle</div>${rows.map(([a, b]) => `<div class="ph-krow"><span>${esc(a)}</span><kbd>${esc(b)}</kbd></div>`).join('')}</div></div>`,
    });
  }

  /* ================================================================ Tastatur */
  const isOn = () => !!st.root && document.contains(st.root) && st.root.offsetParent !== null;
  const TOOL_KEYS = {};
  for (const t of TOOLS) if (Array.isArray(t)) (TOOL_KEYS[t[2].toLowerCase()] ||= []).push(t[0]);
  function onKeyDown(e) {
    if (!isOn()) return;
    const t = e.target;
    const typing = t instanceof HTMLElement && (t.isContentEditable || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || (t.tagName === 'INPUT' && !/^(range|checkbox|radio|button|color)$/.test(t.type)));
    if (st.textEdit) {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); cancelText(); } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); commitText(); }
      return;
    }
    if (st.dlg) {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeDlg(false); } else if (e.key === 'Enter' && t.tagName !== 'TEXTAREA' && st.dlg.el.querySelector('[data-dlg="ok"]')) { e.preventDefault(); t.dispatchEvent?.(new Event('change', { bubbles: true })); closeDlg(true); }
      return;
    }
    if (typing) { if (e.key === 'Escape') t.blur(); return; }
    const k = combo(e);
    if (st.menu && k === 'escape') { e.preventDefault(); closeMenu(); return; }
    if (k === 'space') { e.preventDefault(); if (!st.space) { st.space = true; updateCursor(); draw(); } return; }
    if (k === 'ctrl+v') { st.pasteAt = Date.now(); return; } // → paste-Ereignis
    const item = KEYMAP.get(k);
    if (item) {
      e.preventDefault();
      e.stopPropagation();
      if (!item.en || item.en()) item.run();
      return;
    }
    const doc = D();
    const handled = () => { e.preventDefault(); e.stopPropagation(); };
    const base = k.replace(/^shift\+/, '');
    if (!e.ctrlKey && !e.altKey && !e.metaKey && TOOL_KEYS[base]) {
      handled();
      const list = TOOL_KEYS[base];
      const i = list.indexOf(st.tool);
      setTool(i >= 0 && list.length > 1 ? list[(i + 1) % list.length] : list[0]);
      return;
    }
    if (k === 'x') { handled(); return swapColors(); }
    if (k === 'd') { handled(); st.fg = '#000000'; st.bg = '#ffffff'; renderColorChips(); renderColorPanel(); return; }
    const smaller = ['[', 'ö', ','].includes(base), bigger = [']', '#', '.', 'ä'].includes(base);
    if (smaller || bigger) {
      handled();
      if (e.shiftKey) st.opt.hardness = clamp(st.opt.hardness + (bigger ? 25 : -25), 0, 100);
      else { const s = st.opt.size, step = s < 10 ? 1 : s < 50 ? 5 : s < 100 ? 10 : 25; st.opt.size = clamp(s + (bigger ? step : -step), 1, 500); }
      renderOptions();
      draw();
      return;
    }
    if (/^\d$/.test(k) && (PAINT.has(st.tool) || st.tool === 'bucket' || st.tool === 'gradient')) { handled(); st.opt.opacity = k === '0' ? 100 : +k * 10; renderOptions(); return; }
    if (k === 'tab') { handled(); return togglePanels(); }
    if (!doc) return;
    if (k === 'enter') { if (st.crop) { handled(); return cropApply(); } if (st.xf) { handled(); return applyTransform(); } }
    if (k === 'escape') { if (st.xf) { handled(); return cancelTransform(); } if (st.crop) { handled(); return cropCancel(); } if (st.drag) return; }
    if (k === 'backspace' || k === 'delete') { handled(); if (doc.sel) clearSelection(); else if (k === 'delete') deleteLayer(); return; }
    if (k === 'alt+backspace' || k === 'alt+delete') { handled(); return fillWith(st.fg, 1, 'Mit Vordergrundfarbe füllen'); }
    if (k === 'ctrl+backspace' || k === 'ctrl+delete') { handled(); return fillWith(st.bg, 1, 'Mit Hintergrundfarbe füllen'); }
    const arrows = { arrowleft: [-1, 0], arrowright: [1, 0], arrowup: [0, -1], arrowdown: [0, 1] }[base];
    if (arrows && st.tool === 'move' && !st.xf) { handled(); const n = e.shiftKey ? 10 : 1; return nudge(arrows[0] * n, arrows[1] * n); }
  }
  function onKeyUp(e) {
    if (e.key === ' ' && st.space) { st.space = false; updateCursor(); draw(); }
  }
  async function onPaste(e) {
    if (!isOn() || st.dlg || st.textEdit) return;
    const t = e.target;
    if (t instanceof HTMLElement && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    e.preventDefault();
    const file = [...(e.clipboardData?.items || [])].find((it) => it.type.startsWith('image/'))?.getAsFile();
    let img = null;
    if (file) { try { img = await loadImg(file); } catch { img = null; } }
    if (st.clip && (!img || (img.width === st.clip.c.width && img.height === st.clip.c.height))) return placeImage(st.clip.c, 'Eingefügte Ebene', st.clip.x, st.clip.y);
    if (img) return placeImage(img, 'Eingefügte Ebene');
    paste();
  }
  window.addEventListener('keydown', onKeyDown, true);
  window.addEventListener('keyup', onKeyUp, true);
  window.addEventListener('blur', () => { st.space = false; });
  document.addEventListener('paste', onPaste);

  // Für automatische Tests
  window.__ph = { projectBlob, openFiles, startTransform, applyTransform, cropApply, adjDialog, closeDlg, regionMask, combineSel, st, composite, flatCanvas, commit, addDoc, makeDoc, setTool, applyFilter, addAdjLayer, toScr, fit, undo, redo, paintStart, mergeDown, resizeImage, rotateImage };

  A.define(
    ID,
    { nav: 'Foto', title: 'Foto', sub: 'Bilder bearbeiten wie in Photoshop', icon: 'image', tint: 'linear-gradient(135deg,#31a8ff,#001e36)', desc: 'Bildbearbeitung mit Ebenen, Masken, Füllmethoden, Einstellungsebenen (Tonwerte, Kurven, Farbton/Sättigung …), Filtern, Auswahlwerkzeugen, Kopierstempel, Text und Formen. Export als PNG, JPG und WebP, Projekte mit Ebenen speichern.' },
    {
      mount(root) {
        st.root = root;
        mountUi(root);
        clearInterval(st.timer);
        st.timer = setInterval(() => {
          const doc = D();
          if (doc && (doc.sel || st.drag?.kind === 'sel' || st.drag?.kind === 'lasso')) { st.antsOff = (st.antsOff + 1) % 8; draw(); }
        }, 140);
      },
      unmount() {
        if (st.textEdit) commitText();
        clearInterval(st.timer);
        st.ro?.disconnect();
        closeDlg(false);
        closeMenu();
        st.root = null;
        st.el = {};
        panelPicker = null;
      },
      wide: true,
      game: true,
    },
  );
})();
