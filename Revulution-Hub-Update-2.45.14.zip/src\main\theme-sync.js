'use strict';
/* Runde 11b – Design „Pro“: verteilt das gewählte Design (settings.design: 'standard' | 'pro')
   an ALLE Fenster und Ansichten – auch Modul-Apps mit eigener Partition (eigenes localStorage).
   Jede Seite bekommt html[data-theme] gesetzt und den Wert in ihr localStorage geschrieben,
   damit theme-boot.js beim nächsten Start ohne Aufblitzen das richtige Design setzt. */
const { app, webContents } = require('electron');

let getDesign = () => 'standard';

function snippet(design) {
  const d = design === 'pro' ? 'pro' : 'standard';
  return `(()=>{try{localStorage.setItem('rh-design',${JSON.stringify(d)})}catch(e){}var h=document.documentElement;if(h){if(${JSON.stringify(d)}==='pro')h.setAttribute('data-theme','pro');else h.removeAttribute('data-theme');}})();`;
}

function applyTo(wc) {
  try {
    if (!wc || wc.isDestroyed()) return;
    const url = wc.getURL() || '';
    // nur eigene Seiten (file://), keine fremden Webseiten
    if (!url.startsWith('file:')) return;
    wc.executeJavaScript(snippet(getDesign()), true).catch(() => {});
  } catch {}
}

function broadcast() {
  for (const wc of webContents.getAllWebContents()) applyTo(wc);
}

function init(getter) {
  if (typeof getter === 'function') getDesign = () => (getter() === 'pro' ? 'pro' : 'standard');
  app.on('web-contents-created', (_e, wc) => {
    wc.on('dom-ready', () => applyTo(wc));
  });
}

module.exports = { init, broadcast };
