'use strict';

/*
 * Hintergründe aus der Cloud (Firebase-Projekt der Hub-Konten):
 *   bg_submissions/{id}  – Einsendungen von angemeldeten Nutzern (nur der Admin liest sie)
 *   backgrounds/{id}     – vom Admin freigegebene Bilder (alle dürfen lesen)
 * Jedes Dokument: { name, img: "data:image/jpeg;base64,…" (max. ~900 KB), by, uid, at }
 */
const fs = require('fs');
const path = require('path');

const MAX_IMG = 950 * 1024;
const clean = (v, max = 60) => String(v ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);

function checkImage(dataUrl) {
  const img = String(dataUrl || '');
  if (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(img)) throw new Error('Ungültiges Bild.');
  if (img.length > MAX_IMG) throw new Error('Das Bild ist zu groß (max. ~900 KB nach dem Verkleinern).');
  return img;
}

class CloudBackgrounds {
  /** @param {{ fb: object, token?: () => Promise<string>, uid?: () => string, name?: () => string, dir?: string }} o */
  constructor(o) {
    this.fb = o.fb;
    this.token = o.token || (async () => '');
    this.uid = o.uid || (() => '');
    this.name = o.name || (() => 'Nutzer');
    this.dir = o.dir || '';
    this.cache = null;
    this.cacheAt = 0;
  }

  /** Freigegebene Hintergründe (öffentlich). */
  async list(force = false) {
    if (!force && this.cache && Date.now() - this.cacheAt < 5 * 60000) return this.cache;
    const docs = await this.fb.list('backgrounds');
    this.cache = docs.map((d) => ({ id: d.id, name: clean(d.name) || 'Hintergrund', by: clean(d.by, 40), at: Number(d.at) || 0, img: String(d.img || '') })).sort((a, b) => b.at - a.at);
    this.cacheAt = Date.now();
    return this.cache;
  }

  /* 2.39: Likes gehen immer – lokal gespeichert (ohne Konto oder wenn die Datenbank-Regel fehlt),
     mit Konto zusätzlich in der Cloud. */
  localFile() {
    return this.dir ? path.join(this.dir, 'wp-likes.json') : '';
  }
  readLocal() {
    if (this.localMine) return this.localMine;
    try {
      this.localMine = JSON.parse(fs.readFileSync(this.localFile(), 'utf8')).filter((k) => typeof k === 'string').slice(0, 500);
    } catch {
      this.localMine = [];
    }
    return this.localMine;
  }
  writeLocal(list) {
    this.localMine = [...new Set(list)].slice(0, 500);
    try {
      if (this.localFile()) fs.writeFileSync(this.localFile(), JSON.stringify(this.localMine));
    } catch {
      /* egal */
    }
  }

  /* ---------------- Echte Likes: wp_likes/{uid} = { keys: [...] } – gezählt wird über alle Nutzer */
  async likes(force = false) {
    const r = await this.cloudLikes(force);
    // eigene lokale Likes immer mitzählen
    const mine = [...new Set([...(r.mine || []), ...this.readLocal()])];
    const counts = { ...(r.counts || {}) };
    for (const k of this.readLocal()) if (!(r.mine || []).includes(k)) counts[k] = (counts[k] || 0) + 1;
    return { ...r, counts, mine };
  }
  async cloudLikes(force = false) {
    if (!force && this.likeCache && Date.now() - this.likeAt < 60000) return this.likeCache;
    const uid = this.uid();
    let docs = [];
    try {
      docs = await this.fb.list('wp_likes', await this.token().catch(() => ''), 2000);
    } catch (e) {
      // Regeln noch nicht freigeschaltet: dann wenigstens die eigenen Likes lokal
      return { counts: {}, mine: [], error: /PERMISSION|403/i.test(String(e?.message)) ? 'rules' : 'offline' };
    }
    const counts = {};
    let mine = [];
    for (const d of docs) {
      const keys = Array.isArray(d.keys) ? d.keys.filter((k) => typeof k === 'string').slice(0, 500) : [];
      for (const k of keys) counts[k] = (counts[k] || 0) + 1;
      if (d.id === uid) mine = keys;
    }
    this.likeCache = { counts, mine };
    this.likeAt = Date.now();
    return this.likeCache;
  }

  async toggleLike(key) {
    key = String(key || '').slice(0, 80);
    if (!key) throw new Error('Unbekannter Hintergrund');
    const token = await this.token().catch(() => '');
    const uid = this.uid();
    const cur = await this.likes(true);
    const set = new Set(cur.mine || []);
    set.has(key) ? set.delete(key) : set.add(key);
    this.writeLocal([...set]);
    if (token && uid) {
      try {
        await this.fb.setDoc(`wp_likes/${uid}`, { keys: [...set], at: Date.now() }, token);
      } catch {
        /* Cloud gerade nicht erreichbar oder Regel fehlt – lokal ist gespeichert */
      }
    }
    this.likeAt = 0;
    return this.likes(true);
  }

  /** Einreichen (angemeldet): landet beim Admin zur Prüfung. */
  async submit({ name, img }) {
    const token = await this.token();
    if (!token) throw new Error('Bitte melde dich zuerst mit deinem Hub-Konto an.');
    const id = await this.fb.addDoc('bg_submissions', { name: clean(name) || 'Hintergrund', img: checkImage(img), by: clean(this.name(), 40) || 'Nutzer', uid: this.uid(), at: Date.now() }, token);
    return { id };
  }

  /** Als Windows-Hintergrund setzen. */
  async desktop(id, opts = {}) {
    const entry = (await this.list()).find((b) => b.id === id) || (await this.fb.getDoc(`backgrounds/${id}`));
    if (!entry?.img) throw new Error('Hintergrund nicht gefunden.');
    const m = /^data:image\/(jpeg|png|webp);base64,(.+)$/.exec(entry.img);
    if (!m) throw new Error('Bild beschädigt.');
    const dir = path.join(this.dir, 'community');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `cloud-wallpaper.${m[1] === 'jpeg' ? 'jpg' : m[1]}`);
    fs.writeFileSync(file, Buffer.from(m[2], 'base64'));
    await require('./desktop-wallpaper').applyDesktopWallpaper(file, opts);
    return true;
  }

  /* ---------------------------------------------------------------- 2.42 Support-Tickets (Feedback, Bugs, Probleme, Meldungen) */
  async ticket(r = {}) {
    const token = await this.token().catch(() => '');
    const KINDS = ['feedback', 'bug', 'problem', 'idea', 'wallpaper', 'other'];
    const kind = KINDS.includes(r.kind) ? r.kind : 'other';
    const text = clean(r.text, 3000);
    if (text.length < 3) throw new Error('Schreib bitte kurz, worum es geht.');
    let img = '';
    if (r.img) img = checkImage(r.img);
    const data = {
      kind, subject: clean(r.subject, 80), text, email: clean(r.email, 80), ref: clean(r.ref, 80), refName: clean(r.refName, 80),
      version: clean(r.version, 20), uid: this.uid() || '', by: clean(this.name(), 40) || 'Gast', img, status: 'open', at: Date.now(),
    };
    const id = await this.fb.addDoc('tickets', data, token || undefined);
    return { id };
  }
  async tickets(token) {
    const docs = await this.fb.list('tickets', token);
    return docs.map((d) => ({ id: d.id, kind: clean(d.kind, 20), subject: clean(d.subject, 80), text: String(d.text || ''), email: clean(d.email, 80), ref: clean(d.ref, 80), refName: clean(d.refName, 80), version: clean(d.version, 20), by: clean(d.by, 40), img: String(d.img || ''), status: ['open', 'doing', 'done'].includes(d.status) ? d.status : 'open', at: Number(d.at) || 0 })).sort((a, b) => b.at - a.at);
  }
  async ticketStatus(id, status, token) {
    const d = await this.fb.getDoc(`tickets/${id}`, token);
    if (!d) throw new Error('Ticket nicht gefunden.');
    const { id: _drop, ...rest } = d;
    await this.fb.setDoc(`tickets/${id}`, { ...rest, status: ['open', 'doing', 'done'].includes(status) ? status : 'open' }, token);
    return true;
  }

  /* ---------------------------------------------------------------- 2.39 Chat-Meldungen */
  async chatReport(r = {}) {
    const token = await this.token();
    if (!token) throw new Error('Zum Melden melde dich mit deinem Revulution-Konto an (Konto-App).');
    const msgs = (Array.isArray(r.msgs) ? r.msgs : []).slice(-30).map((m) => ({ from: clean(m.from, 24), code: clean(m.code, 12), text: clean(m.text, 400), at: Number(m.at) || 0 }));
    let img = '';
    if (r.img) img = checkImage(r.img);
    const id = await this.fb.addDoc('chat_reports', {
      uid: this.uid(), by: clean(this.name(), 40) || 'Nutzer', byCode: clean(r.myCode, 12),
      reported: clean(r.reported, 40), reportedCode: clean(r.reportedCode, 12), chat: clean(r.chat, 40),
      reason: clean(r.reason, 40), text: clean(r.text, 800), msgs: JSON.stringify(msgs).slice(0, 60000), img, status: 'open', at: Date.now(),
    }, token);
    return { id };
  }
  async chatReports(token) {
    const docs = await this.fb.list('chat_reports', token);
    return docs.map((d) => ({ id: d.id, by: clean(d.by, 40), byCode: clean(d.byCode, 12), reported: clean(d.reported, 40), reportedCode: clean(d.reportedCode, 12), chat: clean(d.chat, 40), reason: clean(d.reason, 40), text: String(d.text || ''), msgs: (() => { try { return JSON.parse(d.msgs || '[]'); } catch { return []; } })(), img: String(d.img || ''), status: d.status === 'done' ? 'done' : 'open', at: Number(d.at) || 0 })).sort((a, b) => b.at - a.at);
  }
  async chatReportStatus(id, status, token) {
    const d = await this.fb.getDoc(`chat_reports/${id}`, token);
    if (!d) throw new Error('Meldung nicht gefunden.');
    const { id: _drop, ...rest } = d;
    await this.fb.setDoc(`chat_reports/${id}`, { ...rest, status: status === 'done' ? 'done' : 'open' }, token);
    return true;
  }

  /* ---------------------------------------------------------------- Admin */
  async pending(token) {
    const docs = await this.fb.list('bg_submissions', token);
    return docs.map((d) => ({ id: d.id, name: clean(d.name) || 'Hintergrund', by: clean(d.by, 40), uid: String(d.uid || ''), at: Number(d.at) || 0, img: String(d.img || '') })).sort((a, b) => b.at - a.at);
  }

  async approve(id, token, name) {
    const d = await this.fb.getDoc(`bg_submissions/${id}`, token);
    if (!d) throw new Error('Einsendung nicht gefunden.');
    await this.fb.addDoc('backgrounds', { name: clean(name || d.name) || 'Hintergrund', img: checkImage(d.img), by: clean(d.by, 40), at: Date.now() }, token);
    await this.fb.delDoc(`bg_submissions/${id}`, token);
    this.cache = null;
    return true;
  }

  async reject(id, token) {
    await this.fb.delDoc(`bg_submissions/${id}`, token);
    return true;
  }

  async removePublic(id, token) {
    await this.fb.delDoc(`backgrounds/${id}`, token);
    this.cache = null;
    return true;
  }

  /** Admin lädt direkt ein freigegebenes Bild hoch (aus einer Datei, schon verkleinert). */
  async publish({ name, img }, token) {
    await this.fb.addDoc('backgrounds', { name: clean(name) || 'Hintergrund', img: checkImage(img), by: 'Revulution', at: Date.now() }, token);
    this.cache = null;
    return true;
  }
}

/** Firestore-Regeln, die der Admin einmal in der Firebase-Konsole einträgt.
    Runde 11c: Support-Chat (tickets/{id}/msgs), Sperren/Timeouts (revhub_mod) – gesperrte Konten dürfen
    keine Tickets, Antworten, Meldungen oder Einsendungen schreiben. */
function rulesFor(adminUid) {
  return `    // ---- Revulution Hub (Runde 11c) – diesen ganzen Block ersetzt den bisherigen Revulution-Block
    function revAdmin() {
      return request.auth != null && request.auth.uid == '${adminUid}';
    }
    // frei = ohne Konto, oder Konto ohne Sperre und ohne laufenden Timeout (revhub_mod/{uid})
    function revFree() {
      return request.auth == null
        || !exists(/databases/$(database)/documents/revhub_mod/$(request.auth.uid))
        || (get(/databases/$(database)/documents/revhub_mod/$(request.auth.uid)).data.blocked != true
            && get(/databases/$(database)/documents/revhub_mod/$(request.auth.uid)).data.until < request.time.toMillis());
    }
    match /revhub_mod/{uid} {
      // Sperren und Timeouts: setzt nur der Admin, das eigene Konto darf seinen Status lesen
      allow read: if revAdmin() || (request.auth != null && request.auth.uid == uid);
      allow write: if revAdmin();
    }
    match /bg_submissions/{id} {
      allow create: if request.auth != null && request.resource.data.uid == request.auth.uid && revFree()
                    && request.resource.data.img is string && request.resource.data.img.size() < 980000;
      allow read, delete: if request.auth != null && request.auth.uid == '${adminUid}';
    }
    match /backgrounds/{id} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == '${adminUid}';
    }
    match /tickets/{id} {
      // Tickets dürfen alle schicken (auch ohne Konto), gesperrte Konten nicht.
      // Mit Konto sieht man die eigenen Tickets samt Antworten (Support-Chat).
      allow create: if revFree()
                    && request.resource.data.text is string && request.resource.data.text.size() < 4000
                    && request.resource.data.img is string && request.resource.data.img.size() < 980000
                    && request.resource.data.status == 'open'
                    && (request.resource.data.uid == '' || (request.auth != null && request.resource.data.uid == request.auth.uid));
      allow read: if revAdmin() || (request.auth != null && resource.data.uid == request.auth.uid);
      allow update: if revAdmin() || (request.auth != null && resource.data.uid == request.auth.uid && revFree()
                    && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['lastAt', 'lastBy', 'status'])
                    && request.resource.data.status == 'open' && request.resource.data.lastBy == 'user');
      allow delete: if revAdmin();
      match /msgs/{mid} {
        allow read: if revAdmin() || (request.auth != null && get(/databases/$(database)/documents/tickets/$(id)).data.uid == request.auth.uid);
        allow create: if revAdmin() || (request.auth != null && revFree()
                      && request.resource.data.from == 'user' && request.resource.data.uid == request.auth.uid
                      && get(/databases/$(database)/documents/tickets/$(id)).data.uid == request.auth.uid
                      && request.resource.data.text is string && request.resource.data.text.size() < 4000);
        allow delete: if revAdmin();
      }
    }
    match /revhub_names/{key} {
      // 2.45.9 eindeutige Anzeigenamen: jeder Name gehört genau einem Konto
      allow read: if true;
      allow create: if request.auth != null && request.resource.data.uid == request.auth.uid;
      allow update: if request.auth != null && resource.data.uid == request.auth.uid && request.resource.data.uid == request.auth.uid;
      allow delete: if request.auth != null && resource.data.uid == request.auth.uid;
    }
    match /chat_reports/{id} {
      // Melden nur mit Konto und ohne Sperre/Timeout
      allow create: if request.auth != null && request.resource.data.uid == request.auth.uid && revFree()
                    && request.resource.data.img is string && request.resource.data.img.size() < 980000;
      allow read, update, delete: if request.auth != null && request.auth.uid == '${adminUid}';
    }`;
}

module.exports = { CloudBackgrounds, rulesFor };
