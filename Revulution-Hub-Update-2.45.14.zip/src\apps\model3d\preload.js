'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('model3d', {
  save: (req) => ipcRenderer.invoke('save', req),
  open: (req) => ipcRenderer.invoke('open', req),
  unzip3mf: (bytes) => ipcRenderer.invoke('unzip3mf', bytes),
  draftSave: (text) => ipcRenderer.invoke('draft:save', text),
  draftLoad: () => ipcRenderer.invoke('draft:load'),
});
