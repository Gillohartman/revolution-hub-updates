'use strict';

/* Runde 11d – Recherche: OSINT-Werkzeugkasten für Domains, IP-Adressen, Webseiten und eigene Dateien.
   Netzwerk-Abfragen laufen im Hauptprozess (src/main/recherche.js), Datei- und E-Mail-Analyse lokal.
   Bewusst ohne Personensuche: keine Namen, Benutzernamen, Telefonnummern oder Adressen. */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const PAGE = 'tool-recherche';
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const ctx = () => T.ctx();
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const api = () => window.hub.recherche;
  const date = (v) => (v ? new Date(v).toLocaleDateString('de-CH', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '–');
  const dateTime = (v) => (v ? new Date(v).toLocaleString('de-CH', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '–');
  const ago = (v) => {
    if (!v) return '';
    const days = Math.round((Date.now() - Date.parse(v)) / 86400000);
    if (days < 0) return `in ${Math.abs(days)} Tagen`;
    if (days < 60) return `vor ${days} Tagen`;
    const y = days / 365.25;
    return y < 2 ? `vor ${Math.round(days / 30)} Monaten` : `vor ${Math.floor(y)} Jahren`;
  };
  const SVG = {
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
    pin: '<path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    code: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
    route: '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h7a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h7"/>',
    tree: '<path d="M12 3v6M12 9H6v4M12 9h6v4M6 13v3M18 13v3M12 9v7"/><circle cx="12" cy="3" r="1"/><circle cx="6" cy="18" r="2"/><circle cx="12" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
    hash: '<path d="M5 9h14M5 15h14M10 4 8 20M16 4l-2 16"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/>',
    id: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15h4M7 11h10"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    ok: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    warn: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17h.01"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  };
  const ico = (k, s = 18) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${SVG[k] || SVG.spark}</svg>`;
  // [id, Name, Symbol, Gruppe, braucht Ziel]
  const TABS = [
    ['overview', 'Übersicht', 'spark', 'Ziel', true],
    ['rdap', 'WHOIS / RDAP', 'id', 'Ziel', true],
    ['dns', 'DNS-Einträge', 'list', 'Ziel', true],
    ['ipinfo', 'IP & Standort', 'pin', 'Ziel', true],
    ['ssl', 'SSL-Zertifikat', 'lock', 'Ziel', true],
    ['web', 'Webseite & Technik', 'code', 'Ziel', true],
    ['redirects', 'Weiterleitungen', 'route', 'Ziel', true],
    ['subdomains', 'Subdomains', 'tree', 'Ziel', true],
    ['archive', 'Web-Archiv', 'clock', 'Ziel', true],
    ['meta', 'Datei-Metadaten', 'image', 'Lokal', false],
    ['hash', 'Hash-Rechner', 'hash', 'Lokal', false],
    ['mail', 'E-Mail-Header', 'mail', 'Lokal', false],
  ];
  const st = { tab: 'overview', q: '', target: '', kind: '', res: {}, busy: {}, err: {}, recent: [], meta: null, hash: null, hashBusy: false, hashCmp: '', hashText: '', mailRaw: '', mail: null };
  try {
    st.recent = JSON.parse(localStorage.getItem('rev-rc-recent') || '[]').slice(0, 8);
  } catch {
    st.recent = [];
  }

  /* ---------------------------------------------------------------- Abfragen */
  const key = (tool) => `${tool}|${st.target}`;
  async function run(tool, { force = false } = {}) {
    if (!st.target) return;
    const k = key(tool);
    if (!force && (st.res[k] || st.busy[k])) return;
    st.busy[k] = true;
    delete st.err[k];
    paint();
    try {
      st.res[k] = await api().run(tool, st.target);
    } catch (e) {
      st.err[k] = errText(e);
    }
    delete st.busy[k];
    paint();
  }
  async function analyze(q) {
    const v = String(q ?? st.q).trim();
    if (!v) return;
    try {
      const d = await api().run('detect', v);
      st.q = v;
      st.target = v;
      st.kind = d.kind;
      st.recent = [v, ...st.recent.filter((x) => x !== v)].slice(0, 8);
      localStorage.setItem('rev-rc-recent', JSON.stringify(st.recent));
      if (!TABS.find((t) => t[0] === st.tab)?.[4]) st.tab = 'overview';
      st.err.input = '';
      startTab();
    } catch (e) {
      st.err.input = errText(e);
      paint();
    }
  }
  function startTab() {
    if (!st.target) return paint();
    if (st.tab === 'overview') ['rdap', 'dns', 'ipinfo', 'ssl', 'web'].forEach((t) => run(t));
    else if (TABS.find((t) => t[0] === st.tab)?.[4]) run(st.tab);
    paint();
  }

  /* ---------------------------------------------------------------- Bausteine */
  const kv = (rows) => `<dl class="rc-kv">${rows.filter((r) => r && r[1] !== undefined && r[1] !== '' && r[1] !== null).map(([k, v, raw]) => `<dt>${esc(k)}</dt><dd>${raw ? v : esc(v)}</dd>`).join('')}</dl>`;
  const pill = (text, tone = '') => `<span class="rc-pill ${tone}">${esc(text)}</span>`;
  const copyBtn = (text) => `<button class="rc-copy" data-rc-copy="${esc(text)}" title="Kopieren">${ico('copy', 13)}</button>`;
  const card = (title, icon, body, extra = '') => `<section class="rc-card ${extra}"><header>${ico(icon, 16)}<h3>${esc(title)}</h3></header>${body}</section>`;
  function state(tool) {
    const k = key(tool);
    if (st.busy[k]) return { html: '<div class="rc-load"><i></i><span>Wird abgefragt …</span></div>' };
    if (st.err[k]) return { html: `<div class="rc-err">${ico('warn', 16)}<span>${esc(st.err[k])}</span><button class="btn small" data-rc-retry="${tool}">Nochmal</button></div>` };
    return { data: st.res[k] };
  }
  const extLink = (url, text) => `<a href="#" data-rc-ext="${esc(url)}">${esc(text || url)}</a>`;

  /* ---------------------------------------------------------------- Ansichten je Werkzeug */
  function rdapHtml(d) {
    if (d.kind === 'ip') return kv([['Netz', d.name], ['Bereich', d.range], ['CIDR', d.cidr], ['Land', d.country], ['Typ', d.type], ['Registriert', d.registered ? `${date(d.registered)} (${ago(d.registered)})` : ''], ['Geändert', date(d.changed)], ['Handle', d.handle]]) + (d.orgs.length ? `<h4 class="rc-h">Organisationen</h4>${kv(d.orgs.map((o) => [o.role || 'Kontakt', o.name]))}` : '');
    const exp = d.expires ? Math.round((Date.parse(d.expires) - Date.now()) / 86400000) : null;
    return kv([
      ['Domain', d.name], ['Registrar', d.registrar], ['Registriert', d.registered ? `${date(d.registered)} · ${ago(d.registered)}` : ''],
      ['Läuft ab', d.expires ? `${date(d.expires)} ${exp !== null && exp < 30 ? pill(`in ${exp} Tagen`, 'warn') : ''}` : '', true],
      ['Geändert', d.changed ? date(d.changed) : ''], ['DNSSEC', d.dnssec], ['Missbrauch melden', d.abuse],
      ['Nameserver', d.nameservers.map((n) => `<code>${esc(n)}</code>`).join(' '), true],
      ['Status', d.status.map((s) => pill(s)).join(' '), true],
    ]);
  }
  function dnsHtml(d) {
    if (!d.records.length) return `<p class="rc-empty">${esc(d.note || 'Keine Einträge gefunden.')}</p>`;
    const groups = {};
    for (const r of d.records) (groups[r.type] = groups[r.type] || []).push(r);
    const order = ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'CAA', 'PTR'];
    return `<table class="rc-table"><thead><tr><th>Typ</th><th>Wert</th><th>TTL</th></tr></thead><tbody>${order.filter((t) => groups[t]).flatMap((t) => groups[t].map((r, i) => `<tr><td>${i ? '' : pill(t, 'type')}</td><td><code>${esc(r.data)}</code>${(t === 'A' || t === 'AAAA') ? ` <button class="rc-link" data-rc-go="${esc(r.data)}">prüfen</button>` : ''}</td><td>${r.ttl}s</td></tr>`)).join('')}</tbody></table>
      ${d.mail ? `<h4 class="rc-h">E-Mail-Schutz</h4>${kv([['SPF', `${pill(d.mail.spfVerdict, d.mail.spf ? (/streng/.test(d.mail.spfVerdict) ? 'ok' : 'warn') : 'bad')} ${d.mail.spf ? `<code>${esc(d.mail.spf)}</code>` : ''}`, true], ['DMARC', `${pill(d.mail.dmarc ? `p=${d.mail.dmarcPolicy || '?'}` : 'fehlt', d.mail.dmarc ? (/reject|quarantine/.test(d.mail.dmarcPolicy) ? 'ok' : 'warn') : 'bad')} ${d.mail.dmarc ? `<code>${esc(d.mail.dmarc)}</code>` : ''}`, true]])}` : ''}`;
  }
  function ipHtml(d) {
    const map = Number.isFinite(d.lat) ? `https://www.openstreetmap.org/?mlat=${d.lat}&mlon=${d.lon}#map=10/${d.lat}/${d.lon}` : '';
    return `${kv([
      ['IP-Adresse', `<code>${esc(d.ip)}</code> ${copyBtn(d.ip)} ${pill(d.type || '')}${d.own ? ` ${pill('deine öffentliche IP', 'ok')}` : ''}`, true],
      ['Ort (ungefähr)', [d.city, d.region, d.country].filter(Boolean).join(', ')], ['Zeitzone', d.timezone],
      ['Provider', d.isp], ['Organisation', d.org], ['ASN', d.asn ? `AS${d.asn}` : ''], ['Reverse DNS', d.ptr.join(', ')],
      ['Karte', map ? extLink(map, `${d.lat?.toFixed(3)}, ${d.lon?.toFixed(3)} auf OpenStreetMap`) : '', true],
    ])}<p class="rc-note">Der Standort einer IP zeigt meist nur den Ort des Providers oder Rechenzentrums – nie eine Wohnadresse.</p>`;
  }
  function sslHtml(d) {
    const tone = d.daysLeft < 0 ? 'bad' : d.daysLeft < 21 ? 'warn' : 'ok';
    return `<div class="rc-badges">${pill(d.authorized ? 'Vertrauenswürdig' : `Nicht vertrauenswürdig${d.authError ? `: ${d.authError}` : ''}`, d.authorized ? 'ok' : 'bad')} ${pill(d.daysLeft < 0 ? 'abgelaufen' : `noch ${d.daysLeft} Tage gültig`, tone)} ${pill(d.protocol || '')}</div>
      ${kv([['Ausgestellt für', d.subject], ['Organisation', d.org], ['Aussteller', [d.issuer, d.issuerOrg].filter(Boolean).join(' · ')], ['Gültig', `${date(d.validFrom)} – ${date(d.validTo)}`], ['Schlüssel', d.keyType], ['Cipher', d.cipher], ['ALPN', d.alpn], ['Seriennummer', d.serial], ['SHA-256', `<code class="rc-wrap">${esc(d.fingerprint)}</code>`, true]])}
      ${d.chain.length ? `<h4 class="rc-h">Kette</h4><ol class="rc-chain">${d.chain.map((c) => `<li><b>${esc(c.subject)}</b><small>von ${esc(c.issuer)}</small></li>`).join('')}</ol>` : ''}
      ${d.san.length ? `<h4 class="rc-h">Gilt für ${d.san.length} Namen</h4><div class="rc-tags">${d.san.slice(0, 60).map((s) => `<code>${esc(s)}</code>`).join('')}${d.san.length > 60 ? `<small>… und ${d.san.length - 60} weitere</small>` : ''}</div>` : ''}`;
  }
  function hopsHtml(hops) {
    return `<ol class="rc-hops">${hops.map((h) => `<li class="${h.error ? 'bad' : h.status >= 400 ? 'bad' : h.status >= 300 ? 'redir' : 'ok'}"><span class="rc-code">${h.error ? '!' : h.status}</span><div><code class="rc-wrap">${esc(h.url)}</code><small>${h.error ? esc(h.error) : `${esc(h.statusText)} · ${h.ms} ms${h.ip ? ` · ${esc(h.ip)}` : ''}${h.server ? ` · ${esc(h.server)}` : ''}`}</small></div></li>`).join('')}</ol>`;
  }
  function webHtml(d) {
    const good = d.security.filter((s) => s.value).length;
    return `<div class="rc-badges">${pill(`HTTP ${d.status}`, d.status < 400 ? 'ok' : 'bad')} ${pill(d.https ? 'HTTPS' : 'kein HTTPS', d.https ? 'ok' : 'bad')} ${pill(`${d.ms} ms`)} ${pill(`Sicherheits-Header ${good}/${d.security.length}`, good >= 5 ? 'ok' : good >= 3 ? 'warn' : 'bad')}</div>
      ${kv([['Titel', d.title], ['Beschreibung', d.description], ['Ziel-Adresse', d.final], ['Server-IP', d.ip]])}
      <h4 class="rc-h">Erkannte Technik</h4><div class="rc-tags">${d.tech.length ? d.tech.map((t) => `<span class="rc-tech">${esc(t)}</span>`).join('') : '<small class="rc-empty">Nichts Eindeutiges erkannt.</small>'}</div>
      <h4 class="rc-h">Sicherheits-Header</h4><ul class="rc-sec">${d.security.map((s) => `<li class="${s.value ? 'ok' : 'miss'}">${ico(s.value ? 'ok' : 'warn', 14)}<b>${esc(s.name)}</b><small>${esc(s.value || s.why)}</small></li>`).join('')}</ul>
      ${d.cookies.length ? `<h4 class="rc-h">Cookies beim ersten Aufruf</h4><table class="rc-table"><tbody>${d.cookies.map((c) => `<tr><td><code>${esc(c.name)}</code></td><td>${pill('Secure', c.secure ? 'ok' : 'bad')} ${pill('HttpOnly', c.httpOnly ? 'ok' : 'warn')} ${c.sameSite ? pill(`SameSite=${c.sameSite}`) : ''}</td></tr>`).join('')}</tbody></table>` : ''}
      ${d.hops.length > 1 ? `<h4 class="rc-h">Weiterleitungen</h4>${hopsHtml(d.hops)}` : ''}
      <details class="rc-raw"><summary>Alle ${d.headers.length} Antwort-Header</summary><table class="rc-table"><tbody>${d.headers.map(([k, v]) => `<tr><td><code>${esc(k)}</code></td><td><code class="rc-wrap">${esc(v)}</code></td></tr>`).join('')}</tbody></table></details>`;
  }
  function subHtml(d) {
    if (!d.list.length) return '<p class="rc-empty">Keine Subdomains in den Zertifikats-Logs gefunden.</p>';
    return `<p class="rc-note">${d.total} Namen aus öffentlichen Zertifikats-Logs (crt.sh)${d.total > d.list.length ? `, die ersten ${d.list.length}` : ''}.</p>
      <table class="rc-table"><thead><tr><th>Name</th><th>Zuletzt</th><th>Zertifikate</th><th></th></tr></thead><tbody>${d.list.map((s) => `<tr><td><code>${esc(s.name)}</code></td><td>${date(s.last)}</td><td>${s.count}</td><td><button class="rc-link" data-rc-go="${esc(s.name)}">prüfen</button></td></tr>`).join('')}</tbody></table>`;
  }
  function archiveHtml(d) {
    if (!d.latest && !d.first && !d.years.length) return `<p class="rc-empty">Nicht im Internet Archive gefunden.</p>`;
    const now = new Date().getFullYear();
    const from = Number(d.years[0] || now);
    const yrs = [];
    for (let y = from; y <= now; y++) yrs.push(y);
    return `${kv([['Erste Aufnahme', d.first ? extLink(d.first.url, d.first.date) : '', true], ['Neueste Aufnahme', d.latest ? extLink(d.latest.url, d.latest.date) : '', true], ['Alle Aufnahmen', extLink(d.calendar, 'Kalender auf archive.org'), true]])}
      <h4 class="rc-h">Jahre mit Aufnahmen</h4><div class="rc-years">${yrs.map((y) => `<span class="${d.years.includes(String(y)) ? 'on' : ''}">${y}</span>`).join('')}</div>`;
  }

  /* ---------------------------------------------------------------- Übersicht */
  function overviewHtml() {
    const pick = (tool, fn) => {
      const s = state(tool);
      return s.html || (s.data ? fn(s.data) : '<div class="rc-load"><i></i><span>Wartet …</span></div>');
    };
    const isIp = st.kind === 'ip';
    return `<div class="rc-grid">
      ${card(isIp ? 'Netz-Eigentümer (RDAP)' : 'Registrierung (RDAP)', 'id', pick('rdap', (d) => (d.kind === 'ip' ? kv([['Netz', d.name], ['Land', d.country], ['Bereich', d.cidr || d.range]]) : kv([['Registrar', d.registrar], ['Registriert', d.registered ? `${date(d.registered)} · ${ago(d.registered)}` : ''], ['Läuft ab', date(d.expires)], ['Nameserver', d.nameservers.slice(0, 3).join(', ')]]))))}
      ${card('IP & Standort', 'pin', pick('ipinfo', (d) => kv([['IP', d.ip], ['Ort (ungefähr)', [d.city, d.country].filter(Boolean).join(', ')], ['Provider', d.isp || d.org], ['ASN', d.asn ? `AS${d.asn}` : '']])))}
      ${card('DNS', 'list', pick('dns', (d) => {
        const c = {};
        d.records.forEach((r) => (c[r.type] = (c[r.type] || 0) + 1));
        return `<div class="rc-tags">${Object.entries(c).map(([k, n]) => `<span class="rc-tech">${k} · ${n}</span>`).join('') || '<small class="rc-empty">keine</small>'}</div>${d.mail ? kv([['SPF', d.mail.spfVerdict], ['DMARC', d.mail.dmarc ? `p=${d.mail.dmarcPolicy}` : 'fehlt']]) : ''}`;
      }))}
      ${card('SSL-Zertifikat', 'lock', pick('ssl', (d) => `<div class="rc-badges">${pill(d.authorized ? 'gültig' : 'nicht vertrauenswürdig', d.authorized ? 'ok' : 'bad')} ${pill(`noch ${d.daysLeft} Tage`, d.daysLeft < 21 ? 'warn' : 'ok')}</div>${kv([['Aussteller', d.issuerOrg || d.issuer], ['Gilt bis', date(d.validTo)], ['Namen', String(d.san.length)]])}`))}
      ${card('Webseite', 'code', pick('web', (d) => `<div class="rc-badges">${pill(`HTTP ${d.status}`, d.status < 400 ? 'ok' : 'bad')} ${pill(`Header ${d.security.filter((s) => s.value).length}/${d.security.length}`)}</div>${kv([['Titel', d.title]])}<div class="rc-tags">${d.tech.slice(0, 10).map((t) => `<span class="rc-tech">${esc(t)}</span>`).join('')}</div>`), 'wide')}
    </div>`;
  }

  /* ---------------------------------------------------------------- Lokal: Datei-Metadaten (EXIF, PNG, PDF) */
  const EXIF_TAGS = { 0x010f: 'Hersteller', 0x0110: 'Modell', 0x0131: 'Software', 0x0132: 'Geändert', 0x013b: 'Urheber', 0x8298: 'Copyright', 0x0112: 'Ausrichtung', 0x010e: 'Beschreibung', 0x9003: 'Aufgenommen', 0x9004: 'Digitalisiert', 0x9010: 'Zeitzone', 0x829a: 'Belichtung', 0x829d: 'Blende', 0x8827: 'ISO', 0x920a: 'Brennweite', 0xa002: 'Breite', 0xa003: 'Höhe', 0xa433: 'Objektiv-Hersteller', 0xa434: 'Objektiv', 0xa420: 'Bild-ID', 0xa431: 'Seriennummer Kamera', 0x9209: 'Blitz', 0xa406: 'Szene' };
  function parseExif(buf) {
    const v = new DataView(buf);
    if (v.getUint16(0) !== 0xffd8) return null;
    let off = 2;
    while (off + 4 < v.byteLength) {
      const marker = v.getUint16(off);
      const len = v.getUint16(off + 2);
      if (marker === 0xffe1 && v.getUint32(off + 4) === 0x45786966) return readTiff(v, off + 10);
      if ((marker & 0xff00) !== 0xff00 || marker === 0xffda) break;
      off += 2 + len;
    }
    return null;
  }
  function readTiff(v, start) {
    const le = v.getUint16(start) === 0x4949;
    const u16 = (o) => v.getUint16(start + o, le);
    const u32 = (o) => v.getUint32(start + o, le);
    const out = { tags: {}, gps: {} };
    const SIZES = { 1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8 };
    const val = (type, count, o) => {
      const size = (SIZES[type] || 1) * count;
      const at = size > 4 ? u32(o) : o;
      if (start + at + size > v.byteLength) return null;
      if (type === 2) {
        let s = '';
        for (let i = 0; i < count; i++) {
          const c = v.getUint8(start + at + i);
          if (!c) break;
          s += String.fromCharCode(c);
        }
        return s.trim();
      }
      const one = (i) => {
        if (type === 3) return u16(at + i * 2);
        if (type === 4) return u32(at + i * 4);
        if (type === 9) return v.getInt32(start + at + i * 4, le);
        if (type === 5 || type === 10) {
          const n = type === 5 ? u32(at + i * 8) : v.getInt32(start + at + i * 8, le);
          const d = type === 5 ? u32(at + i * 8 + 4) : v.getInt32(start + at + i * 8 + 4, le);
          return d ? n / d : 0;
        }
        return v.getUint8(start + at + i);
      };
      return count === 1 ? one(0) : Array.from({ length: Math.min(count, 16) }, (_, i) => one(i));
    };
    const ifd = (o, into, depth = 0) => {
      if (!o || start + o + 2 > v.byteLength || depth > 3) return;
      const n = u16(o);
      for (let i = 0; i < n && i < 300; i++) {
        const e = o + 2 + i * 12;
        if (start + e + 12 > v.byteLength) return;
        const tag = u16(e);
        const type = u16(e + 2);
        const count = u32(e + 4);
        if (tag === 0x8769) ifd(u32(e + 8), into, depth + 1);
        else if (tag === 0x8825) ifd(u32(e + 8), out.gps, depth + 1);
        else into[tag] = val(type, count, e + 8);
      }
    };
    if (u16(2) !== 42) return null;
    ifd(u32(4), out.tags);
    return out;
  }
  function gpsOf(g) {
    if (!g || !Array.isArray(g[2]) || !Array.isArray(g[4])) return null;
    const dms = (a) => a[0] + a[1] / 60 + a[2] / 3600;
    const lat = dms(g[2]) * (g[1] === 'S' ? -1 : 1);
    const lon = dms(g[4]) * (g[3] === 'W' ? -1 : 1);
    return Number.isFinite(lat) && Number.isFinite(lon) && (lat || lon) ? { lat, lon, alt: typeof g[6] === 'number' ? g[6] : null } : null;
  }
  function pngText(buf) {
    const v = new DataView(buf);
    const out = [];
    let off = 8;
    const dec = new TextDecoder('latin1');
    while (off + 12 < v.byteLength && out.length < 40) {
      const len = v.getUint32(off);
      const type = dec.decode(new Uint8Array(buf, off + 4, 4));
      if (type === 'tEXt' || type === 'iTXt') {
        const raw = dec.decode(new Uint8Array(buf, off + 8, Math.min(len, 4000)));
        const [k, ...rest] = raw.split('\0');
        out.push([k, rest.filter(Boolean).pop() || '']);
      }
      if (type === 'eXIf') out.push(['EXIF', 'enthalten']);
      if (type === 'IEND') break;
      off += 12 + len;
    }
    return out;
  }
  function pdfInfo(buf) {
    const s = new TextDecoder('latin1').decode(new Uint8Array(buf, 0, Math.min(buf.byteLength, 4 * 1024 * 1024)));
    const out = [];
    for (const k of ['Title', 'Author', 'Subject', 'Keywords', 'Creator', 'Producer', 'CreationDate', 'ModDate']) {
      const m = new RegExp(`/${k}\\s*\\(([^)]{0,300})\\)`).exec(s);
      if (m) out.push([k, m[1]]);
    }
    const ver = /%PDF-(\d\.\d)/.exec(s);
    if (ver) out.unshift(['PDF-Version', ver[1]]);
    const pages = (s.match(/\/Type\s*\/Page[^s]/g) || []).length;
    if (pages) out.push(['Seiten (ca.)', String(pages)]);
    return out;
  }
  async function readMeta(file) {
    const buf = await file.arrayBuffer();
    const info = { name: file.name, size: file.size, type: file.type || '–', modified: file.lastModified, rows: [], gps: null, image: false, warnings: [] };
    if (/^image\//.test(file.type)) {
      info.image = true;
      const bmp = await createImageBitmap(file).catch(() => null);
      if (bmp) info.dims = `${bmp.width} × ${bmp.height} px`;
      const ex = file.type === 'image/jpeg' ? parseExif(buf) : null;
      if (ex) {
        for (const [tag, name] of Object.entries(EXIF_TAGS)) {
          let x = ex.tags[tag];
          if (x === undefined || x === null || x === '') continue;
          if (Number(tag) === 0x829a && typeof x === 'number') x = x < 1 ? `1/${Math.round(1 / x)} s` : `${x} s`;
          else if (Number(tag) === 0x829d) x = `f/${Number(x).toFixed(1)}`;
          else if (Number(tag) === 0x920a) x = `${Math.round(x)} mm`;
          else if (Array.isArray(x)) x = x.join(', ');
          info.rows.push([name, String(x)]);
        }
        info.gps = gpsOf(ex.gps);
        if (info.gps) info.warnings.push('Dieses Foto enthält GPS-Koordinaten – wer es bekommt, sieht, wo es aufgenommen wurde.');
        if (ex.tags[0xa431]) info.warnings.push('Die Seriennummer der Kamera ist gespeichert.');
        if (ex.tags[0x013b]) info.warnings.push('Ein Name (Urheber) ist gespeichert.');
      }
      if (file.type === 'image/png') info.rows.push(...pngText(buf));
    } else if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
      info.rows.push(...pdfInfo(buf));
      if (info.rows.some(([k]) => k === 'Author')) info.warnings.push('Im PDF steht ein Autor-Name.');
    }
    return info;
  }
  async function stripImage(file) {
    const bmp = await createImageBitmap(file);
    const cv = document.createElement('canvas');
    cv.width = bmp.width;
    cv.height = bmp.height;
    cv.getContext('2d').drawImage(bmp, 0, 0);
    const type = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
    const blob = await new Promise((r) => cv.toBlob(r, type, 0.95));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = file.name.replace(/(\.[^.]+)?$/, `-ohne-metadaten${type === 'image/png' ? '.png' : '.jpg'}`);
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  const fmtSize = (n) => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : n > 1024 ? `${Math.round(n / 1024)} KB` : `${n} B`);
  function metaHtml() {
    const m = st.meta;
    const drop = `<label class="rc-drop" data-rc-drop="meta"><input type="file" data-rc-file="meta" hidden />${ico('image', 28)}<b>Datei hierher ziehen oder klicken</b><small>Fotos (JPEG/PNG), PDFs – die Datei bleibt auf deinem PC.</small></label>`;
    if (!m) return `${drop}<p class="rc-note">Zeigt, was in einer eigenen Datei an versteckten Infos steckt – z. B. bevor du ein Foto teilst.</p>`;
    if (m.error) return `${drop}<div class="rc-err">${esc(m.error)}</div>`;
    return `${drop}<div class="rc-grid">
      ${card('Datei', 'id', kv([['Name', m.name], ['Grösse', fmtSize(m.size)], ['Typ', m.type], ['Abmessungen', m.dims], ['Zuletzt geändert', dateTime(m.modified)]]))}
      ${card(m.warnings.length ? 'Achtung' : 'Datenschutz', m.warnings.length ? 'warn' : 'ok', m.warnings.length ? `<ul class="rc-warn">${m.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul>${m.image ? '<button class="btn primary small" data-rc-strip>Kopie ohne Metadaten speichern</button>' : ''}` : '<p class="rc-ok">Keine auffälligen persönlichen Infos gefunden.</p>', m.warnings.length ? 'alert' : '')}
      ${m.gps ? card('Aufnahmeort', 'pin', kv([['Koordinaten', `${m.gps.lat.toFixed(5)}, ${m.gps.lon.toFixed(5)}`], ['Höhe', m.gps.alt !== null ? `${Math.round(m.gps.alt)} m` : ''], ['Karte', extLink(`https://www.openstreetmap.org/?mlat=${m.gps.lat}&mlon=${m.gps.lon}#map=15/${m.gps.lat}/${m.gps.lon}`, 'auf OpenStreetMap ansehen'), true]])) : ''}
      ${card(`Metadaten (${m.rows.length})`, 'list', m.rows.length ? kv(m.rows) : '<p class="rc-empty">Keine eingebetteten Metadaten gefunden.</p>', 'wide')}
    </div>`;
  }

  /* ---------------------------------------------------------------- Lokal: Hash */
  function hashHtml() {
    const h = st.hash;
    const cmp = st.hashCmp.trim().toLowerCase();
    const row = (alg, val) => `<tr class="${cmp && cmp === val ? 'match' : ''}"><td>${alg}</td><td><code class="rc-wrap">${esc(val)}</code></td><td>${copyBtn(val)}</td></tr>`;
    const match = h && cmp ? ['md5', 'sha1', 'sha256', 'sha512'].find((k) => h[k] === cmp) : null;
    return `<div class="rc-two"><label class="rc-drop" data-rc-drop="hash"><input type="file" data-rc-file="hash" hidden />${ico('hash', 28)}<b>${st.hashBusy ? 'Wird berechnet …' : 'Datei wählen oder hierher ziehen'}</b><small>Bis 512 MB · bleibt auf deinem PC</small></label>
      <div class="rc-field"><label>… oder Text</label><textarea class="input" rows="4" data-rc-f="hashText" placeholder="Text, dessen Hash du brauchst">${esc(st.hashText)}</textarea><button class="btn small" data-rc-hashtext>Text hashen</button></div></div>
      <div class="rc-field"><label>Erwarteter Hash zum Vergleichen (optional)</label><input class="input" data-rc-f="hashCmp" value="${esc(st.hashCmp)}" placeholder="z. B. SHA-256 von der Download-Seite" /></div>
      ${h ? `${h.label ? `<p class="rc-note">${esc(h.label)} · ${fmtSize(h.size)}</p>` : ''}${cmp ? `<div class="rc-verdict ${match ? 'ok' : 'bad'}">${ico(match ? 'ok' : 'warn', 18)}${match ? `Stimmt überein (${match.toUpperCase()})` : 'Stimmt NICHT überein – Datei könnte verändert oder beschädigt sein.'}</div>` : ''}
        <table class="rc-table rc-hash"><tbody>${row('MD5', h.md5)}${row('SHA-1', h.sha1)}${row('SHA-256', h.sha256)}${row('SHA-512', h.sha512)}</tbody></table>` : ''}`;
  }

  /* ---------------------------------------------------------------- Lokal: E-Mail-Header */
  function parseMail(raw) {
    const head = String(raw).replace(/\r\n/g, '\n').split(/\n\n/)[0];
    const lines = head.split('\n');
    const fields = [];
    for (const l of lines) {
      if (/^[ \t]/.test(l) && fields.length) fields[fields.length - 1][1] += ` ${l.trim()}`;
      else {
        const i = l.indexOf(':');
        if (i > 0) fields.push([l.slice(0, i).trim(), l.slice(i + 1).trim()]);
      }
    }
    const get = (n) => fields.find(([k]) => k.toLowerCase() === n)?.[1] || '';
    const all = (n) => fields.filter(([k]) => k.toLowerCase() === n).map(([, v]) => v);
    const dom = (s) => ((/@([a-z0-9.-]+)/i.exec(s) || [])[1] || '').toLowerCase();
    const base = (d) => d.split('.').slice(-2).join('.');
    const hops = all('received').reverse().map((r) => {
      const [main, when] = r.split(/;\s*(?=[^;]*$)/);
      const ips = (main.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g) || []).filter((ip) => !/^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip));
      return { from: (/from\s+(\S+)/i.exec(main) || [])[1] || '', by: (/by\s+(\S+)/i.exec(main) || [])[1] || '', with: (/with\s+(\S+)/i.exec(main) || [])[1] || '', at: Date.parse(when || '') || 0, ips };
    });
    hops.forEach((h, i) => (h.delay = i && h.at && hops[i - 1].at ? Math.round((h.at - hops[i - 1].at) / 1000) : null));
    const auth = all('authentication-results').join(' ');
    const res = (k) => (new RegExp(`${k}=(\\w+)`, 'i').exec(auth) || [])[1]?.toLowerCase() || '';
    const out = { from: get('from'), to: get('to'), subject: get('subject'), date: get('date'), replyTo: get('reply-to'), returnPath: get('return-path'), messageId: get('message-id'), mailer: get('x-mailer') || get('user-agent'), spf: res('spf') || (/^(\w+)/.exec(get('received-spf')) || [])[1]?.toLowerCase() || '', dkim: res('dkim'), dmarc: res('dmarc'), hops, warnings: [], count: fields.length };
    const fd = dom(out.from);
    if (out.replyTo && dom(out.replyTo) && base(dom(out.replyTo)) !== base(fd)) out.warnings.push(`Antworten gehen an eine andere Domain (${dom(out.replyTo)}) als der Absender (${fd}).`);
    if (out.returnPath && dom(out.returnPath) && fd && base(dom(out.returnPath)) !== base(fd)) out.warnings.push(`Return-Path (${dom(out.returnPath)}) passt nicht zur Absender-Domain – bei Newslettern normal, sonst verdächtig.`);
    if (/fail|softfail/.test(out.spf)) out.warnings.push('SPF-Prüfung fehlgeschlagen – der sendende Server ist für die Domain nicht erlaubt.');
    if (/fail/.test(out.dkim)) out.warnings.push('DKIM-Signatur ungültig – Inhalt oder Absender könnten verändert sein.');
    if (/fail/.test(out.dmarc)) out.warnings.push('DMARC fehlgeschlagen – starkes Zeichen für eine gefälschte Absender-Adresse.');
    if (out.messageId && fd && dom(out.messageId) && base(dom(out.messageId)) !== base(fd)) out.warnings.push(`Message-ID stammt von ${dom(out.messageId)}, nicht von ${fd}.`);
    return out;
  }
  function mailHtml() {
    const m = st.mail;
    const verdict = (k, v) => pill(`${k}: ${v || 'unbekannt'}`, v === 'pass' ? 'ok' : /fail/.test(v) ? 'bad' : 'warn');
    return `<div class="rc-field"><label>Kopfzeilen einer E-Mail einfügen</label><textarea class="input rc-mailraw" rows="8" data-rc-f="mailRaw" placeholder="In Outlook: Datei → Eigenschaften → Internetkopfzeilen. In Gmail: ⋮ → Original anzeigen. Alles kopieren und hier einfügen.">${esc(st.mailRaw)}</textarea><div class="rc-row"><button class="btn primary small" data-rc-mail>Analysieren</button><small class="rc-note">Bleibt auf deinem PC.</small></div></div>
      ${m ? (m.count ? `<div class="rc-badges">${verdict('SPF', m.spf)} ${verdict('DKIM', m.dkim)} ${verdict('DMARC', m.dmarc)}</div>
        ${m.warnings.length ? `<ul class="rc-warn">${m.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul>` : '<p class="rc-ok">Keine Auffälligkeiten in den Kopfzeilen.</p>'}
        <div class="rc-grid">${card('Absender & Empfänger', 'mail', kv([['Von', m.from], ['An', m.to], ['Antwort an', m.replyTo], ['Return-Path', m.returnPath], ['Betreff', m.subject], ['Datum', m.date], ['Message-ID', m.messageId], ['Programm', m.mailer]]), 'wide')}
        ${card(`Weg der Nachricht (${m.hops.length} Stationen)`, 'route', m.hops.length ? `<ol class="rc-hops">${m.hops.map((h) => `<li class="ok"><span class="rc-code">${h.delay !== null && h.delay > 300 ? '!' : '→'}</span><div><b>${esc(h.by || '?')}</b> <small>von ${esc(h.from || '?')}${h.with ? ` · ${esc(h.with)}` : ''}</small><small>${h.at ? dateTime(h.at) : ''}${h.delay !== null ? ` · +${h.delay} s` : ''} ${h.ips.map((ip) => `<button class="rc-link" data-rc-go="${esc(ip)}">${esc(ip)}</button>`).join(' ')}</small></div></li>`).join('')}</ol>` : '<p class="rc-empty">Keine Received-Zeilen.</p>', 'wide')}</div>`
        : '<div class="rc-err">Keine Kopfzeilen erkannt.</div>') : ''}`;
  }

  /* ---------------------------------------------------------------- Seite */
  function bodyHtml() {
    const tab = TABS.find((t) => t[0] === st.tab);
    if (!tab[4]) return st.tab === 'meta' ? metaHtml() : st.tab === 'hash' ? hashHtml() : mailHtml();
    if (!st.target) return `<div class="rc-hello">${ico('search', 34)}<h3>Domain, IP-Adresse oder URL eingeben</h3><p>z. B. <button class="rc-link" data-rc-go="wikipedia.org">wikipedia.org</button>, <button class="rc-link" data-rc-go="1.1.1.1">1.1.1.1</button> oder <button class="rc-link" data-rc-go="https://github.com">https://github.com</button></p><button class="btn small" data-rc-myip>Meine öffentliche IP anzeigen</button></div>`;
    if (st.tab === 'overview') return overviewHtml();
    const fn = { rdap: rdapHtml, dns: dnsHtml, ipinfo: ipHtml, ssl: sslHtml, web: webHtml, redirects: (d) => `<div class="rc-badges">${pill(`${d.hops.length} Station${d.hops.length === 1 ? '' : 'en'}`)} ${pill(d.final === d.start ? 'keine Weiterleitung' : 'leitet weiter', d.final === d.start ? 'ok' : 'warn')}</div>${hopsHtml(d.hops)}${d.final !== d.start ? kv([['Endet bei', d.final]]) : ''}`, subdomains: subHtml, archive: archiveHtml }[st.tab];
    const s = state(st.tab);
    return card(tab[1], tab[2], s.html || (s.data ? fn(s.data) : '<div class="rc-load"><i></i><span>Wird abgefragt …</span></div>'), 'solo');
  }
  function navHtml() {
    let group = '';
    return TABS.map(([id, name, icon, g]) => `${g !== group ? `<small class="rc-group">${(group = g) === 'Ziel' ? 'Domain · IP · URL' : 'Eigene Daten (lokal)'}</small>` : ''}<button class="rc-tab ${st.tab === id ? 'on' : ''}" data-rc-tab="${id}">${ico(icon, 16)}<span>${esc(name)}</span></button>`).join('');
  }
  function html() {
    const tab = TABS.find((t) => t[0] === st.tab);
    return `<div class="rc">
      <form class="rc-search" data-rc-form>${ico('search', 18)}<input class="rc-q" data-rc-f="q" value="${esc(st.q)}" placeholder="Domain, IP-Adresse oder URL – z. B. beispiel.ch" autocomplete="off" spellcheck="false" /><button class="btn primary" type="submit">Analysieren</button></form>
      ${st.err.input ? `<p class="rc-inerr">${esc(st.err.input)}</p>` : ''}
      ${st.recent.length ? `<div class="rc-recent">${st.recent.map((r) => `<button class="${r === st.target ? 'on' : ''}" data-rc-go="${esc(r)}">${esc(r)}</button>`).join('')}</div>` : ''}
      <div class="rc-body"><nav class="rc-nav">${navHtml()}</nav><div class="rc-main">${tab[4] && st.target ? `<div class="rc-target">${pill(st.kind === 'ip' ? 'IP-Adresse' : 'Domain', 'type')}<b>${esc(st.target)}</b>${st.tab !== 'overview' ? `<button class="btn small ghost" data-rc-retry="${st.tab}">Neu laden</button>` : ''}</div>` : ''}<div data-rc-view>${bodyHtml()}</div></div></div>
      <p class="rc-foot">Nur öffentliche, technische Quellen (RDAP, DNS, Zertifikats-Logs, Internet Archive, ipwho.is). Keine Personensuche – nutze die Werkzeuge für eigene Projekte, Sicherheit und Faktenprüfung.</p>
    </div>`;
  }
  // Nur den Inhaltsbereich neu zeichnen, damit das Suchfeld nicht springt
  function paint() {
    if (!active()) return;
    const view = document.querySelector('[data-rc-view]');
    if (!view) return ctx().render();
    view.innerHTML = bodyHtml();
    const tgt = document.querySelector('.rc-target');
    if (!tgt && TABS.find((t) => t[0] === st.tab)?.[4] && st.target) ctx().render();
  }

  /* ---------------------------------------------------------------- Ereignisse */
  document.addEventListener('submit', (e) => {
    if (!active() || !e.target.matches?.('[data-rc-form]')) return;
    e.preventDefault();
    analyze(document.querySelector('[data-rc-f="q"]')?.value);
  });
  document.addEventListener('input', (e) => {
    if (!active()) return;
    const f = e.target.dataset?.rcF;
    if (!f) return;
    st[f] = e.target.value;
    if (f === 'hashCmp' && st.hash) paint();
  });
  async function hashFile(file) {
    if (!file) return;
    st.hashBusy = true;
    paint();
    try {
      st.hash = { ...(await api().hash(new Uint8Array(await file.arrayBuffer()))), label: file.name };
    } catch (e) {
      ctx().toast?.(errText(e));
    }
    st.hashBusy = false;
    paint();
  }
  async function metaFile(file) {
    if (!file) return;
    st.metaFile = file;
    try {
      st.meta = await readMeta(file);
    } catch (e) {
      st.meta = { error: `Datei konnte nicht gelesen werden: ${errText(e)}` };
    }
    paint();
  }
  document.addEventListener('change', (e) => {
    if (!active()) return;
    const which = e.target.dataset?.rcFile;
    if (which === 'hash') hashFile(e.target.files?.[0]);
    if (which === 'meta') metaFile(e.target.files?.[0]);
  });
  document.addEventListener('dragover', (e) => {
    if (active() && e.target.closest?.('[data-rc-drop]')) e.preventDefault();
  });
  document.addEventListener('drop', (e) => {
    const zone = active() && e.target.closest?.('[data-rc-drop]');
    if (!zone) return;
    e.preventDefault();
    const f = e.dataTransfer?.files?.[0];
    if (zone.dataset.rcDrop === 'hash') hashFile(f);
    else metaFile(f);
  });
  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const t = e.target.closest('[data-rc-tab]')?.dataset.rcTab;
    if (t) {
      st.tab = t;
      ctx().render();
      return startTab();
    }
    const go = e.target.closest('[data-rc-go]')?.dataset.rcGo;
    if (go) {
      st.q = go;
      if (!TABS.find((x) => x[0] === st.tab)?.[4]) st.tab = /^[\d.:]+$/.test(go) ? 'ipinfo' : 'overview';
      await analyze(go);
      return ctx().render();
    }
    const retry = e.target.closest('[data-rc-retry]')?.dataset.rcRetry;
    if (retry) return run(retry, { force: true });
    const copy = e.target.closest('[data-rc-copy]')?.dataset.rcCopy;
    if (copy) {
      navigator.clipboard?.writeText(copy);
      return ctx().toast?.('Kopiert.');
    }
    const ext = e.target.closest('[data-rc-ext]')?.dataset.rcExt;
    if (ext) {
      e.preventDefault();
      return window.hub.external ? window.hub.external(ext) : window.open(ext, '_blank');
    }
    if (e.target.closest('[data-rc-myip]')) {
      st.tab = 'ipinfo';
      try {
        const d = await api().run('ipinfo', '');
        st.q = d.ip;
        st.target = d.ip;
        st.kind = 'ip';
        st.res[key('ipinfo')] = d;
      } catch (err) {
        st.err.input = errText(err);
      }
      return ctx().render();
    }
    if (e.target.closest('[data-rc-strip]') && st.metaFile) return stripImage(st.metaFile).catch((err) => ctx().toast?.(errText(err)));
    if (e.target.closest('[data-rc-hashtext]')) {
      if (!st.hashText) return;
      st.hash = { ...(await api().hash(new TextEncoder().encode(st.hashText))), label: 'Text' };
      return paint();
    }
    if (e.target.closest('[data-rc-mail]')) {
      st.mail = parseMail(st.mailRaw);
      return paint();
    }
  });

  // eigenes App-Symbol
  if (window.APP_ART) window.APP_ART[PAGE] = ['#0ea5e9', '#312e81', '<circle cx="21" cy="21" r="10" fill="none" stroke="#fff" stroke-width="3.4"/><path d="m28.5 28.5 9 9" stroke="#fff" stroke-width="4" stroke-linecap="round"/><path d="M15 21h12M21 15c3 3.5 3 8.5 0 12M21 15c-3 3.5-3 8.5 0 12" fill="none" stroke="#fff" stroke-width="1.6" opacity=".85"/>'];
  T.register(PAGE, { nav: 'Recherche', title: 'Recherche', sub: 'Domains, IPs, Webseiten, Dateien', icon: 'search', tint: 'linear-gradient(135deg,#0ea5e9,#312e81)', desc: 'OSINT-Werkzeugkasten: WHOIS/RDAP, DNS, IP-Infos, SSL, Webseiten-Technik, Weiterleitungen, Archiv, Metadaten, Hashes und E-Mail-Header.' }, html);
  window.revRecherche = { parseMail, parseExif };
})();
