'use strict';

/*
 * 2.45 Task-Manager im Hub: Prozesse gruppiert nach Programm (Apps mit Fenster zuerst), Suche,
 * Sortierung, Beenden einzelner Prozesse oder ganzer Programme und ein Leistungsverlauf.
 * Alles lässt sich beenden – nur der Revolution Hub selbst nicht.
 */
(() => {
  const A = window.RevApp;
  if (!A) return;
  const { esc } = A;
  const ID = 'tool-taskman';
  const st = { root: null, data: null, timer: 0, q: '', sort: 'cpu', dir: -1, open: new Set(), sel: null, tab: 'procs', hist: [], err: '', busy: false };

  const mb = (b) => (b >= 1073741824 ? `${(b / 1073741824).toFixed(1)} GB` : `${Math.round(b / 1048576)} MB`);
  const pct = (v) => `${(v || 0).toFixed(1).replace('.', ',')} %`;
  const heat = (v, max) => `background:rgba(255,${Math.round(200 - Math.min(1, v / max) * 140)},70,${Math.min(0.42, (v / max) * 0.5)})`;

  function groups() {
    const map = new Map();
    for (const p of st.data?.procs || []) {
      const key = p.name.toLowerCase();
      if (!map.has(key)) map.set(key, { key, name: p.name, procs: [], cpu: 0, mem: 0, title: '', app: false, own: false, critical: false, path: '' });
      const g = map.get(key);
      g.procs.push(p);
      g.cpu += p.cpu;
      g.mem += p.mem;
      if (p.title && !g.title) g.title = p.title;
      if (p.title) g.app = true;
      if (p.own) g.own = true;
      if (p.critical) g.critical = true;
      if (p.path && !g.path) g.path = p.path;
      if (!p.responding) g.hung = true;
    }
    let list = [...map.values()];
    const q = st.q.trim().toLowerCase();
    if (q) list = list.filter((g) => g.name.toLowerCase().includes(q) || g.title.toLowerCase().includes(q) || g.procs.some((p) => String(p.pid) === q));
    const k = st.sort;
    list.sort((a, b) => (k === 'name' ? a.name.localeCompare(b.name) * -st.dir : (a[k] - b[k]) * st.dir) || a.name.localeCompare(b.name));
    return { apps: list.filter((g) => g.app && !g.own), bg: list.filter((g) => !g.app && !g.own), own: list.filter((g) => g.own) };
  }

  function rowHtml(g) {
    const multi = g.procs.length > 1;
    const open = st.open.has(g.key);
    const sel = st.sel?.kind === 'group' && st.sel.key === g.key;
    const label = g.app && g.title ? `${esc(g.name)}<small>${esc(g.title)}</small>` : esc(g.name);
    let h = `<div class="tm-row ${sel ? 'sel' : ''} ${g.own ? 'own' : ''}" data-tm-group="${esc(g.key)}">
      <span class="tm-name">${multi ? `<button class="tm-exp ${open ? 'open' : ''}" data-tm-exp="${esc(g.key)}">›</button>` : '<i class="tm-exp-sp"></i>'}<span class="tm-ic">${esc(g.name.slice(0, 1).toUpperCase())}</span><span class="tm-n">${label}${multi ? ` <em>(${g.procs.length})</em>` : ''}</span>${g.hung ? '<span class="tm-hung">Reagiert nicht</span>' : ''}${g.own ? '<span class="tm-lock">geschützt</span>' : ''}</span>
      <span class="tm-num" style="${heat(g.cpu, 50)}">${pct(g.cpu)}</span><span class="tm-num" style="${heat(g.mem, 2147483648)}">${mb(g.mem)}</span></div>`;
    if (multi && open) {
      for (const p of g.procs.sort((a, b) => b.cpu - a.cpu || b.mem - a.mem)) {
        const ps = st.sel?.kind === 'proc' && st.sel.pid === p.pid;
        h += `<div class="tm-row sub ${ps ? 'sel' : ''}" data-tm-pid="${p.pid}"><span class="tm-name"><i class="tm-exp-sp"></i><i class="tm-exp-sp"></i><span class="tm-n">${esc(p.title || p.name)} <em>PID ${p.pid}</em></span></span><span class="tm-num">${pct(p.cpu)}</span><span class="tm-num">${mb(p.mem)}</span></div>`;
      }
    }
    return h;
  }

  function spark(vals, color) {
    const n = 60;
    const pts = vals.slice(-n);
    if (pts.length < 2) return '<svg class="tm-spark"></svg>';
    const d = pts.map((v, i) => `${((i + (n - pts.length)) / (n - 1)) * 300},${100 - Math.max(0, Math.min(100, v))}`).join(' L');
    return `<svg class="tm-spark" viewBox="0 0 300 100" preserveAspectRatio="none"><path d="M${d}" fill="none" stroke="${color}" stroke-width="2" vector-effect="non-scaling-stroke"/><path d="M${d} L300,100 L${((n - pts.length) / (n - 1)) * 300},100Z" fill="${color}" opacity=".18"/></svg>`;
  }

  function paint() {
    if (!st.root) return;
    const scroll = st.root.querySelector('.tm-list')?.scrollTop || 0;
    const d = st.data;
    const g = d ? groups() : null;
    const cpuTotal = d ? Math.min(100, d.procs.reduce((s, p) => s + p.cpu, 0)) : 0;
    const ramPct = d ? (d.ramUsed / d.ramTotal) * 100 : 0;
    const selG = st.sel?.kind === 'group' ? g && [...g.apps, ...g.bg, ...g.own].find((x) => x.key === st.sel.key) : null;
    const selP = st.sel?.kind === 'proc' ? d?.procs.find((p) => p.pid === st.sel.pid) : null;
    const canKill = (selG && !selG.own) || (selP && !selP.own);
    const head = (k, label) => `<button class="tm-h ${st.sort === k ? 'on' : ''}" data-tm-sort="${k}">${label}${st.sort === k ? (st.dir < 0 ? ' ↓' : ' ↑') : ''}</button>`;
    st.root.innerHTML = `<div class="rv-card tm">
      <div class="rv-row between">
        <div class="rv-tabs"><button class="${st.tab === 'procs' ? 'on' : ''}" data-tm-tab="procs">Prozesse</button><button class="${st.tab === 'perf' ? 'on' : ''}" data-tm-tab="perf">Leistung</button></div>
        <div class="rv-row"><input class="rv-input" id="tm-q" placeholder="Suchen (Name, Titel, PID)" value="${esc(st.q)}" autocomplete="off" spellcheck="false" style="width:240px"/>
        <button class="rv-btn danger" data-tm-kill ${canKill ? '' : 'disabled'}>Task beenden</button>${selG && selG.procs.length > 1 ? '' : `<button class="rv-btn" data-tm-tree ${canKill ? '' : 'disabled'}>Prozessbaum</button>`}<button class="rv-btn ghost" data-tm-reveal ${(selG?.path || selP?.path) ? '' : 'disabled'}>Speicherort</button></div>
      </div>
      ${st.err ? `<p class="rv-muted" style="color:#ff8a80">${esc(st.err)}</p>` : ''}
      ${!d ? '<div class="rv-empty">Prozesse werden gelesen …</div>' : st.tab === 'perf'
        ? `<div class="tm-perf"><div class="rv-card"><div class="rv-row between"><b>CPU</b><span>${pct(cpuTotal)}</span></div>${spark(st.hist.map((h) => h.cpu), '#0a84ff')}<small class="rv-muted">${d.cores} logische Kerne · ${d.procs.length} Prozesse</small></div>
           <div class="rv-card"><div class="rv-row between"><b>Arbeitsspeicher</b><span>${mb(d.ramUsed)} / ${mb(d.ramTotal)}</span></div>${spark(st.hist.map((h) => h.ram), '#bf5af2')}<small class="rv-muted">${Math.round(ramPct)} % belegt</small></div></div>`
        : `<div class="tm-head"><span>${head('name', 'Name')}</span>${head('cpu', `CPU ${pct(cpuTotal)}`)}${head('mem', `RAM ${Math.round(ramPct)} %`)}</div>
           <div class="tm-list">
             ${g.apps.length ? `<div class="tm-sec">Apps (${g.apps.length})</div>${g.apps.map(rowHtml).join('')}` : ''}
             ${g.bg.length ? `<div class="tm-sec">Hintergrundprozesse (${g.bg.length})</div>${g.bg.map(rowHtml).join('')}` : ''}
             ${g.own.length ? `<div class="tm-sec">Revolution Hub (geschützt)</div>${g.own.map(rowHtml).join('')}` : ''}
             ${!g.apps.length && !g.bg.length ? '<div class="rv-empty">Nichts gefunden.</div>' : ''}
           </div>`}
    </div>`;
    const list = st.root.querySelector('.tm-list');
    if (list) list.scrollTop = scroll;
  }

  async function refresh() {
    if (!st.root) return;
    try {
      st.data = await window.hub.taskman.list();
      st.err = '';
      const cpu = Math.min(100, st.data.procs.reduce((s, p) => s + p.cpu, 0));
      st.hist.push({ cpu, ram: (st.data.ramUsed / st.data.ramTotal) * 100 });
      if (st.hist.length > 120) st.hist.shift();
    } catch (e) {
      st.err = A.errText(e);
    }
    // Während man ins Suchfeld tippt, nicht neu zeichnen (sonst springt der Cursor)
    if (document.activeElement?.id !== 'tm-q') paint();
  }

  async function killSel(tree) {
    const d = st.data;
    let targets = [];
    let label = '';
    let critical = false;
    if (st.sel?.kind === 'group') {
      const g = groups();
      const grp = [...g.apps, ...g.bg].find((x) => x.key === st.sel.key);
      if (!grp) return;
      targets = grp.procs.map((p) => p.pid);
      label = grp.name;
      critical = grp.critical;
    } else if (st.sel?.kind === 'proc') {
      const p = d.procs.find((x) => x.pid === st.sel.pid);
      if (!p) return;
      targets = [p.pid];
      label = `${p.name} (PID ${p.pid})`;
      critical = p.critical;
    }
    if (!targets.length) return;
    if (critical && !window.confirm(`${label} ist ein Windows-Systemprozess. Beenden kann Windows abstürzen lassen. Trotzdem beenden?`)) return;
    let ok = 0;
    let last = '';
    for (const pid of targets) {
      try {
        await window.hub.taskman.kill(pid, tree);
        ok += 1;
      } catch (e) {
        last = A.errText(e);
      }
    }
    A.toast(ok ? `${label} beendet.` : last || 'Konnte nicht beendet werden.', ok ? '' : 'error');
    st.sel = null;
    setTimeout(refresh, 400);
  }

  function onClick(e) {
    if (!st.root?.contains(e.target)) return;
    const q = (s) => e.target.closest(s);
    const tab = q('[data-tm-tab]')?.dataset.tmTab;
    if (tab) {
      st.tab = tab;
      return paint();
    }
    const sort = q('[data-tm-sort]')?.dataset.tmSort;
    if (sort) {
      st.dir = st.sort === sort ? -st.dir : sort === 'name' ? 1 : -1;
      st.sort = sort;
      return paint();
    }
    const exp = q('[data-tm-exp]')?.dataset.tmExp;
    if (exp) {
      st.open.has(exp) ? st.open.delete(exp) : st.open.add(exp);
      return paint();
    }
    if (q('[data-tm-kill]')) return killSel(false);
    if (q('[data-tm-tree]')) return killSel(true);
    if (q('[data-tm-reveal]')) {
      const g = st.sel?.kind === 'group' ? groups() : null;
      const file = st.sel?.kind === 'group' ? [...g.apps, ...g.bg, ...g.own].find((x) => x.key === st.sel.key)?.path : st.data?.procs.find((p) => p.pid === st.sel?.pid)?.path;
      if (file) window.hub.taskman.reveal(file);
      return;
    }
    const pid = q('[data-tm-pid]')?.dataset.tmPid;
    if (pid) {
      st.sel = { kind: 'proc', pid: Number(pid) };
      return paint();
    }
    const grp = q('[data-tm-group]')?.dataset.tmGroup;
    if (grp) {
      st.sel = { kind: 'group', key: grp };
      return paint();
    }
  }
  function onKey(e) {
    if (!st.root || !document.contains(st.root)) return;
    if (e.key === 'Delete' && document.activeElement?.id !== 'tm-q' && st.sel) killSel(false);
  }
  document.addEventListener('click', onClick);
  document.addEventListener('dblclick', (e) => {
    const exp = st.root?.contains(e.target) && e.target.closest('[data-tm-group]')?.dataset.tmGroup;
    if (exp) {
      st.open.has(exp) ? st.open.delete(exp) : st.open.add(exp);
      paint();
    }
  });
  document.addEventListener('keydown', onKey);
  document.addEventListener('input', (e) => {
    if (e.target.id !== 'tm-q' || !st.root?.contains(e.target)) return;
    st.q = e.target.value;
    clearTimeout(st.qTimer);
    st.qTimer = setTimeout(() => {
      const pos = e.target.selectionStart;
      paint();
      const el = st.root.querySelector('#tm-q');
      el?.focus();
      el?.setSelectionRange(pos, pos);
    }, 180);
  });

  A.define(
    ID,
    { nav: 'Task-Manager', title: 'Task-Manager', sub: 'Prozesse ansehen und beenden', icon: 'grid', tint: 'linear-gradient(135deg,#34d399,#065f46)', desc: 'Alle laufenden Programme mit CPU und Arbeitsspeicher – Tasks beenden, Prozessbäume schließen, Speicherort öffnen. Der Revolution Hub selbst ist geschützt.' },
    {
      mount(root) {
        st.root = root;
        paint();
        refresh();
        clearInterval(st.timer);
        st.timer = setInterval(refresh, 2000);
      },
      unmount() {
        clearInterval(st.timer);
        st.root = null;
      },
    },
  );
})();
