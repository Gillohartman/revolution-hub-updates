'use strict';
/**
 * Lüftersteuerung wie Fan Control (2.45.3): spricht mit dem Helfer RevFans.exe (vendor/fans),
 * der mit Administratorrechten über LibreHardwareMonitorLib + PawnIO alle Lüfter liest und die
 * Lüfter-Anschlüsse (Mainboard, Grafikkarte) steuert. Verbindung über eine Named Pipe, die nur
 * der angemeldete Benutzer öffnen darf. Kurven laufen im Helfer selbst.
 */
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

class FanControl {
  constructor({ exePaths, configFile }) {
    this.exePaths = exePaths;
    this.configFile = configFile;
    this.pipe = `revhub-fans-${crypto.createHash('sha1').update(os.userInfo().username + os.hostname()).digest('hex').slice(0, 10)}`;
    this.sock = null;
    this.queue = [];
    this.buf = '';
    this.starting = null;
  }

  exe() {
    return this.exePaths.find((p) => p && fs.existsSync(p)) || null;
  }

  pawnio() {
    return new Promise((resolve) => execFile('sc.exe', ['query', 'PawnIO'], { windowsHide: true, timeout: 8000 }, (err, out) => resolve(/RUNNING|STOPPED/i.test(String(out || '')))));
  }

  connect() {
    return new Promise((resolve, reject) => {
      const sock = net.connect(`\\\\.\\pipe\\${this.pipe}`);
      const fail = (e) => reject(e);
      sock.once('error', fail);
      sock.once('connect', () => {
        sock.off('error', fail);
        sock.on('data', (d) => this.onData(d));
        sock.on('error', () => this.drop());
        sock.on('close', () => this.drop());
        this.sock = sock;
        resolve(sock);
      });
    });
  }

  drop() {
    this.sock = null;
    for (const q of this.queue.splice(0)) q.reject(new Error('Verbindung zum Lüfter-Helfer verloren.'));
  }

  onData(d) {
    this.buf += d;
    let i;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, i);
      this.buf = this.buf.slice(i + 1);
      const q = this.queue.shift();
      if (!q) continue;
      try { q.resolve(JSON.parse(line)); } catch (e) { q.reject(e); }
    }
  }

  async request(msg) {
    if (!this.sock) await this.connect();
    return new Promise((resolve, reject) => {
      this.queue.push({ resolve, reject });
      this.sock.write(`${JSON.stringify(msg)}\n`);
      setTimeout(() => reject(new Error('Der Lüfter-Helfer antwortet nicht.')), 10000);
    });
  }

  running() {
    return new Promise((resolve) => {
      const s = net.connect(`\\\\.\\pipe\\${this.pipe}`);
      s.once('connect', () => { s.destroy(); resolve(true); });
      s.once('error', () => resolve(false));
    });
  }

  /** Startet den Helfer mit Administratorrechten (Windows fragt nach). */
  async start() {
    if (this.sock || (await this.running())) return this.list();
    if (this.starting) return this.starting;
    const exe = this.exe();
    if (!exe) throw new Error('Der Lüfter-Helfer fehlt in dieser Installation.');
    if (!(await this.pawnio())) throw new Error('Der PawnIO-Treiber ist nicht installiert – ohne ihn kann Windows keine Lüfter steuern.');
    this.starting = (async () => {
      fs.mkdirSync(path.dirname(this.configFile), { recursive: true });
      const q = (s) => `'${String(s).replace(/'/g, "''")}'`;
      const script = `$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value; Start-Process -FilePath ${q(exe)} -ArgumentList @('--pipe',${q(this.pipe)},'--sid',$sid,'--config',${q(`"${this.configFile}"`)}) -Verb RunAs -WindowStyle Hidden`;
      await new Promise((resolve, reject) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout: 120000 }, (err, _o, errOut) => {
        if (err) return reject(new Error(/abgebrochen|canceled|cancelled/i.test(String(errOut)) ? 'Die Administrator-Abfrage wurde abgelehnt.' : String(errOut || err.message).trim().split(/\r?\n/)[0]));
        resolve();
      }));
      for (let i = 0; i < 40; i++) {
        if (await this.running()) return this.list();
        await new Promise((r) => setTimeout(r, 250));
      }
      throw new Error('Der Lüfter-Helfer ist nicht gestartet.');
    })().finally(() => { this.starting = null; });
    return this.starting;
  }

  /** PawnIO (offizieller, signierter Installer von namazso) herunterladen, Signatur prüfen, mit Adminrechten installieren. */
  async installDriver() {
    if (await this.pawnio()) return { ok: true, already: true };
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'revhub-pawnio-'));
    const file = path.join(dir, 'PawnIO_setup.exe');
    const script = [
      "$ProgressPreference='SilentlyContinue'",
      `Invoke-WebRequest 'https://github.com/namazso/PawnIO.Setup/releases/download/2.2.0/PawnIO_setup.exe' -OutFile '${file}' -UseBasicParsing`,
      `$sig = Get-AuthenticodeSignature '${file}'`,
      "if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'CN=namazso\\.eu') { Write-Error 'Signatur des Treibers ungültig'; exit 3 }",
      `$p = Start-Process '${file}' -ArgumentList '-install','-silent' -Verb RunAs -Wait -PassThru`,
      'exit $p.ExitCode',
    ].join('; ');
    try {
      await new Promise((resolve, reject) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout: 300000 }, (err, _o, errOut) => {
        if (err) return reject(new Error(/abgebrochen|canceled|cancelled/i.test(String(errOut)) ? 'Die Administrator-Abfrage wurde abgelehnt.' : String(errOut || err.message).trim().split(/\r?\n/)[0] || 'Installation fehlgeschlagen.'));
        resolve();
      }));
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
    return { ok: await this.pawnio() };
  }

  list() { return this.request({ cmd: 'list' }); }

  setConfig(config) { return this.request({ cmd: 'config', config }); }

  async status() {
    return { running: Boolean(this.sock) || (await this.running()), pawnio: await this.pawnio(), helper: Boolean(this.exe()) };
  }

  async stop() {
    try { await this.request({ cmd: 'quit' }); } catch { /* läuft schon nicht mehr */ }
    this.sock?.destroy();
    this.drop();
  }
}

module.exports = { FanControl };
