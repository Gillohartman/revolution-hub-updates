'use strict';

/**
 * Orbit Island is a native WPF app (C#). The hub ships its build and runs it as a
 * background companion: start, stop and a live "running" status.
 */

const { app } = require('electron');
const { spawn, execFile } = require('child_process');
const fs = require('fs');
const { takeOverStandalone } = require('./standalone');
const path = require('path');

const EXE_NAME = 'OrbitIsland.exe';

/**
 * 2.45.11: Island-Dateien aus einem Update (resources\orbit-pending) nach resources\orbit kopieren.
 * Klappt das nicht (Datei gesperrt), bleibt der Ordner liegen und wird beim nächsten
 * Island-Start erneut eingespielt – so läuft nie still die alte Island weiter.
 */
function applyPendingIsland(resources = process.resourcesPath) {
  const pending = resources ? path.join(resources, 'orbit-pending') : '';
  if (!pending || !fs.existsSync(pending)) return { applied: false, error: '' };
  const target = path.join(resources, 'orbit');
  let count = 0;
  const copy = (from, to) => {
    for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
      const src = path.join(from, entry.name);
      const dst = path.join(to, entry.name);
      if (entry.isDirectory()) {
        fs.mkdirSync(dst, { recursive: true });
        copy(src, dst);
      } else {
        fs.copyFileSync(src, dst);
        count += 1;
      }
    }
  };
  try {
    fs.mkdirSync(target, { recursive: true });
    copy(pending, target);
    fs.rmSync(pending, { recursive: true, force: true });
    console.log(`[orbit] Island aktualisiert (${count} Dateien)`);
    return { applied: true, error: '' };
  } catch (error) {
    return { applied: false, error: String(error?.message || error) };
  }
}

class OrbitIsland {
  constructor(onChange) {
    this.onChange = onChange;
    this.running = false;
    this.startedByHub = false;
    this.timer = null;
    // 2.45.9: Eine Test-Instanz (eigenes Profil) fasst die Island nie an – sonst beendet sie die Island
    // des installierten Hubs und startet ihre eigene (anderes Design, ständiges Hin und Her).
    this.disabled = Boolean(process.env.REVOLUTION_HUB_PROFILE);
  }

  exePath() {
    const candidates = [
      path.join(process.resourcesPath || '', 'orbit', EXE_NAME),
      path.join(app.getAppPath(), '..', 'orbit', EXE_NAME),
      path.join(app.getAppPath(), 'vendor', 'orbit', EXE_NAME),
    ];
    return candidates.find((file) => fs.existsSync(file)) || null;
  }

  available() {
    return process.platform === 'win32' && Boolean(this.exePath());
  }

  /**
   * Face ID hat Vorrang vor der Facecam: die Island schreibt camera-request.json, sobald sie
   * die Kamera braucht. Dann pausiert der Hub die Facecam des Gaming Hubs (und gibt sie danach zurück).
   */
  watchCamera(onChange) {
    const file = path.join(path.dirname(this.settingsFile()), 'camera-request.json');
    let last = null;
    const check = () => {
      let active = false;
      try {
        const j = JSON.parse(fs.readFileSync(file, 'utf8'));
        active = Boolean(j.active) && this.running !== false;
      } catch {
        active = false;
      }
      if (this.cameraHold && Date.now() < this.cameraHold) active = true;
      if (active !== last) {
        last = active;
        onChange(active);
      }
    };
    check();
    setInterval(check, 1000).unref?.();
  }

  /** Kamera für die Face-ID-Einrichtung sofort freigeben (bis die Island übernimmt). */
  holdCamera(ms = 20000) {
    this.cameraHold = Date.now() + ms;
  }

  /* ------------------------------------------------------- Mitte des Monitors */

  /**
   * 2.45.11: Die Island richtet „oben mittig“ am Arbeitsbereich aus. Steht die Windows-Taskleiste
   * seitlich (z. B. rechts, 48 px), ist dessen Mitte verschoben – die Island sass ~24 px zu weit links.
   * Der Hub gleicht das über den seitlichen Versatz aus. Den ausgeglichenen Teil merkt er sich in
   * hub-center.json; Einstellungsseite und dein eigener Versatz sehen ihn nicht.
   */
  centerFile() {
    return path.join(path.dirname(this.settingsFile()), 'hub-center.json');
  }

  appliedCenter() {
    try {
      return Number(JSON.parse(fs.readFileSync(this.centerFile(), 'utf8')).applied) || 0;
    } catch {
      return 0;
    }
  }

  /** Gerätenamen (\\.\DISPLAYn) von links nach rechts – in derselben Reihenfolge wie Electrons Bildschirme. */
  screenNames() {
    if (this.screenNameCache && Date.now() - this.screenNameCache.at < 15000) return Promise.resolve(this.screenNameCache.names);
    return new Promise((resolve) => {
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::AllScreens | Sort-Object { $_.Bounds.X } | ForEach-Object { $_.DeviceName }"], { windowsHide: true, timeout: 8000 }, (error, stdout) => {
        const names = error ? [] : String(stdout).split(/\r?\n/).map((l) => l.trim().toLowerCase()).filter(Boolean);
        this.screenNameCache = { at: Date.now(), names };
        resolve(names);
      });
    });
  }

  /** Abstand (logische px) zwischen Monitor-Mitte und Mitte des Arbeitsbereichs. */
  async centerCorrection(monitorId) {
    const { screen } = require('electron');
    let display = screen.getPrimaryDisplay();
    if (monitorId) {
      const displays = screen.getAllDisplays().slice().sort((a, b) => a.bounds.x - b.bounds.x);
      const names = await this.screenNames();
      const i = names.indexOf(String(monitorId).toLowerCase());
      if (i < 0 || names.length !== displays.length) return null; // unklar: nichts verändern
      display = displays[i];
    }
    const { bounds: b, workArea: w } = display;
    return Math.round(b.x + b.width / 2 - (w.x + w.width / 2));
  }

  /** Versatz so setzen, dass „oben mittig“ die Mitte des ganzen Monitors ist. */
  async syncCenter() {
    if (this.disabled || process.platform !== 'win32') return false;
    const raw = this.readRawSettings();
    if (!raw) return false;
    const pos = raw.Position || {};
    const centered = !pos.Anchor || pos.Anchor === 'TopCenter';
    const want = centered ? await this.centerCorrection(pos.MonitorId || '') : 0;
    const applied = this.appliedCenter();
    if (want === null || want === applied) return false;
    const own = (Number(pos.HorizontalOffset) || 0) - applied;
    this.writeRaw({ ...raw, Position: { ...pos, HorizontalOffset: own + want } });
    fs.writeFileSync(this.centerFile(), JSON.stringify({ applied: want }));
    return true;
  }

  watch() {
    if (this.timer) return;
    const tick = () => this.refresh().catch(() => {});
    tick();
    // Taskleiste verschoben, Monitor an/ab, Auflösung geändert → Mitte neu ausgleichen
    try {
      const { screen } = require('electron');
      let pending = null;
      const resync = () => {
        clearTimeout(pending);
        pending = setTimeout(() => this.syncCenter().catch(() => {}), 1500);
      };
      for (const event of ['display-metrics-changed', 'display-added', 'display-removed']) screen.on(event, resync);
      resync();
    } catch {
      /* kein Bildschirm-Zugriff */
    }
    this.timer = setInterval(tick, 4000);
    this.timer.unref?.();
    this.watchForeign();
  }

  /**
   * Die alte Einzelinstallation darf sich nicht neben dem Hub öffnen – auch nicht über
   * eine alte Verknüpfung, ein Token oder einen zweiten Start. Der Wachhund beendet nur
   * OrbitIsland-Prozesse außerhalb des Hub-Ordners, niemals die Island des Hubs.
   */
  watchForeign() {
    if (this.disabled || this.foreignTimer || process.platform !== 'win32' || !app.isPackaged) return;
    const local = process.env.LOCALAPPDATA || '';
    const candidates = [path.join(local, 'Programs', 'OrbitIsland', EXE_NAME), path.join(local, 'Programs', 'PulseIsland', EXE_NAME)];
    if (!candidates.some((file) => fs.existsSync(file))) return;
    const hub = path.dirname(process.execPath) + path.sep;
    const quoted = `'${hub.replace(/'/g, "''")}'`;
    const script = `$hub = ${quoted}; Get-CimInstance Win32_Process | Where-Object { $_.Name -eq '${EXE_NAME}' -and $_.ExecutablePath -and -not $_.ExecutablePath.StartsWith($hub, [StringComparison]::OrdinalIgnoreCase) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force; "killed|" + $_.ExecutablePath }`;
    const killForeign = () =>
      execFile(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')],
        { windowsHide: true, timeout: 15000 },
        (_error, stdout) => {
          if (String(stdout || '').trim()) console.log('[orbit] alte Island blockiert');
        },
      );
    // Nur die Prozessliste prüfen; PowerShell erst, wenn eine zweite Island läuft
    // oder die Hub-Island noch nicht läuft. Das ist im Leerlauf sehr günstig.
    const run = () =>
      execFile('tasklist', ['/FI', `IMAGENAME eq ${EXE_NAME}`, '/FO', 'CSV', '/NH'], { windowsHide: true }, (error, stdout) => {
        if (error) return;
        const count = String(stdout || '').split(/\r?\n/).filter((line) => line.toLowerCase().includes(EXE_NAME.toLowerCase())).length;
        if (count > 1 || (count === 1 && !this.child)) killForeign();
      });
    run();
    this.foreignTimer = setInterval(run, 8000);
    this.foreignTimer.unref?.();
  }

  refresh() {
    return new Promise((resolve) => {
      if (process.platform !== 'win32') return resolve(false);
      execFile('tasklist', ['/FI', `IMAGENAME eq ${EXE_NAME}`, '/FO', 'CSV', '/NH'], { windowsHide: true }, (error, stdout) => {
        const running = !error && stdout.toLowerCase().includes(EXE_NAME.toLowerCase());
        // Läuft eine Island, die nicht der Hub gestartet hat (z. B. alter Autostart),
        // wird sie durch die Island aus dem Hub ersetzt.
        if (running && !this.child && this.autoReplace && !this.replacing && !this.disabled) {
          this.replacing = true;
          this.start().catch(() => {}).finally(() => { this.replacing = false; });
        }
        if (running !== this.running) {
          this.running = running;
          if (!running) this.startedByHub = false;
          this.onChange();
        }
        resolve(running);
      });
    });
  }

  async start() {
    if (this.disabled) return false;
    const exe = this.exePath();
    if (!exe) throw new Error('Revulution Island ist in dieser Installation nicht enthalten.');
    // Eine alte Einzel-Installation der Island hält sonst die Einzel-Instanz-Sperre –
    // dann liefe deren Prozess statt der Island aus dem Hub.
    if (this.child) return true;
    if (Date.now() - (this.tookOverAt || 0) > 15000) await this.takeOver();
    // Läuft noch eine Island, die nicht vom Hub gestartet wurde (z. B. über den Windows-
    // Autostart), wird sie durch die Island als Teil des Hubs ersetzt.
    if (await this.refresh()) {
      await new Promise((resolve) => execFile('taskkill', ['/IM', EXE_NAME, '/T', '/F'], { windowsHide: true }, () => resolve()));
      await new Promise((resolve) => setTimeout(resolve, 700));
    }
    // Ein Update konnte die Island nicht ersetzen, weil sie lief: jetzt (gestoppt) nachholen.
    if (app.isPackaged) {
      const pending = applyPendingIsland(process.resourcesPath);
      if (pending.error) console.error('[orbit] Island-Update noch offen:', pending.error);
    }
    this.ensureSettingsFile();
    await this.syncCenter().catch(() => {});
    // Nicht losgelöst starten: So gehört die Island zum Hub-Prozess (Task-Manager zeigt
    // sie unter Revolution Hub) und endet mit ihm.
    const child = spawn(exe, ['--startup'], { cwd: path.dirname(exe), stdio: 'ignore', windowsHide: false });
    child.on('error', (error) => console.error('[orbit] start failed', error));
    child.on('exit', () => {
      if (this.child === child) this.child = null;
      setTimeout(() => this.refresh(), 300);
    });
    this.child = child;
    this.startedByHub = true;
    setTimeout(() => this.refresh(), 1500);
    return true;
  }

  /** Alte Einzel-Apps beenden, ihren Autostart auf den Hub umbiegen. */
  async takeOver() {
    this.tookOverAt = Date.now();
    return takeOverStandalone({ islandExe: this.exePath() || '' });
  }

  stop() {
    if (this.disabled) return Promise.resolve(false);
    return new Promise((resolve) => {
      if (process.platform !== 'win32') return resolve(false);
      execFile('taskkill', ['/IM', EXE_NAME, '/T', '/F'], { windowsHide: true }, () => {
        this.startedByHub = false;
        setTimeout(() => this.refresh().then(() => resolve(true)), 600);
      });
    });
  }

  /* -------------------------------------------------------------- settings */

  settingsFile() {
    return path.join(process.env.APPDATA || app.getPath('appData'), 'PulseIsland', 'settings.json');
  }

  defaults() {
    return require('./orbit-defaults.json');
  }

  /** Without a settings file the island opens its own first-run window; the hub has the settings. */
  ensureSettingsFile() {
    if (this.disabled) return;
    const file = this.settingsFile();
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      const settings = fs.existsSync(file)
        ? JSON.parse(fs.readFileSync(file, 'utf8').replace(/^﻿/, ''))
        : { ...this.defaults().settings, FirstRun: false };
      if (settings.Dock?.Enabled === false && Array.isArray(settings.Dock.Widgets) && settings.Dock.Widgets.length === 0) return;
      settings.Dock = { ...(settings.Dock || {}), Enabled: false, Widgets: [] };
      fs.writeFileSync(file, JSON.stringify(settings, null, 2));
    } catch {
      /* the island falls back to its own defaults */
    }
  }

  /** settings.json genau so, wie die Island sie liest. */
  readRawSettings() {
    try {
      return JSON.parse(fs.readFileSync(this.settingsFile(), 'utf8').replace(/^\uFEFF/, ''));
    } catch {
      return null;
    }
  }

  writeRaw(settings) {
    const file = this.settingsFile();
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(`${file}.tmp`, JSON.stringify({ ...settings, LastSavedUtc: new Date().toISOString() }, null, 2));
    fs.renameSync(`${file}.tmp`, file);
  }

  /** Einstellungen f\u00FCr die Hub-Seite: der seitliche Versatz ohne den Mitte-Ausgleich (siehe syncCenter). */
  readSettings() {
    const settings = this.readRawSettings();
    if (!settings) return { exists: false, settings: null };
    const applied = this.appliedCenter();
    if (applied && settings.Position) settings.Position = { ...settings.Position, HorizontalOffset: (Number(settings.Position.HorizontalOffset) || 0) - applied };
    return { exists: true, settings };
  }

  /** Bundled live wallpapers of the island (same set as the hub). */
  wallpapers() {
    const exe = this.exePath();
    if (!exe) return [];
    const dir = path.join(path.dirname(exe), 'Assets', 'Wallpapers');
    try {
      return fs
        .readdirSync(dir)
        .filter((name) => /\.(mp4|webm|mov|wmv|m4v)$/i.test(name))
        .map((name) => ({ name: name.replace(/^live-/, '').replace(/\.[^.]+$/, ''), path: path.join(dir, name) }));
    } catch {
      return [];
    }
  }

  wallpaperPath(id) {
    return this.wallpapers().find((entry) => entry.name === id)?.path || '';
  }

  /**
   * Writes a change set into settings.json. The running island watches that file and
   * merges the new values into its live settings, so nothing restarts or flickers.
   * Only the changed keys are written; values the island set itself stay untouched.
   */
  async writeSettings(patch) {
    if (this.disabled) return false; // Test-Instanz: Einstellungen der echten Island nicht ändern
    const file = this.settingsFile();
    const current = this.readRawSettings() || { ...this.defaults().settings, FirstRun: false };
    // Die Hub-Seite kennt nur deinen eigenen Versatz – den Mitte-Ausgleich wieder dazurechnen.
    const applied = this.appliedCenter();
    if (applied && typeof patch?.Position?.HorizontalOffset === 'number') patch = { ...patch, Position: { ...patch.Position, HorizontalOffset: patch.Position.HorizontalOffset + applied } };
    const merge = (base, change) => {
      const out = { ...base };
      for (const [key, value] of Object.entries(change || {})) {
        out[key] = value && typeof value === 'object' && !Array.isArray(value) && base?.[key] && typeof base[key] === 'object' && !Array.isArray(base[key]) ? merge(base[key], value) : value;
      }
      return out;
    };
    const next = { ...merge(current, patch), LastSavedUtc: new Date().toISOString() };
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(`${file}.tmp`, JSON.stringify(next, null, 2));
    fs.renameSync(`${file}.tmp`, file);
    // Monitor oder Ausrichtung geändert → Mitte neu ausgleichen
    if (patch?.Position && ('MonitorId' in patch.Position || 'Anchor' in patch.Position)) this.syncCenter().catch(() => {});
    return true;
  }

  /* ----------------------------------------------------------------- inbox */

  inboxDir() {
    return path.join(path.dirname(this.settingsFile()), 'inbox');
  }

  /**
   * Drops a message into the island's inbox (it watches the folder). Used for the hub's
   * own notifications and for commands such as opening the Face ID scan.
   */
  post(message) {
    try {
      const dir = this.inboxDir();
      fs.mkdirSync(dir, { recursive: true });
      const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      fs.writeFileSync(path.join(dir, `${name}.tmp`), JSON.stringify(message));
      fs.renameSync(path.join(dir, `${name}.tmp`), path.join(dir, `${name}.json`));
      return true;
    } catch {
      return false;
    }
  }

  /** Runs a command in the island ("face", "newevent", "settings"), starting it if needed. */
  async command(name) {
    if (name === 'face') this.holdCamera(90000);
    this.post({ command: name });
    if (!(await this.refresh())) await this.start();
    return true;
  }

  /** Called when the hub quits: only close the island if the hub started it. */
  shutdown() {
    clearInterval(this.timer);
    clearInterval(this.foreignTimer);
    if (this.startedByHub && process.platform === 'win32') {
      try {
        require('child_process').execFileSync('taskkill', ['/IM', EXE_NAME, '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
      } catch {
        /* already closed */
      }
    }
  }
}

module.exports = { OrbitIsland, applyPendingIsland };
