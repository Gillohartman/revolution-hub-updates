'use strict';

/* 2.38: weitere Desktop-Widgets – PC-Laufzeit, Notizen, To-do, Rechner, Pixel-Pflanze,
   Mikrofon-Monitor, Live-Kamera, Soundboard und Schnellzugriff.
   Notizen/To-do/Pflanze liegen im localStorage, damit alle Monitore dasselbe zeigen. */
(() => {
  const $ = (id) => document.getElementById(id);
  const card = (k) => document.querySelector(`.dw[data-w="${k}"]`);
  const shown = (k) => {
    const el = card(k);
    return Boolean(el && !el.hidden && !el.classList.contains('away'));
  };
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const load = (k, d) => {
    try {
      return JSON.parse(localStorage.getItem(k)) ?? d;
    } catch {
      return d;
    }
  };
  const save = (k, v) => localStorage.setItem(k, JSON.stringify(v));

  /* Tastatur: nur solange ein Feld den Fokus hat, darf das Widget-Fenster Tasten bekommen */
  document.addEventListener('focusin', (e) => {
    if (e.target.matches('textarea, input')) window.hub.widgetsKeyboard?.(true);
  });
  document.addEventListener('focusout', (e) => {
    if (e.target.matches('textarea, input')) setTimeout(() => !document.activeElement?.matches?.('textarea, input') && window.hub.widgetsKeyboard?.(false), 60);
  });
  let calcFocus = false;
  document.addEventListener('pointerdown', (e) => {
    // 2.45.12: schon beim Antippen eines Textfelds die Tastatur holen – im nicht fokussierbaren
    // Widget-Fenster kam „focusin“ oft gar nicht an, dann ging Tippen in Notizen/To-do nicht.
    const field = e.target.closest('textarea, input:not([type=range]):not([type=checkbox]):not([type=color])');
    if (field) {
      window.hub.widgetsKeyboard?.(true);
      setTimeout(() => { if (document.activeElement !== field) field.focus(); }, 80);
      return;
    }
    const inCalc = Boolean(e.target.closest('.dw-calc'));
    if (inCalc !== calcFocus) {
      calcFocus = inCalc;
      window.hub.widgetsKeyboard?.(inCalc);
    }
  });

  /* ------------------------------------------------------------ PC-Laufzeit */
  let upBase = null;
  async function paintUptime() {
    if (!shown('uptime')) return;
    if (!upBase || Date.now() - upBase.at > 10 * 60000) {
      const s = await window.hub.widgetUptime?.().catch(() => null);
      if (s != null) upBase = { at: Date.now(), secs: Number(s) };
    }
    if (!upBase) return;
    const secs = upBase.secs + (Date.now() - upBase.at) / 1000;
    const d = Math.floor(secs / 86400);
    const h = Math.floor((secs % 86400) / 3600);
    const m = Math.floor((secs % 3600) / 60);
    $('dw-up-big').innerHTML = `${d ? `${d}<small>T</small> ` : ''}${h}<small>h</small> ${String(m).padStart(2, '0')}<small>m</small>`;
    const since = new Date(Date.now() - secs * 1000);
    $('dw-up-since').textContent = `seit ${since.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' })}, ${since.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
  }

  /* ------------------------------------------------------------ Notizen */
  const notes = $('dw-notes-t');
  notes.value = load('dw-notes', '');
  let noteT = 0;
  notes.addEventListener('input', () => {
    clearTimeout(noteT);
    noteT = setTimeout(() => save('dw-notes', notes.value), 300);
  });

  /* ------------------------------------------------------------ To-do */
  function paintTodo() {
    const list = load('dw-todo', []);
    $('dw-todo-n').textContent = list.length ? `${list.filter((t) => t.done).length}/${list.length}` : '';
    $('dw-todo-list').innerHTML = list.length
      ? list.map((t, i) => `<div class="dw-todo-row ${t.done ? 'done' : ''}" data-nodrag><button class="dw-chk" data-todo-t="${i}">${t.done ? '✓' : ''}</button><span>${esc(t.text)}</span><button class="dw-x-del" data-todo-d="${i}" title="Löschen">✕</button></div>`).join('')
      : '<div class="dw-empty">Nichts zu tun 🎉</div>';
  }
  $('dw-todo-in').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || !e.target.value.trim()) return;
    save('dw-todo', [...load('dw-todo', []), { text: e.target.value.trim().slice(0, 120), done: false }].slice(-30));
    e.target.value = '';
    paintTodo();
  });
  $('dw-todo-list').addEventListener('click', (e) => {
    const list = load('dw-todo', []);
    const t = e.target.closest('[data-todo-t]');
    const d = e.target.closest('[data-todo-d]');
    if (t) list[Number(t.dataset.todoT)].done = !list[Number(t.dataset.todoT)].done;
    else if (d) list.splice(Number(d.dataset.todoD), 1);
    else return;
    save('dw-todo', list);
    paintTodo();
  });

  /* ------------------------------------------------------------ Rechner (wie ein Taschenrechner) */
  const KEYS = ['C', '±', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '0', ',', '⌫', '='];
  $('dw-calc-k').innerHTML = KEYS.map((k) => `<button data-k="${k}" class="${'÷×−+='.includes(k) ? 'op' : 'C±%'.includes(k) ? 'fn' : ''}">${k}</button>`).join('');
  const calc = { cur: '0', acc: null, op: null, fresh: false };
  const num = (s) => Number(String(s).replace(',', '.'));
  const show = (v) => {
    if (!Number.isFinite(v)) return 'Fehler';
    const r = Math.round(v * 1e10) / 1e10;
    return String(r).replace('.', ',');
  };
  function calcOp(a, b, op) {
    return op === '+' ? a + b : op === '−' ? a - b : op === '×' ? a * b : op === '÷' ? a / b : b;
  }
  function press(k) {
    if (/^[0-9]$/.test(k)) {
      calc.cur = calc.fresh || calc.cur === '0' ? k : calc.cur.length < 14 ? calc.cur + k : calc.cur;
      calc.fresh = false;
    } else if (k === ',') {
      if (calc.fresh) calc.cur = '0';
      if (!calc.cur.includes(',')) calc.cur += ',';
      calc.fresh = false;
    } else if (k === 'C') Object.assign(calc, { cur: '0', acc: null, op: null, fresh: false });
    else if (k === '⌫') calc.cur = calc.cur.length > 1 ? calc.cur.slice(0, -1) : '0';
    else if (k === '±') calc.cur = calc.cur.startsWith('-') ? calc.cur.slice(1) : calc.cur === '0' ? '0' : `-${calc.cur}`;
    else if (k === '%') calc.cur = show(num(calc.cur) / 100);
    else if ('÷×−+'.includes(k)) {
      if (calc.op && !calc.fresh) calc.cur = show(calcOp(calc.acc, num(calc.cur), calc.op));
      calc.acc = num(calc.cur);
      calc.op = k;
      calc.fresh = true;
    } else if (k === '=') {
      if (calc.op) calc.cur = show(calcOp(calc.acc, num(calc.cur), calc.op));
      Object.assign(calc, { acc: null, op: null, fresh: true });
    }
    $('dw-calc-d').textContent = calc.cur;
    document.querySelectorAll('#dw-calc-k .op').forEach((b) => b.classList.toggle('on', calc.fresh && b.dataset.k === calc.op));
  }
  $('dw-calc-k').addEventListener('click', (e) => {
    const b = e.target.closest('[data-k]');
    if (b) press(b.dataset.k);
  });
  document.addEventListener('keydown', (e) => {
    if (!calcFocus || e.target.matches('textarea, input')) return;
    const map = { '/': '÷', '*': '×', '-': '−', '+': '+', Enter: '=', '=': '=', Backspace: '⌫', Escape: 'C', '.': ',', ',': ',', '%': '%' };
    const k = /^[0-9]$/.test(e.key) ? e.key : map[e.key];
    if (k) {
      e.preventDefault();
      press(k);
    }
  });

  /* ------------------------------------------------------------ Pixel-Pflanze (2.39)
     27 Stufen. Nach jedem Gießen läuft ein Ring zu – erst wenn er voll ist, darf wieder gegossen werden.
     Die Wartezeit wächst von 30 Minuten (Stufe 1) bis 4 Wochen (Stufe 27). Alles in Punkten, ohne Hintergrund. */
  const P_MAX = 27;
  const waitOf = (stage) => Math.round(30 * 60000 * Math.pow((28 * 24 * 60) / 30, (Math.max(1, stage) - 1) / (P_MAX - 1)));
  function plantState() {
    const p = load('dw-plant2', null) || { stage: 0, at: 0, waterings: 0 };
    const wait = p.stage ? waitOf(p.stage) : 0;
    const left = Math.max(0, p.at + wait - Date.now());
    return { ...p, wait, left, ready: p.stage < P_MAX && left <= 0, done: p.stage >= P_MAX };
  }
  const fmtLeft = (ms) => {
    const m = Math.ceil(ms / 60000);
    if (m < 60) return `${m} min`;
    const h = Math.round(m / 60);
    return h < 48 ? `${h} h` : `${Math.round(h / 24)} Tage`;
  };
  // Punktraster: 20 × 24 Punkte, jeder Punkt ein Kreis
  const PG = { cols: 20, rows: 24, S: 15 };
  function plantCells(stage, wilt) {
    const cells = new Map();
    const put = (x, y, c) => x >= 0 && x < PG.cols && y >= 0 && y < PG.rows && cells.set(`${x},${y}`, c);
    const pot = '#ff6a3d';
    // Topf (unten, 4 Reihen)
    for (let x = 6; x <= 13; x++) put(x, 20, pot);
    for (let y = 21; y <= 23; y++) for (let x = 7 + (y - 21 > 1 ? 1 : 0); x <= 12 - (y - 21 > 1 ? 1 : 0); x++) put(x, y, pot);
    if (!stage) {
      put(9, 19, '#7a5a3a');
      put(10, 19, '#7a5a3a');
      return cells;
    }
    const green = wilt ? '#b08a4a' : '#ffffff';
    const leaf = wilt ? '#8a6a3a' : '#4ade80';
    // Stiel wächst mit der Stufe (max. 17 Punkte hoch)
    const h = Math.min(17, 1 + Math.round((stage / P_MAX) * 16));
    let x = 10;
    for (let i = 0; i < h; i++) {
      const y = 19 - i;
      if (i > 3 && i % 5 === 0) x += i % 10 === 0 ? -1 : 1;
      put(x, y, green);
      // Blätter: alle 2 Punkte ein Paar, mit der Stufe größer
      if (i > 0 && i % 2 === 0 && i < h - 1) {
        const size = 1 + Math.min(2, Math.floor(stage / 9));
        const side = (i / 2) % 2 ? 1 : -1;
        for (let k = 1; k <= size; k++) put(x + side * k, y - (k > 1 ? 1 : 0), leaf);
      }
    }
    const topY = 19 - h + 1;
    // Knospe ab Stufe 18, Blüte ab Stufe 22, große Blüte bei 27
    if (stage >= 18) put(x, topY - 1, '#f9a8d4');
    if (stage >= 22) {
      const r = stage >= P_MAX ? 2 : 1;
      for (let dx = -r; dx <= r; dx++) for (let dy = -r; dy <= r; dy++) if (Math.abs(dx) + Math.abs(dy) <= r && (dx || dy)) put(x + dx, topY - 1 - r + 1 + dy - 1, '#f472b6');
      put(x, topY - 2, '#fde047');
    }
    return cells;
  }
  function drawPlant(drops = 0) {
    const p = plantState();
    const c = $('dw-plant-c');
    const g = c.getContext('2d');
    g.clearRect(0, 0, c.width, c.height);
    const wilt = !p.done && p.stage > 0 && p.left <= 0 && Date.now() - (p.at + p.wait) > 3 * 86400000;
    const cells = plantCells(p.stage, wilt);
    for (let y = 0; y < PG.rows; y++)
      for (let x = 0; x < PG.cols; x++) {
        const col = cells.get(`${x},${y}`);
        g.beginPath();
        g.arc(x * PG.S + PG.S / 2, y * PG.S + PG.S / 2, PG.S * (col ? 0.42 : 0.16), 0, Math.PI * 2);
        g.fillStyle = col || 'rgba(255,255,255,0.08)';
        g.fill();
      }
    // Wassertropfen fallen als blaue Punkte
    if (drops > 0) {
      g.fillStyle = '#7dd3fc';
      for (let i = 0; i < 7; i++) {
        const t = (drops * 2.2 + i / 7) % 1;
        g.beginPath();
        g.arc((8 + (i % 4)) * PG.S, (2 + t * 15) * PG.S, PG.S * 0.3, 0, Math.PI * 2);
        g.fill();
      }
    }
    // Ring: wie viel der Wartezeit schon vorbei ist
    const ring = $('dw-ring');
    const frac = p.done ? 1 : !p.stage ? 1 : 1 - p.left / p.wait;
    $('dw-ring-p').style.strokeDashoffset = String(100 - Math.max(0, Math.min(1, frac)) * 100);
    ring.classList.toggle('ready', p.ready || !p.stage);
    $('dw-plant-s').textContent = p.done ? 'Ausgewachsen · 27/27' : !p.stage ? 'Samen · gießen!' : p.ready ? `Stufe ${p.stage}/27 · gießen!` : `Stufe ${p.stage}/27 · ${fmtLeft(p.left)}`;
    drawCloud(p.ready || !p.stage, drops);
  }
  // 2.42: Wolke aus Punkten über der Pflanze statt Gießkanne. Bereit = dunkle Regenwolke, sonst hell und blass.
  const CLOUD = ['....###.....', '..#######...', '.##########.', '############', '.##########.'];
  function drawCloud(ready, drops = 0) {
    const c = $('dw-cloud');
    if (!c) return;
    const g = c.getContext('2d');
    g.clearRect(0, 0, c.width, c.height);
    const S = 12;
    const ox = (c.width - CLOUD[0].length * S) / 2 + (drops ? Math.sin(drops * 20) * 2 : 0);
    CLOUD.forEach((row, y) => [...row].forEach((ch, x) => {
      if (ch !== '#') return;
      g.beginPath();
      g.arc(ox + x * S + S / 2, 4 + y * S + S / 2, S * 0.42, 0, Math.PI * 2);
      g.fillStyle = drops ? '#7b8494' : ready ? '#9aa3b2' : 'rgba(255,255,255,0.35)';
      g.fill();
    }));
    c.classList.toggle('ready', Boolean(ready));
    c.title = ready ? 'Klick – es regnet!' : 'Die Wolke sammelt noch Wasser …';
  }
  function water() {
    const p = plantState();
    if (!(p.ready || !p.stage)) return false;
    const next = { stage: Math.min(P_MAX, p.stage + 1), at: Date.now(), waterings: (p.waterings || 0) + 1 };
    save('dw-plant2', next);
    window.hub.plantSync?.({ stage: next.stage, waterings: next.waterings }).catch(() => {});
    const t0 = performance.now();
    const step = (t) => {
      const k = (t - t0) / 1500;
      drawPlant(k < 1 ? k : 0);
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
    return true;
  }
  // Klick auf die Wolke → Regen (nur wenn der Ring voll ist)
  const cloud = $('dw-cloud');
  // 2.43: Klick auf die Wolke darf nie ein Ziehen des Widgets starten oder zum Desktop durchrutschen
  cloud?.addEventListener('pointerdown', (e) => e.stopPropagation(), true);
  cloud?.addEventListener('click', (e) => {
    e.stopPropagation();
    e.preventDefault();
    water();
  });
  // 2.42: Stand aus dem Hub wiederherstellen, falls dieses Fenster noch nichts gespeichert hat
  if (!localStorage.getItem('dw-plant2')) {
    window.hub.state?.().then((st) => {
      const pl = st?.settings?.plant;
      if (pl?.stage && !localStorage.getItem('dw-plant2')) {
        save('dw-plant2', { stage: Math.min(P_MAX, Number(pl.stage) || 0), at: Number(pl.at) || 0, waterings: Number(pl.waterings) || 0 });
        if (shown('plant')) drawPlant();
      }
    }).catch(() => {});
  }
  // alte Pflanze (2.38) übernehmen
  if (!localStorage.getItem('dw-plant2')) {
    const old = load('dw-plant', null);
    if (old?.growth) save('dw-plant2', { stage: Math.min(P_MAX, old.growth + 1), at: 0, waterings: old.growth + 1 });
  }

  /* ------------------------------------------------------------ Mikrofon-Monitor */
  const mic = { stream: null, ctx: null, an: null, hear: null, raf: 0 };
  $('dw-mic-bar').innerHTML = Array.from({ length: 24 }, () => '<i></i>').join('');
  function micStop() {
    cancelAnimationFrame(mic.raf);
    mic.stream?.getTracks().forEach((t) => t.stop());
    mic.ctx?.close().catch(() => {});
    Object.assign(mic, { stream: null, ctx: null, an: null, hear: null });
    $('dw-mic-on').textContent = 'Start';
    $('dw-mic-on').classList.remove('on');
    $('dw-mic-hear').classList.remove('on');
    $('dw-mic-db').textContent = '';
    [...$('dw-mic-bar').children].forEach((i) => (i.className = ''));
  }
  async function micStart() {
    try {
      const dev = localStorage.getItem('dw-mic-dev');
      mic.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, ...(dev ? { deviceId: { exact: dev } } : {}) } });
    } catch {
      $('dw-mic-db').textContent = 'kein Zugriff';
      return;
    }
    mic.ctx = new AudioContext();
    const src = mic.ctx.createMediaStreamSource(mic.stream);
    mic.an = mic.ctx.createAnalyser();
    mic.an.fftSize = 1024;
    src.connect(mic.an);
    mic.src = src;
    $('dw-mic-on').textContent = 'Stopp';
    $('dw-mic-on').classList.add('on');
    const buf = new Float32Array(mic.an.fftSize);
    const bars = [...$('dw-mic-bar').children];
    let peak = 0;
    const loop = () => {
      mic.an.getFloatTimeDomainData(buf);
      let sum = 0;
      for (const v of buf) sum += v * v;
      const db = 20 * Math.log10(Math.sqrt(sum / buf.length) || 1e-6);
      const lvl = Math.max(0, Math.min(1, (db + 60) / 60));
      peak = Math.max(lvl, peak - 0.01);
      const n = Math.round(lvl * bars.length);
      const pk = Math.round(peak * bars.length) - 1;
      bars.forEach((b, i) => (b.className = i < n ? (i > bars.length * 0.85 ? 'r' : i > bars.length * 0.65 ? 'y' : 'g') : i === pk ? 'pk' : ''));
      $('dw-mic-db').textContent = `${Math.max(-60, Math.round(db))} dB`;
      mic.raf = requestAnimationFrame(loop);
    };
    loop();
  }
  $('dw-mic-on').addEventListener('click', () => (mic.stream ? micStop() : micStart()));
  $('dw-mic-hear').addEventListener('click', () => {
    if (!mic.ctx) return;
    if (mic.hear) {
      mic.src.disconnect(mic.ctx.destination);
      mic.hear = null;
    } else {
      mic.src.connect(mic.ctx.destination);
      mic.hear = true;
    }
    $('dw-mic-hear').classList.toggle('on', Boolean(mic.hear));
  });

  /* ------------------------------------------------------------ Live-Kamera */
  const cam = { stream: null };
  // Damit die Kamera-Anzeige im Hub weiß, wer die Kamera nutzt – und sie abschalten kann
  if (!window.__revCam) {
    window.__revCam = {
      count: () => (cam.stream ? cam.stream.getVideoTracks().filter((t) => t.readyState === 'live').length : 0),
      stop: () => {
        const n = window.__revCam.count();
        camStop();
        return n;
      },
    };
  }
  function camStop() {
    cam.stream?.getTracks().forEach((t) => t.stop());
    cam.stream = null;
    $('dw-cam-v').srcObject = null;
    card('cam').classList.remove('live');
    $('dw-cam-btn').textContent = 'Kamera an';
  }
  $('dw-cam-btn').addEventListener('click', async () => {
    if (cam.stream) return camStop();
    try {
      const dev = localStorage.getItem('dw-cam-dev');
      cam.stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360, ...(dev ? { deviceId: { exact: dev } } : {}) } });
    } catch {
      $('dw-cam-off').textContent = 'Keine Kamera gefunden';
      return;
    }
    $('dw-cam-v').srcObject = cam.stream;
    $('dw-cam-v').play().catch(() => {});
    card('cam').classList.add('live');
    $('dw-cam-btn').textContent = 'Aus';
  });

  /* ------------------------------------------------------------ Soundboard (synthetisch, ohne Dateien) */
  let sctx = null;
  const ac = () => (sctx ||= new AudioContext());
  function noise(c, dur) {
    const b = c.createBuffer(1, c.sampleRate * dur, c.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource();
    s.buffer = b;
    return s;
  }
  function env(c, node, t, a, dur, peak = 0.8) {
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    node.connect(g).connect(c.destination);
    return g;
  }
  const PADS = [
    ['🥁', 'Kick', (c, t) => { const o = c.createOscillator(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.4); env(c, o, t, 0.005, 0.45, 1); o.start(t); o.stop(t + 0.5); }],
    ['👏', 'Klatsch', (c, t) => { for (let i = 0; i < 3; i++) { const n = noise(c, 0.2); const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1400; n.connect(f); env(c, f, t + i * 0.012, 0.002, 0.18, 0.7); n.start(t + i * 0.012); } }],
    ['📯', 'Horn', (c, t) => { for (const fr of [440, 554, 659]) { const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = fr; env(c, o, t, 0.03, 1.1, 0.18); o.start(t); o.stop(t + 1.2); } }],
    ['🔔', 'Ding', (c, t) => { for (const [fr, v] of [[1320, 0.4], [2640, 0.15]]) { const o = c.createOscillator(); o.frequency.value = fr; env(c, o, t, 0.004, 1.4, v); o.start(t); o.stop(t + 1.5); } }],
    ['🌀', 'Boing', (c, t) => { const o = c.createOscillator(); o.type = 'triangle'; o.frequency.setValueAtTime(180, t); o.frequency.exponentialRampToValueAtTime(700, t + 0.25); o.frequency.exponentialRampToValueAtTime(260, t + 0.6); env(c, o, t, 0.01, 0.65, 0.6); o.start(t); o.stop(t + 0.7); }],
    ['💥', 'Boom', (c, t) => { const n = noise(c, 1.2); const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(60, t + 1.1); n.connect(f); env(c, f, t, 0.005, 1.15, 1); n.start(t); }],
    ['🎺', 'Fail', (c, t) => { [392, 370, 349, 330].forEach((fr, i) => { const o = c.createOscillator(); o.type = 'square'; o.frequency.value = fr; env(c, o, t + i * 0.32, 0.02, i === 3 ? 0.9 : 0.3, 0.12); o.start(t + i * 0.32); o.stop(t + i * 0.32 + (i === 3 ? 0.95 : 0.32)); }); }],
    ['✨', 'Tada', (c, t) => { [523, 659, 784, 1047].forEach((fr, i) => { const o = c.createOscillator(); o.type = 'triangle'; o.frequency.value = fr; env(c, o, t + i * 0.07, 0.01, 0.9, 0.25); o.start(t + i * 0.07); o.stop(t + 1.1); }); }],
  ];
  // 2.39: Rechtsklick → Emoji, Name und eigener Sound pro Knopf
  const padCfg = () => {
    const c = load('dw-pads', []);
    return PADS.map((p, i) => ({ e: c[i]?.e || p[0], n: c[i]?.n || p[1], file: c[i]?.file || '' }));
  };
  const padAudio = {};
  function paintPads() {
    $('dw-pads').innerHTML = padCfg().map((p, i) => `<button data-pad="${i}" title="${esc(p.n)} – Rechtsklick: anpassen"><span>${esc(p.e)}</span><small>${esc(p.n)}</small></button>`).join('');
  }
  paintPads();
  async function playCustom(i) {
    if (!padAudio[i]) {
      const url = await window.hub.widgetSound.data(i).catch(() => '');
      if (!url) return false;
      padAudio[i] = url;
    }
    const a = new Audio(padAudio[i]);
    a.play().catch(() => {});
    return true;
  }
  $('dw-pads').addEventListener('click', (e) => {
    const b = e.target.closest('[data-pad]');
    if (!b) return;
    const i = Number(b.dataset.pad);
    // 2.45.8: über die Audio-Engine des Hubs – stummschaltbar und auf Wunsch auch im Mikrofon (Discord)
    if (window.hub.sound) window.hub.sound.play(i, 1).catch(() => {});
    else if (padCfg()[i].file) playCustom(i);
    else {
      const c = ac();
      c.resume?.();
      PADS[i][2](c, c.currentTime + 0.01);
    }
    b.classList.remove('hit');
    void b.offsetWidth;
    b.classList.add('hit');
  });

  /* ------------------------------------------------------------ Schnellzugriff */
  async function paintQuick() {
    if (!shown('quick') || !window.hub.quick) return;
    const list = await window.hub.quick.list().catch(() => []);
    $('dw-quick-list').innerHTML = list.length
      ? list.map((f, i) => `<button class="dw-qa ${f.missing ? 'gone' : ''}" data-q="${i}" title="${esc(f.path)}\nKlick: öffnen · Rechtsklick: entfernen"><span>${f.dir ? '📁' : /\.(png|jpe?g|gif|webp)$/i.test(f.name) ? '🖼️' : /\.(mp3|wav|ogg|flac)$/i.test(f.name) ? '🎵' : /\.(mp4|mov|mkv)$/i.test(f.name) ? '🎬' : /\.(pdf|docx?|txt)$/i.test(f.name) ? '📄' : '📦'}</span><b>${esc(f.name.replace(/\.[^.]+$/, ''))}</b>${f.dir ? '' : `<i>${esc((f.name.match(/\.([^.]+)$/)?.[1] || '').slice(0, 4).toUpperCase())}</i>`}</button>`).join('')
      : '<div class="dw-empty">Dateien hierher ziehen oder + drücken</div>';
  }
  $('dw-quick-add').addEventListener('click', () => window.hub.quick?.pick().then(paintQuick).catch(() => {}));
  $('dw-quick-list').addEventListener('click', (e) => {
    const b = e.target.closest('[data-q]');
    if (b) window.hub.quick.open(Number(b.dataset.q)).catch(() => {});
  });
  $('dw-quick-list').addEventListener('contextmenu', (e) => {
    const b = e.target.closest('[data-q]');
    if (!b || e.ctrlKey) return;
    e.preventDefault();
    e.stopPropagation();
    window.hub.quick.remove(Number(b.dataset.q)).then(paintQuick).catch(() => {});
  });
  const qc = card('quick');
  qc.addEventListener('dragover', (e) => {
    e.preventDefault();
    qc.classList.add('over');
  });
  qc.addEventListener('dragleave', () => qc.classList.remove('over'));
  qc.addEventListener('drop', (e) => {
    e.preventDefault();
    qc.classList.remove('over');
    const paths = [...(e.dataTransfer?.files || [])].map((f) => window.hub.quick.pathOf(f)).filter(Boolean);
    if (paths.length) window.hub.quick.add(paths).then(paintQuick).catch(() => {});
  });
  // Ohne das würde Electron eine Datei, die daneben fällt, als Seite öffnen
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => e.preventDefault());

  /* ------------------------------------------------------------ Rechtsklick: eigene Einstellungen pro Widget (2.39)
     Rechte Maustaste ziehen = verschieben, Rechtsklick ohne Bewegen = Anpassen. */
  let rDown = null;
  let cfgEl = null;
  const closeCfg = () => {
    cfgEl?.remove();
    cfgEl = null;
  };
  document.addEventListener('pointerdown', (e) => {
    if (e.button === 2) rDown = { x: e.clientX, y: e.clientY };
    if (cfgEl && !e.target.closest('.dw-cfg')) closeCfg();
  }, true);
  document.addEventListener('contextmenu', (e) => {
    const el = e.target.closest('.dw');
    if (!el || e.ctrlKey || !rDown) return;
    if (Math.abs(e.clientX - rDown.x) + Math.abs(e.clientY - rDown.y) > 5) return; // war ein Ziehen
    const k = el.dataset.w;
    if (el.classList.contains('ghost')) return;
    e.preventDefault();
    e.stopPropagation();
    openCfg(k, e.clientX, e.clientY);
  }, true);
  async function openCfg(k, x, y) {
    closeCfg();
    cfgEl = document.createElement('div');
    cfgEl.className = 'dw-cfg';
    cfgEl.dataset.nodrag = '1';
    const def = CFG[k] || { html: () => `<h4>${esc(NAMES[k] || 'Widget')}</h4><div class="foot"><button data-close>Fertig</button></div>` };
    cfgEl.innerHTML = await def.html();
    // 2.44: jedes Widget lässt sich per Rechtsklick entfernen
    cfgEl.querySelector('.foot')?.insertAdjacentHTML('afterbegin', '<button data-remove class="danger">Entfernen</button>');
    cfgEl.style.left = `${Math.min(x, window.innerWidth - 310)}px`;
    cfgEl.style.top = `${Math.min(y, window.innerHeight - 380)}px`;
    document.body.appendChild(cfgEl);
    window.hub.widgetsInteractive?.(true);
    cfgEl.addEventListener('click', (ev) => {
      if (ev.target.closest('[data-remove]')) {
        window.hub.setSettings({ desktopWidgets: { [k === 'screen' ? 'screentime' : k]: false } }).catch(() => {});
        return closeCfg();
      }
      if (ev.target.closest('[data-close]')) return closeCfg();
      def.click?.(ev);
    });
    cfgEl.addEventListener('change', (ev) => def.change?.(ev));
  }
  async function devices(kind) {
    try {
      return (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === kind);
    } catch {
      return [];
    }
  }
  const devSelect = (list, cur, attr) => `<select ${attr}><option value="">Standardgerät</option>${list.map((d, i) => `<option value="${esc(d.deviceId)}" ${d.deviceId === cur ? 'selected' : ''}>${esc(d.label || `Gerät ${i + 1}`)}</option>`).join('')}</select>`;
  const NAMES = { clock: 'Uhr', face: 'Analoguhr', music: 'Läuft gerade', system: 'System', calendar: 'Kalender', screen: 'Bildschirmzeit', upcoming: 'Termine', eq: 'Sound', mixer: 'Mixer', weather: 'Wetter', football: 'Fußball', clicker: 'Autoclicker', trading: 'Märkte', streamchat: 'Stream-Chat', uptime: 'PC läuft seit', notes: 'Notizen', todo: 'To-do', calc: 'Rechner', plant: 'Pflanze', mic: 'Mikrofon', cam: 'Kamera', sound: 'Soundboard', quick: 'Schnellzugriff', perf: 'Leistung' };
  const CFG = {
    sound: {
      html: () => `<h4>Soundboard anpassen</h4>${padCfg().map((p, i) => `<div class="r"><input class="emo" data-pe="${i}" value="${esc(p.e)}" maxlength="4" /><input data-pn="${i}" value="${esc(p.n)}" maxlength="14" /><button data-pick="${i}" title="Eigene Sounddatei">${p.file ? '🎵' : 'Sound'}</button><button data-pr="${i}" title="Zurücksetzen">↺</button></div>`).join('')}<div class="foot"><button data-close>Fertig</button></div>`,
      change: (e) => {
        const cfg = padCfg();
        const i = Number(e.target.dataset.pe ?? e.target.dataset.pn);
        if (Number.isNaN(i)) return;
        if (e.target.dataset.pe != null) cfg[i].e = e.target.value.trim() || PADS[i][0];
        else cfg[i].n = e.target.value.trim() || PADS[i][1];
        save('dw-pads', cfg);
        paintPads();
      },
      click: async (e) => {
        const cfg = padCfg();
        if (e.target.closest('[data-close]')) return closeCfg();
        const pick = e.target.closest('[data-pick]');
        const reset = e.target.closest('[data-pr]');
        if (pick) {
          const i = Number(pick.dataset.pick);
          const name = await window.hub.widgetSound.pick(i).catch(() => '');
          if (!name) return;
          cfg[i].file = name;
          delete padAudio[i];
          save('dw-pads', cfg);
          pick.textContent = '🎵';
        } else if (reset) {
          const i = Number(reset.dataset.pr);
          await window.hub.widgetSound.reset(i).catch(() => {});
          cfg[i] = { e: PADS[i][0], n: PADS[i][1], file: '' };
          delete padAudio[i];
          save('dw-pads', cfg);
          const r = reset.closest('.r');
          r.querySelector('[data-pe]').value = cfg[i].e;
          r.querySelector('[data-pn]').value = cfg[i].n;
          r.querySelector('[data-pick]').textContent = 'Sound';
        }
        paintPads();
      },
    },
    mic: {
      html: async () => `<h4>Mikrofon wählen</h4>${devSelect(await devices('audioinput'), localStorage.getItem('dw-mic-dev') || '', 'data-dev="mic"')}<div class="foot"><button data-close>Fertig</button></div>`,
      change: (e) => {
        localStorage.setItem('dw-mic-dev', e.target.value);
        if (mic.stream) {
          micStop();
          micStart();
        }
        paintDev();
      },
      click: (e) => e.target.closest('[data-close]') && closeCfg(),
    },
    cam: {
      html: async () => `<h4>Kamera wählen</h4>${devSelect(await devices('videoinput'), localStorage.getItem('dw-cam-dev') || '', 'data-dev="cam"')}<div class="foot"><button data-close>Fertig</button></div>`,
      change: async (e) => {
        localStorage.setItem('dw-cam-dev', e.target.value);
        if (cam.stream) {
          camStop();
          $('dw-cam-btn').click();
        }
      },
      click: (e) => e.target.closest('[data-close]') && closeCfg(),
    },
    plant: {
      html: () => {
        const p = plantState();
        return `<h4>Pflanze</h4><div style="font-size:12.5px;line-height:1.5;color:rgba(255,255,255,.8)">Stufe ${p.stage}/27 · ${p.waterings || 0}× gegossen.<br>Nächste Wartezeit: ${fmtLeft(waitOf(Math.min(P_MAX, p.stage + 1)))}.<br>Die letzte Stufe braucht 4 Wochen.</div><div class="foot"><button data-close>Fertig</button></div>`;
      },
      click: (e) => e.target.closest('[data-close]') && closeCfg(),
    },
  };
  async function paintDev() {
    const id = localStorage.getItem('dw-mic-dev') || '';
    const list = await devices('audioinput');
    $('dw-mic-dev').textContent = id ? list.find((d) => d.deviceId === id)?.label || '' : '';
  }

  /* ------------------------------------------------------------ Steuerung */
  function refresh() {
    paintUptime();
    paintTodo();
    if (shown('plant')) drawPlant();
    paintQuick();
    if (!shown('mic') && mic.stream) micStop();
    if (!shown('cam') && cam.stream) camStop();
  }
  window.addEventListener('dw-extra', refresh);
  window.addEventListener('storage', (e) => {
    if (e.key === 'dw-notes' && document.activeElement !== notes) notes.value = load('dw-notes', '');
    if (e.key === 'dw-todo') paintTodo();
    if (e.key === 'dw-plant2' && shown('plant')) drawPlant();
    if (e.key === 'dw-pads') paintPads();
  });
  setInterval(() => {
    if (document.hidden) return;
    paintUptime();
    if (shown('plant')) drawPlant();
  }, 60000);
  window.hub.onWidgetsPause?.((on) => on && (micStop(), camStop()));
  paintDev();
  refresh();
})();
