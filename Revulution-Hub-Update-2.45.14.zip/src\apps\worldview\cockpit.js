'use strict';
/* Weltansicht 2.45.3 – Cockpit & 3D-Ansicht eines Flugs (WebGL).
   Die Erde darunter besteht aus echten Satellitenkacheln (Esri World Imagery) in zwei Detailstufen,
   mit Erdkrümmung und Dunst zum Horizont. Das Flugzeug fliegt mit Kurs und Tempo des echten Flugs weiter.
   Cockpit: Blick aus der Nase. Aussen: 3D-Verkehrsflugzeug von hinten (Verfolgerkamera). */
(() => {
  const root = document.getElementById('cockpit');
  const canvas = document.getElementById('cockpit-gl');
  if (!root || !canvas) return;
  const $ = (id) => document.getElementById(id);
  const DEG = Math.PI / 180;
  const RE = 6371000;
  const ESRI = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/';
  let gl = null;
  let prog = null, progMesh = null;
  let state = null;
  let raf = 0;

  /* ---------------------------------------------------------------- Mathe */
  const persp = (fovy, aspect, near, far) => {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
  };
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const norm = (a) => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  function lookAt(eye, target, up) {
    const z = norm(sub(eye, target)), x = norm(cross(up, z)), y = cross(z, x);
    return new Float32Array([x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -dot(x, eye), -dot(y, eye), -dot(z, eye), 1]);
  }
  function mul(a, b) {
    const o = new Float32Array(16);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + j] * b[i * 4 + k]; o[i * 4 + j] = s; }
    return o;
  }

  /* ---------------------------------------------------------------- Shader */
  const VS = `attribute vec3 p; attribute vec2 uv; uniform mat4 mvp; uniform vec3 eye; varying vec2 v; varying float d; varying vec2 g;
    void main(){ v = uv; g = p.xy; d = distance(p, eye); gl_Position = mvp * vec4(p, 1.0); }`;
  // Feinere Detailstufen werden zum Rand hin weich ausgeblendet (sonst sieht man ein hartes Quadrat)
  const FS = `precision mediump float; uniform sampler2D t; uniform vec3 haze; uniform float fog; uniform vec2 mid; uniform float rad; varying vec2 v; varying float d; varying vec2 g;
    void main(){ vec3 c = texture2D(t, v).rgb; float f = 1.0 - exp(-d / fog); float a = 1.0 - smoothstep(rad * 0.55, rad, distance(g, mid));
      gl_FragColor = vec4(mix(c * 0.95, haze, clamp(f, 0.0, 0.92)), a); }`;
  const VSM = `attribute vec3 p; attribute vec3 n; attribute vec3 col; uniform mat4 mvp; uniform mat4 model; varying vec3 vn; varying vec3 vc;
    void main(){ vn = mat3(model) * n; vc = col; gl_Position = mvp * vec4(p, 1.0); }`;
  const FSM = `precision mediump float; varying vec3 vn; varying vec3 vc; uniform vec3 sun;
    void main(){ float l = 0.42 + 0.58 * abs(dot(normalize(vn), sun)); gl_FragColor = vec4(vc * l, 1.0); }`;
  function compile(vs, fs) {
    const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    const p = gl.createProgram();
    gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    return p;
  }

  /* ---------------------------------------------------------------- Boden aus Kacheln */
  const lat2ty = (lat, n) => ((1 - Math.log(Math.tan(lat) + 1 / Math.cos(lat)) / Math.PI) / 2) * n;
  const ty2lat = (y, n) => Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / n)));
  // Breite/Länge → lokale Meter (Ost, Nord, Hoch) um den Ursprung, mit Erdkrümmung
  function enu(lat, lon) {
    const o = state.origin;
    let dl = lon - o.lon;
    dl = ((dl + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
    const e = dl * Math.cos(o.lat) * RE, nn = (lat - o.lat) * RE;
    return [e, nn, -(e * e + nn * nn) / (2 * RE)];
  }
  function tileMesh(z, x, y) {
    const n = 2 ** z, S = 8, pos = [], uv = [], idx = [];
    for (let j = 0; j <= S; j++) for (let i = 0; i <= S; i++) {
      const lat = ty2lat(y + j / S, n), lon = ((x + i / S) / n - 0.5) * 2 * Math.PI;
      pos.push(...enu(lat, lon)); uv.push(i / S, j / S);
    }
    for (let j = 0; j < S; j++) for (let i = 0; i < S; i++) { const a = j * (S + 1) + i, b = a + 1, c = a + S + 1, d = c + 1; idx.push(a, c, b, b, c, d); }
    const vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pos), gl.STATIC_DRAW);
    const ub = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, ub); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(uv), gl.STATIC_DRAW);
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(idx), gl.STATIC_DRAW);
    return { vb, ub, ib, count: idx.length };
  }
  function tile(z, x, y) {
    const key = `${z}/${x}/${y}`;
    let t = state.tiles.get(key);
    if (t) { t.used = state.frame; return t; }
    t = { z, x, y, used: state.frame, tex: null, mesh: tileMesh(z, x, y) };
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (!gl || !state) return;
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, img);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.generateMipmap(gl.TEXTURE_2D);
      t.tex = tex;
    };
    img.src = `${ESRI}${z}/${y}/${((x % (2 ** z)) + 2 ** z) % (2 ** z)}`;
    state.tiles.set(key, t);
    return t;
  }
  function dropTile(t) {
    gl.deleteBuffer(t.mesh.vb); gl.deleteBuffer(t.mesh.ub); gl.deleteBuffer(t.mesh.ib);
    if (t.tex) gl.deleteTexture(t.tex);
  }
  function rebuildOrigin(lat, lon) {
    // Ursprung neu setzen (alle Kachel-Netze sind relativ dazu) – alle ~60 km
    for (const t of state.tiles.values()) dropTile(t);
    state.tiles.clear();
    state.origin = { lat, lon };
  }
  // Kacheln in zwei Ringen: grob bis zum Horizont, fein in der Nähe
  function groundTiles(lat, lon) {
    const layers = [];
    for (const [z, r] of [[8, 4], [11, 4], [13, 3]]) {
      const n = 2 ** z, cx = Math.floor((lon / (2 * Math.PI) + 0.5) * n), cy = Math.floor(lat2ty(lat, n));
      const tileM = (2 * Math.PI * RE * Math.cos(lat)) / n;
      const tiles = [];
      for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
        const y = cy + dy;
        if (y < 0 || y >= n) continue;
        tiles.push(tile(z, cx + dx, y));
      }
      layers.push({ z, rad: z === 8 ? 1e9 : (r + 0.5) * tileM * 0.95, tiles });
    }
    return layers;
  }

  /* ---------------------------------------------------------------- 3D-Flugzeug (Verkehrsflugzeug, ~40 m) */
  function planeMesh() {
    const P = [], N = [], C = [], I = [];
    const white = [0.94, 0.95, 0.97], grey = [0.55, 0.6, 0.66], tail = [0.85, 0.18, 0.22], dark = [0.12, 0.14, 0.18];
    const add = (verts, col) => {
      // Dreiecke mit flachen Normalen
      for (let i = 0; i < verts.length; i += 3) {
        const a = verts[i], b = verts[i + 1], c = verts[i + 2];
        const nn = norm(cross(sub(b, a), sub(c, a)));
        for (const v of [a, b, c]) { I.push(P.length / 3); P.push(...v); N.push(...nn); C.push(...col); }
      }
    };
    const quad = (a, b, c, d, col) => { add([a, b, c, a, c, d], col); add([a, c, b, a, d, c], col); };
    // Rumpf: Zylinder entlang x (vorne +x), Radius 2 m, von -20 bis +18, Nase/Heck verjüngt
    const seg = 14, rings = [[-20, 0.9], [-17, 1.7], [-12, 2], [12, 2], [16, 1.6], [18.5, 0.6], [19.2, 0.05]];
    for (let r = 0; r < rings.length - 1; r++) {
      const [x0, r0] = rings[r], [x1, r1] = rings[r + 1];
      for (let s = 0; s < seg; s++) {
        const a0 = (s / seg) * 2 * Math.PI, a1 = ((s + 1) / seg) * 2 * Math.PI;
        const p = (x, rr, a) => [x, Math.cos(a) * rr, Math.sin(a) * rr + 0.2];
        add([p(x0, r0, a0), p(x1, r1, a0), p(x1, r1, a1), p(x0, r0, a0), p(x1, r1, a1), p(x0, r0, a1)], white);
      }
    }
    // Cockpitscheiben
    quad([17, -1.1, 1.2], [17, 1.1, 1.2], [18.3, 0.7, 0.75], [18.3, -0.7, 0.75], dark);
    // Flügel (gepfeilt), Dicke 0.4 m
    for (const s of [-1, 1]) {
      const root = [[3, s * 1.8], [-4, s * 1.8]], tip = [[-7, s * 17.5], [-9.5, s * 17.5]];
      const top = (pt) => [pt[0], pt[1], -0.3], bot = (pt) => [pt[0], pt[1], -0.7];
      quad(top(root[0]), top(tip[0]), top(tip[1]), top(root[1]), white);
      quad(bot(root[0]), bot(tip[0]), bot(tip[1]), bot(root[1]), grey);
      quad(top(root[0]), top(tip[0]), bot(tip[0]), bot(root[0]), grey);
      // Winglet
      quad([-7, s * 17.5, -0.3], [-9.5, s * 17.5, -0.3], [-10.2, s * 17.8, 2], [-8.8, s * 17.8, 2], tail);
      // Triebwerk
      const ex = -0.5, ey = s * 6.5, ez = -1.6;
      for (let k = 0; k < 10; k++) {
        const a0 = (k / 10) * 2 * Math.PI, a1 = ((k + 1) / 10) * 2 * Math.PI, rr = 1.1;
        const p = (x, a) => [x, ey + Math.cos(a) * rr, ez + Math.sin(a) * rr];
        add([p(ex + 2.5, a0), p(ex - 2.5, a0), p(ex - 2.5, a1), p(ex + 2.5, a0), p(ex - 2.5, a1), p(ex + 2.5, a1)], grey);
      }
      // Höhenleitwerk
      quad([-15.5, s * 1.2, 0.8], [-19.5, s * 6.5, 0.9], [-20.5, s * 6.5, 0.9], [-19.5, s * 1, 0.8], white);
    }
    // Seitenleitwerk
    quad([-14, 0, 2], [-19.8, 0, 9.5], [-21.2, 0, 9.5], [-20, 0, 1.6], tail);
    const buf = (arr, Ty = Float32Array, target = gl.ARRAY_BUFFER) => { const b = gl.createBuffer(); gl.bindBuffer(target, b); gl.bufferData(target, new Ty(arr), gl.STATIC_DRAW); return b; };
    return { p: buf(P), n: buf(N), c: buf(C), i: buf(I, Uint16Array, gl.ELEMENT_ARRAY_BUFFER), count: I.length };
  }

  /* ---------------------------------------------------------------- Ablauf */
  function flightNow() {
    const f = state.getFlight();
    const dt = Math.max(0, Math.min(600, (Date.now() - state.flightsAt()) / 1000));
    const dist = ((f.v || 450) / 3.6) * dt, hd = (f.hd || 0) * DEG;
    const lat = (f.lat + (dist * Math.cos(hd)) / 111320) * DEG;
    const lon = (f.lon + (dist * Math.sin(hd)) / (111320 * Math.max(0.05, Math.cos(f.lat * DEG)))) * DEG;
    return { f, lat, lon, alt: Math.max(300, f.alt || 3000), hd };
  }
  function resize() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(innerWidth * dpr); canvas.height = Math.round(innerHeight * dpr);
    canvas.style.width = innerWidth + 'px'; canvas.style.height = innerHeight + 'px';
  }
  function draw() {
    raf = requestAnimationFrame(draw);
    if (!state || document.hidden) return;
    state.frame++;
    const now = flightNow();
    if (!state.origin || Math.hypot(...enu(now.lat, now.lon).slice(0, 2)) > 60000) rebuildOrigin(now.lat, now.lon);
    const P = enu(now.lat, now.lon);
    const pos = [P[0], P[1], P[2] + now.alt];
    const fwd = [Math.sin(now.hd), Math.cos(now.hd), 0];
    const right = [Math.cos(now.hd), -Math.sin(now.hd), 0];
    // Blickrichtung mit Umschauen (Ziehen)
    const yaw = now.hd + state.look.yaw, pitch = state.look.pitch;
    const dir = [Math.sin(yaw) * Math.cos(pitch), Math.cos(yaw) * Math.cos(pitch), Math.sin(pitch)];
    let eye, target;
    if (state.mode === 'cockpit') {
      eye = [pos[0] + fwd[0] * 17, pos[1] + fwd[1] * 17, pos[2] + 1.2];
      target = [eye[0] + dir[0], eye[1] + dir[1], eye[2] + dir[2]];
    } else {
      const dist = state.dist;
      eye = [pos[0] - dir[0] * dist, pos[1] - dir[1] * dist, pos[2] - dir[2] * dist + dist * 0.12];
      target = [pos[0], pos[1], pos[2]];
    }
    const proj = persp((state.mode === 'cockpit' ? 70 : 55) * DEG, canvas.width / canvas.height, 2, 900000);
    const view = lookAt(eye, target, [0, 0, 1]);
    const vp = mul(proj, view);
    gl.viewport(0, 0, canvas.width, canvas.height);
    // Himmel: Farbe je nach Höhe
    const haze = [0.62, 0.74, 0.88];
    gl.clearColor(0.42, 0.62, 0.86, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // Boden (grob → fein übereinander, ohne Tiefentest)
    gl.disable(gl.DEPTH_TEST);
    gl.useProgram(prog);
    gl.uniformMatrix4fv(gl.getUniformLocation(prog, 'mvp'), false, vp);
    gl.uniform3fv(gl.getUniformLocation(prog, 'eye'), eye);
    gl.uniform3fv(gl.getUniformLocation(prog, 'haze'), haze);
    gl.uniform1f(gl.getUniformLocation(prog, 'fog'), 160000 + now.alt * 12);
    const aP = gl.getAttribLocation(prog, 'p'), aUV = gl.getAttribLocation(prog, 'uv');
    gl.enableVertexAttribArray(aP); gl.enableVertexAttribArray(aUV);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.uniform2f(gl.getUniformLocation(prog, 'mid'), P[0], P[1]);
    const uRad = gl.getUniformLocation(prog, 'rad');
    for (const layer of groundTiles(now.lat, now.lon)) {
      gl.uniform1f(uRad, layer.rad);
      for (const t of layer.tiles) {
        if (!t.tex) continue;
        gl.bindTexture(gl.TEXTURE_2D, t.tex);
        gl.bindBuffer(gl.ARRAY_BUFFER, t.mesh.vb); gl.vertexAttribPointer(aP, 3, gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, t.mesh.ub); gl.vertexAttribPointer(aUV, 2, gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, t.mesh.ib);
        gl.drawElements(gl.TRIANGLES, t.mesh.count, gl.UNSIGNED_SHORT, 0);
      }
    }
    gl.disable(gl.BLEND);
    gl.disableVertexAttribArray(aUV);
    // Flugzeug (nur aussen sichtbar)
    if (state.mode !== 'cockpit') {
      gl.enable(gl.DEPTH_TEST);
      gl.useProgram(progMesh);
      const ch = Math.cos(now.hd), sh = Math.sin(now.hd);
      // Modell: x nach vorne → Kursrichtung, y nach links, z hoch
      const model = new Float32Array([sh, ch, 0, 0, -ch, sh, 0, 0, 0, 0, 1, 0, pos[0], pos[1], pos[2], 1]);
      gl.uniformMatrix4fv(gl.getUniformLocation(progMesh, 'mvp'), false, mul(vp, model));
      gl.uniformMatrix4fv(gl.getUniformLocation(progMesh, 'model'), false, model);
      gl.uniform3fv(gl.getUniformLocation(progMesh, 'sun'), norm([0.4, -0.3, 0.86]));
      const m = state.mesh;
      const a = (name, b, size) => { const l = gl.getAttribLocation(progMesh, name); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, size, gl.FLOAT, false, 0, 0); return l; };
      const l1 = a('p', m.p, 3), l2 = a('n', m.n, 3), l3 = a('col', m.c, 3);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.i);
      gl.drawElements(gl.TRIANGLES, m.count, gl.UNSIGNED_SHORT, 0);
      gl.disableVertexAttribArray(l2); gl.disableVertexAttribArray(l3);
      void l1; void right;
    }
    // alte Kacheln aufräumen
    if (state.frame % 120 === 0 && state.tiles.size > 400) {
      for (const [k, t] of state.tiles) if (t.used < state.frame - 60) { dropTile(t); state.tiles.delete(k); }
    }
    // Anzeigen
    if (state.frame % 10 === 0) {
      $('ck-cs').textContent = now.f.cs || String(now.f.id || '').toUpperCase();
      $('ck-route').textContent = now.f.c || '';
      $('ck-alt').textContent = `${Math.round(now.alt).toLocaleString('de-CH')} m`;
      $('ck-spd').textContent = now.f.v ? `${now.f.v} km/h` : '–';
      $('ck-hdg').textContent = `${Math.round(((now.hd / DEG) % 360 + 360) % 360)}°`;
    }
  }

  function setMode(mode) {
    state.mode = mode;
    state.look = { yaw: 0, pitch: mode === 'cockpit' ? -4 * DEG : -12 * DEG };
    root.querySelectorAll('[data-ck]').forEach((b) => b.classList.toggle('on', b.dataset.ck === mode));
  }

  function open({ flight, mode, getFlight, flightsAt }) {
    try {
      if (!gl) {
        gl = canvas.getContext('webgl', { antialias: true, alpha: false });
        if (!gl) throw new Error('WebGL ist auf diesem PC nicht verfügbar.');
        prog = compile(VS, FS);
        progMesh = compile(VSM, FSM);
      }
    } catch (e) {
      alert(`3D-Ansicht nicht möglich: ${e.message}`);
      return;
    }
    if (state) close();
    state = { flight, getFlight, flightsAt, tiles: new Map(), frame: 0, origin: null, dist: 140, look: { yaw: 0, pitch: 0 }, mode };
    state.mesh = planeMesh();
    setMode(mode);
    root.hidden = false;
    resize();
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(draw);
  }
  function close() {
    cancelAnimationFrame(raf);
    if (state && gl) for (const t of state.tiles.values()) dropTile(t);
    state = null;
    root.hidden = true;
  }

  // Bedienung: ziehen = umschauen, Rad = Abstand
  let drag = null;
  canvas.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY, yaw: state?.look.yaw || 0, pitch: state?.look.pitch || 0 }; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener('pointermove', (e) => {
    if (!drag || !state) return;
    state.look.yaw = drag.yaw + (e.clientX - drag.x) * 0.005;
    state.look.pitch = Math.max(-80 * DEG, Math.min(30 * DEG, drag.pitch - (e.clientY - drag.y) * 0.004));
  });
  canvas.addEventListener('pointerup', () => { drag = null; });
  canvas.addEventListener('wheel', (e) => { if (!state) return; e.preventDefault(); state.dist = Math.max(45, Math.min(2500, state.dist * Math.exp(e.deltaY * 0.0015))); }, { passive: false });
  root.addEventListener('click', (e) => {
    const b = e.target.closest('[data-ck]');
    if (!b) return;
    if (b.dataset.ck === 'close') close();
    else if (state) setMode(b.dataset.ck);
  });
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && state) close(); });
  window.addEventListener('resize', () => { if (state) resize(); });

  window.WVCockpit = { open, close };
})();
