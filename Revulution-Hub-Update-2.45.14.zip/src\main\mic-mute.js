'use strict';
/**
 * Mikrofon stumm schalten (2.45.9) – das Standard-Aufnahmegerät von Windows, wirkt also in jeder App
 * (Discord, Spiele, Hub-Mikrofon-Mix). Über die Windows-Audio-Schnittstelle (IAudioEndpointVolume).
 */
const { execFile } = require('child_process');

const CS = `
using System; using System.Runtime.InteropServices;
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorCom {}
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator { int NotImpl1(); [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppDevice); }
[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice { [PreserveSig] int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface); }
[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
  int f1(); int f2(); int f3(); int f4(); int f5(); int f6(); int f7(); int f8(); int f9(); int f10(); int f11();
  [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, Guid pguidEventContext);
  [PreserveSig] int GetMute(out bool pbMute);
}
public static class RevMic {
  static IAudioEndpointVolume Vol() {
    var en = (IMMDeviceEnumerator)(new MMDeviceEnumeratorCom());
    IMMDevice dev; Marshal.ThrowExceptionForHR(en.GetDefaultAudioEndpoint(1, 0, out dev)); // 1 = Aufnahme
    var iid = typeof(IAudioEndpointVolume).GUID; object o;
    Marshal.ThrowExceptionForHR(dev.Activate(ref iid, 23, IntPtr.Zero, out o));
    return (IAudioEndpointVolume)o;
  }
  public static string Run(string mode) {
    var v = Vol(); bool m; v.GetMute(out m);
    if (mode == "toggle") { m = !m; v.SetMute(m, Guid.Empty); }
    else if (mode == "on") { m = true; v.SetMute(true, Guid.Empty); }
    else if (mode == "off") { m = false; v.SetMute(false, Guid.Empty); }
    return m ? "muted" : "live";
  }
}`;

function micMute(mode = 'state') {
  const m = ['toggle', 'on', 'off', 'state'].includes(mode) ? mode : 'state';
  const script = `$ErrorActionPreference='Stop'; Add-Type -TypeDefinition @'\n${CS}\n'@\n[Console]::Out.Write([RevMic]::Run('${m}'))`;
  return new Promise((resolve, reject) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 15000 }, (err, out, errOut) => {
    const s = String(out || '').trim();
    if (s === 'muted' || s === 'live') return resolve({ muted: s === 'muted' });
    reject(new Error(/Element nicht gefunden|0x80070490|not found/i.test(String(errOut || err?.message)) ? 'Kein Mikrofon gefunden.' : 'Mikrofon konnte nicht umgeschaltet werden.'));
  }));
}

module.exports = { micMute };
