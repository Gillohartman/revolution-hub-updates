/* Runde 11b – Design „Pro“: setzt html[data-theme] so früh wie möglich (im <head>, vor dem ersten
   Zeichnen), damit es kein Aufblitzen gibt. Quelle: localStorage 'rh-design' (vom Hub bzw. vom
   Hauptprozess geschrieben). Wechsel in einem anderen Fenster derselben Herkunft kommen per
   'storage'-Ereignis sofort an; Modul-Fenster mit eigener Partition setzt der Hauptprozess. */
(function () {
  var root = document.documentElement;
  // Durchsichtige Fenster (Leiste, Dock, Widgets, Kontrollzentrum, Overlays) behalten ihren
  // durchsichtigen Grund – Pro färbt dort nur die Bauteile, nicht die ganze Fläche.
  try {
    var page = (location.pathname.split('/').pop() || '').toLowerCase();
    if (/^(taskbar|dock|desktop-widgets|airplay-widget|wp-switch|stream-chat|client|lock|parental-lock|crosshair-overlay|monitor-glow)\.html$/.test(page)) root.setAttribute('data-surface', 'overlay');
  } catch (e) {}
  // 2.45.13: „Pro“ ist der Standard – nur 'standard' (Liquid Glass, ausdrücklich gewählt) schaltet es ab.
  // Der Hauptprozess schreibt den gespeicherten Wert beim Laden jeder Seite nach (theme-sync.js).
  function apply(v) {
    if (v === 'standard') root.removeAttribute('data-theme');
    else root.setAttribute('data-theme', 'pro');
  }
  try { apply(localStorage.getItem('rh-design')); } catch (e) {}
  try {
    window.addEventListener('storage', function (e) {
      if (e.key === 'rh-design') apply(e.newValue);
    });
  } catch (e) {}
})();
