'use strict';
/**
 * Welche App ist gerade vorne? (2.45.7) – für die KI-Agent-Tasten: „fertig“ wird wieder „bereit“,
 * sobald man die App (Claude, ChatGPT/Codex, Freebuff) angeklickt hat.
 * Ein kleiner PowerShell-Helfer meldet nur den Prozessnamen des Vordergrundfensters, wenn er wechselt.
 * Läuft nur, solange die Claude-/Agenten-Verbindung eingeschaltet ist. Es werden keine Fensterinhalte gelesen.
 */
const { spawn } = require('child_process');

const SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class RevFg {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
}
'@
$last = ''
while ($true) {
  $p = 0; [void][RevFg]::GetWindowThreadProcessId([RevFg]::GetForegroundWindow(), [ref]$p)
  $n = ''; if ($p) { $n = (Get-Process -Id $p -ErrorAction SilentlyContinue).ProcessName }
  if ($n -ne $last) { [Console]::Out.WriteLine('fg ' + $n); [Console]::Out.Flush(); $last = $n }
  Start-Sleep -Milliseconds 700
}`;

// Prozessname → Agent
const AGENT_OF = (name) => {
  const n = String(name || '').toLowerCase();
  if (n === 'claude') return 'claude';
  if (n === 'chatgpt' || n === 'codex') return 'codex';
  if (n === 'freebuff') return 'freebuff';
  return null;
};

class ForegroundWatch {
  constructor() {
    this.child = null;
    this.current = '';
    this.seen = { claude: 0, codex: 0, freebuff: 0 }; // wann die App zuletzt vorne war
  }
  start() {
    if (this.child) return;
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', SCRIPT], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    this.child = child;
    let rest = '';
    child.stdout.on('data', (buf) => {
      rest += String(buf);
      const lines = rest.split(/\r?\n/);
      rest = lines.pop();
      for (const l of lines) if (l.startsWith('fg ')) this.set(l.slice(3).trim());
    });
    child.on('exit', () => { if (this.child === child) this.child = null; });
    child.on('error', () => { if (this.child === child) this.child = null; });
  }
  set(name) {
    this.current = name;
    const a = AGENT_OF(name);
    if (a) this.seen[a] = Date.now();
  }
  /** Zeitpunkt, bis zu dem die App angesehen wurde (läuft sie gerade vorne: jetzt). */
  seenAt(agent) {
    return AGENT_OF(this.current) === agent ? Date.now() : this.seen[agent] || 0;
  }
  stop() {
    const c = this.child;
    this.child = null;
    if (c) try { c.kill(); } catch { /* egal */ }
  }
}

module.exports = { ForegroundWatch, AGENT_OF };
