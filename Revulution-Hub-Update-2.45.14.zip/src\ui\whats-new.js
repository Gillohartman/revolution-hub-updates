'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.45.14',
  title: 'Revulution Hub 2.45.14',
  sub: 'Neues Design Pro, Foto-App, 3D-Modell, Plattenspieler, Kopfhörer-Animation und vieles mehr.',
  items: [
    { open: 'settings', icon: 'palette', title: 'Design Pro', text: 'Ruhig und kompakt wie Profi-Software – jetzt der Standard. Nach Updates kannst du das Design mit Live-Vorschau wählen; Liquid Glass bleibt unter Einstellungen → Design.' },
    { open: 'tool-photo', icon: 'image', title: 'Foto', text: 'Bilder bearbeiten wie in Photoshop: Ebenen, Masken, Korrekturen, Filter, Bildgrösse, Text und Formen.' },
    { open: 'model3d', icon: 'cube', title: '3D-Modell', text: 'Für den 3D-Druck: Druckbett, viele fertige Formen, Ecken ziehen, Löcher und Verbinden, Export als STL und 3MF – mit Tutorial.' },
    { open: 'tool-draw', icon: 'palette', title: 'Zeichnen', text: 'Unendliche Blätter, scharf in jeder Zoomstufe, zusammen live zeichnen, Formen-Assistent, Lasso, Stift-Tasten frei belegbar.' },
    { open: 'tool-player', icon: 'music', title: 'Player & Plattenspieler', text: 'Cover und Titel kommen so schnell wie in der Island. Neu: grosser Plattenspieler mit Tonarm.' },
    { open: 'orbit', icon: 'island', title: 'Island & Kopfhörer', text: 'Neues Island-Design kommt mit jedem Update. AirPods und Kopfhörer erscheinen als 3D-Animation mit Akkuring; Taskleiste frei einfärbbar.' },
    { open: 'tool-recherche', icon: 'search', title: 'Recherche', text: 'Werkzeugkasten für Domains, IPs, Webseiten und Dateien: WHOIS, DNS, SSL, Weiterleitungen, Archiv, Metadaten, Hashes, E-Mail-Header.' },
    { open: 'tool-support', icon: 'chat', title: 'Support-Chat', text: 'Thema wählen, Entwurf anpassen, senden – Antworten kommen direkt im Chat.' },
    { open: 'home', icon: 'spark', title: 'Feinschliff', text: 'Neue App-Logos, vollere Startseite, Dokumente ohne Kästchen, Notizen-/To-do-Widget tippbar, Zeitklick im Autoclicker, aufgeräumter Code.' },
  ],
};
