'use strict';

/*
 * 2.47.2 Revolution Cloud – eigener Speicher für Premium (10 GB) und Max (350 GB).
 * Spricht mit dem Cloudflare-Worker (tools/cloud-worker/worker.js); der prüft Anmeldung, Plan und Platz.
 * Große Dateien (z. B. Clips) gehen in Teilen à 90 MB hoch.
 */
const fs = require('fs');
const path = require('path');

class CloudDrive {
  /** @param {{ base: () => string, token: () => Promise<string> }} o */
  constructor(o) {
    this.o = o;
  }

  base() {
    const b = String(this.o.base() || '').trim().replace(/\/+$/, '');
    return /^https:\/\/[^\s"'<>]+$/i.test(b) ? b : '';
  }

  async call(p, { method = 'GET', body, headers = {}, raw = false } = {}) {
    const base = this.base();
    if (!base) throw new Error('Die Revolution Cloud wird gerade eingerichtet.');
    const token = await this.o.token().catch(() => '');
    if (!token) throw new Error('Für die Cloud mit deinem Revolution-Konto anmelden.');
    const r = await fetch(`${base}${p}`, { method, body, headers: { authorization: `Bearer ${token}`, ...headers }, duplex: body && typeof body !== 'string' && !(body instanceof Buffer) ? 'half' : undefined });
    if (raw) {
      if (!r.ok) throw new Error(`Cloud-Fehler (${r.status})`);
      return r;
    }
    const j = await r.json().catch(() => null);
    if (!j?.ok) throw new Error(j?.error || `Cloud-Fehler (${r.status})`);
    return j;
  }

  usage() {
    return this.call('/usage');
  }

  list(prefix = '') {
    return this.call(`/list?prefix=${encodeURIComponent(prefix)}`);
  }

  remove(p) {
    return this.call(`/file?path=${encodeURIComponent(p)}`, { method: 'DELETE' });
  }

  /** Datei hochladen – kleine in einem Stück, große in Teilen. */
  async upload(file, remote, onProgress) {
    const size = fs.statSync(file).size;
    const type = /\.(mp4|webm|mov)$/i.test(file) ? 'video/mp4' : /\.(png)$/i.test(file) ? 'image/png' : /\.(jpe?g)$/i.test(file) ? 'image/jpeg' : 'application/octet-stream';
    if (size <= 90 * 1024 * 1024) {
      const buf = fs.readFileSync(file);
      await this.call(`/file?path=${encodeURIComponent(remote)}`, { method: 'PUT', body: buf, headers: { 'content-type': type, 'content-length': String(size) } });
      onProgress?.(1);
      return { size };
    }
    const m = await this.call('/mpu/create', { method: 'POST', body: JSON.stringify({ path: remote, size }), headers: { 'content-type': 'application/json' } });
    const parts = [];
    const fd = fs.openSync(file, 'r');
    try {
      let n = 1;
      for (let off = 0; off < size; off += m.partSize, n++) {
        const len = Math.min(m.partSize, size - off);
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, off);
        const r = await this.call(`/mpu/part?path=${encodeURIComponent(remote)}&uploadId=${encodeURIComponent(m.uploadId)}&n=${n}`, { method: 'PUT', body: buf, headers: { 'content-length': String(len) } });
        parts.push(r.part);
        onProgress?.(Math.min(1, (off + len) / size));
      }
      await this.call('/mpu/complete', { method: 'POST', body: JSON.stringify({ path: remote, uploadId: m.uploadId, parts }), headers: { 'content-type': 'application/json' } });
    } catch (e) {
      await this.call('/mpu/abort', { method: 'POST', body: JSON.stringify({ path: remote, uploadId: m.uploadId }), headers: { 'content-type': 'application/json' } }).catch(() => {});
      throw e;
    } finally {
      fs.closeSync(fd);
    }
    return { size };
  }

  async download(remote, dest, onProgress) {
    const r = await this.call(`/file?path=${encodeURIComponent(remote)}`, { raw: true });
    const total = Number(r.headers.get('content-length')) || 0;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const out = fs.createWriteStream(`${dest}.part`);
    let got = 0;
    for await (const chunk of r.body) {
      got += chunk.length;
      if (!out.write(chunk)) await new Promise((res) => out.once('drain', res));
      if (total) onProgress?.(got / total);
    }
    await new Promise((res, rej) => out.end((e) => (e ? rej(e) : res())));
    fs.renameSync(`${dest}.part`, dest);
    return dest;
  }
}

module.exports = { CloudDrive };
