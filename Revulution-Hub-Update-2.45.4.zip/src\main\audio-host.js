'use strict';
/**
 * Startet die Audio-Engine (unsichtbares Fenster src/ui/audio-engine.html) und reicht Befehle durch (2.45.8):
 * Soundboard-Sound abspielen (Widget + Stream Deck), alles stoppen, stummschalten, Mikrofon-Mix einstellen.
 * Die Seite hat keinen Node-Zugriff; sie bekommt die Sounds als Data-URL. Mikrofon-Zugriff nur für diese Seite.
 */
const path = require('path');
const { BrowserWindow, session } = require('electron');

class AudioHost {
  constructor({ soundData, onState }) {
    this.soundData = soundData; // (pad) => { data, ver }
    this.onState = onState;
    this.win = null;
    this.ready = null;
    this.muted = false;
    this.mix = null;
  }

  ensure() {
    if (this.win && !this.win.isDestroyed()) return this.ready;
    const ses = session.fromPartition('rev-audio-engine');
    // Nur Audio/Mikrofon erlauben – sonst nichts
    ses.setPermissionRequestHandler((_wc, perm, cb, details) => cb(perm === 'media' && !(details?.mediaTypes || []).includes('video')));
    ses.setPermissionCheckHandler((_wc, perm) => perm === 'media' || perm === 'speaker-selection');
    ses.setDevicePermissionHandler?.(() => false);
    this.win = new BrowserWindow({
      show: false, width: 200, height: 100, skipTaskbar: true,
      webPreferences: { partition: 'rev-audio-engine', contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' },
    });
    this.win.webContents.on('will-navigate', (e) => e.preventDefault());
    this.win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    this.win.on('closed', () => { this.win = null; this.ready = null; });
    this.ready = this.win.loadFile(path.join(__dirname, '..', 'ui', 'audio-engine.html')).then(async () => {
      if (this.muted) await this.run('mute', true);
      if (this.mix) await this.run('config', this.mix);
      return true;
    });
    return this.ready;
  }

  async run(fn, arg) {
    await this.ensure();
    return this.win.webContents.executeJavaScript(`window.__engine.${fn}(${arg === undefined ? '' : JSON.stringify(arg)})`, true);
  }

  async play(pad, volume = 1) {
    const i = Math.max(0, Math.min(7, Number(pad) || 0));
    const { data, ver } = this.soundData(i);
    return this.run('play', { pad: i, volume: Math.max(0, Math.min(1.5, Number(volume ?? 1))), data, ver });
  }

  stop() { return this.win ? this.run('stop') : true; }

  async setMuted(on) {
    this.muted = Boolean(on);
    const s = this.win || this.mix?.on ? await this.run('mute', this.muted) : { muted: this.muted };
    this.onState?.(await this.status());
    return s;
  }

  async configure(mix) {
    this.mix = mix;
    if (!mix?.on && !this.win) return this.status();
    await this.run('config', mix);
    const s = await this.status();
    this.onState?.(s);
    return s;
  }

  devices() { return this.run('devices'); }

  async status() {
    if (!this.win) return { muted: this.muted, mix: this.mix || { on: false }, active: false, level: 0 };
    return this.run('status');
  }

  destroy() { if (this.win && !this.win.isDestroyed()) this.win.destroy(); this.win = null; }
}

module.exports = { AudioHost };
