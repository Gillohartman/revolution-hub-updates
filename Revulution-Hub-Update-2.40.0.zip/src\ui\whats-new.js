'use strict';
/* „Was ist neu“: nur die Neuerungen dieser Version – ältere Einträge stehen nicht mehr drin. */
window.WHATS_NEW = {
  version: '2.40.0',
  title: 'Revulution Hub 2.40',
  sub: 'Feinschliff: runde Leisten, ruhige Knöpfe, dunkle Menüs und der normale Mauszeiger.',
  items: [
    { open: 'chats', icon: 'layers', title: 'Komplett runde Leisten', text: 'Auswahl-Leisten wie „Erstellen/Beitreten“ oder „Medien/Clips“ sind jetzt ganz rund – wie alle anderen Menüs.' },
    { open: 'chats', icon: 'chat', title: 'Keine Striche mehr', text: 'Knöpfe wie „Anrufen“ werden beim Drüberfahren nur sanft heller.' },
    { open: 'settings', icon: 'grid', title: 'Dunkle Aufklapp-Menüs', text: 'Auswahllisten sind dunkel und gut lesbar statt weiß.' },
    { open: 'home', icon: 'spark', title: 'Durchsichtige Beschreibungen', text: 'Die Infos beim Drüberfahren sind jetzt durchsichtig statt schwarz.' },
    { open: 'home', icon: 'pointer', title: 'Normaler Mauszeiger', text: 'Überall der Windows-Mauszeiger – er wechselt nicht mehr zur Hand.' },
  ],
};
