'use strict';

/*
 * iPhone-Spiegelung über AirPlay (Empfänger für Windows).
 *
 * Der Hub richtet dafür den freien Empfänger „AirPlay-Windows“ (GPL-3.0,
 * github.com/moieric11/AirPlay-Windows) ein: Download des offiziellen Windows-ZIPs
 * aus den GitHub-Releases, entpacken, starten. Das Spiegelungsfenster wird per
 * Windows-Fensteraufnahme in den Hub geholt (siehe main.js), damit die Spiegelung
 * im Hub sichtbar ist. Der Empfänger läuft als eigenes Programm – der Hub steuert
 * nur Start/Stop und die Anzeige.
 */
const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');

const REPO = 'moieric11/AirPlay-Windows';
const API = `https://api.github.com/repos/${REPO}/releases/latest`;
const PAGE = `https://github.com/${REPO}/releases`;

class AirPlay {
  constructor({ dir, onChange }) {
    this.dir = path.join(dir, 'airplay');
    this.onChange = onChange || (() => {});
    this.proc = null;
    this.installing = 0;
    this.error = '';
    this.version = '';
  }

  exe() {
    const walk = (d, depth = 0) => {
      let entries;
      try {
        entries = fs.readdirSync(d, { withFileTypes: true });
      } catch {
        return '';
      }
      for (const e of entries) {
        const f = path.join(d, e.name);
        if (e.isFile() && /^airplay-windows\.exe$/i.test(e.name)) return f;
      }
      if (depth >= 3) return '';
      for (const e of entries) {
        if (!e.isDirectory()) continue;
        const found = walk(path.join(d, e.name), depth + 1);
        if (found) return found;
      }
      return '';
    };
    return walk(this.dir);
  }

  status() {
    return {
      installed: Boolean(this.exe()),
      installing: this.installing,
      running: Boolean(this.proc),
      error: this.error,
      version: this.version,
      name: this.name || String(require('os').hostname() || 'PC'),
      page: PAGE,
    };
  }

  notify() {
    this.onChange(this.status());
  }

  async install() {
    if (this.exe() || this.installing) return this.status();
    this.installing = 0.01;
    this.error = '';
    this.notify();
    try {
      const { net } = require('electron');
      const headers = { 'User-Agent': 'Revolution-Hub', Accept: 'application/vnd.github+json' };
      const rel = await net.fetch(API, { headers });
      if (!rel.ok) throw new Error(rel.status === 403 ? 'GitHub begrenzt gerade die Anfragen – später erneut versuchen' : `GitHub antwortet nicht (${rel.status})`);
      const data = await rel.json();
      this.version = String(data.tag_name || '').replace(/^v/, '');
      const assets = Array.isArray(data.assets) ? data.assets : [];
      const asset =
        assets.find((a) => /\.zip$/i.test(a.name) && /(win|x64|windows)/i.test(a.name)) ||
        assets.find((a) => /\.zip$/i.test(a.name));
      if (!asset) throw new Error('Kein Windows-Paket im Release gefunden');

      fs.mkdirSync(this.dir, { recursive: true });
      const res = await net.fetch(asset.browser_download_url, { headers: { 'User-Agent': 'Revolution-Hub' } });
      if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
      const total = Number(res.headers.get('content-length')) || Number(asset.size) || 0;
      const chunks = [];
      let got = 0;
      let last = 0;
      if (res.body?.getReader) {
        const reader = res.body.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(Buffer.from(value));
          got += value.length;
          if (total) this.installing = Math.min(0.9, (got / total) * 0.9);
          if (Date.now() - last > 300) {
            last = Date.now();
            this.notify();
          }
        }
      } else {
        chunks.push(Buffer.from(await res.arrayBuffer()));
      }
      const zip = path.join(this.dir, 'airplay-windows.zip');
      fs.writeFileSync(zip, Buffer.concat(chunks));
      this.installing = 0.93;
      this.notify();
      await new Promise((resolve, reject) =>
        execFile(
          'powershell.exe',
          ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${this.dir.replace(/'/g, "''")}' -Force`],
          { windowsHide: true, timeout: 300000 },
          (e) => (e ? reject(new Error('Entpacken fehlgeschlagen')) : resolve()),
        ),
      );
      fs.rmSync(zip, { force: true });
      if (!this.exe()) throw new Error('airplay-windows.exe fehlt im Paket');
    } catch (error) {
      this.error = String(error?.message || error);
    }
    this.installing = 0;
    this.notify();
    return this.status();
  }

  /** Empfänger-Einstellungen vor dem Start: Name = PC-Name, randlos, Fenster außerhalb des Bildschirms. */
  prepareSettings() {
    try {
      const dir = path.join(process.env.APPDATA || '', 'AirPlay-Windows');
      fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, 'settings.ini');
      const cur = {};
      try {
        for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
          const i = line.indexOf('=');
          if (i > 0) cur[line.slice(0, i).trim()] = line.slice(i + 1).trim();
        }
      } catch {
        /* erste Einrichtung */
      }
      // Name: nur der PC-Name (keine Punkte/Backslashes, max. 50 Byte)
      let name = String(require('os').hostname() || 'PC').replace(/[.\\]/g, ' ').trim() || 'PC';
      while (Buffer.byteLength(name, 'utf8') > 50) name = name.slice(0, -1);
      Object.assign(cur, { receiver_name: name, chromeless: '1', fullscreen: '0', window_placement_valid: '1', window_x: '-7000', window_y: '120', window_maximized: '0' });
      fs.writeFileSync(file, Object.entries(cur).map(([k, v]) => `${k}=${v}`).join('\r\n') + '\r\n');
      this.name = name;
    } catch {
      /* Einstellungen sind optional */
    }
  }

  /** Solange der Empfänger läuft: Fenster aus der Taskleiste und vom Bildschirm fernhalten (es bleibt aufnehmbar). */
  hideWindow(pid) {
    const script = `$ErrorActionPreference='SilentlyContinue'
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class ApHide {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int i, int v);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int w, int hh, uint f);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  public static void Tick(uint pid) {
    EnumWindows((h, l) => {
      uint p; GetWindowThreadProcessId(h, out p);
      if (p != pid || !IsWindowVisible(h)) return true;
      int ex = GetWindowLong(h, -20);
      int want = (ex | 0x80) & ~0x40000; // WS_EX_TOOLWINDOW, nicht WS_EX_APPWINDOW → keine Taskleiste
      if (want != ex) { ShowWindow(h, 0); SetWindowLong(h, -20, want); ShowWindow(h, 8); }
      RECT r; GetWindowRect(h, out r);
      if (r.L > -5000) SetWindowPos(h, IntPtr.Zero, -7000, 120, 0, 0, 0x0001 | 0x0004 | 0x0010);
      return true;
    }, IntPtr.Zero);
  }
}
'@
while ($true) { if (-not (Get-Process -Id ${pid} -ErrorAction SilentlyContinue)) { break }; [ApHide]::Tick(${pid}); Start-Sleep -Milliseconds 700 }`;
    try {
      this.hider = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], { windowsHide: true, stdio: 'ignore' });
    } catch {
      /* ohne Verstecken */
    }
  }

  start() {
    if (this.proc) return this.status();
    this.error = '';
    this.prepareSettings();
    const exe = this.exe();
    if (!exe) {
      this.error = 'Bitte zuerst den Empfänger einrichten.';
      this.notify();
      return this.status();
    }
    try {
      const child = spawn(exe, [], { cwd: path.dirname(exe), windowsHide: false, stdio: 'ignore' });
      this.proc = child;
      this.hideWindow(child.pid);
      child.on('exit', () => {
        if (this.proc === child) this.proc = null;
        this.notify();
      });
      child.on('error', (error) => {
        this.proc = null;
        this.error = String(error?.message || error);
        this.notify();
      });
    } catch (error) {
      this.error = String(error?.message || error);
    }
    this.notify();
    return this.status();
  }

  stop() {
    const child = this.proc;
    this.proc = null;
    try {
      this.hider?.kill();
    } catch {
      /* schon weg */
    }
    this.hider = null;
    if (child?.pid) {
      execFile('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true }, () => {});
    }
    this.notify();
    return this.status();
  }

  /** AirPlay-Fenster nach vorn holen (falls die Einbettung nicht klappt). */
  focus() {
    return new Promise((resolve) => {
      const script = "$w = New-Object -ComObject WScript.Shell; if ($w.AppActivate('AirPlay')) { 'ok' } else { 'no' }";
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 8000 }, (e, out) => resolve(!e && String(out).trim() === 'ok'));
    });
  }

  shutdown() {
    this.stop();
  }
}

module.exports = { AirPlay, PAGE };
