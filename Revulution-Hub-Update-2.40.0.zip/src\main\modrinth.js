'use strict';

/* 2.38 Mod-Bibliothek: sucht über die öffentliche Modrinth-API (api.modrinth.com/v2) und legt
   Mods, Shader und Ressourcenpakete direkt in den passenden Ordner einer Minecraft-Installation.
   Heruntergeladen wird nur von cdn.modrinth.com; die SHA-1 aus der API wird geprüft. */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { gameDirs } = require('./schematics');

const API = 'https://api.modrinth.com/v2';
const UA = 'Revulution-Hub/2.38 (desktop app)';
const TYPE_DIR = { mod: 'mods', shader: 'shaderpacks', resourcepack: 'resourcepacks', datapack: 'datapacks' };

async function get(url) {
  const { net } = require('electron');
  const res = await net.fetch(url, { headers: { 'User-Agent': UA } });
  if (res.status === 429) throw new Error('Modrinth bremst gerade – bitte kurz warten.');
  if (!res.ok) throw new Error(`Modrinth nicht erreichbar (${res.status})`);
  return res.json();
}
const clean = (v, max = 60) => String(v ?? '').replace(/[^\w .:+-]/g, '').slice(0, max);

async function search(opts = {}) {
  const type = TYPE_DIR[opts.type] ? opts.type : 'mod';
  const facets = [[`project_type:${type}`]];
  if (opts.loader && type === 'mod') facets.push([`categories:${clean(opts.loader, 20).toLowerCase()}`]);
  if (opts.version) facets.push([`versions:${clean(opts.version, 20)}`]);
  if (opts.category) facets.push([`categories:${clean(opts.category, 30).toLowerCase()}`]);
  const sort = ['relevance', 'downloads', 'follows', 'newest', 'updated'].includes(opts.sort) ? opts.sort : 'relevance';
  const q = new URLSearchParams({ query: String(opts.q || '').slice(0, 100), facets: JSON.stringify(facets), index: sort, limit: '30', offset: String(Math.max(0, Number(opts.offset) || 0)) });
  const r = await get(`${API}/search?${q}`);
  return {
    total: r.total_hits || 0,
    hits: (r.hits || []).map((h) => ({ id: h.project_id, slug: h.slug, title: h.title, author: h.author, desc: h.description, icon: h.icon_url || '', downloads: h.downloads || 0, follows: h.follows || 0, cats: (h.display_categories || h.categories || []).slice(0, 4), versions: (h.versions || []).slice(-3), type: h.project_type, color: h.color, gallery: (h.gallery || []).slice(0, 1) })),
  };
}

async function project(id) {
  const p = await get(`${API}/project/${encodeURIComponent(clean(id, 40))}`);
  return { id: p.id, slug: p.slug, title: p.title, desc: p.description, body: String(p.body || '').slice(0, 6000), icon: p.icon_url || '', downloads: p.downloads, follows: p.followers, type: p.project_type, loaders: p.loaders || [], versions: (p.game_versions || []).slice(-12).reverse(), gallery: (p.gallery || []).slice(0, 6).map((g) => g.url), source: p.source_url || '', license: p.license?.id || '' };
}

async function versions(id, loader, version) {
  const q = new URLSearchParams();
  if (loader) q.set('loaders', JSON.stringify([clean(loader, 20).toLowerCase()]));
  if (version) q.set('game_versions', JSON.stringify([clean(version, 20)]));
  const list = await get(`${API}/project/${encodeURIComponent(clean(id, 40))}/version?${q}`);
  return list.slice(0, 20).map((v) => ({ id: v.id, name: v.name, number: v.version_number, type: v.version_type, loaders: v.loaders, games: v.game_versions.slice(-4), date: v.date_published, deps: (v.dependencies || []).filter((d) => d.dependency_type === 'required').length }));
}

async function gameVersions() {
  const list = await get(`${API}/tag/game_version`);
  return list.filter((v) => v.version_type === 'release').slice(0, 30).map((v) => v.version);
}

function targets() {
  return gameDirs().map((g) => ({ dir: g.dir, label: g.label }));
}

async function download(file) {
  const u = new URL(file.url);
  if (u.protocol !== 'https:' || u.hostname !== 'cdn.modrinth.com') throw new Error('Unerwartete Download-Adresse');
  const { net } = require('electron');
  const res = await net.fetch(u.toString(), { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error(`Download fehlgeschlagen (${res.status})`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > 200 * 1024 * 1024) throw new Error('Datei zu groß');
  const sha1 = crypto.createHash('sha1').update(buf).digest('hex');
  if (file.hashes?.sha1 && file.hashes.sha1 !== sha1) throw new Error('Prüfsumme stimmt nicht – Download verworfen');
  return buf;
}
const safeFile = (name) => path.basename(String(name)).replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 150);

/** Version installieren (+ benötigte Abhängigkeiten eine Ebene tief) in die gewählte Installation. */
async function install(versionId, dir, done = new Set()) {
  const known = targets().find((t) => t.dir.toLowerCase() === String(dir || '').toLowerCase());
  if (!known) throw new Error('Diese Minecraft-Installation kenne ich nicht');
  const v = await get(`${API}/version/${encodeURIComponent(clean(versionId, 40))}`);
  const p = await get(`${API}/project/${encodeURIComponent(v.project_id)}`);
  const sub = TYPE_DIR[p.project_type] || 'mods';
  const file = v.files.find((f) => f.primary) || v.files[0];
  if (!file) throw new Error('Keine Datei in dieser Version');
  const buf = await download(file);
  const outDir = path.join(known.dir, sub);
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, safeFile(file.filename)), buf);
  done.add(v.project_id);
  const installed = [{ name: p.title, file: safeFile(file.filename), folder: sub }];
  // Benötigte Abhängigkeiten (z. B. Fabric API) passend zur Version/Loader nachziehen
  if (done.size < 8) {
    for (const d of (v.dependencies || []).filter((x) => x.dependency_type === 'required')) {
      if (d.project_id && done.has(d.project_id)) continue;
      try {
        let depVer = d.version_id;
        if (!depVer && d.project_id) {
          const list = await versions(d.project_id, v.loaders[0], v.game_versions[v.game_versions.length - 1]);
          depVer = list[0]?.id;
        }
        if (depVer) installed.push(...(await install(depVer, known.dir, done)));
      } catch {
        /* Abhängigkeit nicht gefunden – Haupt-Mod ist trotzdem drin */
      }
    }
  }
  return installed;
}

function installedList(dir) {
  const known = targets().find((t) => t.dir.toLowerCase() === String(dir || '').toLowerCase());
  if (!known) return [];
  const out = [];
  for (const sub of ['mods', 'shaderpacks', 'resourcepacks']) {
    try {
      for (const f of fs.readdirSync(path.join(known.dir, sub))) if (/\.(jar|zip|disabled)$/i.test(f)) out.push({ file: f, folder: sub, off: /\.disabled$/i.test(f) });
    } catch {
      /* Ordner fehlt */
    }
  }
  return out;
}

/** Mod an/aus (".disabled") oder in den Papierkorb – nur Dateien in bekannten Installationen. */
async function modAction(dir, folder, file, action) {
  const known = targets().find((t) => t.dir.toLowerCase() === String(dir || '').toLowerCase());
  if (!known || !['mods', 'shaderpacks', 'resourcepacks'].includes(folder)) throw new Error('Unbekannter Ordner');
  const p = path.join(known.dir, folder, safeFile(file));
  if (!fs.existsSync(p)) throw new Error('Datei nicht gefunden');
  if (action === 'toggle') {
    const next = /\.disabled$/i.test(p) ? p.replace(/\.disabled$/i, '') : `${p}.disabled`;
    fs.renameSync(p, next);
    return true;
  }
  if (action === 'trash') {
    await require('electron').shell.trashItem(p);
    return true;
  }
  if (action === 'folder') {
    require('electron').shell.showItemInFolder(p);
    return true;
  }
  return false;
}

module.exports = { search, project, versions, gameVersions, targets, install, installedList, modAction };
