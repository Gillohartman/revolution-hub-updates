'use strict';

/* 2.39 Erfolge: aus echten Daten im Hub (Pflanze, Bildschirmzeit, Clips, Punkte, WLAN-Tests, Likes …).
   Jede Stufe gibt einmalig ◆ Punkte. Punkte sind Spielgeld: nicht kaufbar, nicht in Coins tauschbar. */
const fs = require('fs');
const path = require('path');

// [id, Titel, Symbol, Einheit, Stufen[], Punkte pro Stufe, Beschreibung]
const DEFS = [
  ['plant', 'Gärtner', '🌱', 'Stufen', [1, 5, 10, 18, 27], 40, 'Lass deine Pixel-Pflanze wachsen.'],
  ['screen', 'Dauergast', '⏳', 'Stunden am PC', [10, 50, 150, 400, 1000], 30, 'Gesamte Bildschirmzeit.'],
  ['days', 'Treu', '📅', 'Tage', [3, 7, 30, 100, 365], 50, 'An so vielen Tagen den Hub genutzt.'],
  ['clips', 'Clipper', '🎬', 'Clips', [1, 10, 50, 200, 500], 40, 'Clips im Gaming Hub gespeichert.'],
  ['points', 'Sammler', '◆', 'Punkte', [100, 500, 2000, 10000, 50000], 0, 'So viele ◆ Punkte gesammelt.'],
  ['speed', 'Netzwerker', '📶', 'WLAN-Tests', [1, 5, 20, 50], 20, 'WLAN-Tests gemacht.'],
  ['likes', 'Geschmack', '♥', 'Likes', [1, 5, 15, 40], 15, 'Hintergründe geliked.'],
  ['widgets', 'Desktop-Designer', '🧩', 'Widgets', [2, 4, 7, 10], 25, 'Gleichzeitig aktive Desktop-Widgets.'],
  ['cosmetics', 'Stilsicher', '✨', 'Designs', [1, 5, 15, 30], 30, 'Designs im Store freigeschaltet.'],
];

function countClips(dir, depth = 0) {
  if (!dir || depth > 3) return 0;
  let n = 0;
  try {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.isDirectory()) n += countClips(path.join(dir, e.name), depth + 1);
      else if (/\.(mp4|mkv|mov|webm)$/i.test(e.name)) n += 1;
    }
  } catch {
    /* Ordner fehlt */
  }
  return n;
}

class Achievements {
  /** @param {{ settings: () => any, save: (p: any) => void, profile: () => any, earn: (n: number) => void, screen: () => any, clipDirs: () => string[], likes: () => number, notify: (t: string, b: string) => void }} o */
  constructor(o) {
    this.o = o;
    this.clipCache = { at: 0, n: 0 };
  }

  stats() {
    const s = this.o.settings();
    const days = this.o.screen()?.data?.days || {};
    const totalSecs = Object.values(days).reduce((a, d) => a + (Number(d?.total) || 0), 0);
    if (Date.now() - this.clipCache.at > 10 * 60000) this.clipCache = { at: Date.now(), n: this.o.clipDirs().reduce((a, d) => a + countClips(d), 0) };
    const dw = s.desktopWidgets || {};
    const p = this.o.profile();
    const owned = Object.values(p.cos?.owned || {}).reduce((a, list) => a + (Array.isArray(list) ? list.length : 0), 0);
    return {
      plant: Number(s.plant?.stage) || 0,
      screen: Math.floor(totalSecs / 3600),
      days: Object.values(days).filter((d) => (Number(d?.total) || 0) > 60).length,
      clips: this.clipCache.n,
      points: Number(p.points) || 0,
      speed: Number(s.speedRuns) || (s.speedHistory || []).length,
      likes: this.o.likes(),
      widgets: dw.enabled === false ? 0 : Object.entries(dw).filter(([k, v]) => v === true && !['enabled', 'cards'].includes(k)).length,
      cosmetics: owned,
    };
  }

  /** Liste mit Fortschritt; neue Stufen werden gutgeschrieben (Punkte) und gemeldet. */
  list(award = true) {
    const st = this.stats();
    const s = this.o.settings();
    const claimed = { ...(s.achClaimed || {}) };
    let gained = 0;
    const fresh = [];
    const out = DEFS.map(([id, title, icon, unit, tiers, reward, desc]) => {
      const v = st[id] || 0;
      const tier = tiers.filter((t) => v >= t).length;
      const had = Number(claimed[id]) || 0;
      if (award && tier > had) {
        gained += reward * (tier - had);
        claimed[id] = tier;
        fresh.push(`${icon} ${title} · Stufe ${tier}`);
      }
      const next = tiers[tier] ?? null;
      const prevT = tier ? tiers[tier - 1] : 0;
      return { id, title, icon, unit, desc, value: v, tier, tiers: tiers.length, next, progress: next ? Math.max(0, Math.min(1, (v - prevT) / (next - prevT))) : 1, reward };
    });
    if (award && fresh.length) {
      this.o.save({ achClaimed: claimed });
      if (gained) this.o.earn(gained);
      this.o.notify('Erfolg freigeschaltet', `${fresh.slice(0, 2).join(', ')}${gained ? ` · +${gained} ◆` : ''}`);
    }
    return { list: out, stats: st, total: out.reduce((a, x) => a + x.tier, 0), max: out.reduce((a, x) => a + x.tiers, 0) };
  }

  /** Was Freunde sehen dürfen (über die Chats): nur Name, Punkte und Erfolge – keine Dateien, keine Apps. */
  publicCard() {
    const p = this.o.profile();
    const r = this.list(false);
    return { name: p.name || 'Spieler', points: Number(p.points) || 0, total: r.total, max: r.max, ach: r.list.map((a) => ({ id: a.id, title: a.title, icon: a.icon, tier: a.tier, tiers: a.tiers, value: a.value, unit: a.unit })) };
  }
}

module.exports = { Achievements };
