'use strict';
/*
 * Der Coach als Charakter: Gesicht mit Augen und Mund, spricht mit der Windows-Stimme
 * (Web Speech, offline) und bewegt dabei den Mund. Stimmung je nach Zug (froh, besorgt, nachdenklich).
 */
(function () {
  const svg = `<svg viewBox="0 0 120 120" class="ca-svg" aria-hidden="true">
    <defs>
      <radialGradient id="ca-skin" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#f8d6b6"/><stop offset="1" stop-color="#e7bb93"/></radialGradient>
      <linearGradient id="ca-hair" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e6c584"/><stop offset="1" stop-color="#c09a56"/></linearGradient>
    </defs>
    <ellipse cx="60" cy="113" rx="36" ry="6" fill="rgba(0,0,0,.28)"/>
    <path d="M22 48c-6 22-4 46 6 60h64c10-14 12-38 6-60Z" fill="#3a2418"/>
    <path d="M20 114c2-20 18-31 40-31s38 11 40 31Z" fill="#111114"/>
    <path d="M44 86q16 14 32 0l4 3q-20 22-40 0Z" fill="#ff2d2d"/>
    <path d="M53 76h14v11q-7 4-14 0Z" fill="#e7bb93"/>
    <circle cx="60" cy="55" r="34" fill="url(#ca-skin)"/>
    <ellipse cx="27" cy="57" rx="5" ry="8" fill="#e7bb93"/><ellipse cx="93" cy="57" rx="5" ry="8" fill="#e7bb93"/>
    <path d="M24 56c-2-28 14-44 37-44 22 0 38 15 36 44-4-12-10-20-18-24-7 8-22 13-38 12-7 3-13 7-17 12Z" fill="#4a2c1d"/>
    <path d="M33 28c9-9 22-12 33-9-11 3-22 9-29 18Z" fill="#6b4029"/>
    <circle cx="27" cy="66" r="2.4" fill="#ff2d2d"/><circle cx="93" cy="66" r="2.4" fill="#ff2d2d"/>
    <g class="ca-brows"><path class="ca-brow l" d="M38 42q8-5 15 0"/><path class="ca-brow r" d="M67 42q7-5 15 0"/></g>
    <g class="ca-eyes"><ellipse class="ca-eye" cx="46" cy="54" rx="5" ry="6"/><ellipse class="ca-eye" cx="74" cy="54" rx="5" ry="6"/>
      <circle cx="47.5" cy="52" r="1.6" fill="#fff"/><circle cx="75.5" cy="52" r="1.6" fill="#fff"/>
      <path d="M40 49l-3-3M42 47.5l-2-3.5M80 49l3-3M78 47.5l2-3.5" stroke="#2a1a12" stroke-width="1.3" stroke-linecap="round"/></g>
    <path d="M60 55v8l3 2" fill="none" stroke="#d8a67f" stroke-width="1.6" stroke-linecap="round"/>
    <ellipse cx="35" cy="68" rx="6" ry="3.5" fill="#ef9a8f" opacity=".3"/><ellipse cx="85" cy="68" rx="6" ry="3.5" fill="#ef9a8f" opacity=".3"/>
    <path class="ca-mouth ca-lips" d="M47 72q13 9 26 0"/>
  </svg>`;
  const MOUTH = {
    smile: 'M48 72q12 9 24 0',
    flat: 'M50 74q10 1 20 0',
    worried: 'M50 77q10-6 20 0',
    o: 'M54 72q6-6 12 0q-6 9-12 0Z',
    open: 'M48 70q12-2 24 0q-12 14-24 0Z',
    half: 'M49 71q11 0 22 0q-11 8-22 0Z',
    wide: 'M46 70q14-3 28 0q-14 12-28 0Z',
  };
  const MOODS = { brilliant: 'happy', great: 'happy', best: 'happy', excellent: 'happy', good: 'happy', book: 'happy', inaccuracy: 'think', mistake: 'worried', miss: 'worried', blunder: 'worried', think: 'think' };

  let el = null, mouth = null, mood = 'happy', talking = null, lastText = '', voice = null;
  const pickVoice = (lang, male = false) => {
    const vs = window.speechSynthesis?.getVoices() || [];
    const same = vs.filter((v) => v.lang?.toLowerCase().startsWith(lang));
    if (male) {
      // Magnus-Stil: tiefe Männerstimme, zuerst hochwertige Natural-Stimmen.
      const man = /thorsten|conrad|stefan|klaus|georg|christoph|ryan|david|guy|male|mann/i;
      return same.find((v) => man.test(v.name) && /natural|online/i.test(v.name)) || same.find((v) => man.test(v.name)) || same.find((v) => /natural|online/i.test(v.name)) || same[0] || null;
    }
    // Weibliche Stimme als Standard (Hedda, Katja, Zira, Sabina …).
    const female = /hedda|katja|zira|sabina|aria|jenny|sonia|natasha|helena|female|frau/i;
    return same.find((v) => female.test(v.name) && /natural|online/i.test(v.name)) || same.find((v) => female.test(v.name)) || same.find((v) => /natural|online/i.test(v.name)) || same[0] || null;
  };
  window.speechSynthesis?.addEventListener?.('voiceschanged', () => (voice = null));

  function rest() {
    if (mouth) mouth.setAttribute('d', mood === 'worried' ? MOUTH.worried : mood === 'think' ? MOUTH.flat : MOUTH.smile);
  }
  function setMood(m) {
    mood = m || 'happy';
    if (el) el.dataset.mood = mood;
    if (!talking) rest();
  }
  function stopTalking() {
    clearInterval(talking);
    talking = null;
    el?.classList.remove('talking');
    rest();
  }
  function startTalking() {
    clearInterval(talking);
    el?.classList.add('talking');
    const shapes = [MOUTH.half, MOUTH.open, MOUTH.o, MOUTH.wide, MOUTH.half, MOUTH.flat];
    talking = setInterval(() => mouth?.setAttribute('d', shapes[Math.floor(Math.random() * shapes.length)]), 95);
  }
  const clean = (html) => {
    const d = document.createElement('div');
    d.innerHTML = String(html || '');
    d.querySelectorAll('button').forEach((b) => b.remove());
    return d.textContent.replace(/\s+/g, ' ').replace(/[♔-♟◆★✓✗⏱]/g, '').trim();
  };
  // Schachnotation vorlesbar machen: Sf3 → Springer f3, exd5 → e schlägt d5
  const speakable = (t, lang) => {
    if (lang !== 'de') return t;
    const P = { K: 'König', D: 'Dame', T: 'Turm', L: 'Läufer', S: 'Springer' };
    return t
      .replace(/\b([KDTLS])([a-h]?[1-8]?)x([a-h][1-8])[+#]?/g, (_, p, _d, sq) => `${P[p]} schlägt ${sq}`)
      .replace(/\b([KDTLS])[a-h]?[1-8]?([a-h][1-8])[+#]?/g, (_, p, sq) => `${P[p]} ${sq}`)
      .replace(/\b([a-h])x([a-h][1-8])[+#]?/g, '$1 schlägt $2')
      .replace(/\bO-O-O\b/g, 'lange Rochade')
      .replace(/\bO-O\b/g, 'kurze Rochade');
  };

  window.CoachAvatar = {
    mount(host) {
      if (!host) return;
      host.innerHTML = svg;
      el = host;
      el.classList.add('coach-avatar');
      mouth = host.querySelector('.ca-mouth');
      setMood('happy');
      // Gesicht bleibt ruhig – nur der Mund bewegt sich beim Sprechen
    },
    mood: setMood,
    moodFor: (cls) => MOODS[cls] || 'happy',
    /** Spricht den Text (HTML erlaubt). on = Stimme an, sonst nur Mundbewegung. */
    natural: false, // Piper-Stimme verwenden (falls installiert)
    magnus: false, // Original-Clip als Begrüßung, danach die natürliche Ersatzstimme
    magnusDone: false,
    /* Nicht mehr abschneiden: kommt ein neuer Satz, während sie noch spricht, wartet er,
       bis der alte fertig ist. Nur der jeweils neueste wartende Satz bleibt in der Schlange. */
    say(html, opts = {}) {
      // 2.38: in der Lobby / im Start-Fenster schweigt der Coach
      const lobby = document.getElementById('lobby');
      if (lobby && !lobby.hidden && !opts.force) return Promise.resolve();
      const text = clean(html);
      if (opts.cls) setMood(MOODS[opts.cls] || 'happy');
      if (!text || text === lastText) return Promise.resolve();
      lastText = text;
      const ticket = (this.ticket = (this.ticket || 0) + 1);
      const gen = this.gen || 0;
      const run = () => (ticket === this.ticket || !this.busy ? (gen === (this.gen || 0) ? this.sayNow(text, opts) : null) : null);
      const wait = this.busy || Promise.resolve();
      const p = wait.then(run, run).finally(() => {
        if (this.busy === p) this.busy = null;
      });
      this.busy = p;
      return p;
    },
    sayNow(text, { on = true, lang = 'de' } = {}) {
      if (on && this.magnus && !this.magnusDone) {
        this.magnusDone = true;
        return this.sayMagnus().then((ok) => {
          if (ok) return null;
          return this.natural && window.chessTts
            ? this.sayNatural(speakable(text, lang), this.voiceId || lang).catch(() => this.sayWindows(text, lang))
            : this.sayWindows(text, lang, true);
        });
      }
      if (on && this.natural && window.chessTts) return this.sayNatural(speakable(text, lang), this.voiceId || lang).catch(() => this.sayWindows(text, lang));
      return this.sayWindows(text, lang, on);
    },
    /** Den mitgelieferten Magnus-Clip abspielen (3,5 s). */
    sayMagnus() {
      this.quietAudio();
      window.speechSynthesis?.cancel();
      const audio = (this.magnusAudio ||= new Audio('assets/magnus-carlsen.mp3'));
      audio.pause();
      audio.currentTime = 0;
      audio.volume = 1;
      startTalking();
      return new Promise((resolve) => {
        let done = false;
        const finish = (ok) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          stopTalking();
          resolve(ok);
        };
        const timer = setTimeout(() => finish(true), 5000);
        audio.onended = () => finish(true);
        audio.onerror = () => finish(false);
        audio.play().catch(() => finish(false));
      });
    },
    /** Piper: WAV abspielen, Mund folgt der Lautstärke. */
    async sayNatural(text, lang) {
      this.quietAudio();
      const id = (this.seq = (this.seq || 0) + 1);
      const bytes = await window.chessTts.speak(text, lang);
      if (id !== this.seq) return;
      const ac = (this.ac ||= new AudioContext());
      const buf = await ac.decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
      if (id !== this.seq) return;
      const src = ac.createBufferSource();
      const an = ac.createAnalyser();
      an.fftSize = 512;
      src.buffer = buf;
      src.connect(an);
      an.connect(ac.destination);
      this.src = src;
      el?.classList.add('talking');
      const data = new Uint8Array(an.fftSize);
      const shapes = [MOUTH.flat, MOUTH.half, MOUTH.o, MOUTH.open, MOUTH.wide];
      const loop = () => {
        if (this.src !== src) return;
        an.getByteTimeDomainData(data);
        let sum = 0;
        for (const v of data) sum += (v - 128) * (v - 128);
        const rms = Math.sqrt(sum / data.length) / 128;
        mouth?.setAttribute('d', shapes[Math.min(shapes.length - 1, Math.floor(rms * 18))]);
        requestAnimationFrame(loop);
      };
      return new Promise((resolve) => {
        src.onended = () => {
          if (this.src === src) this.src = null;
          stopTalking();
          resolve();
        };
        src.start();
        loop();
      });
    },
    quietAudio() {
      try {
        this.src?.stop();
      } catch {}
      this.src = null;
      try {
        this.magnusAudio?.pause();
        if (this.magnusAudio) this.magnusAudio.currentTime = 0;
      } catch {}
    },
    sayWindows(text, lang = 'de', on = true) {
      const synth = window.speechSynthesis;
      if (!on || !synth) {
        startTalking();
        clearTimeout(this.t);
        this.t = setTimeout(stopTalking, Math.min(4000, 300 + text.length * 45));
        return Promise.resolve();
      }
      synth.cancel();
      return new Promise((resolve) => {
        const u = new SpeechSynthesisUtterance(speakable(text, lang).slice(0, 400));
        voice = (this.winVoice && (window.speechSynthesis.getVoices() || []).find((v) => v.name === this.winVoice)) || (this.magnus ? pickVoice(lang, true) : voice || pickVoice(lang));
        if (voice) u.voice = voice;
        u.lang = { de: 'de-DE', en: 'en-US', es: 'es-ES' }[lang] || 'de-DE';
        u.rate = this.magnus ? 0.96 : 1.04;
        u.pitch = this.magnus ? 0.78 : 1.05;
        u.onstart = startTalking;
        const done = () => {
          stopTalking();
          resolve();
        };
        u.onend = done;
        u.onerror = done;
        synth.speak(u);
        // Sicherheitsnetz, falls Windows kein Ende meldet
        setTimeout(done, 1500 + text.length * 90);
      });
    },
    quiet() {
      this.gen = (this.gen || 0) + 1;
      this.busy = null;
      this.seq = (this.seq || 0) + 1;
      this.quietAudio();
      window.speechSynthesis?.cancel();
      stopTalking();
      lastText = '';
    },
  };
})();
