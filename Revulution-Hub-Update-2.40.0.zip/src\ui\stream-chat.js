'use strict';

/* Stream-Chat als Overlay: neueste Nachrichten unten, ältere blenden nach 30 s aus. */
(() => {
  const list = document.getElementById('list');
  const st = document.getElementById('st');
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const color = (m) => m.color || `hsl(${[...String(m.user || '?')].reduce((a, c) => a + c.charCodeAt(0), 0) % 360} 80% 70%)`;

  function add(msgs) {
    for (const m of msgs || []) {
      const el = document.createElement('div');
      el.className = `m ${m.kind && m.kind !== 'chat' ? 'sys' : ''}`;
      el.innerHTML = `${m.user ? `<b style="color:${esc(color(m))}">${esc(m.user)}</b>` : ''}${esc(m.text)}`;
      list.appendChild(el);
      setTimeout(() => el.classList.add('old'), 30000);
      setTimeout(() => el.remove(), 31500);
    }
    while (list.children.length > 14) list.firstElementChild.remove();
  }
  function state(s) {
    if (!s) return;
    st.hidden = !s.cfg;
    st.innerHTML = s.status === 'live' ? `<i></i>${esc(s.cfg?.channel || '')}` : s.status === 'connecting' ? 'verbindet …' : esc(s.error || '');
  }
  window.hub.streamChat.onMsgs(add);
  window.hub.streamChat.onState(state);
  window.hub.streamChat
    .state()
    .then((s) => {
      state(s);
      add((s.msgs || []).slice(-6));
    })
    .catch(() => {});
})();
