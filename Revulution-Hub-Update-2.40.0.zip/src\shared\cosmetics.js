'use strict';

/*
 * Cosmetics für den ganzen Hub: ein Profil (Name, Punkte, Cosmetics) für Schach, Geo, Chats
 * und den Shop auf der Startseite. Katalog + Darstellung (Avatar, Namensfarbe, Titel).
 */
(function (root) {
  // Cosmetics: slot → Liste. Preis in Punkten (◆). Das erste Element je Slot ist gratis.
  // Cosmetics: slot → Liste. Preis in Punkten (◆). Das erste Element je Slot ist gratis.
  // Bewusst teuer: die besten Sachen brauchen viele Lektionen und Siege.
  const COSMETICS = {
    pieces: [
      { id: 'classic', price: 0, t: { de: 'Klassisch', en: 'Classic', es: 'Clásico' } },
      { id: 'marble', price: 400, t: { de: 'Marmor', en: 'Marble', es: 'Mármol' } },
      { id: 'neon', price: 900, t: { de: 'Neon', en: 'Neon', es: 'Neón' }, anim: true },
      { id: 'ice', price: 1200, t: { de: 'Eis', en: 'Ice', es: 'Hielo' }, anim: true },
      { id: 'emerald', price: 1500, t: { de: 'Smaragd', en: 'Emerald', es: 'Esmeralda' }, anim: true },
      { id: 'gold', price: 1800, t: { de: 'Gold', en: 'Gold', es: 'Oro' }, anim: true },
      { id: 'chrome', price: 2200, t: { de: 'Chrom', en: 'Chrome', es: 'Cromo' } },
      { id: 'fire', price: 2600, t: { de: 'Feuer', en: 'Fire', es: 'Fuego' }, anim: true },
      { id: 'obsidian', price: 2900, t: { de: 'Obsidian', en: 'Obsidian', es: 'Obsidiana' } },
      { id: 'void', price: 3200, t: { de: 'Leere', en: 'Void', es: 'Vacío' }, anim: true },
      { id: 'galaxy', price: 4500, t: { de: 'Galaxie', en: 'Galaxy', es: 'Galaxia' }, anim: true },
      { id: 'rainbow', price: 6000, t: { de: 'Regenbogen', en: 'Rainbow', es: 'Arcoíris' }, anim: true },
      { id: 'nothing', coins: 300, price: 1e9 /* nur im Revolution Store */, t: { de: 'Punktmatrix', en: 'Dot matrix', es: 'Matriz de puntos' } },
      { id: 'liquid', coins: 380, price: 1e9 /* nur im Revolution Store */, t: { de: 'Liquid Glass', en: 'Liquid Glass', es: 'Cristal líquido' }, anim: true },
      { id: 'chroma', coins: 260, price: 1e9 /* nur im Revolution Store */, t: { de: 'Chromatisch', en: 'Chromatic', es: 'Cromático' }, anim: true },
    ],
    board: [
      { id: 'standard', price: 0, t: { de: 'Standard', en: 'Standard', es: 'Estándar' } },
      { id: 'walnut', price: 500, t: { de: 'Walnuss', en: 'Walnut', es: 'Nogal' } },
      { id: 'marble', price: 800, t: { de: 'Marmor', en: 'Marble', es: 'Mármol' } },
      { id: 'sakura', price: 950, t: { de: 'Kirschblüte', en: 'Sakura', es: 'Sakura' } },
      { id: 'ocean', price: 1100, t: { de: 'Ozean', en: 'Ocean', es: 'Océano' }, anim: true },
      { id: 'glass', price: 1400, t: { de: 'Glas', en: 'Glass', es: 'Cristal' } },
      { id: 'royal', price: 2000, t: { de: 'Königlich', en: 'Royal', es: 'Real' } },
      { id: 'neon', price: 1600, t: { de: 'Neon-Raster', en: 'Neon grid', es: 'Rejilla neón' }, anim: true },
      { id: 'lava', price: 2400, t: { de: 'Lava', en: 'Lava', es: 'Lava' }, anim: true },
      { id: 'cosmos', price: 3500, t: { de: 'Kosmos', en: 'Cosmos', es: 'Cosmos' }, anim: true },
      { id: 'nothing', coins: 280, price: 1e9 /* nur im Revolution Store */, t: { de: 'Nothing', en: 'Nothing', es: 'Nothing' } },
      { id: 'graphite', coins: 220, price: 1e9 /* nur im Revolution Store */, t: { de: 'Graphit', en: 'Graphite', es: 'Grafito' } },
      { id: 'synth', coins: 340, price: 1e9 /* nur im Revolution Store */, t: { de: 'Synth', en: 'Synth', es: 'Synth' }, anim: true },
    ],
    avatar: [
      { id: 'none', glyph: '', price: 0 },
      { id: 'pawn', glyph: '♟', price: 80 },
      { id: 'knight', glyph: '♞', price: 200 },
      { id: 'bishop', glyph: '♝', price: 200 },
      { id: 'rook', glyph: '♜', price: 300 },
      { id: 'queen', glyph: '♛', price: 500 },
      { id: 'king', glyph: '♚', price: 700 },
      { id: 'star', glyph: '★', price: 400 },
      { id: 'bolt', glyph: 'ϟ', price: 550 },
      { id: 'crown', glyph: '♔', price: 900 },
      { id: 'heart', glyph: '♥', price: 350 },
      { id: 'spade', glyph: '♠', price: 350 },
      { id: 'sun', glyph: '☀', price: 600 },
      { id: 'moon', glyph: '☾', price: 600 },
      { id: 'skull', glyph: '☠', price: 1100 },
      { id: 'infinity', glyph: '∞', price: 1400 },
      { id: 'custom', glyph: '', price: 4000, custom: true },
    ],
    color: [
      { id: 'grey', bg: 'linear-gradient(135deg,#55556a,#2c2c38)', price: 0 },
      { id: 'violet', bg: 'linear-gradient(135deg,#9a7dff,#6a45f5)', price: 150 },
      { id: 'ocean', bg: 'linear-gradient(135deg,#38bdf8,#1e3a8a)', price: 150 },
      { id: 'forest', bg: 'linear-gradient(135deg,#4ade80,#166534)', price: 150 },
      { id: 'sunset', bg: 'linear-gradient(135deg,#fb923c,#db2777)', price: 300 },
      { id: 'gold', bg: 'linear-gradient(135deg,#fde68a,#b45309)', price: 600 },
      { id: 'rose', bg: 'linear-gradient(135deg,#fb7185,#9f1239)', price: 300 },
      { id: 'midnight', bg: 'linear-gradient(135deg,#1e293b,#020617)', price: 400 },
      { id: 'aurora', bg: 'linear-gradient(135deg,#22d3ee,#a855f7,#f472b6)', price: 1000, anim: true },
      { id: 'lava', bg: 'linear-gradient(135deg,#fde047,#f97316,#b91c1c)', price: 1300, anim: true },
      { id: 'galaxy', bg: 'linear-gradient(135deg,#0f172a,#4c1d95,#1d4ed8,#0f172a)', price: 1800, anim: true },
      // Revolution Store (Coins)
      { id: 'nothing', bg: 'radial-gradient(circle at 70% 28%,#ff2d2d 0 7%,transparent 8%),radial-gradient(circle,#2a2a2a 1px,transparent 1.4px) 0 0/5px 5px,#050505', coins: 180, price: 1e9 /* nur im Revolution Store */ },
      { id: 'holo', bg: 'linear-gradient(120deg,#a5f3fc,#c4b5fd,#fbcfe8,#bbf7d0,#a5f3fc)', coins: 320, price: 1e9 /* nur im Revolution Store */, anim: true },
      { id: 'carbon', bg: 'repeating-linear-gradient(45deg,#1a1a1a 0 4px,#0d0d0d 4px 8px)', coins: 220, price: 1e9 /* nur im Revolution Store */ },
      { id: 'mesh', bg: 'radial-gradient(at 20% 20%,#ff7ad1,transparent 55%),radial-gradient(at 80% 30%,#62c9ff,transparent 55%),radial-gradient(at 50% 90%,#a78bfa,transparent 60%),#111', coins: 260, price: 1e9 /* nur im Revolution Store */, anim: true },
      { id: 'sunrise', bg: 'linear-gradient(180deg,#ffd166,#ff7a59 55%,#7c3aed)', coins: 180, price: 1e9 /* nur im Revolution Store */ },
    ],
    frame: [
      { id: 'none', price: 0 },
      { id: 'silver', price: 200 },
      { id: 'gold', price: 500 },
      { id: 'neon', price: 900, anim: true },
      { id: 'fire', price: 1500, anim: true },
      { id: 'ice', price: 1200, anim: true },
      { id: 'rainbow', price: 2200, anim: true },
      { id: 'void', price: 3000, anim: true },
      { id: 'dotmatrix', coins: 260, price: 1e9 /* nur im Revolution Store */ },
      { id: 'redline', coins: 200, price: 1e9 /* nur im Revolution Store */ },
      { id: 'halo', coins: 380, price: 1e9 /* nur im Revolution Store */, anim: true },
      { id: 'orbit', coins: 320, price: 1e9 /* nur im Revolution Store */, anim: true },
    ],
    name: [
      { id: 'white', css: '#f2f1f7', price: 0 },
      { id: 'mint', css: '#4ade80', price: 150 },
      { id: 'sky', css: '#38bdf8', price: 150 },
      { id: 'gold', css: '#fbbf24', price: 500 },
      { id: 'rose', css: '#fb7185', price: 150 },
      { id: 'violet', css: '#b39dff', price: 250 },
      { id: 'ice', css: '#a5f3fc', price: 400 },
      { id: 'rainbow', css: 'rainbow', price: 1200, anim: true },
      { id: 'fire', css: 'fire', price: 1800, anim: true },
      { id: 'signal', css: '#ff2d2d', coins: 120, price: 1e9 /* nur im Revolution Store */ },
      { id: 'chrome', css: 'chrome', coins: 300, price: 1e9 /* nur im Revolution Store */, anim: true },
      { id: 'aurora', css: 'aurora', coins: 260, price: 1e9 /* nur im Revolution Store */, anim: true },
    ],
    title: [
      { id: 'none', t: { de: '', en: '', es: '' }, price: 0 },
      { id: 'rookie', t: { de: 'Neuling', en: 'Rookie', es: 'Novato' }, price: 60 },
      { id: 'tactician', t: { de: 'Taktiker', en: 'Tactician', es: 'Táctico' }, price: 400 },
      { id: 'mateking', t: { de: 'Mattkönig', en: 'Mate King', es: 'Rey del mate' }, price: 900 },
      { id: 'grandmaster', t: { de: 'Großmeister', en: 'Grandmaster', es: 'Gran maestro' }, price: 2500 },
      { id: 'strategist', t: { de: 'Stratege', en: 'Strategist', es: 'Estratega' }, price: 650 },
      { id: 'explorer', t: { de: 'Weltenbummler', en: 'Globetrotter', es: 'Trotamundos' }, price: 800 },
      { id: 'nightowl', t: { de: 'Nachteule', en: 'Night Owl', es: 'Búho' }, price: 1200 },
      { id: 'legend', t: { de: 'Legende', en: 'Legend', es: 'Leyenda' }, price: 5000 },
      { id: 'revolution', t: { de: 'Revulutionär', en: 'Revulutionary', es: 'Revolucionario' }, price: 8000 },
      { id: 'pixel', t: { de: 'Pixel', en: 'Pixel', es: 'Píxel' }, coins: 150, price: 1e9 /* nur im Revolution Store */ },
      { id: 'glitch', t: { de: 'Glitch', en: 'Glitch', es: 'Glitch' }, coins: 220, price: 1e9 /* nur im Revolution Store */ },
      { id: 'supporter', t: { de: 'Unterstützer', en: 'Supporter', es: 'Partidario' }, coins: 100, price: 1e9 /* nur im Revolution Store */ },
      { id: 'streamer', t: { de: 'Streamer', en: 'Streamer', es: 'Streamer' }, coins: 150, price: 1e9 /* nur im Revolution Store */ },
      { id: 'trader', t: { de: 'Trader', en: 'Trader', es: 'Trader' }, coins: 150, price: 1e9 /* nur im Revolution Store */ },
    ],
    effect: [
      { id: 'none', price: 0 },
      { id: 'sparks', color: '#fbbf24', price: 300 },
      { id: 'ice', color: '#7dd3fc', price: 300 },
      { id: 'toxic', color: '#a3e635', price: 450 },
      { id: 'void', color: '#c084fc', price: 700 },
      { id: 'shockwave', color: '#38bdf8', price: 1200, wave: true },
      { id: 'sakura', color: '#f9a8d4', price: 550 },
      { id: 'gold', color: '#fde047', price: 900 },
      { id: 'meteor', color: '#ff7a1a', price: 2000, wave: true, big: true },
      { id: 'supernova', color: '#e0e7ff', price: 3200, wave: true, big: true },
      { id: 'glitch', color: '#ff2d2d', coins: 350, price: 1e9 /* nur im Revolution Store */, wave: true },
      { id: 'dotburst', color: '#ffffff', coins: 280, price: 1e9 /* nur im Revolution Store */, big: true },
      { id: 'ripple', color: '#0a84ff', coins: 240, price: 1e9 /* nur im Revolution Store */, wave: true },
      { id: 'confetti', color: '#ff7ad1', coins: 300, price: 1e9 /* nur im Revolution Store */, multi: true },
    ],
    // Dynamic Island: Farb-Designs, werden beim Anlegen direkt auf die Island übertragen
    island: [
      { id: 'standard', price: 0, t: { de: 'Standard', en: 'Standard', es: 'Estándar' }, app: { Backdrop: 'Glass', BackgroundColor: '#17161C', BackgroundColor2: '#221F2B', AccentColor: '#C9A7FF', AccentColor2: '#F06BC0', TextColor: '#F4F2F7', SubTextColor: '#A7A3B4', ProgressColor: '#C9A7FF', GlowColor: '#8F73FF', BorderColor: '#FFFFFF', AnimatedBorder: false } },
      { id: 'mint', price: 900, t: { de: 'Minze', en: 'Mint', es: 'Menta' }, app: { Backdrop: 'Glass', BackgroundColor: '#0E1B17', BackgroundColor2: '#12261F', AccentColor: '#5EE6A8', AccentColor2: '#2DD4BF', TextColor: '#ECFDF5', SubTextColor: '#9CC9B5', ProgressColor: '#5EE6A8', GlowColor: '#2DD4BF', BorderColor: '#A7F3D0', AnimatedBorder: false } },
      { id: 'ocean', price: 1500, t: { de: 'Ozean', en: 'Ocean', es: 'Océano' }, app: { Backdrop: 'Gradient', BackgroundColor: '#071A33', BackgroundColor2: '#0B3A6B', AccentColor: '#62C9FF', AccentColor2: '#38BDF8', TextColor: '#F0F9FF', SubTextColor: '#93C5FD', ProgressColor: '#62C9FF', GlowColor: '#0EA5E9', BorderColor: '#BAE6FD', AnimatedBorder: false } },
      { id: 'nothing', coins: 220, price: 1e9 /* nur im Revolution Store */, t: { de: 'Nothing', en: 'Nothing', es: 'Nothing' }, app: { Backdrop: 'Solid', BackgroundColor: '#000000', BackgroundColor2: '#000000', AccentColor: '#FF2D2D', AccentColor2: '#FFFFFF', TextColor: '#FFFFFF', SubTextColor: '#8E8E93', ProgressColor: '#FF2D2D', GlowColor: '#FF2D2D', BorderColor: '#FFFFFF', AnimatedBorder: false } },
      { id: 'liquid', coins: 260, price: 1e9 /* nur im Revolution Store */, t: { de: 'Liquid Glass', en: 'Liquid Glass', es: 'Cristal líquido' }, app: { Backdrop: 'Glass', BackgroundColor: '#1C2433', BackgroundColor2: '#2A3550', AccentColor: '#0A84FF', AccentColor2: '#64D2FF', TextColor: '#FFFFFF', SubTextColor: '#C7D2E0', ProgressColor: '#64D2FF', GlowColor: '#0A84FF', BorderColor: '#FFFFFF', AnimatedBorder: false } },
      { id: 'sunset', coins: 240, price: 1e9 /* nur im Revolution Store */, t: { de: 'Sunset', en: 'Sunset', es: 'Atardecer' }, app: { Backdrop: 'Gradient', BackgroundColor: '#3B0D2E', BackgroundColor2: '#7A2A12', AccentColor: '#FFB347', AccentColor2: '#FF5E8A', TextColor: '#FFF4EC', SubTextColor: '#F5B9A6', ProgressColor: '#FFB347', GlowColor: '#FF5E8A', BorderColor: '#FFD6B0', AnimatedBorder: false } },
      { id: 'terminal', coins: 200, price: 1e9 /* nur im Revolution Store */, t: { de: 'Terminal', en: 'Terminal', es: 'Terminal' }, app: { Backdrop: 'Solid', BackgroundColor: '#020A04', BackgroundColor2: '#04140A', AccentColor: '#39FF7A', AccentColor2: '#00C853', TextColor: '#C8FFD9', SubTextColor: '#5FB57A', ProgressColor: '#39FF7A', GlowColor: '#00E676', BorderColor: '#39FF7A', AnimatedBorder: false } },
      { id: 'aurora', coins: 340, price: 1e9 /* nur im Revolution Store */, t: { de: 'Aurora', en: 'Aurora', es: 'Aurora' }, anim: true, app: { Backdrop: 'Gradient', BackgroundColor: '#0B1026', BackgroundColor2: '#1B0B33', AccentColor: '#22D3EE', AccentColor2: '#A855F7', TextColor: '#F5F3FF', SubTextColor: '#B4B8E8', ProgressColor: '#22D3EE', GlowColor: '#A855F7', BorderColor: '#C4B5FD', AnimatedBorder: true } },
      { id: 'gold', coins: 300, price: 1e9 /* nur im Revolution Store */, t: { de: 'Gold', en: 'Gold', es: 'Oro' }, app: { Backdrop: 'Solid', BackgroundColor: '#0D0B07', BackgroundColor2: '#1A140A', AccentColor: '#F5C451', AccentColor2: '#B8860B', TextColor: '#FFF8E7', SubTextColor: '#CDB88A', ProgressColor: '#F5C451', GlowColor: '#F5C451', BorderColor: '#F5C451', AnimatedBorder: true } },
    ],
    // Tastatur-Displays (AJAZZ, 128 × 128): Animationen aus shared/kbd-anim.js
    kbd: [
      { id: 'none', price: 0, t: { de: 'Keins', en: 'None', es: 'Ninguno' } },
      { id: 'heart', price: 1200, t: { de: 'Herzschlag', en: 'Heartbeat', es: 'Latido' }, anim: true },
      { id: 'starfield', price: 1800, t: { de: 'Sternenflug', en: 'Starfield', es: 'Estrellas' }, anim: true },
      { id: 'matrix', coins: 150, price: 1e9 /* nur im Revolution Store */, t: { de: 'Matrix-Regen', en: 'Matrix rain', es: 'Lluvia Matrix' }, anim: true },
      { id: 'eqbars', coins: 180, price: 1e9 /* nur im Revolution Store */, t: { de: 'Equalizer', en: 'Equalizer', es: 'Ecualizador' }, anim: true },
      { id: 'dotclock', coins: 200, price: 1e9 /* nur im Revolution Store */, t: { de: 'Punkt-Uhr', en: 'Dot clock', es: 'Reloj de puntos' }, anim: true },
      { id: 'fire', coins: 220, price: 1e9 /* nur im Revolution Store */, t: { de: 'Feuer', en: 'Fire', es: 'Fuego' }, anim: true },
      { id: 'plasma', coins: 250, price: 1e9 /* nur im Revolution Store */, t: { de: 'Plasma', en: 'Plasma', es: 'Plasma' }, anim: true },
      { id: 'radar', coins: 230, price: 1e9 /* nur im Revolution Store */, t: { de: 'Radar', en: 'Radar', es: 'Radar' }, anim: true },
    ],
    // 2.41 Display-GIFs von Revulution: Mini gratis, die anderen im Store
    gif: [
      { id: 'pixel', coins: 120, price: 1e9 /* nur im Revolution Store */, t: { de: 'Pixel', en: 'Pixel', es: 'Pixel' }, anim: true },
      { id: 'wireframe', coins: 140, price: 1e9 /* nur im Revolution Store */, t: { de: 'Wireframe', en: 'Wireframe', es: 'Wireframe' }, anim: true },
    ],
    // Premium-Widgets für den Desktop
    widget: [
      { id: 'none', price: 0, t: { de: 'Keins', en: 'None', es: 'Ninguno' } },
      { id: 'trading', coins: 400, price: 1e9 /* nur im Revolution Store */, t: { de: 'Trading', en: 'Trading', es: 'Trading' }, feature: true },
      { id: 'streamchat', coins: 450, price: 1e9 /* nur im Revolution Store */, t: { de: 'Stream-Chat', en: 'Stream chat', es: 'Chat de stream' }, feature: true },
      { id: 'sound', coins: 250, price: 1e9 /* nur im Revolution Store */, t: { de: 'Soundboard', en: 'Soundboard', es: 'Soundboard' }, feature: true },
      { id: 'quick', coins: 200, price: 1e9 /* nur im Revolution Store */, t: { de: 'Schnellzugriff', en: 'Quick access', es: 'Acceso rápido' }, feature: true },
    ],
  };

  const SLOT_NAMES = {
    pieces: { de: 'Figuren', en: 'Pieces', es: 'Piezas' },
    board: { de: 'Brett', en: 'Board', es: 'Tablero' },
    avatar: { de: 'Bild', en: 'Avatar', es: 'Avatar' },
    color: { de: 'Hintergrund', en: 'Background', es: 'Fondo' },
    frame: { de: 'Rahmen', en: 'Frame', es: 'Marco' },
    name: { de: 'Namensfarbe', en: 'Name color', es: 'Color del nombre' },
    title: { de: 'Titel', en: 'Title', es: 'Título' },
    effect: { de: 'Zug-Effekt', en: 'Move effect', es: 'Efecto de jugada' },
    island: { de: 'Dynamic Island', en: 'Dynamic Island', es: 'Dynamic Island' },
    kbd: { de: 'Tastatur-Display', en: 'Keyboard display', es: 'Pantalla del teclado' },
    gif: { de: 'Display-GIF', en: 'Display GIF', es: 'GIF de pantalla' },
    widget: { de: 'Widgets', en: 'Widgets', es: 'Widgets' },
  };


  const cosItem = (slot, id) => COSMETICS[slot].find((x) => x.id === id) || COSMETICS[slot][0];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  function avatarHtml(eq = {}, size = 40) {
    const av = cosItem('avatar', eq.avatar), col = cosItem('color', eq.color), fr = cosItem('frame', eq.frame);
    const img = av.custom && typeof eq.img === 'string' && eq.img.startsWith('data:image/') ? eq.img : '';
    const inner = img
      ? `<img class="av-img" src="${img}" alt="" />`
      : av.glyph
      ? `<span class="av-glyph" style="font-size:${Math.round(size * 0.62)}px">${av.glyph}&#xFE0E;</span>`
      : `<svg class="av-default" viewBox="0 0 24 24"><circle cx="12" cy="9" r="4.2"/><path d="M4 21c.8-4.4 4-7 8-7s7.2 2.6 8 7"/></svg>`;
    return `<div class="av frame-${fr.id}${col.anim ? ' av-anim' : ''}" style="width:${size}px;height:${size}px;background:${col.bg}">${inner}</div>`;
  }
  function nameStyle(eq = {}) {
    const n = cosItem('name', eq.name);
    return n.css === 'rainbow' ? 'class="name-rainbow"' : n.css === 'fire' ? 'class="name-fire"' : n.css === 'chrome' ? 'class="name-chrome"' : n.css === 'aurora' ? 'class="name-aurora"' : `style="color:${n.css}"`;
  }
  function titleHtml(eq = {}, lang = 'de') {
    const ti = cosItem('title', eq.title);
    const text = ti.t?.[lang] || ti.t?.de || '';
    return text ? ` <span class="title-tag">${esc(text)}</span>` : '';
  }
  /** Vorschau eines Shop-Artikels. */
  function preview(slot, it, eq = {}, name = '') {
    if (slot === 'pieces') return `<div class="skin-prev"><span class="piece w skin-${it.id}"><span>♚&#xFE0E;</span></span><span class="piece b skin-${it.id}"><span>♛&#xFE0E;</span></span></div>`;
    if (slot === 'board') return `<div class="board-prev bd-${it.id}">${[0, 1, 2, 3, 4, 5, 6, 7, 8].map((k) => `<i class="sq${(k % 3 + Math.floor(k / 3)) % 2 ? ' dark' : ''}"></i>`).join('')}</div>`;
    if (slot === 'avatar' && it.custom) return `<div class="custom-prev">${eq.img ? `<img src="${eq.img}" alt="" />` : '📷'}</div>`;
    if (slot === 'avatar' || slot === 'color' || slot === 'frame') return avatarHtml({ ...eq, [slot]: it.id }, 44);
    if (slot === 'name') return `<b ${nameStyle({ name: it.id })}>${esc(name || 'Name')}</b>`;
    if (slot === 'title') return `<span class="title-tag">${esc(it.t?.de || '–')}</span>`;
    if (slot === 'island') {
      const a = it.app || {};
      return `<div class="isl-prev ${it.anim || a.AnimatedBorder ? 'anim' : ''} bd-${String(a.Backdrop || 'Glass').toLowerCase()}" style="--bg:${a.BackgroundColor};--bg2:${a.BackgroundColor2};--ac:${a.AccentColor};--ac2:${a.AccentColor2};--tx:${a.TextColor};--st:${a.SubTextColor};--gl:${a.GlowColor};--bc:${a.BorderColor}"><i class="isl-art"></i><span class="isl-t"><b>Now Playing</b><small>Revulution</small></span><span class="isl-eq"><i></i><i></i><i></i><i></i></span><em class="isl-bar"><u></u></em></div>`;
    }
    if (slot === 'gif') return `<div class="kbd-prev"><img src="assets/gifs/${esc(it.id)}.gif" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" /></div>`;
    if (slot === 'kbd') return it.id === 'none' ? '<div class="kbd-prev off">Aus</div>' : `<div class="kbd-prev"><canvas data-kbd="${esc(it.id)}" width="128" height="128"></canvas></div>`;
    if (slot === 'widget') {
      if (it.id === 'trading')
        return `<div class="wg-prev wg-trade"><div class="wg-row"><b>AAPL</b><span class="up">+1.84 %</span></div><svg viewBox="0 0 100 34" preserveAspectRatio="none"><path class="wg-line" d="M0 26 L10 24 L20 27 L30 20 L40 22 L50 15 L60 17 L70 10 L80 12 L90 6 L100 8"/></svg><div class="wg-row"><b>BTC</b><span class="down">−0.62 %</span></div></div>`;
      if (it.id === 'streamchat')
        return `<div class="wg-prev wg-chat"><p style="--d:0s"><b style="color:#62c9ff">luca</b> GG 🔥</p><p style="--d:.8s"><b style="color:#ff7ad1">mia_</b> wie heißt der Song?</p><p style="--d:1.6s"><b style="color:#5ee08a">nico</b> hat ein Geschenk gesendet 🎁</p></div>`;
      if (it.id === 'sound')
        return `<div class="wg-prev wg-pads">${['🥁', '👏', '📯', '🔔', '🌀', '💥', '🎺', '✨'].map((e, k) => `<i style="--d:${k * 0.25}s">${e}</i>`).join('')}</div>`;
      if (it.id === 'quick')
        return `<div class="wg-prev wg-quick">${[['📁', 'Clips'], ['📄', 'Notiz'], ['🖼️', 'Bild'], ['🎵', 'Beat']].map(([e, n]) => `<span><i>${e}</i><small>${n}</small></span>`).join('')}</div>`;
      return '<div class="wg-prev off">–</div>';
    }
    if (slot === 'effect') {
      if (it.id === 'none') return '<span class="fx-dot" style="background:#444"></span>';
      return `<div class="fx-prev ${it.wave ? 'wave' : ''} ${it.big ? 'big' : ''} ${it.multi ? 'multi' : ''} fx-${esc(it.id)}" style="--c:${it.color}">${'<i class="sq"></i>'.repeat(9)}<span class="fx-piece">♞&#xFE0E;</span><b class="fx-ring"></b>${Array.from({ length: 10 }, (_, k) => `<em style="--a:${k * 36}deg"></em>`).join('')}</div>`;
    }
    return `<span class="fx-dot" style="background:${it.color || '#444'}"></span>`;
  }

  const api = { COSMETICS, SLOT_NAMES, cosItem, avatarHtml, nameStyle, titleHtml, preview };
  root.RevCos = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
