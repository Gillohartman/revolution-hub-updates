'use strict';

/*
 * Echtes Liquid Glass (2.36): jede Glasfläche bekommt eine eigene Verschiebungskarte in ihrer
 * echten Größe. Nur ein schmaler Rand (≈14 px) bricht das Licht – wie der Rand eines
 * Wassertropfens –, die Mitte bleibt klar und unverzerrt (keine „Lupe“, nichts doppelt).
 * Dazu: Tab-Leisten mit federnder Glas-Kapsel (Apple-Bounce).
 */
(function () {
  if (window.__revLiquid || typeof document === 'undefined') return;
  window.__revLiquid = true;
  const NS = 'http://www.w3.org/2000/svg';
  const GLASS = [
    '.btn', '.wp-glass-btn', '.wp-player', '.wp-tabs', '.wp-search', '.wp-navback', '.wp-round', '.wp-chips span',
    '.seg', '.rs-cats', '.h3-tabs', '.h2-tabs', '.desk-tabs', '.mp-seg', '.mp-sheet', '.tool-card', '.w3', '.rs-item', '.rs-feat',
    '.desk-pane', '.desk-prem-card', '.upd-card', '.rs-sheet', '.ov-sheet', '.toast', '.dock-bar', '.dock-pill', '.tb-bar', '.tb-pill',
    '.h2-set', '.h3-news', '.top-acc', '.top-set', '.lg', '.modal', '.call-card', '.glass', '.card', '.nav', 'nav', '.side', '.rail',
  ].join(',');
  let defs = null;
  // Nur wo wirklich Inhalt unter dem Glas liegt (Hub-Fenster mit Hintergrund, Website), wird
  // verzerrt/weichgezeichnet. Getrennte durchsichtige Ebenen (Apps, Dock, Leiste, Widgets) hätten
  // darunter nichts – dort malt Chromium nur eckige Kästen und Streifen. Dort: klares Glas ohne Filter.
  // dynamisch: der Gaming Hub zeigt sein Hintergrund-Video nur, wenn eines gewählt ist
  // 2.37: nur wenn wirklich ein Bild/Video unter dem Glas liegt – sonst malt Chromium feine Kästen
  const hasImage = (el) => {
    if (!el || el.hidden) return false;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) return false;
    return el.tagName === 'VIDEO' ? Boolean(el.currentSrc || el.poster) : cs.backgroundImage !== 'none';
  };
  const hostNow = () => hasImage(document.getElementById('wall-blur')) || hasImage(document.getElementById('wall')) || /^https?:$/.test(location.protocol);
  let HOST = false;
  let flat = null;
  const made = new Map(); // key -> filter id
  let n = 0;

  /** Karte für eine Fläche w×h (px) mit Eckenradius r: Rand zieht nach innen, Mitte neutral. */
  function makeMap(w, h, r, edge) {
    const k = Math.min(1, 220 / Math.max(w, h)); // Karte klein rechnen, wird exakt gestreckt
    const W = Math.max(8, Math.round(w * k));
    const H = Math.max(8, Math.round(h * k));
    const R = Math.min(r * k, W / 2, H / 2);
    const E = Math.max(2, edge * k);
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const g = c.getContext('2d');
    const img = g.createImageData(W, H);
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        const px = x + 0.5 - W / 2;
        const py = y + 0.5 - H / 2;
        const qx = Math.abs(px) - (W / 2 - R);
        const qy = Math.abs(py) - (H / 2 - R);
        const dist = R - (Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0)); // 0 am Rand
        // 2.38: die äußersten ~2 px bleiben unverschoben – sonst entstehen an der runden Kante
        // harte Pixelstufen (die Verzerrung zog Pixel von außerhalb bis an den Rand)
        const guard = 2 * (W / Math.max(1, w));
        let s = dist < guard ? 0 : Math.max(0, 1 - (dist - guard) / E);
        s = s * s; // nur am Rand stark
        // Normale der abgerundeten Fläche (nach außen) → Verschiebung nach innen
        let nx = qx > 0 ? Math.sign(px) * (qy > 0 ? qx / Math.hypot(qx, qy) : 1) : 0;
        let ny = qy > 0 ? Math.sign(py) * (qx > 0 ? qy / Math.hypot(qx, qy) : 1) : 0;
        if (!nx && !ny) {
          if (Math.abs(px) / W > Math.abs(py) / H) nx = Math.sign(px);
          else ny = Math.sign(py);
        }
        const i = (y * W + x) * 4;
        img.data[i] = 128 - nx * s * 127;
        img.data[i + 1] = 128 - ny * s * 127;
        img.data[i + 2] = 128;
        img.data[i + 3] = 255;
      }
    g.putImageData(img, 0, 0);
    return c.toDataURL('image/png');
  }

  function filterFor(w, h, r) {
    const bw = Math.max(16, Math.round(w / 6) * 6);
    const bh = Math.max(16, Math.round(h / 6) * 6);
    const br = Math.round(r / 2) * 2;
    const key = `${bw}x${bh}r${br}`;
    if (made.has(key)) return made.get(key);
    const edge = Math.min(16, Math.min(bw, bh) * 0.3);
    const scale = Math.min(22, edge * 1.5);
    const id = `lgf${++n}`;
    const f = document.createElementNS(NS, 'filter');
    f.setAttribute('id', id);
    f.setAttribute('x', '0');
    f.setAttribute('y', '0');
    f.setAttribute('width', String(bw));
    f.setAttribute('height', String(bh));
    f.setAttribute('filterUnits', 'userSpaceOnUse');
    f.setAttribute('primitiveUnits', 'userSpaceOnUse');
    f.setAttribute('color-interpolation-filters', 'sRGB');
    f.innerHTML = `<feImage href="${makeMap(bw, bh, br, edge)}" x="0" y="0" width="${bw}" height="${bh}" preserveAspectRatio="none" result="m"/>
      <feDisplacementMap in="SourceGraphic" in2="m" scale="${scale}" xChannelSelector="R" yChannelSelector="G"/>`;
    defs.appendChild(f);
    made.set(key, id);
    return id;
  }

  const seen = new WeakMap();
  function apply(el) {
    if (!HOST) return;
    const r = el.getBoundingClientRect();
    if (r.width < 12 || r.height < 12) return;
    const rad = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0;
    const sig = `${Math.round(r.width / 6)}x${Math.round(r.height / 6)}r${Math.round(rad)}`;
    if (seen.get(el) === sig) return;
    seen.set(el, sig);
    // kleine runde Knöpfe: keine Rand-Verzerrung (wirkte dort verpixelt), nur sanftes Glas
    if (r.width < 64 || r.height < 34) {
      el.style.setProperty('backdrop-filter', 'blur(var(--lg-b, 2px)) saturate(1.8) brightness(1.05)', 'important');
      return;
    }
    const id = filterFor(r.width, r.height, Math.min(rad, r.height / 2, r.width / 2));
    el.style.setProperty('backdrop-filter', `url(#${id}) blur(var(--lg-b, 2px)) saturate(1.8) brightness(1.05)`, 'important');
  }
  function setHost() {
    const h = hostNow();
    if (setHost.done && h === HOST) return;
    setHost.done = true;
    HOST = h;
    flat.disabled = HOST;
    document.documentElement.classList.toggle('lg-ready', HOST);
    document.documentElement.classList.toggle('lg-flat', !HOST);
    needGlass = true;
    queue();
  }
  // 2.36: sparsam – nur neu vermessen, wenn sich eine Leiste oder neue Glasfläche geändert hat
  let queued = false;
  let needGlass = true;
  let needBars = true;
  function scan() {
    queued = false;
    if (!defs || document.hidden) return;
    if (needGlass && HOST) for (const el of document.querySelectorAll(GLASS)) apply(el);
    if (needBars) bounceAll();
    needGlass = needBars = false;
  }
  const queue = () => {
    if (!queued) {
      queued = true;
      setTimeout(() => requestAnimationFrame(scan), 60);
    }
  };
  function onMutations(list) {
    for (const m of list) {
      const t = m.target;
      if (m.type === 'attributes') {
        // nur Klassen-Wechsel in einer Tab-Leiste interessieren (aktiver Tab)
        // 2.39: eigene Klassen an der Leiste (lg-has-pill …) lösten sonst eine Endlosschleife aus – die Seitenleiste blinkte
        if (t.matches?.(BARS) || t.classList.contains('lg-pill')) continue;
        if (t.closest?.(BARS)) needBars = true;
        continue;
      }
      for (const n of m.addedNodes) {
        if (n.nodeType !== 1) continue;
        if (n.matches?.(BARS) || n.querySelector?.(BARS) || t.closest?.(BARS)) needBars = true;
        if (HOST && (n.matches?.(GLASS) || n.querySelector?.(GLASS))) needGlass = true;
      }
    }
    if (needBars || needGlass) queue();
  }

  /* ---------------- Tab-Leisten: federnde Glas-Kapsel (wischt rüber und bounced) */
  const VBARS = '.sidebar .nav, .side-nav';
  const BARS = '.sidebar .nav, .side-nav, .seg, .rs-cats, .h3-tabs, .h2-tabs, .desk-tabs, .wp-tabs, .mp-seg, .tabs, .cats, .gh-cats, .side-nav, body > nav';
  const lastPos = new Map(); // Leisten-Schlüssel -> {x,w}
  const keyOf = (bar) => bar.dataset.lgKey || (bar.dataset.lgKey = `${bar.className}|${[...bar.children].map((c) => c.textContent.trim()).join('·').slice(0, 80)}`);
  function bounceAll() {
    for (const bar of document.querySelectorAll(BARS)) {
      // waagrechte Leisten: direktes Kind ist aktiv; senkrechte Seitenleisten (Gaming Hub): irgendein Eintrag
      const on = bar.querySelector(':scope > .on, :scope > .active, :scope > .is-active, :scope > [aria-selected="true"]') || (bar.matches(VBARS) ? bar.querySelector('.nav-item.is-active, .nav-item.active, .nav-item.on') : null);
      if (!on) continue;
      let pill = bar.querySelector(':scope > .lg-pill');
      if (!pill) {
        if (getComputedStyle(bar).position === 'static') bar.style.position = 'relative';
        pill = document.createElement('i');
        pill.className = 'lg-pill';
        pill.dataset.fresh = '1';
        bar.prepend(pill);
      }
      if (!bar.classList.contains('lg-has-pill')) bar.classList.add('lg-has-pill');
      if (bar.matches(VBARS) && !bar.classList.contains('lg-vbar')) bar.classList.add('lg-vbar');
      const br = bar.getBoundingClientRect();
      const r = on.getBoundingClientRect();
      const x = Math.round(r.left - br.left + bar.scrollLeft);
      const y = Math.round(r.top - br.top + bar.scrollTop);
      const w = Math.round(r.width);
      const h = Math.round(r.height);
      if (!w || !h) continue;
      const key = keyOf(bar);
      // eigene letzte Stelle zuerst – mehrere Leisten mit gleichem Schlüssel schaukelten sich sonst gegenseitig auf
      const prev = bar.__lgPos || lastPos.get(key);
      bar.__lgPos = { x, y, w, h };
      lastPos.set(key, { x, y, w, h });
      if (pill.dataset.t === `${x},${y},${w},${h}`) continue;
      pill.dataset.t = `${x},${y},${w},${h}`;
      const moved = prev && (prev.x !== x || prev.y !== y || prev.w !== w);
      const fresh = pill.dataset.fresh;
      delete pill.dataset.fresh;
      if (moved) {
        // von der alten Stelle aus losfedern, mit kurzem Dehnen in Laufrichtung
        pill.style.transition = 'none';
        pill.style.width = `${prev.w}px`;
        pill.style.height = `${prev.h}px`;
        pill.style.transform = `translate(${prev.x}px, ${prev.y}px)`;
        void pill.offsetWidth;
        pill.style.transition = '';
        pill.classList.remove('stretch', 'stretch-v');
        void pill.offsetWidth;
        pill.classList.add(Math.abs(prev.y - y) > Math.abs(prev.x - x) ? 'stretch-v' : 'stretch');
      } else if (fresh) pill.style.transition = 'none';
      pill.style.width = `${w}px`;
      pill.style.height = `${h}px`;
      pill.style.transform = `translate(${x}px, ${y}px)`;
      if (fresh && !moved) requestAnimationFrame(() => (pill.style.transition = ''));
    }
  }

  function install() {
    if (document.getElementById('lg-defs')) return;
    const svg = document.createElementNS(NS, 'svg');
    svg.id = 'lg-defs';
    svg.setAttribute('aria-hidden', 'true');
    svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
    defs = document.createElementNS(NS, 'defs');
    svg.appendChild(defs);
    document.body.appendChild(svg);
    flat = document.createElement('style');
    flat.textContent = '*,*::before,*::after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}';
    document.head.appendChild(flat);
    setHost();
    setInterval(setHost, 2000);
    const css = document.createElement('style');
    css.textContent = `.lg-has-pill > .on, .lg-has-pill > .active, .lg-has-pill > .is-active, .lg-vbar .nav-item.is-active { background: transparent !important; box-shadow: none !important; border-color: transparent !important; }
      .lg-vbar .nav-item.is-active::before { display: none !important; }
      .lg-vbar .lg-pill { border-radius: 12px; }
      .lg-has-pill > *:not(.lg-pill) { position: relative; z-index: 1; }
      .lg-pill { position: absolute; left: 0; top: 0; z-index: 0; border-radius: 999px; pointer-events: none;
        background: linear-gradient(180deg, rgba(255,255,255,.26), rgba(255,255,255,.09));
        box-shadow: inset 0 0 0 1px rgba(255,255,255,.22), inset 0 1.5px 0 rgba(255,255,255,.5), 0 6px 16px -6px rgba(0,0,0,.45);
        transition: transform .62s cubic-bezier(.22,1.18,.36,1), width .62s cubic-bezier(.22,1.18,.36,1), height .62s cubic-bezier(.22,1.18,.36,1); will-change: transform, width; }
      .lg-pill.stretch-v { animation: lg-squish-v .62s cubic-bezier(.22,1,.36,1); }
      @keyframes lg-squish-v { 0% { scale: 1 1; } 35% { scale: .95 1.07; } 70% { scale: 1.015 .985; } 100% { scale: 1 1; } }
      .lg-pill.stretch { animation: lg-squish .62s cubic-bezier(.22,1,.36,1); }
      @keyframes lg-squish { 0% { scale: 1 1; } 35% { scale: 1.06 .93; } 70% { scale: .985 1.015; } 100% { scale: 1 1; } }`;
    document.head.appendChild(css);
    new MutationObserver(onMutations).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    window.addEventListener('resize', () => {
      needGlass = needBars = true;
      queue();
    });
    queue();
  }
  if (document.body) install();
  else document.addEventListener('DOMContentLoaded', install);
})();
