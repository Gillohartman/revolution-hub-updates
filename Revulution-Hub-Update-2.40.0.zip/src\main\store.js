'use strict';

/*
 * Revolution Store – Verbindung der App zum Server (Firebase Cloud Functions).
 * Die App kennt KEINEN Stripe-Schlüssel. Sie schickt nur „welches Paket / welcher Artikel“
 * plus das Anmelde-Token; Preise, Coins und Inventar entscheidet der Server.
 */
const { shell } = require('electron');

const BASE = 'https://europe-west6-revolutionhub-56a80.cloudfunctions.net';

class Store {
  constructor({ token, onChange }) {
    this.token = token; // () => Promise<string> (Firebase-ID-Token, leer = nicht angemeldet)
    this.onChange = onChange || (() => {});
    this.state = { ready: false, offline: false, error: '', catalog: null, coins: 0, owned: [], transactions: [], dailyAt: 0, signedIn: false };
    this.poll = null;
  }

  async call(fn, { method = 'POST', body, auth = true } = {}) {
    const headers = { 'content-type': 'application/json' };
    if (auth) {
      const t = await this.token().catch(() => '');
      if (t) headers.authorization = `Bearer ${t}`;
    }
    let r;
    try {
      r = await fetch(`${BASE}/${fn}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
    } catch {
      throw new Error('Store gerade nicht erreichbar.');
    }
    let j = null;
    try {
      j = await r.json();
    } catch {
      j = null;
    }
    // 404 = Server noch nicht eingerichtet (Cloud Functions nicht hochgeladen)
    if (r.status === 404) throw Object.assign(new Error('Der Store wird gerade eingerichtet.'), { setup: true });
    if (!j?.ok) throw new Error(j?.error || `Store-Fehler (${r.status})`);
    return j;
  }

  async catalog() {
    try {
      this.state.catalog = await this.call('catalog', { method: 'GET', auth: false });
      this.state.offline = false;
      this.state.error = '';
    } catch (e) {
      this.state.offline = true;
      this.state.error = e.setup ? 'setup' : e.message;
    }
    this.state.ready = true;
    this.onChange(this.state);
    return this.state;
  }

  async refresh() {
    const t = await this.token().catch(() => '');
    this.state.signedIn = Boolean(t);
    if (!t) {
      this.onChange(this.state);
      return this.state;
    }
    try {
      const me = await this.call('me', { method: 'GET' });
      Object.assign(this.state, { coins: me.coins, owned: me.owned || [], transactions: me.transactions || [], dailyAt: me.dailyAt || 0, pro: me.pro || { active: false }, wheelAt: me.wheelAt || 0, wheelWon: me.wheelWon || {}, proDiscount: me.proDiscount || 0, offline: false });
    } catch (e) {
      if (e.setup) this.state.offline = true;
    }
    this.onChange(this.state);
    return this.state;
  }

  owns(slot, id) {
    return this.state.owned.includes(`${slot}/${id}`);
  }

  /** Nach dem Bezahlen im Browser: 3 Minuten lang alle 4 s nachsehen, bis der Server gebucht hat. */
  watch() {
    clearInterval(this.poll);
    const until = Date.now() + 3 * 60 * 1000;
    const before = this.state.coins;
    this.poll = setInterval(async () => {
      await this.refresh();
      if (this.state.coins !== before || Date.now() > until) clearInterval(this.poll);
    }, 4000);
  }

  async checkout(pack) {
    const { url } = await this.call('createCheckout', { body: { pack } });
    await shell.openExternal(url);
    this.watch();
    return true;
  }

  async proCheckout(plan) {
    const { url } = await this.call('createProCheckout', { body: { plan } });
    await shell.openExternal(url);
    this.watch();
    return true;
  }

  async proPortal() {
    const { url } = await this.call('proPortal', { body: {} });
    await shell.openExternal(url);
    return true;
  }

  async donate({ amount, anonymous, showName, name }) {
    const { url } = await this.call('createDonation', { body: { amount, anonymous, showName, name } });
    await shell.openExternal(url);
    setTimeout(() => this.refresh(), 20000);
    return true;
  }

  async buy(item) {
    const r = await this.call('buyItem', { body: { item } });
    Object.assign(this.state, { coins: r.coins, owned: r.owned });
    await this.refresh();
    return this.state;
  }

  async spin() {
    const r = await this.call('spinWheel', {});
    this.state.wheelAt = r.wheelAt || Date.now();
    await this.refresh();
    return r;
  }

  async daily() {
    const r = await this.call('claimDaily', {});
    Object.assign(this.state, { coins: r.coins, dailyAt: r.dailyAt });
    await this.refresh();
    return this.state;
  }

  async referral() {
    return this.call('myReferral', { method: 'GET' });
  }

  async redeem(code) {
    const r = await this.call('redeemReferral', { body: { code } });
    await this.refresh();
    return r;
  }

  async supporters() {
    try {
      return (await this.call('supporters', { method: 'GET', auth: false })).supporters || [];
    } catch {
      return [];
    }
  }
}

module.exports = { Store };
