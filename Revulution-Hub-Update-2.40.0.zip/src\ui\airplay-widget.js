'use strict';

/* iPhone-Spiegelung als freies Fenster: holt das (versteckte) Empfänger-Fenster per Aufnahme
   und zeigt es mit iPhone-Ecken oder eckig. Ziehen am Bild verschiebt das Fenster. */
(() => {
  const q = new URLSearchParams(location.search);
  const setCorners = (c) => {
    document.body.classList.toggle('square', c === 'square');
    document.getElementById('corners').textContent = c === 'square' ? 'Rund' : 'Eckig';
  };
  setCorners(q.get('corners') || 'round');
  window.hub.onApCorners?.(setCorners);
  document.getElementById('corners').addEventListener('click', () => setCorners(document.body.classList.contains('square') ? 'round' : 'square'));
  document.getElementById('close').addEventListener('click', () => window.hub.apWidgetClose());
  let onTop = true;
  document.getElementById('pin').addEventListener('click', (e) => {
    onTop = !onTop;
    e.currentTarget.textContent = onTop ? 'Nicht oben' : 'Immer oben';
    window.hub.winAlwaysOnTop?.(onTop);
  });

  async function connect() {
    try {
      await window.hub.airplay.arm();
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 60 }, audio: false });
      const v = document.getElementById('v');
      v.srcObject = stream;
      // Text erst weg, wenn wirklich Bild kommt
      v.onplaying = () => (document.getElementById('empty').hidden = true);
      document.getElementById('empty').hidden = true;
      stream.getVideoTracks()[0]?.addEventListener('ended', () => {
        document.getElementById('empty').hidden = false;
        setTimeout(connect, 2000);
      });
    } catch {
      document.getElementById('empty').hidden = false;
      setTimeout(connect, 3000);
    }
  }
  connect();
})();
