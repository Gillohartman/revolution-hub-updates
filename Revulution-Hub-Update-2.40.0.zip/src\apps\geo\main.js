'use strict';

const fs = require('fs');
const path = require('path');
const { boot, bindHubProfile, bindChat } = require('../shared/boot');

const ctx = boot('geo', __dirname);
const { app, ipcMain } = ctx.electron;
bindHubProfile(ipcMain);
bindChat(ipcMain);
const file = () => path.join(app.getPath('userData'), 'profile.json');

ipcMain.handle('load', () => {
  try {
    return JSON.parse(fs.readFileSync(file(), 'utf8'));
  } catch {
    return null;
  }
});
ipcMain.handle('save', (_event, profile) => {
  fs.mkdirSync(path.dirname(file()), { recursive: true });
  fs.writeFileSync(`${file()}.tmp`, JSON.stringify(profile));
  fs.renameSync(`${file()}.tmp`, file());
  return true;
});

/* ------------------------------------------------------------------ Street-View-Suche */
// Sucht das nächste offizielle Google-Street-View-Panorama (Straße, keine Nutzerfotos)
// in der Nähe eines Punktes. Braucht keinen API-Schlüssel.
async function findPano(lat, lng, radius) {
  // 2.41: Google hat die alte GeoPhotoService-Suche abgeschaltet („deprecated“) – darum fand das Spiel nie ein
  // Straßenpanorama und zeigte stattdessen irgendein Nutzerfoto. Neue Suche: nur offizielle Straßenbilder (Typ 2).
  const { net } = ctx.electron;
  const body = [['apiv3', null, null, null, 'US', null, null, null, null, null, [[0]]], [[null, null, lat, lng], radius], [null, ['en', 'US'], null, null, null, null, null, null, [2], null, [[[2, true, 2]]]], [[1, 2, 3, 4, 8, 6]]];
  const url = 'https://maps.googleapis.com/$rpc/google.internal.maps.mapsjs.v1.MapsJsInternalService/SingleImageSearch';
  const opts = { method: 'POST', headers: { 'content-type': 'application/json+protobuf', 'x-user-agent': 'grpc-web-javascript/0.1' }, body: JSON.stringify(body) };
  const res = await (net?.fetch ? net.fetch(url, opts) : fetch(url, opts));
  const j = JSON.parse(await res.text());
  const kind = j?.[1]?.[1]?.[0];
  const id = j?.[1]?.[1]?.[1];
  const loc = j?.[1]?.[5]?.[0]?.[1]?.[0];
  if (kind !== 2 || typeof id !== 'string' || !/^[A-Za-z0-9_-]{22}$/.test(id) || !loc) return null;
  return { pano: id, lat: Number(loc[2]), lng: Number(loc[3]) };
}

ipcMain.handle('pano:find', async (_event, { lat, lng, radii = [800, 4000, 20000] }) => {
  for (const r of radii) {
    try {
      const hit = await findPano(lat, lng, r);
      if (hit) return hit;
    } catch {
      /* nächsten Radius versuchen */
    }
  }
  return null;
});
