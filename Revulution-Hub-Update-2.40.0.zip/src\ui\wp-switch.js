'use strict';

/* Schnellwechsler: gelikte Hintergründe schweben in der Mitte, Nachbarn links und rechts dahinter.
   Pfeiltasten wechseln – der Desktop-Hintergrund wird kurz danach live gesetzt. */
(async () => {
  const stage = document.getElementById('stage');
  const nameEl = document.getElementById('name');
  const busy = document.getElementById('busy');
  let items = [];
  try {
    items = await window.hub.wpSwitch.list();
  } catch {
    items = [];
  }
  if (!items.length) {
    nameEl.textContent = 'Noch keine gelikten Hintergründe';
    return;
  }
  let idx = 0;
  const cards = items.map((it) => {
    const el = document.createElement('div');
    el.className = 'card';
    el.style.backgroundImage = `url("${it.img}")`;
    stage.appendChild(el);
    return el;
  });
  function layout() {
    cards.forEach((el, i) => {
      let d = i - idx;
      if (d > items.length / 2) d -= items.length;
      if (d < -items.length / 2) d += items.length;
      const a = Math.abs(d);
      el.style.transform = `translate(-50%, -50%) translateX(${d * 34}vw) translateZ(${-a * 260}px) rotateY(${-d * 18}deg) scale(${a ? 0.82 : 1})`;
      el.style.opacity = a > 2 ? '0' : a ? '0.55' : '1';
      el.style.filter = a ? 'saturate(0.7) brightness(0.75)' : 'none';
      el.style.zIndex = String(10 - a);
    });
    nameEl.textContent = items[idx].name;
  }
  layout();
  let timer = 0;
  function applySoon() {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      busy.classList.add('on');
      await window.hub.wpSwitch.apply(items[idx]).catch(() => {});
      busy.classList.remove('on');
    }, 650);
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
      idx = (idx + (e.key === 'ArrowRight' ? 1 : -1) + items.length) % items.length;
      layout();
      applySoon();
    } else if (e.key === 'Escape' || e.key === 'Enter') window.hub.wpSwitch.close();
  });
  document.addEventListener('click', (e) => {
    const i = cards.indexOf(e.target.closest('.card'));
    if (i < 0) return window.hub.wpSwitch.close();
    if (i === idx) return window.hub.wpSwitch.close();
    idx = i;
    layout();
    applySoon();
  });
})();
