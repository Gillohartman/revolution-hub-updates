'use strict';

/*
 * Eigene Tooltips statt der grauen Windows-Kästen: jedes title-Attribut wird beim Darüberfahren
 * in ein kleines Liquid-Glass-Schild verwandelt (kurz, rund, mit Einblend-Animation).
 */
(function () {
  if (window.__revTips) return;
  window.__revTips = true;
  let tip = null;
  let cur = null;
  let timer = 0;
  const css = `.rev-tip{position:fixed;z-index:2147483000;max-width:280px;padding:6px 11px;border-radius:12px;pointer-events:none;
    font:500 12px/1.35 'Segoe UI Variable Text','Segoe UI',system-ui,sans-serif;color:#fff;
    background:rgba(40,40,48,.38);-webkit-backdrop-filter:blur(18px) saturate(1.6);backdrop-filter:blur(18px) saturate(1.6);
    box-shadow:inset 0 0 0 .75px rgba(255,255,255,.18),0 10px 26px -10px rgba(0,0,0,.45);text-shadow:0 1px 2px rgba(0,0,0,.45);
    opacity:0;transform:translateY(4px) scale(.97);transition:opacity .16s ease,transform .22s cubic-bezier(.2,1.2,.3,1)}
    .rev-tip.on{opacity:1;transform:none}`;
  const style = document.createElement('style');
  style.textContent = css;
  (document.head || document.documentElement).appendChild(style);

  function hide() {
    clearTimeout(timer);
    if (cur && cur.dataset.revTitle != null && !cur.hasAttribute('title')) cur.setAttribute('title', cur.dataset.revTitle);
    cur = null;
    if (tip) tip.classList.remove('on');
  }
  function show(el) {
    const text = el.dataset.revTitle;
    if (!text) return;
    if (!tip) {
      tip = document.createElement('div');
      tip.className = 'rev-tip';
      document.body.appendChild(tip);
    }
    tip.textContent = text;
    const r = el.getBoundingClientRect();
    const t = tip.getBoundingClientRect();
    let x = r.left + r.width / 2 - t.width / 2;
    let y = r.top - t.height - 8;
    if (y < 4) y = r.bottom + 8;
    x = Math.max(6, Math.min(window.innerWidth - t.width - 6, x));
    tip.style.left = `${x}px`;
    tip.style.top = `${y}px`;
    requestAnimationFrame(() => tip.classList.add('on'));
  }
  document.addEventListener(
    'mouseover',
    (e) => {
      const el = e.target.closest?.('[title]');
      if (!el || el === cur) return;
      hide();
      const text = el.getAttribute('title');
      if (!text) return;
      // title entfernen, sonst zeigt Windows zusätzlich seinen eigenen Kasten
      el.dataset.revTitle = text;
      el.removeAttribute('title');
      cur = el;
      timer = setTimeout(() => cur === el && show(el), 450);
    },
    true,
  );
  document.addEventListener(
    'mouseout',
    (e) => {
      if (cur && (!e.relatedTarget || !cur.contains(e.relatedTarget))) hide();
    },
    true,
  );
  document.addEventListener('mousedown', hide, true);
  window.addEventListener('blur', hide);
  document.addEventListener('scroll', hide, true);
})();
