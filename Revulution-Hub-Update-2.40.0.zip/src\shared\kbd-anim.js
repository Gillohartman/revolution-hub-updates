'use strict';

/*
 * Premium-Displays für die Tastatur (128 × 128): jede Animation ist eine Zeichenfunktion
 * draw(g, t) mit t = 0 … 1 (eine Schleife). Dieselbe Funktion zeichnet die Live-Vorschau
 * im Revolution Store und die 30 Bilder, die auf das AJAZZ-Display geladen werden.
 */
(function (root) {
  const S = 128;
  const TAU = Math.PI * 2;
  // feste Zufallsfolge, damit jede Schleife gleich aussieht
  const rnd = (i) => {
    const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
  };
  const dot = (g, x, y, r, c) => {
    g.fillStyle = c;
    g.beginPath();
    g.arc(x, y, r, 0, TAU);
    g.fill();
  };

  // 5×7-Punktziffern für die Nothing-Uhr
  const DIG = {
    0: ['01110', '10001', '10011', '10101', '11001', '10001', '01110'],
    1: ['00100', '01100', '00100', '00100', '00100', '00100', '01110'],
    2: ['01110', '10001', '00001', '00010', '00100', '01000', '11111'],
    3: ['11110', '00001', '00001', '01110', '00001', '00001', '11110'],
    4: ['00010', '00110', '01010', '10010', '11111', '00010', '00010'],
    5: ['11111', '10000', '11110', '00001', '00001', '10001', '01110'],
    6: ['00110', '01000', '10000', '11110', '10001', '10001', '01110'],
    7: ['11111', '00001', '00010', '00100', '01000', '01000', '01000'],
    8: ['01110', '10001', '10001', '01110', '10001', '10001', '01110'],
    9: ['01110', '10001', '10001', '01111', '00001', '00010', '01100'],
  };

  const ANIMS = {
    // Grüner Code-Regen
    matrix(g, t) {
      g.fillStyle = '#000';
      g.fillRect(0, 0, S, S);
      g.font = '700 10px Consolas, monospace';
      for (let c = 0; c < 16; c++) {
        const speed = 0.6 + rnd(c) * 0.9;
        const head = ((t * speed + rnd(c + 40)) % 1) * (S + 80) - 40;
        for (let k = 0; k < 10; k++) {
          const y = head - k * 9;
          if (y < -10 || y > S + 10) continue;
          const ch = String.fromCharCode(0x30a0 + Math.floor(rnd(c * 31 + k + Math.floor(t * 30)) * 90));
          g.fillStyle = k === 0 ? '#e8ffe8' : `rgba(40,255,90,${1 - k / 10})`;
          g.fillText(ch, c * 8, y);
        }
      }
    },
    // Equalizer-Balken mit roter Spitze
    eqbars(g, t) {
      g.fillStyle = '#050505';
      g.fillRect(0, 0, S, S);
      const n = 12;
      for (let i = 0; i < n; i++) {
        const v = 0.25 + 0.7 * Math.abs(Math.sin(t * TAU * (1 + (i % 3)) + i * 0.9)) * (0.6 + 0.4 * Math.sin(t * TAU + i));
        const h = Math.max(4, Math.round((v * 92) / 6)) * 6;
        for (let y = 0; y < h; y += 6) dot(g, 10 + i * 9.8, 116 - y, 2.4, y + 6 >= h ? '#ff2d2d' : '#fff');
      }
    },
    // Nothing-Uhr aus Punkten, Sekundenpunkt läuft im Kreis
    dotclock(g, t) {
      g.fillStyle = '#000';
      g.fillRect(0, 0, S, S);
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const drawDigit = (d, ox, oy) =>
        DIG[d].forEach((row, y) => [...row].forEach((on, x) => dot(g, ox + x * 5, oy + y * 5, on === '1' ? 1.9 : 0.7, on === '1' ? '#fff' : 'rgba(255,255,255,0.12)')));
      drawDigit(hh[0], 20, 26);
      drawDigit(hh[1], 50, 26);
      drawDigit(mm[0], 20, 70);
      drawDigit(mm[1], 50, 70);
      const a = t * TAU - Math.PI / 2;
      for (let i = 0; i < 24; i++) {
        const b = (i / 24) * TAU - Math.PI / 2;
        dot(g, 100 + Math.cos(b) * 16, 64 + Math.sin(b) * 16, 1.2, 'rgba(255,255,255,0.2)');
      }
      dot(g, 100 + Math.cos(a) * 16, 64 + Math.sin(a) * 16, 3, '#ff2d2d');
    },
    // Lodernde Flamme
    fire(g, t) {
      g.fillStyle = '#000';
      g.fillRect(0, 0, S, S);
      for (let i = 0; i < 70; i++) {
        const life = (t * (1 + rnd(i) * 0.6) + rnd(i + 9)) % 1;
        const x = 64 + (rnd(i + 3) - 0.5) * 70 * (1 - life) + Math.sin(life * 8 + i) * 6;
        const y = 124 - life * 110;
        const r = (1 - life) * 14 + 2;
        const hue = 50 - life * 50;
        g.fillStyle = `hsla(${hue},100%,${60 - life * 25}%,${0.55 * (1 - life)})`;
        g.beginPath();
        g.arc(x, y, r, 0, TAU);
        g.fill();
      }
    },
    // Sterne fliegen auf dich zu
    starfield(g, t) {
      g.fillStyle = '#02030a';
      g.fillRect(0, 0, S, S);
      for (let i = 0; i < 90; i++) {
        const z = 1 - ((t + rnd(i)) % 1);
        const x = 64 + ((rnd(i + 100) - 0.5) * 128) / z;
        const y = 64 + ((rnd(i + 200) - 0.5) * 128) / z;
        if (x < 0 || x > S || y < 0 || y > S) continue;
        dot(g, x, y, Math.max(0.4, (1 - z) * 2.4), `rgba(255,255,255,${1 - z * 0.7})`);
      }
    },
    // Weiches Plasma in Regenbogenfarben
    plasma(g, t) {
      const step = 8;
      for (let y = 0; y < S; y += step)
        for (let x = 0; x < S; x += step) {
          const v = Math.sin(x / 16 + t * TAU) + Math.sin(y / 11 - t * TAU) + Math.sin((x + y) / 22 + t * TAU * 2);
          g.fillStyle = `hsl(${(v * 60 + t * 360) % 360},90%,55%)`;
          g.fillRect(x, y, step, step);
        }
    },
    // Pochendes Herz aus Punkten
    heart(g, t) {
      g.fillStyle = '#000';
      g.fillRect(0, 0, S, S);
      const beat = 1 + 0.12 * Math.max(Math.sin(t * TAU * 2) ** 8, Math.sin(t * TAU * 2 + 0.6) ** 8);
      for (let y = 0; y < 16; y++)
        for (let x = 0; x < 16; x++) {
          const px = ((x - 7.5) / 6.2) / beat;
          const py = (-(y - 7) / 6.2) / beat;
          const inside = (px * px + py * py - 1) ** 3 - px * px * py ** 3 < 0;
          dot(g, 4 + x * 8, 4 + y * 8, inside ? 3.2 : 1, inside ? '#ff2d55' : 'rgba(255,255,255,0.1)');
        }
    },
    // Radar mit Nachleuchten
    radar(g, t) {
      g.fillStyle = '#000a04';
      g.fillRect(0, 0, S, S);
      g.strokeStyle = 'rgba(60,255,140,0.35)';
      for (const r of [18, 36, 54]) {
        g.beginPath();
        g.arc(64, 64, r, 0, TAU);
        g.stroke();
      }
      const a = t * TAU;
      for (let k = 0; k < 30; k++) {
        const b = a - k * 0.04;
        g.strokeStyle = `rgba(60,255,140,${0.5 * (1 - k / 30)})`;
        g.beginPath();
        g.moveTo(64, 64);
        g.lineTo(64 + Math.cos(b) * 58, 64 + Math.sin(b) * 58);
        g.stroke();
      }
      for (let i = 0; i < 5; i++) {
        const b = rnd(i) * TAU;
        const d = 14 + rnd(i + 7) * 40;
        let diff = (a - b) % TAU;
        if (diff < 0) diff += TAU;
        dot(g, 64 + Math.cos(b) * d, 64 + Math.sin(b) * d, 2.6, `rgba(160,255,200,${Math.max(0, 1 - diff / 2.5)})`);
      }
    },
  };

  /** 30 Bilder einer Animation als Canvas-Liste (für das Display). */
  function frames(id, count = 30) {
    const fn = ANIMS[id];
    if (!fn) return [];
    const out = [];
    for (let i = 0; i < count; i++) {
      const c = document.createElement('canvas');
      c.width = c.height = S;
      const g = c.getContext('2d', { willReadFrequently: true });
      fn(g, i / count);
      out.push(c);
    }
    return out;
  }

  /* Live-Vorschau: jedes <canvas data-kbd="id"> im Dokument läuft automatisch. */
  let raf = 0;
  function loop(now) {
    raf = 0;
    const list = document.querySelectorAll('canvas[data-kbd]');
    if (!list.length) return;
    for (const c of list) {
      const fn = ANIMS[c.dataset.kbd];
      if (!fn || !c.isConnected) continue;
      const g = c.getContext('2d');
      g.save();
      g.scale(c.width / S, c.height / S);
      fn(g, (now / 3000) % 1);
      g.restore();
    }
    raf = requestAnimationFrame(loop);
  }
  function kick() {
    if (!raf && typeof requestAnimationFrame === 'function') raf = requestAnimationFrame(loop);
  }
  if (typeof MutationObserver !== 'undefined' && typeof document !== 'undefined') {
    const start = () => new MutationObserver(kick).observe(document.body, { childList: true, subtree: true });
    if (document.body) start();
    else document.addEventListener('DOMContentLoaded', start);
  }

  root.RevKbd = { ANIMS, frames, kick };
})(typeof self !== 'undefined' ? self : globalThis);
