'use strict';

/*
 * Monitor-Auswahl für „Als Hintergrund“ (2.35, Liquid Glass): zeigt das echte Monitor-Layout
 * mit dem gewählten Bild als Vorschau auf jedem Monitor. Ausgewählte Monitore leuchten,
 * die echten Monitore blinken dabei kurz mit. Ergebnis: { mode, monitors } oder null.
 */
(() => {
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  window.pickWallpaperTarget = async function pickWallpaperTarget(opts = {}) {
    let mons = [];
    try {
      mons = await window.hub.community.monitors();
    } catch {
      mons = [];
    }
    if (mons.length <= 1) return { mode: 'all', monitors: [] };
    const img = typeof opts === 'string' ? opts : opts.img || '';
    const name = typeof opts === 'object' ? opts.name || '' : '';
    return new Promise((resolve) => {
      const sel = new Set(mons.map((m) => m.id));
      let span = false;
      const minX = Math.min(...mons.map((m) => m.x));
      const minY = Math.min(...mons.map((m) => m.y));
      const maxX = Math.max(...mons.map((m) => m.x + m.w));
      const maxY = Math.max(...mons.map((m) => m.y + m.h));
      const W = 600;
      const H = 250;
      const k = Math.min(W / (maxX - minX), H / (maxY - minY));
      const offX = (W - (maxX - minX) * k) / 2;
      const offY = (H - (maxY - minY) * k) / 2;
      const order = [...mons].sort((a, b) => a.x - b.x || a.y - b.y).map((m) => m.id);
      const label = (id) => order.indexOf(id) + 1;
      const back = document.createElement('div');
      back.className = 'mp-back';
      back.innerHTML = `<div class="mp-sheet" role="dialog">
        <div class="mp-head"><span class="mp-eyebrow">ALS HINTERGRUND</span><h3>${name ? `${esc(name)} – ` : ''}auf welche Monitore?</h3><p>Tippe Monitore an, um sie aus- oder abzuwählen.</p></div>
        <div class="mp-stage" style="width:${W}px;height:${H}px">${mons
          .map((m, i) => `<button class="mp-mon" data-id="${m.id}" style="--d:${i * 70}ms;left:${offX + (m.x - minX) * k + 4}px;top:${offY + (m.y - minY) * k + 4}px;width:${m.w * k - 8}px;height:${m.h * k - 8}px">
              <span class="mp-img" ${img ? `style="background-image:url('${img}')"` : ''}></span>
              <span class="mp-num">${label(m.id)}</span><span class="mp-res">${m.w}×${m.h}</span><span class="mp-check">✓</span></button>`)
          .join('')}</div>
        <div class="mp-foot"><div class="mp-seg"><button data-mp="all">Alle Monitore</button><button data-mp="span">Über alle strecken</button></div>
          <span class="mp-grow"></span><button class="btn ghost" data-mp="cancel">Abbrechen</button><button class="btn primary" data-mp="ok">Anwenden</button></div>
      </div>`;
      document.body.appendChild(back);
      requestAnimationFrame(() => back.classList.add('in'));
      const paint = () => {
        back.querySelectorAll('.mp-mon').forEach((b) => b.classList.toggle('on', span || sel.has(Number(b.dataset.id))));
        back.querySelector('[data-mp="span"]').classList.toggle('on', span);
        back.querySelector('[data-mp="all"]').classList.toggle('on', !span && sel.size === mons.length);
        back.querySelector('.mp-stage').classList.toggle('span', span);
        back.querySelector('[data-mp="ok"]').disabled = !span && !sel.size;
        window.hub.community.highlight?.(mons.filter((m) => span || sel.has(m.id))).catch(() => {});
      };
      paint();
      const close = (result) => {
        window.hub.community.highlight?.([]).catch(() => {});
        back.classList.remove('in');
        setTimeout(() => back.remove(), 280);
        document.removeEventListener('keydown', onKey);
        resolve(result);
      };
      const onKey = (e) => e.key === 'Escape' && close(null);
      document.addEventListener('keydown', onKey);
      back.addEventListener('click', (e) => {
        const mon = e.target.closest('.mp-mon');
        if (mon) {
          span = false;
          const id = Number(mon.dataset.id);
          sel.has(id) ? sel.delete(id) : sel.add(id);
          return paint();
        }
        const a = e.target.closest('[data-mp]')?.dataset.mp;
        if (a === 'all') {
          span = false;
          mons.forEach((m) => sel.add(m.id));
          paint();
        } else if (a === 'span') {
          span = !span;
          paint();
        } else if (a === 'cancel' || e.target === back) close(null);
        else if (a === 'ok') close(span ? { mode: 'span', monitors: [] } : sel.size === mons.length ? { mode: 'all', monitors: [] } : { mode: 'select', monitors: [...sel] });
      });
    });
  };
})();
