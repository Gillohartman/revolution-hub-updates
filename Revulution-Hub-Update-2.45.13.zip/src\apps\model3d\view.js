'use strict';
/*
 * 3D-Modell – WebGL-2-Ansicht: Druckbett mit Raster, Bauraum, Objekte mit Kantenlinien.
 * Flächennormalen kommen aus den Ableitungen im Shader (kein Normalenpuffer nötig).
 */
(function () {
  const { M } = window.M3G;

  const VS = `#version 300 es
  uniform mat4 uVP, uM; in vec3 aPos; out vec3 vW;
  void main(){ vec4 w = uM * vec4(aPos,1.0); vW = w.xyz; gl_Position = uVP * w; }`;
  const FS = `#version 300 es
  precision highp float; uniform vec4 uColor; uniform vec3 uEye; uniform float uLit, uSel; in vec3 vW; out vec4 o;
  void main(){
    if (uLit < 0.5) { o = uColor; return; }
    vec3 n = normalize(cross(dFdx(vW), dFdy(vW)));
    vec3 v = normalize(uEye - vW); if (dot(n, v) < 0.0) n = -n;
    vec3 l1 = normalize(v + vec3(0.25, 0.15, 0.6)); vec3 l2 = normalize(vec3(-0.6, 0.4, 0.5));
    float d = 0.55 * max(dot(n, l1), 0.0) + 0.22 * max(dot(n, l2), 0.0) + 0.16 * (0.5 + 0.5 * n.z) + 0.2;
    float s = pow(max(dot(n, normalize(l1 + v)), 0.0), 48.0) * 0.22;
    float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0) * uSel * 0.55;
    vec3 c = uColor.rgb * d + s + rim * vec3(1.0, 0.45, 0.38);
    o = vec4(c, uColor.a);
  }`;

  function View(canvas) {
    const gl = canvas.getContext('webgl2', { antialias: true, alpha: false, preserveDrawingBuffer: true });
    if (!gl) throw new Error('WebGL 2 ist auf diesem Gerät nicht verfügbar.');
    const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
    const U = {}; for (const n of ['uVP', 'uM', 'uColor', 'uEye', 'uLit', 'uSel']) U[n] = gl.getUniformLocation(prog, n);
    const aPos = gl.getAttribLocation(prog, 'aPos');
    const cache = new WeakMap(); // Float32Array → GPU-Puffer
    const buf = (arr) => {
      let e = cache.get(arr);
      if (!e) {
        const mk = (data) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); return b; };
        const edges = window.M3G.featureEdges(arr);
        e = { tri: mk(arr), n: arr.length / 3, edge: mk(edges), en: edges.length / 3 };
        cache.set(arr, e);
      }
      return e;
    };
    const tmp = gl.createBuffer();

    const cam = { target: [0, 0, 10], yaw: -60, pitch: 32, dist: 380, fov: 40, ortho: false };
    const v = { gl, cam, canvas, vp: M.ident(), view: M.ident(), proj: M.ident(), eye: [0, 0, 0], w: 1, h: 1 };

    v.eyePos = () => {
      const y = (cam.yaw * Math.PI) / 180, p = (cam.pitch * Math.PI) / 180;
      return [cam.target[0] + cam.dist * Math.cos(p) * Math.cos(y), cam.target[1] + cam.dist * Math.cos(p) * Math.sin(y), cam.target[2] + cam.dist * Math.sin(p)];
    };
    v.update = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = Math.max(1, Math.round(canvas.clientWidth * dpr)), h = Math.max(1, Math.round(canvas.clientHeight * dpr));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      v.w = canvas.clientWidth; v.h = canvas.clientHeight;
      v.eye = v.eyePos();
      const up = Math.abs(cam.pitch) > 89.5 ? [-Math.cos((cam.yaw * Math.PI) / 180), -Math.sin((cam.yaw * Math.PI) / 180), 0] : [0, 0, 1];
      v.view = M.look(v.eye, cam.target, up);
      const asp = v.w / v.h; const near = Math.max(0.3, cam.dist / 400), far = cam.dist * 30 + 4000;
      v.proj = cam.ortho ? M.ortho(cam.dist * Math.tan((cam.fov * Math.PI) / 360), asp, -far, far) : M.persp((cam.fov * Math.PI) / 180, asp, near, far);
      v.vp = M.mul(v.proj, v.view);
      v.ivp = M.inv(v.vp);
    };
    // Bildschirm → Strahl in Welt
    v.ray = (x, y) => {
      const nx = (x / v.w) * 2 - 1, ny = 1 - (y / v.h) * 2;
      const a = M.pt(v.ivp, [nx, ny, -1]), b = M.pt(v.ivp, [nx, ny, 1]);
      const d = window.M3G.nrm([b[0] - a[0], b[1] - a[1], b[2] - a[2]]);
      return { o: a, d };
    };
    // Welt → Bildschirm (px), z < 1 sichtbar
    v.project = (p) => {
      const m = v.vp; const x = m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], y = m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], w = m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15];
      return [((x / w) * 0.5 + 0.5) * v.w, (0.5 - (y / w) * 0.5) * v.h, w];
    };
    // Weltlänge eines Pixels an einem Punkt
    v.pxSize = (p) => {
      if (cam.ortho) return (2 * cam.dist * Math.tan((cam.fov * Math.PI) / 360)) / v.h;
      const d = Math.hypot(p[0] - v.eye[0], p[1] - v.eye[1], p[2] - v.eye[2]);
      return (2 * d * Math.tan((cam.fov * Math.PI) / 360)) / v.h;
    };

    let gridArr = null, gridKey = '';
    function grid(bed) {
      const key = `${bed.w}x${bed.d}x${bed.h}`;
      if (key === gridKey) return gridArr;
      const minor = [], major = [], box = [];
      const w = bed.w / 2, d = bed.d / 2;
      for (let x = 0; x <= w + 1e-6; x += 10) for (const s of x ? [1, -1] : [1]) ((Math.round(x) % 50 === 0) ? major : minor).push(s * x, -d, 0.01, s * x, d, 0.01);
      for (let y = 0; y <= d + 1e-6; y += 10) for (const s of y ? [1, -1] : [1]) ((Math.round(y) % 50 === 0) ? major : minor).push(-w, s * y, 0.01, w, s * y, 0.01);
      const c = [[-w, -d], [w, -d], [w, d], [-w, d]];
      for (let i = 0; i < 4; i += 1) { const [a, b] = [c[i], c[(i + 1) % 4]]; box.push(a[0], a[1], bed.h, b[0], b[1], bed.h, a[0], a[1], 0, a[0], a[1], bed.h); }
      const plate = new Float32Array([-w, -d, 0, w, -d, 0, w, d, 0, -w, -d, 0, w, d, 0, -w, d, 0]);
      gridArr = { minor: new Float32Array(minor), major: new Float32Array(major), box: new Float32Array(box), plate, rim: new Float32Array([-w, -d, 0.02, w, -d, 0.02, w, -d, 0.02, w, d, 0.02, w, d, 0.02, -w, d, 0.02, -w, d, 0.02, -w, -d, 0.02]) };
      gridKey = key;
      return gridArr;
    }
    const ID = M.ident();
    function drawArr(arr, mode, color, model = ID, lit = 0, sel = 0) {
      gl.bindBuffer(gl.ARRAY_BUFFER, tmp); gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STREAM_DRAW);
      gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
      gl.uniformMatrix4fv(U.uM, false, model); gl.uniform4fv(U.uColor, color); gl.uniform1f(U.uLit, lit); gl.uniform1f(U.uSel, sel);
      gl.drawArrays(mode, 0, arr.length / 3);
    }
    function drawMesh(mesh, model, color, lit, sel, edges, edgeColor) {
      const e = buf(mesh);
      gl.uniformMatrix4fv(U.uM, false, model); gl.uniform1f(U.uSel, sel);
      gl.bindBuffer(gl.ARRAY_BUFFER, e.tri); gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
      gl.uniform4fv(U.uColor, color); gl.uniform1f(U.uLit, lit);
      gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(1, 1);
      gl.drawArrays(gl.TRIANGLES, 0, e.n);
      gl.disable(gl.POLYGON_OFFSET_FILL);
      if (edges && e.en) {
        gl.bindBuffer(gl.ARRAY_BUFFER, e.edge); gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
        gl.uniform4fv(U.uColor, edgeColor); gl.uniform1f(U.uLit, 0);
        gl.drawArrays(gl.LINES, 0, e.en);
      }
    }
    const hex = (h, a = 1) => { const n = parseInt(String(h || '#888').slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255, a]; };

    // items: [{ mesh, model, color, hole, sel, ghost }]
    v.render = (items, bed, opts = {}) => {
      v.update();
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.clearColor(0.085, 0.088, 0.1, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.useProgram(prog); gl.enableVertexAttribArray(aPos);
      gl.uniformMatrix4fv(U.uVP, false, v.vp); gl.uniform3fv(U.uEye, v.eye);
      gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.disable(gl.CULL_FACE);
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      const g = grid(bed);
      const below = v.eye[2] < 0;
      // Druckbett
      gl.depthMask(true);
      gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(2, 2);
      drawArr(g.plate, gl.TRIANGLES, below ? [0.16, 0.17, 0.2, 0.35] : [0.15, 0.155, 0.175, 1]);
      gl.disable(gl.POLYGON_OFFSET_FILL);
      drawArr(g.minor, gl.LINES, [1, 1, 1, 0.07]);
      drawArr(g.major, gl.LINES, [1, 1, 1, 0.16]);
      drawArr(g.rim, gl.LINES, opts.outside ? [1, 0.35, 0.3, 0.9] : [1, 1, 1, 0.35]);
      drawArr(g.box, gl.LINES, [1, 1, 1, 0.06]);
      drawArr(new Float32Array([-bed.w / 2, -bed.d / 2, 0.03, -bed.w / 2 + 20, -bed.d / 2, 0.03]), gl.LINES, [1, 0.3, 0.3, 1]);
      drawArr(new Float32Array([-bed.w / 2, -bed.d / 2, 0.03, -bed.w / 2, -bed.d / 2 + 20, 0.03]), gl.LINES, [0.35, 0.9, 0.4, 1]);
      drawArr(new Float32Array([-bed.w / 2, -bed.d / 2, 0, -bed.w / 2, -bed.d / 2, 20]), gl.LINES, [0.35, 0.6, 1, 1]);
      // Körper
      for (const it of items) if (!it.hole) drawMesh(it.mesh, it.model, it.sel ? hex(it.color).map((c, i) => (i < 3 ? Math.min(1, c * 1.08 + 0.04) : 1)) : hex(it.color), 1, it.sel ? 1 : 0, true, it.sel ? [1, 0.42, 0.36, 1] : [0, 0, 0, 0.45]);
      // Schatten-Fussabdruck der Auswahl
      if (opts.footprint) drawArr(opts.footprint, gl.LINES, [1, 0.42, 0.36, 0.55]);
      // Löcher durchscheinend
      gl.depthMask(false);
      for (const it of items) if (it.hole) drawMesh(it.mesh, it.model, [0.62, 0.66, 0.74, it.sel ? 0.42 : 0.28], 1, it.sel ? 1 : 0, true, it.sel ? [1, 0.42, 0.36, 0.9] : [0.8, 0.85, 0.95, 0.5]);
      gl.depthMask(true);
      // Hilfslinien ohne Tiefentest
      if (opts.lines) { gl.disable(gl.DEPTH_TEST); for (const [arr, col] of opts.lines) drawArr(arr, gl.LINES, col); gl.enable(gl.DEPTH_TEST); }
    };
    v.snapshot = () => canvas.toDataURL('image/png');
    return v;
  }
  window.M3View = View;
})();
