'use strict';
/*
 * 3D-Modell – Geometrie ohne Bibliotheken.
 * Netze sind Float32Arrays aus Dreiecken (9 Werte je Dreieck, gegen den Uhrzeigersinn von aussen),
 * Z zeigt nach oben, Einheit mm. Grundkörper stehen mittig auf z = 0.
 * Enthält: Grundkörper, 3D-Text, Matrizen, CSG (BSP), STL/OBJ/3MF.
 */
(function () {
  const TAU = Math.PI * 2;

  /* ------------------------------------------------------------ Bauhelfer */
  function builder() {
    const a = [];
    const tri = (p, q, r) => {
      const ux = q[0] - p[0], uy = q[1] - p[1], uz = q[2] - p[2];
      const vx = r[0] - p[0], vy = r[1] - p[1], vz = r[2] - p[2];
      const cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
      if (cx * cx + cy * cy + cz * cz < 1e-14) return; // entartet
      a.push(p[0], p[1], p[2], q[0], q[1], q[2], r[0], r[1], r[2]);
    };
    return { tri, quad: (p, q, r, s) => { tri(p, q, r); tri(p, r, s); }, done: () => new Float32Array(a) };
  }
  const ring = (n, rx, ry, z, phase = 0) => Array.from({ length: n }, (_, i) => {
    const t = phase + (i / n) * TAU;
    return [rx * Math.cos(t), ry * Math.sin(t), z];
  });
  // Seitenwand zwischen zwei Ringen gleicher Länge (unten → oben), optional mit Deckeln
  function loft(b, lo, up, capLo = true, capUp = true) {
    const n = lo.length;
    for (let i = 0; i < n; i += 1) {
      const j = (i + 1) % n;
      b.quad(lo[i], lo[j], up[j], up[i]);
    }
    if (capLo) for (let i = 1; i < n - 1; i += 1) b.tri(lo[0], lo[i + 1], lo[i]);
    if (capUp) for (let i = 1; i < n - 1; i += 1) b.tri(up[0], up[i], up[i + 1]);
  }
  const rect = (w, d, z) => [[-w / 2, -d / 2, z], [w / 2, -d / 2, z], [w / 2, d / 2, z], [-w / 2, d / 2, z]];
  const clampInt = (v, lo, hi, def) => Math.max(lo, Math.min(hi, Math.round(Number(v)) || def));
  const pos = (v, def) => (Number(v) > 0 ? Number(v) : def);

  /* ---------------------------------------------------------- Grundkörper */
  const SHAPES = {
    box: {
      name: 'Würfel', params: [['w', 'Breite', 20], ['d', 'Tiefe', 20], ['h', 'Höhe', 20]],
      make: (p) => { const b = builder(); loft(b, rect(pos(p.w, 20), pos(p.d, 20), 0), rect(pos(p.w, 20), pos(p.d, 20), pos(p.h, 20))); return b.done(); },
    },
    cyl: {
      name: 'Zylinder', params: [['r', 'Radius', 10], ['h', 'Höhe', 20], ['n', 'Segmente', 64]],
      make: (p) => { const b = builder(); const n = clampInt(p.n, 3, 256, 64); loft(b, ring(n, pos(p.r, 10), pos(p.r, 10), 0), ring(n, pos(p.r, 10), pos(p.r, 10), pos(p.h, 20))); return b.done(); },
    },
    sphere: {
      name: 'Kugel', params: [['r', 'Radius', 10], ['n', 'Segmente', 48]],
      make: (p) => sphere(pos(p.r, 10), clampInt(p.n, 6, 160, 48), false),
    },
    hemi: {
      name: 'Halbkugel', params: [['r', 'Radius', 10], ['n', 'Segmente', 48]],
      make: (p) => sphere(pos(p.r, 10), clampInt(p.n, 6, 160, 48), true),
    },
    cone: {
      name: 'Kegel', params: [['r1', 'Radius unten', 10], ['r2', 'Radius oben', 0], ['h', 'Höhe', 20], ['n', 'Segmente', 64]],
      make: (p) => {
        const b = builder(); const n = clampInt(p.n, 3, 256, 64); const r1 = pos(p.r1, 10), r2 = Math.max(0, Number(p.r2) || 0), h = pos(p.h, 20);
        if (r2 < 1e-6) { const lo = ring(n, r1, r1, 0); const apex = [0, 0, h]; for (let i = 0; i < n; i += 1) b.tri(lo[i], lo[(i + 1) % n], apex); for (let i = 1; i < n - 1; i += 1) b.tri(lo[0], lo[i + 1], lo[i]); }
        else loft(b, ring(n, r1, r1, 0), ring(n, r2, r2, h));
        return b.done();
      },
    },
    pyramid: {
      name: 'Pyramide', params: [['w', 'Breite', 20], ['d', 'Tiefe', 20], ['h', 'Höhe', 20]],
      make: (p) => { const b = builder(); const lo = rect(pos(p.w, 20), pos(p.d, 20), 0); const apex = [0, 0, pos(p.h, 20)]; for (let i = 0; i < 4; i += 1) b.tri(lo[i], lo[(i + 1) % 4], apex); b.tri(lo[0], lo[2], lo[1]); b.tri(lo[0], lo[3], lo[2]); return b.done(); },
    },
    prism: {
      name: 'Prisma', params: [['k', 'Seiten', 3], ['r', 'Radius', 12], ['h', 'Höhe', 20]],
      make: (p) => { const b = builder(); const k = clampInt(p.k, 3, 64, 3); const r = pos(p.r, 12); loft(b, ring(k, r, r, 0, Math.PI / 2), ring(k, r, r, pos(p.h, 20), Math.PI / 2)); return b.done(); },
    },
    wedge: {
      name: 'Keil', params: [['w', 'Breite', 20], ['d', 'Tiefe', 20], ['h', 'Höhe', 20]],
      make: (p) => {
        const w = pos(p.w, 20) / 2, d = pos(p.d, 20) / 2, h = pos(p.h, 20); const b = builder();
        const A = [-w, -d, 0], B = [w, -d, 0], C = [w, d, 0], D = [-w, d, 0], E = [-w, d, h], F = [w, d, h];
        b.quad(A, D, C, B); b.quad(D, E, F, C); b.quad(A, B, F, E); b.tri(A, E, D); b.tri(B, C, F);
        return b.done();
      },
    },
    torus: {
      name: 'Torus', params: [['R', 'Ringradius', 15], ['r', 'Rohrradius', 5], ['n', 'Segmente', 64], ['m', 'Querschnitt', 24]],
      make: (p) => {
        const R = pos(p.R, 15), r = Math.min(pos(p.r, 5), R * 0.999); const n = clampInt(p.n, 3, 256, 64), m = clampInt(p.m, 3, 128, 24); const b = builder();
        const P = (i, k) => { const u = (i / n) * TAU, v = (k / m) * TAU; const q = R + r * Math.cos(v); return [q * Math.cos(u), q * Math.sin(u), r + r * Math.sin(v)]; };
        for (let i = 0; i < n; i += 1) for (let k = 0; k < m; k += 1) b.quad(P(i, k), P(i + 1, k), P(i + 1, k + 1), P(i, k + 1));
        return b.done();
      },
    },
    tube: {
      name: 'Rohr', params: [['ro', 'Aussenradius', 12], ['ri', 'Innenradius', 9], ['h', 'Höhe', 20], ['n', 'Segmente', 64]],
      make: (p) => {
        const ro = pos(p.ro, 12), ri = Math.min(pos(p.ri, 9), ro - 0.01), h = pos(p.h, 20), n = clampInt(p.n, 3, 256, 64); const b = builder();
        const bo = ring(n, ro, ro, 0), to = ring(n, ro, ro, h), bi = ring(n, ri, ri, 0), ti = ring(n, ri, ri, h);
        for (let i = 0; i < n; i += 1) {
          const j = (i + 1) % n;
          b.quad(bo[i], bo[j], to[j], to[i]);
          b.quad(bi[j], bi[i], ti[i], ti[j]);
          b.quad(to[i], to[j], ti[j], ti[i]);
          b.quad(bo[i], bi[i], bi[j], bo[j]);
        }
        return b.done();
      },
    },
    text: {
      name: 'Text', params: [['t', 'Text', 'Text', 'text'], ['size', 'Schriftgrösse', 12], ['h', 'Höhe', 3], ['font', 'Schrift', 'Segoe UI', 'font'], ['bold', 'Fett', true, 'bool'], ['res', 'Auflösung', 0.15]],
      make: (p) => textMesh(String(p.t ?? 'Text'), pos(p.size, 12), pos(p.h, 3), p.font || 'Segoe UI', p.bold !== false, Math.max(0.05, Math.min(1, Number(p.res) || 0.15))),
    },
  };
  const FONTS = ['Segoe UI', 'Arial', 'Arial Black', 'Bahnschrift', 'Consolas', 'Georgia', 'Impact', 'Times New Roman', 'Comic Sans MS'];

  function sphere(r, n, half) {
    const b = builder(); const stacks = Math.max(3, Math.round(n / 2));
    const k0 = half ? Math.floor(stacks / 2) : 0;
    const zc = half ? 0 : r;
    const R = (k) => { const phi = -Math.PI / 2 + (k / stacks) * Math.PI; return ring(n, r * Math.cos(phi), r * Math.cos(phi), zc + r * Math.sin(phi)); };
    if (half && stacks % 2) { /* gerade Anzahl erzwingen, damit der Äquator genau auf z = 0 liegt */ return sphere(r, n + 2, true); }
    for (let k = k0; k < stacks; k += 1) {
      const lo = R(k), up = R(k + 1);
      for (let i = 0; i < n; i += 1) { const j = (i + 1) % n; b.quad(lo[i], lo[j], up[j], up[i]); }
    }
    if (half) { const lo = R(k0); for (let i = 1; i < n - 1; i += 1) b.tri(lo[0], lo[i + 1], lo[i]); }
    return b.done();
  }

  /* --------------------------------------------------- 3D-Text (gerastert) */
  // Text wird in ein Raster gezeichnet und als geschlossenes, wasserdichtes Netz extrudiert.
  function textMesh(text, size, depth, font, bold, res) {
    const lines = (text || ' ').split('\n');
    const px = Math.max(8, Math.round(size / res));
    const cv = document.createElement('canvas');
    const g = cv.getContext('2d', { willReadFrequently: true });
    const css = `${bold ? '700 ' : ''}${px}px "${font}"`;
    g.font = css;
    const lh = Math.round(px * 1.15);
    const W = Math.min(6000, Math.ceil(Math.max(...lines.map((l) => g.measureText(l).width), 1)) + 8);
    const H = Math.min(6000, lh * lines.length + 8);
    cv.width = W; cv.height = H;
    g.font = css; g.textBaseline = 'top'; g.fillStyle = '#fff';
    lines.forEach((l, i) => g.fillText(l, 4, 4 + i * lh));
    const img = g.getImageData(0, 0, W, H).data;
    const grid = new Uint8Array(W * H);
    for (let i = 0; i < W * H; i += 1) grid[i] = img[i * 4 + 3] > 120 ? 1 : 0;
    // nur diagonal berührende Pixel verbinden (sonst nicht-mannigfaltige Kanten)
    for (let pass = 0; pass < 4; pass += 1) {
      let changed = false;
      for (let y = 0; y < H - 1; y += 1) for (let x = 0; x < W - 1; x += 1) {
        const a = grid[y * W + x], b2 = grid[y * W + x + 1], c = grid[(y + 1) * W + x], d = grid[(y + 1) * W + x + 1];
        if (a && d && !b2 && !c) { grid[y * W + x + 1] = 1; changed = true; } else if (b2 && c && !a && !d) { grid[y * W + x] = 1; changed = true; }
      }
      if (!changed) break;
    }
    const at = (x, y) => (x >= 0 && y >= 0 && x < W && y < H ? grid[y * W + x] : 0);
    const runs = [];
    for (let y = 0; y < H; y += 1) {
      const r = [];
      for (let x = 0; x < W; x += 1) if (at(x, y) && !at(x - 1, y)) { let e = x; while (at(e, y)) e += 1; r.push([x, e]); }
      runs.push(r);
    }
    const b = builder();
    const P = (x, y, z) => [x * res, -y * res, z];
    const breaks = (row, x0, x1) => { const s = new Set(); for (const [a, e] of runs[row] || []) { if (a > x0 && a < x1) s.add(a); if (e > x0 && e < x1) s.add(e); } return [...s].sort((m, n) => m - n); };
    let filled = 0;
    for (let y = 0; y < H; y += 1) for (const [x0, x1] of runs[y]) {
      filled += 1;
      // Umriss im Uhrzeigersinn (Welt-Y zeigt nach oben): obere Kante → rechts, untere Kante → links
      const poly = [[x0, y]];
      for (const x of y > 0 ? breaks(y - 1, x0, x1) : []) poly.push([x, y]);
      poly.push([x1, y], [x1, y + 1]);
      for (const x of (y + 1 < H ? breaks(y + 1, x0, x1) : []).reverse()) poly.push([x, y + 1]);
      poly.push([x0, y + 1]);
      const cx = (x0 + x1) / 2, cy = y + 0.5;
      for (let k = 0; k < poly.length; k += 1) {
        const p = poly[k], q = poly[(k + 1) % poly.length];
        b.tri(P(cx, cy, depth), P(q[0], q[1], depth), P(p[0], p[1], depth));
        b.tri(P(cx, cy, 0), P(p[0], p[1], 0), P(q[0], q[1], 0));
      }
      // senkrechte Wände links/rechts
      wall(b, P(x0, y, 0), P(x0, y + 1, 0), depth);
      wall(b, P(x1, y + 1, 0), P(x1, y, 0), depth);
    }
    if (!filled) return SHAPES.box.make({ w: size, d: 1, h: depth });
    // waagrechte Wände zwischen Zeilen
    for (let y = 0; y <= H; y += 1) {
      let x = 0;
      while (x < W) {
        const up = at(x, y - 1), dn = at(x, y);
        if (up === dn) { x += 1; continue; }
        let e = x; while (e < W && at(e, y - 1) === up && at(e, y) === dn) e += 1;
        if (dn) wall(b, P(e, y, 0), P(x, y, 0), depth); // Fläche gegen +Y (oben frei)
        else wall(b, P(x, y, 0), P(e, y, 0), depth); // Fläche gegen −Y
        x = e;
      }
    }
    return center(b.done());
  }
  // Wand über der Kante p→q (z = 0), Normale zeigt rechts der Laufrichtung
  function wall(b, p, q, h) { b.quad(p, q, [q[0], q[1], h], [p[0], p[1], h]); }

  /* --------------------------------------------------------- Netzwerkzeuge */
  function bbox(a) {
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < a.length; i += 3) for (let k = 0; k < 3; k += 1) { const v = a[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
    return { min: mn, max: mx };
  }
  // verschiebt das Netz so, dass es mittig auf z = 0 steht; gibt den Versatz zurück
  function center(a, out) {
    const bb = bbox(a); const o = [(bb.min[0] + bb.max[0]) / 2, (bb.min[1] + bb.max[1]) / 2, bb.min[2]];
    const r = new Float32Array(a.length);
    for (let i = 0; i < a.length; i += 3) { r[i] = a[i] - o[0]; r[i + 1] = a[i + 1] - o[1]; r[i + 2] = a[i + 2] - o[2]; }
    if (out) out.push(...o);
    return r;
  }
  function volume(a) {
    let v = 0;
    for (let i = 0; i < a.length; i += 9) {
      const [x1, y1, z1, x2, y2, z2, x3, y3, z3] = [a[i], a[i + 1], a[i + 2], a[i + 3], a[i + 4], a[i + 5], a[i + 6], a[i + 7], a[i + 8]];
      v += (x1 * (y2 * z3 - z2 * y3) - y1 * (x2 * z3 - z2 * x3) + z1 * (x2 * y3 - y2 * x3)) / 6;
    }
    return v;
  }
  // Kanten, an denen zwei Flächen deutlich knicken (oder offene Kanten) – für die Kantenlinien
  function featureEdges(a, deg = 28) {
    const key = (i) => `${Math.round(a[i] * 1e3)},${Math.round(a[i + 1] * 1e3)},${Math.round(a[i + 2] * 1e3)}`;
    const ids = new Map(); const pts = [];
    const id = (i) => { const k = key(i); let v = ids.get(k); if (v === undefined) { v = pts.length / 3; ids.set(k, v); pts.push(a[i], a[i + 1], a[i + 2]); } return v; };
    const edges = new Map(); const cos = Math.cos((deg * Math.PI) / 180);
    const tris = a.length / 9;
    if (tris > 400000) return new Float32Array(0);
    for (let t = 0; t < tris; t += 1) {
      const o = t * 9; const v = [id(o), id(o + 3), id(o + 6)];
      const n = normal(a, o);
      for (let k = 0; k < 3; k += 1) {
        const p = v[k], q = v[(k + 1) % 3]; if (p === q) continue;
        const ek = p < q ? `${p}_${q}` : `${q}_${p}`;
        const e = edges.get(ek); if (e) e.push(n); else edges.set(ek, [n]);
      }
    }
    const out = [];
    for (const [ek, ns] of edges) {
      let sharp = ns.length !== 2;
      if (!sharp) { const [m, n] = ns; sharp = m[0] * n[0] + m[1] * n[1] + m[2] * n[2] < cos; }
      if (!sharp) continue;
      const [p, q] = ek.split('_').map(Number);
      out.push(pts[p * 3], pts[p * 3 + 1], pts[p * 3 + 2], pts[q * 3], pts[q * 3 + 1], pts[q * 3 + 2]);
    }
    return new Float32Array(out);
  }
  function normal(a, o) {
    const ux = a[o + 3] - a[o], uy = a[o + 4] - a[o + 1], uz = a[o + 5] - a[o + 2];
    const vx = a[o + 6] - a[o], vy = a[o + 7] - a[o + 1], vz = a[o + 8] - a[o + 2];
    const n = [uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx];
    const l = Math.hypot(n[0], n[1], n[2]) || 1;
    return [n[0] / l, n[1] / l, n[2] / l];
  }
  // offene / mehrfach benutzte Kanten zählen (Druckbarkeit)
  function manifold(a) {
    const key = (i) => `${Math.round(a[i] * 1e3)},${Math.round(a[i + 1] * 1e3)},${Math.round(a[i + 2] * 1e3)}`;
    const edges = new Map();
    for (let o = 0; o < a.length; o += 9) {
      const v = [key(o), key(o + 3), key(o + 6)];
      for (let k = 0; k < 3; k += 1) { const p = v[k], q = v[(k + 1) % 3]; if (p === q) continue; const ek = p < q ? `${p}|${q}` : `${q}|${p}`; edges.set(ek, (edges.get(ek) || 0) + 1); }
    }
    let open = 0, multi = 0;
    for (const c of edges.values()) { if (c === 1) open += 1; else if (c > 2) multi += 1; }
    return { edges: edges.size, open, multi };
  }

  /* -------------------------------------------------------------- Matrizen */
  const M = {
    ident: () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]),
    mul(a, b) {
      const r = new Float32Array(16);
      for (let c = 0; c < 4; c += 1) for (let rr = 0; rr < 4; rr += 1) r[c * 4 + rr] = a[rr] * b[c * 4] + a[4 + rr] * b[c * 4 + 1] + a[8 + rr] * b[c * 4 + 2] + a[12 + rr] * b[c * 4 + 3];
      return r;
    },
    persp(fov, asp, n, f) { const t = 1 / Math.tan(fov / 2); const r = new Float32Array(16); r[0] = t / asp; r[5] = t; r[10] = (f + n) / (n - f); r[11] = -1; r[14] = (2 * f * n) / (n - f); return r; },
    ortho(h, asp, n, f) { const r = M.ident(); r[0] = 1 / (h * asp); r[5] = 1 / h; r[10] = -2 / (f - n); r[14] = -(f + n) / (f - n); return r; },
    look(e, t, up) {
      let z = [e[0] - t[0], e[1] - t[1], e[2] - t[2]]; z = nrm(z);
      let x = nrm(cross(up, z)); if (!isFinite(x[0])) x = [1, 0, 0];
      const y = cross(z, x);
      return new Float32Array([x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -dot(x, e), -dot(y, e), -dot(z, e), 1]);
    },
    // Rotation (Grad) als Rz·Ry·Rx
    rot(rx, ry, rz) {
      const [a, b, c] = [rx, ry, rz].map((d) => (d * Math.PI) / 180);
      const ca = Math.cos(a), sa = Math.sin(a), cb = Math.cos(b), sb = Math.sin(b), cc = Math.cos(c), sc = Math.sin(c);
      return [[cc * cb, cc * sb * sa - sc * ca, cc * sb * ca + sc * sa], [sc * cb, sc * sb * sa + cc * ca, sc * sb * ca - cc * sa], [-sb, cb * sa, cb * ca]];
    },
    euler(R) {
      const sy = -R[2][0];
      if (Math.abs(sy) > 0.99999) { const ry = Math.sign(sy) * 90; return [((Math.atan2(-R[1][2], R[1][1]) * 180) / Math.PI), ry, 0]; }
      return [(Math.atan2(R[2][1], R[2][2]) * 180) / Math.PI, (Math.asin(sy) * 180) / Math.PI, (Math.atan2(R[1][0], R[0][0]) * 180) / Math.PI];
    },
    m3mul: (A, B) => A.map((row) => [0, 1, 2].map((j) => row[0] * B[0][j] + row[1] * B[1][j] + row[2] * B[2][j])),
    axisRot(axis, deg) {
      const t = (deg * Math.PI) / 180, c = Math.cos(t), s = Math.sin(t);
      if (axis === 0) return [[1, 0, 0], [0, c, -s], [0, s, c]];
      if (axis === 1) return [[c, 0, s], [0, 1, 0], [-s, 0, c]];
      return [[c, -s, 0], [s, c, 0], [0, 0, 1]];
    },
    // Objektmatrix T·R·S
    trs(p, r, s) {
      const R = M.rot(r[0], r[1], r[2]);
      return new Float32Array([R[0][0] * s[0], R[1][0] * s[0], R[2][0] * s[0], 0, R[0][1] * s[1], R[1][1] * s[1], R[2][1] * s[1], 0, R[0][2] * s[2], R[1][2] * s[2], R[2][2] * s[2], 0, p[0], p[1], p[2], 1]);
    },
    inv(m) {
      const [a00, a01, a02, a03, a10, a11, a12, a13, a20, a21, a22, a23, a30, a31, a32, a33] = m;
      const b00 = a00 * a11 - a01 * a10, b01 = a00 * a12 - a02 * a10, b02 = a00 * a13 - a03 * a10, b03 = a01 * a12 - a02 * a11;
      const b04 = a01 * a13 - a03 * a11, b05 = a02 * a13 - a03 * a12, b06 = a20 * a31 - a21 * a30, b07 = a20 * a32 - a22 * a30;
      const b08 = a20 * a33 - a23 * a30, b09 = a21 * a32 - a22 * a31, b10 = a21 * a33 - a23 * a31, b11 = a22 * a33 - a23 * a32;
      let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
      if (!det) return M.ident();
      det = 1 / det;
      return new Float32Array([
        (a11 * b11 - a12 * b10 + a13 * b09) * det, (a02 * b10 - a01 * b11 - a03 * b09) * det, (a31 * b05 - a32 * b04 + a33 * b03) * det, (a22 * b04 - a21 * b05 - a23 * b03) * det,
        (a12 * b08 - a10 * b11 - a13 * b07) * det, (a00 * b11 - a02 * b08 + a03 * b07) * det, (a32 * b02 - a30 * b05 - a33 * b01) * det, (a20 * b05 - a22 * b02 + a23 * b01) * det,
        (a10 * b10 - a11 * b08 + a13 * b06) * det, (a01 * b08 - a00 * b10 - a03 * b06) * det, (a30 * b04 - a31 * b02 + a33 * b00) * det, (a21 * b02 - a20 * b04 - a23 * b00) * det,
        (a11 * b07 - a10 * b09 - a12 * b06) * det, (a00 * b09 - a01 * b07 + a02 * b06) * det, (a31 * b01 - a30 * b03 - a32 * b00) * det, (a20 * b03 - a21 * b01 + a22 * b00) * det,
      ]);
    },
    pt: (m, p) => { const w = m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15] || 1; return [(m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12]) / w, (m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13]) / w, (m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]) / w]; },
    dir: (m, p) => [m[0] * p[0] + m[4] * p[1] + m[8] * p[2], m[1] * p[0] + m[5] * p[1] + m[9] * p[2], m[2] * p[0] + m[6] * p[1] + m[10] * p[2]],
    det3: (m) => m[0] * (m[5] * m[10] - m[9] * m[6]) - m[4] * (m[1] * m[10] - m[9] * m[2]) + m[8] * (m[1] * m[6] - m[5] * m[2]),
  };
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function nrm(a) { const l = Math.hypot(a[0], a[1], a[2]); return [a[0] / l, a[1] / l, a[2] / l]; }

  // Netz mit Matrix in Weltkoordinaten (Spiegelung dreht die Reihenfolge, damit Normalen aussen bleiben)
  function transform(a, m) {
    const r = new Float32Array(a.length); const flip = M.det3(m) < 0;
    for (let i = 0; i < a.length; i += 9) for (let k = 0; k < 3; k += 1) {
      const s = i + k * 3, d = i + (flip ? (k === 0 ? 0 : 3 - k) : k) * 3;
      const x = a[s], y = a[s + 1], z = a[s + 2];
      r[d] = m[0] * x + m[4] * y + m[8] * z + m[12]; r[d + 1] = m[1] * x + m[5] * y + m[9] * z + m[13]; r[d + 2] = m[2] * x + m[6] * y + m[10] * z + m[14];
    }
    return r;
  }
  function merge(list) {
    const n = list.reduce((s, a) => s + a.length, 0); const r = new Float32Array(n); let o = 0;
    for (const a of list) { r.set(a, o); o += a.length; }
    return r;
  }
  // Strahl–Dreieck (Möller–Trumbore), liefert kleinstes t > 0 oder Infinity
  function raycast(a, o, d) {
    let best = Infinity;
    for (let i = 0; i < a.length; i += 9) {
      const e1x = a[i + 3] - a[i], e1y = a[i + 4] - a[i + 1], e1z = a[i + 5] - a[i + 2];
      const e2x = a[i + 6] - a[i], e2y = a[i + 7] - a[i + 1], e2z = a[i + 8] - a[i + 2];
      const px = d[1] * e2z - d[2] * e2y, py = d[2] * e2x - d[0] * e2z, pz = d[0] * e2y - d[1] * e2x;
      const det = e1x * px + e1y * py + e1z * pz; if (Math.abs(det) < 1e-12) continue;
      const inv = 1 / det; const tx = o[0] - a[i], ty = o[1] - a[i + 1], tz = o[2] - a[i + 2];
      const u = (tx * px + ty * py + tz * pz) * inv; if (u < 0 || u > 1) continue;
      const qx = ty * e1z - tz * e1y, qy = tz * e1x - tx * e1z, qz = tx * e1y - ty * e1x;
      const v = (d[0] * qx + d[1] * qy + d[2] * qz) * inv; if (v < 0 || u + v > 1) continue;
      const t = (e2x * qx + e2y * qy + e2z * qz) * inv; if (t > 1e-6 && t < best) best = t;
    }
    return best;
  }

  /* ------------------------------------------------------- CSG (BSP-Baum) */
  // Nach dem bekannten csg.js-Verfahren (Evan Wallace), iterativ für tiefe Bäume.
  const EPS = 1e-5;
  class Plane {
    constructor(n, w) { this.n = n; this.w = w; }
    static from(a, b, c) { const n = nrm(cross([b[0] - a[0], b[1] - a[1], b[2] - a[2]], [c[0] - a[0], c[1] - a[1], c[2] - a[2]])); return new Plane(n, dot(n, a)); }
    clone() { return new Plane(this.n.slice(), this.w); }
    flip() { this.n = [-this.n[0], -this.n[1], -this.n[2]]; this.w = -this.w; }
    split(poly, cf, cb, f, b) {
      let type = 0; const types = [];
      for (const v of poly.v) { const t = dot(this.n, v) - this.w; const ty = t < -EPS ? 2 : t > EPS ? 1 : 0; type |= ty; types.push(ty); }
      if (type === 0) (dot(this.n, poly.p.n) > 0 ? cf : cb).push(poly);
      else if (type === 1) f.push(poly);
      else if (type === 2) b.push(poly);
      else {
        const fv = [], bv = []; const n = poly.v.length;
        for (let i = 0; i < n; i += 1) {
          const j = (i + 1) % n; const ti = types[i], tj = types[j], vi = poly.v[i], vj = poly.v[j];
          if (ti !== 2) fv.push(vi);
          if (ti !== 1) bv.push(ti !== 2 ? vi.slice() : vi);
          if ((ti | tj) === 3) {
            const t = (this.w - dot(this.n, vi)) / dot(this.n, [vj[0] - vi[0], vj[1] - vi[1], vj[2] - vi[2]]);
            const v = [vi[0] + (vj[0] - vi[0]) * t, vi[1] + (vj[1] - vi[1]) * t, vi[2] + (vj[2] - vi[2]) * t];
            fv.push(v); bv.push(v.slice());
          }
        }
        if (fv.length >= 3) f.push({ v: fv, p: poly.p });
        if (bv.length >= 3) b.push({ v: bv, p: poly.p });
      }
    }
  }
  const flipPoly = (p) => { p.v.reverse(); p.p = p.p.clone(); p.p.flip(); };
  class Node {
    constructor(polys) { this.plane = null; this.front = null; this.back = null; this.polys = []; if (polys) this.build(polys); }
    nodes() { const out = []; const st = [this]; while (st.length) { const n = st.pop(); out.push(n); if (n.front) st.push(n.front); if (n.back) st.push(n.back); } return out; }
    invert() {
      for (const n of this.nodes()) { for (const p of n.polys) flipPoly(p); n.plane.flip(); const t = n.front; n.front = n.back; n.back = t; }
    }
    clipPolygons(polys) {
      const out = []; const st = [[this, polys]];
      while (st.length) {
        const [n, ps] = st.pop();
        if (!n.plane) { out.push(...ps); continue; }
        let f = [], b = [];
        for (const p of ps) n.plane.split(p, f, b, f, b);
        if (n.front) st.push([n.front, f]); else for (const p of f) out.push(p);
        if (n.back) st.push([n.back, b]);
      }
      return out;
    }
    clipTo(bsp) { for (const n of this.nodes()) n.polys = bsp.clipPolygons(n.polys); }
    all() { const out = []; for (const n of this.nodes()) for (const p of n.polys) out.push(p); return out; }
    build(polys) {
      const st = [[this, polys]];
      while (st.length) {
        const [n, ps] = st.pop(); if (!ps.length) continue;
        if (!n.plane) n.plane = ps[0].p.clone();
        const f = [], b = [];
        for (const p of ps) n.plane.split(p, n.polys, n.polys, f, b);
        if (f.length) { n.front = n.front || new Node(); st.push([n.front, f]); }
        if (b.length) { n.back = n.back || new Node(); st.push([n.back, b]); }
      }
    }
  }
  function toPolys(a) {
    const out = [];
    for (let i = 0; i < a.length; i += 9) {
      const v = [[a[i], a[i + 1], a[i + 2]], [a[i + 3], a[i + 4], a[i + 5]], [a[i + 6], a[i + 7], a[i + 8]]];
      const p = Plane.from(v[0], v[1], v[2]); if (!isFinite(p.n[0])) continue;
      out.push({ v, p });
    }
    return out;
  }
  function fromPolys(polys) {
    const out = [];
    for (const p of polys) for (let i = 1; i < p.v.length - 1; i += 1) out.push(...p.v[0], ...p.v[i], ...p.v[i + 1]);
    return new Float32Array(out);
  }
  function csg(op, A, B) {
    const a = new Node(toPolys(A)), b = new Node(toPolys(B));
    if (op === 'union') { a.clipTo(b); b.clipTo(a); b.invert(); b.clipTo(a); b.invert(); a.build(b.all()); }
    else if (op === 'subtract') { a.invert(); a.clipTo(b); b.clipTo(a); b.invert(); b.clipTo(a); b.invert(); a.build(b.all()); a.invert(); }
    else { a.invert(); b.clipTo(a); b.invert(); a.clipTo(b); b.clipTo(a); a.build(b.all()); a.invert(); }
    return fixTJunctions(fromPolys(a.all()));
  }
  // BSP-Schnitte hinterlassen T-Kreuzungen (Punkt mitten auf der Kante des Nachbarn).
  // Solche Kanten werden am Punkt geteilt, damit das Netz wasserdicht bleibt.
  function fixTJunctions(a) {
    const ids = new Map(); const P = [];
    const id = (i) => { const k = `${Math.round(a[i] * 1e4)},${Math.round(a[i + 1] * 1e4)},${Math.round(a[i + 2] * 1e4)}`; let v = ids.get(k); if (v === undefined) { v = P.length; ids.set(k, v); P.push([a[i], a[i + 1], a[i + 2]]); } return v; };
    let tris = [];
    for (let i = 0; i < a.length; i += 9) { const t = [id(i), id(i + 3), id(i + 6)]; if (t[0] !== t[1] && t[1] !== t[2] && t[0] !== t[2]) tris.push(t); }
    for (let pass = 0; pass < 8; pass += 1) {
      const count = new Map();
      for (const t of tris) for (let k = 0; k < 3; k += 1) { const p = t[k], q = t[(k + 1) % 3]; const ek = p < q ? p * 4194304 + q : q * 4194304 + p; count.set(ek, (count.get(ek) || 0) + 1); }
      const open = []; const verts = new Set();
      tris.forEach((t, ti) => { for (let k = 0; k < 3; k += 1) { const p = t[k], q = t[(k + 1) % 3]; const ek = p < q ? p * 4194304 + q : q * 4194304 + p; if (count.get(ek) === 1) { open.push([ti, k]); verts.add(p); verts.add(q); } } });
      if (!open.length || open.length > 60000) break;
      const vl = [...verts]; const done = new Set(); const out = []; let changed = false;
      for (const [ti, k] of open) {
        if (done.has(ti)) continue;
        const t = tris[ti]; const p = t[k], q = t[(k + 1) % 3], r = t[(k + 2) % 3];
        const A = P[p], B = P[q]; const d = [B[0] - A[0], B[1] - A[1], B[2] - A[2]]; const L2 = dot(d, d); if (L2 < 1e-12) continue;
        const mn = [0, 1, 2].map((j) => Math.min(A[j], B[j]) - 1e-3), mx = [0, 1, 2].map((j) => Math.max(A[j], B[j]) + 1e-3);
        const on = [];
        for (const v of vl) {
          if (v === p || v === q) continue; const V = P[v];
          if (V[0] < mn[0] || V[0] > mx[0] || V[1] < mn[1] || V[1] > mx[1] || V[2] < mn[2] || V[2] > mx[2]) continue;
          const w = [V[0] - A[0], V[1] - A[1], V[2] - A[2]]; const s = dot(w, d) / L2; if (s <= 1e-6 || s >= 1 - 1e-6) continue;
          const e = [w[0] - d[0] * s, w[1] - d[1] * s, w[2] - d[2] * s]; if (dot(e, e) > 1e-6) continue;
          on.push([s, v]);
        }
        if (!on.length) continue;
        on.sort((m, n) => m[0] - n[0]);
        const chain = [p, ...on.map((o) => o[1]), q];
        for (let i = 0; i < chain.length - 1; i += 1) out.push([chain[i], chain[i + 1], r]);
        done.add(ti); changed = true;
      }
      if (!changed) break;
      tris = tris.filter((_, i) => !done.has(i)).concat(out);
    }
    const r = new Float32Array(tris.length * 9);
    tris.forEach((t, i) => { for (let k = 0; k < 3; k += 1) r.set(P[t[k]], i * 9 + k * 3); });
    return r;
  }

  /* --------------------------------------------------------------- Dateien */
  function toSTL(a, name = 'Revolution Hub 3D-Modell') {
    const n = a.length / 9; const buf = new ArrayBuffer(84 + n * 50); const dv = new DataView(buf);
    const head = new TextEncoder().encode(name.slice(0, 79));
    new Uint8Array(buf, 0, 80).set(head);
    dv.setUint32(80, n, true);
    let o = 84;
    for (let i = 0; i < a.length; i += 9) {
      const nn = normal(a, i);
      for (let k = 0; k < 3; k += 1) dv.setFloat32(o + k * 4, isFinite(nn[k]) ? nn[k] : 0, true);
      for (let k = 0; k < 9; k += 1) dv.setFloat32(o + 12 + k * 4, a[i + k], true);
      o += 50;
    }
    return new Uint8Array(buf);
  }
  function parseSTL(bytes) {
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    if (u8.length >= 84) {
      const n = dv.getUint32(80, true);
      if (84 + n * 50 === u8.length) {
        const r = new Float32Array(n * 9);
        for (let t = 0; t < n; t += 1) for (let k = 0; k < 9; k += 1) r[t * 9 + k] = dv.getFloat32(84 + t * 50 + 12 + k * 4, true);
        return r;
      }
    }
    const txt = new TextDecoder().decode(u8);
    const vs = [...txt.matchAll(/vertex\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)/g)].map((m) => [+m[1], +m[2], +m[3]]);
    if (!vs.length) throw new Error('Keine gültige STL-Datei.');
    return new Float32Array(vs.slice(0, vs.length - (vs.length % 3)).flat());
  }
  function indexed(a) {
    const map = new Map(); const v = []; const f = [];
    for (let i = 0; i < a.length; i += 3) {
      const k = `${a[i].toFixed(4)},${a[i + 1].toFixed(4)},${a[i + 2].toFixed(4)}`;
      let id = map.get(k); if (id === undefined) { id = v.length / 3; map.set(k, id); v.push(a[i], a[i + 1], a[i + 2]); }
      f.push(id);
    }
    const faces = [];
    for (let i = 0; i < f.length; i += 3) if (f[i] !== f[i + 1] && f[i + 1] !== f[i + 2] && f[i] !== f[i + 2]) faces.push(f[i], f[i + 1], f[i + 2]);
    return { v, f: faces };
  }
  function toOBJ(parts) {
    let out = '# Revolution Hub 3D-Modell (Einheit: mm)\n'; let base = 1;
    for (const { name, mesh } of parts) {
      const { v, f } = indexed(mesh);
      out += `o ${String(name).replace(/\s+/g, '_')}\n`;
      for (let i = 0; i < v.length; i += 3) out += `v ${+v[i].toFixed(4)} ${+v[i + 1].toFixed(4)} ${+v[i + 2].toFixed(4)}\n`;
      for (let i = 0; i < f.length; i += 3) out += `f ${f[i] + base} ${f[i + 1] + base} ${f[i + 2] + base}\n`;
      base += v.length / 3;
    }
    return out;
  }
  function parseOBJ(text) {
    const v = []; const out = [];
    for (const line of text.split(/\r?\n/)) {
      const s = line.trim().split(/\s+/);
      if (s[0] === 'v') v.push([+s[1], +s[2], +s[3]]);
      else if (s[0] === 'f') {
        const idx = s.slice(1).map((t) => { const i = parseInt(t, 10); return i < 0 ? v.length + i : i - 1; });
        for (let i = 1; i < idx.length - 1; i += 1) { const a = v[idx[0]], b = v[idx[i]], c = v[idx[i + 1]]; if (a && b && c) out.push(...a, ...b, ...c); }
      }
    }
    if (!out.length) throw new Error('Keine Flächen in der OBJ-Datei gefunden.');
    return new Float32Array(out);
  }
  function to3MF(parts) {
    const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
    let objs = ''; let items = '';
    parts.forEach(({ name, mesh }, i) => {
      const { v, f } = indexed(mesh); const id = i + 1;
      let vs = ''; for (let k = 0; k < v.length; k += 3) vs += `<vertex x="${+v[k].toFixed(4)}" y="${+v[k + 1].toFixed(4)}" z="${+v[k + 2].toFixed(4)}"/>`;
      let ts = ''; for (let k = 0; k < f.length; k += 3) ts += `<triangle v1="${f[k]}" v2="${f[k + 1]}" v3="${f[k + 2]}"/>`;
      objs += `<object id="${id}" name="${esc(name)}" type="model"><mesh><vertices>${vs}</vertices><triangles>${ts}</triangles></mesh></object>`;
      items += `<item objectid="${id}"/>`;
    });
    return {
      '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>',
      '_rels/.rels': '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>',
      '3D/3dmodel.model': `<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="de-CH" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><metadata name="Application">Revolution Hub 3D-Modell</metadata><resources>${objs}</resources><build>${items}</build></model>`,
    };
  }
  function parse3MF(xml) {
    const out = [];
    for (const m of xml.matchAll(/<(?:\w+:)?mesh>([\s\S]*?)<\/(?:\w+:)?mesh>/g)) {
      const v = [...m[1].matchAll(/<(?:\w+:)?vertex\s+x="([^"]+)"\s+y="([^"]+)"\s+z="([^"]+)"/g)].map((x) => [+x[1], +x[2], +x[3]]);
      for (const t of m[1].matchAll(/<(?:\w+:)?triangle\s+v1="(\d+)"\s+v2="(\d+)"\s+v3="(\d+)"/g)) { const a = v[+t[1]], b = v[+t[2]], c = v[+t[3]]; if (a && b && c) out.push(...a, ...b, ...c); }
    }
    if (!out.length) throw new Error('Keine Netze in der 3MF-Datei gefunden.');
    return new Float32Array(out);
  }
  const b64 = {
    enc(arr) { const u8 = new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength); let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); },
    dec(s) { const bin = atob(s); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i += 1) u8[i] = bin.charCodeAt(i); return new Float32Array(u8.buffer); },
  };

  window.M3G = { SHAPES, FONTS, M, bbox, center, volume, featureEdges, manifold, transform, merge, raycast, csg, toSTL, parseSTL, toOBJ, parseOBJ, to3MF, parse3MF, b64, cross, dot, nrm };
})();
