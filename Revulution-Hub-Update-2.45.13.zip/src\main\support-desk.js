'use strict';

/*
 * Runde 11c – Support-Chat und Moderation (Firebase-Projekt der Hub-Konten, REST):
 *   tickets/{id}            – Anliegen: { kind, subject, text, uid, by, email, img, status, at, lastAt, lastBy }
 *   tickets/{id}/msgs/{mid} – Verlauf: { from: 'user' | 'admin', uid, by, text, at }
 *   revhub_mod/{uid}        – Sperre/Timeout: { blocked, until (ms), reason, name, by, at }
 * Gesperrte Konten (blocked) und Konten im Timeout (until > jetzt) dürfen keine Tickets,
 * Antworten, Meldungen oder Chat-Nachrichten senden – serverseitig über die Firestore-Regeln
 * (rulesFor in cloud-backgrounds.js), zusätzlich hier im Client mit klarer Meldung.
 */
const KINDS = ['bug', 'problem', 'account', 'store', 'feedback', 'idea', 'wallpaper', 'other'];
const STATUS = ['open', 'doing', 'done'];
const clean = (v, max = 60) => String(v ?? '').replace(/[\u0000-\u0008\u000b-\u001f]/g, ' ').trim().slice(0, max);
const isRules = (e) => /PERMISSION|denied|403|insufficient/i.test(String(e?.message || e?.code || e));

function checkImage(dataUrl) {
  const img = String(dataUrl || '');
  if (!img) return '';
  if (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(img)) throw new Error('Ungültiges Bild.');
  if (img.length > 950 * 1024) throw new Error('Das Bild ist zu gross (max. ~900 KB).');
  return img;
}

/** Lesbarer Text für eine Sperre/einen Timeout. */
function modText(m) {
  if (!m) return '';
  if (m.blocked) return `Dein Konto ist gesperrt${m.reason ? ` (${m.reason})` : ''}. Du kannst keine Tickets, Meldungen oder Chat-Nachrichten senden.`;
  if (m.until > Date.now()) {
    const d = new Date(m.until);
    const when = d.toLocaleString('de-CH', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    return `Du bist bis ${when} im Timeout${m.reason ? ` (${m.reason})` : ''}. Bis dahin kannst du keine Tickets, Meldungen oder Chat-Nachrichten senden.`;
  }
  return '';
}
const modActive = (m) => Boolean(m && (m.blocked || Number(m.until) > Date.now()));

function ticketOut(d) {
  return {
    id: d.id, kind: KINDS.includes(d.kind) ? d.kind : 'other', subject: clean(d.subject, 80), text: String(d.text || ''), email: clean(d.email, 80),
    ref: clean(d.ref, 80), refName: clean(d.refName, 80), version: clean(d.version, 20), uid: clean(d.uid, 64), by: clean(d.by, 40), img: String(d.img || ''),
    status: STATUS.includes(d.status) ? d.status : 'open', at: Number(d.at) || 0, lastAt: Number(d.lastAt) || Number(d.at) || 0, lastBy: d.lastBy === 'admin' ? 'admin' : 'user',
  };
}
const msgOut = (d) => ({ id: d.id, from: d.from === 'admin' ? 'admin' : 'user', by: clean(d.by, 40), text: String(d.text || ''), at: Number(d.at) || 0 });

class SupportDesk {
  /** @param {{ fb: object, token: () => Promise<string>, uid: () => string, name: () => string }} o */
  constructor(o) {
    this.fb = o.fb;
    this.token = o.token || (async () => '');
    this.uid = o.uid || (() => '');
    this.name = o.name || (() => 'Nutzer');
    this.mod = null;
    this.modAt = 0;
    this.modUid = '';
  }

  /* ---------------------------------------------------------------- Nutzer-Seite */
  /** Eigener Sperr-Status (gecacht 60 s). Ohne Konto oder ohne Regeln: frei. */
  async modState(force = false) {
    const uid = this.uid();
    if (!uid) return { signedIn: false, active: false, blocked: false, until: 0, reason: '', text: '' };
    if (force || this.modUid !== uid || Date.now() - this.modAt > 60000) {
      try {
        const d = await this.fb.getDoc(`revhub_mod/${uid}`, await this.token());
        this.mod = d ? { blocked: d.blocked === true, until: Number(d.until) || 0, reason: clean(d.reason, 80) } : null;
      } catch {
        this.mod = null; // Regeln fehlen oder offline – dann entscheidet der Server
      }
      this.modAt = Date.now();
      this.modUid = uid;
    }
    const m = this.mod;
    return { signedIn: true, active: modActive(m), blocked: Boolean(m?.blocked), until: Number(m?.until) || 0, reason: m?.reason || '', text: modText(m) };
  }

  /** Wirft eine klare Meldung, wenn das Konto gesperrt ist oder im Timeout. */
  async guard() {
    const s = await this.modState();
    if (s.active) {
      const e = new Error(s.text);
      e.code = 'MODERATED';
      throw e;
    }
    return true;
  }

  /** Fehler vom Server in Klartext (Regeln verweigern meist wegen Sperre). */
  async explain(error) {
    if (!isRules(error)) return error;
    const s = await this.modState(true).catch(() => null);
    if (s?.active) return new Error(s.text);
    return new Error('Der Server hat das abgelehnt. Bist du angemeldet? Falls ja, sind die Datenbank-Regeln noch nicht aktuell.');
  }

  async create(r = {}) {
    await this.guard();
    const uid = this.uid();
    const kind = KINDS.includes(r.kind) ? r.kind : 'other';
    if (kind === 'wallpaper' && !uid) throw new Error('Zum Melden eines Hintergrunds musst du mit deinem Revulution-Konto angemeldet sein.');
    const text = clean(r.text, 3000);
    if (text.length < 3) throw new Error('Schreib bitte kurz, worum es geht.');
    const now = Date.now();
    const data = {
      kind, subject: clean(r.subject, 80), text, email: clean(r.email, 80), ref: clean(r.ref, 80), refName: clean(r.refName, 80),
      version: clean(r.version, 20), uid: uid || '', by: clean(this.name(), 40) || 'Gast', img: checkImage(r.img), status: 'open', at: now, lastAt: now, lastBy: 'user',
    };
    const token = uid ? await this.token().catch(() => '') : '';
    try {
      const id = await this.fb.addDoc('tickets', data, token || undefined);
      return { id, ticket: ticketOut({ id, ...data }) };
    } catch (error) {
      throw await this.explain(error);
    }
  }

  /** Eigene Tickets (nur mit Konto). */
  async mine() {
    const uid = this.uid();
    if (!uid) return { signedIn: false, list: [] };
    try {
      const docs = await this.fb.query('tickets', 'uid', uid, await this.token(), 100);
      return { signedIn: true, list: docs.map(ticketOut).sort((a, b) => b.lastAt - a.lastAt) };
    } catch (error) {
      return { signedIn: true, list: [], error: isRules(error) ? 'rules' : 'offline' };
    }
  }

  async thread(id) {
    const tid = clean(id, 64);
    const token = await this.token();
    const t = await this.fb.getDoc(`tickets/${tid}`, token);
    if (!t) throw new Error('Ticket nicht gefunden.');
    const msgs = await this.fb.list(`tickets/${tid}/msgs`, token, 300).catch(() => []);
    return { ticket: ticketOut(t), msgs: msgs.map(msgOut).sort((a, b) => a.at - b.at) };
  }

  async reply(id, text) {
    await this.guard();
    const tid = clean(id, 64);
    const body = clean(text, 3000);
    if (body.length < 1) throw new Error('Die Nachricht ist leer.');
    const uid = this.uid();
    if (!uid) throw new Error('Zum Antworten im Chat musst du angemeldet sein.');
    const token = await this.token();
    const now = Date.now();
    try {
      await this.fb.addDoc(`tickets/${tid}/msgs`, { from: 'user', uid, by: clean(this.name(), 40) || 'Nutzer', text: body, at: now }, token);
      await this.fb.updateDoc(`tickets/${tid}`, { lastAt: now, lastBy: 'user', status: 'open' }, token).catch(() => {});
    } catch (error) {
      throw await this.explain(error);
    }
    return this.thread(tid);
  }

  /* ---------------------------------------------------------------- Admin-Seite (Token des Admin-Kontos) */
  async adminTickets(token) {
    const docs = await this.fb.list('tickets', token, 2000);
    return docs.map(ticketOut).sort((a, b) => b.lastAt - a.lastAt);
  }
  async adminThread(id, token) {
    const tid = clean(id, 64);
    const t = await this.fb.getDoc(`tickets/${tid}`, token);
    if (!t) throw new Error('Ticket nicht gefunden.');
    const msgs = await this.fb.list(`tickets/${tid}/msgs`, token, 500);
    return { ticket: ticketOut(t), msgs: msgs.map(msgOut).sort((a, b) => a.at - b.at) };
  }
  async adminReply(id, text, token, adminUid) {
    const tid = clean(id, 64);
    const body = clean(text, 3000);
    if (!body) throw new Error('Die Antwort ist leer.');
    const now = Date.now();
    await this.fb.addDoc(`tickets/${tid}/msgs`, { from: 'admin', uid: clean(adminUid, 64), by: 'Revulution Support', text: body, at: now }, token);
    await this.fb.updateDoc(`tickets/${tid}`, { lastAt: now, lastBy: 'admin', status: 'doing' }, token);
    return this.adminThread(tid, token);
  }
  async adminStatus(id, status, token) {
    await this.fb.updateDoc(`tickets/${clean(id, 64)}`, { status: STATUS.includes(status) ? status : 'open' }, token);
    return true;
  }
  /** Ticket samt Verlauf löschen. */
  async adminDelete(ids, token) {
    let n = 0;
    for (const raw of [].concat(ids || []).slice(0, 500)) {
      const tid = clean(raw, 64);
      if (!tid) continue;
      const msgs = await this.fb.list(`tickets/${tid}/msgs`, token, 500).catch(() => []);
      for (const m of msgs) await this.fb.delDoc(`tickets/${tid}/msgs/${m.id}`, token).catch(() => {});
      await this.fb.delDoc(`tickets/${tid}`, token);
      n++;
    }
    return n;
  }

  /* Moderation */
  async mods(token) {
    const docs = await this.fb.list('revhub_mod', token, 1000);
    return docs.map((d) => ({ uid: d.id, blocked: d.blocked === true, until: Number(d.until) || 0, reason: clean(d.reason, 80), name: clean(d.name, 40), at: Number(d.at) || 0, active: modActive({ blocked: d.blocked === true, until: Number(d.until) || 0 }) })).sort((a, b) => b.at - a.at);
  }
  /** mode: 'block' | 'unblock' | Minuten als Zahl (Timeout). */
  async moderate({ uid, name, mode, reason }, token, adminUid) {
    const id = clean(uid, 64);
    if (!/^[A-Za-z0-9_-]{6,64}$/.test(id)) throw new Error('Ungültige Konto-ID.');
    if (id === adminUid) throw new Error('Das Admin-Konto kann nicht gesperrt werden.');
    if (mode === 'unblock') {
      await this.fb.delDoc(`revhub_mod/${id}`, token);
      return { uid: id, active: false };
    }
    const mins = Number(mode);
    const data = {
      blocked: mode === 'block', until: mode === 'block' ? 0 : Date.now() + Math.max(1, Math.min(60 * 24 * 365, mins || 60)) * 60000,
      reason: clean(reason, 80), name: clean(name, 40), by: clean(adminUid, 64), at: Date.now(),
    };
    await this.fb.setDoc(`revhub_mod/${id}`, data, token);
    return { uid: id, ...data, active: true };
  }
  /** Anzeigename → Konto-ID (über revhub_names). */
  async resolveName(name, token) {
    const key = String(name || '').trim().toLowerCase().replace(/\s+/g, '').replace(/[/.#$[\]]/g, '_').slice(0, 40);
    if (!key) return null;
    const d = await this.fb.getDoc(`revhub_names/${encodeURIComponent(key)}`, token).catch(() => null);
    return d?.uid ? { uid: String(d.uid), name: clean(d.name, 40) } : null;
  }
}

module.exports = { SupportDesk, modText, modActive, KINDS };
