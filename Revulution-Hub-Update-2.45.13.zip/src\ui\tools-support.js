'use strict';

/* Support (Runde 11c): echter Support-Chat. Thema wählen, der Hub schreibt einen kurzen Entwurf vor,
   man ergänzt ihn und sendet – daraus wird ein Ticket. Antworten vom Team erscheinen im selben Verlauf.
   Andere Seiten können vorausfüllen: window.revSupport({ kind, ref, refName, img, text }). */
(() => {
  const T = window.HubTools;
  if (!T?.register) return;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ctx = () => T.ctx();
  const PAGE = 'tool-support';
  const active = () => Boolean(document.querySelector(`[data-tool-page="${PAGE}"]`));
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
  const SVG = {
    bug: '<path d="M9 7a3 3 0 0 1 6 0"/><rect x="7" y="7" width="10" height="12" rx="5"/><path d="M12 11v8M3 13h4M17 13h4M4 7l3 2M20 7l-3 2M4 19l3-2M20 19l-3-2"/>',
    problem: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="m5.6 5.6 3.6 3.6M14.8 14.8l3.6 3.6M18.4 5.6l-3.6 3.6M9.2 14.8l-3.6 3.6"/>',
    account: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    store: '<circle cx="12" cy="12" r="9"/><path d="M14.8 9.2A3 3 0 0 0 12 8c-1.7 0-3 .9-3 2s1.3 1.7 3 2 3 .9 3 2-1.3 2-3 2a3 3 0 0 1-2.8-1.2M12 6v2M12 16v2"/>',
    feedback: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9.5h8M8 12.5h5"/>',
    idea: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
    wallpaper: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
    other: '<path d="M4 8h16v10H4z"/><path d="M4 8l2-4h12l2 4M10 12h4"/>',
    bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    cam: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    send: '<path d="M4 12 20 4l-6 16-3-7z"/><path d="m11 13 9-9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    head: '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="13" width="4" height="6" rx="2"/><rect x="17" y="13" width="4" height="6" rx="2"/><path d="M19 19a3 3 0 0 1-3 3h-3"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
  };
  const ico = (k, size = 22) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${SVG[k] || SVG.other}</svg>`;
  // [Schlüssel, Farbe, Name, vorgeschriebener Entwurf]
  const KINDS = [
    ['bug', '#ff5a6e', 'Fehler / Bug', 'Hallo Team\n\nMir ist ein Fehler aufgefallen.\nWo: \nWas passiert ist: \nWas ich erwartet hätte: '],
    ['problem', '#f59e0b', 'Ich komme nicht weiter', 'Hallo Team\n\nIch komme bei etwas nicht weiter.\nWorum es geht: \nDas habe ich schon versucht: '],
    ['account', '#34d399', 'Konto & Anmeldung', 'Hallo Team\n\nIch habe ein Problem mit meinem Konto.\nWas passiert: '],
    ['store', '#fbbf24', 'Coins & Käufe', 'Hallo Team\n\nEs geht um einen Kauf oder meine Coins.\nWann: \nWas fehlt oder stimmt nicht: '],
    ['feedback', '#38bdf8', 'Feedback', 'Hallo Team\n\nMein Feedback zum Hub: '],
    ['idea', '#facc15', 'Idee', 'Hallo Team\n\nIch hätte eine Idee für den Hub: \nDarum wäre das praktisch: '],
    ['wallpaper', '#a78bfa', 'Hintergrund melden', 'Hallo Team\n\nMit diesem Hintergrund stimmt etwas nicht.\nGrund: '],
    ['other', '#94a3b8', 'Etwas anderes', 'Hallo Team\n\n'],
  ];
  const KIND = Object.fromEntries(KINDS.map((k) => [k[0], { color: k[1], name: k[2], draft: k[3] }]));
  const STATUS = { open: 'Offen', doing: 'In Bearbeitung', done: 'Erledigt' };

  const st = {
    view: 'new', kind: '', draft: '', email: '', ref: '', refName: '', refImg: '', shot: '', withShot: false,
    busy: false, err: '', acct: null, mod: null, mine: null, mineErr: '', loading: false, thread: null, threadErr: '', reply: '', loadedAt: 0,
  };
  const local = () => {
    try {
      return JSON.parse(localStorage.getItem('rev-tickets') || '[]');
    } catch {
      return [];
    }
  };
  const seen = () => {
    try {
      return JSON.parse(localStorage.getItem('rev-sup-seen') || '{}');
    } catch {
      return {};
    }
  };
  const markSeen = (t) => {
    if (!t) return;
    const s = seen();
    s[t.id] = t.lastAt || Date.now();
    localStorage.setItem('rev-sup-seen', JSON.stringify(s));
  };
  const unread = (t) => t.lastBy === 'admin' && (seen()[t.id] || 0) < t.lastAt;
  const when = (at) => (at ? new Date(at).toLocaleString('de-CH', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '');
  const nr = (id) => `#${String(id || '').slice(0, 8).toUpperCase()}`;

  window.revSupport = (pre = {}) => {
    const kind = KIND[pre.kind] ? pre.kind : 'bug';
    Object.assign(st, { view: 'new', kind, ref: pre.ref || '', refName: pre.refName || '', refImg: pre.img || '', draft: pre.text || KIND[kind].draft, err: '' });
    window.hub.open(PAGE);
  };

  /* ---------------------------------------------------------------- Daten */
  async function refresh(full = true) {
    if (st.loading) return;
    st.loading = true;
    st.loadedAt = Date.now();
    try {
      st.acct = await window.hub.account.state().catch(() => ({ signedIn: false }));
      st.mod = st.acct?.signedIn ? await window.hub.support.mod().catch(() => null) : null;
      if (st.acct?.signedIn) {
        const r = await window.hub.support.mine().catch(() => ({ list: [], error: 'offline' }));
        st.mine = r.list || [];
        st.mineErr = r.error || '';
      } else {
        st.mine = [];
        st.mineErr = '';
      }
      if (st.view !== 'new' && st.acct?.signedIn && !String(st.view).startsWith('local:')) {
        st.thread = await window.hub.support.thread(st.view).catch((e) => ((st.threadErr = errText(e)), st.thread));
        if (st.thread) markSeen(st.thread.ticket);
      }
    } finally {
      st.loading = false;
    }
    if (!active()) return;
    if (full) ctx().render();
    else patch();
  }
  // Während die Seite offen ist, alle 20 s neue Antworten holen (ohne das Eingabefeld anzufassen)
  setInterval(() => {
    if (active() && document.visibilityState === 'visible' && st.acct?.signedIn) refresh(false);
  }, 20000);

  /* ---------------------------------------------------------------- Ansicht */
  const bubble = (who, text, at, extra = '') => `<div class="spc-msg ${who}"><div class="spc-b">${extra}${esc(text).replace(/\n/g, '<br>')}</div><small>${who === 'admin' ? 'Revulution Support · ' : who === 'bot' ? '' : ''}${when(at)}</small></div>`;

  function sideHtml() {
    const cloud = st.mine || [];
    const guest = !st.acct?.signedIn;
    const loc = guest ? local().slice(0, 12) : [];
    const rows = cloud.length
      ? cloud.map((t) => `<button class="spc-item ${st.view === t.id ? 'on' : ''} ${unread(t) ? 'new' : ''}" data-sup-open="${esc(t.id)}"><i style="--kc:${KIND[t.kind]?.color || '#94a3b8'}">${ico(t.kind, 15)}</i><span><b>${esc(t.subject || KIND[t.kind]?.name || 'Ticket')}</b><small>${esc(STATUS[t.status])} · ${when(t.lastAt)}</small></span>${unread(t) ? '<em>Neu</em>' : ''}</button>`).join('')
      : loc.map((t) => `<button class="spc-item ${st.view === `local:${t.id}` ? 'on' : ''}" data-sup-open="local:${esc(t.id)}"><i style="--kc:${KIND[t.kind]?.color || '#94a3b8'}">${ico(t.kind, 15)}</i><span><b>${esc(t.subject || 'Ticket')}</b><small>${nr(t.id)} · ${when(t.at)}</small></span></button>`).join('');
    return `<button class="spc-new ${st.view === 'new' ? 'on' : ''}" data-sup="new">${ico('plus', 16)}<span>Neues Anliegen</span></button>
      <div class="spc-list">${rows || '<p class="spc-empty">Noch keine Tickets.</p>'}</div>
      ${guest ? '<p class="spc-note">Ohne Konto gibt es Antworten nur per E-Mail. <a href="#" data-open="tool-account">Anmelden</a>, damit Antworten hier im Chat erscheinen.</p>' : st.mineErr === 'rules' ? '<p class="spc-note">Der Verlauf ist noch nicht freigeschaltet (Datenbank-Regeln). Tickets kommen trotzdem an.</p>' : ''}`;
  }

  function threadHtml() {
    const name = (st.acct?.email || '').split('@')[0];
    if (st.view === 'new') {
      const k = KIND[st.kind];
      return `${bubble('bot', `Hallo${name ? ` ${name}` : ''}! Worum geht es? Wähl unten ein Thema – ich schreibe dir einen kurzen Entwurf vor, den du anpassen und ergänzen kannst.`, 0)}
        ${k ? bubble('bot', `Alles klar: ${k.name}. Ergänz den Entwurf unten so genau wie möglich und drück auf Senden.`, 0) : ''}`;
    }
    if (String(st.view).startsWith('local:')) {
      const t = local().find((x) => `local:${x.id}` === st.view);
      if (!t) return '<p class="spc-empty">Ticket nicht gefunden.</p>';
      return `<div class="spc-sys">Ticket ${nr(t.id)} · ${esc(KIND[t.kind]?.name || '')} · ${when(t.at)}</div>${bubble('user', t.text || t.subject || '', t.at)}<div class="spc-sys">Antworten kommen per E-Mail, falls du eine angegeben hast. Mit Konto siehst du sie hier im Chat.</div>`;
    }
    const th = st.thread;
    if (!th || th.ticket.id !== st.view) return st.threadErr ? `<p class="spc-empty">${esc(st.threadErr)}</p>` : '<p class="spc-empty">Lädt …</p>';
    const t = th.ticket;
    const img = t.img ? `<img class="spc-img" src="${esc(t.img)}" alt="" />` : '';
    return `<div class="spc-sys">Ticket ${nr(t.id)} · ${esc(KIND[t.kind]?.name || '')} · erstellt ${when(t.at)}</div>
      ${t.refName ? `<div class="spc-sys">Betrifft: ${esc(t.refName)}</div>` : ''}
      ${bubble('user', t.text, t.at, img)}
      ${th.msgs.map((m) => bubble(m.from, m.text, m.at)).join('')}
      ${th.msgs.some((m) => m.from === 'admin') ? '' : '<div class="spc-sys">Dein Ticket ist beim Team. Die Antwort erscheint hier – meist innert 24 Stunden.</div>'}
      ${t.status === 'done' ? '<div class="spc-sys done">Dieses Ticket ist erledigt. Schreib einfach weiter, um es wieder zu öffnen.</div>' : ''}`;
  }

  function headHtml() {
    if (st.view === 'new') return `<span class="spc-av">${ico('head', 18)}</span><div><b>Revulution Support</b><small>Neues Anliegen</small></div>`;
    const t = st.thread?.ticket;
    if (!t || t.id !== st.view) return `<span class="spc-av">${ico('head', 18)}</span><div><b>Revulution Support</b><small>Ticket</small></div>`;
    return `<span class="spc-av">${ico('head', 18)}</span><div><b>${esc(t.subject || KIND[t.kind]?.name || 'Ticket')}</b><small>${nr(t.id)}</small></div><span class="spc-st ${t.status}">${esc(STATUS[t.status])}</span>`;
  }

  function composeHtml() {
    if (st.mod?.active) return `<div class="spc-blocked">${ico('lock', 18)}<span>${esc(st.mod.text)}</span></div>`;
    if (String(st.view).startsWith('local:')) return '';
    if (st.view !== 'new') {
      return `<div class="spc-compose">
        <textarea class="input spc-text" data-sup-f="reply" maxlength="3000" rows="2" placeholder="Antwort schreiben … (Strg+Enter sendet)">${esc(st.reply)}</textarea>
        ${st.err ? `<p class="err">${esc(st.err)}</p>` : ''}
        <div class="spc-row"><span class="spc-hint">Strg+Enter sendet</span><button class="btn primary spc-send" data-sup="reply" ${st.busy ? 'disabled' : ''}>${ico('send', 16)}<span>${st.busy ? 'Wird gesendet …' : 'Senden'}</span></button></div></div>`;
    }
    const k = KIND[st.kind];
    const chips = `<div class="spc-chips">${KINDS.map(([id, c, n]) => `<button class="spc-chip ${st.kind === id ? 'on' : ''}" style="--kc:${c}" data-sup-kind="${id}">${ico(id, 15)}<span>${esc(n)}</span></button>`).join('')}</div>`;
    if (!k) return `<div class="spc-compose">${chips}</div>`;
    const guest = !st.acct?.signedIn;
    const needAcct = st.kind === 'wallpaper' && guest;
    return `<div class="spc-compose">${chips}
      ${st.ref ? `<div class="spc-ref">${st.refImg ? `<img src="${esc(st.refImg)}" alt="" />` : ''}<div><small>Betrifft</small><b>${esc(st.refName || st.ref)}</b></div><button class="spc-x" data-sup="unref" title="Entfernen">${ico('x', 14)}</button></div>` : ''}
      <textarea class="input spc-text" data-sup-f="draft" maxlength="3000" rows="5" placeholder="Beschreib dein Anliegen …">${esc(st.draft)}</textarea>
      ${guest ? `<input class="input spc-mail" data-sup-f="email" maxlength="80" placeholder="E-Mail für eine Antwort (ohne Konto)" value="${esc(st.email)}" />` : ''}
      ${needAcct ? '<p class="err">Zum Melden eines Hintergrunds musst du angemeldet sein. <a href="#" data-open="tool-account">Jetzt anmelden</a></p>' : ''}
      ${st.err ? `<p class="err">${esc(st.err)}</p>` : ''}
      <div class="spc-row"><button class="switch ${st.withShot ? 'on' : ''}" data-sup="shot" title="Bildschirmfoto anhängen"></button><span class="spc-hint">${ico('cam', 14)} Bildschirmfoto vom Hub anhängen</span>${st.shot && st.withShot ? `<img class="spc-shot" src="${st.shot}" alt="" />` : ''}
        <button class="btn primary spc-send" data-sup="send" ${st.busy || needAcct ? 'disabled' : ''}>${ico('send', 16)}<span>${st.busy ? 'Wird gesendet …' : 'Ticket senden'}</span></button></div></div>`;
  }

  function html() {
    if (!st.loading && Date.now() - st.loadedAt > 15000) refresh(true);
    return `<section class="sup2-hero">
        <div class="sup2-logo"><i></i><i></i><span>${ico('head', 40)}</span></div>
        <div class="sup2-txt"><small>Revulution Support</small><h2>Wie können wir dir helfen?</h2><p>Wähl unten ein Thema, ergänz den Entwurf und schick ihn ab. Die Antwort vom Team erscheint direkt hier im Chat.</p>
          <div class="sup2-pills spc-pills"><span>${ico('bolt', 13)} Antwort meist innert 24 h</span><span>${ico('lock', 13)} Direkt ans Team</span><span>${ico('cam', 13)} Bildschirmfoto möglich</span></div></div>
        <div class="sup2-art" aria-hidden="true"><div class="b1">Hallo! Was ist passiert?</div><div class="b2">Die App friert beim Öffnen ein …</div><div class="b3"><i></i><i></i><i></i></div></div>
      </section>
      <section class="spc">
        <aside class="spc-side">${sideHtml()}</aside>
        <div class="spc-main">
          <header class="spc-head">${headHtml()}</header>
          <div class="spc-thread">${threadHtml()}</div>
          <div class="spc-foot">${composeHtml()}</div>
        </div>
      </section>`;
  }

  const scrollDown = () => {
    const el = document.querySelector('.spc-thread');
    if (el) el.scrollTop = el.scrollHeight;
  };
  /** Nur Liste, Kopf und Verlauf neu zeichnen – Eingabefeld bleibt, wie es ist. */
  function patch() {
    const side = document.querySelector('.spc-side');
    const thread = document.querySelector('.spc-thread');
    const head = document.querySelector('.spc-head');
    if (!side || !thread) return;
    const atEnd = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 40;
    side.innerHTML = sideHtml();
    head.innerHTML = headHtml();
    thread.innerHTML = threadHtml();
    if (atEnd) scrollDown();
    // Sperre kam dazu oder fiel weg → Eingabe neu zeichnen
    const blocked = Boolean(document.querySelector('.spc-blocked'));
    if (blocked !== Boolean(st.mod?.active)) document.querySelector('.spc-foot').innerHTML = composeHtml();
  }
  const renderKeep = (focusSel) => {
    ctx().render();
    requestAnimationFrame(() => {
      scrollDown();
      const el = focusSel && document.querySelector(focusSel);
      if (el) {
        const f = el.dataset.supF;
        if (f && el.value !== st[f]) el.value = st[f];
        el.focus();
        grow(el);
      }
    });
  };

  // Textfeld wächst mit
  const grow = (el) => {
    el.style.height = 'auto';
    el.style.height = `${Math.min(320, el.scrollHeight + 2)}px`;
  };
  /** Cursor an die erste offene Stelle des Entwurfs („Wo: “) setzen. */
  const caretToGap = (el) => {
    const i = el.value.search(/: $/m);
    const pos = i >= 0 ? i + 2 : el.value.length;
    el.setSelectionRange(pos, pos);
  };
  const subjectOf = () => {
    const k = KIND[st.kind];
    const own = st.draft.split('\n').map((l) => l.replace(/^[^:]{1,30}:\s*/, '').trim()).find((l) => l && !/^Hallo Team/i.test(l) && !k.draft.includes(l));
    return `${k.name}${own ? `: ${own}` : ''}`.slice(0, 80);
  };

  document.addEventListener('input', (e) => {
    if (!active()) return;
    const f = e.target.dataset?.supF;
    if (!f) return;
    st[f] = e.target.value;
    if (e.target.tagName === 'TEXTAREA') grow(e.target);
  });
  document.addEventListener('keydown', (e) => {
    if (!active() || e.key !== 'Enter' || !e.ctrlKey) return;
    const f = e.target.dataset?.supF;
    if (f === 'reply' || f === 'draft') {
      e.preventDefault();
      document.querySelector(`[data-sup="${f === 'reply' ? 'reply' : 'send'}"]`)?.click();
    }
  });
  document.addEventListener('click', async (e) => {
    if (!active()) return;
    const k = e.target.closest('[data-sup-kind]')?.dataset.supKind;
    if (k) {
      // Entwurf nur ersetzen, wenn noch nichts Eigenes drinsteht
      const untouched = !st.draft.trim() || KINDS.some((x) => x[3].trim() === st.draft.trim());
      st.kind = k;
      if (untouched) st.draft = KIND[k].draft;
      st.err = '';
      ctx().render();
      requestAnimationFrame(() => {
        scrollDown();
        const el = document.querySelector('[data-sup-f="draft"]');
        if (el) {
          if (el.value !== st.draft) el.value = st.draft; // Hub-Render behält sonst den alten Text im fokussierten Feld
          el.focus();
          grow(el);
          caretToGap(el);
        }
      });
      return;
    }
    const open = e.target.closest('[data-sup-open]')?.dataset.supOpen;
    if (open) {
      Object.assign(st, { view: open, err: '', threadErr: '', reply: '' });
      if (!open.startsWith('local:')) {
        st.thread = st.thread?.ticket?.id === open ? st.thread : null;
        renderKeep();
        st.thread = await window.hub.support.thread(open).catch((err) => ((st.threadErr = errText(err)), null));
        if (st.thread) markSeen(st.thread.ticket);
        if (active()) renderKeep('[data-sup-f="reply"]');
      } else renderKeep();
      return;
    }
    const a = e.target.closest('[data-sup]')?.dataset.sup;
    if (!a) return;
    if (a === 'new') {
      Object.assign(st, { view: 'new', kind: '', draft: '', ref: '', refName: '', refImg: '', shot: '', withShot: false, err: '' });
      return renderKeep();
    }
    if (a === 'unref') {
      Object.assign(st, { ref: '', refName: '', refImg: '' });
      return ctx().render();
    }
    if (a === 'shot') {
      st.withShot = !st.withShot;
      if (st.withShot && !st.shot) st.shot = await window.hub.support.snap().catch(() => '');
      return renderKeep('[data-sup-f="draft"]');
    }
    if (a === 'send' || a === 'reply') {
      if (st.busy) return;
      st.busy = true;
      st.err = '';
      ctx().render();
      try {
        if (a === 'send') {
          const r = await window.hub.support.send({ kind: st.kind, subject: subjectOf(), text: st.draft, email: st.email, ref: st.ref, refName: st.refName, img: st.withShot ? st.shot : '' });
          localStorage.setItem('rev-tickets', JSON.stringify([{ id: r.id, kind: st.kind, subject: subjectOf(), text: st.draft.slice(0, 3000), at: Date.now() }, ...local()].slice(0, 30)));
          if (st.acct?.signedIn && r.ticket) {
            st.view = r.id;
            st.thread = { ticket: r.ticket, msgs: [] };
            st.mine = [r.ticket, ...(st.mine || []).filter((x) => x.id !== r.id)];
            markSeen(r.ticket);
          } else st.view = `local:${r.id}`;
          Object.assign(st, { kind: '', draft: '', ref: '', refName: '', refImg: '', shot: '', withShot: false });
          ctx().toast?.('Ticket gesendet.');
        } else {
          st.thread = await window.hub.support.reply(st.view, st.reply);
          st.reply = '';
          markSeen(st.thread.ticket);
          const i = (st.mine || []).findIndex((x) => x.id === st.view);
          if (i >= 0) st.mine[i] = st.thread.ticket;
        }
      } catch (err) {
        st.err = errText(err);
        if (/gesperrt|Timeout/.test(st.err)) st.mod = await window.hub.support.mod(true).catch(() => st.mod);
      }
      st.busy = false;
      renderKeep(a === 'reply' ? '[data-sup-f="reply"]' : null);
    }
  });

  T.register(PAGE, { nav: 'Support', title: 'Support', sub: 'Chat mit dem Team', icon: 'chat', tint: 'linear-gradient(135deg,#38bdf8,#6366f1)', desc: 'Bugs melden, Fragen stellen oder Feedback geben – im Chat direkt mit dem Revulution-Team.' }, html);
})();
